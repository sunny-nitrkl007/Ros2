# Loader Job Manager and Weigh App ROS 2 Migration Reference

## 1. Purpose

This document describes the current ROS 2 reference implementation for the Loader Job Manager and Weigh App migration.

## 2. Scope clarification

At present, **only the original Pass Tracker subsystem has been integrated from the legacy repository and behaviorally validated inside ROS 2**.

The complete legacy Job Manager and Weigh App applications have not yet been ported.

The current validated path is:

```text
Deterministic Weigh-state scenario
-> ROS 2 WeighState topic
-> ROS 2 Job Manager shell
-> original Pass Tracker C implementation
-> ROS 2 JobManagerState and PassTrackerDebug topics
```

The following areas are not yet integrated:

- Complete Job Manager task and load-record logic
- Multi-task and subtotal behavior
- Job Manager configuration, statistics, SimpleCal, and persistence
- Original `lps_common`, `lps_weighing`, and `lps_cal` runtime
- Raw machine and sensor inputs
- IMU calibration and Tip-Off Assist
- Complete load-record generation and publication
- External AIS/SCS compatibility bridges

The current implementation should therefore be used as a **reference for ROS 2 architecture, scheduling, communication, legacy-code integration, and automated validation**.

---

## 3. What is implemented

- Independent ROS 2 process shells for Job Manager and Weigh App
- Native ROS 2 communication between the application shells
- Job Manager processing at 10 Hz
- Weigh App processing shell at 50 Hz
- Weigh-state publication at 10 Hz
- Reliable state topics with bounded history
- Bounded, ordered command queues
- First valid Weigh-state gating
- Stale Weigh-state detection and safe state retention
- Direct integration of the original Pass Tracker C source
- Debug visibility for Pass Tracker state and one-cycle events
- Automated validation of:
  - Add pass
  - Multiple completed passes
  - Minus-one
  - Clear
  - Store
  - Stale input
  - State retention during stale input
  - Scenario recovery

---

## 4. What is real and what is simulated

| Area | Current implementation |
|---|---|
| Pass Tracker state machine | Original legacy C implementation |
| Pass Tracker truck and pass calculations | Original legacy C implementation |
| ROS 2 Job Manager shell | Implemented |
| ROS 2 Weigh App shell | Implemented |
| Weigh input used for Pass Tracker validation | Deterministic simulator |
| Dig state | Simulated |
| Dump state | Simulated |
| Bucket weight | Fixed simulated value of 2.5 tonnes |
| Bucket-weight latch | Simulated |
| Calibration state | Fixed simulated calibrated state |
| Weight accuracy | Simulated high-accuracy value |
| Original weighing algorithms | Not integrated into runtime |
| Original calibration algorithms | Not integrated into runtime |
| Job Manager task and load-record classes | Not integrated |
| Job Manager persistence | Not integrated |
| External AIS/SCS bridges | Not integrated |

---

## 5. Expected folder structure

The ROS 2 workspace and legacy repository must be adjacent:

```text
Latest-branch/
├── lps_ros2_m1/
│   ├── src/
│   ├── tools/
│   ├── build/
│   ├── install/
│   └── log/
│
└── ssp-CPM_Loader-ais/
    ├── lps_pass_tracker/
    ├── lps_common/
    ├── lps_weighing/
    ├── lps_cal/
    ├── lps_app_common/
    ├── CPM-Loader-ais/
    └── eta-ais/
```

The Pass Tracker implementation is not copied into the ROS 2 workspace. CMake compiles it directly from the adjacent legacy repository.

---

## 6. ROS 2 workspace structure

```text
lps_ros2_m1/src/
├── lps_interfaces/
├── lps_core/
├── lps_job_manager/
├── lps_weigh_app/
├── lps_simulators/
└── lps_integration_tests/
```

| Package | Responsibility |
|---|---|
| `lps_interfaces` | ROS 2 messages and services |
| `lps_core` | Latest-value cache, ordered command queue, and Pass Tracker adapter |
| `lps_job_manager` | ROS 2 Job Manager shell and Pass Tracker execution |
| `lps_weigh_app` | ROS 2 Weigh App shell |
| `lps_simulators` | Deterministic scenario, launch files, and automated validation |
| `lps_integration_tests` | Initial integration-test package |

---

## 7. Reused legacy Pass Tracker code

The Pass Tracker was not rewritten.

The original source files compiled directly from the legacy repository are:

```text
ssp-CPM_Loader-ais/lps_pass_tracker/src/LpsPtInit.c
ssp-CPM_Loader-ais/lps_pass_tracker/src/LpsPtUpdate.c
ssp-CPM_Loader-ais/lps_pass_tracker/src/LpsPtBucket.c
ssp-CPM_Loader-ais/lps_pass_tracker/src/LpsPtTruck.c
```

The public header is:

```text
ssp-CPM_Loader-ais/lps_pass_tracker/include/LpsPtPublic.h
```

The original APIs called by the ROS 2 adapter are:

```text
LpsPtInit()
LpsPtUpdate()
LpsPtRestoreTruck()
```

The integration boundary is:

```text
ROS 2 WeighState
-> PassTrackerInput
-> LpsPtInputs_t
-> original LpsPtUpdate()
-> LpsPtOutputs_t
-> PassTrackerOutput
-> ROS 2 JobManagerState and PassTrackerDebug
```

The original C implementation continues to make the pass-management decisions.

---

## 8. Current ROS 2 endpoints

| Endpoint | ROS 2 type | Direction and purpose |
|---|---|---|
| `/loader/weigh/state` | `lps_interfaces/msg/WeighState` | Weigh App shell or scenario to Job Manager |
| `/loader/job_manager/state` | `lps_interfaces/msg/JobManagerState` | Job Manager to consumers |
| `/loader/job_manager/pass_tracker_debug` | `lps_interfaces/msg/PassTrackerDebug` | Pass Tracker state and one-cycle validation events |
| `/loader/job_manager/command` | `lps_interfaces/srv/JobManagerCommand` | Client to Job Manager command queue |
| `/loader/weigh/command` | `lps_interfaces/srv/WeighCommand` | Job Manager or client to Weigh App command queue |
| `/loader/scenario/enabled` | `std_srvs/srv/SetBool` | Test-only scenario pause and resume |

---

## 9. Current data flow

```text
/lps_pass_tracker_scenario
        |
        | publishes WeighState at 10 Hz
        v
/loader/weigh/state
        |
        | subscription stores latest complete state
        v
/lps_job_manager
        |
        | 100 ms deterministic timer
        v
PassTrackerAdapter
        |
        | converts to LpsPtInputs_t
        v
Original LpsPtUpdate()
        |
        | returns LpsPtOutputs_t
        v
PassTrackerOutput
        |
        +--> /loader/job_manager/state
        |
        +--> /loader/job_manager/pass_tracker_debug
```

The ROS subscription callback does not invoke Pass Tracker directly. It only stores the latest complete state and local receive time. The 100 ms Job Manager timer reads the cache, checks freshness, consumes at most one queued command, and then calls the original Pass Tracker.

---

## 10. Pass Tracker scenario flow

The deterministic scenario repeats approximately every five seconds:

```text
Fully racked and idle
-> digging
-> valid high-accuracy 2.5-tonne latch
-> partial dump
-> fully racked and idle
```

Important simulated values:

```text
calibration_status = 0
best_bucket_weight_tonnes = 2.5
payload_calculation_method = 769
```

`769` is hexadecimal `0x0301`. The accuracy portion is `3`, meaning high accuracy.

### Important legacy mappings

| Field | Value | Meaning |
|---|---:|---|
| Calibration status | 0 | Calibrated |
| Calibration status | 1 | Uncalibrated |
| Dig status | 1 | Not digging |
| Dig status | 3 | Digging |
| Dump status | 1 | Fully racked |
| Dump status | 3 | Partially dumped |
| Dump status | 4 | Fully dumped |
| Pass Tracker state | 17 / `0x11` | Wait for latch |
| Pass Tracker state | 33 / `0x21` | Wait for dump |
| Pass Tracker state | 49 / `0x31` | Tip-Off |
| Pass Tracker state | 4 / `0x04` | Uncalibrated mode |

### Pass lifecycle

1. Pass Tracker starts in `WAIT_FOR_LATCH_BRI`.
2. The scenario publishes a valid latched 2.5-tonne bucket weight.
3. The adapter maps ROS 2 fields into `LpsPtInputs_t`.
4. The original Pass Tracker starts an active pass.
5. State changes to `WAIT_FOR_DUMP_ARI`.
6. Pass count and truck weight increase.
7. The scenario publishes partial dump.
8. The original Pass Tracker closes and retains the pass.
9. A one-cycle `addPass` event is produced.
10. Pass Tracker requests bucket-weight unlatching.
11. State returns to `WAIT_FOR_LATCH_BRI`.

Expected accumulation:

```text
1 pass  -> 2.5 tonnes
2 passes -> 5.0 tonnes
3 passes -> 7.5 tonnes
```

---

## 11. Command flow

The service callback does not execute the command directly.

```text
ROS 2 service request
-> bounded ordered queue
-> next Job Manager 100 ms cycle
-> one-cycle legacy request field
-> original LpsPtUpdate()
-> event output
-> request field reset
```

Current command values used by the reference implementation:

| Command | Meaning |
|---:|---|
| 1 | Zero |
| 2 | Minus-one |
| 3 | Clear |
| 4 | Store |

The current store validation proves that Pass Tracker generates its store event and clears its internal truck state. Complete Job Manager load-record generation is not yet integrated.

---

## 12. Files to study

### ROS 2 contracts

```text
src/lps_interfaces/msg/WeighState.msg
src/lps_interfaces/msg/JobManagerState.msg
src/lps_interfaces/msg/PassTrackerDebug.msg
src/lps_interfaces/srv/JobManagerCommand.srv
src/lps_interfaces/srv/WeighCommand.srv
src/lps_interfaces/CMakeLists.txt
src/lps_interfaces/package.xml
```

### Legacy Pass Tracker adapter

```text
src/lps_core/include/lps_core/pass_tracker_adapter.hpp
src/lps_core/src/pass_tracker_adapter.cpp
src/lps_core/CMakeLists.txt
src/lps_core/package.xml
```

These files demonstrate:

- Inclusion of legacy C headers
- Direct compilation and linking of legacy C source
- Neutral C++ input and output structures
- ROS-to-legacy field conversion
- Original API invocation
- One-cycle request reset
- Isolation of legacy structures behind a private implementation

### Deterministic callback isolation

```text
src/lps_core/include/lps_core/latest_value_cache.hpp
src/lps_core/include/lps_core/ordered_queue.hpp
```

### Job Manager ROS 2 shell

```text
src/lps_job_manager/src/job_manager_node.cpp
src/lps_job_manager/CMakeLists.txt
src/lps_job_manager/package.xml
```

This is the primary reference for:

- Topic subscription
- Latest-state caching
- First-message gating
- Stale-input checks
- Deterministic timer execution
- Ordered command consumption
- Pass Tracker adapter invocation
- State and debug publication

### Weigh App ROS 2 shell

```text
src/lps_weigh_app/src/weigh_app_node.cpp
src/lps_weigh_app/CMakeLists.txt
src/lps_weigh_app/package.xml
```

This demonstrates an independent node, 20 ms processing timer, 100 ms publication timer, state publication, and service handling. Its weighing business behavior is currently simulated.

### Scenario and automated validation

```text
src/lps_simulators/src/pass_tracker_scenario_node.cpp
src/lps_simulators/scripts/pass_tracker_validation_node.py
src/lps_simulators/launch/pass_tracker_scenario.launch.py
src/lps_simulators/launch/pass_tracker_validation.launch.py
src/lps_simulators/CMakeLists.txt
src/lps_simulators/package.xml
```

### Build integration

```text
tools/build_m2_humble.sh
```

### Original legacy implementation

```text
../ssp-CPM_Loader-ais/lps_pass_tracker/include/LpsPtPublic.h
../ssp-CPM_Loader-ais/lps_pass_tracker/src/LpsPtInit.c
../ssp-CPM_Loader-ais/lps_pass_tracker/src/LpsPtUpdate.c
../ssp-CPM_Loader-ais/lps_pass_tracker/src/LpsPtBucket.c
../ssp-CPM_Loader-ais/lps_pass_tracker/src/LpsPtTruck.c
../ssp-CPM_Loader-ais/lps_pass_tracker/src/LpsPtPrivate.h
```

---

## 13. Build prerequisites

- Ubuntu
- ROS 2 Humble
- `colcon`
- CMake
- C and C++ compilers
- Python 3
- ROS 2 `std_srvs`

Verify ROS 2:

```bash
source /opt/ros/humble/setup.bash
ros2 --help
```

Verify the legacy repository:

```bash
realpath ../ssp-CPM_Loader-ais
```

---

## 14. Clean build

Enter the workspace:

```bash
cd ~/CAT/Milestone_2/CAT-Usecase/Latest-branch/lps_ros2_m1
```

Source ROS 2:

```bash
source /opt/ros/humble/setup.bash
```

Preview the exact clean-build paths:

```bash
printf '%s\n' build install log
```

Clean only those paths:

```bash
rm -rf -- build install log
```

Build:

```bash
./tools/build_m2_humble.sh "$(realpath ../ssp-CPM_Loader-ais)"
```

Expected result:

```text
Summary: 6 packages finished
```

Source the workspace:

```bash
source /opt/ros/humble/setup.bash
source install/setup.bash
```

Verify packages:

```bash
ros2 pkg list | grep '^lps_'
```

Expected packages:

```text
lps_core
lps_integration_tests
lps_interfaces
lps_job_manager
lps_simulators
lps_weigh_app
```

---

## 15. Automated demonstration

Ensure no old LPS nodes are running:

```bash
ros2 node list | grep lps
```

Run:

```bash
ros2 launch lps_simulators pass_tracker_validation.launch.py
```

Expected result:

```text
PASS: normal add-pass event
PASS: two completed passes
PASS: minus-one event
PASS: minus-one state
PASS: clear event
PASS: clear state
PASS: pass for store
PASS: store event
PASS: store state
PASS: stale input detected
PASS: stale state retained without events
PASS: scenario recovery
ALL M2.1 AUTOMATED VALIDATIONS PASSED
```

---

## 16. Manual demonstration

Start the manual scenario:

```bash
ros2 launch lps_simulators pass_tracker_scenario.launch.py
```

### Watch Weigh input

```bash
watch -n 0.2 "ros2 topic echo /loader/weigh/state --once | grep -E 'dig_status:|calibration_status:|dump_status:|best_bucket_weight_tonnes:|payload_calculation_method:|bucket_weight_latched:'"
```

### Watch Pass Tracker state

```bash
watch -n 0.2 "ros2 topic echo /loader/job_manager/pass_tracker_debug --once | grep -E 'pt_current_state:|pass_count:|truck_weight:|truck_start_weight:|truck_pass_active:|input_fresh:'"
```

### Watch one-cycle events

```bash
ros2 topic echo /loader/job_manager/pass_tracker_debug | grep --line-buffered -E 'pt_current_state:|pass_count:|truck_weight:|truck_pass_active:|add_pass: true|add_pass_weight:|add_pass_accuracy:|remove_pass: true|clear: true|store: true|unlatch_current_bucket_weight: true|input_fresh:'
```

### Verify topic rates

```bash
ros2 topic hz /loader/weigh/state
```

```bash
ros2 topic hz /loader/job_manager/state
```

Both should report approximately 10 Hz.

### Verify one publisher and one subscriber

```bash
ros2 topic info /loader/weigh/state --verbose
```

During the scenario test, the expected publisher is `/lps_pass_tracker_scenario` and the expected subscriber is `/lps_job_manager`.

---

## 17. Manual command examples

Run these only while the manual scenario is active.

### Minus-one

```bash
ros2 service call /loader/job_manager/command lps_interfaces/srv/JobManagerCommand "{requester: 'team_demo', legacy_request_id: 101, command: 2}"
```

### Clear

```bash
ros2 service call /loader/job_manager/command lps_interfaces/srv/JobManagerCommand "{requester: 'team_demo', legacy_request_id: 102, command: 3}"
```

### Store

```bash
ros2 service call /loader/job_manager/command lps_interfaces/srv/JobManagerCommand "{requester: 'team_demo', legacy_request_id: 103, command: 4}"
```

Use the one-cycle event observer before sending each command so the event is not missed.

---

## 18. Current AIS/SCS replacement summary

| Existing responsibility | Current ROS 2 replacement | Status |
|---|---|---|
| AIS task lifecycle for node shells | ROS 2 process, constructor, executor, and timers | Implemented for current shells |
| Weigh-to-Job Manager SCS state | `/loader/weigh/state` | Implemented |
| Job Manager SCS state output | `/loader/job_manager/state` | Partially implemented |
| Job Manager debug output | `/loader/job_manager/pass_tracker_debug` | Implemented |
| Job Manager request input | `/loader/job_manager/command` | Core validation commands implemented |
| Weigh request input | `/loader/weigh/command` | Basic queue path implemented |
| SCS continuous-state polling | ROS subscription plus latest-value cache | Implemented |
| SCS event ordering | Bounded ordered command queue | Implemented |
| InterfaceDb binding | Explicit ROS 2 endpoint creation | Implemented for current endpoints |
| AIS logging in new ROS code | `RCLCPP_*` logging | Implemented in new node code |
| Full Job Manager AIS/SCS replacement | Platform-neutral application core plus ROS adapters | Pending |
| Full Weigh App AIS/SCS replacement | Platform-neutral application core plus ROS adapters | Pending |

---

## 19. Remaining porting work

1. Integrate the existing Job Manager task and load-record classes.
2. Integrate multi-task and subtotal behavior.
3. Integrate Job Manager configuration, statistics, SimpleCal, and persistence.
4. Integrate the original `lps_common`, `lps_weighing`, and `lps_cal` runtime.
5. Integrate IMU calibration and Tip-Off Assist.
6. Replace AIS machine, PWM, CAN, DataLink, clock, health, and calibration interfaces with ROS 2 equivalents.
7. Generate and publish complete load records.
8. Create compatibility bridges where surrounding applications remain on AIS/SCS.
9. Complete restart, persistence, deployment, and behavior-equivalence testing.

---

## 20. Recommended architecture for further porting

```text
ROS 2 node
    Communication, lifecycle, timers, and endpoint ownership

Platform-neutral application core
    Reused Job Manager or Weigh App business behavior

Adapter layer
    ROS 2 types, persistence, clock, machine inputs, and external services

Original business libraries
    Pass Tracker, weighing, calibration, and associated algorithms
```

AIS dependencies should be removed by replacing lifecycle, communication, logging, configuration, persistence, and hardware access with explicit ROS 2 or platform-neutral equivalents. Compiler-only stubs should not be treated as the final port.

---

## 21. Key takeaway

The current implementation proves that:

- Separate ROS 2 application processes can replace the AIS task shells.
- Direct Job Manager and Weigh App communication can use native ROS 2.
- Original C business logic can be compiled directly from the legacy repository.
- Asynchronous ROS callbacks can be isolated from deterministic legacy processing.
- Legacy state-machine behavior and one-cycle events can be automatically validated.

Only the original Pass Tracker subsystem is currently integrated and validated. The remaining Job Manager and Weigh App business logic still needs to be ported using the same separation principles.
