#!/usr/bin/env bash
set -eo pipefail
if [ "$#" -ne 1 ]; then
  echo "Usage: $0 /absolute/path/to/super-project-root"
  exit 2
fi
LEGACY_ROOT="$(realpath "$1")"
if [ ! -d "$LEGACY_ROOT/lps_pass_tracker/src" ]; then
  echo "ERROR: $LEGACY_ROOT/lps_pass_tracker/src not found"
  exit 2
fi
if [ ! -f /opt/ros/humble/setup.bash ]; then
  echo "ERROR: ROS 2 Humble setup not found"
  exit 2
fi
source /opt/ros/humble/setup.bash
set -u
rm -rf build/lps_core build/lps_job_manager install/lps_core install/lps_job_manager
colcon build --symlink-install --event-handlers console_direct+   --cmake-args -DLPS_LEGACY_ROOT="$LEGACY_ROOT" -DLPS_ENABLE_PASS_TRACKER=ON
