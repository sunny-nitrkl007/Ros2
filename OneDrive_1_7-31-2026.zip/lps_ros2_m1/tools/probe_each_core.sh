#!/usr/bin/env bash
set -eo pipefail
if [ "$#" -ne 1 ]; then echo "Usage: $0 LEGACY_ROOT"; exit 2; fi
ROOT="$(realpath "$1")"
source /opt/ros/humble/setup.bash
BUILD="build/lps_full_port_probe"
if [ ! -d "$BUILD" ]; then
  echo "Run build_full_application_probe.sh first."
  exit 2
fi
cmake --build "$BUILD" --target lps_weigh_legacy_core_probe -j1 2>&1 | tee full_application_probe_logs/10_weigh_serial.log || true
cmake --build "$BUILD" --target lps_job_manager_domain_probe -j1 2>&1 | tee full_application_probe_logs/11_job_manager_serial.log || true
grep -nE 'fatal error:| error:|undefined reference' full_application_probe_logs/10_weigh_serial.log > full_application_probe_logs/12_weigh_errors.txt || true
grep -nE 'fatal error:| error:|undefined reference' full_application_probe_logs/11_job_manager_serial.log > full_application_probe_logs/13_job_manager_errors.txt || true
echo '[OK] Per-core serial reports generated.'
