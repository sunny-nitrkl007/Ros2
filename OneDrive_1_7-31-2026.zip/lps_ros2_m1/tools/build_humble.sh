#!/usr/bin/env bash

set -eo pipefail

if [ ! -f /opt/ros/humble/setup.bash ]; then
    echo "ERROR: /opt/ros/humble/setup.bash was not found."
    exit 1
fi

source /opt/ros/humble/setup.bash

set -u

colcon build \
    --symlink-install \
    --event-handlers console_direct+
