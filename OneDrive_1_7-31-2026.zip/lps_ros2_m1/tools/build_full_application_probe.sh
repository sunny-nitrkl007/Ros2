#!/usr/bin/env bash
set -o pipefail
if [ "$#" -ne 1 ]; then
  echo "Usage: $0 /absolute/path/to/ssp-CPM_Loader-ais"
  exit 2
fi
ROOT="$(realpath "$1")"
LOG_DIR="full_application_probe_logs"
rm -rf "$LOG_DIR" build/lps_full_port_probe install/lps_full_port_probe
mkdir -p "$LOG_DIR"
unset AMENT_PREFIX_PATH CMAKE_PREFIX_PATH COLCON_PREFIX_PATH
source /opt/ros/humble/setup.bash

set +e
colcon build --packages-select lps_full_port_probe --event-handlers console_direct+   --cmake-args -DLPS_ENABLE_FULL_APPLICATION_PROBE=ON -DLPS_LEGACY_ROOT="$ROOT"   > "$LOG_DIR/00_full_build.log" 2>&1
STATUS=$?
set -e

# Produce short, useful reports even when the broad build fails.
grep -nE 'fatal error:| error:|undefined reference|CMake Error' "$LOG_DIR/00_full_build.log"   > "$LOG_DIR/01_errors.txt" || true
grep -oE 'fatal error: [^:]+|undefined reference to .[^.]+.' "$LOG_DIR/00_full_build.log"   | sort -u > "$LOG_DIR/02_unique_blockers.txt" || true
grep -nE 'Building (C|CXX) object|Linking (C|CXX)' "$LOG_DIR/00_full_build.log"   > "$LOG_DIR/03_compile_progress.txt" || true

printf 'Full log: %s/00_full_build.log
' "$LOG_DIR"
printf 'Errors: %s/01_errors.txt
' "$LOG_DIR"
printf 'Unique blockers: %s/02_unique_blockers.txt
' "$LOG_DIR"
printf 'Compile progress: %s/03_compile_progress.txt
' "$LOG_DIR"
if [ "$STATUS" -eq 0 ]; then
  echo '[PASS] Both broad application-core probes compiled.'
else
  echo '[EXPECTED DISCOVERY RESULT] Broad probe exposed blockers; upload 01_errors.txt and 02_unique_blockers.txt.'
fi
exit "$STATUS"
