#!/usr/bin/env bash
set -euo pipefail
docker build -f docker/Dockerfile.jazzy -t lps-ros2-m1-jazzy .
docker run --rm lps-ros2-m1-jazzy
