
After building:

```bash
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch lps_simulators milestone1.launch.py
```

Inspect the Job Manager state:

```bash
ros2 topic echo /loader/job_manager/state --once
```
