# Implementation Status

## Completed 

- ROS 2 package structure for Humble and Jazzy
- Native Job Manager and Weigh App state topics
- Native bidirectional command services
- Job Manager 100 ms deterministic timer
- Weigh App 20 ms processing timer
- Weigh App 100 ms publication timer
- First-valid-Weigh-state gate
- Latest-value state caches
- Ordered command queues
- State freshness tracking
- Asynchronous service clients
- Independent process launch
- Integration test skeleton
- Jazzy Docker build and test path

## Native ROS 2 endpoints

- `/loader/weigh/state`
- `/loader/job_manager/state`
- `/loader/weigh/command`
- `/loader/job_manager/command`

## Next milestone

1. Add a CMake vendor target for the existing `lps_pass_tracker/src/*.c` files.
2. Add a C-linkage wrapper for `LpsPtPublic.h` if the header does not already
   provide C++ guards.
3. Replace `JobManagerMockCore::step()` with calls to `LpsPtInit()`,
   `LpsPtUpdate()` and `LpsPtRestoreTruck()`.
4. Port the existing command-priority behavior into the deterministic cycle.
5. Add golden-vector tests comparing legacy and ROS 2 pass-tracker outputs.

## Deliberately deferred

- AIS/SCS bridge binaries
- HAL, CAN, PWM and machine input adapters
- Existing NVM persistence integration
- Full legacy Weigh state contract
- Existing Weigh and calibration C-core integration
- Legal-for-Trade production validation

***

# What is real versus simulated

| Component                     | Real existing implementation |     ROS 2 implementation |     Simulated |
| ----------------------------- | ---------------------------: | -----------------------: | ------------: |
| ROS 2 transport               |                          N/A |                      Yes |            No |
| Job Manager 10 Hz scheduling  |    Legacy behavior preserved |                      Yes |            No |
| Weigh 50 Hz scheduling        |      Legacy timing preserved |                      Yes |            No |
| Weigh 10 Hz state publication |      Legacy timing preserved |                      Yes |            No |
| Pass Tracker state machine    |                          Yes |               Integrated |            No |
| Pass Tracker truck state      |                          Yes |               Integrated |            No |
| Pass Tracker command priority |                          Yes |     Partially integrated |            No |
| Pass Tracker one-cycle flags  |                          Yes |               Integrated |            No |
| Weigh state values            |                           No |     Published over ROS 2 |           Yes |
| Dig sequence                  |                           No | Deterministic test input |           Yes |
| Dump sequence                 |                           No | Deterministic test input |           Yes |
| Bucket weight                 |                           No |   Fixed 2.5 t test input |           Yes |
| Calibration status            |                           No |   Fixed calibrated input |           Yes |
| Job Manager task records      |                      Not yet |      Minimal fields only | Partly absent |
| Weighing algorithms           |                      Not yet |          Node shell only |           Yes |
| Calibration algorithms        |                      Not yet |           Not integrated |           Yes |
| Persistence                   |                      Not yet |           Not integrated |   No behavior |
| Hardware inputs               |                      Not yet |           Not integrated |           Yes |
| AIS/SCS bridge                |                      Not yet |          Not implemented |            No |
| Automated equivalence suite   |                      Not yet |       Initial tests only |       Limited |

***