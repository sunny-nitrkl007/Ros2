
# 1. Current Capabilities

The demo proves all of the following:

| Capability                                       | Demonstrated status             |
| ------------------------------------------------ | ------------------------------- |
| Separate ROS 2 processes                         | Working                         |
| Native ROS 2 Job Manager and Weigh communication | Working                         |
| Original Job Manager timing                      | 10 Hz                           |
| Original Weigh processing timing                 | 50 Hz                           |
| Original Weigh publication timing                | 10 Hz                           |
| Original Pass Tracker C source reuse             | Working                         |
| C-to-C++ adapter boundary                        | Working                         |
| Real Pass Tracker initialization                 | Working                         |
| Real Pass Tracker update cycle                   | Working                         |
| Pass creation                                    | Working                         |
| Pass completion                                  | Working                         |
| Truck weight accumulation                        | Working                         |
| Minus-one                                        | Working                         |
| Clear                                            | Working                         |
| Store event                                      | Working                         |
| Stale-input protection                           | Working                         |
| Communication recovery                           | Working                         |
| Automated validation                             | All implemented M2.1 tests pass |

The demo does **not** claim that both apps are fully ported yet. It demonstrates that the selected migration architecture works and that a real legacy business subsystem is running inside ROS 2.

***

# 2. Current architecture

## Legacy architecture

Conceptually, the original apps operate like this:

```text
Legacy Weigh App
    |
    | SCS Weigh Tx channel
    v
Legacy Job Manager
    |
    | SCS Job Manager Tx channel
    v
UI and other legacy applications
```

Both apps also depend on AIS for:

* Task lifecycle
* Interface discovery and binding
* Logging
* Configuration access
* External application communication
* Hardware and machine inputs
* Persistence helpers

## Current ROS 2 architecture

The current validated path is:

```text
Pass Tracker scenario node
    |
    | /loader/weigh/state
    | Reliable ROS 2 topic, 10 Hz
    v
ROS 2 Job Manager node
    |
    | ROS-to-legacy conversion
    v
Original Pass Tracker C core
    |
    | Legacy outputs converted to ROS 2
    v
/loader/job_manager/state
/loader/job_manager/pass_tracker_debug
```

A separate ROS 2 Weigh App shell also exists:

```text
ROS 2 Weigh App shell
    |
    | /loader/weigh/state
    v
ROS 2 Job Manager
```

During Pass Tracker validation, the deterministic scenario node replaces the Weigh App shell so that controlled input sequences can be generated.

***

# 3. How the old repository is integrated

This is the most important technical point to show.

## Repository relationship

Assuming the directory layout is:

```text
Latest-branch/
├── lps_ros2_m1/
└── ssp-CPM_Loader-ais/
```

The ROS 2 workspace does not copy or rewrite the Pass Tracker implementation.

Instead, CMake compiles the original source files directly from:

```text
ssp-CPM_Loader-ais/lps_pass_tracker/src/
```

The reused legacy source files are:

```text
LpsPtBucket.c
LpsPtInit.c
LpsPtTruck.c
LpsPtUpdate.c
```

The reused public API is:

```text
LpsPtInit()
LpsPtUpdate()
LpsPtRestoreTruck()
```

## Integration structure

```text
Legacy repository
└── lps_pass_tracker
    ├── Original C source
    └── Original headers
             |
             | CMake compiles directly
             v
ROS 2 lps_core package
    ├── Legacy Pass Tracker static library
    └── PassTrackerAdapter
             |
             | C++ adapter
             v
ROS 2 lps_job_manager package
```

## Adapter responsibility

The C++ adapter converts ROS-neutral input into the original legacy structure:

```text
PassTrackerInput
    -> LpsPtInputs_t
    -> LpsPtUpdate()
    -> LpsPtOutputs_t
    -> PassTrackerOutput
```

The adapter does not reimplement the state machine.

It only handles:

* Type conversion
* Enum conversion
* One-cycle request pulses
* Legacy initialization
* Legacy output extraction
* Ownership of the legacy implementation boundary

***

# 4. Key exact legacy mappings

These values were taken from the original headers.

## Calibration

| Value | Meaning      |
| ----: | ------------ |
|     0 | Calibrated   |
|     1 | Uncalibrated |

## Dig state

| Value | Meaning           |
| ----: | ----------------- |
|     0 | Unknown           |
|     1 | Not digging       |
|     2 | Tentative digging |
|     3 | Digging           |

## Dump state

| Value | Meaning                         |
| ----: | ------------------------------- |
|     0 | Unknown                         |
|     1 | Fully racked                    |
|     2 | Not fully racked and not dumped |
|     3 | Partially dumped                |
|     4 | Fully dumped                    |

## Pass Tracker state

| Decimal |    Hex | Meaning           |
| ------: | -----: | ----------------- |
|       4 | `0x04` | Uncalibrated mode |
|      17 | `0x11` | Wait for latch    |
|      33 | `0x21` | Wait for dump     |
|      49 | `0x31` | Tip-Off           |

## Weight accuracy

The scenario uses:

```text
payload_calculation_method = 769
```

This equals:

```text
0x0301
```

Bits 8–11 contain:

```text
3 = high accuracy
```

The real Pass Tracker requires at least medium accuracy before accepting a latched bucket weight.

***

# 5. Demo preparation

## Terminal setup

Open three terminals:

* Terminal 1: build and launch
* Terminal 2: inspect ROS 2 graph and live state
* Terminal 3: optional manual commands

Before starting, stop any old launch processes.

## Verify no old nodes are running

Run:

```bash
ros2 node list | grep lps
```

Expected before the demo:

```text
No output
```

If nodes are listed, return to the terminals where those nodes were launched and stop them using `Ctrl+C`.

Do not use process-kill commands unless necessary.

***

# 6. Demo Part A: show the repository integration

From the ROS 2 workspace:

```bash
cd ~/CAT/Milestone_2/CAT-Usecase/Latest-branch/lps_ros2_m1
```

## Show the legacy repository location

```bash
realpath ../ssp-CPM_Loader-ais
```

## Show the original Pass Tracker sources

```bash
find ../ssp-CPM_Loader-ais/lps_pass_tracker/src -maxdepth 1 -type f -name 'LpsPt*.c' -print
```

Expected files include:

```text
LpsPtBucket.c
LpsPtInit.c
LpsPtTruck.c
LpsPtUpdate.c
```

## Show that the adapter calls the real API

```bash
grep -nE 'LpsPtInit|LpsPtUpdate|LpsPtRestoreTruck' src/lps_core/src/pass_tracker_adapter.cpp
```

Expected output includes calls to the original functions.

## Show that no copied Pass Tracker implementation exists in ROS 2 source

```bash
find src -type f -name 'LpsPtUpdate.c' -print
```

Expected:

```text
No output
```

This proves the original implementation is compiled from the adjacent legacy repository rather than copied into the ROS 2 workspace.

***

# 7. Demo Part B: build the integration

Source ROS 2:

```bash
source /opt/ros/humble/setup.bash
```

Run the Milestone 2 build:

```bash
./tools/build_m2_humble.sh "$(realpath ../ssp-CPM_Loader-ais)"
```

Expected final result:

```text
Summary: 6 packages finished
```

Warnings about the following variables being unused by unrelated packages are non-blocking:

```text
LPS_ENABLE_PASS_TRACKER
LPS_LEGACY_ROOT
```

Only `lps_core` needs those values.

## Source the completed build

```bash
source /opt/ros/humble/setup.bash
```

```bash
source install/setup.bash
```

## Show the packages

```bash
ros2 pkg list | grep '^lps_'
```

Expected packages include:

```text
lps_core
lps_integration_tests
lps_interfaces
lps_job_manager
lps_simulators
lps_weigh_app
```

***

# 8. Demo Part C: show the ROS 2 endpoints

## Show interfaces

```bash
ros2 interface show lps_interfaces/msg/WeighState
```

```bash
ros2 interface show lps_interfaces/msg/JobManagerState
```

```bash
ros2 interface show lps_interfaces/msg/PassTrackerDebug
```

```bash
ros2 interface show lps_interfaces/srv/JobManagerCommand
```

Explain that:

* State travels over topics.
* Commands enter through bounded queues.
* Service callbacks do not directly mutate the Pass Tracker.
* The deterministic 100 ms Job Manager cycle processes queued commands.

***

# 9. Demo Part D: run the automated validation

This is the strongest and simplest demonstration.

## Terminal 1

Run:

```bash
ros2 launch lps_simulators pass_tracker_validation.launch.py
```

Expected startup:

```text
Job Manager started with existing Pass Tracker C core and debug output
Pass Tracker scenario publisher started at 10 Hz
```

The automated validator then reports:

```text
PASS: normal add-pass event
PASS: two completed passes
PASS: minus-one event
PASS: minus-one state
PASS: clear event
PASS: clear state
PASS: pass for store
PASS: store event
PASS: store state
PASS: stale input detected
PASS: stale state retained without events
PASS: scenario recovery
ALL M2.1 AUTOMATED VALIDATIONS PASSED
```

This demonstration takes approximately 15–25 seconds.

The validator exits cleanly when complete. Job Manager and the scenario continue running until the launch is stopped.

***

# 10. Demo Part E: inspect the running ROS graph

While Terminal 1 is running, use Terminal 2.

## Source the workspace

```bash
cd ~/CAT/Milestone_2/CAT-Usecase/Latest-branch/lps_ros2_m1
```

```bash
source /opt/ros/humble/setup.bash
```

```bash
source install/setup.bash
```

## Show the nodes

```bash
ros2 node list
```

During validation, expected nodes are:

```text
/lps_job_manager
/lps_pass_tracker_scenario
/lps_pass_tracker_validation
```

The validation node disappears after completing successfully.

## Show the topics

```bash
ros2 topic list | grep loader
```

Expected topics include:

```text
/loader/weigh/state
/loader/job_manager/state
/loader/job_manager/pass_tracker_debug
```

## Prove there is one Weigh publisher

```bash
ros2 topic info /loader/weigh/state --verbose
```

Expected:

```text
Publisher count: 1
Subscription count: 1
```

The publisher is:

```text
/lps_pass_tracker_scenario
```

The subscriber is:

```text
/lps_job_manager
```

Explain that this avoids nondeterministic testing with multiple publishers.

***

# 11. Demo Part F: show the real state machine

For a live compact view:

```bash
ros2 topic echo /loader/job_manager/pass_tracker_debug | grep --line-buffered -E 'pt_current_state:|pass_count:|truck_weight:|truck_pass_active:|add_pass: true|add_pass_weight:|add_pass_accuracy:|remove_pass: true|clear: true|store: true|unlatch_current_bucket_weight: true|input_fresh:'
```

## Expected normal pass transition

### Waiting for weight latch

```text
pt_current_state: 17
truck_pass_active: false
```

### Valid latched bucket

```text
pt_current_state: 33
truck_pass_active: true
```

The Pass Tracker increments the active pass:

```text
pass_count: 1
truck_weight: 2.5
```

### Partial dump and cycle close

```text
pt_current_state: 17
truck_pass_active: false
add_pass: true
add_pass_weight: 2.5
add_pass_accuracy: 3
unlatch_current_bucket_weight: true
```

On the next cycle:

```text
add_pass: false
```

This proves that the original one-cycle legacy event behavior is preserved.

Stop the observer with `Ctrl+C`.

***

# 12. Demo Part G: show exact accumulation

The scenario adds one 2.5-tonne pass approximately every five seconds.

Run:

```bash
ros2 topic echo /loader/job_manager/pass_tracker_debug --once
```

Possible output after several cycles:

```text
pass_count: 4
truck_weight: 10.0
```

Explain the consistency check:

```text
4 passes × 2.5 tonnes = 10.0 tonnes
```

During earlier validation, the system reached:

```text
pass_count: 54
truck_weight: 135.0
```

which is also exact:

```text
54 × 2.5 = 135.0 tonnes
```

***

# 13. Demo Part H: demonstrate stale-input protection

The automated validator already proves this, but it can also be shown manually.

For a clean manual stale-input demo, use separate processes instead of the combined launch.

First stop the combined launch with `Ctrl+C`.

## Terminal 1: start Job Manager

```bash
ros2 run lps_job_manager lps_job_manager_node
```

## Terminal 2: start the scenario

```bash
ros2 run lps_simulators lps_pass_tracker_scenario_node
```

## Terminal 3: monitor freshness

```bash
ros2 topic echo /loader/job_manager/pass_tracker_debug | grep --line-buffered 'input_fresh:'
```

Expected while scenario is running:

```text
input_fresh: true
```

Stop only Terminal 2 using `Ctrl+C`.

Expected in Terminal 1:

```text
WeighState is stale; Pass Tracker step skipped
```

Expected in Terminal 3:

```text
input_fresh: false
```

Restart the scenario in Terminal 2:

```bash
ros2 run lps_simulators lps_pass_tracker_scenario_node
```

Expected recovery:

```text
input_fresh: true
```

Job Manager remains alive throughout the interruption.

***

# 14. How the implementation works internally

## Scenario node

The scenario node publishes a controlled sequence:

```text
Idle and fully racked
-> Digging
-> High-accuracy weight latched
-> Partial dump
-> Return fully racked
```

The scenario directly publishes `WeighState` and is used only to validate the Pass Tracker path.

## Job Manager subscription

The subscription callback:

1. Receives `WeighState`.
2. Stores the message in a latest-value cache.
3. Records local receive time.
4. Does not call Pass Tracker directly.

## Job Manager timer

Every 100 ms:

1. Read the latest consistent Weigh snapshot.
2. Check whether the first message has arrived.
3. Check message freshness.
4. Dequeue one command if available.
5. Convert ROS-neutral data into Pass Tracker input.
6. Call the original `LpsPtUpdate()`.
7. Convert the original outputs.
8. Publish Job Manager state.
9. Publish debug state.

## Command handling

The service callback only queues commands.

```text
ROS 2 service callback
-> bounded ordered queue
-> 100 ms Job Manager cycle
-> one-cycle legacy request field
-> original Pass Tracker
```

This prevents concurrent ROS callbacks from mutating the legacy state machine.

***

# 15. Suggested presentation flow

## Slide or speaking point 1: problem statement

> Job Manager and Weigh App currently depend on AIS task lifecycle and SCS communication. The goal is to port both apps to ROS 2 without rewriting established business algorithms.

## Speaking point 2: migration principle

> Separate business logic from platform integration. Preserve the original C/C++ functionality and replace AIS/SCS lifecycle and communication with ROS 2 equivalents.

## Speaking point 3: first completed subsystem

> Pass Tracker was selected as the first real legacy subsystem because it is central to Job Manager pass, truck, store, clear, and Tip-Off behavior.

## Speaking point 4: implementation

> The original C source is compiled directly from the old repository using CMake and linked through a narrow C++ adapter into the ROS 2 Job Manager.

## Speaking point 5: deterministic processing

> ROS callbacks only cache state or queue commands. The original business logic still runs from a deterministic 100 ms application cycle.

## Speaking point 6: validation

> An automated scenario proves pass creation, cycle close, minus-one, clear, store, stale-data handling, and recovery.

## Speaking point 7: honest boundary

> The current demonstration validates the ROS 2 architecture and the real Pass Tracker integration. The complete Job Manager task/load layer and original Weigh/calibration algorithms are the next application-assembly steps.

***

# 16. Current status to present

| Area                                 | Current status                                    |
| ------------------------------------ | ------------------------------------------------- |
| ROS 2 Job Manager shell              | Working                                           |
| ROS 2 Weigh App shell                | Working                                           |
| Native inter-app ROS communication   | Working                                           |
| Timing architecture                  | Working                                           |
| Original Pass Tracker                | Integrated and validated                          |
| Deterministic scenario               | Working                                           |
| Automated M2.1 validation            | Passing                                           |
| Existing Job Manager task/load logic | Located, not integrated                           |
| Existing Job Manager persistence     | Located, not integrated                           |
| Original weighing algorithms         | Source compilation investigation started          |
| Original calibration algorithms      | Source compilation investigation started          |
| AIS lifecycle replacement            | Partial at node-shell level                       |
| Complete SCS replacement             | Main inter-app path done; external routes pending |
| Full Job Manager port                | Not complete                                      |
| Full Weigh App port                  | Not complete                                      |
| Production readiness                 | Not claimed                                       |

***

# 17. Current Status

The current result is not merely a mock demonstration.

The meaningful achievements are:

1. The migration architecture is viable.
2. Original C business logic can be compiled by ROS 2 CMake.
3. Original C business logic can run inside a C++ ROS 2 node.
4. Job Manager and Weigh App can run as independent processes.
5. Direct inter-app communication can move to ROS 2.
6. Deterministic legacy update behavior can be maintained.
7. Command ordering can be preserved.
8. Stale data can be handled safely.
9. One-cycle legacy outputs can be preserved.
10. Automated regression validation is possible.

The demo should end with:

> We have completed the ROS 2 communication and execution foundation and validated the original Pass Tracker subsystem. The next phase is complete application-core assembly: existing Job Manager tasks, loads, configuration and persistence, followed by the original Weigh and calibration processing behind ROS 2 input adapters.
