EthernetPortStatistics = {
  "enabled" => true,
  "cycleRate_hz" => 4,

  # bdt_init
  "numRxCon" => 4,
  "rxBufSize" => 200,
  "numTxCon" => 4,
  "txBufSize" => 200,
  "numDataLinkCon" => 3,

  #bdt_action_init
  "maxSimultaneousClients" => 2,
}
