Parameters.update( {
  #Source of timesync
  "masterAddress" => IPAddressMap.fetch("gateway_ciscoRouter"), # Address for master time sync computer
} )
