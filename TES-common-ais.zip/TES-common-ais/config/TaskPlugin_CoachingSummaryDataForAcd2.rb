CoachingSummaryDataForAcd2 = {
  "enabled" => true,
}
