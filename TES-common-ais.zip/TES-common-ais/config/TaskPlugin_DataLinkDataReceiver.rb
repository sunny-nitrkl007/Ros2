DataLinkDataReceiver = {
  "enabled" => true,
  "skipParentDataLinkData" => false,      # Set to true to skip DataLinkData objects published by the parent
}
