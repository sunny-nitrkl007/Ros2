/******************************************************************************************************************
 Copyright 2014 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------------------------------------------
File name: csf_fit_config.c

Description:
******************************************************************************************************************/


#include <csf_fit_tune.h>
#include <csf_fit_alloc.h>

const uint_least8_t csf_fit_max_size = CSF_FIT_MAX_SIZE;

csf_fit_t csf_fit[CSF_FIT_MAX_SIZE];