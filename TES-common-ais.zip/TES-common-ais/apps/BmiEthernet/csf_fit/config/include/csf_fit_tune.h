/******************************************************************************************************************
 Copyright 2014 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------------------------------------------
File name: csf_fit_tune.h

Description:
******************************************************************************************************************/
#ifndef CSF_FIT_TUNE_H_
#define CSF_FIT_TUNE_H_

#ifdef __cplusplus
extern "C"
{
#endif


#define CSF_FIT_MAX_SIZE 20


#ifdef __cplusplus
}
#endif
#endif /* #ifndef CSF_FIT_TUNE_H_ */
