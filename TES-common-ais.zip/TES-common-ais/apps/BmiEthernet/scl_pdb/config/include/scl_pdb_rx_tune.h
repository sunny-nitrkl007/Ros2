/*******************************************************************************
Copyright 2014 Caterpillar Inc.  All rights reserved.                      
--------------------------------------------------------------------------------
Filename:  scl_pdb_rx_tune.h 

Description: 
The application will copy this file and adjust the PDB #defines to meet
their needs
*******************************************************************************/
#ifndef SCL_PDB_RX_TUNE_H_
#define SCL_PDB_RX_TUNE_H_

#ifdef __cplusplus
extern "C" {
#endif
 
#define SCL_PDB_NUM_RX_SPN               30

#define SCL_PDB_NUM_RX_PGN               20

#define  SCL_PDB_NUM_RX_CAT_EXT         10 

#ifdef __cplusplus
}
#endif


#endif /* SCL_PDB_RX_TUNE_H_ */
