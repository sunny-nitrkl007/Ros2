/*******************************************************************************
Copyright 2018 Caterpillar Inc.  All rights reserved.
--------------------------------------------------------------------------------
Filename:  csf_pgt_client_tune.h 

Description:
The application will copy this file and adjust the PGT #defines to meet
their needs
*******************************************************************************/
#ifndef CSF_PGT_CLIENT_TUNE_H_
#define CSF_PGT_CLIENT_TUNE_H_

#ifdef __cplusplus
extern "C" {
#endif

#define CSF_PGT_MAX_CLIENT_COUNT 10
#define CSF_PGT_CLIENT_MAX_SPL_COUNT 10
#define CSF_PGT_CLIENT_MAX_SESSION_COUNT 10
#define CSF_PGT_CLIENT_MAX_SERVER_COUNT 10
#define CSF_PGT_CLIENT_MAX_GRP_COUNT 20
#define CSF_PGT_CLIENT_MAX_PARAM_COUNT 70
#define CSF_PGT_CLIENT_MAX_GRP_UDP_RX_BYTES 100

#ifdef __cplusplus
}
#endif


#endif /* CSF_PGT_CLIENT_TUNE_H_ */
