#ifndef APP_BML_RECV_MAIN_H_
#define APP_BML_RECV_MAIN_H_

#ifdef __cplusplus
extern "C"
{
#endif

void app_recv_main_task(void);

#ifdef __cplusplus
}
#endif

#endif //APP_BML_RECV_MAIN_H_
