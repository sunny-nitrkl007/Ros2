#ifndef IOTHUBCOMMS_OUTBOUNDRETURNINTERFACEOUTPUTCHANNEL_H
#define IOTHUBCOMMS_OUTBOUNDRETURNINTERFACEOUTPUTCHANNEL_H

#include <cstddef> // NULL
#include <ais/interfaces/baseTypes/autogen_channel.h>

#include "OutboundReturnInterface.hpp"

// IoTHubCommsOutboundReturnInterfaceOutputChannel
DefineOutputChannel(_, IoTHubCommsOutboundReturnInterface)

#endif

