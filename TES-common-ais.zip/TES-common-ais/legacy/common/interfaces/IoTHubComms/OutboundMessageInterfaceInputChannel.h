#ifndef IOTHUBCOMMS_OUTBOUNDMESSAGEINTERFACEINPUTCHANNEL_H
#define IOTHUBCOMMS_OUTBOUNDMESSAGEINTERFACEINPUTCHANNEL_H

#include <ais/interfaces/baseTypes/autogen_channel.h>

#include "OutboundMessageInterface.hpp"

// IoTHubCommsOutboundMessageInterfaceInputChannel
DefineInputChannel(_, IoTHubCommsOutboundMessageInterface)

#endif

