#ifndef IOTHUBCOMMS_INBOUNDMESSAGEINTERFACEOUTPUTCHANNEL_H
#define IOTHUBCOMMS_INBOUNDMESSAGEINTERFACEOUTPUTCHANNEL_H

#include <cstddef> // NULL
#include <ais/interfaces/baseTypes/autogen_channel.h>

#include "InboundMessageInterface.hpp"

// IoTHubCommsInboundMessageInterfaceOutputChannel
DefineOutputChannel(_, IoTHubCommsInboundMessageInterface)

#endif

