#ifndef IOTHUBCOMMS_INBOUNDMESSAGEINTERFACEINPUTCHANNEL_H
#define IOTHUBCOMMS_INBOUNDMESSAGEINTERFACEINPUTCHANNEL_H

#include <ais/interfaces/baseTypes/autogen_channel.h>

#include "InboundMessageInterface.hpp"

// IoTHubCommsInboundMessageInterfaceInputChannel
DefineInputChannel(_, IoTHubCommsInboundMessageInterface)

#endif

