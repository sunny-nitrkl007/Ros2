#ifndef IOTHUBCOMMS_OUTBOUNDRETURNINTERFACEINPUTCHANNEL_H
#define IOTHUBCOMMS_OUTBOUNDRETURNINTERFACEINPUTCHANNEL_H

#include <ais/interfaces/baseTypes/autogen_channel.h>

#include "OutboundReturnInterface.hpp"

// IoTHubCommsOutboundReturnInterfaceInputChannel
DefineInputChannel(_, IoTHubCommsOutboundReturnInterface)

#endif

