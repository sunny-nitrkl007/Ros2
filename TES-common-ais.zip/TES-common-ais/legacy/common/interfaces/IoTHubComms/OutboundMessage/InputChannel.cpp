#include <ais/PluginProcessor/PluginDefine.h>

#include "../OutboundMessageInterfaceInputChannel.h"

RegisterPlugin(IoTHubCommsOutboundMessage.Channel.Input, interfaces::Interface, IoTHubCommsOutboundMessageInterfaceInputChannel)
