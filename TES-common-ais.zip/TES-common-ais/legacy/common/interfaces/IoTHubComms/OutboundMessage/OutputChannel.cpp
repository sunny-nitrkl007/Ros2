#include <ais/PluginProcessor/PluginDefine.h>

#include "../OutboundMessageInterfaceOutputChannel.h"

RegisterPlugin(IoTHubCommsOutboundMessage.Channel.Output, interfaces::Interface, IoTHubCommsOutboundMessageInterfaceOutputChannel)
