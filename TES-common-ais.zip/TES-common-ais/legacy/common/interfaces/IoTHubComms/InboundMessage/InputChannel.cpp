#include <ais/PluginProcessor/PluginDefine.h>

#include "../InboundMessageInterfaceInputChannel.h"

RegisterPlugin(IoTHubCommsInboundMessage.Channel.Input, interfaces::Interface, IoTHubCommsInboundMessageInterfaceInputChannel)
