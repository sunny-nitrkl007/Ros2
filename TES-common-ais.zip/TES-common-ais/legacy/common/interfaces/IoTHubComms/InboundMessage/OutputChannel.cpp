#include <ais/PluginProcessor/PluginDefine.h>

#include "../InboundMessageInterfaceOutputChannel.h"

RegisterPlugin(IoTHubCommsInboundMessage.Channel.Output, interfaces::Interface, IoTHubCommsInboundMessageInterfaceOutputChannel)
