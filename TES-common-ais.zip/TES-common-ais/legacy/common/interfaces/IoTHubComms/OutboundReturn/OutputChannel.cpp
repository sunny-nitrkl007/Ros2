#include <ais/PluginProcessor/PluginDefine.h>

#include "../OutboundReturnInterfaceOutputChannel.h"

RegisterPlugin(IoTHubCommsOutboundReturn.Channel.Output, interfaces::Interface, IoTHubCommsOutboundReturnInterfaceOutputChannel)
