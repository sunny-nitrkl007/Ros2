#include <ais/PluginProcessor/PluginDefine.h>

#include "../OutboundReturnInterfaceInputChannel.h"

RegisterPlugin(IoTHubCommsOutboundReturn.Channel.Input, interfaces::Interface, IoTHubCommsOutboundReturnInterfaceInputChannel)
