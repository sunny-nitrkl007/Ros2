#ifndef IOTHUBCOMMS_OUTBOUNDMESSAGEINTERFACEOUTPUTCHANNEL_H
#define IOTHUBCOMMS_OUTBOUNDMESSAGEINTERFACEOUTPUTCHANNEL_H

#include <cstddef> // NULL
#include <ais/interfaces/baseTypes/autogen_channel.h>

#include "OutboundMessageInterface.hpp"

// IoTHubCommsOutboundMessageInterfaceOutputChannel
DefineOutputChannel(_, IoTHubCommsOutboundMessageInterface)

#endif

