/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaJobMgrApp.cpp
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include "LpsSaJobMgrApp.h"
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
using namespace task;
/******************************************************************************
FUNCTION NAME:task::getTaskImplementation
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
AbstractTaskCore* task::getTaskImplementation(void)
{
    static LpsSaJobMgrApp thisTask("LpsSaJobMgrApp");
    return dynamic_cast<Task *>(&thisTask);
}
/******************************************************************************
FUNCTION NAME:LpsSaJobMgrApp::LpsSaJobMgrApp()
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
LpsSaJobMgrApp::LpsSaJobMgrApp( const std::string& taskName ):
    Task( taskName ),LpsSaJobMgrScsTxOut( NULL ),
	LpsSaJobMgrScsReqstIn( NULL ),LpsSaWeighScsCmdOut( NULL ),
	LpsSaWeighScsRespIn( NULL ),LpsSaWeighScsTxIn( NULL ),
	LpsSaSwitchInput(NULL), AisJhm2TxInputScs( NULL )
{
    memset(&LpsJobMgrJobTrackerInfoTbl,0,sizeof(LpsJobMgrJobTrackerInfoTbl));

	OelBootupFlag = FALSE;

	LpsJobMgrJobTrackerInfoTbl.OperationMode = LPS_SA_JOB_MGR_WEIGH_MODE;
	LpsJobMgrJobTrackerInfoTbl.DispBestBktWt.Stat = LPS_SA_BEST_BKT_WEIGHT_STAT_BAD;
    LpsJobMgrJobTrackerInfoTbl.StandbyState = LPS_SA_JOB_MGR_STANDBY_DEACTIVATED;
    LpsJobMgrJobTrackerInfoTbl.ManualTipOffState = LPS_SA_JOB_MGR_MAN_TIP_OFF_UNAVAILABLE; /* Hides manual tip off button on
                                                                                              display */
    LpsJobMgrJobTrackerInfoTbl.TipOffState = LPS_SA_JOB_MGR_TIP_OFF_UNAVAILABLE;/* By default the status is set to unavailable
     	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	   for display to show Zero button to operator */

	LpsSaJobMgrScsCmdStatFlg[LPS_SA_JOB_MGR_SCS_CMD_ZERO_INDX]=false;
	LpsSaJobMgrScsCmdStatFlg[LPS_SA_JOB_MGR_SCS_CMD_BEST_BKT_WT_REST_INDX]=false;
	LpsSaJobMgrScsCmdStatFlg[LPS_SA_JOB_MGR_SCS_CMD_CLEAR_REWEIGH_WARNING_INDX]=false;
}
/******************************************************************************
FUNCTION NAME:LpsSaJobMgrApp::~LpsSaJobMgrApp( )
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
LpsSaJobMgrApp::~LpsSaJobMgrApp( )
{

}
/******************************************************************************
FUNCTION NAME:LpsSaJobMgrApp::initialize
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:bool
*******************************************************************************/
bool LpsSaJobMgrApp::initialize( )
{
	getLogger().log_info( "JobManager::initialize" );

	/* Initializing default configuration parameters */
	LpsSaInitJobMgrTbl();

	/* Starting up OEL layer */
	commInitialize();

	/* Reading parameters from NVM */
	NvmInitialize();

	/* Reading NVM Job manager  Data */
	LpsSaJobMgrWmInput.tip_off_trigger = (unsigned_16)LpsSaJobMgrNvmMachSpecificCfg.TipOffTriggerType;
	LpsSaJobMgrWmInput.tip_off_trigger_request_status = TRUE;

	if(LpsSaJobMgrNvmLiveTimeTotal.LastKnownBestBktWtInTonnes > (float)0.0)
	{
		/* Enable clear button on UI */
		LpsJobMgrJobTrackerInfoTbl.ClearMinusOneEnableStat = LPS_SA_JOB_MGR_MINUS_ONE_BTN_ENABLED;
	}

	LOG_NOTICE( "\n LpsSaWeighInfoTbl.Indicator = %d\n",LpsJobMgrJobTrackerInfoTbl.Indicator );

   /* Initialsing SCS interface*/ 
    LpsSaJobMgrScsTxOut  = dynamic_cast<LpsSaJobMgrTxChannelOutput*>( InterfaceDb::fetch("LpsSaJobMgrTxChannelOutput") );
    LpsSaJobMgrScsReqstIn  = dynamic_cast<LpsSaJobMgrReqstChannelInput*>( InterfaceDb::fetch("LpsSaJobMgrReqstChannelInput") );
    LpsSaJobMgrScsDebugOut = dynamic_cast<LpsSaJobMgrDebugChannelOutput*>( InterfaceDb::fetch("LpsSaJobMgrDebugChannelOutput") );
    LpsSaWeighScsCmdOut  = dynamic_cast<LpsSaWeighReqstChannelOutput*>( InterfaceDb::fetch("LpsSaWeighReqstChannelOutput") );
    LpsSaWeighScsRespIn  = dynamic_cast<LpsSaWeighRespChannelInput*>( InterfaceDb::fetch("LpsSaWeighRespChannelInput") );
    LpsSaWeighScsTxIn  = dynamic_cast<LpsSaWeighTxChannelInput*>( InterfaceDb::fetch("LpsSaWeighTxChannelInput") );
	LpsSaSwitchInput = dynamic_cast<SwitchInputScsInput*>( InterfaceDb::fetch("SwitchInputScsInput") );
   LpsSaOutputChannelOut = dynamic_cast<OutputChannelOutput*>( InterfaceDb::fetch("OutputChannelOutput") );
	AisJhm2TxInputScs  = dynamic_cast<AisJhm2TxChannelInput*>( InterfaceDb::fetch("AisJhm2TxChannelInput") );
	ShmClockInputScs = dynamic_cast<ShmClockInput*>( InterfaceDb::fetch("ShmClockInput") );

	if ( !ShmClockInputScs )
	{
	    getLogger().log_error( "\n  ShmClockInputScs Interface  not configured." );
	}

	if ( !LpsSaJobMgrScsTxOut )
	{
		getLogger().log_error( "\n  LpsSaJobMgrScsTxOut Interface  not configured." );
	}
	
	if ( !LpsSaJobMgrScsDebugOut )
	{
		getLogger().log_error( "\n  LpsSaJobMgrScsDebugOut Interface  not configured." );
	}
	
	if ( !LpsSaJobMgrScsReqstIn )
	{
		getLogger().log_error( "t\n  LpsSaJobMgrScsReqstIn Interface  not configured." );
	}
	
	if ( !LpsSaWeighScsCmdOut )
	{
		getLogger().log_error( "\n LpsSaWeighScsCmdOut Interface  not configured." );
	}

	if ( !LpsSaWeighScsRespIn )
	{
		getLogger().log_error( "\n LpsSaWeighScsRespIn Interface  not configured." );
	}

	if ( !LpsSaWeighScsTxIn )
	{
		getLogger().log_error( "\n LpsSaWeighScsTxIn Interface  not configured." );
	}

   if ( !LpsSaSwitchInput )
   {
      getLogger().log_error( "\n LpsSaSwitchInput Interface  not configured." );
   }

   if ( !LpsSaOutputChannelOut )
   {
      getLogger().log_error( "\n LpsSaOutputChannelOut Interface  not configured." );
   }

	if ( !AisJhm2TxInputScs )
	{
		getLogger().log_error( "\n AisJhm2TxInputScs Interface  not configured." );
	}

	LpsSaJobMgrPtInit();

    return true;
}


/******************************************************************************
FUNCTION LpsSaJobMgrApp::executive( )
DESCRIPTION:It will send the parameter to UI App,and send the cmds to Weighing App
			and set the response UI App
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
bool LpsSaJobMgrApp::executive( )
{
	getLogger().log_debug( "Executing JobManager Task" );

	boolean ret;
	ret=LpsSaJobMgrScsRx();
	if(SUCCESS != ret)
	{
		getLogger().log_error("\n Line no = %d,'LpsSaJobMgrUpdate:LpsSaJobMgrScsRx' function return code = %d\n",__LINE__,ret );
	}

	ret = LpsSaJobMgrPtUpdate();

	if(SUCCESS != ret)
	{
		getLogger().log_error( "\n Line no = %d,'LpsSaJobMgrUpdate:LpsSaJobMgrPtUpdate' function return code = %d\n",__LINE__,ret );

		return FAIL;
	}

	/* send the UI Parameter to UI App*/
	ret =LpsSaJobMgrScsTx();
	if(SUCCESS != ret)
	{
		getLogger().log_error( "\n Line no = %d,'LpsSaJobMgrUpdate:LpsSaJobMgrScsTx' function return code = %d\n",__LINE__,ret );

		return FAIL;
	}

	if (LpsSaJobMgrScsDebugOut) 
	{
		LpsSaJobMgrDebugChannel txOut;
		txOut.CurrentState = LpsSaJobMgrWmOutput.pt_current_state;
		LpsSaJobMgrScsDebugOut->publish( txOut );
	}

	// Return true for the executive method to be periodically invoked
	return true;

}

/******************************************************************************
FUNCTION LpsSaJobMgrApp::cleanup( )
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaJobMgrApp::cleanup( )
{
    getLogger().log_info( "LpsSaJobMgrApp::cleanup" );
	LpsJobMgrSimpleCalDataQueue.clear();
	storePressCount = 0;
	
    if((LPS_SA_JOB_MGR_MAN_TIP_OFF_ACTIVE == LpsJobMgrJobTrackerInfoTbl.ManualTipOffState ) ||
    	(LpsSaJobMgrWmOutput.tip_off_trigger == TIP_OFF_TRIGGER_AUTO ))
    {
		LpsSaJobMgrNvmMachSpecificCfg.TipOffState = LpsJobMgrJobTrackerInfoTbl.TipOffState;
		LpsSaNvmJobMgrAppMachSpecificCfgWriteFlag = TRUE;
    }

    /* Writing Live values Data to NVM */
    LpsSaJobMgrNvmLiveTimeTotal.LastKnownBestBktWtInTonnes =  LpsSaJobMgrWmOutput.display_bucket_weight;
    LpsSaJobMgrNvmLiveTimeTotal.TotalTruckWt 			   =  LpsSaJobMgrWmOutput.lpsPtTruckTotals.truck_weight;
    LpsSaJobMgrNvmLiveTimeTotal.PassCount 				   =  (unsigned int)LpsSaJobMgrWmOutput.passcount;
	LpsSaJobMgrNvmLiveTimeTotal.LastDumpedWt 			   =  LpsSaJobMgrWmOutput.lpsPtStoredState.last_payld_rec.PayloadWt;
    /* Writing Pt current state to NVM */
    LpsSaJobMgrNvmLiveTimeTotal.PtPrevState 			   = (char)LpsSaJobMgrWmOutput.pt_current_state;

    LpsSaNvmJobMgrAppLiveValuesWriteFlag = TRUE;

    LOG_NOTICE("clean-up live values LastKnownBestBktWtInTonnes = %f \n", LpsSaJobMgrNvmLiveTimeTotal.LastKnownBestBktWtInTonnes);
    LOG_NOTICE("clean-up live values TotalTruckWt = %lf\n", LpsSaJobMgrNvmLiveTimeTotal.TotalTruckWt);
    LOG_NOTICE("clean-up live values PassCount = %d\n", LpsSaJobMgrNvmLiveTimeTotal.PassCount);
    LOG_NOTICE("clean-up live values TargetWeight = %f\n", LpsSaJobMgrNvmLiveTimeTotal.TargetWeight);

    /*Check the NVM write has happened before key off cycle*/
    while((LpsSaNvmJobMgrAppLiveValuesWriteFlag!=FALSE) || (LpsSaNvmJobMgrAppMachSpecificCfgWriteFlag != FALSE));

}
