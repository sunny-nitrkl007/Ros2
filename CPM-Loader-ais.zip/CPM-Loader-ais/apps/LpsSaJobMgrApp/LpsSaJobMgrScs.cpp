/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaJobMgrScs.cc
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include "LpsSaJobMgrApp.h"

#include <chrono>

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
#define STG4 3                //STG4 is index 3 in the array of STG_values.
#define HORN_PORT_NUMBER   OutputChannel::Port::OUTPUT_SINK_3    //OUTPUT_APP_PORT_SINK3_PIN29_GPIO88
/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/******************************************************************************
FUNCTION LpsSaJobMgrApp::LpsSaJobMgrScsChkForReqst
DESCRIPTION: It will check the request from UI through SCS channel by polling method
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaJobMgrApp::LpsSaJobMgrScsChkForReqst()
{

	 LpsSaJobMgrReqstChannel reqIn;
	 SwitchInputScs STG_Input;

	 /*The store button has higher priority compared to LPS Job Mgr request.*/
	 while(LpsSaSwitchInput->get( STG_Input ))
	 {
		 if(STG_Input.get_STG_value(STG4) == STG::CLOSED)
		 {
			 LpsSaJobMgrWmInput.store_request_status = TRUE;
			 return;
		 }
	 }
 
    /* Retreive SCS channel data */
    while(LpsSaJobMgrScsReqstIn->get( reqIn ))
    {
    	/* Check if Zero request received from UI App */
    	if(true == reqIn.ZeroReqst)
    	{
    		LOG_NOTICE( "\n Line no = %d, zero Received ZeroReqst \n",__LINE__);

			/* Request received for Weighing App,set the request flag */
			LpsSaJobMgrWmInput.zero_request_status = TRUE;
			return;
        }
		/* Check if minus one request received from UI App */
    	else if(true == reqIn.MinusOneReqst)
		{
    		 LOG_NOTICE( "\n Line no = %d, minus one Received MinusOneReqst \n",__LINE__);

			/* Request received for Weighing App,set the request flag */
			LpsSaJobMgrWmInput.minus_one_request_status = TRUE;
			return;
		}
		/* Check if Clear request received from UI App */
		else if(true == reqIn.ClearReqst)
		{
			 LOG_NOTICE( "\n Line no = %d,Received ClearReqst\n",__LINE__);

			/*set the request flag */
			LpsSaJobMgrWmInput.clear_request_status = TRUE;
			return;
		}
		/* Check if Store request received from UI App */
		else if(true == reqIn.StoreReqst)
		{
			 LOG_NOTICE( "\n Line no = %d,Received StoreReqst\n",__LINE__ );

			/* set the request flag */
			LpsSaJobMgrWmInput.store_request_status = TRUE;
			return;
		}
		/* Check ifStandBy Activate request received from UI App */
		else if(true == reqIn.StandByActReqst)
		{
			 LOG_NOTICE( "\n Line no = %d,Received StandByActReqst %d\n",__LINE__);

			 /* set the request flag */
			LpsSaJobMgrWmInput.standby_request_status = TRUE;
			/*set standby state */
			LpsJobMgrJobTrackerInfoTbl.StandbyState = LPS_SA_JOB_MGR_STANDBY_ACTIVATED;
			return;
		}
		/* Check if StandBy Deactivate request received from UI App */
		else if(true == reqIn.StandByDeactReqst)
		{
			LOG_NOTICE( "\n Line no = %d,Received StandByDeactReqst\n",__LINE__);

			 /* set the request flag */
			LpsSaJobMgrWmInput.change_mode_weigh = TRUE;
			/*set standby Deactive state */
		  	LpsJobMgrJobTrackerInfoTbl.StandbyState = LPS_SA_JOB_MGR_STANDBY_DEACTIVATED;
			return;
		}

		/* Check if TRUCK_TIP_OFF Toggle request received from UI App */
    	else if(true == reqIn.TruckPileTipOffToggleReqst)
    	{
    		LOG_NOTICE( "\n Line no = %d,Received TruckTipOffReqst\n",__LINE__);
		    /* set the request flag */	
			LpsSaJobMgrWmInput.tipoff_toggle_request_status = TRUE;
			return;
		}

		/* Check if ManualTipOffActReqst request received from UI App */
        else if(true == reqIn.ManualTipOffActReqst)
        {
        	LOG_NOTICE("\n Line no = %d,Received ManualTipOffActReqst\n",__LINE__);
        	 /* set the request flag */
			LpsJobMgrJobTrackerInfoTbl.ManualTipOffState = LPS_SA_JOB_MGR_MAN_TIP_OFF_ACTIVE;
			LpsSaJobMgrWmInput.change_mode_excess = TRUE;
			return;
        }

		/* Check if ManualTipOffDeactReqst request received from UI App */
		else if(true == reqIn.ManualTipOffDeactReqst)
		{
			LOG_NOTICE("\n Line no = %d,Received ManualTipOffDeactReqst \n",__LINE__);

			/* set the request flag */
			LpsJobMgrJobTrackerInfoTbl.ManualTipOffState = LPS_SA_JOB_MGR_MAN_TIP_OFF_AVAILABLE;
			LpsSaJobMgrWmInput.change_mode_weigh = TRUE;
			return;
		}
    	/* Check if TargetWeightReqst request received from UI App */
		else if(true == reqIn.TargetWeightReqst.ReqstFlag)
		{
			 LOG_NOTICE( "\n Line no = %d,Received TargetWeightReqst\n",__LINE__);

			LpsSaJobMgrWmInput.target_weight_request_status = reqIn.TargetWeightReqst.ReqstFlag;
			LpsSaJobMgrWmInput.target_weight = reqIn.TargetWeightReqst.TargetWeightVal;

			/* Writing Target Weight Data to NVM */
			LpsSaJobMgrNvmLiveTimeTotal.TargetWeight = LpsSaJobMgrWmInput.target_weight;
			LpsSaNvmJobMgrAppLiveValuesWriteFlag = TRUE;
			return;
		}

    	/* Check if Tip-off Trigger (Disabled, Manual, Auto) request received from UI App */
		else if(true == reqIn.TipOffTrigger.ReqstFlag)
		{
			LOG_NOTICE("\n Line no = %d,Received TipOffTrigger\n",__LINE__);

			LpsSaJobMgrWmInput.tip_off_trigger = (unsigned_16)reqIn.TipOffTrigger.Type;
			LpsSaJobMgrWmInput.tip_off_trigger_request_status = TRUE;

			LOG_NOTICE("TIP OFF TRIGGER TYPE = %d \n", reqIn.TipOffTrigger.Type);

			/* Writing  Tip-off Trigger Data to NVM */
			LpsSaJobMgrNvmMachSpecificCfg.TipOffTriggerType = (char)reqIn.TipOffTrigger.Type;
			LpsSaNvmJobMgrAppMachSpecificCfgWriteFlag = TRUE;
			return;
		}
    	    	/* Check if Tip-off Mode  (Truck, Pile) request received from UI App */
		else if(true == reqIn.TipOffState.ReqstFlag)
		{
			LOG_NOTICE("\n Line no = %d,Received Tip-off Mode\n",__LINE__);

			/* set the request flag */
			LpsSaJobMgrWmInput.tip_off_mode = reqIn.TipOffState.State;
			LpsSaJobMgrWmInput.tip_off_mode_request_status = TRUE;

			LOG_NOTICE("TIP OFF STATE = %d \n", reqIn.TipOffState.State);

			/* Writing Tipoff State to NVM */
			LpsSaJobMgrNvmMachSpecificCfg.TipOffState = (char)reqIn.TipOffState.State;
			LpsSaNvmJobMgrAppMachSpecificCfgWriteFlag = TRUE;
			return;
		}
		/* Check if Reweigh request received from UI App */
	    else if(true == reqIn.ReWeighReqst)
		{
			 LOG_NOTICE( "\n Line no = %d,Received Reweigh\n",__LINE__);

			/* set the request flag */
			LpsSaJobMgrWmInput.reweigh_request_status = TRUE;
			return;
		}
	    else if(true == reqIn.LifetimeTruckLoadCount.ReqstFlag)
		{
	    	 LpsSaJobMgrNvmLiveTimeTotal.LifetimeTruckLoadCount = reqIn.LifetimeTruckLoadCount.Data;
	    	 LOG_NOTICE( "\n reqIn.LifetimeTruckLoadCount.Data = %d\n",reqIn.LifetimeTruckLoadCount.Data);
	    	 LpsSaNvmJobMgrAppLiveValuesWriteFlag = TRUE;
			 return;
		}

	    else if(true == reqIn.LifetimePayloadPassCount.ReqstFlag)
		{
	    	 LpsSaJobMgrNvmLiveTimeTotal.LifetimePayloadPassCount = reqIn.LifetimePayloadPassCount.Data;
			 LOG_NOTICE( "\n reqIn.LifetimePayloadPassCount.Data = %d\n",reqIn.LifetimePayloadPassCount.Data);
			 LpsSaNvmJobMgrAppLiveValuesWriteFlag = TRUE;
			 return;
		}

	    else if(true == reqIn.LifetimeTotalPayload.ReqstFlag)
		{
	    	 LpsSaJobMgrNvmLiveTimeTotal.LifetimeTotalPayload = reqIn.LifetimeTotalPayload.Data;
	    	 LOG_NOTICE( "\n reqIn.LifetimeTotalPayload.Data = %d\n",reqIn.LifetimeTotalPayload.Data);
	    	 LOG_NOTICE("\nLpsSaWeighNvmMachSpecificCfg.CalWt = %f\n",LpsSaJobMgrNvmLiveTimeTotal.LifetimeTotalPayload);
	    	 LpsSaNvmJobMgrAppLiveValuesWriteFlag = TRUE;
			 return;
		}
	    else if(true == reqIn.HornStoreStateReqst.ReqstFlag)
	    {
	       HornStoreEnableFlag = reqIn.HornStoreStateReqst.Enable;
          LOG_NOTICE( "\n reqIn.HornStoreStateReqst.Enable = %d\n",reqIn.HornStoreStateReqst.Enable);
          //Save to NVM
          LpsSaJobMgrWriteHornStateToNvm();
          return;
	    }
    }

}


/******************************************************************************
FUNCTION NAME: AisJhmDataServerTxRead
DESCRIPTION:            
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
void LpsSaJobMgrApp::AisJhmDataServerTxRead( )
{
	AisJhm2TxChannel AisJhm2TxIn;
    while ( AisJhm2TxInputScs->get( AisJhm2TxIn ) )
    {
		int simpleCalDataSize = LpsJobMgrSimpleCalDataQueue.size();
		if( (simpleCalDataSize > 0) && (AisJhm2TxIn.simplecal_data.newDataFlag == true))
		{
			for(int i = 0; i < simpleCalDataSize; i++ )
			{
				if(LpsJobMgrSimpleCalDataQueue[i].timeStamp.compare(AisJhm2TxIn.simplecal_data.timeStamp) == 0)
				{
					LpsJobMgrSimpleCalDataQueue.erase(LpsJobMgrSimpleCalDataQueue.begin()+i);
					break;
				}
			}
		}
    }
}

/******************************************************************************
FUNCTION NAME: AisJhmDataServerTxRead
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaJobMgrApp::LpsSaJobMgrScsSHMRead( )
{
    ShmClock ShmClockInput;
    if( ShmClockInputScs )
    {
        while(ShmClockInputScs->get(ShmClockInput))
        {
            std::chrono::minutes tzone_offset(ShmClockInput.getTzoneCommStruct().tzone_bias);
            std::chrono::minutes dst_offset(ShmClockInput.getTzoneCommStruct().dst_info.dst_bias);
            LpsSaJobMgrMinsTZoneOffset = tzone_offset;
            LpsSaJobMgrMinsDSTOffset = dst_offset;
        }
    }
}

/******************************************************************************
FUNCTION LpsSaJobMgrApp::LpsSaWeighScsTxParamRead( )
DESCRIPTION:It will get invoked once JobManager receives the parameters from weighing App
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaJobMgrApp::LpsSaWeighScsTxParamRead( )
{
	LpsSaWeighTxChannel rxParam;
	if ( LpsSaWeighScsTxIn)
	{
		while(LpsSaWeighScsTxIn->get( rxParam ))
		{
			LpsJobMgrJobTrackerInfoTbl.DigStat 					= rxParam.DigStat;
			LpsJobMgrJobTrackerInfoTbl.CalStat 					= rxParam.CalStat;
			LpsJobMgrJobTrackerInfoTbl.DumpStat 				= rxParam.DumpStat;
			LpsSaJobMgrWmInput.current_weight 					= rxParam.BestBktWtInTonnes;
			LpsJobMgrJobTrackerInfoTbl.ZeroNotifyStat 			= rxParam.ZeroNotifyStat;
			LpsSaJobMgrWmInput.calc_method 						= (unsigned int)rxParam.PayloadCalcMeth;
			LpsSaJobMgrWmInput.current_bucket_weight_latched 	= rxParam.bktWtLatchedFlag;
			LpsSaJobMgrWmInput.payload_latch_conditions_ok 		= rxParam.latchConditionsMet;
			LpsJobMgrJobTrackerInfoTbl.Indicator 				= rxParam.Indicator;
			simpleCalAdjustmentFactor 							= rxParam.SimpleCalAdjustment;
			LpsSaJobMgrWmInput.weight_available					= rxParam.PayloadAvailable;
		}

		 LOG_NOTICE("\n Line no = %d,'LpsSaWeighScsTxParamRead:'\n",__LINE__);
	}

}
 
/******************************************************************************
FUNCTION NAME:LpsSaJobMgrApp::LpsSaJobMgrScsRx()
DESCRIPTION:It will read the Tx parameters from weighing app through SCS channel
PARAMETER DESCRIPTION:
RETURN VALUE:boolean
*******************************************************************************/
boolean LpsSaJobMgrApp::LpsSaJobMgrScsRx()
{
    /*Read the SHM object from ACD */
    LpsSaJobMgrScsSHMRead();

    /*Read the requests from Weighing App*/
	LpsSaWeighScsTxParamRead();

	/*Read the requests from UI*/
	LpsSaJobMgrScsChkForReqst();
	
	/*Read the Simple cal data from data server. */
	AisJhmDataServerTxRead();

	LOG_NOTICE( "\n Line no = %d,'LpsSaJobMgrScsRx' function return code = %d\n",__LINE__ );

	return SUCCESS;
}

/******************************************************************************
FUNCTION NAME:LpsSaJobMgrApp::LpsSaJobMgrHornOnStoreAction()
DESCRIPTION:It will blow horn when Action Flag is ture;
PARAMETER DESCRIPTION:
RETURN VALUE:boolean
*******************************************************************************/
bool LpsSaJobMgrApp::LpsSaJobMgrHornOnStoreAction()
{
   OutputChannel outputChannel;
   OutputChannel::OutputCmd command;
   command.OutputPort = HORN_PORT_NUMBER;
   command.InitialState = OutputChannel::State::PORT_ON;
   command.StateChangeDuration = OutputChannel::ChangeDuration::NO_FLASH;
   command.TotalDuration = 2;
   command.FinalState = OutputChannel::State::PORT_OFF;
   outputChannel.AddOutputAppCmd(command);

   return LpsSaOutputChannelOut->publish( outputChannel );
}

/******************************************************************************
FUNCTION NAME:LpsSaJobMgrApp::LpsSaJobMgrScsTx()
DESCRIPTION:It will write the tx parameter to UI App
PARAMETER DESCRIPTION:
RETURN VALUE:boolean
*******************************************************************************/
boolean LpsSaJobMgrApp::LpsSaJobMgrScsTx()
{
	bool scsCmdRet=false;
	LpsSaJobMgrTxChannel txOut;
	/* frame SCS channel data to UI*/
	if ( LpsSaJobMgrScsTxOut )
	{
		/************************************************************/
		/* Filling out dummy data for PPG Testing for some Tx Parameters */

		txOut.MaterialID = 5;
		txOut.MaterialName = "Uranium";

		txOut.OperationMode = LpsJobMgrJobTrackerInfoTbl.OperationMode;

		/************************************************************/
		txOut.ManualTipOffState       = LpsJobMgrJobTrackerInfoTbl.ManualTipOffState;
		txOut.TipOffState             = LpsJobMgrJobTrackerInfoTbl.TipOffState;
		txOut.PassCount               = (unsigned int)LpsSaJobMgrWmOutput.passcount;
		txOut.TruckWeight             = LpsJobMgrJobTrackerInfoTbl.DispTruckWt;
		txOut.StandbyState            = LpsJobMgrJobTrackerInfoTbl.StandbyState;
		txOut.ClearMinusOneEnableStat = LpsJobMgrJobTrackerInfoTbl.ClearMinusOneEnableStat;
		txOut.DispBestBktWt			  = LpsJobMgrJobTrackerInfoTbl.DispBestBktWt;
		txOut.TipOffTriggerType		  = LpsJobMgrJobTrackerInfoTbl.TipOffTriggerType;
		txOut.TipOffStateCfg 		  = (LpsSaJobMgrTipOffState_t) LpsSaJobMgrNvmMachSpecificCfg.TipOffState;

		txOut.LifetimeCycleCount	  = LpsSaJobMgrWmOutput.lpsPtLifetimeTotals.pass_count;
		txOut.LifetimeTotalPayload    = LpsSaJobMgrWmOutput.lpsPtLifetimeTotals.cummulative_weight;
		txOut.LifetimeTruckLoadCount  = LpsSaJobMgrWmOutput.lpsPtLifetimeTotals.load_count;
		txOut.LifetimePayloadPassCount	= LpsSaJobMgrWmOutput.lpsPtLifetimeTotals.pass_count;
		txOut.LpsSaJobMgrAutoManualTipOffDumpState=LpsJobMgrJobTrackerInfoTbl.LpsSaJobMgrAutoManualTipOffDumpState;


		if(0.00 != LpsSaJobMgrNvmLiveTimeTotal.TargetWeight)
		{
			txOut.TargetWeight = LpsSaJobMgrNvmLiveTimeTotal.TargetWeight - (float)LpsJobMgrJobTrackerInfoTbl.DispTruckWt;
		}
		else
		{
			txOut.TargetWeight = 0.00;
		}
		txOut.ReqPloadCtrlSysStat = LpsJobMgrJobTrackerInfoTbl.ReqPloadCtrlSysStat;
		
		txOut.simpleCalData.assign(LpsJobMgrSimpleCalDataQueue.begin(),LpsJobMgrSimpleCalDataQueue.end());
		LOG_NOTICE( "###### size of simplecal data %u",txOut.simpleCalData.size() );
		txOut.storeCount 	= storePressCount;
		txOut.HornStoreState = HornStoreEnableFlag ? SOUND_HORN : NOT_SOUND_HORN;

		scsCmdRet=LpsSaJobMgrScsTxOut->publish( txOut );
	}

	if(!scsCmdRet)
	{
		LOG_ERROR( "\n Line no = %d,'LpsSaJobMgrScsTx' function return code = %d\n",__LINE__,scsCmdRet);

		return FAIL;
    }

    return SUCCESS;
}

/******************************************************************************
FUNCTION LpsSaJobMgrApp::LpsSaJobMgrScsSendCmd
DESCRIPTION: It will send the cmd to weighing App through SCS channel by polling method
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
void LpsSaJobMgrApp::LpsSaJobMgrScsSendCmd(LpsSaJobMgrScsCmdStatIndex_t cmdIndx)
{
    bool scsCmdRet;
    LpsSaWeighReqstChannel cmdOut;

    if(cmdIndx >= LPS_SA_JOB_MGR_SCS_CMD_NO_OF_PARAM_INDX)
    {
        /* This check is done to prevent array out of bound access */
        return ;
    }
    /*Set Default values*/
    cmdOut.ZeroReqst=false;
    cmdOut.BestBktRstReqst=false;
    cmdOut.CaptCylExtRef =false;
    cmdOut.ClearReweighWarnReqst =false;

	switch(cmdIndx)
	{
		case LPS_SA_JOB_MGR_SCS_CMD_ZERO_INDX:
				cmdOut.ZeroReqst=true;
				break;
		case LPS_SA_JOB_MGR_SCS_CMD_BEST_BKT_WT_REST_INDX:
				cmdOut.BestBktRstReqst=true;
				break;
		case LPS_SA_JOB_MGR_SCS_CMD_CAPT_CYL_EXTN_REF_INDX:
				cmdOut.CaptCylExtRef=true;
				break;
    	case LPS_SA_JOB_MGR_SCS_CMD_CLEAR_REWEIGH_WARNING_INDX:
				cmdOut.ClearReweighWarnReqst=true;
				break;
		default:
				break;
	}
	
	scsCmdRet=LpsSaWeighScsCmdOut->publish( cmdOut );

	LOG_NOTICE( "\n Line no = %d,'LpsSaJobMgrScsSendCmd' function return code = %d\n",__LINE__,scsCmdRet );

	if(true == scsCmdRet)
	{
		/* Set status flag for the command to keep record of issued commands */
		LpsSaJobMgrScsCmdStatFlg[cmdIndx] = FALSE;
	}

   return;  
}

/******************************************************************************
FUNCTION NAME: CheckActiveButton
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
ReqPloadCtrlSysStat_t LpsSaJobMgrApp::GetActiveButtonStatus (void)
{
	if(TRUE == LpsSaJobMgrWmInput.clear_request_status)
	{
		return CLEAR;
	}
	else if(TRUE == LpsSaJobMgrWmInput.reweigh_request_status)
	{
		return REWEIGH;
	}
	else if(TRUE == LpsSaJobMgrWmInput.zero_request_status)
	{
		return ZERO;
	}
	else if(TRUE == LpsSaJobMgrWmInput.store_request_status)
	{
		return STORE;
	}
	else if(TRUE == LpsSaJobMgrWmInput.tipoff_toggle_request_status)
	{
		return TIPOFFTOGGLE;
	}
	else if(TRUE == LpsSaJobMgrWmInput.minus_one_request_status)
	{
		return MINUS_ONE;
	}
	else
	{
		return NONE;
	}
}
