/*******************************************************************************
 Copyright 2017 Caterpillar Inc. All rights reserved.
--------------------------------------------------------------------------------
File name: app_nvm_file_access.h

Description:This file contains test code to test the nvm_file feature 
*******************************************************************************/
#ifndef STD_TYPES_H_
#include <std_types.h>
#endif


extern volatile boolean OelBootupFlag;

extern volatile boolean  LpsSaNvmJobMgrAppMachSpecificCfgWriteFlag;
extern volatile boolean  LpsSaNvmJobMgrAppMachSpecificCfgReadFlag;


typedef struct
{
	char      TipOffTriggerType;
	char      TipOffState;
	unsigned char InfoUnitStat;
	unsigned short int ServModEnCode;
	unsigned char DispLangStat;
}LpsSaJobMgrNvmMachSpecificCfg_t;


/* Holds default values for NVM for machine specific configuration */
extern volatile	LpsSaJobMgrNvmMachSpecificCfg_t LpsSaJobMgrNvmDefMachSpecificCfg;

/* Holds actual values stored in NVM for machine specific configuration */
extern volatile	LpsSaJobMgrNvmMachSpecificCfg_t LpsSaJobMgrNvmMachSpecificCfg;

extern volatile boolean LpsSaNvmJobMgrAppLiveValuesReadFlag;
extern volatile boolean LpsSaNvmJobMgrAppLiveValuesWriteFlag;

typedef struct  __attribute__((__packed__))
{
	short int PassCount;
	float     TargetWeight;
	double    TotalTruckWt;
	float	  LastDumpedWt; 
	float     LastKnownBestBktWtInTonnes;
	int       LifetimeTruckLoadCount;
	int       LifetimeCycleCount;
	int       LifetimePayloadPassCount;
	double    LifetimeTotalPayload;
	char      PtPrevState;

}LpsSaJobMgrNvmLiveValues_t;

extern	LpsSaJobMgrNvmLiveValues_t LpsSaJobMgrNvmLiveTimeTotal;
extern  LpsSaJobMgrNvmLiveValues_t LpsSaJobMgrNvmDefLiveTimeTotal;

extern void app_nvm_file_read(void);
extern void app_nvm_file_write(void);
void app_nvm_live_values_file_write(void);
