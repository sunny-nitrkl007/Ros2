/*******************************************************************************
 Copyright 2016 Caterpillar Inc. All rights reserved.
--------------------------------------------------------------------------------
File name: app_nvm_file_access.c

Description:This file contains test code to test the nvm_file feature 
 *******************************************************************************/
#include "app_nvm_globals.h"
#include "app_nvm_file_access.h"
#include <stdio.h>


/*******************************************************************************
Function name: app_nvm_file_write

Description:  
test the nvm_file. 

Parameter Description: 

Return Description:     
    None
 *******************************************************************************/
void app_nvm_file_write(void)
{

	         if(NVM_SUCCESS == nvm_block_write(
	         LpsSaJobMgrNvmMachSpecificCfgNvmBlkHndl,
	         sizeof(LpsSaJobMgrNvmMachSpecificCfg),
	          0,
	         (unsigned_8 *)&LpsSaJobMgrNvmMachSpecificCfg,
	          NVM_CURRENT_TASK_PRIORITY))


	        {
	            printf("\n  JobMgr Data NVM write Success\n");
	        }


}

/*******************************************************************************
Function name: app_nvm_live_values_file_write

Description:
test the nvm_file.

Parameter Description:

Return Description:
    None
 *******************************************************************************/
void app_nvm_live_values_file_write(void)
{

    if(NVM_SUCCESS == nvm_block_write(
    		LiveTimeTotalBlkHndl,
    		sizeof(LpsSaJobMgrNvmLiveValues_t),
            0,
            (unsigned_8 *)&LpsSaJobMgrNvmLiveTimeTotal,
            NVM_CURRENT_TASK_PRIORITY))
    {
        printf("\napp_nvm_live_values_file_write Success\n");
    }
}
/*******************************************************************************
Function name: app_nvm_file_read

Description:
test the nvm_file.

Parameter Description:

Return Description:
    None
 *******************************************************************************/
void app_nvm_file_read(void)
{

}
