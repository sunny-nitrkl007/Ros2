/*******************************************************************************
 Copyright 2017 Caterpillar Inc. All rights reserved.
--------------------------------------------------------------------------------
File name: app_nvm_file_cfg.h

Description:This file contains the nvm_file configuration details
*******************************************************************************/
#include <nvm.h>
#include <nvm_data_id_defs.h>
#include "app_flags.h"
