/******************************************************************************************************************
 Copyright 2017 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------------------------------------------
File name: app_nvm_file_init.c

Description:This file contains startup and initialization code for nvm_file
******************************************************************************************************************/

#include "app_nvm_file_init.h"
#include "app_nvm_file_cfg.h"
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/types.h>
#include "app_nvm_file_access.h"

static void app_nvm_jobmgr_machine_spec_config_file_init();
static void app_nvm_save_live_values_init();

/*Flag will be set when NVM file is not exist and the flag will be reset
*when the file was created or if the file already exist */

boolean LpsSaJobMgrNvmMachSpecificCfgFileCreateFlag=FALSE;
boolean LpsSaJobMgrNvmLiveValuesFileCreateFlag=FALSE;

NVM_block_handle_t LpsSaJobMgrNvmMachSpecificCfgNvmBlkHndl;

/* Holds default values for NVM for machine specific configuration */
volatile LpsSaJobMgrNvmMachSpecificCfg_t LpsSaJobMgrNvmMachSpecificCfg;

/* Holds actual values stored in NVM for machine specific configuration */
volatile LpsSaJobMgrNvmMachSpecificCfg_t LpsSaJobMgrNvmDefMachSpecificCfg;

NVM_block_handle_t LiveTimeTotalBlkHndl;
LpsSaJobMgrNvmLiveValues_t LpsSaJobMgrNvmLiveTimeTotal;
LpsSaJobMgrNvmLiveValues_t LpsSaJobMgrNvmDefLiveTimeTotal=  {0,0.0,0.0,0.0,0,0,0,0.0,0};

struct stat nvm ={0};
/******************************************************************************************************************
Function name: app_nvm_file_init

Description:  
Initialize the nvm_file.

Parameter Description: 
    
Return Description:     
    None
*****************************************************************************************************************/
void app_nvm_file_init(void)
{
    int sys_ret,indx;
    char command[200];
    char id_char[100];
    unsigned int ret;
    struct stat nvmfile ={0};

    LpsSaNvmJobMgrAppMachSpecificCfgWriteFlag = FALSE;
    LpsSaNvmJobMgrAppMachSpecificCfgReadFlag = FALSE;

    LpsSaNvmJobMgrAppLiveValuesReadFlag=FALSE;
    LpsSaNvmJobMgrAppLiveValuesWriteFlag=FALSE;


    strcpy(NvmFilepath, getenv("HOME"));
    strcat(NvmFilepath, "/appdata/CPM/LpsSaJobMgrApp/nvm");

    strcpy(id_char,"/NvmJobMgrAppMachSpecificCfg.txt");

    strcpy(NvmFileName, NvmFilepath);

    strcat(NvmFileName, id_char);

    strcpy(command, "mkdir --mode=755 -p ");

    strcat(command, NvmFilepath);


    /* Create location for NVM log, if it doesn't already exist.*/

    if(stat(NvmFilepath, &nvm) == -1)
    {
        sys_ret = system(command);
        (void) sys_ret;
    }


    strcpy(id_char,"/NvmLiveValues.txt");
    strcpy(NvmLiveValuesFileName, NvmFilepath);
    strcat(NvmLiveValuesFileName, id_char);

          /*Below file exist check can be removed after CSNS library issues got resolved*/
              /*Check NvmFileName file doesn't already exist.*/
              if(stat(NvmFileName, &nvmfile) == -1)
              {
              	printf("nvm jobmgr data default is not exist \n");
              	/*Flag will be set when NvmWeighAppCalibPress file is not exist*/
              	LpsSaJobMgrNvmMachSpecificCfgFileCreateFlag = TRUE;
              }
              /*Check live values file doesn't already exist.*/
              if(stat(NvmLiveValuesFileName, &nvmfile) == -1)
              {
              	printf("nvm live values is not exist \n");
              	/*Flag will be set when NvmLiveValues file is not exist*/
              	LpsSaJobMgrNvmLiveValuesFileCreateFlag = TRUE;
              }

              printf("block size %d\n", BlockSize);

    if(NVM_SUCCESS == nvm_file_init(BlockSize))
    {
    	for(indx = 0; indx < BlockSize; indx++)
        {
    		ret = nvm_file_block_cfg(&app_nvm_file_cfg[indx]);

        	if(NVM_SUCCESS == ret)
            {

          		printf("nvm_file_block_cfg SUCCESS \n");
					switch(indx)
					{
						case 0:app_nvm_jobmgr_machine_spec_config_file_init();
						   break;
						case 1:app_nvm_save_live_values_init();
						   break;
						default:/*Reset the after the folder was created*/
							break;
					}
			}
            else
            {
                printf("nvm_file_block_cfg  %d failed\n", indx);
            }
        }
    }
    else
    {
        printf("nvm_file_init failed\n");
    }

    return;
}

static void app_nvm_jobmgr_machine_spec_config_file_init()
{
	printf("app_nvm_jobmgr_data_default_file_init\n");
			unsigned int ret;

				ret = nvm_block_init(
						NVM_BLOCK_CACHED,
						(unsigned_8 *)&LpsSaJobMgrNvmMachSpecificCfg,
						JOB_MGR_MACH_SPEC_CFG_NVID,
						NVM_CURRENT_TASK_PRIORITY,
						&LpsSaJobMgrNvmMachSpecificCfgNvmBlkHndl);

	                if(NVM_SUCCESS == ret)
	                {

	        			/*Below condition can be removed after CSNS library issues got resolved*/
	        			if(LpsSaJobMgrNvmMachSpecificCfgFileCreateFlag ==TRUE)
	        			{
	        				/*When the Nvm file is created for first time set the default value*/
	        				printf("Jobmgr Default data file created");

	        				/* Assigning default values to machine specific config
	        			                	                	 * due to NVM CRC error */
	        			    LpsSaJobMgrNvmMachSpecificCfg = LpsSaJobMgrNvmDefMachSpecificCfg;
	        				app_nvm_file_write();
	        			}
	        			LpsSaJobMgrNvmMachSpecificCfgFileCreateFlag = FALSE;
	        			printf("app_nvm_jobmgr_data_default_file_init success\n");

	                }
	                else
	                {
	                	/* Assigning default values to machine specific config
	                                	                	 * due to NVM CRC error */
	                    LpsSaJobMgrNvmMachSpecificCfg = LpsSaJobMgrNvmDefMachSpecificCfg;
						printf("app_nvm_jobmgr_data_default_file_init failed");
						app_nvm_file_write();
					}

	            	printf("TipOffState = %d  TipOffTriggerType = %d \n ",
						LpsSaJobMgrNvmMachSpecificCfg.TipOffState,
						LpsSaJobMgrNvmMachSpecificCfg.TipOffTriggerType);

	            	LpsSaNvmJobMgrAppMachSpecificCfgReadFlag = TRUE;


}
static void app_nvm_save_live_values_init()
{

	printf("app_nvm_save_live_values_init\n");
			unsigned int ret;

				ret = nvm_block_init(
						NVM_BLOCK_CACHED,
						(unsigned_8 *)&LpsSaJobMgrNvmLiveTimeTotal,
						JOB_MGR_NVM_LIVE_VAL_NVID,
						NVM_CURRENT_TASK_PRIORITY,
						&LiveTimeTotalBlkHndl);

	                if(NVM_SUCCESS == ret)
	                {
	        			/*Below condition can be removed after CSNS library issues got resolved*/
	        			if(LpsSaJobMgrNvmLiveValuesFileCreateFlag ==TRUE)
	        			{
	        				/*When the Nvm file is created for first time set the default value*/
	        				printf("live values file created");

	        				LpsSaJobMgrNvmLiveTimeTotal = LpsSaJobMgrNvmDefLiveTimeTotal;
	        				app_nvm_live_values_file_write();
	        			}
	        			LpsSaJobMgrNvmLiveValuesFileCreateFlag = FALSE;
	        			printf("app_nvm_save_live_values_init success\n");

	                }
	                else
	                {
	                	LpsSaJobMgrNvmLiveTimeTotal = LpsSaJobMgrNvmDefLiveTimeTotal;
						printf("app_nvm_save_live_values_init failed");
						app_nvm_live_values_file_write();
					}
	            	printf("live values default   PassCount = %d TargetWeight= %f  NvmTotalTruckWt = %lf LastKnownBestBktWtInTonnes = %f\n ",
	            			LpsSaJobMgrNvmLiveTimeTotal.PassCount,
	            			LpsSaJobMgrNvmLiveTimeTotal.TargetWeight,
	            			LpsSaJobMgrNvmLiveTimeTotal.TotalTruckWt,
	            			LpsSaJobMgrNvmLiveTimeTotal.LastKnownBestBktWtInTonnes);

	            	printf("pass tracker state = %d \n",LpsSaJobMgrNvmLiveTimeTotal.PtPrevState);

	            	printf("init life time totals LifetimeTruckLoadCount = %d \n",LpsSaJobMgrNvmLiveTimeTotal.LifetimeTruckLoadCount);
	            	printf("init life time totals LifetimeCycleCount = %d \n",LpsSaJobMgrNvmLiveTimeTotal.LifetimeCycleCount);

	            	printf("init life time totals LifetimePayloadPassCount = %d \n", LpsSaJobMgrNvmLiveTimeTotal.LifetimePayloadPassCount);
	            	printf("init life time totals LifetimeTotalPayload = %f \n", LpsSaJobMgrNvmLiveTimeTotal.LifetimeTotalPayload);

	            	LpsSaNvmJobMgrAppLiveValuesReadFlag = TRUE;

}

