/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaJobMgrApp.h
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef LPSSAJOBMGRAPP_H
#define LPSSAJOBMGRAPP_H

#ifndef __LPS_COMMON_TYPE_DEF_H__
#include <LpsCommonTypeDef.h>
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h>
#endif

#ifndef __LPS_PT_PUBLIC_H__
#include <LpsPtPublic.h>
#endif
#include <LpsPrivate.h>
#include <string>
#include <ais/task/Task.h>

#include <interfaces/LpsSaWeighReqstChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighRespChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrDebugChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighTxChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrTxChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrReqstChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrRespChannel/InterfaceTypes.h>
#include <interfaces/SwitchInputScs/InterfaceTypes.h>
#include <interfaces/OutputChannel/InterfaceTypes.h>
#include <interfaces/AisJhm2TxChannel/InterfaceTypes.h>
#include <interfaces/ShmClock/InterfaceTypes.h>
#include <task/commTask/commTask.h>
#include <ais/time/ConvertTime.h>
#include <nvm.h>
#include <fileio/iflocker.hpp>
#include "src_nvm/app_nvm_file_access.h"
#include <chrono>

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
//#define DEBUG

#define SUCCESS           (boolean) 1
#define FAIL              (boolean) 0

#define LPS_AUTOSTORE_MAX_PASSES 50

typedef enum
{
	LPS_SA_JOB_MGR_SCS_RESP_RECVD = 0,
	LPS_SA_JOB_MGR_SCS_RESP_INCORRECT,
	LPS_SA_JOB_MGR_SCS_RESP_NOT_RECVD,
	LPS_SA_JOB_MGR_SCS_RESP_UNKNOWN_ERR
}LpsSaJobMgrScsChkCmdResponseStat_t;

typedef enum
{
	LPS_SA_JOB_MGR_INIT_SUCCESS = 0,
	LPS_SA_JOB_MGR_SCS_INIT_ERROR,
	LPS_SA_JOB_MGR_PT_INIT_ERROR,
}LpsSaJobMgrInitErrorType_t;

using namespace std;

class LpsSaJobMgrApp: public task::Task,LpsSaWeighTxChannelStorage,LpsSaJobMgrReqstChannelStorage,LpsSaJobMgrRespChannelStorage,LpsSaJobMgrTxChannelStorage,public commTask
{
public:
   	bool checkeds = 0;
    LpsSaJobMgrApp( const std::string& taskName );
    virtual ~LpsSaJobMgrApp( );

    virtual bool initialize( );
    virtual bool executive( );
    virtual void cleanup( );

protected:
private:

    typedef struct
    {
    	/* This structure members may be
    	 * update in future based on TX channels
    	 */
    	/*TX Param*/
    	double 									DispTruckWt;
		unsigned int							SimpleCalPasscount;
    	int 									MaterialID;
    	string 									MaterialName;
    	LpsSaJobMgrManualTipOffState_t 			ManualTipOffState;
    	LpsSaTipOffTriggerType_t 				TipOffTriggerType;
    	LpsSaJobMgrTipOffState_t 				TipOffState;
    	LpsSaJobMgrOperationMode_t 				OperationMode;
    	LpsSaJobMgrStandbyState_t 				StandbyState;
    	LpsSaJobMgrClearMinusOneEnableStat_t 	ClearMinusOneEnableStat;
    	DispBestBktWt_t 						DispBestBktWt;
    	LpsSaJobMgrAutoManualTipOffDumpState_t  LpsSaJobMgrAutoManualTipOffDumpState;

    	/*RX Param*/
    	unsigned char 			    			DigStat; /* Machine Dig Status */
    	LpsSaWeighCalStatus_t 					CalStat; /* Lps System Calibration Status */
    	LpsSaWeighBktDumpStat_t 				DumpStat; /* Machine Dump Status */
    	unsigned int 							ZeroNotifyStat; /* Zero bucket notify status */
    	LpsWeighRangeIndicator_t    			Indicator;
		ReqPloadCtrlSysStat_t					ReqPloadCtrlSysStat;
    }LpsJobMgrJobTrackerInfoTbl_t;

	typedef enum
	{
		LPS_SA_JOB_MGR_SCS_CMD_ZERO_INDX =0,
		LPS_SA_JOB_MGR_SCS_CMD_BEST_BKT_WT_REST_INDX,
		LPS_SA_JOB_MGR_SCS_CMD_CAPT_CYL_EXTN_REF_INDX,
		LPS_SA_JOB_MGR_SCS_CMD_CLEAR_REWEIGH_WARNING_INDX,

		/* Add all command indexes above "LPS_SA_JOBMGR_NO_OF_REQST_PARAM_INDX"*/
		LPS_SA_JOB_MGR_SCS_CMD_NO_OF_PARAM_INDX
	} LpsSaJobMgrScsCmdStatIndex_t;

	/* This array holds the status of various cmd are send by JobMgr App
	true -> cmd  issued
	false-> cmd not issued
	*/
	bool LpsSaJobMgrScsCmdStatFlg[LPS_SA_JOB_MGR_SCS_CMD_NO_OF_PARAM_INDX];

   bool HornStoreEnableFlag;
   std::string    HornStoreNvmPath;
   const string  HornStoreNvmFileName = "/HornStoreEnable.bin";

	/* timezone and dst offsets */
	std::chrono::minutes LpsSaJobMgrMinsTZoneOffset;
	std::chrono::minutes LpsSaJobMgrMinsDSTOffset;

	LpsPtInputs_t 					LpsSaJobMgrWmInput;
	LpsPtOutputs_t 					LpsSaJobMgrWmOutput;
	LpsPtInit_t    					LpsSaWmInit;

	LpsJobMgrJobTrackerInfoTbl_t 	LpsJobMgrJobTrackerInfoTbl;
	std::deque<SimpleCalData_t> 	LpsJobMgrSimpleCalDataQueue;
	unsigned int 					storePressCount;
	float							simpleCalAdjustmentFactor;
	unsigned int					simpleCalMaxTrucksSupported;

    /*SCS  Interfaces*/
	LpsSaJobMgrTxChannelOutput    	*LpsSaJobMgrScsTxOut;/* from job manager write param to UI*/
	LpsSaJobMgrReqstChannelInput  	*LpsSaJobMgrScsReqstIn;/*get request from UI*/
	LpsSaJobMgrDebugChannelOutput 	*LpsSaJobMgrScsDebugOut;/*Debug symbols*/

	LpsSaWeighReqstChannelOutput  	*LpsSaWeighScsCmdOut;/*setCmd to weighing App*/
	LpsSaWeighRespChannelInput    	*LpsSaWeighScsRespIn;/*getRes from weighing App*/
	LpsSaWeighTxChannelInput      	*LpsSaWeighScsTxIn;/*get parameters from weighing app*/
	
	SwitchInputScsInput 		  	*LpsSaSwitchInput;
	OutputChannelOutput        *LpsSaOutputChannelOut;
	
	AisJhm2TxChannelInput		  	*AisJhm2TxInputScs;

	ShmClockInput                   *ShmClockInputScs;

    void LpsSaJobMgrPtInit(void);/* Pass tracker lib Initialization*/
    boolean LpsSaJobMgrPtUpdate(void);/*Job Manager App Pt Lib Update*/

    /*SCS  Functions*/
    void LpsSaWeighScsTxParamRead(void);/*get parameters from weighing app*/
    void LpsSaJobMgrScsChkForReqst(void);/*get request from UI*/

    boolean LpsSaJobMgrScsRx(void);/*get parameters from weighing app*/
    boolean LpsSaJobMgrScsTx(void);/*write param to UI*/
    void LpsSaJobMgrScsSendCmd(LpsSaJobMgrScsCmdStatIndex_t cmdIndx);/*setCmd to weighing App*/
	void NvmInitialize(void);
	void LpsSaInitJobMgrTbl(void);
	void LpsSaJobMgrSendCmdToWeighApp(void);
	void LpsSaJobMgrProcessStoreRequest(void);
	void LpsSaJobMgrHandleTipOffBtnStates(void);
	void LpsSaJobMgrAddSimpleCalTruckData(void);
	void AisJhmDataServerTxRead(void);
	void LpsSaJobMgrScsSHMRead(void);
	void Reset_flags(void);
	bool LpsSaJobMgrReadHornStateFromNvm();
	bool LpsSaJobMgrWriteHornStateToNvm();
	ReqPloadCtrlSysStat_t GetActiveButtonStatus (void);
	void LpsSaJobMgrScsChkHornAction(void);
	bool LpsSaJobMgrHornOnStoreAction(void);
	bool MakeDirFullPath( string path );


};

#endif
