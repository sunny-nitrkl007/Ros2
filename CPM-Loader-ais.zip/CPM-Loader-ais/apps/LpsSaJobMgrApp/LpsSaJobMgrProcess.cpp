/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaJobMgrProcess.cpp
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <stdio.h>

#include "LpsSaJobMgrApp.h"
#include <clock_tm_zone_proto.h>
#include <chrono>
#include <../../../TES-common-ais/prod/common/chrono/print.hpp>

#include <chrono/print.hpp>
#include <fileio/sha1_fstream.hpp>

#include <boost/filesystem.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/archive_exception.hpp>
#include <boost/uuid/sha1.hpp>

#include <fileio/oflocker.hpp>
#include <fileio/iflocker.hpp>


namespace fs = boost::filesystem;
/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
#define AUTO_STORE_PASSCOUNT 50.0

/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/


/******************************************************************************
FUNCTION NAME:LpsSaJobMgrPtUpdate
DESCRIPTION: Handles inputs and outputs of PT lib.           
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
boolean LpsSaJobMgrApp::LpsSaJobMgrPtUpdate(void)
{

	LpsSaJobMgrWmInput.cpm_install_status = true;

	if(LpsJobMgrJobTrackerInfoTbl.CalStat == LPS_SA_WEIGH_SYSTEM_CALIBRATED)
	{	
		LpsSaJobMgrWmInput.cpm_is_calibrated = true;
	}

	LpsSaJobMgrWmInput.pt_time_step_us = 100000.00;

	if(LpsJobMgrJobTrackerInfoTbl.DumpStat == LPS_SA_WEIGHT_BKT_PARTIALLY_DUMPED)
	{
		LpsSaJobMgrWmInput.dump_state_is_partial_dump = true;
	}
	else if(LpsJobMgrJobTrackerInfoTbl.DumpStat == LPS_SA_WEIGHT_BKT_FULLY_DUMPED)
	{
		LpsSaJobMgrWmInput.dump_state_is_full_dump = true;
	}

	if (LPS_SA_WEIGHT_BKT_DIGGING == LpsJobMgrJobTrackerInfoTbl.DigStat)
	{
		LpsSaJobMgrWmInput.dig_detected = true;
	}

	LOG_DEBUG( "\n LpsSaWeighInfoTbl.Indicator = %d\n",LpsJobMgrJobTrackerInfoTbl.Indicator );

	LOG_DEBUG(  "############# INPUTS #################");
	LOG_DEBUG(  "cpm_install_status: %d", (bool)LpsSaJobMgrWmInput.cpm_install_status);
	LOG_DEBUG(  "cpm_is_calibrated: %d", (bool)LpsSaJobMgrWmInput.cpm_is_calibrated);
	LOG_DEBUG(  "weigh_range_is_weighing: %d", (bool)LpsSaJobMgrWmInput.weigh_range_is_weighing);
	LOG_DEBUG(  "weight_available: %d", (bool)LpsSaJobMgrWmInput.weight_available);
	LOG_DEBUG(  "target_weight_request_status: %d", (bool)LpsSaJobMgrWmInput.target_weight_request_status);
	LOG_DEBUG(  "target_weight: %f" ,LpsSaJobMgrWmInput.target_weight);
	LOG_DEBUG(  "calc_method:%d", LpsSaJobMgrWmInput.calc_method);
	LOG_DEBUG(  "payload_latch_conditions_ok: %d", (bool)LpsSaJobMgrWmInput.payload_latch_conditions_ok);
	LOG_DEBUG(  "dump_state_is_partial_dump: %d",(bool)LpsSaJobMgrWmInput.dump_state_is_partial_dump);
	LOG_DEBUG(  "dump_state_is_full_dump: %d",  (bool)LpsSaJobMgrWmInput.dump_state_is_full_dump );
	LOG_DEBUG(  "current_bucket_weight_latched: %d",(bool)LpsSaJobMgrWmInput.current_bucket_weight_latched);
	LOG_DEBUG(  "dig_detected: %d" , (bool)LpsSaJobMgrWmInput.dig_detected );
	LOG_DEBUG(  "tip_off_trigger_request_status: %d",  (bool)LpsSaJobMgrWmInput.tip_off_trigger_request_status );
	LOG_DEBUG(  "tip_off_trigger: %d" , LpsSaJobMgrWmInput.tip_off_trigger);
	LOG_DEBUG(  "tip_off_mode_request_status: %d",  (bool)LpsSaJobMgrWmInput.tip_off_mode_request_status );
	LOG_DEBUG(  "tip_off_mode: %d" , LpsSaJobMgrWmInput.tip_off_mode);
	LOG_DEBUG(  "store_request_status: %d", (bool)LpsSaJobMgrWmInput.store_request_status );
	LOG_DEBUG(  "reweigh_request_status: %d", (bool)LpsSaJobMgrWmInput.reweigh_request_status );
	LOG_DEBUG(  "zero_request_status: %d" , (bool)LpsSaJobMgrWmInput.zero_request_status);
	LOG_DEBUG(  "minus_one_request_status: %d" ,  (bool)LpsSaJobMgrWmInput.minus_one_request_status );
	LOG_DEBUG(  "clear_request_status: %d" ,  (bool)LpsSaJobMgrWmInput.clear_request_status );
	LOG_DEBUG(  "tipoff_toggle_request_status: %d" , (bool)LpsSaJobMgrWmInput.tipoff_toggle_request_status );
	LOG_DEBUG(  "standby_request_status: %d" ,  (bool)LpsSaJobMgrWmInput.standby_request_status );
	LOG_DEBUG(  "change_mode_weigh : %d" ,  (bool)LpsSaJobMgrWmInput.change_mode_weigh );
	LOG_DEBUG(  "change_mode_excess: %d" ,  (bool)LpsSaJobMgrWmInput.change_mode_excess );

    /* ####################################### Inputs end here */
	LpsSaJobMgrWmOutput = weigh_mode(LpsSaJobMgrWmInput);
	/* ####################################### Ouputs start here */

	LOG_DEBUG(  "############# OUTPUTS #################" );
	LOG_DEBUG(  "display_weight: %f" , LpsSaJobMgrWmOutput.truck_weight );
	LOG_DEBUG(  "display_passcount: %f" , LpsSaJobMgrWmOutput.passcount );
	LOG_DEBUG(  "disp bucket weight: %f" , LpsSaJobMgrWmOutput.display_bucket_weight);
	LOG_DEBUG(  "weight_status: %d" , (bool)LpsSaJobMgrWmOutput.weight_status);
	LOG_DEBUG(  "clear_reweigh_warning_status: %d" , (bool)LpsSaJobMgrWmOutput.clear_reweigh_warning_status);
	LOG_DEBUG(  "dump_detect_capture_cyl_ext_reference: %d" , (bool)LpsSaJobMgrWmOutput.dump_detect_capture_cyl_ext_reference);
	LOG_DEBUG(  "add_simple_cal_data: %d" , (bool)LpsSaJobMgrWmOutput.add_truck_simple_cal );
	LOG_DEBUG(  "lpsPtLifetimeTotals.cummulative_weight: %f" , LpsSaJobMgrWmOutput.lpsPtLifetimeTotals.cummulative_weight);
	LOG_DEBUG(  "lpsPtLifetimeTotals.load_count: %d" , LpsSaJobMgrWmOutput.lpsPtLifetimeTotals.load_count);
	LOG_DEBUG(  "lpsPtLifetimeTotals.pass_count: %d" , LpsSaJobMgrWmOutput.lpsPtLifetimeTotals.pass_count);
	LOG_DEBUG(  "lpsPtTruckTotals.truck_weight: %f" , LpsSaJobMgrWmOutput.lpsPtTruckTotals.truck_weight );
	LOG_DEBUG(  "lpsPtTruckTotals.truck_pass_count: %d" , LpsSaJobMgrWmOutput.lpsPtTruckTotals.truck_pass_count );
	LOG_DEBUG(  "LastDumpedWt: %f" , LpsSaJobMgrWmOutput.lpsPtStoredState.last_payld_rec.PayloadWt );
	LOG_DEBUG(  "manual_tip_button_state: %d" , (bool)LpsSaJobMgrWmOutput.manual_tip_button_state);
	LOG_DEBUG(  "pt_current_state: %d" , LpsSaJobMgrWmOutput.pt_current_state);
	LOG_DEBUG(  "remainingWeight: %f" , LpsSaJobMgrWmOutput.remainingWeight);
	LOG_DEBUG(  "show_clear_not_minus_one: %d" , (bool)LpsSaJobMgrWmOutput.show_clear_not_minus_one);
	LOG_DEBUG(  "store_to_nvm_flag: %d" , (bool)LpsSaJobMgrWmOutput.store_to_nvm_flag);
	LOG_DEBUG(  "tip_off_mode: %d" , LpsSaJobMgrWmOutput.tip_off_mode);
	LOG_DEBUG(  "configured_tip_off_mode: %d" , LpsSaJobMgrWmOutput.configured_tip_off_mode);
	LOG_DEBUG(  "tip_off_trigger: %d" , LpsSaJobMgrWmOutput.tip_off_trigger);
	LOG_DEBUG(  "unlatch_current_bucket_weight: %d" , (bool)LpsSaJobMgrWmOutput.unlatch_current_bucket_weight );

	LpsJobMgrJobTrackerInfoTbl.ReqPloadCtrlSysStat = GetActiveButtonStatus();

	if(LpsSaJobMgrWmOutput.add_truck_simple_cal)
	{
		LpsSaJobMgrProcessStoreRequest();
		LpsSaJobMgrScsChkHornAction();
	}
	

	LpsJobMgrJobTrackerInfoTbl.SimpleCalPasscount = (unsigned int)LpsSaJobMgrWmOutput.passcount;
	
	LpsJobMgrJobTrackerInfoTbl.DispTruckWt = (double)LpsSaJobMgrWmOutput.truck_weight;
	LpsJobMgrJobTrackerInfoTbl.DispBestBktWt.Val = LpsSaJobMgrWmOutput.display_bucket_weight;

	if(LpsSaJobMgrWmOutput.show_clear_not_minus_one)
	{
		LpsJobMgrJobTrackerInfoTbl.ClearMinusOneEnableStat = LPS_SA_JOB_MGR_CLEAR_BTN_ENABLED;
	}
	else
	{
		LpsJobMgrJobTrackerInfoTbl.ClearMinusOneEnableStat = LPS_SA_JOB_MGR_MINUS_ONE_BTN_ENABLED;
		LpsSaJobMgrWmInput.clear_request_status = FALSE;
	}
	
	LpsSaJobMgrSendCmdToWeighApp();

	Reset_flags();   // Reset the flags and then handle tipoff.
	
	LpsSaJobMgrHandleTipOffBtnStates();
	
	//Set flags to show bucket weight on the display. 
	if (LpsSaJobMgrWmOutput.weight_status)
	{
		LpsJobMgrJobTrackerInfoTbl.DispBestBktWt.Stat = LPS_SA_BEST_BKT_WEIGHT_STAT_OK;
	}
	else
	{
		/* Sending display status to UI to display *** at Bucket weight */
		LpsJobMgrJobTrackerInfoTbl.DispBestBktWt.Stat = LPS_SA_BEST_BKT_WEIGHT_STAT_BAD;
	}
	
	//Stall Detect.
	if(LpsSaJobMgrWmOutput.pt_current_state == WAIT_FOR_DUMP_ARI || LpsSaJobMgrWmOutput.pt_current_state == TIP_OFF_IRI)
	{
		LpsJobMgrJobTrackerInfoTbl.LpsSaJobMgrAutoManualTipOffDumpState = LPS_SA_JOB_MGR_AUTO_MANUAL_TIP_OFF_DUMP_STATE_ACTIVE ;
	}
	else
	{
		LpsJobMgrJobTrackerInfoTbl.LpsSaJobMgrAutoManualTipOffDumpState = LPS_SA_JOB_MGR_AUTO_MANUAL_TIP_OFF_DUMP_STATE_INACTIVE ;
	}

    return SUCCESS;
}


/******************************************************************************
FUNCTION: LpsSaJobMgrScsChkHornAction
DESCRIPTION: Raise Action Flag when it fit the condition.
PARAMETER DESCRIPTION:
RETURN VALUE:void
*******************************************************************************/
void LpsSaJobMgrApp::LpsSaJobMgrScsChkHornAction()
{
   LOG_INFO( "Passcount = %f   HornStoreEnableFlag:%d", LpsSaJobMgrWmOutput.passcount, HornStoreEnableFlag);

   if(( LpsSaJobMgrWmOutput.passcount < AUTO_STORE_PASSCOUNT ) && ( HornStoreEnableFlag ))
   {
            LOG_INFO( "Horn: ACTIVATED" );
            LpsSaJobMgrHornOnStoreAction();			// send scs object to OutputApp to drive Output Pin
   }
   else
   {
      LOG_INFO( "Horn: NOT ACTIVATED" );
   }
}


/******************************************************************************
FUNCTION:LpsSaJobMgrHandleTipOffBtnStates
DESCRIPTION:Handles whether to show or hide tip off buttons.
PARAMETER DESCRIPTION:
RETURN VALUE:void
*******************************************************************************/
void LpsSaJobMgrApp::LpsSaJobMgrHandleTipOffBtnStates()
{
	LpsJobMgrJobTrackerInfoTbl.TipOffState = LPS_SA_JOB_MGR_TIP_OFF_UNAVAILABLE;
	LpsJobMgrJobTrackerInfoTbl.ManualTipOffState = LPS_SA_JOB_MGR_MAN_TIP_OFF_UNAVAILABLE;
	LpsJobMgrJobTrackerInfoTbl.TipOffTriggerType = (LpsSaTipOffTriggerType_t) LpsSaJobMgrWmOutput.tip_off_trigger;
	
	if (LpsSaJobMgrWmOutput.weight_status)
	{
		if(LpsSaJobMgrWmOutput.tip_off_trigger == TIP_OFF_TRIGGER_MANUAL)
		{
			if (LpsSaJobMgrWmOutput.manual_tip_button_state == FALSE)
			{
				LpsJobMgrJobTrackerInfoTbl.ManualTipOffState = LPS_SA_JOB_MGR_MAN_TIP_OFF_AVAILABLE;
			}
			else
			{
				LpsJobMgrJobTrackerInfoTbl.ManualTipOffState = LPS_SA_JOB_MGR_MAN_TIP_OFF_ACTIVE;
				LpsJobMgrJobTrackerInfoTbl.TipOffState = (LpsSaJobMgrTipOffState_t)LpsSaJobMgrWmOutput.tip_off_mode;
			}
		}
		else /* trigger is auto or disabled */
		{
			if(LpsSaJobMgrWmOutput.pt_current_state == TIP_OFF_IRI)
			{
				LpsJobMgrJobTrackerInfoTbl.TipOffState = (LpsSaJobMgrTipOffState_t)LpsSaJobMgrWmOutput.tip_off_mode;
			}
		}
	}
}

/******************************************************************************
FUNCTION:LpsSaJobMgrSendCmdToWeighApp
DESCRIPTION:Send appropriate commands to weigh app depending on flags set. 
PARAMETER DESCRIPTION:
RETURN VALUE:void
*******************************************************************************/
void LpsSaJobMgrApp::LpsSaJobMgrSendCmdToWeighApp()
{
	if(LpsSaJobMgrWmOutput.unlatch_current_bucket_weight)
	{
		LpsSaJobMgrScsSendCmd(LPS_SA_JOB_MGR_SCS_CMD_BEST_BKT_WT_REST_INDX);
	}
	
	if(LpsSaJobMgrWmOutput.dump_detect_capture_cyl_ext_reference)
	{
		LpsSaJobMgrScsSendCmd(LPS_SA_JOB_MGR_SCS_CMD_CAPT_CYL_EXTN_REF_INDX);
	}

	if(LpsSaJobMgrWmOutput.clear_reweigh_warning_status)
	{
		LpsSaJobMgrScsSendCmd(LPS_SA_JOB_MGR_SCS_CMD_CLEAR_REWEIGH_WARNING_INDX);
	}
}


/******************************************************************************
FUNCTION:Reset_flags
DESCRIPTION:Resets some of the input flags.
PARAMETER DESCRIPTION:
RETURN VALUE:void
*******************************************************************************/
void LpsSaJobMgrApp::Reset_flags()
{
	LpsSaJobMgrWmInput.cpm_is_calibrated = FALSE;
	LpsSaJobMgrWmInput.tip_off_mode_request_status = FALSE;
	LpsSaJobMgrWmInput.dump_state_is_partial_dump = FALSE;
	LpsSaJobMgrWmInput.dump_state_is_full_dump = FALSE;
	LpsSaJobMgrWmInput.dig_detected = FALSE;
	LpsSaJobMgrWmInput.tip_off_trigger_request_status = FALSE;
	LpsSaJobMgrWmInput.target_weight_request_status = FALSE;
	LpsSaJobMgrWmInput.minus_one_request_status = FALSE;
	LpsSaJobMgrWmInput.reweigh_request_status = FALSE;
	LpsSaJobMgrWmInput.zero_request_status = FALSE;
	LpsSaJobMgrWmInput.tipoff_toggle_request_status = FALSE;
	LpsSaJobMgrWmInput.standby_request_status = FALSE;
	LpsSaJobMgrWmInput.change_mode_weigh = FALSE;
	LpsSaJobMgrWmInput.change_mode_excess = FALSE;
	LpsSaJobMgrWmInput.store_request_status = FALSE;
}


/******************************************************************************
FUNCTION: LpsSaJobMgrProcessStoreRequest
DESCRIPTION:Process Store Request form UI
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaJobMgrApp::LpsSaJobMgrProcessStoreRequest( void )
{
	/* updating info-table data to Lifetime totals */
	LpsSaJobMgrNvmLiveTimeTotal.LifetimeTruckLoadCount = LpsSaJobMgrWmOutput.lpsPtLifetimeTotals.load_count;
	LpsSaJobMgrNvmLiveTimeTotal.LifetimeCycleCount = LpsSaJobMgrWmOutput.lpsPtLifetimeTotals.pass_count;
	LpsSaJobMgrNvmLiveTimeTotal.LifetimeTotalPayload = LpsSaJobMgrWmOutput.lpsPtLifetimeTotals.cummulative_weight;
	LpsSaJobMgrNvmLiveTimeTotal.LifetimePayloadPassCount = LpsSaJobMgrWmOutput.lpsPtLifetimeTotals.pass_count;

	/* Writing Life time total  Data to NVM */
	LpsSaNvmJobMgrAppLiveValuesWriteFlag = TRUE;

	LOG_NOTICE("init life time totals LifetimeCycleCount = %d \n",LpsSaJobMgrNvmLiveTimeTotal.LifetimeCycleCount);
	LOG_NOTICE("init life time totals LifetimeTruckLoadCount = %d \n",LpsSaJobMgrNvmLiveTimeTotal.LifetimeTruckLoadCount);
	LOG_NOTICE("init life time totals LifetimePayloadPassCount = %d \n", LpsSaJobMgrNvmLiveTimeTotal.LifetimePayloadPassCount);
	LOG_NOTICE("init life time totals LifetimeTotalPayload = %f \n", LpsSaJobMgrNvmLiveTimeTotal.LifetimeTotalPayload);

	if(LpsJobMgrJobTrackerInfoTbl.SimpleCalPasscount > 0)
		LpsSaJobMgrAddSimpleCalTruckData();

}


/******************************************************************************
FUNCTION: LpsSaJobMgrAddSimpleCaltruckData
DESCRIPTION:clear payload  Data
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaJobMgrApp::LpsSaJobMgrAddSimpleCalTruckData()
{
	TimeStamp 		localTime;
	SimpleCalData_t TruckData;
	
	storePressCount++;

	std::chrono::system_clock::time_point now = std::chrono::system_clock::now(); /* utc time */

	/* Apply the tzone and dst offsets, convert to tm, and store timestamp in temp string */
	auto local_tp = now + LpsSaJobMgrMinsTZoneOffset + LpsSaJobMgrMinsDSTOffset;
    string temp = tes_common_ais::putTime(local_tp, tes_common_ais::date_time_formats::ISO_DATE_TIME_LOCAL_NO_T);

    LOG_DEBUG("Simple Cal Timestamp: %s \n", temp.c_str());

	TruckData.truckWt = LpsJobMgrJobTrackerInfoTbl.DispTruckWt;
	TruckData.zeroedTruckWt = TruckData.truckWt/simpleCalAdjustmentFactor;
	TruckData.timeStamp = temp;
	
	if(LpsJobMgrSimpleCalDataQueue.size() >= simpleCalMaxTrucksSupported)
		LpsJobMgrSimpleCalDataQueue.pop_front();
	
	LpsJobMgrSimpleCalDataQueue.push_back(TruckData);
}


/******************************************************************************
FUNCTION: LpsSaJobMgrReadHornStateFromNvm
DESCRIPTION: Read HornStoreEnableFlag from given nvm path
PARAMETER DESCRIPTION: path
RETURN VALUE:
*******************************************************************************/
bool LpsSaJobMgrApp::LpsSaJobMgrReadHornStateFromNvm()
{
    bool success = false;
    tes_common_ais::sha1_ifstream ifs{ true }; // two_copy
    ifs.open(HornStoreNvmPath, std::ios_base::in | std::ios_base::binary);
    if (ifs) {
        // Read the file in
        try {
      	    ifs >> HornStoreEnableFlag;
            LOG_ERROR("retrieve HornStore from storage.:%d", HornStoreEnableFlag);
            success = true;
        }
        catch (...) {
            LOG_ERROR("Could not retrieve HornStore from storage, unexpected error.");
        }

        ifs.close();

        if (ifs.is_corrupt()) {
            if (ifs.fix_it()) {
                LOG_WARN("HornStore file was corrupt... fixed it.");
            }
            else {
                LOG_ERROR("HornStore file was corrupt... could not fix it.");
            }
        }
    }
    else {
        LOG_ERROR("HornStore could not be opened from storage.");
    }

    return success;
}

/******************************************************************************
FUNCTION: LpsSaJobMgrWriteHornStateToNvm
DESCRIPTION: write HornStoreEnableFlag to given nvm path.
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
bool LpsSaJobMgrApp::LpsSaJobMgrWriteHornStateToNvm()
{
    bool success = false;
    tes_common_ais::sha1_ofstream ofs{ true }; // two_copy
    ofs.open(HornStoreNvmPath, std::ios_base::out | std::ios_base::binary);
    if (ofs) {
            ofs << HornStoreEnableFlag;
            LOG_ERROR("Saved HornStore to storage:%d", HornStoreEnableFlag);
            success = true;
            ofs.close();
    }
    else {
        LOG_ERROR("HornStore could not be opened from storage.");
    }

    return success;
}


/******************************************************************************
FUNCTION: MakeDirFullPath
DESCRIPTION: Make nvm path when it not exist.
PARAMETER DESCRIPTION: path: the
RETURN VALUE:
*******************************************************************************/
bool LpsSaJobMgrApp::MakeDirFullPath( string path )
{
   bool ret_val = false;
   if(fs::is_directory( path ) )//Check the Dir
   {
      ret_val = true;
   }
   else
   {
    try {
        fs::create_directories( path );
        LOG_NOTICE( "path created: %s", path.c_str() );
        ret_val = true;
     }
    catch (const fs::filesystem_error& e) {
        LOG_ERROR(e.what());
    }
   }
   return ret_val;
}

