/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaJobMgrInit.cpp
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include "LpsSaJobMgrApp.h"

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
/******************************************************************************
FUNCTION NAME:LpsSaJobMgrApp::LpsSaJobMgrInit()
DESCRIPTION:Initialize the pass tracker Lib
PARAMETER DESCRIPTION:
RETURN VALUE:LpsSaJobMgrInitErrorType_t
*******************************************************************************/
void LpsSaJobMgrApp::LpsSaJobMgrPtInit()
{
	LpsSaWmInit.lpsPtLifetimeTotals.load_count = LpsSaJobMgrNvmLiveTimeTotal.LifetimeTruckLoadCount;
	LpsSaWmInit.lpsPtLifetimeTotals.cummulative_weight = LpsSaJobMgrNvmLiveTimeTotal.LifetimeTotalPayload;
	LpsSaWmInit.lpsPtLifetimeTotals.pass_count = LpsSaJobMgrNvmLiveTimeTotal.LifetimePayloadPassCount;

	LpsSaWmInit.lpsPtTruckTotals.truck_weight = LpsSaJobMgrNvmLiveTimeTotal.TotalTruckWt;
	LpsSaWmInit.lpsPtTruckTotals.truck_pass_count = LpsSaJobMgrNvmLiveTimeTotal.PassCount;			 

	LpsSaWmInit.lpsPtStoredState.last_payld_rec.PayloadWt = LpsSaJobMgrNvmLiveTimeTotal.LastDumpedWt;
	LpsSaWmInit.lpsPtStoredState.truck_target_wt = LpsSaJobMgrNvmLiveTimeTotal.TargetWeight;

	LpsSaWmInit.pt_prev_state = LpsSaJobMgrNvmLiveTimeTotal.PtPrevState;
	LpsSaWmInit.lastKnownBucketWeight = LpsSaJobMgrNvmLiveTimeTotal.LastKnownBestBktWtInTonnes;

	LpsSaWmInit.tip_off_mode = LpsSaJobMgrNvmMachSpecificCfg.TipOffState;
	LpsSaWmInit.tip_off_trigger = LpsSaJobMgrNvmMachSpecificCfg.TipOffTriggerType;

	LpsPtInit(LpsSaWmInit);


}


/******************************************************************************
FUNCTION: NvmInitialize
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaJobMgrApp::NvmInitialize(void)
{

    /* Wait till OEL layer boot up*/
	 while(FALSE == OelBootupFlag);

	/* Wait till NVM is read */
	 while((FALSE == LpsSaNvmJobMgrAppMachSpecificCfgReadFlag) || (FALSE == LpsSaNvmJobMgrAppLiveValuesReadFlag));

}
/******************************************************************************
FUNCTION: LpsSaInitJobMgrTbl
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaJobMgrApp::LpsSaInitJobMgrTbl(void)
{

	float     defTargetWeighttemp;
	char      defTipOffTriggerTypetemp;
	char      defTipOffStatetemp;

	/* getting default machine config data */

	getTaskConfig().get( "DefTargetWeight",defTargetWeighttemp);
	getTaskConfig().get( "DefTipOffTriggerType",defTipOffTriggerTypetemp);
	getTaskConfig().get( "DefTipOffState",defTipOffStatetemp);
   getTaskConfig().get( "SimpleCalMaxTrucksSupported",simpleCalMaxTrucksSupported);
   getTaskConfig().get( "HornStoreNvmPath",HornStoreNvmPath);


	LpsSaJobMgrNvmDefLiveTimeTotal.TargetWeight = defTargetWeighttemp;
	LpsSaJobMgrNvmDefMachSpecificCfg.TipOffTriggerType = defTipOffTriggerTypetemp;
	LpsSaJobMgrNvmDefMachSpecificCfg.TipOffState = defTipOffStatetemp;

	LOG_NOTICE( "defTargetWeight %f",LpsSaJobMgrNvmDefLiveTimeTotal.TargetWeight);
	LOG_NOTICE( "defTipOffTriggerType %d",LpsSaJobMgrNvmDefMachSpecificCfg.TipOffTriggerType);
	LOG_NOTICE( "defTipOffState %d",LpsSaJobMgrNvmDefMachSpecificCfg.TipOffState);

   	MakeDirFullPath( HornStoreNvmPath);

	HornStoreNvmPath= HornStoreNvmPath+HornStoreNvmFileName;

   LOG_NOTICE("Reading From Nvm");

   HornStoreEnableFlag = false;	// default to FALSE until we get ET & UI working
   if( !LpsSaJobMgrReadHornStateFromNvm())
   {
      ConfigSection machineCfg;
      LOG_NOTICE("Finding MachineSpecificConfig section");
      if( getTaskParser().getSection( "MachineSpecificConfig", machineCfg ) )
      {
         if(!machineCfg.get( "HornStoreEnable", HornStoreEnableFlag ))
         {
            LOG_NOTICE("Config section item not found, set HornStoreEnableFlag to default: %d", HornStoreEnableFlag);
         }
         else
         {
            LOG_NOTICE("Config section item found, set HornStoreEnableFlag to: %d", HornStoreEnableFlag);
         }
      }
      else
      {
         LOG_NOTICE("MachineSpecificConfig section not found, set HornStoreEnableFlag to default: %d", HornStoreEnableFlag);
      }
      LpsSaJobMgrWriteHornStateToNvm();
   }
}
