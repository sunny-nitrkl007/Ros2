///////////////////////////////////////////////////////////////////////////////
/// @file      XcpScsInputs.h
/// @author    J Struble
/// @date      3/22/2013
/// @brief     Structure containing all data coming in from SCS that needs
///            to displayed in jhm2
///
/// @attention COPYRIGHT (C) 2012 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////
#ifndef XCPSCSINPUTS_H_
#define XCPSCSINPUTS_H_

#include <scsIOContainer/SCSInputs.h>
#include <scsIOContainer/SCSInData.h>
#include <ais/config/ConfigSection.h>

//Interfaces we want to receive and store
#include <interfaces/LpsSaWeighReqstChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighRespChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighTxChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrTxChannel/InterfaceTypes.h>
#include <interfaces/PwmInputChannels/InterfaceTypes.h>
#include <interfaces/Machine/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrReqstChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrRespChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrDebugChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrDebugChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighDebugChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighInitDebugChannel/InterfaceTypes.h>
#include <interfaces/LpsSaNvmCalDataChannel/InterfaceTypes.h>
#include <interfaces/LpsSaNvmCalOnTheFlyDataChannel/InterfaceTypes.h>

class XcpScsInputs : public SCSInputs
{

  public:
	SCSInData<LpsSaWeighReqstChannel>   m_lpsSaWeighRegstChannel;
	SCSInData<LpsSaWeighRespChannel>    m_lpsSaWeighRespChannel;
	SCSInData<LpsSaWeighDebugChannel>   m_lpsSaWeighDebugChannel;
	SCSInData<LpsSaWeighInitDebugChannel>    m_lpsSaWeighInitDebugChannel;
	SCSInData<LpsSaWeighTxChannel>   	m_lpsSaWeighTxChannel;
	SCSInData<LpsSaNvmCalDataChannel> m_lpsSaNvmDataChannel;
	SCSInData<LpsSaNvmCalOnTheFlyDataChannel> m_lpsSaNvmOnTheFlyDataChannel;
	SCSInData<LpsSaJobMgrTxChannel>   	m_lpsSaJobMgrTxChannel;
	SCSInData<PwmInputChannels>   		m_pwmInputChannels;
	SCSInData<Machine>   				m_machine;
	SCSInData<LpsSaJobMgrReqstChannel>  m_lpsSaJobMgrReqstChannel;
	SCSInData<LpsSaJobMgrRespChannel>  	m_lpsSaJobMgrRespChannel;
	SCSInData<LpsSaJobMgrDebugChannel>  m_lpsSaJobMgrDebugChannel;

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Run "update" on all of the scs channels in the structure
  ///
  /// @return true if any channel has new data, false otherwise
  ///////////////////////////////////////////////////////////////////////////////
  bool update()
  {
	bool retVal = true;

    if ( !m_lpsSaWeighRegstChannel.update() ) retVal = false;
    if ( !m_lpsSaWeighRespChannel.update() ) retVal = false;
    if ( !m_lpsSaWeighDebugChannel.update() ) retVal = false;
    if ( !m_lpsSaWeighInitDebugChannel.update() ) retVal = false;
    if ( !m_lpsSaWeighTxChannel.update() ) retVal = false;
    if ( !m_lpsSaNvmDataChannel.update() ) retVal = false;
    if ( !m_lpsSaNvmOnTheFlyDataChannel.update() ) retVal = false;
    if ( !m_lpsSaJobMgrTxChannel.update() ) retVal = false;
    if ( !m_pwmInputChannels.update() ) retVal = false;
    if ( !m_machine.update() ) retVal = false;
    if ( !m_lpsSaJobMgrReqstChannel.update() ) retVal = false;
    if ( !m_lpsSaJobMgrRespChannel.update() ) retVal = false;
    if ( !m_lpsSaJobMgrDebugChannel.update() ) retVal = false;

    return retVal;
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Run "initReadInterface" on all of the scs channels in the structure
  ///
  /// @return true if all interfaces were successfully configured, false if any failed
  ///////////////////////////////////////////////////////////////////////////////
  bool initReadInterface( ConfigSection& cs )
  {
    bool retVal = true;

    if ( !m_lpsSaWeighRegstChannel.initReadInterface("LpsSaWeighReqstChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaWeighRespChannel.initReadInterface("LpsSaWeighRespChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaWeighTxChannel.initReadInterface("LpsSaWeighTxChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaWeighDebugChannel.initReadInterface("LpsSaWeighDebugChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaWeighInitDebugChannel.initReadInterface("LpsSaWeighInitDebugChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaNvmDataChannel.initReadInterface("LpsSaNvmCalDataChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaNvmOnTheFlyDataChannel.initReadInterface("LpsSaNvmCalOnTheFlyDataChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaJobMgrTxChannel.initReadInterface("LpsSaJobMgrTxChannelInput", cs) ) retVal = false;
    if ( !m_pwmInputChannels.initReadInterface("PwmInputChannelsInput", cs) ) retVal = false;
    if ( !m_machine.initReadInterface("MachineInput", cs) ) retVal = false;
    if ( !m_lpsSaJobMgrReqstChannel.initReadInterface("LpsSaJobMgrReqstChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaJobMgrRespChannel.initReadInterface("LpsSaJobMgrRespChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaJobMgrDebugChannel.initReadInterface("LpsSaJobMgrDebugChannelInput", cs) ) retVal = false;

    return retVal;
  }

};

#endif /*XCPSCSINPUTS_H_*/
