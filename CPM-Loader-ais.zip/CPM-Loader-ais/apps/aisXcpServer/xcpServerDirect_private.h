/*
 * xcpServer.h
 *
 *  Created on: Mar 1, 2017
 *      Author: pf
 */

#ifndef XCPSERVERPRIVATE_H_
#define XCPSERVERPRIVATE_H_

bool xcpServerInit(void *pContext);
bool xcpServerUpdate();
void xcpServerCleanup();

#endif /* XCPSERVERPRIVATE_H_ */
