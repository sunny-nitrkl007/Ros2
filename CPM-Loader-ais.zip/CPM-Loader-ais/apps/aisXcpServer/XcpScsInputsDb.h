///////////////////////////////////////////////////////////////////////////////
/// @file      XcpScsInputs.h
/// @author    J Struble
/// @date      3/22/2013
/// @brief     Structure containing all data coming in from SCS that needs
///            to displayed in jhm2
///
/// @attention COPYRIGHT (C) 2012 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////
#ifndef XCPSCSINPUTS_H_
#define XCPSCSINPUTS_H_

#include <scsIOContainer/SCSInputs.h>
#include <scsIOContainer/SCSInData.h>
#include <ais/config/ConfigSection.h>

//Interfaces we want to receive and store
#include <interfaces/LpsSaWeighReqstChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighRespChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighTxChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrTxChannel/InterfaceTypes.h>
#include <interfaces/PwmInputChannels/InterfaceTypes.h>
#include <interfaces/Machine/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrReqstChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrRespChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrDebugChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrDebugChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighDebugChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighInitDebugChannel/InterfaceTypes.h>
#include <interfaces/SwitchInputScs/InterfaceTypes.h>
#include <interfaces/LpsSaNvmCalDataChannel/InterfaceTypes.h>
#include <interfaces/LpsSaNvmCalOnTheFlyDataChannel/InterfaceTypes.h>

#include <stddef.h>     /* offsetof */
#include "xcp_server/db/XCPServerDb.hpp"
using namespace xcp_server;

// Macros that are used to push SCS data into 'db': DB_PUSH invokes db.update, DB_PUSH_ARRAY expands into a for-loop with DB_PUSH invocations
#define DB_PUSH(item) db.update( ((index << 16) |  offset++ ), (item))
#define DB_PUSH_ARRAY(array_name,num_elements) for (uint8_t iter=0; iter < num_elements; iter++)                                   \
                                               {                                                                                   \
                                                  DB_PUSH(array_name[iter]);                                                       \
                                               }

class XcpScsInputs : public SCSInputs
{

  public:

	ParameterDb db;

	SCSInData<LpsSaWeighReqstChannel>   m_lpsSaWeighRegstChannel;
	SCSInData<LpsSaWeighRespChannel>    m_lpsSaWeighRespChannel;
	SCSInData<LpsSaWeighDebugChannel>   m_lpsSaWeighDebugChannel;
	SCSInData<LpsSaWeighInitDebugChannel>    m_lpsSaWeighInitDebugChannel;
	SCSInData<LpsSaWeighTxChannel>   	m_lpsSaWeighTxChannel;
	SCSInData<LpsSaNvmCalDataChannel> m_lpsSaNvmDataChannel;
	SCSInData<LpsSaNvmCalOnTheFlyDataChannel> m_lpsSaNvmOnTheFlyDataChannel;
	SCSInData<LpsSaJobMgrTxChannel>   	m_lpsSaJobMgrTxChannel;
	SCSInData<PwmInputChannels>   		m_pwmInputChannels;
	SCSInData<Machine>   				m_machine;
	SCSInData<LpsSaJobMgrReqstChannel>  m_lpsSaJobMgrReqstChannel;
	SCSInData<LpsSaJobMgrRespChannel>  	m_lpsSaJobMgrRespChannel;
	SCSInData<LpsSaJobMgrDebugChannel>  m_lpsSaJobMgrDebugChannel;
	SCSInData<SwitchInputScs>  			m_switchInputScs;

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Run "update" on all of the scs channels in the structure
  ///
  /// @return true if any channel has new data, false otherwise
  ///////////////////////////////////////////////////////////////////////////////
  bool update()
  {
	bool retVal = true;
	static int init_done = 0;
	int index = 0;
	int offset = 0;

	/* xcp app vars to monitor */
	static int xcp_counter=0;
	db.update( ((index << 16) |  255 ), xcp_counter++);
	/* -----------------*/
	index++; offset=0;

	if ( m_lpsSaWeighRegstChannel.update() | !init_done ) {

		db.update( ((index << 16) |  offset++ ), m_lpsSaWeighRegstChannel.ZeroReqst);
		db.update( ((index << 16) |  offset++ ), m_lpsSaWeighRegstChannel.BestBktRstReqst);
		db.update( ((index << 16) |  offset++ ), m_lpsSaWeighRegstChannel.CaptCylExtRef);
		db.update( ((index << 16) |  offset++ ), m_lpsSaWeighRegstChannel.WeighRangeRequest.WeighRangeReqstFlag);
		db.update( ((index << 16) |  offset++ ), m_lpsSaWeighRegstChannel.WeighRangeRequest.WeighRangeBottom);
		db.update( ((index << 16) |  offset++ ), m_lpsSaWeighRegstChannel.WeighRangeRequest.WeighRangeSize);

		static int m_lpsSaWeighRegstChannel_counter=0;
		db.update( ((index << 16) |  255 ), m_lpsSaWeighRegstChannel_counter++);
	}
    index++; offset=0;

    if ( m_lpsSaWeighRespChannel.update() | !init_done ) {
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighRespChannel.ZeroResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighRespChannel.BestBktRstResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighRespChannel.WeighRangeResp);

    	static int m_lpsSaWeighRespChannel_counter=0;
    	db.update( ((index << 16) |  255 ), m_lpsSaWeighRespChannel_counter++);
    }
    index++; offset=0;

    if ( m_lpsSaWeighDebugChannel.update() | !init_done ) {
    	/* LpsUpdtTbl_t m_weighUpdtTbl */
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_weighUpdtTbl.LiftCylHePres.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.LiftCylHePres.Val);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_weighUpdtTbl.LiftCylRePres.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.LiftCylRePres.Val);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_weighUpdtTbl.LiftCylExt.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.LiftCylExt.Val);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_weighUpdtTbl.LiftCylVel.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.LiftCylVel.Val);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_weighUpdtTbl.HydOilTemp.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.HydOilTemp.Val);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.ClockKeyonSec);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.PassCount);
    	db.update( ((index << 16) |  offset++ ), (bool)m_lpsSaWeighDebugChannel.m_weighUpdtTbl.ZeroButtonPress);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_weighUpdtTbl.TiltCylExt.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.TiltCylExt.Val);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_weighUpdtTbl.TiltCylVel.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.TiltCylVel.Val);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_weighUpdtTbl.BktAngle.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.BktAngle.Val);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_weighUpdtTbl.RequestedGear.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.RequestedGear.Val);
    	db.update( ((index << 16) |  offset++ ), (bool)m_lpsSaWeighDebugChannel.m_weighUpdtTbl.UseFastFilter);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_weighUpdtTbl.LoaderBktPayldTrgtWt);

    	/* LpsWrkTbl_t m_LpsWrk */
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.LiftCylPres);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.InstWtLlwFilt);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.InstWtDer);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.InstWtRaw.Val);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.InstWtRaw.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.InstWtFilt);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.CylFlowConst.LiftHeFlowConst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.CylFlowConst.LiftReToHeFlowRatio);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.LinkageMovement.lift);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.LinkageMovement.tilt);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.WrwTbl.OpTbl.Wt);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.WrwTbl.OpTbl.Warning);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.WrwTbl.OpTbl.Status);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.WrwTbl.OpTbl.Indicator);
    	db.update( ((index << 16) |  offset++ ), (bool)m_lpsSaWeighDebugChannel.m_LpsWrk.WrwTbl.WkTbl.BeenBelowRange);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.LpsStallDetect.LiftStallStat);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.DumpStateStatus);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.BestBktWt.Wt);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.BestBktWt.PayloadCalcMeth);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.LowLiftWt.LastInput);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.LowLiftWt.MeanEst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.LowLiftWt.MeanEstComp);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.LowLiftWt.VarianceEst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.LowLiftWt.StdevEst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.LowLiftWt.Confidence);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.LowLiftWt.ConfidenceEst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.LowLiftWt.ConfidenceTimer);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.LowLiftWt.Wt);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.LowLiftWt.Stat);
    	db.update( ((index << 16) |  offset++ ), (bool)m_lpsSaWeighDebugChannel.m_LpsWrk.ZeroAdjTbl.ZeroAccepted);
    	db.update( ((index << 16) |  offset++ ), (bool)m_lpsSaWeighDebugChannel.m_LpsWrk.ZeroAdjTbl.TooHeavyToZero);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.ZeroAdjTbl.ZeroAdjStatus);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.DumpWtChangeData.DumpCumulativeWtChange);
    	db.update( ((index << 16) |  offset++ ), (bool)m_lpsSaWeighDebugChannel.m_LpsWrk.DigDetectData.DigStarted);
    	db.update( ((index << 16) |  offset++ ), (bool)m_lpsSaWeighDebugChannel.m_LpsWrk.DigDetectData.DigDetected);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.DigDetectData.DigState);
    	db.update( ((index << 16) |  offset++ ), (bool)m_lpsSaWeighDebugChannel.m_LpsWrk.DigDetectData.WtStabilized);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.DigDetectData.DigDuration);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.m_LpsWrk.LiveWeighTbl.Wt);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighDebugChannel.m_LpsWrk.LiveWeighTbl.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.reweighWarn);

    	/* Lift Cylinder Head End Pressure */
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylHePeriod);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylHeWidth);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylHeDc);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylHePress);

    	/* Lift Cylinder Rod End Pressure */
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylRePeriod);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylReWidth);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylReDc);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylRePress);

    	/* Lift Cylinder */
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylPeriod);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylWidth);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylDc);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylRawExt);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylFiltExt);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylNormExt);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftCylVel);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugLiftAngle);

    	/* Tilt Cylinder */
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugTiltCylPeriod);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugTiltCylWidth);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugTiltCylDc);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugTiltCylRawExt);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugTiltCylVel);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugTiltAngle);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighDebugChannel.DebugTiltAngleABC);

    	static int m_lpsSaWeighDebugChannel_counter=0;
    	db.update( ((index << 16) |  255 ), m_lpsSaWeighDebugChannel_counter++);
    }
    index++; offset=0;

    if ( m_lpsSaWeighInitDebugChannel.update() | !init_done ) {
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighInitDebugChannel.m_LpsSaInitTbl.AppNumber);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighInitDebugChannel.m_LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.CalStat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighInitDebugChannel.m_LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.Calwt);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighInitDebugChannel.m_LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.CalAdjust);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighInitDebugChannel.m_LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.ZeroWeight);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighInitDebugChannel.m_LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.StartOfWeigh);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighInitDebugChannel.m_LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.TiltComp.TiltCompGainScalar);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighInitDebugChannel.m_LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.DigConfig.DigTargetWt);

    	static int m_lpsSaWeighInitDebugChannel_counter=0;
    	db.update( ((index << 16) |  255 ), m_lpsSaWeighInitDebugChannel_counter++);
    }
    index++; offset=0;

    if ( m_lpsSaWeighTxChannel.update() | !init_done ) {
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighTxChannel.DigStat);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighTxChannel.CalStat);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighTxChannel.DumpStat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighTxChannel.BestBktWtInTonnes);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighTxChannel.ZeroNotifyStat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighTxChannel.PayloadCalcMeth);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighTxChannel.LiftCylVel.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighTxChannel.LiftCylVel.MilliPerSec);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighTxChannel.WeighRange.WeighRangeBottom);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighTxChannel.WeighRange.WeighRangeSize);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaWeighTxChannel.LiftCylExt.Stat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaWeighTxChannel.LiftCylExt.Val);

    	static int m_lpsSaWeighTxChannel_counter=0;
    	db.update( ((index << 16) |  255 ), m_lpsSaWeighTxChannel_counter++);
    }
    index++; offset=0;

    if ( m_lpsSaJobMgrTxChannel.update() | !init_done ) {
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrTxChannel.PassCount);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrTxChannel.TargetWeight);
    	db.update( ((index << 16) |  offset++ ), (float)m_lpsSaJobMgrTxChannel.TruckWeight);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrTxChannel.MaterialID);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrTxChannel.ManualTipOffState);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrTxChannel.TipOffTriggerType);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrTxChannel.TipOffState);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrTxChannel.OperationMode);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrTxChannel.StandbyState);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrTxChannel.ClearMinusOneEnableStat);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrTxChannel.DispBestBktWt.Val);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrTxChannel.DispBestBktWt.Stat);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrTxChannel.TipOffStateCfg);

    	static int m_lpsSaJobMgrTxChannel_counter=0;
    	db.update( ((index << 16) |  255 ), m_lpsSaJobMgrTxChannel_counter++);
    }
    index++; offset=0;

    if ( m_pwmInputChannels.update() | !init_done ) {
    	db.update( ((index << 16) |  offset++ ), (int)m_pwmInputChannels.PwmData.ActualTimeUs);
    	db.update( ((index << 16) |  offset++ ), m_pwmInputChannels.PwmData.ExecTime);
    	db.update( ((index << 16) |  offset++ ), m_pwmInputChannels.PwmData.DiffTime);
    	db.update( ((index << 16) |  offset++ ), m_pwmInputChannels.PwmData.Exp);

    	db.update( ((index << 16) |  offset++ ), m_pwmInputChannels.PwmData.Width[0]);
    	db.update( ((index << 16) |  offset++ ), m_pwmInputChannels.PwmData.Width[1]);
    	db.update( ((index << 16) |  offset++ ), m_pwmInputChannels.PwmData.Width[2]);
    	db.update( ((index << 16) |  offset++ ), m_pwmInputChannels.PwmData.Width[3]);
    	db.update( ((index << 16) |  offset++ ), m_pwmInputChannels.PwmData.Period[0]);
    	db.update( ((index << 16) |  offset++ ), m_pwmInputChannels.PwmData.Period[1]);
    	db.update( ((index << 16) |  offset++ ), m_pwmInputChannels.PwmData.Period[2]);
    	db.update( ((index << 16) |  offset++ ), m_pwmInputChannels.PwmData.Period[3]);

    	static int m_pwmInputChannels_counter=0;
    	db.update( ((index << 16) |  255 ), m_pwmInputChannels_counter++);
    }
    index++; offset=0;

    if ( m_machine.update() | !init_done ) {
		db.update( ((index << 16) |  offset++ ), m_machine.payload_calc_method);
		db.update( ((index << 16) |  offset++ ), m_machine.hydarulic_oil_temp);
		db.update( ((index << 16) |  offset++ ), m_machine.bucket_payload);

		static int m_machine_counter=0;
    	db.update( ((index << 16) |  255 ), m_machine_counter++);
    }
    index++; offset=0;

    if ( m_lpsSaJobMgrReqstChannel.update() | !init_done ) {
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.ZeroReqst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.MinusOneReqst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.ClearReqst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.StoreReqst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.StandByActReqst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.StandByDeactReqst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.TruckPileTipOffToggleReqst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.ManualTipOffActReqst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.ManualTipOffDeactReqst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.TipOffTrigger.ReqstFlag);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrReqstChannel.TipOffTrigger.Type);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.TipOffState.ReqstFlag);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrReqstChannel.TipOffState.State);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.ReWeighReqst);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.TargetWeightReqst.ReqstFlag);
    	db.update( ((index << 16) |  offset++ ), m_lpsSaJobMgrReqstChannel.TargetWeightReqst.TargetWeightVal);

    	static int m_lpsSaJobMgrReqstChannel_counter=0;
    	db.update( ((index << 16) |  255 ), m_lpsSaJobMgrReqstChannel_counter++);
    }
    index++; offset=0;

    if ( m_lpsSaJobMgrRespChannel.update() | !init_done ) {
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.ZeroResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.MinusOneResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.ClearResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.StoreResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.StandByActResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.StandByDeActResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.TipOffTruckPileToggleResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.TipOffActResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.TipOffDeactResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.ReWeighResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.TargetWeightResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.TipOffTriggerTypeResp);
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrRespChannel.TipOffStateResp);

    	static int m_lpsSaJobMgrRespChannel_counter=0;
    	db.update( ((index << 16) |  255 ), m_lpsSaJobMgrRespChannel_counter++);
    }
    index++; offset=0;

    if ( m_lpsSaJobMgrDebugChannel.update() | !init_done ) {
    	db.update( ((index << 16) |  offset++ ), (int)m_lpsSaJobMgrDebugChannel.CurrentState);

    	static int m_lpsSaJobMgrDebugChannel_counter=0;
    	db.update( ((index << 16) |  255 ), m_lpsSaJobMgrDebugChannel_counter++);
    }
    index++; offset=0;

    if ( m_switchInputScs.update() | !init_done ) {
        // read store button press
    	db.update( ((index << 16) |  offset++ ), m_switchInputScs.get_STG_value(3));

    	static int m_switchInputScs_counter=0;
    	db.update( ((index << 16) |  255 ), m_switchInputScs_counter++);
    }

    index++; offset=0;
    if ( m_lpsSaNvmDataChannel.update() || !init_done )
    {
       // The expression below expands into a for-loop to DB_PUSH: raise_slow_empty_lift_heights[0], raise_slow_empty_lift_heights[1], ... , raise_slow_empty_lift_heights[10]
       DB_PUSH_ARRAY(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.raise_slow_empty_lift_heights, 11)

       DB_PUSH_ARRAY(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.raise_slow_empty_pressures, 11)
       DB_PUSH_ARRAY(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.lower_slow_empty_lift_heights, 11)
       DB_PUSH_ARRAY(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.lower_slow_empty_pressures, 11)
       DB_PUSH_ARRAY(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.raise_slow_full_lift_heights, 11)
       DB_PUSH_ARRAY(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.raise_slow_full_pressures, 11)
       DB_PUSH_ARRAY(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.lower_slow_full_lift_heights, 11)
       DB_PUSH_ARRAY(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.lower_slow_full_pressures, 11)
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.raise_speed_empty_slow);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.raise_speed_empty_fast);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.raise_fast_delta_p_empty);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.raise_speed_full_slow);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.raise_speed_full_fast);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_main.raise_fast_delta_p_full);

       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.lift_full_lower_DC_inf_value);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.lift_full_raise_DC_inf_value);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.tilt_full_dump_DC_inf_value);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.tilt_full_rack_DC_inf_value);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.pcs_vel_slope);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.pcs_cal_weight);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.zero_weight);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.cal_adjust);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.temp_slope);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.empty_temp);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.full_temp);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.empty_bucket_weight_est);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.cal_adjust_temp);
       DB_PUSH(m_lpsSaNvmDataChannel.lps_sa_nvm_calibration_data_debug.hyd_oil_type_index);

       static int m_lpsSaNvmDataChannel_counter=0;
       db.update( ((index << 16) |  255 ), m_lpsSaNvmDataChannel_counter++);
    }

    index++; offset=0;
    if ( m_lpsSaNvmOnTheFlyDataChannel.update() || !init_done )
    {
       // Convert all data into 4-byte integers
       typedef uint32_t CommonPushType;

       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.statusFlags.CalInProgress));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.statusFlags.PayloadCalFlag));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.statusFlags.EmptyBktCalDone));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.statusFlags.FullBktCalDone));

       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.curveInfo.HydOilTempMet));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.curveInfo.EnforceRaiseDetent));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.curveInfo.EnforceLowerDetent));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseFastVelDone));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseSlowFitDone));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseFastFitDone));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.curveInfo.LowerSlowFitDone));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.curveInfo.InternalStep));

       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftHePres_Stat));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftRePres_Stat));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftCylExt_Stat));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.HydOilTemp_Stat));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftCylVel_Stat));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.TiltCylExt_Stat));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.BktAngle_Stat));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftLeverInfo_LeverInfoAvailable));
       DB_PUSH(static_cast<CommonPushType>(m_lpsSaNvmOnTheFlyDataChannel.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftLeverInfo_Faulted));

       static int m_lpsSaNvmOnTheFlyDataChannel_counter=0;
       db.update( ((index << 16) |  255 ), m_lpsSaNvmOnTheFlyDataChannel_counter++);
    }

    //printf ("Db size: %i\n", db.size());

    /* mark init done */
    if (!init_done)
    	init_done = 1;

    return retVal;
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Run "initReadInterface" on all of the scs channels in the structure
  ///
  /// @return true if all interfaces were successfully configured, false if any failed
  ///////////////////////////////////////////////////////////////////////////////
  bool initReadInterface( ConfigSection& cs )
  {
    bool retVal = true;

    if ( !m_lpsSaWeighRegstChannel.initReadInterface("LpsSaWeighReqstChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaWeighRespChannel.initReadInterface("LpsSaWeighRespChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaWeighTxChannel.initReadInterface("LpsSaWeighTxChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaWeighDebugChannel.initReadInterface("LpsSaWeighDebugChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaWeighInitDebugChannel.initReadInterface("LpsSaWeighInitDebugChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaNvmDataChannel.initReadInterface("LpsSaNvmCalDataChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaNvmOnTheFlyDataChannel.initReadInterface("LpsSaNvmCalOnTheFlyDataChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaJobMgrTxChannel.initReadInterface("LpsSaJobMgrTxChannelInput", cs) ) retVal = false;
    if ( !m_pwmInputChannels.initReadInterface("PwmInputChannelsInput", cs) ) retVal = false;
    if ( !m_machine.initReadInterface("MachineInput", cs) ) retVal = false;
    if ( !m_lpsSaJobMgrReqstChannel.initReadInterface("LpsSaJobMgrReqstChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaJobMgrRespChannel.initReadInterface("LpsSaJobMgrRespChannelInput", cs) ) retVal = false;
    if ( !m_lpsSaJobMgrDebugChannel.initReadInterface("LpsSaJobMgrDebugChannelInput", cs) ) retVal = false;
    if ( !m_switchInputScs.initReadInterface("SwitchInputScsInput", cs) ) retVal = false;

    return retVal;
  }

};

#endif /*XCPSCSINPUTS_H_*/
