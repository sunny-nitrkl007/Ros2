#include <iostream>

#include <xcp_server/XCP.h>
#include <xcp_server/XCPServer.h>
#include <ais/log/Logger.h>
#include "xcpServerDb_private.h"

static XCPServer_t * pXCP_;

/*
 * Should probably get some of this from task configuration.
 *  For example, the event period and UDP port should be configurable.
 */
static const XCPServer_Config_t XCPUDPConfig = {
    XCP_XPORT_UDP,  // UDP or CAN
    60000,          // UDP Port
    0,              // Master CAN ID, set MSB of 32 bit to indicate 29 bit ID
    0,              // Slave CAN ID, set MSB of 32 bit to indicate 29 bit ID
    0,              // Broadcast CAN ID, set MSB of 32 bit to indicate 29 bit ID
    10,             // # DAQ lists (0-192)
    1,              // # ODTs per DAQ
    255,            // # ODT entries per ODT, must be < MAX_DTO - 1 and <= 255
    8,              // Max ODT entry size in bytes (1..255, 8 works for most implementations)
    255,            // MAX_CTO (8..255)
    1024,           // MAX_DTO (8..~1500 on UDP)
    2,              // Num Events (MAX_EVENTS)
    {
            { 1, XCP_EVENT_TU_10MS},   // EventID 0, 10 ms
            { 0, 0},                   // EventID 1
            { 0, 0},                   // EventID 2
            { 0, 0}                    // EventID 2
    },
};

/*
 * xcpServerInit()
 */
bool xcpServerDbInit(xcp_server::ParameterDb& db)
{
    bool everything_ok = true;

    LOG_INFO("XCPServe::init");

    pXCP_ = XCPServer_new();
    if (NULL != pXCP_) {
    	if (XCPServer_init(pXCP_, &XCPUDPConfig)) {
    		LOG_DEBUG("- Initialization successful.");

    		// Register the database with the server.
    		db.registerWithServer(pXCP_);

    		LOG_DEBUG("- Database registered.");
    	} else {
    		LOG_FATAL("XCPServer initialization failed.");
            everything_ok = false;
        }
    } else {
        LOG_FATAL("XCPServer creation failed.")
        everything_ok = false;
    }

    return everything_ok;
}


bool xcpServerDbUpdate()
{
	LOG_INFO("XCPExampleServerTask::update");

    // Update the XCP server
    XCPServer_main(pXCP_);
    XCPServer_procEvent(pXCP_, 0);

    return true;
}

void xcpServerDbCleanup()
{
    LOG_INFO("XCPExampleServerTask::cleanup");

    // Cleanup the XCP server.
    if (NULL != pXCP_) {
        XCPServer_cleanup(pXCP_);
        XCPServer_free(pXCP_);
        pXCP_ = NULL;
    }
}

