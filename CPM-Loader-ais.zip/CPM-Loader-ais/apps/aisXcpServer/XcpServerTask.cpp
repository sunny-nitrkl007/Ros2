/**
***************************************************************************
* @file XcpServerTask.cpp
* A simple task to use as an empty starting point
*
* Copyright 2010
*
* National Robotics Engineering Center, Carnegie Mellon University
* 10 40th Street, Pittsburgh, PA 15201
* www.rec.ri.cmu.edu
*
* Control Instructions (who can see this code): NREC Confidential.
* Not for public release unless permission granted by program manager.
*
* Usage Rights (who can use this code): Usage allowed for all NREC
* programs with permissions from author and program manager.
*
* This notice must appear in all copies of this file and its derivatives.
*
* Created under Program: ACRS
*
* History of Significant Contributions (don't put commit logs here):
* 2010-10-22 cbaker@rec.ri.cmu.edu  Created file.
***************************************************************************
*/


#include "XcpServerTask.h"
#include <unistd.h>
#include <ais/interfaces/baseTypes/ChannelInterface.h>
#include <xcp_server/XCPServer.h>
#include "xcpServerDb_private.h"

int huzefa_test = 9;

using namespace task;

XcpScsInputs  XcpServerTask::m_xcpScsInputs = {};

// Tasks are singletons within any one process: this is the singleton accessor
AbstractTaskCore* task::getTaskImplementation(void)
{
    // it is important to realize that the quoted string controls the name of the
    // default configuration file.  In this case, the use of "XcpServerTask" means that
    // there must be a file named "XcpServerTask.rb" in the config directory for this
    // task to successfully start up.
    static XcpServerTask thisTask("XcpServerTask");
    return &thisTask;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Constructs an instance of this class.
///
///////////////////////////////////////////////////////////////////////////////
XcpServerTask::XcpServerTask(const std::string &taskName) :
    Task(taskName)
{
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Destroys this class
///
///////////////////////////////////////////////////////////////////////////////
XcpServerTask::~XcpServerTask()
{
}

bool XcpServerTask::initialize()
{
  LOG_NOTICE("Hello from %s",getTaskName().c_str() );

  ConfigSection cs;
  if ( !getTaskParser().getSection("ScsRxTimeouts", cs) )
  {
	  LOG_FATAL( "Couldn't find ScsRxTimeouts Config Section in rb file" );
	  return false;
  }
  m_xcpScsInputs.initReadInterface( cs );

  xcpServerDbInit(m_xcpScsInputs.db);

  return true; // false causes the application to bail
}

bool XcpServerTask::executive()
{
	LOG_NOTICE("%s: executive  (pid: %d)", getTaskName().c_str(), getpid());

    // this is where you do periodic work
	xcpServerDbUpdate();

	m_xcpScsInputs.update();

    // and then return so you can get message notifications, etc.

    return true; // false again causes the application to bail
}

void XcpServerTask::cleanup()
{
    LOG_NOTICE("%s: cleanup  (pid: %d)", getTaskName().c_str(), getpid());

    // this is where you would clean up your allocated resources (if any)
	xcpServerDbCleanup();

    return; // you can't really fail to "clean up"
}
