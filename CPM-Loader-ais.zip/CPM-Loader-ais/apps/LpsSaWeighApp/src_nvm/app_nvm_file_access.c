/*******************************************************************************
 Copyright 2017 Caterpillar Inc. All rights reserved.
--------------------------------------------------------------------------------
File name: app_nvm_file_access.c

Description:This file contains test code to test the nvm_file feature 
 *******************************************************************************/
#include "app_nvm_globals.h"
#include "app_nvm_file_access.h"
#include <stdio.h>


/*******************************************************************************
Function name: app_nvm_file_write

Description:  
test the nvm_file. 

Parameter Description: 

Return Description:     
    None
 *******************************************************************************/
void app_nvm_file_write(void)
{

    if(NVM_SUCCESS == nvm_block_write(
    		LpsSaWeighMachSpecificCfgNvmBlkHndl,
    		sizeof(LpsSaWeighNvmMachSpecificCfg),
            0,
           (unsigned_8 *)&LpsSaWeighNvmMachSpecificCfg,
            NVM_CURRENT_TASK_PRIORITY))
    {
        printf("\n Machine Config  Data NVM write Success \n");
    }

}

/*******************************************************************************
Function name: app_nvm_zero_weight_file_write

Description:
test the nvm_file.

Parameter Description:

Return Description:
    None
 *******************************************************************************/
void app_nvm_zero_weight_file_write(void)
{

    if(NVM_SUCCESS == nvm_block_write(
    		LpsSaWeighZeroWtNvmBlkHndl,
    		sizeof(LpsSaNvmWeighAppNvmZeroWt),
            0,
           (unsigned_8 *)&LpsSaNvmWeighAppNvmZeroWt,
            NVM_CURRENT_TASK_PRIORITY))
    {
        printf("\n zero weight  NVM write Success \n");
    }

}

/*******************************************************************************
Function name: app_nvm_calibration_file_write

Description:
test the nvm_file.

Parameter Description:

Return Description:
    None
 *******************************************************************************/
void app_nvm_calibration_file_write(void)
{

    if(NVM_SUCCESS == nvm_block_write(
    		LpsSaWeighCalNvmBlkHndl,
    		sizeof(LpsSaWeighNvmCal),
            0,
           (unsigned_8 *)&LpsSaWeighNvmCal,
            NVM_CURRENT_TASK_PRIORITY))
    {
        printf("\n calibration  NVM write Success \n");
    }

}
/*******************************************************************************
Function name: app_nvm_tilt_cal_file_write

Description:
test the nvm_file.

Parameter Description:

Return Description:
    None
 *******************************************************************************/
void app_nvm_tilt_cal_file_write(void)
{

    if(NVM_SUCCESS == nvm_block_write(
    		LpsSaWeighTiltCalNvmBlkHndl,
    		sizeof(LpsSaWeighTiltNvmCal),
            0,
           (unsigned_8 *)&LpsSaWeighTiltNvmCal,
            NVM_CURRENT_TASK_PRIORITY))
    {
        printf("\n calibration TILT NVM write Success \n");
    }

}
/*******************************************************************************
Function name: app_nvm_lift_cal_file_write

Description:
test the nvm_file.

Parameter Description:

Return Description:
    None
 *******************************************************************************/
void app_nvm_lift_cal_file_write(void)
{

    if(NVM_SUCCESS == nvm_block_write(
    		LpsSaWeighLiftCalNvmBlkHndl,
    		sizeof(LpsSaWeighLiftNvmCal),
            0,
           (unsigned_8 *)&LpsSaWeighLiftNvmCal,
            NVM_CURRENT_TASK_PRIORITY))
    {
        printf("\n calibration LIFT NVM write Success \n");
    }

}







/*******************************************************************************
Function name: app_nvm_file_read

Description:
test the nvm_file.

Parameter Description:

Return Description:
    None
 *******************************************************************************/
void app_nvm_file_read(void)
{

}
