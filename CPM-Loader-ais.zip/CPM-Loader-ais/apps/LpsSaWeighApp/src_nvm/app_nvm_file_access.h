/*******************************************************************************
 Copyright 2017 Caterpillar Inc. All rights reserved.
--------------------------------------------------------------------------------
File name: app_nvm_file_access.h

Description:This file contains test code to test the nvm_file feature 
*******************************************************************************/
#ifndef STD_TYPES_H_
#include <std_types.h>
#endif

typedef struct
{
  float  WeighRangeBottom; /* weigh range Bottom in % */
  float  WeighRangeSize;   /* weigh range Size in %   */
  unsigned short int PloadOvrloadWarnEn;
  float  CalWt;
  float  activeSimpleCalFactor;
  float  updatedSimpleCalFactor;	
  float LastPloadWt;
  float LoaderBktPloadTrgtWt;

}LpsSaWeighNvmMachSpecificCfg_t;

typedef struct
{
	unsigned short    CalNvmBlkVerNo;
	unsigned short    CalStat; //steps_complete renamed to CalStat.
	float       SlowRaiseEmptyBktLiftHt[11];
	float       SlowRaiseEmptyBktLiftPres[11];
	float       SlowRaiseFullBktLiftHt[11];
	float       SlowRaiseFullBktLiftPres[11];
	float       SlowLowerEmptyBktLiftHt[11];
	float       SlowLowerEmptyBktLiftPres[11];
	float       SlowLowerFullBktLiftHt[11];
	float       SlowLowerFullBktLiftPres[11];
	float       FastRaiseEmptyBktDeltaPres;
	float       FastRaiseFullBktDeltaPres;
	float       EmptyBktSlowRaiseSpd;
	float       EmptyBktFastRaiseSpd;
	float       FullBktSlowRaiseSpd;
	float       FullBktFastRaiseSpd;
	float       Calwt;
	unsigned int	  ShmEmptyMain; //use these vars.
	unsigned int      ShmFullMain;
	/* hydraulic oil temps for empty and full calibration curves */
    float 	   EmptyTemp;
    float 	   FullTemp;
	float 	   EmptyBucketWeightEst;
	unsigned int	   LifeTimeTotalPassCount;
	float       LifeTimeTotalPayloadWeight;
	float       CalAdjust;
	float       ZeroWeight;
	float	   StartOfWeigh;
	float	   EndOfWeigh;
	float	   LoaderBktPayldTrgtWt;
	unsigned int    Reserved[42];

} LpsSaCalNvmTbl_t;

typedef struct
{
	float 		tilt_full_rack_dc;
	float 		tilt_full_dump_dc;
	unsigned short    tilt_cal_stat; //steps_complete renamed to CalStat.
} LpsSaTiltCalNvmTbl_t;
typedef struct
{
	float 		lift_full_raise_dc;
	float 		lift_full_lower_dc;
	unsigned short    lift_cal_stat; //steps_complete renamed to CalStat.
} LpsSaLiftCalNvmTbl_t;

/* Holds default values for NVM for zero weight */

extern volatile float LpsSaNvmWeighAppDefZeroWt;

/* Holds actual values stored in NVM for zero Weight */

extern volatile float  LpsSaNvmWeighAppNvmZeroWt;

extern volatile boolean OelBootupFlag;
extern volatile boolean LpsSaNvmWeighAppMachSpecificCfgReadFlag;
extern volatile boolean LpsSaNvmWeighAppMachSpecificCfgWriteFlag;

extern volatile boolean LpsSaNvmWeighAppZeroWtReadFlag;
extern volatile boolean LpsSaNvmWeighAppZeroWtWriteFlag;

extern volatile boolean LpsSaNvmWeighAppCalReadFlag;
extern volatile boolean LpsSaNvmWeighAppCalWriteFlag;


extern volatile boolean LpsSaTiltNvmWeighAppCalReadFlag;
extern volatile boolean LpsSaTiltNvmWeighAppCalWriteFlag;

extern volatile boolean LpsSaLiftNvmWeighAppCalReadFlag;
extern volatile boolean LpsSaLiftNvmWeighAppCalWriteFlag;

/* Holds default values for NVM for machine specific configuration */
extern volatile LpsSaWeighNvmMachSpecificCfg_t LpsSaWeighDefMachSpecificCfg;
/* Holds actual values stored in NVM for machine specific configuration */
extern volatile LpsSaWeighNvmMachSpecificCfg_t LpsSaWeighNvmMachSpecificCfg;

/* Holds default values for NVM for cal values */
extern volatile LpsSaCalNvmTbl_t LpsSaWeighDefCal;
/* Holds actual values stored in NVM for cal values */
extern volatile LpsSaCalNvmTbl_t LpsSaWeighNvmCal;


/* Holds default values for NVM for Lift cal values */
extern volatile LpsSaLiftCalNvmTbl_t LpsSaWeighDefLiftNvmCal;
/* Holds actual values stored in NVM for Lift cal values */
extern volatile LpsSaLiftCalNvmTbl_t LpsSaWeighLiftNvmCal;

/* Holds default values for NVM for Tilt cal values */
extern volatile LpsSaTiltCalNvmTbl_t LpsSaWeighDefTiltNvmCal;
/* Holds actual values stored in NVM for Tilt cal values */
extern volatile LpsSaTiltCalNvmTbl_t LpsSaWeighTiltNvmCal;

extern void app_nvm_file_read(void);
extern void app_nvm_file_write(void);
extern void app_nvm_calibration_file_write(void);
extern void app_nvm_tilt_cal_file_write(void);
extern void app_nvm_lift_cal_file_write(void);
