/******************************************************************************************************************
 Copyright 2017 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------------------------------------------
File name: app_nvm_file_init.c

Description:This file contains startup and initialization code for nvm_file
******************************************************************************************************************/

#include "app_nvm_file_init.h"
#include "app_nvm_file_cfg.h"
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/types.h>
#include "app_nvm_file_access.h"


NVM_block_handle_t  LpsSaWeighMachSpecificCfgNvmBlkHndl;
NVM_block_handle_t  LpsSaWeighZeroWtNvmBlkHndl;
NVM_block_handle_t  LpsSaWeighCalNvmBlkHndl;

NVM_block_handle_t  LpsSaWeighTiltCalNvmBlkHndl;
NVM_block_handle_t  LpsSaWeighLiftCalNvmBlkHndl;

/* Holds default values for NVM for machine specific configuration */
volatile LpsSaWeighNvmMachSpecificCfg_t LpsSaWeighDefMachSpecificCfg;
/* Holds actual values stored in NVM for machine specific configuration */
volatile LpsSaWeighNvmMachSpecificCfg_t LpsSaWeighNvmMachSpecificCfg;


/* Holds default values for NVM for zero weight */
volatile float LpsSaNvmWeighAppDefZeroWt = 0.0 ;
/* Holds actual values stored in NVM for zero weight  */
volatile float LpsSaNvmWeighAppNvmZeroWt;

volatile LpsSaCalNvmTbl_t LpsSaWeighDefCal = {0};

/* Holds actual values stored in NVM for cal values */
 volatile LpsSaCalNvmTbl_t LpsSaWeighNvmCal;

 volatile LpsSaLiftCalNvmTbl_t LpsSaWeighDefLiftNvmCal = {71,14};

 /* Holds actual values stored in NVM for LIFT cal values */
 volatile LpsSaLiftCalNvmTbl_t LpsSaWeighLiftNvmCal;

 volatile LpsSaTiltCalNvmTbl_t LpsSaWeighDefTiltNvmCal = {68,29};

  /* Holds actual values stored in NVM for Tilt cal values */
 volatile LpsSaTiltCalNvmTbl_t LpsSaWeighTiltNvmCal;


/*Flag will be set when NVM file is not exist and the flag will be reset
*when the file was created or if the file already exist */

boolean NvmWeighingAppMachSpecificCfgFileCreateFlag=FALSE;
boolean NvmWeighingAppZeroWtFileCreateFlag=FALSE;
boolean NvmWeighingAppCalFileCreateFlag=FALSE;
boolean NvmWeighingAppLiftCalFileCreateFlag=FALSE;
boolean NvmWeighingAppTiltCalFileCreateFlag=FALSE;


static void app_nvm_weighapp_machine_spec_config_file_init();
static void app_nvm_save_zero_weight_values_init();
static void app_nvm_calibration_values_init();
static void app_nvm_tilt_cal_values_init();
static void app_nvm_lift_cal_values_init();
struct stat nvm ={0};

/******************************************************************************************************************
Function name: app_nvm_file_init

Description:  
Intialzie the nvm_file. 

Parameter Description: 
    
Return Description:     
    None
*****************************************************************************************************************/
void app_nvm_file_init(void)
{
	int sys_ret,indx;
	char command[200];
	char id_char[100];
	struct stat nvmfile ={0};
	unsigned int ret;


    LpsSaNvmWeighAppMachSpecificCfgWriteFlag = FALSE;
    LpsSaNvmWeighAppMachSpecificCfgReadFlag  = FALSE;

    LpsSaNvmWeighAppCalWriteFlag = FALSE;
    LpsSaNvmWeighAppCalReadFlag  = FALSE;

    LpsSaLiftNvmWeighAppCalWriteFlag = FALSE;
    LpsSaLiftNvmWeighAppCalReadFlag  = FALSE;
    LpsSaTiltNvmWeighAppCalWriteFlag = FALSE;
    LpsSaTiltNvmWeighAppCalReadFlag  = FALSE;

    strcpy(NvmFilepath, getenv("HOME"));
	strcat(NvmFilepath, "/appdata/CPM/LpsSaWeighApp/nvm");
    strcpy(id_char,"/NvmWeighAppMachSpecificCfg.txt");
    strcpy(NvmFileName, NvmFilepath);
    strcat(NvmFileName, id_char);
    strcpy(command, "mkdir --mode=755 -p ");
    strcat(command, NvmFilepath);

	/* Create location for NVM log, if it doesn't already exist.*/
	if(stat(NvmFilepath, &nvm) == -1)
	{
		sys_ret = system(command);
		(void) sys_ret;
	}


	strcpy(id_char,"/NvmWeighAppZeroWeightValue.txt");
	strcpy(NvmZeroWeightfileName, NvmFilepath);
	strcat(NvmZeroWeightfileName, id_char);

    strcpy(id_char,"/NvmWeighAppCalibrationVal.txt");
    strcpy(NvmCalibrationfileName, NvmFilepath);
    strcat(NvmCalibrationfileName, id_char);


    strcpy(id_char,"/NvmWeighAppLiftCalVal.txt");
    strcpy(NvmLiftCalfileName, NvmFilepath);
    strcat(NvmLiftCalfileName, id_char);


    strcpy(id_char,"/NvmWeighAppTiltCalVal.txt");
    strcpy(NvmTiltCalfileName, NvmFilepath);
    strcat(NvmTiltCalfileName, id_char);

	/*Below file exist check can be removed after CSNS library issues got resolved*/
    /*Check NvmFileName file doesn't already exist.*/
    if(stat(NvmFileName, &nvmfile) == -1)
    {
    	printf("nvm weigh app machine spec is not exist \n");
    	/*Flag will be set when NvmWeighAppCalibPress file is not exist*/
    	NvmWeighingAppMachSpecificCfgFileCreateFlag = TRUE;
    }

    if(stat(NvmZeroWeightfileName, &nvmfile) == -1)
    {
	printf("nvm Zero weight file  not exist \n");
	/*Flag will be set when NvmWeighAppCalibPress file is not exist*/
	NvmWeighingAppZeroWtFileCreateFlag = TRUE;
    }

     if(stat(NvmCalibrationfileName, &nvmfile) == -1)
     {
     	printf("nvm calibration file  not exist \n");
     	/*Flag will be set when NvmWeighAppCalibPress file is not exist*/
     	NvmWeighingAppCalFileCreateFlag = TRUE;
     }


     if(stat(NvmLiftCalfileName, &nvmfile) == -1)
          {
          	printf("LIFT nvm calibration file  not exist \n");
          	/*Flag will be set when NvmWeighAppCalibPress file is not exist*/
          	NvmWeighingAppLiftCalFileCreateFlag = TRUE;
          }
     if(stat(NvmTiltCalfileName, &nvmfile) == -1)
               {
               	printf("TILT nvm calibration file  not exist \n");
               	/*Flag will be set when NvmWeighAppCalibPress file is not exist*/
               	NvmWeighingAppTiltCalFileCreateFlag = TRUE;
               }

    if(NVM_SUCCESS == nvm_file_init(BlockSize))
    {
    	for(indx = 0; indx < BlockSize; indx++)
        {
    		ret = nvm_file_block_cfg(&app_nvm_file_cfg[indx]);

         	if(NVM_SUCCESS == ret)
			{

				printf("nvm_file_block_cfg SUCCESS \n");
				switch(indx)
				{
					case 0:app_nvm_weighapp_machine_spec_config_file_init();
					   break;
					case 1:app_nvm_save_zero_weight_values_init();
					   break;
        						case 2:
        							app_nvm_calibration_values_init();
        						    break;
        						case 3:
									app_nvm_lift_cal_values_init();
									break;
        						case 4:
        							app_nvm_tilt_cal_values_init();
									break;
					default:/*Reset the after the folder was created*/
						break;
				}
			}
            else
            {
                printf("nvm_file_block_cfg  %d failed\n", indx);
            }
        }
    }
    else
    {
        printf("nvm_file_init failed\n");
    }

    return;
}


static void app_nvm_weighapp_machine_spec_config_file_init()
{

	printf("app_nvm_weighapp_data_default_file_init\n");
	unsigned int ret;


	ret = nvm_block_init(
			NVM_BLOCK_CACHED,
			(unsigned_8 *)&LpsSaWeighNvmMachSpecificCfg,
			LPS_WEIGH_MACH_SPECIFIC_CFG_NVID,
			NVM_CURRENT_TASK_PRIORITY,
			&LpsSaWeighMachSpecificCfgNvmBlkHndl);


	if(NVM_SUCCESS == ret)
	{
		/*Below condition can be removed after CSNS library issues got resolved*/
		if(NvmWeighingAppMachSpecificCfgFileCreateFlag ==TRUE)
		{
			/*When the Nvm file is created for first time set the default value*/
			printf("weigh app config  file created");

			/* Assigning default values to machine specific config   due to NVM CRC error */

			LpsSaWeighNvmMachSpecificCfg = LpsSaWeighDefMachSpecificCfg;
			app_nvm_file_write();
		}
		NvmWeighingAppMachSpecificCfgFileCreateFlag = FALSE;
		printf("weigh app config file_init success %d\n");

	}
	else
	{
		/* Assigning default values to machine specific config
		 * due to NVM CRC error */
		LpsSaWeighNvmMachSpecificCfg = LpsSaWeighDefMachSpecificCfg;

		printf("nvm_block_init %d failed\n");

		app_nvm_file_write();
	}

	                LpsSaNvmWeighAppMachSpecificCfgReadFlag = TRUE;
}


static void app_nvm_save_zero_weight_values_init()
{
	printf("app_nvm_save_zero_weight_init\n");

	unsigned int ret;

	ret = nvm_block_init(
		NVM_BLOCK_CACHED,
		(unsigned_8 *)&LpsSaNvmWeighAppNvmZeroWt,
		LPS_WEIGH_NVM_ZERO_WEIGHT_NVID,
		NVM_CURRENT_TASK_PRIORITY,
		&LpsSaWeighZeroWtNvmBlkHndl);

	if(NVM_SUCCESS == ret)
	{
		/*Below condition can be removed after CSNS library issues got resolved*/
		if(NvmWeighingAppZeroWtFileCreateFlag ==TRUE)
		{
			/*When the Nvm file is created for first time set the default value*/
			printf("zero weight file created");

			LpsSaNvmWeighAppNvmZeroWt = LpsSaNvmWeighAppDefZeroWt;
			app_nvm_zero_weight_file_write();
		}
		NvmWeighingAppZeroWtFileCreateFlag = FALSE;
		printf("app_nvm_save_live_values_init success\n");

	}
	else
	{
		LpsSaNvmWeighAppNvmZeroWt = LpsSaNvmWeighAppDefZeroWt;
		printf("app_nvm_save_live_values_init failed");
		app_nvm_zero_weight_file_write();
	}
	printf("Zero weight default   LpsSaNvmWeighAppNvmZeroWt = %f \n ",
			LpsSaNvmWeighAppNvmZeroWt);


	LpsSaNvmWeighAppZeroWtReadFlag = TRUE;

}

static void app_nvm_calibration_values_init()
{
	printf("app_nvm_calibration file_init\n");

		unsigned int ret;

						ret = nvm_block_init(
								NVM_BLOCK_CACHED,
								(unsigned_8 *)&LpsSaWeighNvmCal,
								LPS_WEIGH_NVM_CAL_NVID,
								NVM_CURRENT_TASK_PRIORITY,
								&LpsSaWeighCalNvmBlkHndl);

			                if(NVM_SUCCESS == ret)
			                {
			        			/*Below condition can be removed after CSNS library issues got resolved*/
			        			if(NvmWeighingAppCalFileCreateFlag ==TRUE)
			        			{
			        				/*When the Nvm file is created for first time set the default value*/
			        				printf("cal file created\n");
			        				memcpy(&LpsSaWeighNvmCal,&LpsSaWeighDefCal,sizeof(LpsSaWeighNvmCal));

			        				 printf("\n Calwt 1 %f  %f \n",LpsSaWeighDefCal.Calwt, LpsSaWeighNvmCal.Calwt);
			        				app_nvm_calibration_file_write();

			        			}
			        			NvmWeighingAppCalFileCreateFlag = FALSE;
			        			printf("app_nvm_cal file_init success\n");

			                }
			                else
			                {
			                	memcpy(&LpsSaWeighNvmCal,&LpsSaWeighDefCal,sizeof(LpsSaWeighNvmCal));

			                	printf("app_nvm_cal file init failed");
								 printf("\n Calwt 2 %f  %f \n",LpsSaWeighDefCal.Calwt, LpsSaWeighNvmCal.Calwt);
								app_nvm_calibration_file_write();
							}

			                printf("\n CalNvmBlkVerNo %d CalStat %d FastRaiseEmptyBktDeltaPres %f FastRaiseFullBktDeltaPres %f "
									"EmptyBktSlowRaiseSpd %f EmptyBktFastRaiseSpd %f FullBktSlowRaiseSpd %f FullBktFastRaiseSpd %f "
									"Calwt %f ShmEmptyMain %d ShmFullMain %d EmptyTemp %f FullTemp %f EmptyBucketWeightEst %f "
									"LifeTimeTotalPassCount %d LifeTimeTotalPayloadWeight %f CalAdjust %f ZeroWeight %f"
									"StartOfWeigh %f EndOfWeigh %f LoaderBktPayldTrgtWt %f \n",
							LpsSaWeighNvmCal.CalNvmBlkVerNo,
							LpsSaWeighNvmCal.CalStat,
							LpsSaWeighNvmCal.FastRaiseEmptyBktDeltaPres,
							LpsSaWeighNvmCal.FastRaiseFullBktDeltaPres,
							LpsSaWeighNvmCal.EmptyBktSlowRaiseSpd,
							LpsSaWeighNvmCal.EmptyBktFastRaiseSpd,
							LpsSaWeighNvmCal.FullBktSlowRaiseSpd,
							LpsSaWeighNvmCal.FullBktFastRaiseSpd,
							LpsSaWeighNvmCal.Calwt,
							LpsSaWeighNvmCal.ShmEmptyMain,
							LpsSaWeighNvmCal.ShmFullMain,
							LpsSaWeighNvmCal.EmptyTemp,
							LpsSaWeighNvmCal.FullTemp,
							LpsSaWeighNvmCal.EmptyBucketWeightEst,
							LpsSaWeighNvmCal.LifeTimeTotalPassCount,
							LpsSaWeighNvmCal.LifeTimeTotalPayloadWeight,
							LpsSaWeighNvmCal.CalAdjust,
							LpsSaWeighNvmCal.ZeroWeight,
							LpsSaWeighNvmCal.StartOfWeigh,
							LpsSaWeighNvmCal.EndOfWeigh,
							LpsSaWeighNvmCal.LoaderBktPayldTrgtWt);
				int iCount=0;
				for(iCount=0;iCount<11;iCount++)
				{
					printf("\n SlowRaiseEmptyBktLiftHt[%d] %f"
							"SlowRaiseEmptyBktLiftPres[%d] %f"
							"SlowRaiseFullBktLiftHt[%d] %f"
							"SlowRaiseFullBktLiftPres[%d] %f"
							"SlowLowerEmptyBktLiftHt[%d] %f"
							"SlowLowerEmptyBktLiftPres[%d] %f"
							"SlowLowerFullBktLiftHt[%d] %f"
							"SlowLowerFullBktLiftPres[%d] %f \n ",
							iCount,LpsSaWeighNvmCal.SlowRaiseEmptyBktLiftHt[iCount],
							iCount,LpsSaWeighNvmCal.SlowRaiseEmptyBktLiftPres[iCount],
							iCount,LpsSaWeighNvmCal.SlowRaiseFullBktLiftHt[iCount],
							iCount,LpsSaWeighNvmCal.SlowRaiseFullBktLiftPres[iCount],
							iCount,LpsSaWeighNvmCal.SlowLowerEmptyBktLiftHt[iCount],
							iCount,LpsSaWeighNvmCal.SlowLowerEmptyBktLiftPres[iCount],
							iCount,LpsSaWeighNvmCal.SlowLowerFullBktLiftHt[iCount],
							iCount,LpsSaWeighNvmCal.SlowLowerFullBktLiftPres[iCount]);

				}




			            	LpsSaNvmWeighAppCalReadFlag = TRUE;
}



static void app_nvm_lift_cal_values_init()
{
	printf("app_nvm_lift_cal_values_init\n");

		unsigned int ret;

						ret = nvm_block_init(
								NVM_BLOCK_CACHED,
								(unsigned_8 *)&LpsSaWeighLiftNvmCal,
								LPS_WEIGH_NVM_LIFT_CAL_NVID,
								NVM_CURRENT_TASK_PRIORITY,
								&LpsSaWeighLiftCalNvmBlkHndl);

			                if(NVM_SUCCESS == ret)
			                {
			        			/*Below condition can be removed after CSNS library issues got resolved*/
			        			if(NvmWeighingAppLiftCalFileCreateFlag ==TRUE)
			        			{
			        				/*When the Nvm file is created for first time set the default value*/
			        				printf("lift cal file created\n");
			        				memcpy(&LpsSaWeighLiftNvmCal,&LpsSaWeighDefLiftNvmCal,sizeof(LpsSaWeighLiftNvmCal));

			        				 printf("\n lift_full_lower_dc 1: %d  %d \n",LpsSaWeighDefLiftNvmCal.lift_full_lower_dc, LpsSaWeighLiftNvmCal.lift_full_lower_dc);
			        				 printf("\n lift_full_raise_dc 1: %d  %d \n",LpsSaWeighDefLiftNvmCal.lift_full_raise_dc, LpsSaWeighLiftNvmCal.lift_full_raise_dc);
			        				 app_nvm_lift_cal_file_write();

			        			}
			        			NvmWeighingAppLiftCalFileCreateFlag = FALSE;
			        			printf("LIFT app_nvm_cal file_init success\n");

			                }
			                else
			                {
			                	memcpy(&LpsSaWeighLiftNvmCal,&LpsSaWeighDefLiftNvmCal,sizeof(LpsSaWeighLiftNvmCal));

			                	printf("LIFT app_nvm_cal file init failed");
			                	 printf("\n lift_full_lower_dc 2: %f  %f \n",LpsSaWeighDefLiftNvmCal.lift_full_lower_dc, LpsSaWeighLiftNvmCal.lift_full_lower_dc);
			                	 printf("\n lift_full_raise_dc 2: %f  %f \n",LpsSaWeighDefLiftNvmCal.lift_full_raise_dc, LpsSaWeighLiftNvmCal.lift_full_raise_dc);
			                	 app_nvm_lift_cal_file_write();
							}


			                LpsSaLiftNvmWeighAppCalReadFlag = TRUE;
}

static void app_nvm_tilt_cal_values_init()
{
	printf("app_nvm_tilt_cal_values_init\n");

		unsigned int ret;

						ret = nvm_block_init(
								NVM_BLOCK_CACHED,
								(unsigned_8 *)&LpsSaWeighTiltNvmCal,
								LPS_WEIGH_NVM_TILT_CAL_NVID,
								NVM_CURRENT_TASK_PRIORITY,
								&LpsSaWeighTiltCalNvmBlkHndl);

			                if(NVM_SUCCESS == ret)
			                {
			        			/*Below condition can be removed after CSNS library issues got resolved*/
			        			if(NvmWeighingAppTiltCalFileCreateFlag ==TRUE)
			        			{
			        				/*When the Nvm file is created for first time set the default value*/
			        				printf("tilt cal file created\n");
			        				memcpy(&LpsSaWeighTiltNvmCal,&LpsSaWeighDefTiltNvmCal,sizeof(LpsSaWeighTiltNvmCal));

			        				printf("\n tilt_full_dump_dc 1: %d  %d \n",LpsSaWeighDefTiltNvmCal.tilt_full_dump_dc, LpsSaWeighTiltNvmCal.tilt_full_dump_dc);
			        				printf("\n tilt_full_rack_dc 1: %d  %d \n",LpsSaWeighDefTiltNvmCal.tilt_full_rack_dc, LpsSaWeighTiltNvmCal.tilt_full_rack_dc);
			        				app_nvm_tilt_cal_file_write();

			        			}
			        			NvmWeighingAppTiltCalFileCreateFlag = FALSE;
			        			printf("TILT app_nvm_cal file_init success\n");

			                }
			                else
			                {
			                	memcpy(&LpsSaWeighTiltNvmCal,&LpsSaWeighDefTiltNvmCal,sizeof(LpsSaWeighTiltNvmCal));

								 printf("\n tilt_full_dump_dc 2: %d  %d \n",LpsSaWeighDefTiltNvmCal.tilt_full_dump_dc, LpsSaWeighTiltNvmCal.tilt_full_dump_dc);
								 printf("\n tilt_full_rack_dc 2: %d  %d \n",LpsSaWeighDefTiltNvmCal.tilt_full_rack_dc, LpsSaWeighTiltNvmCal.tilt_full_rack_dc);
								 app_nvm_tilt_cal_file_write();
							}


			                LpsSaTiltNvmWeighAppCalReadFlag = TRUE;
}
