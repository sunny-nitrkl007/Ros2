/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaLinkageCal.cpp
DESCRIPTION:This file provides the update routines for the application software
            for LPS library.
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  _LPS_SA_WEIGHAPP_H_
#include "LpsSaWeighApp.h"
#endif

#define LPS_SA_SENSOR_STATUS_GOOD 0
#define LPS_SA_SENSOR_STATUS_BAD 1

static unsigned_8 lstat_hdlr(   unsigned_8 cmd,
                                cal_last_stat_t *rpt );
static cal_last_stat_t  lstat = { lstat_hdlr };
/*
**  --- Globals ---
*/
CAL_Linkage_Work_t         cal_linkage_workspace;

extern boolean CalNVMReinitFlag;

static float lift_linkage_cal_array[LINKAGE_NUM_CAL_POINTS] =
{
    12.000,
    83.000
};

static float tilt_linkage_cal_array[LINKAGE_NUM_CAL_POINTS] =
{
    11.000,
    74.000
};

/*
**  --- Global Functions ---
*/
CAL_MGR_MR_E LpsSaWeighApp:: LpsSaTiltLinkageSensorCalibration(
											CAL_MGR_MC_E         Cmd,
											unsigned_16	         CalId,
											unsigned_8*	         StepNo,
											unsigned_16*         CalError
											)
{
	static bool validate_success_tilt = FALSE;

	(void)cmc;
	*CalError = 0;

    switch( LpsSaWeighInfoTbl.Calcmd ) {
        /********************/
        /* Control Commands */
        /********************/
        case( CAL_MGR_MC_INIT_LAST_STAT ): {
            /*
            **  This command is sent when the application has requested the
            **  CAL_MGR to enable the calibration from the application with
            **  cal_mgr_enable_cal( CAL_NEUTSETPT_ID ) call.  This command
            **  is not sent during the actual execution of the calibration
            **  through a service tool.
            **  The possible responses are as follows:
            **      OK - the last status report is supported and
            **          the last status report cache has been initialized
            **          correctly.
            **      NOT_OK - the last status resport is required or
            **          the last status report cache has not been initialized
            **          correctly.
            **      NA - Last status report not used (not applicable) and
            **          allow the enabling of the calibration
            */

        	//((CAL_MGR_LStat_t *)cal)->stat = &lstat; - TODO set last cal stat

            /* Default Response */
            return( CAL_MGR_MR_INIT_LAST_STAT_OK );

        }
        case( CAL_MGR_MC_GET_INPUTS ): {
            /*
            **  This "Control" command is intended to be used to acquire the calibration
            **  inputs required by the calibration from the application.  This
            **  is the first command sent on an execution loop.  Validation
            **  checks on the inputs are to be handled within the CAL_ADIAGCHK
            **  command.
            **
            **  The possible responses are as follows:
            **      OK - Inputs were processed/acquired successfully
            */

            /* Get inputs into the workspace */

            return( CAL_MGR_MR_GET_INPUTS_OK );
        }
        case( CAL_MGR_MC_SET_OUTPUTS ): {
            /*
            **  This "Control" command is intended to be used to send the calibration
            **  outputs of the calibration to the application.  Validation
            **  checks on the outputs are to be handled within the CAL_ADIAGCHK
            **  command.  This is the last command sent on an execution loop.
            **
            **  The possible responses are as follows:
            **      OK - Outputs were processed successfully
            */

            return( CAL_MGR_MR_SET_OUTPUTS_OK );
        }

        case( CAL_MGR_MC_INITIALIZE ): {

            /*
            **  This "Control" command is sent when the user has selected the calibration
            **  from the service tool assuming cal_mgr_enable_cal( CAL_NEUTSETPT_ID )
            **  was successful.  This "Control" command is a high-level intialization of the
            **  calibration intended to be used to notify the application that the
            **  calibration has begun, presenting an opportunity to begin actively
            **  overriding certain components of the application or initializing
            **  qualified read parameters.  It follows GET_INPUTS command on an
            **  execution loop until response is OK.
            **
            **  The possible responses are as follows:
            **      OK - initialization was completed successfully, after returning
            **          OK, the CAL_MGR will wait for the user to start the calibration
            **          by pressing the (Next>>) button the first time.  This
            **          command will not get called again until the calibration
            **          has ended its execution.
            **      AGAIN - if initialization requires more than one loop
            **          to complete
            **      NOT_OK - intialization was not completed successfully
            */

        	//cal_linkage_workspace.lift_sensor_status = 0;
        	//cal_linkage_workspace.tilt_sensor_status = 0;
        	//LpsSaWeighNvmCal.CalStat &= ~CAL_LIFT_LINKAGE_MASK;

        	/* Fail calibrations if machine/model is not selected */
        	if(TRUE == LpsSaWeighInfoTbl.MachineModelNotSet)
        	{
        		*CalError = CAL_MACHINE_MODEL_NOT_SET;
        		return CAL_MGR_MR_INITIALIZE_NOT_OK;
        	}

        	return( CAL_MGR_MR_INITIALIZE_OK );
        }
        case( CAL_MGR_MC_ADIAGCHK ): {
            /*
            **  This "Control" command is intended to be used to check active diagnostics
            **  for calibration inputs, outputs and any other high-level
            **  requirements of the calibration.  This "Control" command is sent just prior
            **  to SETUPCHK and FLOW commands only.
            **
            **  The possible responses are as follows:
            **      OK - No "Active Diagnostics" are present that will effect the
            **          execution of the calibration.
            **      NOT_OK - an "Active Diagnostic" is present that will effect the
            **          execution of the calibration.  The generic
            **          CAL_MGR_EW_ACTIVE_DIAGNOSTIC will be automatically issued by
            **          CAL_MGR if NOT_OK is the response.  Further
            **          cal_add_error() may be required here for the calibration.
            **          QUIT or TERMINATE command will be sent on the next
            **          execution loop.  SETUPCHK and FLOW commands will not
            **          be called on this execution loop due to this response.
            */
        	if ((LPS_CYL_EXT_STAT_BAD == weighUpdtTbl.LiftCylExt.Stat) ||
        		(LPS_CYL_EXT_STAT_BAD == weighUpdtTbl.TiltCylExt.Stat))
			{
				*CalError = CAL_LINKAGE_ABORTED_BY_ECM;
                return( CAL_MGR_MR_ADIAGCHK_NOT_OK );
            }
			else
			{
            	return( CAL_MGR_MR_ADIAGCHK_OK );
			}
        }
        case( CAL_MGR_MC_SETUPCHK ): {
            /*
            **  This "Control" command is intended to be used to check the setup conditions
            **  for the calibration prior to moving to the FLOW portion of the
            **  calibration.  This "Control" command follows the ADIAGCHK command when response
            **  from ADIAGCHK is OK.
            **
            **  The possible responses are as follows:
            **      OK - All setup conditions have been met and CAL_MGR_STEPNUMBER(cmw)
            **          has been set to the first FLOW step number.
            **      NOT_OK - All setup conditions have not been met and
            **          LpsSaWeighInfoTbl.stepNo has been set to the step number
            **          associated with the setup condition not being met.
            */
			LpsSaWeighInfoTbl.stepNo = CAL_TILT_LINKAGE_SETUP_COMPLETE;
			return (CAL_MGR_MR_SETUPCHK_OK);
        }
        case( CAL_MGR_MC_INIT_FLOW ): {
        	LOG_NOTICE("\n CAL_MGR_MC_INIT_FLOW \n");
            /*
            **  This "Control" command is intended to be used to intialize the FLOW portion
            **  of a calibration.  This "Control" command is a lower-level intialization of the
            **  flow portion of the calibration which can be used to notify the
            **  application that the calibration flow portion has begun,
            **  presenting an opportunity to begin actively overriding additional
            **  components of the application.  It may also be used to set
            **  LpsSaWeighInfoTbl.stepNo, in the event that calibration has been
            **  "restarted internally", (i.e. not "restarted by service tool").
            **
            **  The possible responses are as follows:
            **      OK - Calibration Flow parameters have been initialized.
            */
            LpsSaWeighInfoTbl.stepNo = CAL_TILT_LINKAGE_FULL_RACK;


            /* Default with OK */
            return( CAL_MGR_MR_INIT_FLOW_OK );
        }
        case( CAL_MGR_MC_FLOW ): {
            /*
            **  This "Control" command is intended to be used to check conditions required
            **  by a FLOW step.
            **
            **  The possible responses are as follows:
            **      OK      - Flow conditions are valid, FLOW commands will follow.
            **      RESTART - A Flow condition is not valid and a "restart by calibration"
            **          is required.  The FLOW step may be recorded internally
            **          for "return to FLOW" capability.
            **      ABORT   - A Flow condition is not valid and will require
            **          the calibration to TERMINATE.  cal_add_error()'s may
            **          be called here to explicitly provide which Flow condition
            **          was not met.
            **
            */
            register unsigned_16 warning = 0;

            /* Check flow conditions for each flow step */
            if( warning ) return( CAL_MGR_MR_FLOW_RESTART );

            /* Else */
            return( CAL_MGR_MR_FLOW_OK );
        }
        case( CAL_MGR_MC_RESTART_FLOW ): {
            /*
            **  This "Control" command is intended to be used to internally restart a
            **  calibration for some reason.  ADIAGCHK command is not sent during
            **  a restart.  LpsSaWeighInfoTbl.stepNo has been set to 1 on restart.
            **
            **  The possible responses are as follows:
            **      OK      - The internal restarting process has completed, optional
            **          setting of LpsSaWeighInfoTbl.stepNo can be applied to start
            **          at a specific step number
            **      AGAIN   - The internal restarting process requires more than one
            **          execution loop.
            */
            return( CAL_MGR_MR_RESTART_FLOW_OK );

        }
        case( CAL_MGR_MC_STOP ): {
            /*
            **  This "Control" command is sent to notify the calibration that the calibration
            **  has been requested to abort (internally or by the user) before
            **  the calibration has "started" (meaning the user has yet to press
            **  the Next>> button to start the calibration)
            **  The application may choose to set the status of the calibration to
            **  NOT_CALIBRATED since the calibration was stopped.
            **
            **  The possible responses are as follows:
            **      OK          - No active overrides are possible prior to "started"
            **      EXIT_REQ    - It is possible that active overrides exist,
            **          most likely generated INITIALIZE command. The EXIT_FLOW
            **          command will follow with this response.
            */

            return( CAL_MGR_MR_STOP_EXIT_REQ );
        }
        case( CAL_MGR_MC_QUIT ): {
            /*
            **  This "Control" command is sent to notify the calibration that the calibration
            **  has been requested to abort (internally or by the user) before
            **  the calibration setup conditions have been met (prior to executing
            **  the flow portion of the calibration, TERMINATE sent on restarts);
            **  The application may choose to set the status of the calibration to
            **  NOT_CALIBRATED since the calibration was quit.
            **
            **  The possible responses are as follows:
            **      OK          - No active overrides are possible prior to the
            **          INIT_FLOW command.
            **      EXIT_REQ    - It is possible that active overrides exist,
            **          most likely generated INITIALIZE command.
            **          The EXIT_FLOW command will follow with this response.
            */

            return( CAL_MGR_MR_QUIT_EXIT_REQ );
        }
        case( CAL_MGR_MC_TERMINATE ): {
            /*
            **  This "Control" command is sent to notify the calibration that the calibration
            **  has been requested to abort (internally or by the user) after the
            **  INIT_FLOW command had been sent at least once.  The application may
            **  choose to set the status of the calibration to NOT_CALIBRATED since
            **  the calibration was terminated.
            **
            **  The possible responses are as follows:
            **      OK          - No active overrides are possible
            **      EXIT_REQ    - It is possible that active overrides exist,
            **          most likely generated by INITIALIZE, INIT_FLOW, and/or FLOW
            **          commands. The EXIT_FLOW command will follow with this
            **          response.
            */

            return( CAL_MGR_MR_TERMINATE_EXIT_REQ );
        }
        case( CAL_MGR_MC_EXIT_FLOW ): {
            /*
            **  This "Control" command is intended to be used to check if any calibration
            **  overrides are active that require a cleanup of more than one
            **  execution loop.  This command will be called at most once per
            **  calibration execution.
            **
            **  The possible responses are as follows:
            **      DONE        - No cleanup is required (no active overrides exist)
            **      CLEANUP_REQ - Cleanup is required to clear overrides.
            **          CLEANUP command will follow with this response.
            */

            return( CAL_MGR_MR_EXIT_FLOW_CLEANUP_REQ );
        }
        case( CAL_MGR_MC_CLEANUP ): {
            /*
            **  This "Control" command is sent to notify the calibration that the calibration
            **  has been requested to abort (internally or by the user).  The
            **  CLEANUP_REQ response to the EXIT_FLOW command indicates that an
            **  active overrides exist that will possibly take more than one
            **  execution loop to clear.  The cleanup procedure is executed within
            **  this command.
            **
            **  The possible responses are as follows:
            **      DONE        - No active overrides exist
            **      NOT_DONE    - More execution loops are required to clear
            **          active overrides.
            */
            /* Else, default with DONE */
            return( CAL_MGR_MR_CLEANUP_DONE );
        }

        /*****************/
        /* Flow Commands */
        /*****************/
        case( CAL_MGR_MC_READY ): {
            /*
            **  This "Flow" command is sent to evaluate whether or not the
            **  calibration is "READY" to collect a sample.  The sample/s that
            **  is/are to be collected is/are most likely associated with a
            **  flow step number (LpsSaWeighInfoTbl.stepNo).
            **
            **  The possible responses are as follows:
            **      YES - The calibration is ready to begin the sampling
            **          process associated with the current flow step.
            **      NO  - The calibration is not ready to begine the sampling
            **          process associated with the current flow step.
            */
            /* Else, default with YES */
            return( CAL_MGR_MR_READY_YES );

        }
        case( CAL_MGR_MC_SAMPLE_INIT ): {
            /*
            **  This "Flow" command is sent to intialize the sampling process
            **  associated with the current step number (LpsSaWeighInfoTbl.stepNo).
            **
            **  The possible responses are as follows:
            **      OK  - Initialization for the sampling process associated with
            **          the current flow step (LpsSaWeighInfoTbl.stepNo) is complete.
            */
            LpsSaWeighInfoTbl.stepNo = CAL_TILT_LINKAGE_FULL_RACK;
            LOG_NOTICE("\n CAL_MGR_MC_SAMPLE_INIT \n");
            /* Default with OK */
            return( CAL_MGR_MR_SAMPLE_INIT_OK );
        }
        case( CAL_MGR_MC_SAMPLE ): {
        	LOG_NOTICE("\n CAL_MGR_MC_SAMPLE \n");
            /*
            **  This "Flow" command is sent during the execution of the sampling process
            **  associated with the current step number (LpsSaWeighInfoTbl.stepNo).
            **
            **  The possible responses are as follows:
            **      PT_COLLECTED - Sample point/s was/were collected that require
            **          validation after RESET
            **      WAIT - Sample Process is executing and requires another
            **          execution loop.
            **      SKIP - Sampling process has completed, no validation is required
            **          following RESET.
            */
           unsigned_8 done = FALSE;

            if( CAL_MGR_KEY_CONT )
	            {
                	LOG_NOTICE("\n CAL_MGR_KEY_CONT \n");

	                switch(   LpsSaWeighInfoTbl.stepNo )
	                {
	                	LOG_NOTICE("\n CAL_MGR_KEY_CONT:STEPNO %d \n", LpsSaWeighInfoTbl.stepNo);
	                    case( CAL_TILT_LINKAGE_FULL_RACK ): {
	                    	LOG_NOTICE("\n CAL_TILT_LINKAGE_FULL_RACK \n");
	                        cal_linkage_workspace.tilt_full_rack_dc = WeighPidTbl.TiltCylDc;
	                        LpsSaWeighInfoTbl.stepNo = CAL_TILT_LINKAGE_FULL_LOWER;
	                        break;
	                    }
	                    case( CAL_TILT_LINKAGE_FULL_LOWER ):
	                    {
							if (LPS_SA_SENSOR_STATUS_GOOD == cal_linkage_workspace.lift_sensor_status)
							{
							 	LOG_NOTICE("\n CAL_TILT_LINKAGE_FULL_LOWER \n");
		                        cal_linkage_workspace.lift_full_lower_dc = WeighPidTbl.LiftCylDc;
							}

	                        LpsSaWeighInfoTbl.stepNo = CAL_TILT_LINKAGE_FULL_RAISE;
	                        break;
	                    }
	                    case( CAL_TILT_LINKAGE_FULL_RAISE ):
	                    {
							if (LPS_SA_SENSOR_STATUS_GOOD == cal_linkage_workspace.lift_sensor_status)
							{
							 	LOG_NOTICE("\n CAL_TILT_LINKAGE_FULL_RAISE \n");
		                        cal_linkage_workspace.lift_full_raise_dc = WeighPidTbl.LiftCylDc;
							}
                     	    LpsSaWeighInfoTbl.stepNo =CAL_TILT_LINKAGE_FULL_DUMP;
	                        break;
	                    }
	                    case( CAL_TILT_LINKAGE_FULL_DUMP ):
	                    {
	                     	LOG_NOTICE("\n CAL_TILT_LINKAGE_FULL_DUMP \n");
	                        cal_linkage_workspace.tilt_full_dump_dc = WeighPidTbl.TiltCylDc;
	                    	printf("CAL_TILT_LINKAGE_FULL_DUMP -done \n");
	                        done = TRUE;
	                        break;
	                    }
	                    default:
	                    {
	                     	LOG_NOTICE("\n DEF-CAL_TILT_LINKAGE_FULL_RACK \n");
	                        LpsSaWeighInfoTbl.stepNo = CAL_TILT_LINKAGE_FULL_RACK;
	                        break;
	                    }
	                }
	            }

            return( done ? CAL_MGR_MR_SAMPLE_PT_COLLECTED : CAL_MGR_MR_SAMPLE_WAIT );
        }
        case( CAL_MGR_MC_RESET_INIT ): {
            /*
            **  This "Flow" command is sent to provide the calibration an
            **  opportunity to intialize any RESET parameters used within the
            **  RESET process after execution of the sampling process
            **  associated with the current step number (LpsSaWeighInfoTbl.stepNo).
            **
            **  The possible responses are as follows:
            **      OK - Initialization of RESET parameters is complete and a
            **          RESET process exists and should be executed
            **      NONE - No RESET process exists for the current step number.
            */

            return( CAL_MGR_MR_RESET_INIT_NONE );

        }
        case( CAL_MGR_MC_RESET ): {
            /*
            **  This "Flow" command is sent during the execution of the RESET process
            **  associated with the current step number (LpsSaWeighInfoTbl.stepNo).
            **
            **  The possible responses are as follows:
            **      DONE - RESET process is complete
            **      NOT_DONE - RESET process requires more execution loops to complete
            */
            return( CAL_MGR_MR_RESET_DONE );
        }
        case( CAL_MGR_MC_VALIDATE ): {
            /*
            **  This "Flow" command is sent to provide the calibration with the
            **  opportunity to validate the sample point/s associated with the
            **  current step number (LpsSaWeighInfoTbl.stepNo).  NOTE: This
            **  "Flow" command will not be sent if the SAMPLE command response is
            **  SKIP.
            **
            **  The possible responses are as follows:
            **      OK      - Sample Point/s is/are valid
            **      NOT_OK  - Sample Point/s is/are not valid.  cal_add_error()
            **          the reason for NOT_OK response.  The calibration will
            **          TERMINATE on next execution loop.
            **      RESTART - Sample Point/s is/are not valid.  cal_add_warning()
            **          the reason for RESTART response.  The calibration
            **          will RESTART_FLOW on next execution loop.
            */

        	if(cal_linkage_workspace.tilt_full_dump_dc > cal_linkage_workspace.tilt_full_rack_dc)
        	{
        		validate_success_tilt = FALSE;
        	}
        	else
        	{
        		validate_success_tilt = TRUE;
        	}

        	if(TRUE == validate_success_tilt)
        	{
        		printf("\nTILT CAL_MGR_MR_VALIDATE_OK\n");
        		return( CAL_MGR_MR_VALIDATE_OK );
        	}
        	else
        	{
        		*CalError =0x0103;
        		printf("\nTILT CAL_MGR_MR_VALIDATE_NOT_OK Tilt_full_Dump:%d     Tilt_full_rack:%d\n", cal_linkage_workspace.tilt_full_dump_dc,  cal_linkage_workspace.tilt_full_rack_dc);
        		return( CAL_MGR_MR_VALIDATE_NOT_OK );
        	}

        }
        case( CAL_MGR_MC_NEXT_PT ): {
            /*
            **  This "Flow" command is sent to provide the calibration with the
            **  opportunity to change the current step number
            **  (LpsSaWeighInfoTbl.stepNo) to the next step number.
            **
            **  The possible responses are as follows:
            **      MORE        - More Sample Point/s to collect
            **      NO_MORE     - No more Sample Point/s to collect
            */
            return( CAL_MGR_MR_NEXT_PT_NO_MORE );
        }
        case( CAL_MGR_MC_SUCCESS ): {


            /*
            **  This "Flow" command is sent following a NO_MORE response to the
            **  NEXT_PT command.  This "Flow" Command should be used to save the
            **  sampled points collected.  The status of the calibration points
            **  should be noted as CALIBRATED as appropriate just prior to a
            **  SAVED response.
            **
            **  The possible responses are as follows:
            **      SAVED   - Sampled Points (Data) were saved successfully
            **      WAIT    - Sampled Points (Data) are being saved or the
            **          SAVING process is waiting for User input (i.e. revert to
            **          previous, revert to default, save current, etc.)
            */

            /*** Save the data to NVM ***/

            /* Set the calibration values (at the same time, save to nvm) */
			if (validate_success_tilt)
			{
				tilt_linkage_cal_array[0] = cal_linkage_workspace.tilt_full_dump_dc;
				tilt_linkage_cal_array[1] = cal_linkage_workspace.tilt_full_rack_dc;
			}

        	printf("\n tilt_linkage_cal_array[0] %f tilt_linkage_cal_array[1] %f \n",
        			tilt_linkage_cal_array[0], tilt_linkage_cal_array[1]);

        	LpsSaWeighTiltNvmCal.tilt_full_dump_dc = tilt_linkage_cal_array[0];
        	LpsSaWeighTiltNvmCal.tilt_full_rack_dc = tilt_linkage_cal_array[1];

        	LpsSaWeighTiltNvmCal.tilt_cal_stat |= CAL_TILT_LINKAGE_MASK;

        	LpsSaTiltNvmWeighAppCalWriteFlag = TRUE;

        	/*Enable Reinit flag*/
        	CalNVMReinitFlag =TRUE;

            return( CAL_MGR_MR_SUCCESS_SAVED );

        }
        case( CAL_MGR_MC_DONE ): {
            /*
            **  This "Flow" command is sent following a SAVED response to the
            **  SUCCESS command.  The EXIT_FLOW Command will follow on the next
            **  execution loop.
            **
            **  The possible responses are as follows:
            **      OK      - no more sets of Sampled Points (Data) to be
            **          collected.
            **      RESTART - (Advanced Option) another set of Sampled Points
            **          (Data) are to be collected.
            */
        	printf("\n CAL_MGR_MC_DONE \n");
            /* Default with OK */
            return( CAL_MGR_MR_DONE_OK );
        }
        case( CAL_MGR_MC_FAIL ): {
        	printf("\n CAL_MGR_MC_FAIL \n");

            /*
            **  This "Flow" command is sent following a NOT_OK response to the
            **  VALIDATE command.  The TERMINATE command will follow on the next
            **  execution loop.
            **
            **  The possible responses are as follows:
            **      OK      - Set of Sampled Points (Data) were noted as being
            **          NOT_CALIBRATED
            */

            /* Default Response */
            return( CAL_MGR_MR_FAIL_OK );
        }

        default:
           // Do nothing for now
           break;
    }

    /* This should never happen */
    return( CAL_MGR_MR_NOT_SUPPORTED );

}


CAL_MGR_MR_E LpsSaWeighApp:: LpsSaLiftLinkageSensorCalibration(
									CAL_MGR_MC_E         Cmd,
									unsigned_16	         CalId,
									unsigned_8*	         StepNo,
									unsigned_16*         CalError
									)
{
	static bool validate_success_lift = FALSE;

	(void)cmc;
	*CalError = 0;

    switch( LpsSaWeighInfoTbl.Calcmd ) {
        /********************/
        /* Control Commands */
        /********************/
        case( CAL_MGR_MC_INIT_LAST_STAT ): {
            /*
            **  This command is sent when the application has requested the
            **  CAL_MGR to enable the calibration from the application with
            **  cal_mgr_enable_cal( CAL_NEUTSETPT_ID ) call.  This command
            **  is not sent during the actual execution of the calibration
            **  through a service tool.
            **  The possible responses are as follows:
            **      OK - the last status report is supported and
            **          the last status report cache has been initialized
            **          correctly.
            **      NOT_OK - the last status resport is required or
            **          the last status report cache has not been initialized
            **          correctly.
            **      NA - Last status report not used (not applicable) and
            **          allow the enabling of the calibration
            */

            /* Default Response */
            return( CAL_MGR_MR_INIT_LAST_STAT_OK );

        }
        case( CAL_MGR_MC_GET_INPUTS ): {
            /*
            **  This "Control" command is intended to be used to acquire the calibration
            **  inputs required by the calibration from the application.  This
            **  is the first command sent on an execution loop.  Validation
            **  checks on the inputs are to be handled within the CAL_ADIAGCHK
            **  command.
            **
            **  The possible responses are as follows:
            **      OK - Inputs were processed/acquired successfully
            */

            /* Get inputs into the workspace */
             cal_linkage_workspace.lift_sensor_status = 0;
        	 cal_linkage_workspace.tilt_sensor_status = 0;

            return( CAL_MGR_MR_GET_INPUTS_OK );
        }
        case( CAL_MGR_MC_SET_OUTPUTS ): {
            /*
            **  This "Control" command is intended to be used to send the calibration
            **  outputs of the calibration to the application.  Validation
            **  checks on the outputs are to be handled within the CAL_ADIAGCHK
            **  command.  This is the last command sent on an execution loop.
            **
            **  The possible responses are as follows:
            **      OK - Outputs were processed successfully
            */

            return( CAL_MGR_MR_SET_OUTPUTS_OK );
        }

        case( CAL_MGR_MC_INITIALIZE ): {

            /*
            **  This "Control" command is sent when the user has selected the calibration
            **  from the service tool assuming cal_mgr_enable_cal( CAL_NEUTSETPT_ID )
            **  was successful.  This "Control" command is a high-level intialization of the
            **  calibration intended to be used to notify the application that the
            **  calibration has begun, presenting an opportunity to begin actively
            **  overriding certain components of the application or initializing
            **  qualified read parameters.  It follows GET_INPUTS command on an
            **  execution loop until response is OK.
            **
            **  The possible responses are as follows:
            **      OK - initialization was completed successfully, after returning
            **          OK, the CAL_MGR will wait for the user to start the calibration
            **          by pressing the (Next>>) button the first time.  This
            **          command will not get called again until the calibration
            **          has ended its execution.
            **      AGAIN - if initialization requires more than one loop
            **          to complete
            **      NOT_OK - intialization was not completed successfully
            */
        	 //LpsSaWeighNvmCal.CalStat &= ~CAL_TILT_LINKAGE_MASK;

        	/* Fail calibrations if machine/model is not selected */
        	if(TRUE == LpsSaWeighInfoTbl.MachineModelNotSet)
        	{
        		*CalError = CAL_MACHINE_MODEL_NOT_SET;
        		return CAL_MGR_MR_INITIALIZE_NOT_OK;
        	}

        	return( CAL_MGR_MR_INITIALIZE_OK );

        }
        case( CAL_MGR_MC_ADIAGCHK ): {
            /*
            **  This "Control" command is intended to be used to check active diagnostics
            **  for calibration inputs, outputs and any other high-level
            **  requirements of the calibration.  This "Control" command is sent just prior
            **  to SETUPCHK and FLOW commands only.
            **
            **  The possible responses are as follows:
            **      OK - No "Active Diagnostics" are present that will effect the
            **          execution of the calibration.
            **      NOT_OK - an "Active Diagnostic" is present that will effect the
            **          execution of the calibration.  The generic
            **          CAL_MGR_EW_ACTIVE_DIAGNOSTIC will be automatically issued by
            **          CAL_MGR if NOT_OK is the response.  Further
            **          cal_add_error() may be required here for the calibration.
            **          QUIT or TERMINATE command will be sent on the next
            **          execution loop.  SETUPCHK and FLOW commands will not
            **          be called on this execution loop due to this response.
            */
			//unsigned_8 lift_sensor_good = FALSE;

			if ((LPS_CYL_EXT_STAT_BAD == weighUpdtTbl.LiftCylExt.Stat) ||
			    (LPS_CYL_EXT_STAT_BAD == weighUpdtTbl.TiltCylExt.Stat))
			{
				*CalError = CAL_LINKAGE_ABORTED_BY_ECM;
			    return( CAL_MGR_MR_ADIAGCHK_NOT_OK );
			}
			else
			{
				return( CAL_MGR_MR_ADIAGCHK_OK );
			}
        }
        case( CAL_MGR_MC_SETUPCHK ): {
            /*
            **  This "Control" command is intended to be used to check the setup conditions
            **  for the calibration prior to moving to the FLOW portion of the
            **  calibration.  This "Control" command follows the ADIAGCHK command when response
            **  from ADIAGCHK is OK.
            **
            **  The possible responses are as follows:
            **      OK - All setup conditions have been met and CAL_MGR_STEPNUMBER(cmw)
            **          has been set to the first FLOW step number.
            **      NOT_OK - All setup conditions have not been met and
            **          LpsSaWeighInfoTbl.stepNo has been set to the step number
            **          associated with the setup condition not being met.
            */
			LpsSaWeighInfoTbl.stepNo = CAL_LIFT_LINKAGE_SETUP_COMPLETE;
			return (CAL_MGR_MR_SETUPCHK_OK);
        }
        case( CAL_MGR_MC_INIT_FLOW ): {
        	LOG_NOTICE("\n CAL_MGR_MC_INIT_FLOW \n");
            /*
            **  This "Control" command is intended to be used to intialize the FLOW portion
            **  of a calibration.  This "Control" command is a lower-level intialization of the
            **  flow portion of the calibration which can be used to notify the
            **  application that the calibration flow portion has begun,
            **  presenting an opportunity to begin actively overriding additional
            **  components of the application.  It may also be used to set
            **  LpsSaWeighInfoTbl.stepNo, in the event that calibration has been
            **  "restarted internally", (i.e. not "restarted by service tool").
            **
            **  The possible responses are as follows:
            **      OK - Calibration Flow parameters have been initialized.
            */
            LpsSaWeighInfoTbl.stepNo = CAL_LIFT_LINKAGE_FULL_RAISE;


            /* Default with OK */
            return( CAL_MGR_MR_INIT_FLOW_OK );
        }
        case( CAL_MGR_MC_FLOW ): {
            /*
            **  This "Control" command is intended to be used to check conditions required
            **  by a FLOW step.
            **
            **  The possible responses are as follows:
            **      OK      - Flow conditions are valid, FLOW commands will follow.
            **      RESTART - A Flow condition is not valid and a "restart by calibration"
            **          is required.  The FLOW step may be recorded internally
            **          for "return to FLOW" capability.
            **      ABORT   - A Flow condition is not valid and will require
            **          the calibration to TERMINATE.  cal_add_error()'s may
            **          be called here to explicitly provide which Flow condition
            **          was not met.
            **
            */
            register unsigned_16 warning = 0;

            if( warning ) return( CAL_MGR_MR_FLOW_RESTART );

            /* Else */
            return( CAL_MGR_MR_FLOW_OK );


        }
        case( CAL_MGR_MC_RESTART_FLOW ): {
            /*
            **  This "Control" command is intended to be used to internally restart a
            **  calibration for some reason.  ADIAGCHK command is not sent during
            **  a restart.  LpsSaWeighInfoTbl.stepNo has been set to 1 on restart.
            **
            **  The possible responses are as follows:
            **      OK      - The internal restarting process has completed, optional
            **          setting of LpsSaWeighInfoTbl.stepNo can be applied to start
            **          at a specific step number
            **      AGAIN   - The internal restarting process requires more than one
            **          execution loop.
            */
            return( CAL_MGR_MR_RESTART_FLOW_OK );

        }
        case( CAL_MGR_MC_STOP ): {
            /*
            **  This "Control" command is sent to notify the calibration that the calibration
            **  has been requested to abort (internally or by the user) before
            **  the calibration has "started" (meaning the user has yet to press
            **  the Next>> button to start the calibration)
            **  The application may choose to set the status of the calibration to
            **  NOT_CALIBRATED since the calibration was stopped.
            **
            **  The possible responses are as follows:
            **      OK          - No active overrides are possible prior to "started"
            **      EXIT_REQ    - It is possible that active overrides exist,
            **          most likely generated INITIALIZE command. The EXIT_FLOW
            **          command will follow with this response.
            */

            return( CAL_MGR_MR_STOP_EXIT_REQ );
        }
        case( CAL_MGR_MC_QUIT ): {
            /*
            **  This "Control" command is sent to notify the calibration that the calibration
            **  has been requested to abort (internally or by the user) before
            **  the calibration setup conditions have been met (prior to executing
            **  the flow portion of the calibration, TERMINATE sent on restarts);
            **  The application may choose to set the status of the calibration to
            **  NOT_CALIBRATED since the calibration was quit.
            **
            **  The possible responses are as follows:
            **      OK          - No active overrides are possible prior to the
            **          INIT_FLOW command.
            **      EXIT_REQ    - It is possible that active overrides exist,
            **          most likely generated INITIALIZE command.
            **          The EXIT_FLOW command will follow with this response.
            */

            return( CAL_MGR_MR_QUIT_EXIT_REQ );
        }
        case( CAL_MGR_MC_TERMINATE ): {
            /*
            **  This "Control" command is sent to notify the calibration that the calibration
            **  has been requested to abort (internally or by the user) after the
            **  INIT_FLOW command had been sent at least once.  The application may
            **  choose to set the status of the calibration to NOT_CALIBRATED since
            **  the calibration was terminated.
            **
            **  The possible responses are as follows:
            **      OK          - No active overrides are possible
            **      EXIT_REQ    - It is possible that active overrides exist,
            **          most likely generated by INITIALIZE, INIT_FLOW, and/or FLOW
            **          commands. The EXIT_FLOW command will follow with this
            **          response.
            */

            return( CAL_MGR_MR_TERMINATE_EXIT_REQ );
        }
        case( CAL_MGR_MC_EXIT_FLOW ): {
            /*
            **  This "Control" command is intended to be used to check if any calibration
            **  overrides are active that require a cleanup of more than one
            **  execution loop.  This command will be called at most once per
            **  calibration execution.
            **
            **  The possible responses are as follows:
            **      DONE        - No cleanup is required (no active overrides exist)
            **      CLEANUP_REQ - Cleanup is required to clear overrides.
            **          CLEANUP command will follow with this response.
            */

            return( CAL_MGR_MR_EXIT_FLOW_CLEANUP_REQ );
        }
        case( CAL_MGR_MC_CLEANUP ): {
            /*
            **  This "Control" command is sent to notify the calibration that the calibration
            **  has been requested to abort (internally or by the user).  The
            **  CLEANUP_REQ response to the EXIT_FLOW command indicates that an
            **  active overrides exist that will possibly take more than one
            **  execution loop to clear.  The cleanup procedure is executed within
            **  this command.
            **
            **  The possible responses are as follows:
            **      DONE        - No active overrides exist
            **      NOT_DONE    - More execution loops are required to clear
            **          active overrides.
            */
            /* Else, default with DONE */
            return( CAL_MGR_MR_CLEANUP_DONE );
        }

        /*****************/
        /* Flow Commands */
        /*****************/
        case( CAL_MGR_MC_READY ): {
            /*
            **  This "Flow" command is sent to evaluate whether or not the
            **  calibration is "READY" to collect a sample.  The sample/s that
            **  is/are to be collected is/are most likely associated with a
            **  flow step number (LpsSaWeighInfoTbl.stepNo).
            **
            **  The possible responses are as follows:
            **      YES - The calibration is ready to begin the sampling
            **          process associated with the current flow step.
            **      NO  - The calibration is not ready to begine the sampling
            **          process associated with the current flow step.
            */
            /* Else, default with YES */
            return( CAL_MGR_MR_READY_YES );

        }
        case( CAL_MGR_MC_SAMPLE_INIT ): {
            /*
            **  This "Flow" command is sent to intialize the sampling process
            **  associated with the current step number (LpsSaWeighInfoTbl.stepNo).
            **
            **  The possible responses are as follows:
            **      OK  - Initialization for the sampling process associated with
            **          the current flow step (LpsSaWeighInfoTbl.stepNo) is complete.
            */
            LpsSaWeighInfoTbl.stepNo = CAL_LIFT_LINKAGE_FULL_RAISE;
            LOG_NOTICE("\n CAL_MGR_MC_SAMPLE_INIT \n");
            /* Default with OK */
            return( CAL_MGR_MR_SAMPLE_INIT_OK );
        }
        case( CAL_MGR_MC_SAMPLE ): {
        	LOG_NOTICE("\n CAL_MGR_MC_SAMPLE \n");
            /*
            **  This "Flow" command is sent during the execution of the sampling process
            **  associated with the current step number (LpsSaWeighInfoTbl.stepNo).
            **
            **  The possible responses are as follows:
            **      PT_COLLECTED - Sample point/s was/were collected that require
            **          validation after RESET
            **      WAIT - Sample Process is executing and requires another
            **          execution loop.
            **      SKIP - Sampling process has completed, no validation is required
            **          following RESET.
            */
            unsigned_8 done = FALSE;

            if( CAL_MGR_KEY_CONT )
	        {
                	LOG_NOTICE("\n CAL_MGR_KEY_CONT \n");

	                switch(   LpsSaWeighInfoTbl.stepNo )
	                {
	                	LOG_NOTICE("\n CAL_MGR_KEY_CONT:STEPNO %d \n", LpsSaWeighInfoTbl.stepNo);
	                    case( CAL_LIFT_LINKAGE_FULL_RAISE ): {
	                    	LOG_NOTICE("\n CAL_LIFT_LINKAGE_FULL_RAISE \n");
	                        cal_linkage_workspace.lift_full_raise_dc = WeighPidTbl.LiftCylDc;

	                        LpsSaWeighInfoTbl.stepNo = CAL_LIFT_LINKAGE_FULL_RACK;
	                        break;
	                    }
	                    case( CAL_LIFT_LINKAGE_FULL_RACK ):
	                    {
							if (LPS_SA_SENSOR_STATUS_GOOD == cal_linkage_workspace.lift_sensor_status)
							{
							 	LOG_NOTICE("\n CAL_LIFT_LINKAGE_FULL_RACK \n");
		                        cal_linkage_workspace.tilt_full_rack_dc = WeighPidTbl.TiltCylDc;

							}

	                        LpsSaWeighInfoTbl.stepNo = CAL_LIFT_LINKAGE_FULL_LOWER;
	                        break;
	                    }
	                    case( CAL_LIFT_LINKAGE_FULL_LOWER ):
	                    {
							if (LPS_SA_SENSOR_STATUS_GOOD == cal_linkage_workspace.lift_sensor_status)
							{
							 	LOG_NOTICE("\n CAL_LIFT_LINKAGE_FULL_LOWER \n");
		                        cal_linkage_workspace.lift_full_lower_dc = WeighPidTbl.LiftCylDc;

							}
							 done = TRUE;
     	                        break;
	                    }

	                    default:
	                    {
	                     	LOG_NOTICE("\n DEF-CAL_LIFT_LINKAGE_FULL_RAISE \n");
	                        LpsSaWeighInfoTbl.stepNo = CAL_LIFT_LINKAGE_FULL_RAISE;
	                        break;
	                    }
	                }
	            }

            return( done ? CAL_MGR_MR_SAMPLE_PT_COLLECTED : CAL_MGR_MR_SAMPLE_WAIT );
        }
        case( CAL_MGR_MC_RESET_INIT ): {
            /*
            **  This "Flow" command is sent to provide the calibration an
            **  opportunity to intialize any RESET parameters used within the
            **  RESET process after execution of the sampling process
            **  associated with the current step number (LpsSaWeighInfoTbl.stepNo).
            **
            **  The possible responses are as follows:
            **      OK - Initialization of RESET parameters is complete and a
            **          RESET process exists and should be executed
            **      NONE - No RESET process exists for the current step number.
            */

            return( CAL_MGR_MR_RESET_INIT_NONE );

        }
        case( CAL_MGR_MC_RESET ): {
            /*
            **  This "Flow" command is sent during the execution of the RESET process
            **  associated with the current step number (LpsSaWeighInfoTbl.stepNo).
            **
            **  The possible responses are as follows:
            **      DONE - RESET process is complete
            **      NOT_DONE - RESET process requires more execution loops to complete
            */
            return( CAL_MGR_MR_RESET_DONE );
        }
        case( CAL_MGR_MC_VALIDATE ): {
            /*
            **  This "Flow" command is sent to provide the calibration with the
            **  opportunity to validate the sample point/s associated with the
            **  current step number (LpsSaWeighInfoTbl.stepNo).  NOTE: This
            **  "Flow" command will not be sent if the SAMPLE command response is
            **  SKIP.
            **
            **  The possible responses are as follows:
            **      OK      - Sample Point/s is/are valid
            **      NOT_OK  - Sample Point/s is/are not valid.  cal_add_error()
            **          the reason for NOT_OK response.  The calibration will
            **          TERMINATE on next execution loop.
            **      RESTART - Sample Point/s is/are not valid.  cal_add_warning()
            **          the reason for RESTART response.  The calibration
            **          will RESTART_FLOW on next execution loop.
            */

        	if(cal_linkage_workspace.lift_full_lower_dc > cal_linkage_workspace.lift_full_raise_dc)
        	{
        		validate_success_lift = FALSE;
        	}
        	else
        	{
        		validate_success_lift = TRUE;
        	}

        	if(TRUE == validate_success_lift)
        	{
        		printf("\n LIFT CAL_MGR_MR_VALIDATE_OK");
        		return ( CAL_MGR_MR_VALIDATE_OK );
        	}
        	else
        	{
        		*CalError = 0x0103;
        		printf("\n LIFT CAL_MGR_MR_VALIDATE_NOT_OK");
        		return( CAL_MGR_MR_VALIDATE_NOT_OK );
        	}

        }
        case( CAL_MGR_MC_NEXT_PT ): {
            /*
            **  This "Flow" command is sent to provide the calibration with the
            **  opportunity to change the current step number
            **  (LpsSaWeighInfoTbl.stepNo) to the next step number.
            **
            **  The possible responses are as follows:
            **      MORE        - More Sample Point/s to collect
            **      NO_MORE     - No more Sample Point/s to collect
            */

            return( CAL_MGR_MR_NEXT_PT_NO_MORE );
        }
        case( CAL_MGR_MC_SUCCESS ): {


            /*
            **  This "Flow" command is sent following a NO_MORE response to the
            **  NEXT_PT command.  This "Flow" Command should be used to save the
            **  sampled points collected.  The status of the calibration points
            **  should be noted as CALIBRATED as appropriate just prior to a
            **  SAVED response.
            **
            **  The possible responses are as follows:
            **      SAVED   - Sampled Points (Data) were saved successfully
            **      WAIT    - Sampled Points (Data) are being saved or the
            **          SAVING process is waiting for User input (i.e. revert to
            **          previous, revert to default, save current, etc.)
            */

            /*** Save the data to NVM ***/

            /* Set the calibration values (at the same time, save to nvm) */
			if (validate_success_lift)
			{
	            lift_linkage_cal_array[0] = cal_linkage_workspace.lift_full_lower_dc;
	            lift_linkage_cal_array[1] = cal_linkage_workspace.lift_full_raise_dc;
			}

			printf("lift_linkage_cal_array[0] %f lift_linkage_cal_array[1] %f \n",
					lift_linkage_cal_array[0], lift_linkage_cal_array[1]);
        	printf("\n CAL_MGR_MC_SUCCESS LIFT \n");

			LpsSaWeighLiftNvmCal.lift_full_lower_dc = lift_linkage_cal_array[0];
			LpsSaWeighLiftNvmCal.lift_full_raise_dc = lift_linkage_cal_array[1];

			LpsSaWeighLiftNvmCal.lift_cal_stat |= CAL_LIFT_LINKAGE_MASK;

			LpsSaLiftNvmWeighAppCalWriteFlag = TRUE;

			/*Enable Reinit flag*/
			CalNVMReinitFlag =TRUE;

            return( CAL_MGR_MR_SUCCESS_SAVED );

        }
        case( CAL_MGR_MC_DONE ): {
            /*
            **  This "Flow" command is sent following a SAVED response to the
            **  SUCCESS command.  The EXIT_FLOW Command will follow on the next
            **  execution loop.
            **
            **  The possible responses are as follows:
            **      OK      - no more sets of Sampled Points (Data) to be
            **          collected.
            **      RESTART - (Advanced Option) another set of Sampled Points
            **          (Data) are to be collected.
            */
        	printf("\n CAL_MGR_MC_DONE \n");
            /* Default with OK */
            return( CAL_MGR_MR_DONE_OK );

        }
        case( CAL_MGR_MC_FAIL ): {
        	printf("\n CAL_MGR_MC_FAIL \n");

            /*
            **  This "Flow" command is sent following a NOT_OK response to the
            **  VALIDATE command.  The TERMINATE command will follow on the next
            **  execution loop.
            **
            **  The possible responses are as follows:
            **      OK      - Set of Sampled Points (Data) were noted as being
            **          NOT_CALIBRATED
            */

            /* Default Response */
            return( CAL_MGR_MR_FAIL_OK );
        }

        default:
           // Do nothing for now
           break;
    }

    /* This should never happen */
    return( CAL_MGR_MR_NOT_SUPPORTED );
}


/*
**  --- Local Functions ---
*/
static unsigned_8 lstat_hdlr(   unsigned_8 cmd,
                                cal_last_stat_t *rpt ) {

    switch( cmd ) {
        case( CAL_PUSH_STATUS ): {
            break;
        }
        case( CAL_PULL_STATUS ): {
            rpt->bstatus    = 0x01;
            rpt->lHourMeter = 1;
            rpt->bErrors    = 0;
            break;
        }
    }
    return( CAL_MGR_MR_INIT_LAST_STAT_OK );

}
