/*******************************************************************************
** COPYRIGHT (C) 2016-2017, 2019 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaCda.cpp
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  _LPS_SA_WEIGHAPP_H_
#include "LpsSaWeighApp.h"
#endif

#ifndef __LPS_PRIVATE_H__
#include <LpsPrivate.h>
#endif

extern boolean CalNVMReinitFlag;

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/******************************************************************************
FUNCTION NAME:LpsSaScsChkForReqst
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaScsChkForReqst()
{

	LpsSaWeighReqstChannel reqIn;

	/* Retreive SCS channel data */
	while(LpsSaWeighScsReqstIn->get( reqIn ))
	{
		/* Check if Zero request received from JM App */
		if(true == reqIn.ZeroReqst)
		{
			/* Request received by Weighing App,set the request flag */
			LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_ZERO_INDX] = TRUE;
			return;
		}
		/* Check if best bucket reset request received from JM App */
		else if(true == reqIn.BestBktRstReqst)
		{
			/* Request received for Weighing App,set the request flag */
			LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_BEST_BKT_RST_INDX] = TRUE;
			return;
		}
		else if(true == reqIn.CaptCylExtRef)
		{
			/* Request received for Weighing App,set the request flag */
			LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_CAPT_CYL_EXTN_REF_INDX] = TRUE;
			return;
		}
		else if(true == reqIn.ClearReweighWarnReqst)
		{
			/* Request received for Weighing App,set the request flag */
			LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_CLEAR_REWEIGH_WARNING_INDX] = TRUE;
			return;
		}

	/* Check if Weigh Range request received from UI App */
		else if(true == reqIn.WeighRangeRequest.WeighRangeReqstFlag)
		{
			LOG_NOTICE( "\n weigh range reqst receivd  Bottom:%.1f  Size:%.1f \n", reqIn.WeighRangeRequest.WeighRangeBottom, reqIn.WeighRangeRequest.WeighRangeSize);
		   /* Request received for Weighing App,set the request flag */
			LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_WEIGH_RANGE_INDX] = TRUE;

			LpsSaChkWeighRangeConfig( reqIn.WeighRangeRequest.WeighRangeBottom,
									  reqIn.WeighRangeRequest.WeighRangeSize);

			/* Copying the received Weigh range settings */
			LpsSaWeighNvmMachSpecificCfg.WeighRangeBottom =
					LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.StartOfWeigh;


			LpsSaWeighNvmMachSpecificCfg.WeighRangeSize = (LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.EndOfWeigh -
														   LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.StartOfWeigh);
			ReInitWeighLib( );
			
			return;
		}
		else if(true == reqIn.SetCalWtRequest.newCalWtFlag )
		{
		    LOG_DEBUG( "\n calwt reqst receivd: %f \n", reqIn.SetCalWtRequest.newCalWt );

		    if((LpsSaWeighNvmMachSpecificCfg.CalWt != reqIn.SetCalWtRequest.newCalWt) && (reqIn.SetCalWtRequest.newCalWt > 0.0))
			{
			    LOG_DEBUG( "\n calwt set: %f \n", reqIn.SetCalWtRequest.newCalWt );
			    LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_NEW_CAL_WT_INDX] = TRUE;
				LpsSaWeighNvmMachSpecificCfg.CalWt = reqIn.SetCalWtRequest.newCalWt;
				//Check if cal wt required diagnostic added to ET.
				LpsSaWeighNvmCal.CalStat |= CAL_BKT_WT_MASK;
				WeighPidTbl.LastPloadWt = LPS_CAL_LAST_PAYLOAD_WT_COND_NOT_MET_PID_DSI;
				LpsSaWeighNvmMachSpecificCfg.LastPloadWt = WeighPidTbl.LastPloadWt;
				LpsSaNvmWeighAppCalWriteFlag = TRUE;
				LpsSaNvmWeighAppMachSpecificCfgWriteFlag = TRUE;
				CalNVMReinitFlag =TRUE;
				//ReInitWeighLib( );				
			}
			return;
		}

		else if(true == reqIn.PloadOvrloadWarnEnReq )
		{
			LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_OVR_LOAD_WARN_EN_INDX] = FALSE;
			WeighPidTbl.PloadOvrloadWarnEn = LpsSaWeighNvmMachSpecificCfg.PloadOvrloadWarnEn = reqIn.PidWrData.PloadOvrloadWarnEn;/* - Payload Overload Warning Enable [1] (RECM)*/
			LOG_NOTICE( "\n reqIn.PidWrData.PloadOvrloadWarnEn = %x\n",reqIn.PidWrData.PloadOvrloadWarnEn);
			printf("PloadOvrloadWarnEn = %x \n", WeighPidTbl.PloadOvrloadWarnEn);
			LpsSaNvmWeighAppMachSpecificCfgWriteFlag = TRUE;
			return;
		}

		else if(true == reqIn.LastPloadWtSetReq)
		{
			//this appears to be incorrect. set LastPloadWt to ET PID.
			// this should be read-only, no write
			LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_LAST_PAY_LOAD_WT_INDX] = TRUE;
			WeighPidTbl.LastPloadWt = LpsSaWeighNvmMachSpecificCfg.LastPloadWt = reqIn.PidWrData.LastPloadWt;/*  - Last Payload Weight [255]*/
			LOG_NOTICE( "\n reqIn.PidWrData.LastPloadWt = %f\n",reqIn.PidWrData.LastPloadWt);
			printf("LAST PAYLOAD WEIGHT = %f \n", WeighPidTbl.LastPloadWt);
			ReInitWeighLib( );
			return;
		}

		else if(true == reqIn.LoaderBktPloadTgtWtSetReq)
		{
			LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_LOADER_BKT_PAYLOAD_WT_INDX] = TRUE;
			LpsSaWeighInfoTbl.LoaderBktPayldTrgtWt = LpsSaWeighNvmMachSpecificCfg.LoaderBktPloadTrgtWt = reqIn.PidWrData.LoaderBktPloadTgtWt;/*  - Last Payload Weight [255]*/
			LOG_NOTICE( "\n reqIn.PidWrData.LastPloadWt = %f\n",reqIn.PidWrData.LastPloadWt);
			LOG_DEBUG("LoaderBktPayloadTrgtWt = %f \n", LpsSaWeighInfoTbl.LoaderBktPayldTrgtWt);
			ReInitWeighLib( );
			return;
		}
	}

	return;
}
/******************************************************************************
FUNCTION NAME:LpsSaScsSendReqstResponse
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
boolean LpsSaWeighApp::LpsSaScsSendReqstResponse(LpsSaWeighScsReqstStatIndex_t reqstIndx, unsigned char respCode)
{
	bool scsCmdRet=false;
	LpsSaWeighRespChannel respOut;

	if(reqstIndx >= LPS_SA_WEIGH_SCS_REQST_NO_OF_PARAM_INDX)
	{
		/* This check is done to prevent array out of bound access */
		return LPS_SA_WEIGH_FAIL;
	}

	/* Clear request flag */
	LpsSaWeighScsReqstStatFlg[reqstIndx] = FALSE;

	/*Set Default values*/
	respOut.ZeroResp=LPS_SA_WEIGH_ZERO_UNKNOWN;
	respOut.BestBktRstResp=LPS_SA_WEIGH_BEST_BKT_RST_UNKNOWN;
	respOut.CaptCylExtRefResp=LPS_SA_WEIGH_CAPT_CYL_EXTN_REF_UNKNOWN;
	respOut.ClearReweighWarningResp=LPS_SA_WEIGH_CLEAR_REWEIGH_WARNING_UNKNOWN;
	respOut.WeighRangeResp=LPS_SA_WEIGH_RANGE_UNKNOWN;

	switch(reqstIndx)
	{
		 case LPS_SA_WEIGH_SCS_REQST_ZERO_INDX:
			 respOut.ZeroResp=(LpsSaWeighZeroRespCode_t)respCode;
			break;
		 case LPS_SA_WEIGH_SCS_REQST_BEST_BKT_RST_INDX:
			respOut.BestBktRstResp=(LpsSaBestBktRstRespCode_t)respCode;
			 break;
		 case LPS_SA_WEIGH_SCS_REQST_CAPT_CYL_EXTN_REF_INDX:
			respOut.CaptCylExtRefResp=(LpsSaCaptCylExtRefRespCode_t)respCode;
			break;
		 case LPS_SA_WEIGH_SCS_REQST_WEIGH_RANGE_INDX:
			 respOut.WeighRangeResp=(LpsSaWeighRangeRespCode_t)respCode;
			 break;
		 case LPS_SA_WEIGH_SCS_REQST_CLEAR_REWEIGH_WARNING_INDX:
			 respOut.ClearReweighWarningResp=(LpsSaClearReweighWarningRespCode_t)respCode;
			 break;

		 default:
			break;
	}


	/* send response SCS channel to Job Manager*/
	if ( LpsSaWeighScsRespOut )
	{
		scsCmdRet =LpsSaWeighScsRespOut ->publish( respOut );
		LOG_NOTICE( "\n Line no = %d,'LpsSaScsSendReqstResponse' function return code = %d\n",__LINE__,scsCmdRet);

	}

	if(true != scsCmdRet)
	{
		return LPS_SA_WEIGH_FAIL;
	}

	return LPS_SA_WEIGH_SUCCESS;
}

/******************************************************************************
FUNCTION NAME: AisJhmDataServerTxRead
DESCRIPTION:            
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
void LpsSaWeighApp::AisJhmDataServerTxRead( )
{
	AisJhm2TxChannel AisJhm2TxIn;
    while ( AisJhm2TxInputScs->get( AisJhm2TxIn ) )
    {
    	if(AisJhm2TxIn.simplecal_data.newDataFlag == true)
		{
			LOG_NOTICE( "\n ### AIS Adj wt = %f\n",AisJhm2TxIn.simplecal_data.adjtruckweight);
			LOG_NOTICE( "\n ### AIS Zeroed wt = %f\n",AisJhm2TxIn.simplecal_data.zeroedTruckWt);
			sumOfAdjustedTruckWts += AisJhm2TxIn.simplecal_data.adjtruckweight;
			sumOfZeroedTruckWts += AisJhm2TxIn.simplecal_data.zeroedTruckWt;

			if(sumOfZeroedTruckWts > 0.0f)
				updatedSimpleCalFactor = sumOfAdjustedTruckWts/sumOfZeroedTruckWts;

			if (updatedSimpleCalFactor > 0.0f && updatedSimpleCalFactor < 10.0f)
			{
				if(LpsSaWeighNvmMachSpecificCfg.updatedSimpleCalFactor != updatedSimpleCalFactor)
				{
					LOG_NOTICE( "\n updated simple cal factor = %f\n",updatedSimpleCalFactor);
					LpsSaWeighNvmMachSpecificCfg.updatedSimpleCalFactor = updatedSimpleCalFactor;
					LpsSaNvmWeighAppMachSpecificCfgWriteFlag = TRUE;
				}
			}
		}
    }
}

/******************************************************************************
FUNCTION NAME: AisJhmDataServerTxRead
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaSEAStatus( )
{
	/*TODO: We are initializing the status of the SEA to installed/enabled,
	 * we should probably disable the SEA if we do not receive a SEA object
	 * in the first x minutes */
	SEAStatus SEAStatusIn;
    while ( SEAStatusInScs->get( SEAStatusIn ) )
    {
    	for (auto & element : SEAStatusIn.m_seaList) {
    	    if (element.reason_code == 149) {
    	    	/* Payload installation and Enable status*/
    	    	LpsSaWeighInfoTbl.LpsSaPayloadSEAStatus = element.status;
    	    }
    	}
    }

    if ( SCL_PRMSW_FEAT_STATUS_INSTALLED_ENABLED == LpsSaWeighInfoTbl.LpsSaPayloadSEAStatus) {
    	LpsSaWeighInfoTbl.DiagState.flag.PaylodMonSystemNotInstalled = DIAG_INACTIVE;
    }
    else {
    	LpsSaWeighInfoTbl.DiagState.flag.PaylodMonSystemNotInstalled = DIAG_ACTIVE;
    }
}

/******************************************************************************
FUNCTION NAME:LpsSaJobMgrScsRx
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaWeighingScsRx( )
{
	/*Read the requests from JM App*/
	LpsSaScsChkForReqst();

	/*Read the param from JM*/
	LpsJobMgrTxRead();
	
	/* Read simple cal params from AisJhmDataServer. */
	AisJhmDataServerTxRead();

	/* Read Payload SEA status */
	LpsSaSEAStatus();

	/*Read params from Machine Interface*/
	LpsSaMachineRead();

}

/******************************************************************************
FUNCTION NAME: LpsSaScsSendZeroRqst
DESCRIPTION:
PARAMETER DESCRIPTION: Publishes a zero request on the JobMgr Reqst channel
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaScsSendZeroRqst()
{
	bool scsReqstRet=false;
	LpsSaJobMgrReqstChannel ReqstOut;
	if (LpsSaJobMgrScsReqstOut )
	{
		ReqstOut.ZeroReqst = 1;
		scsReqstRet = LpsSaJobMgrScsReqstOut->publish(ReqstOut);
	}

	if(true != scsReqstRet)
	{
		LOG_NOTICE( "\n Line no = %d,'LpsSaScsSendZeroRqst' Fail to Send Zero Reqst \n",__LINE__ );
	}
}
/******************************************************************************
FUNCTION NAME: LpsSaWeighingScsTx
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
boolean LpsSaWeighApp::LpsSaWeighingScsTx()
{
	bool scsCmdRet=false;
	LpsSaWeighTxChannel txOut;
	if (LpsSaWeighScsTxOut )
	{
		txOut.DigStat = LpsSaWeighInfoTbl.DigStat;
		txOut.CalStat = LpsSaWeighInfoTbl.CalStat;
		txOut.DumpStat = LpsSaWeighInfoTbl.DumpStat;
		txOut.BestBktWtInTonnes = LpsSaWeighInfoTbl.BestBktWtInTonnes;
		txOut.ZeroNotifyStat = LpsSaWeighInfoTbl.ZeroNotifyStat;
		txOut.PayloadCalcMeth = LpsSaWeighInfoTbl.PayloadCalcMeth;
		txOut.bktWtLatchedFlag = LpsSaWeighInfoTbl.WeighDecFlag;
		txOut.latchConditionsMet = LpsSaWeighInfoTbl.LatchConditionsOK;
		txOut.LiftCylVel = LpsSaWeighInfoTbl.LiftCylVel;
		txOut.WeighRange.WeighRangeBottom = LpsSaWeighNvmMachSpecificCfg.WeighRangeBottom;
		LOG_NOTICE( "\n WeighRange.WeighRangeBottom = %f\n",txOut.WeighRange.WeighRangeBottom);
		txOut.WeighRange.WeighRangeSize = LpsSaWeighNvmMachSpecificCfg.WeighRangeSize;
		LOG_NOTICE( "\n WeighRange.WeighRangeSize = %f\n",txOut.WeighRange.WeighRangeSize);
		txOut.PidData.PloadOvrloadWarnEn = WeighPidTbl.PloadOvrloadWarnEn;



		/*ET Weigh Status parameters */


	    LpsWeighWrwReweighStatus_t ReweighRetStat;

	    ReweighRetStat=LpsGetWrwReweighWarning();

	    if(TRUE == ReweighRetStat.TooSlow )
	    		{
	    			LpsSaWeighInfoTbl.InfoState.flag.ReWeighLiftTooSlow=true;
	    		}

		if(TRUE == ReweighRetStat.Stopped)
		{
			LpsSaWeighInfoTbl.InfoState.flag.ReWeighStoppedInWRG=true;
		}
		if(TRUE == ReweighRetStat.NotRacked)
		{
			LpsSaWeighInfoTbl.InfoState.flag.ReWeighBucketNotRacked=true;
		}
		if(TRUE == ReweighRetStat.Jerky) 			/* Speed Change Too High */
		{
			LpsSaWeighInfoTbl.InfoState.flag.ReWeighSpeedCHG2HI=true;
		}
		if(TRUE == ReweighRetStat.Inconsistent)
		{
			LpsSaWeighInfoTbl.InfoState.flag.ReWeighInconsistent=true;
		}
		if(TRUE == ReweighRetStat.RateOfChangeHi) 	/* Pressure Change Too High */
		{
			LpsSaWeighInfoTbl.InfoState.flag.ReWeighPressureCHG2HI=true;
		}

		/* We will no longer show any pop-up on stall */
		/*if(TRUE == LpsWeighGetStallStat().UpperStall)
		{
			LpsSaWeighInfoTbl.InfoState.flag.UpperStall=true;
		}
		if(TRUE ==  LpsWeighGetStallStat().LowerStall)
		{
			if(TRUE == LpsSalowerStallDetectFlag)
			{
				LpsSaWeighInfoTbl.InfoState.flag.LowerStall=true;
			}
		}*/

		txOut.PidData.ProdMeasureWeighStatus.Data = WeighPidTbl.ProdMeasureWeighStatus.Data;

	    txOut.PidData.ProdMeasureWeighStatus.flag.LowerStall = LpsSaWeighInfoTbl.InfoState.flag.LowerStall;
	    txOut.PidData.ProdMeasureWeighStatus.flag.UpperStall = LpsSaWeighInfoTbl.InfoState.flag.UpperStall;
	    txOut.PidData.ProdMeasureWeighStatus.flag.InsufficentData = 0;
	    txOut.PidData.ProdMeasureWeighStatus.flag.ReWeighPressureCHG2HI = LpsSaWeighInfoTbl.InfoState.flag.ReWeighPressureCHG2HI;
	    txOut.PidData.ProdMeasureWeighStatus.flag.ReWeighInconsistent = LpsSaWeighInfoTbl.InfoState.flag.ReWeighInconsistent;
	    txOut.PidData.ProdMeasureWeighStatus.flag.ReWeighSpeedCHG2HI = LpsSaWeighInfoTbl.InfoState.flag.ReWeighSpeedCHG2HI;
	    txOut.PidData.ProdMeasureWeighStatus.flag.ReWeighBucketNotRacked = LpsSaWeighInfoTbl.InfoState.flag.ReWeighBucketNotRacked;
	    txOut.PidData.ProdMeasureWeighStatus.flag.ReWeighStoppedInWRG = LpsSaWeighInfoTbl.InfoState.flag.ReWeighStoppedInWRG;
	  	txOut.PidData.ProdMeasureWeighStatus.flag.ReWeighLiftTooSlow = LpsSaWeighInfoTbl.InfoState.flag.ReWeighLiftTooSlow;



		LOG_NOTICE( "\n WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus.Data  = %d \n",WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus.Data );
		LOG_NOTICE( "\n LpsSaWeighInfoTbl.InfoState.Data = %d \n",LpsSaWeighInfoTbl.InfoState.Data );



		LOG_NOTICE( "\n LpsSaWeighInfoTbl.InfoState.flag.UpperStall = %d \n",LpsSaWeighInfoTbl.InfoState.flag.UpperStall);
		LOG_NOTICE( "\n LpsSaWeighInfoTbl.InfoState.flag.LowerStall = %d \n",LpsSaWeighInfoTbl.InfoState.flag.LowerStall);
		LOG_NOTICE( "\n LpsSaWeighInfoTbl.InfoState.flag.ReWeighPressureCHG2HI = %d \n",LpsSaWeighInfoTbl.InfoState.flag.ReWeighPressureCHG2HI);
		LOG_NOTICE( "\n LpsSaWeighInfoTbl.InfoState.flag.ReWeighInconsistent = %d \n",LpsSaWeighInfoTbl.InfoState.flag.ReWeighInconsistent);
		LOG_NOTICE( "\n LpsSaWeighInfoTbl.InfoState.flag.ReWeighSpeedCHG2HI = %d \n",LpsSaWeighInfoTbl.InfoState.flag.ReWeighSpeedCHG2HI);
		LOG_NOTICE( "\n LpsSaWeighInfoTbl.InfoState.flag.ReWeighBucketNotRacked = %d \n", LpsSaWeighInfoTbl.InfoState.flag.ReWeighBucketNotRacked);
		LOG_NOTICE( "\n LpsSaWeighInfoTbl.InfoState.flag.ReWeighStoppedInWRG = %d \n",LpsSaWeighInfoTbl.InfoState.flag.ReWeighStoppedInWRG);
		LOG_NOTICE( "\n LpsSaWeighInfoTbl.InfoState.flag.ReWeighLiftTooSlow = %d \n",LpsSaWeighInfoTbl.InfoState.flag.ReWeighLiftTooSlow);



		LOG_NOTICE( "\n WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus LowerStall = %d \n",WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus.flag.LowerStall);
		LOG_NOTICE( "\n WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus UpperStall = %d \n",WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus.flag.UpperStall);
		LOG_NOTICE( "\n WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus InsufficentData = %d \n",WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus.flag.InsufficentData);
		LOG_NOTICE( "\n WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus ReWeighPressureCHG2HI = %d \n",WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus.flag.ReWeighPressureCHG2HI);
		LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn Inconsistent = %d \n",WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus.flag.ReWeighInconsistent);
		LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn RateOfChangeHi = %d \n",WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus.flag.ReWeighSpeedCHG2HI);
		LOG_NOTICE( "\n WeighWrwReweighStatus.ReweighBucke = %d \n", WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus.flag.ReWeighBucketNotRacked);
		LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn RateOfChangeHi = %d \n",WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus.flag.ReWeighStoppedInWRG);
		LOG_NOTICE( "\n WeighWrwReweighStatus.ReweighBucke = %d \n", WeighPidTbl.ProdMeasureWeighStatus.WeighWrwReweighStatus.flag.ReWeighLiftTooSlow);


		LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn TooSlow = %d \n",LpsWrk.WrwTbl.ReweighWarn.TooSlow);
		LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn Stopped = %d \n",LpsWrk.WrwTbl.ReweighWarn.Stopped);
		LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn NotRacked = %d \n",LpsWrk.WrwTbl.ReweighWarn.NotRacked);
		LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn Jerky = %d \n",LpsWrk.WrwTbl.ReweighWarn.Jerky);
		LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn Inconsistent = %d \n",LpsWrk.WrwTbl.ReweighWarn.Inconsistent);
		LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn RateOfChangeHi = %d \n",LpsWrk.WrwTbl.ReweighWarn.RateOfChangeHi);
		LOG_NOTICE( "\n LpsWrk.ZeroAdjTbl.AutoZeroStatus = %d \n", LpsWrk.ZeroAdjTbl.AutoZeroStatus);
		LOG_NOTICE( "\n LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed = %d \n",LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed);
		LOG_NOTICE( "\n LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjAutoTimeInterval = %d \n",LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjAutoTimeInterval);
		LOG_NOTICE( "\n LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjInitTimeInterval = %d \n",LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjInitTimeInterval);
		LOG_NOTICE( "\n LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed = %d \n",LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed);

		LOG_NOTICE( "\n WeighPidTbl.ProdMeasureWeighStatus.Data = %d \n",WeighPidTbl.ProdMeasureWeighStatus.Data);
		LOG_NOTICE( "\n txOut.PidData.ProdMeasureWeighStatus = %d \n",txOut.PidData.ProdMeasureWeighStatus);












		txOut.LiftCylExt = LpsSaWeighInfoTbl.LiftCylExt;
		txOut.CalWt = LpsSaWeighNvmMachSpecificCfg.CalWt;
		LOG_NOTICE( "\n txOut.CalWt  = %f \n",txOut.CalWt);
		txOut.Indicator =  LpsSaWeighInfoTbl.Indicator;
		txOut.PayloadAvailable = LpsWrk.LpsStallDetect.payload_available;
		txOut.SimpleCalAdjustment = activeSimpleCalFactor;
		txOut.EventState.Data = LpsSaWeighInfoTbl.EventState.Data;
		txOut.DiagState.Data = LpsSaWeighInfoTbl.DiagState.Data;
		txOut.InfoState.Data = LpsSaWeighInfoTbl.InfoState.Data;

		if(FALSE == LpsSaWeighInfoTbl.DiagState.Data)
		{
			txOut.ShowExclamationPoint = false;
		}
		else
		{
			if (txOut.DiagState.flag.PaylodMonSystemNotInstalled == DIAG_ACTIVE) {
				/* Suppress all other info/event/diag if SEA is not installed/enabled */
				txOut.DiagState.Data = DIAG_INACTIVE;
				txOut.DiagState.flag.PaylodMonSystemNotInstalled = DIAG_ACTIVE;
				txOut.InfoState.Data = 0;
				txOut.EventState.Data = EVENT_INACTIVE;
			}

			txOut.ShowExclamationPoint = true;
		}
		LOG_NOTICE("\n\n\n InfoPopUpStatus = %08x \n\n",txOut.InfoState.Data);
		LOG_NOTICE( "\n WeighRange.WeighRangeBottom = %f\n",txOut.WeighRange.WeighRangeBottom);
		LOG_NOTICE( "\n WeighRange.WeighRangeSize = %f\n",txOut.WeighRange.WeighRangeSize);
		LOG_NOTICE("\n\n\n DiagState = %08x \n\n",txOut.DiagState.Data);
		LOG_NOTICE("\n\n\n EventState = %08x \n\n",txOut.EventState.Data);
		LOG_NOTICE( "\n LpsSaWeighInfoTbl.Indicator = %d\n",LpsSaWeighInfoTbl.Indicator );


		/*Production Measurement Sensor Status*/
		txOut.PidData.ProdMeasureSensorStatus.LiftCylExtMm = LpsSaWeighInfoTbl.LiftCylExtMillimeter.Val;/*Lift Cylinder Extension*/
		txOut.PidData.ProdMeasureSensorStatus.TiltCylExtMm = LpsSaWeighInfoTbl.TiltCylExtMillimeter.Val;/*Tilt Cylinder Extension*/
		txOut.PidData.ProdMeasureSensorStatus.BktAngle = LpsSaWeighInfoTbl.BucketAngle.Val;/*Bucket Angle*/
		txOut.PidData.ProdMeasureSensorStatus.LiftLinkDC = WeighPidTbl.LiftCylDc;/* Lift Linkage Position Sensor Duty Cycle*/
		txOut.PidData.ProdMeasureSensorStatus.LiftCylPos = weighUpdtTbl.LiftCylExt.Val;/*Lift Cylinder Position*/
		txOut.PidData.ProdMeasureSensorStatus.LiftCylHEPres = weighUpdtTbl.LiftCylHePres.Val;/*Lift Cylinder Head End Pressure*/
		txOut.PidData.ProdMeasureSensorStatus.LiftCylREPres = weighUpdtTbl.LiftCylRePres.Val;/*Lift Cylinder Rod End Pressure*/
		txOut.PidData.LastPloadWt = WeighPidTbl.LastPloadWt;

		
		txOut.PidData.ProdMeasureSensorStatus.TiltLinkDC = WeighPidTbl.TiltCylDc;/*LpsSaWeighInfoTbl.TiltCylDc.Val;//Tilt Linkage Position Sensor Duty Cycle*/
		txOut.PidData.ProdMeasureSensorStatus.HydOilTemp = WeighPidTbl.HydOilTemp;
		/* Linkage Sensor Calibrated Limits [-75722]*/
		txOut.PidData.LinkSensorCalLim.LiftPosSensorFullRaiseDC =  LiftTiltMinMaxDc.LiftCylMaxDc;/*Lift Linkage Position Sensor Full Raise Duty Cycle*/
		txOut.PidData.LinkSensorCalLim.LiftPosSensorFullLowerDC = LiftTiltMinMaxDc.LiftCylMinDc ;/*Lift Linkage Position Sensor Full Lower Duty Cycle*/
		txOut.PidData.LinkSensorCalLim.TiltPosSensorFullRackDC = LiftTiltMinMaxDc.TiltCylMaxDc  ;/*Tilt Linkage Position Sensor Full Rackback Duty Cycle*/
		txOut.PidData.LinkSensorCalLim.TiltPosSensorFullDumpDC = LiftTiltMinMaxDc.TiltCylMinDc  ;/*Tilt Linkage Position Sensor Full Dump Duty Cycle*/
		txOut.PidData.PloadSysZeroStat = GetZeroStat() ;/*Payload Remove Last Pass Button Display Status*/

		txOut.PidData.LoaderBktPloadTgtWt = LpsSaWeighInfoTbl.LoaderBktPayldTrgtWt;
		txOut.PidData.LoaderBktPloadTgtWtPer = LpsWeighGetBucketLoadFactor();

		txOut.PidData.PloadSysCalWtEntryReqStat = WeighPidTbl.PloadSysCalWtEntryReqStat;
		WeighPidTbl.PloadSysZeroReqStat.ZeroNeededStatus = LpsWeighGetAutoZeroUpdateStatus();
		txOut.PidData.PloadSysZeroReqStat = WeighPidTbl.PloadSysZeroReqStat.Data;/* Payload System Zero Requirement Status */
		txOut.PidData.BktPayloadData = WeighPidTbl.BktPayloadData;
		LOG_NOTICE( "\n WeighRange.WeighRangeBottom = %f \n WeighRange.WeighRangeSize = %f \n	\
						PidData.PloadOvrloadWarnEn = %x \n	\
						PidData.ProdMeasureWeighStatus = %x \n \
						WeighPidTbl.HydOilTemp = %f \n	\
						PidData.LdrPayloadStat = %x \n	\
						PidData.PloadSysZeroStat = %x \n \
						PidData.LoaderBktPloadTgtWt = %x \n \
						PidData.PloadSysZeroReqStat = %x \n",
						txOut.WeighRange.WeighRangeBottom,
						txOut.WeighRange.WeighRangeSize,
						txOut.PidData.PloadOvrloadWarnEn,
						txOut.PidData.ProdMeasureWeighStatus,
						txOut.PidData.ProdMeasureSensorStatus.HydOilTemp,
						txOut.PidData.LdrPayloadStat,
						txOut.PidData.PloadSysZeroStat,
						txOut.PidData.LoaderBktPloadTgtWt,
						txOut.PidData.PloadSysZeroReqStat
				);


		LOG_NOTICE( "\n PayloadAvailable  = %d \n",txOut.PayloadAvailable);
		LpsSaWeighInfoTbl.CalibrationTxval.LiftCylVel=weighUpdtTbl.LiftCylVel.Val;


		LOG_NOTICE("\n LpsSaWeighingScsTx: Vel %f LiftCylExt%f HE %f RE %f ,':'\n",
				weighUpdtTbl.LiftCylVel.Val,
				weighUpdtTbl.LiftCylExt.Val,
				weighUpdtTbl.LiftCylHePres.Val,
				weighUpdtTbl.LiftCylRePres.Val);
				


		txOut.CalParam.LiftCylVel = LpsSaWeighInfoTbl.CalibrationTxval.LiftCylVel;

		/* Broadcasting Weighing App elements */
		scsCmdRet=LpsSaWeighScsTxOut->publish( txOut );

	}
	else
	{
		/* do nothing */
	}

	if(true != scsCmdRet)
	{
		 LOG_NOTICE( "\n Line no = %d,'LpsSaWeighingScsTx' function return code = %d\n",__LINE__,scsCmdRet );
		 return LPS_SA_WEIGH_FAIL;
	}

	return LPS_SA_WEIGH_SUCCESS;
}

/******************************************************************************
FUNCTION NAME: LpsSaWeighScsInitDebugTx
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaWeighScsInitDebugTx()
{
	LpsSaWeighInitDebugChannel txOut;
	if (LpsSaWeighScsInitDebugOut )
	{
		/* Fill in the data to publish */
		txOut.m_LpsSaInitTbl = this->LpsSaInitTbl;

		/* Broadcasting Weighing App elements */
		LpsSaWeighScsInitDebugOut->publish( txOut );
	}
	else
	{
		/* do nothing */
	}
}

/******************************************************************************
FUNCTION NAME: LpsSaWeighScsDebugTx
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
 *******************************************************************************/
void LpsSaWeighApp::LpsSaWeighScsDebugTx()
{
	LpsSaWeighDebugChannel txOut;
	if (LpsSaWeighScsDebugOut )
	{
		/* Fill in the data to publish */
		txOut.m_weighUpdtTbl = this->weighUpdtTbl;
		txOut.m_LpsWrk = LpsWrk;

		/* Lift Cylinder Head End Pressure */
		txOut.DebugLiftCylHePeriod = this->DebugLiftCylHePeriod;
		txOut.DebugLiftCylHeWidth = this->DebugLiftCylHeWidth;
		txOut.DebugLiftCylHeDc = this->DebugLiftCylHeDc;
		txOut.DebugLiftCylHePress = this->DebugLiftCylHePress;

		/* Lift Cylinder Rod End Pressure */
		txOut.DebugLiftCylRePeriod = this->DebugLiftCylRePeriod;
		txOut.DebugLiftCylReWidth = this->DebugLiftCylReWidth;
		txOut.DebugLiftCylReDc = this->DebugLiftCylReDc;
		txOut.DebugLiftCylRePress = this->DebugLiftCylRePress;

		/* Lift Cylinder */
		txOut.DebugLiftCylPeriod = this->DebugLiftCylPeriod;
		txOut.DebugLiftCylWidth = this->DebugLiftCylWidth;
		txOut.DebugLiftCylDc = this->DebugLiftCylDc;
		txOut.DebugLiftCylRawExt = this->DebugLiftCylRawExt;
		txOut.DebugLiftCylFiltExt = this->DebugLiftCylFiltExt;
		txOut.DebugLiftCylNormExt = this->DebugLiftCylNormExt;
		txOut.DebugLiftCylVel = this->DebugLiftCylVel;
		txOut.DebugLiftAngle = this->DebugLiftAngle;

		/* Tilt Cylinder */
		txOut.DebugTiltCylPeriod = this->DebugTiltCylPeriod;
		txOut.DebugTiltCylWidth = this->DebugTiltCylWidth;
		txOut.DebugTiltCylDc = this->DebugTiltCylDc;
		txOut.DebugTiltCylRawExt = this->DebugTiltCylRawExt;
		txOut.DebugTiltCylVel = this->DebugTiltCylVel;
		txOut.DebugTiltAngle = this->DebugTiltAngle;
		txOut.DebugTiltAngleABC = this->DebugTiltAngleABC;

		/* Broadcasting Weighing App elements */
		LpsSaWeighScsDebugOut->publish( txOut );
	}
	else
	{
		/* do nothing */
	}
}

/******************************************************************************
FUNCTION: PublishCalFromNvmPayload
DESCRIPTION: Prepares an SCS object with the key-on available calibration data and send the data out
PARAMETER DESCRIPTION: None
RETURN VALUE: None
*******************************************************************************/
void LpsSaWeighApp::PublishCalFromNvmPayload( void )
{
   LpsSaNvmCalDataChannel scsPayload; // Default constructor clears the initial container
   LOG_NOTICE("Populating SCS object with key-on NVM calibration data");

   memcpy(scsPayload.lps_sa_nvm_calibration_data_main.raise_slow_empty_lift_heights,
          LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.SlowRaiseEmptyBktLiftHt,
          sizeof(scsPayload.lps_sa_nvm_calibration_data_main.raise_slow_empty_lift_heights));
   memcpy(scsPayload.lps_sa_nvm_calibration_data_main.raise_slow_empty_pressures,
          LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.SlowRaiseEmptyBktLiftPres,
          sizeof(scsPayload.lps_sa_nvm_calibration_data_main.raise_slow_empty_pressures));
   memcpy(scsPayload.lps_sa_nvm_calibration_data_main.lower_slow_empty_lift_heights,
          LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.SlowLowerEmptyBktLiftHt,
          sizeof(scsPayload.lps_sa_nvm_calibration_data_main.lower_slow_empty_lift_heights));
   memcpy(scsPayload.lps_sa_nvm_calibration_data_main.lower_slow_empty_pressures,
          LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.SlowLowerEmptyBktLiftPres,
          sizeof(scsPayload.lps_sa_nvm_calibration_data_main.lower_slow_empty_pressures));
   memcpy(scsPayload.lps_sa_nvm_calibration_data_main.raise_slow_full_lift_heights,
          LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.SlowRaiseFullBktLiftHt,
          sizeof(scsPayload.lps_sa_nvm_calibration_data_main.raise_slow_full_lift_heights));
   memcpy(scsPayload.lps_sa_nvm_calibration_data_main.raise_slow_full_pressures,
          LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.SlowRaiseFullBktLiftPres,
          sizeof(scsPayload.lps_sa_nvm_calibration_data_main.raise_slow_full_pressures));
   memcpy(scsPayload.lps_sa_nvm_calibration_data_main.lower_slow_full_lift_heights,
          LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.SlowLowerFullBktLiftHt,
          sizeof(scsPayload.lps_sa_nvm_calibration_data_main.lower_slow_full_lift_heights));
   memcpy(scsPayload.lps_sa_nvm_calibration_data_main.lower_slow_full_pressures,
          LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.SlowLowerFullBktLiftPres,
          sizeof(scsPayload.lps_sa_nvm_calibration_data_main.lower_slow_full_pressures));
   scsPayload.lps_sa_nvm_calibration_data_main.raise_speed_empty_slow = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.EmptyBktSlowRaiseSpd;
   scsPayload.lps_sa_nvm_calibration_data_main.raise_speed_empty_fast = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.EmptyBktFastRaiseSpd;
   scsPayload.lps_sa_nvm_calibration_data_main.raise_fast_delta_p_empty = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.FastRaiseEmptyBktDeltaPres;
   scsPayload.lps_sa_nvm_calibration_data_main.raise_speed_full_slow = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.FullBktSlowRaiseSpd;
   scsPayload.lps_sa_nvm_calibration_data_main.raise_speed_full_fast = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.FullBktFastRaiseSpd;
   scsPayload.lps_sa_nvm_calibration_data_main.raise_fast_delta_p_full = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.FastRaiseFullBktDeltaPres;

   scsPayload.lps_sa_nvm_calibration_data_debug.lift_full_lower_DC_inf_value = static_cast<int_32>(LiftTiltMinMaxDc.LiftCylMinDc);
   scsPayload.lps_sa_nvm_calibration_data_debug.lift_full_raise_DC_inf_value = static_cast<int_32>(LiftTiltMinMaxDc.LiftCylMaxDc);
   scsPayload.lps_sa_nvm_calibration_data_debug.tilt_full_dump_DC_inf_value = static_cast<int_32>(LiftTiltMinMaxDc.TiltCylMinDc);
   scsPayload.lps_sa_nvm_calibration_data_debug.tilt_full_rack_DC_inf_value = static_cast<int_32>(LiftTiltMinMaxDc.TiltCylMaxDc);
   scsPayload.lps_sa_nvm_calibration_data_debug.pcs_cal_weight = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.Calwt;
   scsPayload.lps_sa_nvm_calibration_data_debug.zero_weight = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.ZeroWeight;
   scsPayload.lps_sa_nvm_calibration_data_debug.cal_adjust = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.CalAdjust;
   scsPayload.lps_sa_nvm_calibration_data_debug.empty_temp = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.EmptyTemp;
   scsPayload.lps_sa_nvm_calibration_data_debug.full_temp = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.FullTemp;
   scsPayload.lps_sa_nvm_calibration_data_debug.empty_bucket_weight_est = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.CalibTbl.EmptyBktWtEst;
   scsPayload.lps_sa_nvm_calibration_data_debug.hyd_oil_type_index = static_cast<int_32>(LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.HydOilType);

   /* The following fields are not yet populated:
    * lps_sa_nvm_calibration_data_debug.pcs_vel_slope
    * lps_sa_nvm_calibration_data_debug.temp_slope
    * lps_sa_nvm_calibration_data_debug.cal_adjust_temp
    */

   LpsNvmDumpChanOut->publish(scsPayload);
}

/******************************************************************************
FUNCTION: PublishCalOnTheFlyPayload
DESCRIPTION: Prepares an SCS object with the on-the-fly calibration data and send the data out
PARAMETER DESCRIPTION: None
RETURN VALUE: None
*******************************************************************************/
void LpsSaWeighApp::PublishCalOnTheFlyPayload( LpsCalStatus_t calStatusFlags )
{
   LpsSaNvmCalOnTheFlyDataChannel scsPayload; // Default constructor clears the initial container
   LOG_NOTICE("Populating SCS object with on-the-fly calibration data");

   scsPayload.lps_sa_nvm_calibration_data_on_the_fly.statusFlags.CalInProgress = calStatusFlags.CalInProgress;
   scsPayload.lps_sa_nvm_calibration_data_on_the_fly.statusFlags.PayloadCalFlag = calStatusFlags.PayloadCalFlag;
   scsPayload.lps_sa_nvm_calibration_data_on_the_fly.statusFlags.EmptyBktCalDone = calStatusFlags.EmptyBktCalDone;
   scsPayload.lps_sa_nvm_calibration_data_on_the_fly.statusFlags.FullBktCalDone = calStatusFlags.FullBktCalDone;

   scsPayload.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftHePres_Stat = weighUpdtTbl.LiftCylHePres.Stat;
   scsPayload.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftRePres_Stat = weighUpdtTbl.LiftCylRePres.Stat;
   scsPayload.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftCylExt_Stat = weighUpdtTbl.LiftCylExt.Stat;
   scsPayload.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.HydOilTemp_Stat = weighUpdtTbl.HydOilTemp.Stat;
   scsPayload.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftCylVel_Stat = weighUpdtTbl.LiftCylVel.Stat;
   scsPayload.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.TiltCylExt_Stat = weighUpdtTbl.TiltCylExt.Stat;
   scsPayload.lps_sa_nvm_calibration_data_on_the_fly.calUpdates.BktAngle_Stat = weighUpdtTbl.BktAngle.Stat;

   /* The following fields are not yet populated:
    * lps_sa_nvm_calibration_data_on_the_fly.curveInfo.HydOilTempMet
    * lps_sa_nvm_calibration_data_on_the_fly.curveInfo.EnforceRaiseDetent
    * lps_sa_nvm_calibration_data_on_the_fly.curveInfo.EnforceLowerDetent
    * lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseFastVelDone
    * lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseSlowFitDone
    * lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseFastFitDone
    * lps_sa_nvm_calibration_data_on_the_fly.curveInfo.LowerSlowFitDone
    * lps_sa_nvm_calibration_data_on_the_fly.curveInfo.InternalStep
    *
    * lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftLeverInfo_LeverInfoAvailable
    * lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftLeverInfo_Faulted
    */

   LpsNvmOnTheFlyDumpChanOut->publish(scsPayload);
}
