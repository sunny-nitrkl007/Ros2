/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaWeighApp.cpp
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  _LPS_SA_WEIGHAPP_H_
#include "LpsSaWeighApp.h"
#include <ksw.h>
#endif
#include <stdio.h>
/*******************************************************************************/
/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/

using namespace task;

/* This array holds the status of various requests received by Weighing App
   true -> Request received
   false-> Request not issued
 */
/******************************************************************************
FUNCTION NAME:getTaskImplementation
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
AbstractTaskCore* task::getTaskImplementation(void )
{
  static LpsSaWeighApp thisTask("LpsSaWeighApp");
  return &thisTask;
}

/******************************************************************************
FUNCTION NAME:LpsSaWeighApp
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
LpsSaWeighApp::LpsSaWeighApp( const std::string& taskName ):
    Task( taskName ),
    AisJhm2TxInputScs( NULL ),
    SEAStatusInScs (NULL),
    LpsCalCmdScsReqstIn( NULL ),
    LpsCalCmdScsRespOut ( NULL ),
    DataLinkDataInput_( NULL )
{
	LpsSaInitTbl = {0};
	LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_ZERO_INDX] = false;
    LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_BEST_BKT_RST_INDX] = false;
    LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_WEIGH_RANGE_INDX]= false;
    OelBootupFlag = FALSE;
    IsLiftCyCalibrated = FALSE;
    IsTiltCyCalibrated = FALSE;
    IsPayLoadMonSysCalibrated = FALSE;

	WeighPidTbl.PloadSysCalWtEntryReqStat = CAL_ENTRY_NOT_REQUIRED;

    getLogger().log_info( "LpsSaWeighApp::LpsSaWeighApp" );

}
/******************************************************************************
FUNCTION NAME:~LpsSaWeighApp
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
LpsSaWeighApp::~LpsSaWeighApp( )
{
}
/******************************************************************************
FUNCTION NAME:Initialize
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
bool LpsSaWeighApp::initialize( )
{
    getLogger().log_info( "LpsSaWeighApp::initialize" );

	/*Initializing default configuration parameters */
	LpsSaInitWeighTbl(&LpsSaInitTbl.WeighInitTbl);

	/*Starting up OEL layer */
	commInitialize();
		/*Reading parameters from NVM */
	NvmInitialize();

	if(LpsSaWeighNvmMachSpecificCfg.activeSimpleCalFactor > 0.0f && LpsSaWeighNvmMachSpecificCfg.activeSimpleCalFactor < 10.0f)
		activeSimpleCalFactor = LpsSaWeighNvmMachSpecificCfg.activeSimpleCalFactor;

	if(LpsSaWeighNvmMachSpecificCfg.updatedSimpleCalFactor > 0.0f && LpsSaWeighNvmMachSpecificCfg.updatedSimpleCalFactor < 10.0f)
		updatedSimpleCalFactor = LpsSaWeighNvmMachSpecificCfg.updatedSimpleCalFactor;
	

	storePressCount = 0;
	/*Initializing dependent libraries */
	InitRet = LpsSaInit(&LpsSaInitTbl);

    LOG_INFO( "BmiCdlTest::initialize" );

	if(LPS_SA_INIT_SUCCESS != InitRet)
	{
		LOG_ERROR( "\n Stanalone init failed error code = %d\n",InitRet );
		return(1);
	}
    /* Initialising SCS Channels */
    LpsSaJobMgrScsTxIn  		= dynamic_cast<LpsSaJobMgrTxChannelInput*>( InterfaceDb::fetch("LpsSaJobMgrTxChannelInput") );
	AisJhm2TxInputScs  			= dynamic_cast<AisJhm2TxChannelInput*>( InterfaceDb::fetch("AisJhm2TxChannelInput") );
	SEAStatusInScs 				= dynamic_cast<SEAStatusInput*>( InterfaceDb::fetch("SEAStatusInput") );
	LpsSaWeighScsReqstIn  		= dynamic_cast<LpsSaWeighReqstChannelInput*>( InterfaceDb::fetch("LpsSaWeighReqstChannelInput") );
    LpsSaWeighScsTxOut    		= dynamic_cast<LpsSaWeighTxChannelOutput*>( InterfaceDb::fetch("LpsSaWeighTxChannelOutput") );
    LpsSaWeighScsRespOut  		= dynamic_cast<LpsSaWeighRespChannelOutput*>( InterfaceDb::fetch("LpsSaWeighRespChannelOutput") );
    LpsSaWeighScsInitDebugOut  	= dynamic_cast<LpsSaWeighInitDebugChannelOutput*>( InterfaceDb::fetch("LpsSaWeighInitDebugChannelOutput") );
    LpsSaWeighScsDebugOut  		= dynamic_cast<LpsSaWeighDebugChannelOutput*>( InterfaceDb::fetch("LpsSaWeighDebugChannelOutput") );
    PwmIn  		     			= dynamic_cast<PwmInputChannelsInput*>( InterfaceDb::fetch("PwmInputChannelsInput") );
    MachineIn  		      		= dynamic_cast<MachineInput*>( InterfaceDb::fetch("MachineInput") );
    DataLinkDataInput_ 			= dynamic_cast<DataLinkDataInput*>( InterfaceDb::fetch("DataLinkDataInput") );
    LpsCalCmdScsReqstIn   		= dynamic_cast<LpsCalCmdReqstChannelInput*>( InterfaceDb::fetch("LpsCalCmdReqstChannelInput") );
    LpsCalCmdScsRespOut   		= dynamic_cast<LpsCalCmdRespChannelOutput*>( InterfaceDb::fetch("LpsCalCmdRespChannelOutput") );
    LpsNvmDumpChanOut 			= dynamic_cast<LpsSaNvmCalDataChannelOutput*>( InterfaceDb::fetch("LpsSaNvmCalDataChannelOutput") );
    LpsNvmOnTheFlyDumpChanOut 	= dynamic_cast<LpsSaNvmCalOnTheFlyDataChannelOutput*>( InterfaceDb::fetch("LpsSaNvmCalOnTheFlyDataChannelOutput") );
    LpsSaJobMgrScsReqstOut 		= dynamic_cast<LpsSaJobMgrReqstChannelOutput*>( InterfaceDb::fetch("LpsSaJobMgrReqstChannelOutput") );

	if ( !DataLinkDataInput_ )
	{
		LOG_ERROR( "DataLinkDataInput_ interface not defined" );
		return false;
	}

	if ( !LpsSaJobMgrScsReqstOut )
	{
		LOG_ERROR( "LpsSaJobMgrScsReqstOut interface not defined" );
		return (1);
	}

	if ( !SEAStatusInScs )
	{
		LOG_ERROR( "SEAStatusInput interface not defined" );
		return (1);
	}

    if(!LpsSaWeighScsTxOut)
    {
    	 LOG_ERROR( "Interface LpsSaWeighScsTxOut not configured." );
    	 return(1);
    }

    if(!LpsSaWeighScsRespOut)
    {
        LOG_ERROR( "Interface LpsSaWeighScsRespOut not configured." );
    	return(1);
    }

    if(!LpsSaWeighScsInitDebugOut)
    {
    	LOG_ERROR( "Interface LpsSaWeighScsInitDebugOut not configured." );
    	return(1);
    }
    else
    {
    	LpsSaWeighScsInitDebugTx();
    }

    if(!LpsSaWeighScsDebugOut)
    {
    	LOG_ERROR( "Interface LpsSaWeighScsDebugOut not configured." );
    	return(1);
    }

	if ( !LpsSaWeighScsReqstIn )
	{
        	LOG_ERROR( "Interface LpsSaWeighScsReqstIn not configured." );
        	return(1);
	}
	else
	{
		LpsCalCmdScsReqstIn->addNewDataSlot( boost::bind(&LpsSaWeighApp::LpsSaWeighCalReqstCallback, this ) );
	}	

	if ( !PwmIn )
	{
    	 LOG_ERROR( "Interface PwmIn not configured." );
		return(1);
	}

	if ( !MachineIn )
	{
    	 LOG_ERROR( "Interface MachineIn not configured." );
		return(1);
	}

	if ( !LpsSaJobMgrScsTxIn )
	{
    	 LOG_ERROR( "Interface LpsSaJobMgrScsTxIn not configured." );
		return(1);
	}
	
	if ( !AisJhm2TxInputScs )
	{
		LOG_ERROR( "Interface AisJhm2TxInputScs not configured." );
		return(1);
	}

	if ( !LpsCalCmdScsReqstIn )
	{
		//LpsCalCmdScsReqstIn->addNewDataSlot( boost::bind(&LpsSaWeighApp::LpsSaWeighReqstRead, this ) );
	    LOG_ERROR( "Interface LpsCalCmdScsReqstIn not configured." );
	    return(1);
	}
	
	if ( !LpsCalCmdScsRespOut )
	{
	  	LOG_ERROR( "Interface LpsCalCmdScsRespOut not configured." );
		return(1);
	}

   if ( (LpsNvmDumpChanOut == NULL) || (LpsNvmOnTheFlyDumpChanOut == NULL) )
   {
      LOG_ERROR("Failed to initialize NVM-to-SCS-to-XCP interfaces");
   }

    return true;
}

/******************************************************************************
FUNCTION NAME:executive
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
bool LpsSaWeighApp::executive( )
{
	getLogger().log_debug( "executive" );
	LpsSaUpdtErrorType_t updtRet;
	boolean txRet;

	static bool cal_data_published = false;
	if  (!cal_data_published) {
		/* Publish the key-on calibration data from NVM through SCS one-time for XCP app.
		 * We do this in the executive to guarantee that XCP app is already running */
		PublishCalFromNvmPayload();

		cal_data_published = true;
	}

	//LpsSaCheckForPIDWriteParam( );
	LpsSaWeighingScsRx();

	updtRet = LpsSaUpdt();

	if(LPS_SA_UPDT_SUCCESS != updtRet)
	{
		LOG_ERROR( "\n Standalone update failed error code = %d\n",updtRet);
	}

	txRet=LpsSaWeighingScsTx();
	if(LPS_SA_WEIGH_SUCCESS != txRet)
	{
		LOG_ERROR( "\n Standalone LpsSaWeighingScsTx failed error code = %d\n",txRet);
	}

	LpsSaWeighScsDebugTx();

	return true;
}


/******************************************************************************
FUNCTION NAME:LpsSaWeighReqstRead
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaWeighCalReqstCallback( )
{
 	LpsCalCmdReqstChannel calCmdReqCh;
	LpsCalCmdRespChannel calCmdRespCh;

	if (LpsCalCmdScsReqstIn->get( calCmdReqCh ))
	{
		/* Check if CalibrationRequest request received from JM App */
		if(true == calCmdReqCh.CalibrationRequest.CalibrationReqstFlag)
		{
			 getLogger().log_info("CalibrationRequest-came\n");
			/* Request received for Weighing App,set the request flag */
			LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_CAL_INDX] = TRUE;
			LpsSaWeighInfoTbl.Cal_id = calCmdReqCh.CalibrationRequest.Cal_id;
			LpsSaWeighInfoTbl.Calcmd = calCmdReqCh.CalibrationRequest.Calcmd;
			printf("Cal_ID:%d  Cal_Cmd:%d\n", calCmdReqCh.CalibrationRequest.Cal_id, calCmdReqCh.CalibrationRequest.Calcmd);
			memcpy(cal_iterm,calCmdReqCh.CalibrationRequest.CalIterm,sizeof(calCmdReqCh.CalibrationRequest.CalIterm));
			LOG_DEBUG("cal id %d calCmd %d\n",calCmdReqCh.CalibrationRequest.Cal_id,calCmdReqCh.CalibrationRequest.Calcmd);
			LOG_DEBUG("----CAL_MGR_KEY_CONT %d LineNo %d File %s\n", CAL_MGR_KEY_CONT, __LINE__, __FILE__);

   			calibrationUpdate();
 
	    	 	calCmdRespCh.CalibrationResp.RespCode=LPS_SA_CAL_SUCCESS;
	    	 	calCmdRespCh.CalibrationResp.CalResp=LpsSaWeighInfoTbl.CalResp;
			calCmdRespCh.CalibrationResp.error=LpsSaWeighInfoTbl.error;
			calCmdRespCh.CalibrationResp.stepNo=LpsSaWeighInfoTbl.stepNo;
			calCmdRespCh.CalibrationResp.warning=LpsSaWeighInfoTbl.warning;
			calCmdRespCh.CalibrationResp.EnableQualRead = LpsCalGetQualReadStatus();

printf("Rsp:%d  error:%d  step:%d  warn:%d  qr:%d\n", calCmdRespCh.CalibrationResp.CalResp, calCmdRespCh.CalibrationResp.error, calCmdRespCh.CalibrationResp.stepNo, calCmdRespCh.CalibrationResp.warning, calCmdRespCh.CalibrationResp.EnableQualRead);

			if (LpsCalCmdScsRespOut)
			{
				bool scsCmdRet=false;
				scsCmdRet = LpsCalCmdScsRespOut ->publish( calCmdRespCh );
				LOG_NOTICE( "\n Line no = %d,'LpsCalCmdScsRespOut' function return code = %d\n",__LINE__,scsCmdRet);
			}
			else
			{
				LOG_NOTICE( "LpsCalCmdScsRespOut is null.");
			}
		}
		else
		{
			/* Do nothing */
		}
	}
	return;
}

/******************************************************************************
FUNCTION NAME:LpsJobMgrTxRead
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsJobMgrTxRead( )
{
    LpsSaJobMgrTxChannel jobMgrIn;
    while ( LpsSaJobMgrScsTxIn->get( jobMgrIn ) )
    {
    	LpsSaWeighInfoTbl.PassCount=jobMgrIn.PassCount;
    	LpsSaWeighInfoTbl.LpsSaJobMgrAutoManualTipOffDumpState=jobMgrIn.LpsSaJobMgrAutoManualTipOffDumpState;

    	/* Receive standby state  from job manager */
    	LpsSaWeighInfoTbl.StandbyState=jobMgrIn.StandbyState;


    	LOG_NOTICE( "LpsJobMgrTxRead StandbyState %d",LpsSaWeighInfoTbl.StandbyState );
		
		if(0 == LpsSaWeighInfoTbl.PassCount)
		{
			activeSimpleCalFactor = updatedSimpleCalFactor;
		}
		
		if(storePressCount != jobMgrIn.storeCount)
		{
			sumOfAdjustedTruckWts = 0.0f;
			sumOfZeroedTruckWts = 0.0f;
			LOG_NOTICE( "\n #### Storebutton pressed. Adj = %f & Zeroed = %f \n",sumOfAdjustedTruckWts,sumOfZeroedTruckWts );
			storePressCount = jobMgrIn.storeCount;
		}	
		
		if(LpsSaWeighNvmMachSpecificCfg.activeSimpleCalFactor != activeSimpleCalFactor)
		{
			LpsSaWeighNvmMachSpecificCfg.activeSimpleCalFactor = activeSimpleCalFactor;
			LpsSaNvmWeighAppMachSpecificCfgWriteFlag = TRUE;
		}	

		LOG_NOTICE( "LpsJobMgrTxRead %i\n",LpsSaWeighInfoTbl.PassCount );
		LOG_NOTICE( "\n### activeSimpleCalFactor %f\n",activeSimpleCalFactor );	
		LOG_NOTICE( "\n ### updatedSimpleCalFactor = %f\n",updatedSimpleCalFactor);
		LOG_NOTICE( "\n ### sumOfAdjustedTruckWts = %f\n",sumOfAdjustedTruckWts);
		LOG_NOTICE( "\n ### sumOfZeroedTruckWts = %f\n",sumOfZeroedTruckWts);
    	LOG_NOTICE( "LpsSaWeighInfoTbl.LpsSaJobMgrAutoManualTipOffDumpState %i",LpsSaWeighInfoTbl.LpsSaJobMgrAutoManualTipOffDumpState );
    }
}

/******************************************************************************
FUNCTION LpsSaMachineRead
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaMachineRead( )
{
    /* Read from CDL */
    LpsSaBmiCdlRead( );

    KeyswitchIn = ksw_keyswitch_get();
}

/******************************************************************************
FUNCTION LpsSaBmiCdlRead
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaBmiCdlRead( )
{
	#define BMI_CDL_PID_HYD_OIL_TEMP 	0x0045
	LOG_INFO( "executive" );

	DataLinkData dlData;
	while (DataLinkDataInput_->get(dlData))
	{
		//print data
		LOG_INFO("");
		std::map<std::string, DataLinkParam> *dlDataMap = dlData.GetDataLinkDataMapPtr();
		for(std::map<std::string, DataLinkParam>::iterator it = dlDataMap->begin();
		            it != dlDataMap->end(); ++it)
		{
			const DataLinkParam& dlParam = it->second;
			LOG_INFO("DL type %d sid %x paramId %x  dsi %x ParamValue raw %d eng %f scaling %f offset %f units %d",
					dlParam.GetDataLinkType(), dlParam.GetSid(),
					dlParam.GetParamId(), dlParam.GetLastValueDsi(),
					dlParam.GetLastValue<float>(), dlParam.GetLastValueEng(),
					dlParam.GetScaling(), dlParam.GetOffset(),
					dlParam.GetUnits());

			if (DIAG_INACTIVE == LpsSaWeighInfoTbl.DiagState.flag.MachineModelNotSet)	// check Hyd-Oil--Temp DIAG only if we have selected a machine
			{
				/*Read the CDL data */
				if(BMI_CDL_PID_HYD_OIL_TEMP == dlParam.GetParamId())
				{
				    if (0 == dlParam.GetLastValueDsi() ) {
				        WeighPidTbl.HydOilTemp = (float)dlParam.GetLastValueEng();

				        /* clear flag to indicate good hydraulic oil temp */
        		            LpsSaWeighInfoTbl.DiagState.flag.HydraulicOilTempBad = DIAG_INACTIVE;
				    }
				    else {
				        WeighPidTbl.HydOilTemp = (float)HYDRAULIC_OIL_TEMP_MIN_VALID_DATA;  // which is -32736.0

				        /* set flag to indicate bad hydraulic oil temp */
			                LpsSaWeighInfoTbl.DiagState.flag.HydraulicOilTempBad = DIAG_ACTIVE;
				    }
				}
			}  // end of  if (DIAG_INACTIVE == LpsSaWeighInfoTbl.DiagState.flag.MachineModelNotSet)
		}
	}

	// measure cycle rate and print out rate every 100 cycles
	static int cn = 0;
	cn++;
	static TimeStamp ts;
	TimeStamp last = ts;
	ts= localhostNow();
	double cr = (ts - last).toDouble();

	if ( cn % 5 == 1)
	{
		LOG_INFO( "cycle rate is %lf hertz\n", 1.0 / cr );
	}


	return true;
}


/******************************************************************************
FUNCTION NAME:cleanup
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void  LpsSaWeighApp::cleanup( )
{
    getLogger().log_info( "LpsSaWeighApp::cleanup" );
    sleep(2);
	
	std::ifstream machineModelFp("/opt/etc/robot");
	std::string newMachineMSN;
	
	if(machineModelFp.good())
	{
		machineModelFp >> newMachineMSN;
		if(machineMSN.compare(newMachineMSN) != 0)
		{
			LpsSaWeighNvmCal.CalStat = 0; //reset all cals. so, operator needs to run all cals again to use payload system.
			memcpy(&LpsSaWeighNvmCal,&LpsSaWeighDefCal,sizeof(LpsSaWeighNvmCal));
			LpsSaNvmWeighAppCalWriteFlag = TRUE;
		}
	}
 
    while ((LpsSaNvmWeighAppMachSpecificCfgWriteFlag != FALSE) ||
    		(LpsSaNvmWeighAppZeroWtWriteFlag != FALSE) ||
    		(LpsSaNvmWeighAppCalWriteFlag != FALSE)||
    		(LpsSaLiftNvmWeighAppCalWriteFlag != FALSE)||
    		(LpsSaTiltNvmWeighAppCalWriteFlag != FALSE));

    LOG_NOTICE( "cleanup nvm_block_write success in keyoff" );

}



/******************************************************************************
FUNCTION NAME:cleanup
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/

void LpsSaWeighApp::UpdateEvents( void )
{

	if( LpsWeighGetTooHeavyToZero() && ( EVENT_INACTIVE == LpsSaWeighInfoTbl.EventState.flag.zeroTooHeavyEvnt) )
	 {
	    PayLdWtTooHeavyToZero cond1;
	 	setAutonomyCondition(cond1);
	 	LpsSaWeighInfoTbl.EventState.flag.zeroTooHeavyEvnt = EVENT_ACTIVE;
	    LOG_NOTICE( "zeroTooHeavyEvnt Activated: %d\n",LpsWeighGetZeroAdjStatus());
	 }
	 else if( (!LpsWeighGetTooHeavyToZero()) &&  (EVENT_ACTIVE == LpsSaWeighInfoTbl.EventState.flag.zeroTooHeavyEvnt) )
	 {
		clearAutonomyCondition<PayLdWtTooHeavyToZero>();
		LpsSaWeighInfoTbl.EventState.flag.zeroTooHeavyEvnt = EVENT_INACTIVE;
		LOG_NOTICE( "zeroTooHeavyEvnt De-activated: %d\n",LpsWeighGetZeroAdjStatus());
	 }
	 else
	 {
	 	 /* Do nothing */
	 }

 	 if ( (LPS_ZERO_UPDATE_TEMPERATURE_CHANGE_ZERO_REQUIRED == LpsWeighGetAutoZeroUpdateStatus()) && (EVENT_INACTIVE == LpsSaWeighInfoTbl.EventState.flag.ctrlSysNotZeroEvntTemp) )
	 {
		PayLdCtrlSysNotZeroed cond2;
		setAutonomyCondition(cond2);
		LpsSaWeighInfoTbl.EventState.flag.ctrlSysNotZeroEvntTemp = EVENT_ACTIVE;
	 	LOG_NOTICE( "Temperature change zero required Activated %d \n",LpsWeighGetAutoZeroUpdateStatus());
	 }
	 else if( (LPS_ZERO_UPDATE_TEMPERATURE_CHANGE_ZERO_REQUIRED != LpsWeighGetAutoZeroUpdateStatus()) && (EVENT_ACTIVE == LpsSaWeighInfoTbl.EventState.flag.ctrlSysNotZeroEvntTemp) )
	 {
	 	 clearAutonomyCondition<PayLdCtrlSysNotZeroed>();
	 	 LpsSaWeighInfoTbl.EventState.flag.ctrlSysNotZeroEvntTemp = EVENT_INACTIVE;
	 	 LOG_NOTICE( "Temperature change zero required De-activated %d \n",LpsWeighGetAutoZeroUpdateStatus());
	 }
	 else
	 {
		 /* Do nothing */
	 }

 	 if( (LPS_ZERO_UPDATE_TIMER_EXPIRED_ZERO_REQUIRED == LpsWeighGetAutoZeroUpdateStatus()) && (EVENT_INACTIVE == LpsSaWeighInfoTbl.EventState.flag.ctrlSysNotZeroEvntTime))
	 {
	 	 PayLdCtrlSysNotZeroed cond3;
	 	 setAutonomyCondition(cond3);
	 	 LpsSaWeighInfoTbl.EventState.flag.ctrlSysNotZeroEvntTime = EVENT_ACTIVE;
	 	 LOG_NOTICE( "Zero update timer expired required Activated %d\n",LpsWeighGetAutoZeroUpdateStatus());
	 }
	 else if( (LPS_ZERO_UPDATE_TIMER_EXPIRED_ZERO_REQUIRED != LpsWeighGetAutoZeroUpdateStatus()) && (EVENT_ACTIVE == LpsSaWeighInfoTbl.EventState.flag.ctrlSysNotZeroEvntTime))
	 {
	 	 clearAutonomyCondition<PayLdCtrlSysNotZeroed>();
	 	 LpsSaWeighInfoTbl.EventState.flag.ctrlSysNotZeroEvntTime = EVENT_INACTIVE;
	 	 LOG_NOTICE( " Zero update timer expired required De-activated %d\n",LpsWeighGetAutoZeroUpdateStatus());
	 }
	 else
	 {
	 	 /* Do nothing */
	 }

	 if((true == LpsWeighOverloadWarningActive()) && (EVENT_INACTIVE == LpsSaWeighInfoTbl.EventState.flag.overLoadLimitExceed) &&
		(OVR_LOAD_WARN_ENABLED == WeighPidTbl.PloadOvrloadWarnEn)
	    )
	 {
	 	 PayLdOverLdLimitExceeded cond4;
	 	 setAutonomyCondition(cond4);
	 	 LpsSaWeighInfoTbl.EventState.flag.overLoadLimitExceed = EVENT_ACTIVE;
	 	 LOG_NOTICE( " Over load Warning Actived  \n");
	 }
	 else if((true != LpsWeighOverloadWarningActive()) && (EVENT_ACTIVE == LpsSaWeighInfoTbl.EventState.flag.overLoadLimitExceed))
	 {
	 	  clearAutonomyCondition<PayLdOverLdLimitExceeded>();
	 	  LpsSaWeighInfoTbl.EventState.flag.overLoadLimitExceed = EVENT_INACTIVE;
	 	  LOG_NOTICE( "Over load Warning De-actived \n");
	  }
	 else
	 {
		 /* Do nothing */
	 }
}

bool LpsSaWeighApp::GetPayLoadMonSysCalStatus(void)
{
	if( true == GetLiftCylCalStatus() &&
		true == GetTiltCylCalStatus() &&
		true == GetPayloadCalStatus() )
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool LpsSaWeighApp::GetPayloadCalStatus(void)
{
	if(( CAL_EMPTY_BKT_CURVE_MASK & LpsSaWeighNvmCal.CalStat) &&
	   ( CAL_FULL_BKT_CURVE_MASK  & LpsSaWeighNvmCal.CalStat) &&
	   ( CAL_BKT_WT_MASK  & LpsSaWeighNvmCal.CalStat ))
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool LpsSaWeighApp::GetLiftCylCalStatus(void)
{
	if(LpsSaWeighNvmCal.CalStat & CAL_LIFT_LINKAGE_MASK)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool LpsSaWeighApp::GetTiltCylCalStatus(void)
{
	if(LpsSaWeighNvmCal.CalStat & CAL_TILT_LINKAGE_MASK)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool LpsSaWeighApp::GetCalWtRequired(void)
{
	LpsCalStatus_t		calStatus;
	LpsCalGetCalStatus(&calStatus);

	if(false == GetPayloadCalStatus())
	{
		if((LpsSaWeighNvmCal.CalStat & CAL_BKT_WT_MASK) != CAL_BKT_WT_MASK)
		{
			unsigned_16 CalStatFlags = (unsigned_16)(CAL_EMPTY_BKT_CURVE_MASK | CAL_FULL_BKT_CURVE_MASK | CAL_VELCAL);
			if((LpsSaWeighNvmCal.CalStat & CalStatFlags) == CalStatFlags)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	else if(true == calStatus.CalInProgress)
	{
		return false;
	}

	return false;
}


