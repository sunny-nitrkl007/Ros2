/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaInit.cpp
DESCRIPTION:This file provides the initialization routines for the application software
            for Stadalone LPS system.
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  _LPS_SA_WEIGHAPP_H_
#include "LpsSaWeighApp.h"
#endif

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/

/******************************************************************************
FUNCTION NAME:LpsSaInit
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/

boolean calFlg;
boolean CalNVMReinitFlag=FALSE;
LpsSaInitErrorType_t LpsSaWeighApp::LpsSaInit(LpsSaInitTbl_t *lpsSaInitTbl)
{

		LpsInitErrorTypes_t lpsWeighRet;

		if(NULL == lpsSaInitTbl)
		{
			return LPS_SA_INIT_CONFIG_ERROR;
		}

#ifdef DEBUG
	    fp = fopen ("/opt/tmp/outputFiles/Test_Points_Log.csv", "w+");
	    if (NULL == fp)
	    {
	       char alternate_path[80];
	       strcat(strncpy(alternate_path, getenv("HOME"), 60), "/Test_Points_Log.csv");

	       LOG_ERROR("Failed to open the CSV log file. Attempting to create %s", alternate_path);
	       fp = fopen (alternate_path, "w+");
	    }

	    if (NULL == fp)
	    {
	       LOG_FATAL("Unable to open Test_Points_Log.csv; skipping write on initialization");
	    }
	    else
	    {

		/* Test points log File Header */
		fprintf(fp, "Lift Cyl HE Period,Lift Cyl HE Width,Lift Cyl HE DC,Lift Cyl HE Press,\
	Lift Cyl RE Period,Lift Cyl RE Width,Lift Cyl RE DC,Lift Cyl RE Press,\
	Lift Cyl EXT Period,Lift Cyl EXT Width,Lift Cyl EXT Sensor DC,\
	Lift Cyl Raw EXT,Lift Cyl Filt EXT,Lift Cyl Norm EXT DC,Lift Cyl Norm Velocity,\
	Tilt Cyl EXT Period,Tilt Cyl EXT Width,Tilt Cyl EXT Sensor DC,\
	Tilt Cyl Raw EXT,Tilt Cyl  Velocity,Impl_Hyd Oil Temp,Impl_Bucket_Weight,Impl_Payload_Calc_Mathod,\
	LpsSa_Best_Bucket_Weight,LpsSa_Payload_Calc_Method\n");

	fprintf(fp,"1 micro-second/bit,1 micro-second/bit,Percentage,Kpa,\
	1 micro-second/bit,1 micro-second/bit,Percentage,Kpa,\
	1 micro-second/bit,1 micro-second/bit,Percentage,\
	millimeter,millimeter,Percentage,millimeter/sec,\
	1 micro-second/bit,1 micro-second/bit,Percentage,\
	millimeter,mm/sec,DegC,tonnes,1/bit,tonnes,1/bit\n");

	    }
	TestLogCount = 0;

#endif
		/* Assigning application table to pick respective machine kinematics map*/
		LpsSaAppNumber = lpsSaInitTbl->AppNumber;

		/* Loading NVM values for Start of weigh and End of Weigh library configuration */
		lpsSaInitTbl->WeighInitTbl.MachSpecificCfg.StartOfWeigh = LpsSaWeighNvmMachSpecificCfg.WeighRangeBottom;
		lpsSaInitTbl->WeighInitTbl.MachSpecificCfg.EndOfWeigh   = (LpsSaWeighNvmMachSpecificCfg.WeighRangeBottom +
																   LpsSaWeighNvmMachSpecificCfg.WeighRangeSize);

		LOG_NOTICE("\n LPS Weigh library Machine specific configs \n");

		LOG_NOTICE("\n MachSpecificCfg.StartOfWeigh = %f,MachSpecificCfg.EndOfWeigh = %f\n",
							  lpsSaInitTbl->WeighInitTbl.MachSpecificCfg.StartOfWeigh,
							  lpsSaInitTbl->WeighInitTbl.MachSpecificCfg.EndOfWeigh);

		/* Loading NVM values for zero weight  Weigh library configuration */

	lpsSaInitTbl->WeighInitTbl.MachSpecificCfg.CalibTbl.ZeroWeight = LpsSaNvmWeighAppNvmZeroWt;
	lpsSaInitTbl->WeighInitTbl.MachSpecificCfg.CalibTbl.Calwt = LpsSaWeighNvmMachSpecificCfg.CalWt;

	/* Initial value for hydraulic oil temp */
	WeighPidTbl.HydOilTemp = (float)HYDRAULIC_OIL_TEMP_MIN_VALID_DATA;  // which is -32736.0

	 WeighPidTbl.PloadOvrloadWarnEn = (PloadOvrloadWarnEn_t)LpsSaWeighNvmMachSpecificCfg.PloadOvrloadWarnEn;
	 WeighPidTbl.LastPloadWt = LpsSaWeighNvmMachSpecificCfg.LastPloadWt;
	 LpsSaWeighInfoTbl.LoaderBktPayldTrgtWt = weighUpdtTbl.LoaderBktPayldTrgtWt = LpsSaWeighNvmMachSpecificCfg.LoaderBktPloadTrgtWt;

	/* Always use fast filter for live weight since we do not have ground speed to determine
	 * how fast we are going. Using the fast filter will give us a weight quickly during
	 * tipoff, and will result in an inaccurate weight when in load and carry, which is less
	 * important */
	 weighUpdtTbl.UseFastFilter = TRUE;

	LOG_NOTICE("NEW CAL WEIGHT = %f \n", LpsSaWeighNvmMachSpecificCfg.CalWt);
	LOG_NOTICE("PloadOvrloadWarnEn = %x \n", WeighPidTbl.PloadOvrloadWarnEn);
	LOG_NOTICE("LAST PAYLOAD WEIGHT = %f \n", WeighPidTbl.LastPloadWt);
	LOG_NOTICE("LoaderBktPloadTrgtWt = %f \n", LpsSaWeighInfoTbl.LoaderBktPayldTrgtWt);
	LOG_NOTICE( "MachSpecificCfg.CalibTbl.ZeroWeight %f",lpsSaInitTbl->WeighInitTbl.MachSpecificCfg.CalibTbl.ZeroWeight);

		/* Loading NVM values for calibration values  Weigh library configuration */
		memcpy(&LpsSaWeighInfoTbl.CalInit.Nvm, &LpsSaWeighNvmCal, sizeof(LpsSaWeighInfoTbl.CalInit.Nvm));

		LOG_NOTICE("LpsSaWeighInfoTbl.CalInit.Nvm.Calwt %f \n",LpsSaWeighInfoTbl.CalInit.Nvm.Calwt);

		/* Loading LIFT/TILT NVM values for calibration values  Weigh library configuration */
		LiftTiltMinMaxDc.LiftCylMaxDc = (float)LpsSaWeighLiftNvmCal.lift_full_raise_dc;
		LiftTiltMinMaxDc.LiftCylMinDc = (float)LpsSaWeighLiftNvmCal.lift_full_lower_dc;
		LiftTiltMinMaxDc.TiltCylMaxDc = (float)LpsSaWeighTiltNvmCal.tilt_full_rack_dc;
		LiftTiltMinMaxDc.TiltCylMinDc = (float)LpsSaWeighTiltNvmCal.tilt_full_dump_dc;


		LpsSaWeighNvmCal.CalStat |= LpsSaWeighTiltNvmCal.tilt_cal_stat;
		LpsSaWeighNvmCal.CalStat |= LpsSaWeighLiftNvmCal.lift_cal_stat;

		LOG_NOTICE( "\nNVM LiftCylMaxDc %f", LiftTiltMinMaxDc.LiftCylMaxDc);
		LOG_NOTICE( "\nNVM LiftCylMinDc %f", LiftTiltMinMaxDc.LiftCylMinDc);
		LOG_NOTICE( "\nNVM TiltCylMaxDc %f", LiftTiltMinMaxDc.TiltCylMaxDc);
		LOG_NOTICE( "\nNVM TiltCylMinDc %f", LiftTiltMinMaxDc.TiltCylMinDc);


		/*copy the nvm values into weigh init table*/
		copyCalNVMValtoWeighInitTable(&lpsSaInitTbl->WeighInitTbl.MachSpecificCfg.CalibTbl);

		/* Initializing the LPS Weighing library */
		lpsWeighRet = LpsInit(&lpsSaInitTbl->WeighInitTbl);

		if(LPS_INIT_SUCCESS != lpsWeighRet)
		{
			 LOG_NOTICE( "\n LpsInit return code = %d \n",lpsWeighRet );
			return LPS_SA_INIT_DEPANDANT_LIBRARY_INIT_FAIL;
		}


		/* Initialsing filters library for low pass filter for
		 * lift cylinder velocity computation.
		 */
		 LiftCylVelLpFltConst.ts   = lpsSaInitTbl->WeighInitTbl.ExecRate;
		 LiftCylVelLpFltConst.cf   = LIFT_CYL_VEL_LP_FLT_CF;
		 LiftCylVelLpFltConst.init = FALSE;

		 /* Initialsing filters library for low pass filter for
		 * lift cylinder extension computation.
		 */
		 LiftCylExtLpFltConst.ts   = lpsSaInitTbl->WeighInitTbl.ExecRate;
		 LiftCylExtLpFltConst.cf   = LIFT_CYL_EXT_LP_FLT_CF;
		 LiftCylExtLpFltConst.init = FALSE;

		 /* Initialsing filters library for low pass filter for
		 * Tilt cylinder velocity computation.
		 */
		 TiltCylVelLpFltConst.ts   = lpsSaInitTbl->WeighInitTbl.ExecRate;
		 TiltCylVelLpFltConst.cf   = TILT_CYL_VEL_LP_FLT_CF;
		 TiltCylVelLpFltConst.init = FALSE;

		 LiftCylVelLpFltConst2.kff = LIFT_CYL_VEL_LP_FLT_KFF;
		 LiftCylVelLpFltConst2.init = FALSE;

		 TiltCylVelLpFltConst2.kff = TILT_CYL_VEL_LP_FLT_KFF;
		 TiltCylVelLpFltConst2.init = FALSE;

		 TiltCylDc.kff = LP_FLT_CF_TO_KFF( TILT_CYL_DC_LP_FLT_CF ,lpsSaInitTbl->WeighInitTbl.ExecRate);
		 TiltCylDc.init = FALSE;

		 LiftCylDc.kff = LP_FLT_CF_TO_KFF( TILT_CYL_DC_LP_FLT_CF ,lpsSaInitTbl->WeighInitTbl.ExecRate);
		 LiftCylDc.init = FALSE;

		 /* Initialize Payload installation and Enable status to Installed and Enabled,
		  * we do this so that the user does not see a pop up during initialization before
		  * the SEA status has been received from ACD */
		 LpsSaWeighInfoTbl.LpsSaPayloadSEAStatus = SCL_PRMSW_FEAT_STATUS_INSTALLED_ENABLED;

		 LpsSaWeighInfoTbl.FilterSettleDelay = 0;
//		 IsPayLoadMonSysCalibrated = GetPayLoadMonSysCalStatus();
//		 IsLiftCyCalibrated = GetLiftCylCalStatus();
//		 IsTiltCyCalibrated = GetTiltCylCalStatus();
		 //WeighPidTbl.LastPloadWt = LPS_CAL_LAST_PAYLOAD_WT_COND_NOT_MET_PID_DSI;
		// WeighPidTbl.PloadSysCalWtEntryReqStat = CAL_ENTRY_REQUIRED;
		 IsCalWtRequired = GetCalWtRequired();

		 if(true == IsCalWtRequired )
		 {
			 WeighPidTbl.PloadSysCalWtEntryReqStat = CAL_ENTRY_REQUIRED;
		 }
		 else
		 {
			 WeighPidTbl.PloadSysCalWtEntryReqStat = CAL_ENTRY_NOT_REQUIRED;
		 }
		 //initialize cal
		 CalLibInit();

		 LOG_NOTICE("LpsSaWeighNvmCal.CalStat %x\n", LpsSaWeighNvmCal.CalStat);

	 return LPS_SA_INIT_SUCCESS;
}

boolean LpsSaWeighApp::CalLibInit(void)
{
	LpsCalInit_t *calInitTbl = &LpsSaWeighInfoTbl.CalInit;
	calFlg = true;
	calInitTbl->Cfg.CalEnableFlg   = &calFlg;

	//should not pass original NVM reference to caln
	memcpy(&calInitTbl->Nvm,&LpsSaWeighNvmCal,sizeof(LpsCalNvmTbl_t));

	calInitTbl->Cfg.CalSlowRaiseCmd = 40;
	calInitTbl->Cfg.CalFastRaiseCmd = 100;
	calInitTbl->Cfg.CalSlowLowerCmd = -30;
	calInitTbl->Cfg.CalFastLowerCmd = -50;

	calInitTbl->Cfg.KgPerKpaAtMidExtension = LpsSaWeighInfoTbl.KgPerLiftKpaAtMidExtension; //0.925332325;//0.807422574;
	calInitTbl->Cfg.LiftCylHeKpaWithoutBktAtMidExtn = LpsSaWeighInfoTbl.LiftKpaNoBucketMidExtension;//1394.712036;//1598.385;
	calInitTbl->Cfg.ExecPeriodSec = LpsSaInitTbl.WeighInitTbl.ExecRate;

	calInitTbl->Cfg.LiftCylDiffLimits.RaiseCalPercDiffRangeLimit = 10;
	calInitTbl->Cfg.LiftCylDiffLimits.RaiseCalPercDiffAbsLimit = 2.0;
	calInitTbl->Cfg.LiftCylDiffLimits.LowerCalPercDiffRangeLimit = 1.0;
	calInitTbl->Cfg.LiftCylDiffLimits.LowerCalPercDiffAbsLimit = 2.0;

	calInitTbl->Cfg.QualReadEnableOrDisable = AppEnableDisableQualRead;
	calInitTbl->Cfg.UpdateNvm = AppUpdtCalNvmTbl;
	calInitTbl->Cfg.LpsCalGetAppCalOvCtrlFunc = AppGetCalOvCtrl;

	if (TRUE == LpsSaWeighInfoTbl.MachineModelNotSet)
	{
		calInitTbl->Cfg.MachineModelCfg = LPS_STATUS_BAD;
	}

	LpsCalInitErrorTypes_t calRet = LpsCalInit(calInitTbl);

    LOG_NOTICE("*************** LpsCalInit %d ", calRet);

	if(LPS_CAL_INIT_SUCCESS != calRet)
	{
		return false;
	}
	else
	{
		return true;
	}
}

void AppGetCalOvCtrl(boolean enable)
{
	return;
}

void AppEnableDisableQualRead(unsigned_8 Enable, signed_16* minvalue)
{
	return;
}

void AppUpdtCalNvmTbl(LpsCalNvmTbl_t CalNvmTbl)
{
	/* Updating NVM with the cal values*/

	unsigned short    tempCalStat;
	printf("AppUpdtCalNvmTbl NVM CB by lpscal lib\n ");

	tempCalStat = LpsSaWeighNvmCal.CalStat;
	memcpy(&LpsSaWeighNvmCal,&CalNvmTbl,sizeof(LpsCalNvmTbl_t));
	LpsSaWeighNvmCal.CalStat |= tempCalStat;
	LpsSaNvmWeighAppCalWriteFlag = TRUE;

	/*Enable Reinit flag*/
	CalNVMReinitFlag =TRUE;
	return;
}

/******************************************************************************
FUNCTION: NvmInitialize
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::NvmInitialize(void)
{

	/* Wait till OEL layer boot up*/
	while(FALSE == OelBootupFlag);

    /* Wait till NVM is read */
	while((FALSE == LpsSaNvmWeighAppMachSpecificCfgReadFlag) ||
			(FALSE == LpsSaNvmWeighAppZeroWtReadFlag) ||
			(FALSE == LpsSaNvmWeighAppCalReadFlag)||
			(FALSE == LpsSaTiltNvmWeighAppCalReadFlag)||
			(FALSE == LpsSaLiftNvmWeighAppCalReadFlag));

}
