/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaLinkageTables.cpp
DESCRIPTION: Functions required for select the appropriate map for selected application
             to calculate lift and tilt parameters
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  _LPS_SA_WEIGHAPP_H_
#include "LpsSaWeighApp.h"
#include <math.h>
#endif
/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
/*Normaising cylinder extension in millimeters to % of full cylinder extension */
#define NORM_CYL_EXTN(CYL_EXT,MAX_CYL_EXTN) (float_32) ((CYL_EXT/MAX_CYL_EXTN) * 100.0)

#define BKT_ANGLE_OFFSET    101.70

#define ABEF_TO_NORM_SENSOR(angle_ABEF) \
    (float_32)( ( ( ( angle_ABEF ) - 6.84 ) / \
                     ( 68.27 - 6.84 ) ) * \
                   ( 100 ) )
/* Tilt cylinder extension array elements 0 and 1 mapped with minimum and maximum limit */
#define KnmaticsTiltClExtMin 0
#define KnmaticsTiltClExtMax 1


/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/

/******************************************************************************
FUNCTION NAME: LpsSaLoadKinamaticsTbl
DESCRIPTION: This function reads the kinamatics table from the ruby file
PARAMETER DESCRIPTION: none
RETURN VALUE: none
*******************************************************************************/
void LpsSaWeighApp::LpsSaLoadKinamaticsTbl(void)
{

	ConfigSection rubyCfg;

	if (!getTaskParser().getSection("MachineSpecificConfig",rubyCfg))
	{
		LOG_ERROR("MachineSpecificConfig section not found");
	}

	ConfigSection *pRubyCfg = &rubyCfg;
	unsigned int i=0;

	linkage_table_cnfg.invertLiftDc = 0;	// default to NO INVERT
	pRubyCfg->get( "invertLiftDc", linkage_table_cnfg.invertLiftDc );
	LOG_NOTICE( "invertLiftDc %d",linkage_table_cnfg.invertLiftDc);

	linkage_table_cnfg.invertTiltDc = 0;	// default to NO INVERT
	pRubyCfg->get( "invertTiltDc", linkage_table_cnfg.invertTiltDc );
	LOG_NOTICE( "invertTiltDc %d",linkage_table_cnfg.invertTiltDc);

	if(pRubyCfg->get("inLiftDc", linkage_table_cnfg.inLiftDc))
	{
		linkage_table_cnfg.nLiftAngle = linkage_table_cnfg.inLiftDc.size();
		LOG_NOTICE("\n inLiftDc \n");
		for(i = 0; i < linkage_table_cnfg.nLiftAngle; i++)
		{
		  LOG_NOTICE("%f",linkage_table_cnfg.inLiftDc[i]);
		}
	 }
	 else
	 {
		 getLogger().log_error("inLiftDc read fail.");
	 }


	if(pRubyCfg->get("outLiftAngle", linkage_table_cnfg.outLiftAngle))
	{
		LOG_NOTICE("\n outLiftAngle \n");
		for(i = 0; i < linkage_table_cnfg.outLiftAngle.size(); i++)
		{
		  LOG_NOTICE("%f",linkage_table_cnfg.outLiftAngle[i]);
		}

	}
	else
	{
		getLogger().log_error("outLiftAngle read fail.");
	}

	if(pRubyCfg->get("inTiltDc", linkage_table_cnfg.inTiltDc))
	{

		LOG_NOTICE("\n inTiltDc \n");
		for(i = 0; i < linkage_table_cnfg.inTiltDc.size(); i++)
		{
			LOG_NOTICE("%f",linkage_table_cnfg.inTiltDc[i]);
		}

	}
	else
	{
		getLogger().log_error("inTiltDc read fail.");
	}

	if(pRubyCfg->get("outTiltAngle", linkage_table_cnfg.outTiltAngle))
	{

		LOG_NOTICE("\n outTiltAngle \n");
		for(i=0; i<linkage_table_cnfg.outTiltAngle.size(); i++)
		{
		  LOG_NOTICE("%f",linkage_table_cnfg.outTiltAngle[i]);
		}

	}
	else
	{
		getLogger().log_error("outTiltAngle read fail.");
	}

	if(pRubyCfg->get("inLiftAngle", linkage_table_cnfg.inLiftAngle))
	 {
		LOG_NOTICE("\n inLiftAngle \n");
		for(i=0; i<linkage_table_cnfg.inLiftAngle.size(); i++)
		{
		  LOG_NOTICE("%f",linkage_table_cnfg.inLiftAngle[i]);
		}

	 }
	 else
	 {
		 getLogger().log_error("inLiftAngle read fail.");
	 }
	 
	if(pRubyCfg->get("outLiftCylLen", linkage_table_cnfg.outLiftCylExt))
	{
		linkage_table_cnfg.nCylExt = linkage_table_cnfg.outLiftCylExt.size();
		LOG_NOTICE("\n outLiftCylLen \n");
		for(i=0; i<linkage_table_cnfg.nCylExt; i++)
		{
		  LOG_NOTICE(" %f",linkage_table_cnfg.outLiftCylExt[i]);
		}

	}
	else
	{
		getLogger().log_error("outLiftCylLen read fail.");
	}
	 
	if(pRubyCfg->get("xTiltAngle", linkage_table_cnfg.xTiltAngle))
	 {
		linkage_table_cnfg.nTiltAngle = linkage_table_cnfg.xTiltAngle.size();

		LOG_NOTICE("\n xTiltAngle \n");
		for(i = 0; i < linkage_table_cnfg.nTiltAngle; i++)
		{
		  LOG_NOTICE("%f",linkage_table_cnfg.xTiltAngle[i]);
		}

	 }
	 else
	 {
		 getLogger().log_error("xTiltAngle read fail.");
	 }

	if(pRubyCfg->get("yLiftAngle", linkage_table_cnfg.yLiftAngle))
	{
		LOG_NOTICE("\n yLiftAngle \n");
		for(i=0; i < linkage_table_cnfg.yLiftAngle.size(); i++)
		{
		  LOG_NOTICE("%f",linkage_table_cnfg.yLiftAngle[i]);
		}

	 }
	 else
	 {
		 getLogger().log_error("yLiftAngle read fail.");
	 }
	if(pRubyCfg->get("outTiltCylLen", linkage_table_cnfg.outTiltCylExt))
	 {
		linkage_table_cnfg.nTiltEntries = sqrt(linkage_table_cnfg.outTiltCylExt.size());
		linkage_table_cnfg.nLiftEntries = sqrt(linkage_table_cnfg.outTiltCylExt.size());

		LOG_NOTICE("\n outTiltCylLen \n");
		for(i=0; i<linkage_table_cnfg.outTiltCylExt.size(); i++)
		{
		  LOG_NOTICE("%f",linkage_table_cnfg.outTiltCylExt[i]);
		}

	 }
	 else
	 {
		 getLogger().log_error("outTiltCylLen read fail.");
	 }

	if(pRubyCfg->get("inTiltAngle", linkage_table_cnfg.inTiltAngle))
	 {
		LOG_NOTICE("\n inTiltAngle \n");
		for(i=0; i<linkage_table_cnfg.inTiltAngle.size(); i++)
		{
		  LOG_NOTICE("%f",linkage_table_cnfg.inTiltAngle[i]);
		}

	 }
	 else
	 {
		 getLogger().log_error("inTiltAngle read fail.");
	 }

	if(pRubyCfg->get("outBktAngle", linkage_table_cnfg.outBktAngle))
	 {
		 linkage_table_cnfg.nTiltToBktAngleEntries = linkage_table_cnfg.outBktAngle.size();

		 LOG_NOTICE("\n outBktAngle \n");

		  for(i=0; i<linkage_table_cnfg.nTiltToBktAngleEntries; i++)
		  {
			  LOG_NOTICE("%f",linkage_table_cnfg.outBktAngle[i]);
		  }

	 }
	 else
	 {
		 getLogger().log_error("outBktAngle read fail.");
	 }
	/*kinematic min and max tilte cyl ext */
	if(pRubyCfg->get("KnmaticsTiltCylLenMinMax", linkage_table_cnfg.KnmaticsTiltCylExtMinMax))
	 {

		LOG_NOTICE("\n KinamaticsTiltCylLenMin \n");
		for(i=0; i<linkage_table_cnfg.KnmaticsTiltCylExtMinMax.size(); i++)
		{
		  LOG_NOTICE("%f",linkage_table_cnfg.KnmaticsTiltCylExtMinMax[i]);
		}

	 }
	 else
	 {
		 getLogger().log_error("KnmaticsTiltCylLenMinMax read fail.");
	 }

	/*kinematic min and max tilt angle ABC limits in degrees */
	if(pRubyCfg->get("KnmaticsTiltAngleMinMax", linkage_table_cnfg.KnmaticsTiltAngleMinMax))
	{
		LOG_NOTICE("KnmaticsTiltAngleMinMax\n");
		for(i=0; i<linkage_table_cnfg.KnmaticsTiltAngleMinMax.size(); i++)
		{
		  LOG_NOTICE("%f",linkage_table_cnfg.KnmaticsTiltAngleMinMax[i]);
		}

	}
	else
	{
		getLogger().log_error("KnmaticsTiltAngleMinMax read fail.");
	}

	LOG_NOTICE( "nLiftEntries %i",linkage_table_cnfg.nLiftEntries );
	LOG_NOTICE( "nTiltEntries %i",linkage_table_cnfg.nTiltEntries );
	LOG_NOTICE( "nCylExt %i",linkage_table_cnfg.nCylExt );
	LOG_NOTICE( "nTiltAngle %i",linkage_table_cnfg.nTiltAngle );
	LOG_NOTICE( "nLiftAngle %i",linkage_table_cnfg.nLiftAngle);
	LOG_NOTICE( "nTiltToBktAngleEntries %i",linkage_table_cnfg.nTiltToBktAngleEntries );

}

/******************************************************************************
FUNCTION NAME: lpsSaGetLiftCylExt
DESCRIPTION: Calculates the lift cylinder extension from the given PWM duty cycle            
PARAMETER DESCRIPTION: float_32 liftCylExtDc                       
RETURN VALUE: LpsLiftCylExt_t liftCylExt           
*******************************************************************************/
LpsSaLiftCylExt_t LpsSaWeighApp::lpsSaGetLiftCylExt(float_32 liftCylExtDc)
{
    float_32 liftAngle;
	float_32 liftCylExtRaw;
	LpsSaLiftCylExt_t liftCylExt;
    
    if(NULL != linkage_table_cnfg.outLiftCylExt.data())
    {
        /* Convert duty cycle to lift angle */
        liftAngle = LpsLookup(liftCylExtDc, linkage_table_cnfg.inLiftDc.data(), linkage_table_cnfg.outLiftAngle.data(), linkage_table_cnfg.nLiftAngle);

        /* Convert lift angle to cylinder extension */
        liftCylExtRaw = (LpsLookup(liftAngle, linkage_table_cnfg.inLiftAngle.data(),
									   linkage_table_cnfg.outLiftCylExt.data(), linkage_table_cnfg.nCylExt));
		
		//cpm_filter_low_pass_filter(&LiftCylExtLpFltConst,liftCylExtRaw);
		
		liftCylExt.ExtVal = liftCylExtRaw; /*LiftCylExtLpFltConst.ystate;*/
		weighUpdtTbl.LiftCylPos = liftCylExt.ExtVal;
							 
		liftCylExt.PerExtVal = NORM_CYL_EXTN((liftCylExt.ExtVal - linkage_table_cnfg.outLiftCylExt[0]),
		                                     (linkage_table_cnfg.outLiftCylExt[linkage_table_cnfg.nCylExt -1] -
											  linkage_table_cnfg.outLiftCylExt[0])
											 );
        liftCylExt.Stat   = LPS_CYL_EXT_STAT_OK;
		
        DebugLiftCylRawExt  = liftCylExtRaw;
        DebugLiftCylFiltExt = liftCylExt.ExtVal;
        DebugLiftCylNormExt = liftCylExt.PerExtVal;
        DebugLiftAngle = liftAngle;
    }
    else
    {
        liftCylExt.PerExtVal = liftCylExt.ExtVal = 0;
		liftCylExt.Stat = LPS_CYL_EXT_STAT_BAD;
		//weighUpdtTbl.UseFilterDataFlag = FALSE;
    }
    return liftCylExt;
}

/******************************************************************************
FUNCTION NAME: lpsSaGetTiltCylExt
DESCRIPTION: Calculates the tilt cylinder extension from the given PWM duty cycle 
             values of lift and tilt cylider extension           
PARAMETER DESCRIPTION: float_32 liftCylExtDc, float_32 tiltCylExtDc                       
RETURN VALUE: LpsSaTiltCylExt_t TiltCylExtData            
*******************************************************************************/
LpsSaTiltCylExt_t LpsSaWeighApp::lpsSaGetTiltCylExt(float_32 liftCylExtDc, float_32 tiltCylExtDc)
{
    float_32 liftAngle, tiltAngle;
	LpsSaTiltCylExt_t TiltCylExtData;

    if(NULL != linkage_table_cnfg.outTiltCylExt.data())
    {

        /* Convert duty cycle to lift angle */
        liftAngle = LpsLookup(liftCylExtDc, linkage_table_cnfg.inLiftDc.data(), linkage_table_cnfg.outLiftAngle.data(), linkage_table_cnfg.nLiftAngle);
        tiltAngle = LpsLookup(tiltCylExtDc, linkage_table_cnfg.inTiltDc.data(), linkage_table_cnfg.outTiltAngle.data(), linkage_table_cnfg.nTiltAngle);

        /* Convert Tilt Angle to Tilt Angle ABC Percent of full cylinder extension angle */
		TiltCylExtData.PerTiltAngleABC = NORM_CYL_EXTN((tiltAngle - linkage_table_cnfg.KnmaticsTiltAngleMinMax[KnmaticsTiltClExtMin]),
												 (linkage_table_cnfg.KnmaticsTiltAngleMinMax[KnmaticsTiltClExtMax] - linkage_table_cnfg.KnmaticsTiltAngleMinMax[KnmaticsTiltClExtMin]));
		if (TiltCylExtData.PerTiltAngleABC > 100)
		{
			TiltCylExtData.PerTiltAngleABC = 100;
		}

		/* Convert  lift angle to cylinder extension */
		TiltCylExtData.TiltCylExt.Val = (LpsLookup2d(liftAngle, tiltAngle, linkage_table_cnfg.yLiftAngle.data(), linkage_table_cnfg.xTiltAngle.data(), linkage_table_cnfg.outTiltCylExt.data(), linkage_table_cnfg.nLiftEntries, linkage_table_cnfg.nTiltEntries));
		LOG_NOTICE("linkage titlecyleExtmin %f   %f ",linkage_table_cnfg.KnmaticsTiltCylExtMinMax[KnmaticsTiltClExtMin],linkage_table_cnfg.KnmaticsTiltCylExtMinMax[KnmaticsTiltClExtMax]);

		TiltCylExtData.PerExtVal = NORM_CYL_EXTN((TiltCylExtData.TiltCylExt.Val - linkage_table_cnfg.KnmaticsTiltCylExtMinMax[KnmaticsTiltClExtMin]),
												 (linkage_table_cnfg.KnmaticsTiltCylExtMinMax[KnmaticsTiltClExtMax] - linkage_table_cnfg.KnmaticsTiltCylExtMinMax[KnmaticsTiltClExtMin]));

		if (TiltCylExtData.PerExtVal > 100)
		{
			TiltCylExtData.PerExtVal = 100;
		}
												  		
		TiltCylExtData.BucketAngle.Val = liftAngle + LpsLookup(tiltAngle, linkage_table_cnfg.inTiltAngle.data(), linkage_table_cnfg.outBktAngle.data(), linkage_table_cnfg.nTiltToBktAngleEntries);

		TiltCylExtData.TiltCylExt.Stat = LPS_CYL_EXT_STAT_OK;
		TiltCylExtData.BucketAngle.Stat = LPS_BKT_ANGLE_STATUS_OK;

		DebugTiltAngle = tiltAngle;
		DebugTiltAngleABC = TiltCylExtData.PerTiltAngleABC;
		DebugTiltCylRawExt = TiltCylExtData.TiltCylExt.Val;
    }
    else
    {
        TiltCylExtData.TiltCylExt.Stat = LPS_CYL_EXT_STAT_BAD;
        TiltCylExtData.BucketAngle.Stat = LPS_BKT_ANGLE_STATUS_BAD;
        //weighUpdtTbl.UseFilterDataFlag = FALSE;
    }

    return TiltCylExtData;
}   
