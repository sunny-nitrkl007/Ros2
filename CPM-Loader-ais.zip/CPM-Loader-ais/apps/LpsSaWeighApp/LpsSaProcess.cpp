/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaProcess.cpp
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  _LPS_SA_WEIGHAPP_H_
#include "LpsSaWeighApp.h"
#endif

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/


/******************************************************************************
FUNCTION NAME:LpsSaNormaliseDc
DESCRIPTION:            
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
float_32 LpsSaWeighApp::LpsSaNormaliseDc(float_32 dc,float_32 maxdc,float_32 mindc)
{
  float_32 normdc;
  
  if(dc > maxdc)
  {
	/* If sensor duty cycle exceeds max cyclinder extension
       intialise to 100% duty cycle
	*/
	normdc = 100.0;
  }
  else if(dc < mindc)
  {
	/* If sensor duty cycle less than min cyclinder extension
       intialise to 0% duty cycle
	*/
	normdc = 0.0;
  }
  else
  {
	  normdc = ((dc - mindc)/(maxdc - mindc)) * 100.0;
  }

   LOG_DEBUG( "dc: %f  mindc:%f   maxdc:%f normdc:%f  ***********",dc, mindc, maxdc, normdc);

  return normdc;
}

/******************************************************************************
FUNCTION NAME:LpsSaHydPresTransferFunc
DESCRIPTION:            
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
LpsPresSensorInfo_t LpsSaWeighApp::LpsSaHydPresTransferFunc(int width,int period,HeadRodEndIdentifier_t HeadOrRodEnd)
{
    float_32 sensorFreq;/*Value between 400 t0 600*/
	float_32 sensorDc;/*Value between 5 to 90*/
	LpsPresSensorInfo_t presInfo;
	
	sensorFreq = CONVERT_PWM_COUNTS_TO_FREQ(period);
	sensorDc = CONVERT_PWM_COUNTS_TO_DC(width,period);

	if((sensorFreq > HYD_PRES_SENSOR_MAX_FREQ) ||
	   (sensorFreq < HYD_PRES_SENSOR_MIN_FREQ) ||
	   (sensorDc > HYD_PRES_SENSOR_MAX_DC ) ||
	   (sensorDc < HYD_PRES_SENSOR_MIN_DC)
	  )
   {
		presInfo.Stat = LPS_PRES_STATUS_BAD;
		presInfo.Val  = 0.0;
		WeighPidTbl.BktPayloadData = NOT_AVAILABLE;

		/* check if Frequency abnormal and set the diagnostics */
		if(LIFT_CYL_ROD_END_INPUT == HeadOrRodEnd)/*if Rod end  lift cyl input */
		{

			if(((sensorFreq > HYD_PRES_SENSOR_MAX_FREQ) ||
			   (sensorFreq < HYD_PRES_SENSOR_MIN_FREQ)) &&
				(DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftREFreqAbnormal)
			   )
			{
				LiftREFreqAbnormal setDiag;
				setAutonomyCondition(setDiag);
				LpsSaWeighInfoTbl.DiagState.flag.LiftREFreqAbnormal = DIAG_ACTIVE;
			}

			else if(((sensorFreq <= HYD_PRES_SENSOR_MAX_FREQ) &&
					(sensorFreq >= HYD_PRES_SENSOR_MIN_FREQ)) &&
					(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftREFreqAbnormal)
				  )
			{
				clearAutonomyCondition<LiftREFreqAbnormal>();
				LpsSaWeighInfoTbl.DiagState.flag.LiftREFreqAbnormal = DIAG_INACTIVE;
			}

			else
			{
				/*do nothing */
			}

			if((sensorDc < HYD_PRES_SENSOR_MIN_DC) &&
			   (DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftREVoltageBelow)
			  )
			{
				LiftREVoltageBelow setDiag;
				setAutonomyCondition(setDiag);
				LpsSaWeighInfoTbl.DiagState.flag.LiftREVoltageBelow = DIAG_ACTIVE;
				clearAutonomyCondition<LiftREVoltageAbove>();
				LpsSaWeighInfoTbl.DiagState.flag.LiftREVoltageAbove = DIAG_INACTIVE;
			}

			else if((sensorDc > HYD_PRES_SENSOR_MAX_DC) &&
					(DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftREVoltageAbove)
				   )
			{
				LiftREVoltageAbove setDiag;
				setAutonomyCondition(setDiag);
				LpsSaWeighInfoTbl.DiagState.flag.LiftREVoltageAbove = DIAG_ACTIVE;
				clearAutonomyCondition<LiftREVoltageBelow>();
				LpsSaWeighInfoTbl.DiagState.flag.LiftREVoltageBelow = DIAG_INACTIVE;
			}

			else
			{
				/*do nothing */
			}

		}

		else/*if Head end lift cyl input */
		{
			/* Check if frequency abnormal */
			if(((sensorFreq > HYD_PRES_SENSOR_MAX_FREQ) ||
				(sensorFreq < HYD_PRES_SENSOR_MIN_FREQ)) &&
				(DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftHEFreqAbnormal)
			   )
			{
				LiftHEFreqAbnormal setDiag;
				setAutonomyCondition(setDiag);
				LpsSaWeighInfoTbl.DiagState.flag.LiftHEFreqAbnormal = DIAG_ACTIVE;
			}

			else if(((sensorFreq <= HYD_PRES_SENSOR_MAX_FREQ) &&
					(sensorFreq >= HYD_PRES_SENSOR_MIN_FREQ)) &&
					(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftHEFreqAbnormal)
				  )
			{
				clearAutonomyCondition<LiftHEFreqAbnormal>();
				LpsSaWeighInfoTbl.DiagState.flag.LiftHEFreqAbnormal = DIAG_INACTIVE;
			}

			else
			{
				/*do nothing */
			}

			/* check if Duty cycle abnormal */
			if((sensorDc < HYD_PRES_SENSOR_MIN_DC) &&
				(DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftHEVoltageBelow )
			   )
			{
				LiftHEVoltageBelow setDiag;
				setAutonomyCondition(setDiag);
				LpsSaWeighInfoTbl.DiagState.flag.LiftHEVoltageBelow = DIAG_ACTIVE;
				clearAutonomyCondition<LiftHEVoltageAbove>();
				LpsSaWeighInfoTbl.DiagState.flag.LiftHEVoltageAbove = DIAG_INACTIVE;
			}

			else if((sensorDc > HYD_PRES_SENSOR_MAX_DC) &&
					(DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftHEVoltageAbove)
				    )
			{
				LiftHEVoltageAbove setDiag;
				setAutonomyCondition(setDiag);
				LpsSaWeighInfoTbl.DiagState.flag.LiftHEVoltageAbove = DIAG_ACTIVE;
				clearAutonomyCondition<LiftHEVoltageBelow>();
				LpsSaWeighInfoTbl.DiagState.flag.LiftHEVoltageBelow = DIAG_INACTIVE;
			}

			else
			{
				/*do nothing */
			}
		}


		return presInfo;
	 }

	/* Clear already rised  diagnostics */
     if(LIFT_CYL_ROD_END_INPUT == HeadOrRodEnd)
      {

    	 if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftREVoltageBelow)
    	 {
    		 LpsSaWeighInfoTbl.DiagState.flag.LiftREVoltageBelow = DIAG_INACTIVE;
    		 clearAutonomyCondition<LiftREVoltageBelow>();
    	 }

    	 else if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftREVoltageAbove)
    	 {
    		 clearAutonomyCondition<LiftREVoltageAbove>();
    		 LpsSaWeighInfoTbl.DiagState.flag.LiftREVoltageAbove = DIAG_INACTIVE;
    	 }

    	 if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftREFreqAbnormal)
		 {
			 clearAutonomyCondition<LiftREFreqAbnormal>();
			 LpsSaWeighInfoTbl.DiagState.flag.LiftREFreqAbnormal = DIAG_INACTIVE;
		 }
      }

     else/*if Head end lift cyl input */
     {

    	 if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftHEVoltageBelow)
		 {
			 LpsSaWeighInfoTbl.DiagState.flag.LiftHEVoltageBelow = DIAG_INACTIVE;
			 clearAutonomyCondition<LiftHEVoltageBelow>();
		 }

    	 else if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftHEVoltageAbove)
		 {
			 clearAutonomyCondition<LiftHEVoltageAbove>();
			 LpsSaWeighInfoTbl.DiagState.flag.LiftHEVoltageAbove = DIAG_INACTIVE;
		 }

		 if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftHEFreqAbnormal)
		 {
			 clearAutonomyCondition<LiftHEFreqAbnormal>();
			 LpsSaWeighInfoTbl.DiagState.flag.LiftHEFreqAbnormal = DIAG_INACTIVE;
		 }

     }
	   /* Computing sensor pressure in Kpa - limit at min/max pressures that the sensor supports
	    * This is done to avoid the pressures going negative after the scaling is applied
	    * */
	   presInfo.Val  = ((sensorDc - HYD_PRES_SENSOR_INTERCEPT)/HYD_PRES_SENSOR_SLOPE);

	   if (presInfo.Val > HYD_PRES_SENSOR_MAX_VALUE_KPA) {
		   presInfo.Val = HYD_PRES_SENSOR_MAX_VALUE_KPA;
	   }
	   else if (presInfo.Val < HYD_PRES_SENSOR_MIN_VALUE_KPA) {
		   presInfo.Val = HYD_PRES_SENSOR_MIN_VALUE_KPA;
	   }

	   presInfo.Stat = LPS_PRES_STATUS_OK;
	   WeighPidTbl.BktPayloadData = AVAILABLE;

	return presInfo;  
}

/******************************************************************************
FUNCTION NAME:LpsSaLiftCylVelTransferFunc
DESCRIPTION:            
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
LpsLiftCylVel_t LpsSaWeighApp::LpsSaLiftCylVelTransferFunc(LpsLiftCylExt_t liftCylExt)
{
   LpsLiftCylVel_t liftCylVel;
   static float prevLiftCylExt, prevPrevLiftCylExt = 0;
      
   if(LPS_CYL_EXT_STAT_BAD != liftCylExt.Stat)
   {
		/*cpm_filter_low_pass_filter(&LiftCylVelLpFltConst,liftCylExt.Val);*/

		/*liftCylVel.Val = LiftCylVelLpFltConst.yprimestate;
		liftCylVel.Stat = LPS_CYL_VEL_STATUS_OK;*/

		cpm_filter_low_pass_filter2(&LiftCylVelLpFltConst2,liftCylExt.Val);

		liftCylVel.Val = (LiftCylVelLpFltConst2.y - prevPrevLiftCylExt) / (2 * LiftCylVelLpFltConst.ts );
		liftCylVel.Stat = LPS_CYL_VEL_STATUS_OK;



   }
   else
   {
	   liftCylVel.Val  = 0.0;
	   liftCylVel.Stat = LPS_CYL_VEL_STATUS_BAD;


   }
   
   /* Store filtered lift cylinder extension values for next loop */
   prevPrevLiftCylExt = prevLiftCylExt;
   prevLiftCylExt = LiftCylVelLpFltConst2.y;

   return liftCylVel;
}

/******************************************************************************
FUNCTION NAME:LpsSaLiftCylExtTransferFunc
DESCRIPTION:            
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
LpsSaLiftCylExt_t LpsSaWeighApp::LpsSaLiftCylExtTransferFunc(int width,int period)
{
    float_32 liftCylExtDc;
    float_32 liftCylExtDcFilt;
	LpsSaLiftCylExt_t liftCylExt;
	float_32 sensorFreq;

    /* Convert PWM inputs to duty cycle */
    if (0 == linkage_table_cnfg.invertLiftDc)   // NO INVERT
    	liftCylExtDc = CONVERT_PWM_COUNTS_TO_DC(width,period);
    else
    	liftCylExtDc = (100 - CONVERT_PWM_COUNTS_TO_DC(width,period));

    sensorFreq = CONVERT_PWM_COUNTS_TO_FREQ(period);

    if((sensorFreq > CYL_POS_SENSOR_MAX_FREQ) ||
	    (sensorFreq < CYL_POS_SENSOR_MIN_FREQ) ||
		(liftCylExtDc > LIFT_TILT_CYL_MAX_DC ) ||
		(liftCylExtDc < LIFT_TILT_CYL_MIN_DC)
	  )
    {
    	liftCylExt.ExtVal = 0.0;
		liftCylExt.PerExtVal = 0.0;
		liftCylExt.Stat = LPS_CYL_EXT_STAT_BAD;

		/* Set diagnostics if lift Frequency is out of range */
		if(((sensorFreq > CYL_POS_SENSOR_MAX_FREQ) ||
			(sensorFreq < CYL_POS_SENSOR_MIN_FREQ)) &&
			(DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftLinkFreqAbnormal)
		  )
		{
			LiftLinkFreqAbnormal setDiag;
			setAutonomyCondition(setDiag);
			LpsSaWeighInfoTbl.DiagState.flag.LiftLinkFreqAbnormal = DIAG_ACTIVE;
		}

		else if(((sensorFreq <= CYL_POS_SENSOR_MAX_FREQ) &&
				(sensorFreq >= CYL_POS_SENSOR_MIN_FREQ)) &&
				(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftLinkFreqAbnormal)
			  )
		{
			clearAutonomyCondition<LiftLinkFreqAbnormal>();
			LpsSaWeighInfoTbl.DiagState.flag.LiftLinkOutOfCal = DIAG_INACTIVE;
		}

		else
		{
			/*do nothing */
		}

		/* Set diagnostics if lift duty cycle is out of range */
		if((liftCylExtDc > LIFT_TILT_CYL_MAX_DC) &&
			(DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftLinkFreqAbnormal)
		   )
		{
			LiftLinkVoltageAbove setDiag;
			setAutonomyCondition(setDiag);
			LpsSaWeighInfoTbl.DiagState.flag.LiftLinkVoltageAbove = DIAG_ACTIVE;
			clearAutonomyCondition<LiftLinkVoltageBelow>();
			LpsSaWeighInfoTbl.DiagState.flag.LiftLinkVoltageBelow = DIAG_INACTIVE;
		}

		else if((liftCylExtDc < LIFT_TILT_CYL_MIN_DC) &&
				(DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftLinkVoltageBelow)
				)
		{
			LiftLinkVoltageBelow setDiag;
			setAutonomyCondition(setDiag);
			LpsSaWeighInfoTbl.DiagState.flag.LiftLinkVoltageBelow = DIAG_ACTIVE;
			clearAutonomyCondition<LiftLinkVoltageAbove>();
			LpsSaWeighInfoTbl.DiagState.flag.LiftLinkVoltageAbove = DIAG_INACTIVE;
		}

		else
		{
			/*do nothing */
		}

		return liftCylExt;
	}

    /* Clear the diagnostics if both frequency and dutycycle ar in range */
    if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftLinkFreqAbnormal)
	{
		clearAutonomyCondition<LiftLinkFreqAbnormal>();
		LpsSaWeighInfoTbl.DiagState.flag.LiftLinkFreqAbnormal = DIAG_INACTIVE;
	}

    if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftLinkVoltageAbove)
    {
		clearAutonomyCondition<LiftLinkVoltageAbove>();
		LpsSaWeighInfoTbl.DiagState.flag.LiftLinkVoltageAbove = DIAG_INACTIVE;
    }

    else if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftLinkVoltageBelow)
    {
		clearAutonomyCondition<LiftLinkVoltageBelow>();
		LpsSaWeighInfoTbl.DiagState.flag.LiftLinkVoltageBelow = DIAG_INACTIVE;
    }

    else
	{
		/*do nothing */
	}

    /* Apply LPF on Dutycycle */
    cpm_filter_low_pass_filter2( &LiftCylDc, liftCylExtDc );
    liftCylExtDcFilt = LiftCylDc.y;

    DebugLiftCylDc = liftCylExtDcFilt;
	WeighPidTbl.LiftCylDc = liftCylExtDcFilt;
//	printf("/n LIFT DC %f % f/n ",WeighPidTbl.LiftCylDc,liftCylExtDc);
	/*Noramilse cylinder duty cycle*/
	liftCylExtDc = LpsSaNormaliseDc(liftCylExtDcFilt,LiftTiltMinMaxDc.LiftCylMaxDc,LiftTiltMinMaxDc.LiftCylMinDc);
	
    /* Convert duty cycle to cylider extension based on the map from selected application */
    liftCylExt  = lpsSaGetLiftCylExt(liftCylExtDc);

    return liftCylExt;
}

/******************************************************************************
FUNCTION NAME:LpsSaTiltCylExtTransferFunc
DESCRIPTION:            
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
LpsSaTiltCylExt_t LpsSaWeighApp::LpsSaTiltCylExtTransferFunc(int liftCylExtPwmWidth,int liftCylExtPwmPeriod,int tiltCylExtPwmWidth,int tiltCylExtPwmPeriod)
{
    float_32 liftCylExtDc,tiltCylExtDc;
    float_32 liftCylExtDcFilt,tiltCylExtDcFilt;
	LpsSaTiltCylExt_t tiltCylExt;
    
    /* Convert PWM inputs to duty cycle */
    if (0 == linkage_table_cnfg.invertLiftDc)   // NO INVERT
	    liftCylExtDc = CONVERT_PWM_COUNTS_TO_DC(liftCylExtPwmWidth,liftCylExtPwmPeriod);
    else
	    liftCylExtDc = (100 - CONVERT_PWM_COUNTS_TO_DC(liftCylExtPwmWidth,liftCylExtPwmPeriod));

    if (0 == linkage_table_cnfg.invertTiltDc)   // NO INVERT
	tiltCylExtDc = CONVERT_PWM_COUNTS_TO_DC(tiltCylExtPwmWidth,tiltCylExtPwmPeriod);
    else
	tiltCylExtDc = (100 - CONVERT_PWM_COUNTS_TO_DC(tiltCylExtPwmWidth,tiltCylExtPwmPeriod));

    float_32 sensorFreq = CONVERT_PWM_COUNTS_TO_FREQ(tiltCylExtPwmPeriod);

    if((sensorFreq > CYL_POS_SENSOR_MAX_FREQ) ||
    	    (sensorFreq < CYL_POS_SENSOR_MIN_FREQ) ||
    		(liftCylExtDc > LIFT_TILT_CYL_MAX_DC ) ||
    		(liftCylExtDc < LIFT_TILT_CYL_MIN_DC)
    	  )
    {
    	tiltCylExt.TiltCylExt.Stat = LPS_CYL_EXT_STAT_BAD;
		tiltCylExt.PerExtVal = 0.0;
		tiltCylExt.BucketAngle.Val = 0.0;
		tiltCylExt.BucketAngle.Stat = LPS_BKT_ANGLE_STATUS_BAD;

		/* Rise diagnostics for abnormal frequency */
		if(((sensorFreq > CYL_POS_SENSOR_MAX_FREQ) ||
			(sensorFreq < CYL_POS_SENSOR_MIN_FREQ)) &&
			(DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.TiltLinkFreqAbnormal)
		  )
		{
			TiltLinkFreqAbnormal setDiag;
			setAutonomyCondition(setDiag);
			LpsSaWeighInfoTbl.DiagState.flag.TiltLinkFreqAbnormal = DIAG_ACTIVE;
		}

		else if(((sensorFreq <= CYL_POS_SENSOR_MAX_FREQ) &&
			  (sensorFreq >= CYL_POS_SENSOR_MIN_FREQ)) &&
			  (DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.TiltLinkFreqAbnormal)
			 )
		{
			clearAutonomyCondition<TiltLinkFreqAbnormal>();
			LpsSaWeighInfoTbl.DiagState.flag.TiltLinkFreqAbnormal = DIAG_INACTIVE;
		}

		else
		{
			/*do nothing */
		}

		if((tiltCylExtDc > LIFT_TILT_CYL_MAX_DC) &&
			(DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.TiltLinkVoltageAbove)
		   )
		{
			TiltLinkVoltageAbove setDiag;
			setAutonomyCondition(setDiag);
			LpsSaWeighInfoTbl.DiagState.flag.TiltLinkVoltageAbove = DIAG_ACTIVE;
			clearAutonomyCondition<TiltLinkVoltageBelow>();
			LpsSaWeighInfoTbl.DiagState.flag.TiltLinkVoltageBelow = DIAG_INACTIVE;
		}

		else if((tiltCylExtDc < LIFT_TILT_CYL_MIN_DC) &&
				(DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.TiltLinkVoltageBelow)
				)
		{
			TiltLinkVoltageBelow setDiag;
			setAutonomyCondition(setDiag);
			LpsSaWeighInfoTbl.DiagState.flag.TiltLinkVoltageBelow = DIAG_ACTIVE;
			clearAutonomyCondition<TiltLinkVoltageAbove>();
			LpsSaWeighInfoTbl.DiagState.flag.TiltLinkVoltageAbove = DIAG_INACTIVE;
		}

		else
		{
			/*do nothing */
		}

		return tiltCylExt;
	}
    /* Clear the diagnostics if both frequency and dutycycle ar in range */

	if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.TiltLinkFreqAbnormal)
	{
		clearAutonomyCondition<TiltLinkFreqAbnormal>();
		LpsSaWeighInfoTbl.DiagState.flag.TiltLinkFreqAbnormal = DIAG_INACTIVE;
	}

	if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.TiltLinkVoltageAbove)
	{
		clearAutonomyCondition<TiltLinkVoltageAbove>();
		LpsSaWeighInfoTbl.DiagState.flag.TiltLinkVoltageAbove = DIAG_INACTIVE;
	}

	else if(DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.TiltLinkVoltageBelow)
	{
		clearAutonomyCondition<TiltLinkVoltageBelow>();
		LpsSaWeighInfoTbl.DiagState.flag.TiltLinkVoltageBelow = DIAG_INACTIVE;
	}

	else
	{
		/*do nothing */
	}

    /* Apply LPF to duty cycle */
    cpm_filter_low_pass_filter2(&TiltCylDc, tiltCylExtDc);
    liftCylExtDcFilt = LiftCylDc.y;	/* Lift DC has already been filtered */
    tiltCylExtDcFilt = TiltCylDc.y;
    
    DebugTiltCylDc = tiltCylExtDcFilt;

	WeighPidTbl.TiltCylDc=tiltCylExtDc;
//	printf("/n TILT  DC %f % f/n ",WeighPidTbl.TiltCylDc,tiltCylExtDc);
	/*Noramilse cylinder duty cycle*/
	liftCylExtDc = LpsSaNormaliseDc(liftCylExtDcFilt,LiftTiltMinMaxDc.LiftCylMaxDc,LiftTiltMinMaxDc.LiftCylMinDc);

    tiltCylExtDc = LpsSaNormaliseDc(tiltCylExtDcFilt,LiftTiltMinMaxDc.TiltCylMaxDc,LiftTiltMinMaxDc.TiltCylMinDc);

	/* Convert duty cycle to tilt cylinder extension(in percentage and millimeter)
       based on the machine specific maps
    */
	tiltCylExt = lpsSaGetTiltCylExt(liftCylExtDc,tiltCylExtDc);
    return tiltCylExt;
}

/******************************************************************************
FUNCTION NAME:LpsSaTiltCylVelTransferFunc
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
LpsTiltCylVel_t LpsSaWeighApp::LpsSaTiltCylVelTransferFunc(LpsTiltCylExt_t TiltCylExt)
{
   LpsTiltCylVel_t TiltCylVel;
   static float prevTiltCylExt, prevPrevTiltCylExt = 0;

   if(LPS_CYL_EXT_STAT_BAD != TiltCylExt.Stat)
   {
		/*cpm_filter_low_pass_filter(&TiltCylVelLpFltConst,TiltCylExt.Val);

		TiltCylVel.Val = TiltCylVelLpFltConst.yprimestate;
		TiltCylVel.Stat = LPS_CYL_VEL_STATUS_OK;*/

	   cpm_filter_low_pass_filter2(&TiltCylVelLpFltConst2,TiltCylExt.Val);

	   TiltCylVel.Val = (TiltCylVelLpFltConst2.y - prevPrevTiltCylExt) / (2 * TiltCylVelLpFltConst.ts );
	   TiltCylVel.Stat = LPS_CYL_VEL_STATUS_OK;


   }
   else
   {
	   TiltCylVel.Val  = 0.0;
	   TiltCylVel.Stat = LPS_CYL_VEL_STATUS_BAD;

   }

   /* Store filtered lift cylinder extension values for next loop */
   prevPrevTiltCylExt = prevTiltCylExt;
   prevTiltCylExt = TiltCylVelLpFltConst2.y;

   return TiltCylVel;
}
/******************************************************************************
FUNCTION NAME:LpsSaHydOilTempTransferFunc
DESCRIPTION:            
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
LpsHydOilTemp_t LpsSaWeighApp::LpsSaHydOilTempTransferFunc(void)
{
	LpsHydOilTemp_t hydOilTemp;
	
	/* Hydraulic oil temperature is hard coded in this version to 50 degC,Need to determine 
	   the input processing for the temperature sensor in future versions
	*/
	
	hydOilTemp.Val  = WeighPidTbl.HydOilTemp;
	hydOilTemp.Stat = LPS_HYD_OIL_TEMP_STATUS_OK;
	return hydOilTemp;
}

/******************************************************************************
FUNCTION ; CheckCalibrationStatus
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::CheckCalibrationStatus(void)
{

	if(FALSE == IsTiltCyCalibrated && ( DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.TiltLinkOutOfCal) )
	{
		TiltLinkCalibrationOut setDiag;
		setAutonomyCondition(setDiag);
		LpsSaWeighInfoTbl.DiagState.flag.TiltLinkOutOfCal = DIAG_ACTIVE;
	}

	else if((TRUE == IsTiltCyCalibrated) && (DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.TiltLinkOutOfCal))
	{
		clearAutonomyCondition<TiltLinkCalibrationOut>();
		LpsSaWeighInfoTbl.DiagState.flag.TiltLinkOutOfCal = DIAG_INACTIVE;
	}

	if((FALSE == IsLiftCyCalibrated) && ( DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftLinkOutOfCal))
	{
		LiftLinkCalibrationOut setDiag;
		setAutonomyCondition(setDiag);
		LpsSaWeighInfoTbl.DiagState.flag.LiftLinkOutOfCal = DIAG_ACTIVE;
	}

	else if((TRUE == IsLiftCyCalibrated) && (DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.LiftLinkOutOfCal))
	{
		clearAutonomyCondition<LiftLinkCalibrationOut>();
		LpsSaWeighInfoTbl.DiagState.flag.LiftLinkOutOfCal = DIAG_INACTIVE;
	}

	if((FALSE == IsPayLoadMonSysCalibrated) && ( DIAG_ACTIVE != LpsSaWeighInfoTbl.DiagState.flag.PayloadMonSystemOutOfCal))
	{
		PayloadMonCalibrationOut setDiag;
		setAutonomyCondition(setDiag);
		LpsSaWeighInfoTbl.DiagState.flag.PayloadMonSystemOutOfCal = DIAG_ACTIVE;
	}

	else if((TRUE == IsPayLoadMonSysCalibrated) && (DIAG_INACTIVE != LpsSaWeighInfoTbl.DiagState.flag.PayloadMonSystemOutOfCal))
	{
		clearAutonomyCondition<PayloadMonCalibrationOut>();
		LpsSaWeighInfoTbl.DiagState.flag.PayloadMonSystemOutOfCal = DIAG_INACTIVE;
	}
}

/******************************************************************************
FUNCTION NAME:LpsSaUpdateWeighingLib
DESCRIPTION:            
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
 LpsUpdtErrorTypes_t LpsSaWeighApp::LpsSaUpdateWeighingLib(PWM_Buffer_t InpBuff)
{
    boolean zeroButtonPress;
	LpsUpdtErrorTypes_t weighRet;
    LpsSaLiftCylExt_t  liftCylExt;
	LpsSaTiltCylExt_t  tiltCylExt;
    LpsLiftCylExt_t    liftCylExtVelComp;
    LpsTiltCylExt_t    tiltCylExtVelComp;

	/* Initialising Zero Button Status to not pressed by default*/
    zeroButtonPress = weighUpdtTbl.ZeroButtonPress = FALSE;
    weighUpdtTbl.CaptCylExtnRef = FALSE;
    /*Update the Loader payload Tatget Weight from info table*/

    weighUpdtTbl.LoaderBktPayldTrgtWt=LpsSaWeighInfoTbl.LoaderBktPayldTrgtWt;
	
	/* Check if request for Best Bucket Weight reset is received*/
    if(TRUE == LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_BEST_BKT_RST_INDX])
	{
    	/* Reset Best Bucket Weight*/
		LpsWeighResetBestAvailableBktWt();
		LpsSaScsSendReqstResponse(LPS_SA_WEIGH_SCS_REQST_BEST_BKT_RST_INDX,(unsigned char)LPS_SA_WEIGH_BEST_BKT_RST_SUCCESS);
	}
	/* Check if request for Zero Weight Adjust is received*/
	else if(TRUE == LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_ZERO_INDX])
	{
		/* Command Weigh Library for Zero Adjust or intimating*/
		/*  Weigh Library that Zero button is pressed on display by*/
		/*   operator*/

		zeroButtonPress = weighUpdtTbl.ZeroButtonPress = TRUE;
	}
	
	else
	{
		/* Do nothing*/
	}
    if (TRUE == LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_CAPT_CYL_EXTN_REF_INDX])
	{
	   weighUpdtTbl.CaptCylExtnRef = TRUE;
	   LpsSaScsSendReqstResponse(LPS_SA_WEIGH_SCS_REQST_CAPT_CYL_EXTN_REF_INDX,(unsigned char)LPS_SA_WEIGH_CAPT_CYL_EXTN_REF_SUCCESS);
	}

    /*  reweigh warning clearing */
    if (TRUE == LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_CLEAR_REWEIGH_WARNING_INDX])
	{
	   weighUpdtTbl.StandbyActiveState = FALSE;
	   LpsSaScsSendReqstResponse(LPS_SA_WEIGH_SCS_REQST_CLEAR_REWEIGH_WARNING_INDX,(unsigned char)LPS_SA_WEIGH_CAPT_CYL_EXTN_REF_SUCCESS);

	}
    LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn TooSlow = %d \n",LpsWrk.WrwTbl.ReweighWarn.TooSlow);
    LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn Stopped = %d \n",LpsWrk.WrwTbl.ReweighWarn.Stopped);
    LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn NotRacked = %d \n",LpsWrk.WrwTbl.ReweighWarn.NotRacked);
    LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn Jerky = %d \n",LpsWrk.WrwTbl.ReweighWarn.Jerky);
    LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn Inconsistent = %d \n",LpsWrk.WrwTbl.ReweighWarn.Inconsistent);
    LOG_NOTICE( "\n LpsWrk.WrwTbl.ReweighWarn RateOfChangeHi = %d \n",LpsWrk.WrwTbl.ReweighWarn.RateOfChangeHi);
    LOG_NOTICE( "\n LpsWrk.ZeroAdjTbl.AutoZeroStatus = %d \n", LpsWrk.ZeroAdjTbl.AutoZeroStatus);
    LOG_NOTICE( "\n LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed = %d \n",LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed);
    LOG_NOTICE( "\n LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjAutoTimeInterval = %d \n",LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjAutoTimeInterval);
    LOG_NOTICE( "\n LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjInitTimeInterval = %d \n",LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjInitTimeInterval);
    LOG_NOTICE( "\n LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed = %d \n",LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed);

    DebugLiftCylHePeriod = InpBuff.period[LIFT_CYL_HE_PRES_SENS_CH_NUM];
    DebugLiftCylHeWidth  = InpBuff.width[LIFT_CYL_HE_PRES_SENS_CH_NUM];
    DebugLiftCylRePeriod = InpBuff.period[LIFT_CYL_RE_PRES_SENS_CH_NUM];
    DebugLiftCylReWidth  = InpBuff.width[LIFT_CYL_RE_PRES_SENS_CH_NUM];

    DebugLiftCylPeriod = InpBuff.period[LIFT_CYL_POS_SENS_CH_NUM];
    DebugLiftCylWidth  = InpBuff.width[LIFT_CYL_POS_SENS_CH_NUM];

    DebugTiltCylPeriod = InpBuff.period[TILT_CYL_POS_SENS_CH_NUM];
    DebugTiltCylWidth  = InpBuff.width[TILT_CYL_POS_SENS_CH_NUM];

    CheckForFilterSettleTime();
	weighUpdtTbl.LiftCylHePres = LpsSaHydPresTransferFunc(InpBuff.width[LIFT_CYL_HE_PRES_SENS_CH_NUM],
								     					  InpBuff.period[LIFT_CYL_HE_PRES_SENS_CH_NUM]
																		 ,LIFT_CYL_HEAD_END_INPUT);


	weighUpdtTbl.LiftCylRePres = LpsSaHydPresTransferFunc(InpBuff.width[LIFT_CYL_RE_PRES_SENS_CH_NUM],
								     					  InpBuff.period[LIFT_CYL_RE_PRES_SENS_CH_NUM]
																		 ,LIFT_CYL_ROD_END_INPUT);

	 /*Conversion of Lift position sensor input to Lift cyclinder extension*/

	liftCylExt = LpsSaLiftCylExtTransferFunc(InpBuff.width[LIFT_CYL_POS_SENS_CH_NUM],
														  InpBuff.period[LIFT_CYL_POS_SENS_CH_NUM]
														 );

	/* Conversion of Tilt position sensor input to Tilt cyclinder extension*/

	tiltCylExt = LpsSaTiltCylExtTransferFunc(InpBuff.width[LIFT_CYL_POS_SENS_CH_NUM],
                                                          InpBuff.period[LIFT_CYL_POS_SENS_CH_NUM],
                                                          InpBuff.width[TILT_CYL_POS_SENS_CH_NUM],
                                                          InpBuff.period[TILT_CYL_POS_SENS_CH_NUM]
                                                         );

	LOG_INFO("\n keyswitch = %d",KeyswitchIn );

	if (!KeyswitchIn) {
	       // inhibit diagnostics
	       clearAutonomyCondition<TiltLinkFreqAbnormal>();
	       clearAutonomyCondition<TiltLinkVoltageAbove>();
	       clearAutonomyCondition<TiltLinkVoltageBelow>();
	       clearAutonomyCondition<LiftLinkFreqAbnormal>();
	       clearAutonomyCondition<LiftLinkVoltageAbove>();
	       clearAutonomyCondition<LiftLinkVoltageBelow>();
	       clearAutonomyCondition<LiftHEFreqAbnormal>();
	       clearAutonomyCondition<LiftHEVoltageAbove>();
	       clearAutonomyCondition<LiftHEVoltageBelow>();
	       clearAutonomyCondition<LiftREFreqAbnormal>();
	       clearAutonomyCondition<LiftREVoltageAbove>();
	       clearAutonomyCondition<LiftREVoltageBelow>();

	       LpsSaWeighInfoTbl.DiagState.Data = DIAG_INACTIVE;
	}


	DebugLiftCylHePress = weighUpdtTbl.LiftCylHePres.Val;
	DebugLiftCylRePress = weighUpdtTbl.LiftCylRePres.Val;
														 
	/* Assigning lift cylinder extension as percentage of full cylinder extension to weighing library*/
	weighUpdtTbl.LiftCylExt.Val  = liftCylExt.PerExtVal;
	weighUpdtTbl.LiftCylExt.Stat = liftCylExt.Stat;
	
	LpsSaWeighInfoTbl.LiftCylExt.Val  = weighUpdtTbl.LiftCylExt.Val;
	LpsSaWeighInfoTbl.LiftCylExt.Stat = (LpsSaWeighCylExtStat_t) weighUpdtTbl.LiftCylExt.Stat;

	/* Assigning lift cylinder extension in millimeters for velocity computation*/
	liftCylExtVelComp.Val = liftCylExt.ExtVal;
	liftCylExtVelComp.Stat = liftCylExt.Stat;
	
        LpsSaWeighInfoTbl.LiftCylExtMillimeter.Val = liftCylExtVelComp.Val;
	LpsSaWeighInfoTbl.LiftCylExtMillimeter.Stat = liftCylExtVelComp.Stat;

        if((unsigned_16)LpsSaWeighInfoTbl.LiftCylExtMillimeter.Stat == ((LpsCylExtStat_t) LPS_CYL_VEL_STATUS_BAD))
	{
	                /* When sensor is bad, FMI 9 is set for the PID */
	                LpsSaWeighInfoTbl.LiftCylExtMillimeter.Val = UNKNOWN2U + FMIIUA;
	}
	
	weighUpdtTbl.LiftCylVel  = LpsSaLiftCylVelTransferFunc(liftCylExtVelComp);	


	/* Assigning tilt cylinder extension in millimeters for velocity computation*/
	tiltCylExtVelComp.Val = tiltCylExt.TiltCylExt.Val;
	tiltCylExtVelComp.Stat = tiltCylExt.TiltCylExt.Stat;


	LpsSaWeighInfoTbl.TiltCylExtMillimeter.Val = tiltCylExtVelComp.Val;
	LpsSaWeighInfoTbl.TiltCylExtMillimeter.Stat = tiltCylExtVelComp.Stat;
	if((unsigned_16)LpsSaWeighInfoTbl.TiltCylExtMillimeter.Stat == ((LpsCylExtStat_t) LPS_CYL_VEL_STATUS_BAD))
	{
	                /* When sensor is bad, FMI 9 is set for the PID */
	                LpsSaWeighInfoTbl.TiltCylExtMillimeter.Val = UNKNOWN2U + FMIIUA;
	}

        weighUpdtTbl.TiltCylVel  = LpsSaTiltCylVelTransferFunc(tiltCylExtVelComp);

	/* Assigning tilt cylinder extension as percentage of full cylinder extension to weighing library*/
	weighUpdtTbl.TiltCylExt.Val  = tiltCylExt.PerExtVal;
	weighUpdtTbl.TiltCylExt.Stat = tiltCylExt.TiltCylExt.Stat;

	/* Assigning tilt angle ABC as percentage of full cylinder extension angle to weighing library*/
	weighUpdtTbl.TiltAngleABCPercent  = tiltCylExt.PerTiltAngleABC;

	/* Assigning Bucket Angle to weighing library*/
        weighUpdtTbl.BktAngle.Stat = tiltCylExt.BucketAngle.Stat;
        weighUpdtTbl.BktAngle.Val =  tiltCylExt.BucketAngle.Val;    	


        LpsSaWeighInfoTbl.BucketAngle.Stat = tiltCylExt.BucketAngle.Stat;
        LpsSaWeighInfoTbl.BucketAngle.Val =  tiltCylExt.BucketAngle.Val;                   
        if((int_16)LpsSaWeighInfoTbl.BucketAngle.Stat == ((LpsBktAngleStat_t) LPS_BKT_ANGLE_STATUS_BAD))
	{
		/* When sensor is bad, FMI 9 is set for the PID */
	        LpsSaWeighInfoTbl.BucketAngle.Val = (int_16) (UNKNOWN2S + FMIIUA);
	}	  

        DebugLiftCylVel = weighUpdtTbl.LiftCylVel.Val;
        DebugTiltCylVel = weighUpdtTbl.TiltCylVel.Val;

	/* Update SCS Tx variable for lift cylinder velocity*/
	LpsSaWeighInfoTbl.LiftCylVel.Stat = (LpsSaWeighLiftCylVelStat_t)weighUpdtTbl.LiftCylVel.Stat;
	LpsSaWeighInfoTbl.LiftCylVel.MilliPerSec = weighUpdtTbl.LiftCylVel.Val;
	
	/* Hydraulic oil temperature is hard coded in this version to 50 degC,Need to determine
	   the input processing for the temperature sensor in future versions*/
	weighUpdtTbl.HydOilTemp  = LpsSaHydOilTempTransferFunc();

	//DebugImplHydOilTemp = weighUpdtTbl.HydOilTemp.Val;
	DebugLpsSaBucketWeight = LpsSaWeighInfoTbl.BestBktWtInTonnes;
	DebugLpsSaPayloadCalcMethod = LpsSaWeighInfoTbl.PayloadCalcMeth;

       /* The following interface are inputs to zero feature functionality
       of weighing library.In this version of software its populated such that
       the feature is non functional.In future versions it will be updated with
       appropriate inputs*/

       weighUpdtTbl.ClockKeyonSec = GetSysMonotonicTime();

       /* Hardcoding requested gear to always forward,Need to discuss and decide
       on gear input strategy to weigh library in future versions of software */

       weighUpdtTbl.RequestedGear.Stat = LPS_REQUESTED_GEAR_STAT_OK;
       weighUpdtTbl.RequestedGear.Val = 1;
       weighUpdtTbl.PassCount =LpsSaWeighInfoTbl.PassCount;
       weighUpdtTbl.StandbyActiveState = (char)LpsSaWeighInfoTbl.StandbyState;
       LOG_NOTICE("\n LpsSaWeighInfoTbl.StandbyState  = %d \n",LpsSaWeighInfoTbl.StandbyState);
       weighUpdtTbl.AutoManulDumpStateActiveFlag = (LpsSaJobMgrAutoManualTipOffDumpState_t)LpsSaWeighInfoTbl.LpsSaJobMgrAutoManualTipOffDumpState;


       LOG_NOTICE("\n weighUpdtTbl.StandbyActiveState  = %d \n",weighUpdtTbl.StandbyActiveState);
	/* Updating Weigh Library with Inputs */
       weighRet = LpsUpdt(&weighUpdtTbl);
    /* Read All Pop Up Info including Zeroing Status (If Applicable) Once the Weigh library Updated */
    LpsSaWeighGetAllInfoPopUp(zeroButtonPress);

    LOG_NOTICE("\n LpsWrk.LpsStallDetect.LiftStallStat = %d",LpsWrk.LpsStallDetect.LiftStallStat );

    LOG_NOTICE("\n LpsWrk.LpsStallDetect.live_wt_stall = %d",LpsWrk.LpsStallDetect.live_wt_stall);
    LOG_NOTICE("\n LpsWrk.WrwTbl.WkTbl.ReweighPosted = %d",LpsWrk.WrwTbl.WkTbl.ReweighPosted);
    LOG_NOTICE("\n LpsWrk.LpsStallDetect.reset_stall_timer = %d",LpsWrk.LpsStallDetect.reset_stall_timer);
    LOG_NOTICE("\n LpsWrk.LpsStallDetect.stall_debounce_counter = %d",LpsWrk.LpsStallDetect.stall_debounce_counter);

    LOG_NOTICE("\n LpsWrk.LpsStallDetect.lift_pos_too_high = %d",LpsWrk.LpsStallDetect.lift_pos_too_high);

    LOG_NOTICE("\n LpsWrk.LpsStallDetect.lift_pos_too_low = %d",LpsWrk.LpsStallDetect.lift_pos_too_low);
    LOG_NOTICE("\n LpsWrk.LpsStallDetect.lift_pos_too_low = %d",LpsWrk.LpsStallDetect.payload_available);


    /* Check if Zero Adjust is requested/commanded to Weigh Library */
     if(TRUE == zeroButtonPress)
     {
    	 if(LPS_ZERO_UPDATE_SUCCESS == LpsWeighGetZeroAdjStatus())
         {
    		 /*  Updating NVM with the Zero weight value*/

    		LpsSaNvmWeighAppNvmZeroWt = LpsWeighGetZeroWeight();

    		LpsSaNvmWeighAppZeroWtWriteFlag = TRUE;

    	    LOG_NOTICE("\n Zeroed  Weight = %f\n",LpsSaNvmWeighAppNvmZeroWt);


            /* As Zero Adjust was sucessful send positive response/acknowlegement to
			   Job manager App */
    		 LpsSaScsSendReqstResponse(LPS_SA_WEIGH_SCS_REQST_ZERO_INDX,(unsigned char)LPS_SA_WEIGH_ZERO_SUCCESS);

    		 LOG_NOTICE( "\n Sent Positive response for Zero Adjust request \n" );

         }
         else
         {
	        /* As Zero Adjust was unsucessful send negative response/acknowlegement to
			   Job manager App */
        	 LpsSaScsSendReqstResponse(LPS_SA_WEIGH_SCS_REQST_ZERO_INDX,(unsigned char)LPS_SA_WEIGH_ZERO_FAIL);

        	 LOG_NOTICE( "\n Sent Negative response for Zero Adjust request \n" );

         }

     }

	 IsPayLoadMonSysCalibrated = GetPayLoadMonSysCalStatus();
	 IsLiftCyCalibrated = GetLiftCylCalStatus();
	 IsTiltCyCalibrated = GetTiltCylCalStatus();

	 IsCalWtRequired = GetCalWtRequired();
	 if(true == IsCalWtRequired )
	 {
		 WeighPidTbl.PloadSysCalWtEntryReqStat = CAL_ENTRY_REQUIRED;
	 }
	 else
	 {
		 WeighPidTbl.PloadSysCalWtEntryReqStat = CAL_ENTRY_NOT_REQUIRED;
	 }

     CheckCalibrationStatus();

    return weighRet;
}

PloadSysZeroStat_t LpsSaWeighApp::GetZeroStat(void)
{

	 WeighPidTbl.ZeroStat = NOT_ZEROED;
 	WeighPidTbl.ZeroedWt = LpsWeighGetZeroWeight();

 	if(WeighPidTbl.ZeroedWt >= 0.1)
	{

		WeighPidTbl.ZeroStat = ZEROED;

	}

	getLogger().log_info( "\n Zeroed  Weight = %f\n",WeighPidTbl.ZeroedWt);
	getLogger().log_info( "\n WeighPidTbl.ZeroStat = %d \n",WeighPidTbl.ZeroStat);
	getLogger().log_info("\n Zeroed  Weight = %f\n",WeighPidTbl.ZeroedWt);
 	return WeighPidTbl.ZeroStat;
 }

/******************************************************************************
 FUNCTION CheckForFilterSettleTime
 DESCRIPTION:
 PARAMETER DESCRIPTION:
 RETURN VALUE:
 *******************************************************************************/
 void LpsSaWeighApp::CheckForFilterSettleTime(void)
 {
 	weighUpdtTbl.UseFilterDataFlag = TRUE;
 	unsigned int reqDelay;
 	reqDelay = (LpsSaWeighInfoTbl.FilterTauDelay/(float)((float)(1000/LpsSaWeighInfoTbl.PwmcycleRate)/(float)1000))+1;
 	LOG_NOTICE( "\n requiredDelay = %i\n",reqDelay );

 	if(LpsSaWeighInfoTbl.FilterSettleDelay < reqDelay)
 	{
 		LpsSaWeighInfoTbl.FilterSettleDelay++;
 		weighUpdtTbl.UseFilterDataFlag = FALSE;
 		LOG_NOTICE( "\n UseFilterDataFlag == FALSE \n" );
 	}
 	else
 	{
 		//filterSettledelay = 0;
 		//LpsSaWeighInfoTbl.PressureStatusBad = FALSE;
 		LOG_NOTICE( "\n UseFilterDataFlag == TRUE \n" );
 	}

 }

void LpsSaWeighApp::LpsSaChkWeighRangeConfig(float_32 weighRangeBottom,float_32 weighRangeSize)
{
	float_32 startOfWeigh = 0;
	float_32 endOfWeigh = 0;
	float_32 currWeighRange = 0;

	if( (LPS_IN_WEIGH_RANGE_WEIGHING != LpsWeighGetWeighRangeIndicator()) &&
		(LPS_IN_WEIGH_RANGE_NOT_WEIGHING != LpsWeighGetWeighRangeIndicator())
	  )
	 {
		currWeighRange = (LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.EndOfWeigh -
						  LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.StartOfWeigh);

		if(weighRangeBottom < MIN_WEIGH_RANGE_START)
		{
			startOfWeigh = MIN_WEIGH_RANGE_START;
			endOfWeigh   = (startOfWeigh + currWeighRange);
		}
		else if(MAX_WEIGH_RANGE_END < (weighRangeBottom + currWeighRange))
		{
			startOfWeigh = (MAX_WEIGH_RANGE_END - currWeighRange);
			endOfWeigh   =  MAX_WEIGH_RANGE_END;
		}
		else
		{
			startOfWeigh = weighRangeBottom;
			endOfWeigh   = LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.EndOfWeigh;
		}

		if( MAX_WEIGH_RANGE_END < (startOfWeigh + weighRangeSize))
		{
			endOfWeigh = MAX_WEIGH_RANGE_END;
		}
		else if(MIN_WEIGH_RANGE_SIZE > weighRangeSize)
		{
			if(MAX_WEIGH_RANGE_END < (startOfWeigh + MIN_WEIGH_RANGE_SIZE))
			{
				endOfWeigh = MAX_WEIGH_RANGE_END;
			}
			else
			{
				endOfWeigh = (startOfWeigh + MIN_WEIGH_RANGE_SIZE);
			}
		}
		else
		{
			endOfWeigh = (startOfWeigh + weighRangeSize);
		}

		LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.StartOfWeigh = startOfWeigh;
		LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.EndOfWeigh   = endOfWeigh;
	 }
}
/******************************************************************************
 FUNCTION NAME: LpsSaWeighGetAllInfoPopUp
 DESCRIPTION: Collects all info pop up information
 PARAMETER DESCRIPTION: boolean zeroReqstStat   (Zero Request by Operator)
 RETURN VALUE: None
 Author CWS ID: kathis2
 Last Modified: Nov 15, 2017
 *******************************************************************************/
void LpsSaWeighApp::LpsSaWeighGetAllInfoPopUp(boolean zeroReqstStat)
{
		LpsZeroErrorTypes_t zeroRespStat = LPS_ZERO_UPDATE_SUCCESS;
		LpsSaWeighInfoTbl.InfoState={0};
		LpsWeighWrwReweighStatus_t wrwReweighRetStat={0};

		/* Inhibiting the Lower Stall Condition For 5 Second duration */
		LOG_NOTICE( "\n\n\n CycleRate_hz = %f \n\n\n",LpsSaWeighInfoTbl.CycleRate_hz);

		if(LpsSalowerStallCounter >= (LOWER_STALL_KEY_ON_DELAY*LpsSaWeighInfoTbl.CycleRate_hz))
		{
			LpsSalowerStallDetectFlag=true;
		}

		wrwReweighRetStat=LpsGetWrwReweighWarning();

		if(TRUE == wrwReweighRetStat.TooSlow )
		{
			LpsSaWeighInfoTbl.InfoState.flag.ReWeighLiftTooSlow=true;
		}
		if(TRUE == wrwReweighRetStat.Stopped)
		{
			LpsSaWeighInfoTbl.InfoState.flag.ReWeighStoppedInWRG=true;
		}
		if(TRUE == wrwReweighRetStat.NotRacked)
		{
			LpsSaWeighInfoTbl.InfoState.flag.ReWeighBucketNotRacked=true;
		}
		if(TRUE == wrwReweighRetStat.Jerky) 			/* Speed Change Too High */
		{
			LpsSaWeighInfoTbl.InfoState.flag.ReWeighSpeedCHG2HI=true;
		}
		if(TRUE == wrwReweighRetStat.Inconsistent)
		{
			LpsSaWeighInfoTbl.InfoState.flag.ReWeighInconsistent=true;
		}
		if(TRUE == wrwReweighRetStat.RateOfChangeHi) 	/* Pressure Change Too High */
		{
			LpsSaWeighInfoTbl.InfoState.flag.ReWeighPressureCHG2HI=true;
		}

		if(TRUE == LpsWeighGetStallStat().UpperStall)
		{
			//LpsSaWeighInfoTbl.InfoState.flag.UpperStall=true;
		}
		if(TRUE ==  LpsWeighGetStallStat().LowerStall)
		{
			if(TRUE == LpsSalowerStallDetectFlag)
			{
				//LpsSaWeighInfoTbl.InfoState.flag.LowerStall=true;
			}
		}
		/* Upper Stall, Lower Stall and SIMPLE_CAL Pop Up Info to be added and modified here */
		/* zeroReqstStat shall be used if needed */
		zeroRespStat = LpsWeighGetZeroAcceptedStatus();
		if(TRUE == zeroRespStat)
		{
			LOG_ERROR("LastZeroTimerReset: %d \n", LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.LastZeroTimerReset);
			LOG_ERROR("ClockKeyonSec: %d \n", weighUpdtTbl.ClockKeyonSec);
			LOG_ERROR("ZeroAdjAutoTimeInterval: %d \n", LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjAutoTimeInterval);

		    LpsSaWeighInfoTbl.InfoState.flag.ZeroUpdateZeroAccepted=true;
			LOG_NOTICE( "\n\n\n INFO POP UP ZERO UPDATE DONE \n\n\n");

			/* Send zero request to JobMgr so it can clear truck and passcount */
			if (TRUE == zeroReqstStat) {
			    LpsSaScsSendZeroRqst();
			    LOG_NOTICE( "\n\n\n ZERO REQT SENT\n\n\n");
			}
		}
}

unsigned int LpsSaWeighApp::GetSysMonotonicTime()
{
	unsigned int currentTime;
	
	if(clock_gettime(CLOCK_MONOTONIC,&WeighZeroCurrentTime) != -1)
	{
	currentTime = WeighZeroCurrentTime.tv_sec;
	LOG_NOTICE( "currentTime: %d",currentTime);
	}
	else
	{
	LOG_NOTICE( "FetchingcurrentTime FAILED");
	currentTime = 0;
	}
	return currentTime;
}
