/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaCalibration.cpp
DESCRIPTION:This file provides the update routines for the application software
            for LPS library.
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  _LPS_SA_WEIGHAPP_H_
#include "LpsSaWeighApp.h"
#endif
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/

float_32  LpsWeighPtrDumpWtBuffer[WEIGH_LIB_DUMP_BUFF_SIZE];

unsigned_32 cal_iterm[(CAL_LAST_ITERM_BIT>>5)+1];   /* Default Cal Iterm */

/******************************************************************************
FUNCTION NAME: LpsSaLoadCalibrationTbl
DESCRIPTION: This function reads the calibration table from the ruby file
PARAMETER DESCRIPTION: none
RETURN VALUE: none
*******************************************************************************/
void LpsSaWeighApp::LpsSaLoadCalibrationTbl(void)
{

	ConfigSection rubyCfg, defCalCfg;

	if (!getTaskParser().getSection("MachineSpecificConfig",rubyCfg))
	{
		LOG_ERROR("MachineSpecificConfig section not found");
	}

	ConfigSection *pRubyCfg = &rubyCfg;
	unsigned int i=0;
	int temp;

	if(pRubyCfg->get("LiftCylExtPctAxis", CalibTblRuby.lift_cyl_ext_pct_axis))
	{
		LOG_NOTICE("\nLiftCylExtPctAxis\n");
		for(i=0; i<CalibTblRuby.lift_cyl_ext_pct_axis.size(); i++)
		{
		  LOG_NOTICE("%f",CalibTblRuby.lift_cyl_ext_pct_axis[i]);
		}

	}
	 else
	 {
		 getLogger().log_error("LiftCylExtPctAxis read fail.");
	 }

	if(pRubyCfg->get("TiltCompGainData", CalibTblRuby.tilt_comp_gain_data))
	{
 
		LOG_NOTICE("\nTiltCompGainData\n");
		for(i=0; i<CalibTblRuby.tilt_comp_gain_data.size(); i++)
		{
		  LOG_NOTICE("%f",CalibTblRuby.tilt_comp_gain_data[i]);
		}

	}
	 else
	 {
		 getLogger().log_error("TiltCompGainData read fail.");
	 }

	if(pRubyCfg->get("TiltCylExtPctAxis", CalibTblRuby.tilt_cyl_ext_pct_axis))
	{
		LOG_NOTICE("\nTiltCylExtPctAxis\n");
		for(i=0; i<CalibTblRuby.tilt_cyl_ext_pct_axis.size(); i++)
		{
		  LOG_NOTICE("%f",CalibTblRuby.tilt_cyl_ext_pct_axis[i]);
		}

	}
	 else
	 {
		 getLogger().log_error("TiltCylExtPctAxis read fail.");
	 }
	 
	 if (!getTaskParser().getSection("DefaultCalConfig",defCalCfg))
	 {
		 LOG_ERROR("DefaultCalConfig section not found");
	 }
	 else
	 {
		 pRubyCfg = &defCalCfg;
		 
		 pRubyCfg->get( "LiftCylMaxDc", LiftTiltMinMaxDc.LiftCylMaxDc);
		 LpsSaWeighDefLiftNvmCal.lift_full_raise_dc = LiftTiltMinMaxDc.LiftCylMaxDc;
		 
		 pRubyCfg->get( "LiftCylMinDc", LiftTiltMinMaxDc.LiftCylMinDc);
		 LpsSaWeighDefLiftNvmCal.lift_full_lower_dc = LiftTiltMinMaxDc.LiftCylMinDc;
		 
		 pRubyCfg->get( "TiltCylMaxDc", LiftTiltMinMaxDc.TiltCylMaxDc);
		 LpsSaWeighDefTiltNvmCal.tilt_full_rack_dc =	 LiftTiltMinMaxDc.TiltCylMaxDc;	
		 
		 pRubyCfg->get( "TiltCylMinDc", LiftTiltMinMaxDc.TiltCylMinDc);
		 LpsSaWeighDefTiltNvmCal.tilt_full_dump_dc =	 LiftTiltMinMaxDc.TiltCylMinDc;

		 LOG_NOTICE( "\nLiftCylMaxDc %f", LpsSaWeighDefLiftNvmCal.lift_full_raise_dc);
		 LOG_NOTICE( "\nLiftCylMinDc %f", LpsSaWeighDefLiftNvmCal.lift_full_lower_dc);
		 LOG_NOTICE( "\nTiltCylMaxDc %f", LpsSaWeighDefTiltNvmCal.tilt_full_rack_dc);
		 LOG_NOTICE( "\nTiltCylMinDc %f", LpsSaWeighDefTiltNvmCal.tilt_full_dump_dc);

		 pRubyCfg->get( "CalStat", temp);
		 LpsSaDefaultWeighCalibTbl.CalStat = (LpsWeighCalStatus_t)temp;

		 vector<float>   tempArr;
		 if(pRubyCfg->get("SlowRaiseEmptyBktLiftHt", tempArr))
		 {
			 std::copy(tempArr.begin(), tempArr.end(), LpsSaWeighDefCal.SlowRaiseEmptyBktLiftHt);

			 LOG_NOTICE("\nSlowRaiseEmptyBktLiftHt\n");
			 for(i=0; i<tempArr.size(); i++)
			 {
				 LOG_NOTICE("%f",LpsSaWeighDefCal.SlowRaiseEmptyBktLiftHt[i]);
			 }

		 }
		 else
		 {
			 getLogger().log_error("SlowRaiseEmptyBktLiftHt read fail.");
		 }

		 if(pRubyCfg->get("SlowRaiseEmptyBktLiftPres", tempArr))
		 {
			 std::copy(tempArr.begin(), tempArr.end(), LpsSaWeighDefCal.SlowRaiseEmptyBktLiftPres);

			 LOG_NOTICE("\nSlowRaiseEmptyBktLiftPres\n");
			 for(i=0; i<tempArr.size(); i++)
			 {
				 LOG_NOTICE("%f",LpsSaWeighDefCal.SlowRaiseEmptyBktLiftPres[i]);
			 }

		 }
		 else
		 {
			 getLogger().log_error("SlowRaiseEmptyBktLiftPres read fail.");
		 }

		 if(pRubyCfg->get("SlowRaiseFullBktLiftHt", tempArr))
		 {
			 std::copy(tempArr.begin(), tempArr.end(), LpsSaWeighDefCal.SlowRaiseFullBktLiftHt);

			 LOG_NOTICE("\nSlowRaiseFullBktLiftHt\n");
			 for(i=0; i<tempArr.size(); i++)
			 {
				 LOG_NOTICE("%f",LpsSaWeighDefCal.SlowRaiseFullBktLiftHt[i]);
			 }

		 }
		 else
		 {
			 getLogger().log_error("SlowRaiseFullBktLiftHt read fail.");
		 }

		 if(pRubyCfg->get("SlowRaiseFullBktLiftPres", tempArr))
		 {
			 std::copy(tempArr.begin(), tempArr.end(), LpsSaWeighDefCal.SlowRaiseFullBktLiftPres);

			 LOG_NOTICE("\nSlowRaiseFullBktLiftPres\n");
			 for(i=0; i<tempArr.size(); i++)
			 {
				 LOG_NOTICE("%f",LpsSaWeighDefCal.SlowRaiseFullBktLiftPres[i]);
			 }

		 }
		 else
		 {
			 getLogger().log_error("SlowRaiseFullBktLiftPres read fail.");
		 }

		 if(pRubyCfg->get("SlowLowerEmptyBktLiftHt", tempArr))
		 {
			 std::copy(tempArr.begin(), tempArr.end(), LpsSaWeighDefCal.SlowLowerEmptyBktLiftHt);

			 LOG_NOTICE("\nSlowLowerEmptyBktLiftHt\n");
			 for(i=0; i<tempArr.size(); i++)
			 {
				 LOG_NOTICE("%f",LpsSaWeighDefCal.SlowLowerEmptyBktLiftHt[i]);
			 }

		 }
		 else
		 {
			 getLogger().log_error("SlowLowerEmptyBktLiftHt read fail.");
		 }

		 if(pRubyCfg->get("SlowLowerEmptyBktLiftPres", tempArr))
		 {
			 std::copy(tempArr.begin(), tempArr.end(), LpsSaWeighDefCal.SlowLowerEmptyBktLiftPres);

			 LOG_NOTICE("\nSlowLowerEmptyBktLiftPres\n");
			 for(i=0; i<tempArr.size(); i++)
			 {
				 LOG_NOTICE("%f",LpsSaWeighDefCal.SlowLowerEmptyBktLiftPres[i]);
			 }

		 }
		 else
		 {
			 getLogger().log_error("SlowLowerEmptyBktLiftPres read fail.");
		 }

		 if(pRubyCfg->get("SlowLowerFullBktLiftHt", tempArr))
		 {
			 std::copy(tempArr.begin(), tempArr.end(), LpsSaWeighDefCal.SlowLowerFullBktLiftHt);

			 LOG_NOTICE("\nSlowLowerFullBktLiftHt\n");
			 for(i=0; i<tempArr.size(); i++)
			 {
				 LOG_NOTICE("%f",LpsSaWeighDefCal.SlowLowerFullBktLiftHt[i]);
			 }

		 }
		 else
		 {
			 getLogger().log_error("SlowLowerFullBktLiftHt read fail.");
		 }

		 if(pRubyCfg->get("SlowLowerFullBktLiftPres", tempArr))
		 {
			 std::copy(tempArr.begin(), tempArr.end(), LpsSaWeighDefCal.SlowLowerFullBktLiftPres);

			 LOG_NOTICE("\nSlowLowerFullBktLiftPres\n");
			 for(i=0; i<tempArr.size(); i++)
			 {
				 LOG_NOTICE("%f",LpsSaWeighDefCal.SlowLowerFullBktLiftPres[i]);
			 }

		 }
		 else
		 {
			 getLogger().log_error("SlowLowerFullBktLiftPres read fail.");
		 }
		 pRubyCfg->get( "FastRaiseEmptyBktDeltaPres", LpsSaDefaultWeighCalibTbl.FastRaiseEmptyBktDeltaPres);
		 LpsSaWeighDefCal.FastRaiseEmptyBktDeltaPres = LpsSaDefaultWeighCalibTbl.FastRaiseEmptyBktDeltaPres;

		 pRubyCfg->get( "FastRaiseFullBktDeltaPres", LpsSaDefaultWeighCalibTbl.FastRaiseFullBktDeltaPres);
		 LpsSaWeighDefCal.FastRaiseFullBktDeltaPres = LpsSaDefaultWeighCalibTbl.FastRaiseFullBktDeltaPres;

		 pRubyCfg->get( "EmptyBktSlowRaiseSpd", LpsSaDefaultWeighCalibTbl.EmptyBktSlowRaiseSpd);
		 LpsSaWeighDefCal.EmptyBktSlowRaiseSpd = LpsSaDefaultWeighCalibTbl.EmptyBktSlowRaiseSpd;

		 pRubyCfg->get( "EmptyBktFastRaiseSpd", LpsSaDefaultWeighCalibTbl.EmptyBktFastRaiseSpd);
		 LpsSaWeighDefCal.EmptyBktFastRaiseSpd = LpsSaDefaultWeighCalibTbl.EmptyBktFastRaiseSpd;

		 pRubyCfg->get( "FullBktSlowRaiseSpd", LpsSaDefaultWeighCalibTbl.FullBktSlowRaiseSpd);
		 LpsSaWeighDefCal.FullBktSlowRaiseSpd = LpsSaDefaultWeighCalibTbl.FullBktSlowRaiseSpd;

		 pRubyCfg->get( "FullBktFastRaiseSpd", LpsSaDefaultWeighCalibTbl.FullBktFastRaiseSpd);
		 LpsSaWeighDefCal.FullBktFastRaiseSpd = LpsSaDefaultWeighCalibTbl.FullBktFastRaiseSpd;

		 pRubyCfg->get( "Calwt", LpsSaDefaultWeighCalibTbl.Calwt);
		 LpsSaWeighDefCal.Calwt = LpsSaDefaultWeighCalibTbl.Calwt;
		 LpsSaWeighDefMachSpecificCfg.CalWt = LpsSaDefaultWeighCalibTbl.Calwt;

		 LpsSaDefaultWeighCalibTbl.TopOfLift = 100;

		 LpsSaDefaultWeighCalibTbl.BottomOfLift = 0;

		 LOG_NOTICE( "\nFastRaiseEmptyBktDeltaPres %f", LpsSaWeighDefCal.FastRaiseEmptyBktDeltaPres);
		 LOG_NOTICE( "\nFastRaiseFullBktDeltaPres %f", LpsSaWeighDefCal.FastRaiseFullBktDeltaPres);
		 LOG_NOTICE( "\nEmptyBktSlowRaiseSpd %f", LpsSaWeighDefCal.EmptyBktSlowRaiseSpd);
		 LOG_NOTICE( "\nEmptyBktFastRaiseSpd %f", LpsSaWeighDefCal.EmptyBktFastRaiseSpd);
		 LOG_NOTICE( "\nFullBktSlowRaiseSpd %f", LpsSaWeighDefCal.FullBktSlowRaiseSpd);
		 LOG_NOTICE( "\nFullBktFastRaiseSpd %f", LpsSaWeighDefCal.FullBktFastRaiseSpd);
		 LOG_NOTICE( "\nCalwt %f", LpsSaWeighDefCal.Calwt);

		 LOG_NOTICE( "\nTopOfLift %d", LpsSaDefaultWeighCalibTbl.TopOfLift);
		 LOG_NOTICE( "\nBottomOfLift %d ", LpsSaDefaultWeighCalibTbl.BottomOfLift);
	 }
}
/******************************************************************************
FUNCTION NAME:LpsSaInitWeighTbl
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaInitWeighTbl(LpsInitTbl_t *weighInitTbl)
{
    //weighInitTbl->InstallStat = TRUE;/* Lps Installed*/
    //weighInitTbl->ExecRate    = WEIGH_LIB_EXEC_RATE;/* Weighing library set to 20 msec execution rate */

    int temp;
    float weighRangeBottomtemp;
    float weighRangeSizetemp;
	float defaultSimpleCalFactor;

    ConfigSection rubyCfg, machineType;
    if (!getTaskParser().getSection("MachineSpecificConfig",rubyCfg))
	{
		LOG_ERROR("MachineSpecificConfig section not found");
	}
    
    /* Lps Installed*/
	getTaskConfig().get( "CPMInstallStat", weighInitTbl->InstallStat );
	LOG_NOTICE( "CPMInstallStat %d",weighInitTbl->InstallStat);
	/* Weighing library set to 20 msec execution rate */
	getTaskConfig().get( "CPMExecRate", weighInitTbl->ExecRate );
	LOG_NOTICE( "CPMExecRate %f",weighInitTbl->ExecRate);

	/* Weighing App set to 100 msec or 10.0 Hz execution rate */
	getTaskConfig().get( "cycleRate_hz", LpsSaWeighInfoTbl.CycleRate_hz);
	LOG_NOTICE( "cycleRate_hz %f",LpsSaWeighInfoTbl.CycleRate_hz);	
	
	getTaskConfig().get( "DefaultSimpleCalFactor", defaultSimpleCalFactor );
	LOG_NOTICE( "DefaultSimpleCalFactor %f",defaultSimpleCalFactor);
    
	LpsSaWeighDefMachSpecificCfg.activeSimpleCalFactor = defaultSimpleCalFactor;
	LpsSaWeighDefMachSpecificCfg.updatedSimpleCalFactor = defaultSimpleCalFactor;
	
	LpsSaWeighDefMachSpecificCfg.LastPloadWt = LPS_CAL_LAST_PAYLOAD_WT_COND_NOT_MET_PID_DSI;

    LpsSaLoadCalibrationTbl();

    /*Read machine spec config*/
     rubyCfg.get( "NoOfLiftCyls", weighInitTbl->MachSpecificCfg.NoOfLiftCyls );
     rubyCfg.get( "LiftCylBoreDia", weighInitTbl->MachSpecificCfg.LiftCylBoreDia );
     rubyCfg.get( "LiftCylRodDia", weighInitTbl->MachSpecificCfg.LiftCylRodDia );

     LOG_NOTICE( "NoOfLiftCyls %i",weighInitTbl->MachSpecificCfg.NoOfLiftCyls );
     LOG_NOTICE( "LiftCylBoreDia %f",weighInitTbl->MachSpecificCfg.LiftCylBoreDia );
     LOG_NOTICE( "LiftCylRodDia %f",weighInitTbl->MachSpecificCfg.LiftCylRodDia );


    rubyCfg.get( "HydOilType", temp );
    weighInitTbl->MachSpecificCfg.HydOilType = static_cast<LpsHydOilType_t>(temp);
    LOG_NOTICE( "HydOilType %i",weighInitTbl->MachSpecificCfg.HydOilType);


    /* Copying default Calibration Table */
    memcpy(&weighInitTbl->MachSpecificCfg.CalibTbl,&LpsSaDefaultWeighCalibTbl,sizeof(LpsCalib_t));

    /*Note :-
       Temperature compensation co-efficients are defaulted to zeros to provide no
       hydraulic oil temperature compensation
    */
    float tempCompCoeff;
    rubyCfg.get( "LiftCylHeLineLoss2ndOrdrCoeff", tempCompCoeff );
    weighInitTbl->MachSpecificCfg.HydPressLossCoeff.LiftCylHeLineLoss2ndOrdrCoeff = tempCompCoeff;
    rubyCfg.get( "LiftCylHeLineLoss1stOrdrCoeff", tempCompCoeff );
    weighInitTbl->MachSpecificCfg.HydPressLossCoeff.LiftCylHeLineLoss1stOrdrCoeff = tempCompCoeff;
    rubyCfg.get( "LiftCylReLineLoss2ndOrdrCoeff", tempCompCoeff );
    weighInitTbl->MachSpecificCfg.HydPressLossCoeff.LiftCylReLineLoss2ndOrdrCoeff = tempCompCoeff;
    rubyCfg.get( "LiftCylReLineLoss1stOrdrCoeff", tempCompCoeff );
    weighInitTbl->MachSpecificCfg.HydPressLossCoeff.LiftCylReLineLoss1stOrdrCoeff = tempCompCoeff;
    LOG_NOTICE( "LiftCylHeLineLoss2ndOrdrCoeff %f",weighInitTbl->MachSpecificCfg.HydPressLossCoeff.LiftCylHeLineLoss2ndOrdrCoeff);
    LOG_NOTICE( "LiftCylHeLineLoss1stOrdrCoeff %f",weighInitTbl->MachSpecificCfg.HydPressLossCoeff.LiftCylHeLineLoss1stOrdrCoeff);
    LOG_NOTICE( "LiftCylReLineLoss2ndOrdrCoeff %f",weighInitTbl->MachSpecificCfg.HydPressLossCoeff.LiftCylReLineLoss2ndOrdrCoeff);
    LOG_NOTICE( "LiftCylReLineLoss1stOrdrCoeff %f",weighInitTbl->MachSpecificCfg.HydPressLossCoeff.LiftCylReLineLoss1stOrdrCoeff);

    rubyCfg.get( "StartOfWeigh",weighRangeBottomtemp);
    rubyCfg.get( "EndOfWeigh",weighRangeSizetemp);

    LpsSaWeighDefMachSpecificCfg.WeighRangeBottom=weighRangeBottomtemp;
    LpsSaWeighDefMachSpecificCfg.WeighRangeSize=weighRangeSizetemp;

    LpsSaWeighDefMachSpecificCfg.WeighRangeSize = (LpsSaWeighDefMachSpecificCfg.WeighRangeSize - LpsSaWeighDefMachSpecificCfg.WeighRangeBottom);
    LOG_NOTICE( "StartOfWeigh %f",LpsSaWeighDefMachSpecificCfg.WeighRangeBottom);
    LOG_NOTICE( "EndOfWeigh %f",LpsSaWeighDefMachSpecificCfg.WeighRangeSize);

    /* Low Lift Weigh Configuration */
    rubyCfg.get( "FilterFactorMean", weighInitTbl->MachSpecificCfg.LlwTbl.FilterFactorMean);
    rubyCfg.get( "FilterFactorVariance", weighInitTbl->MachSpecificCfg.LlwTbl.FilterFactorVariance);
    rubyCfg.get( "ErrorBand", weighInitTbl->MachSpecificCfg.LlwTbl.ErrorBand);
    rubyCfg.get( "MinimumConfidenceTime", weighInitTbl->MachSpecificCfg.LlwTbl.MinimumConfidenceTime);
    rubyCfg.get( "AutoWeighRangeConfThr", weighInitTbl->MachSpecificCfg.LlwTbl.AutoWeighRangeConfThr);
    rubyCfg.get( "AutoWeighMinLiftHt", weighInitTbl->MachSpecificCfg.LlwTbl.AutoWeighMinLiftHt);
    rubyCfg.get( "WtCf", weighInitTbl->MachSpecificCfg.LlwTbl.WtCf);
    rubyCfg.get( "StageOneCf", weighInitTbl->MachSpecificCfg.LlwTbl.StageOneCf);
    rubyCfg.get( "StageTwoCf", weighInitTbl->MachSpecificCfg.LlwTbl.StageTwoCf);
    rubyCfg.get( "StageThreeCf", weighInitTbl->MachSpecificCfg.LlwTbl.StageThreeCf);
    rubyCfg.get( "DampingRate", weighInitTbl->MachSpecificCfg.LlwTbl.DampingRate);

    LOG_NOTICE( "FilterFactorMean %f",weighInitTbl->MachSpecificCfg.LlwTbl.FilterFactorMean);
    LOG_NOTICE( "FilterFactorVariance %f",weighInitTbl->MachSpecificCfg.LlwTbl.FilterFactorVariance);
    LOG_NOTICE( "ErrorBand %f",weighInitTbl->MachSpecificCfg.LlwTbl.ErrorBand);
    LOG_NOTICE( "MinimumConfidenceTime %f",weighInitTbl->MachSpecificCfg.LlwTbl.MinimumConfidenceTime);
    LOG_NOTICE( "AutoWeighRangeConfThr %f",weighInitTbl->MachSpecificCfg.LlwTbl.AutoWeighRangeConfThr);
    LOG_NOTICE( "AutoWeighMinLiftHt %f",weighInitTbl->MachSpecificCfg.LlwTbl.AutoWeighMinLiftHt);
    LOG_NOTICE( "WtCf %f",weighInitTbl->MachSpecificCfg.LlwTbl.WtCf);
    LOG_NOTICE( "StageOneCf %f",weighInitTbl->MachSpecificCfg.LlwTbl.StageOneCf);
    LOG_NOTICE( "StageTwoCf %f",weighInitTbl->MachSpecificCfg.LlwTbl.StageTwoCf);
    LOG_NOTICE( "StageThreeCf %f",weighInitTbl->MachSpecificCfg.LlwTbl.StageThreeCf);
    LOG_NOTICE( "DampingRate %f",weighInitTbl->MachSpecificCfg.LlwTbl.DampingRate);

    /* Zero weight configuration */
    //getTaskConfig().get( "ZeroBktWtAccuracyLimit", weighInitTbl->MachSpecificCfg.ZeroBktWtAccuracyLimit);
    rubyCfg.get( "ZeroBktWtAccuracyLimit", temp);
    weighInitTbl->MachSpecificCfg.ZeroBktWtAccuracyLimit = static_cast<LpsWeighBktWtAccuracy_t>(temp);
    rubyCfg.get( "ZeroRangeLimit", weighInitTbl->MachSpecificCfg.ZeroRangeLimit);
    rubyCfg.get( "ZeroAdjInitTimeInterval", weighInitTbl->MachSpecificCfg.ZeroAdjInitTimeInterval);
    rubyCfg.get( "ZeroAdjAutoTimeInterval", weighInitTbl->MachSpecificCfg.ZeroAdjAutoTimeInterval);
    rubyCfg.get( "ZeroAdjOilTempWarnThreshold", weighInitTbl->MachSpecificCfg.ZeroAdjOilTempWarnThreshold);

    LOG_NOTICE( "ZeroBktWtAccuracyLimit %d",weighInitTbl->MachSpecificCfg.ZeroBktWtAccuracyLimit);
    LOG_NOTICE( "ZeroRangeLimit %f",weighInitTbl->MachSpecificCfg.ZeroRangeLimit);
    LOG_NOTICE( "ZeroAdjInitTimeInterval %i",weighInitTbl->MachSpecificCfg.ZeroAdjInitTimeInterval);
    LOG_NOTICE( "ZeroAdjAutoTimeInterval %i",weighInitTbl->MachSpecificCfg.ZeroAdjAutoTimeInterval);
    LOG_NOTICE( "ZeroAdjOilTempWarnThreshold %f",weighInitTbl->MachSpecificCfg.ZeroAdjOilTempWarnThreshold);


    /* Tilt Comensation Config */

    rubyCfg.get( "TiltCompGainScalar", weighInitTbl->MachSpecificCfg.TiltComp.TiltCompGainScalar);
    rubyCfg.get( "TiltCompEmptyBktWtGain", weighInitTbl->MachSpecificCfg.TiltComp.TiltCompEmptyBktWtGain);
    rubyCfg.get( "TiltCompMaxGain", weighInitTbl->MachSpecificCfg.TiltComp.TiltCompMaxGain);
    //getTaskConfig().get( "NumColumns", weighInitTbl->MachSpecificCfg.TiltMap.NumColumns);
    //getTaskConfig().get( "NumRows", weighInitTbl->MachSpecificCfg.TiltMap.NumRows);

    weighInitTbl->MachSpecificCfg.TiltMap.NumColumns = CalibTblRuby.lift_cyl_ext_pct_axis.size();
    weighInitTbl->MachSpecificCfg.TiltMap.NumRows = CalibTblRuby.tilt_cyl_ext_pct_axis.size();

    weighInitTbl->MachSpecificCfg.TiltMap.ColumnAxis = CalibTblRuby.lift_cyl_ext_pct_axis.data();

    weighInitTbl->MachSpecificCfg.TiltMap.RowAxis = CalibTblRuby.tilt_cyl_ext_pct_axis.data();

    weighInitTbl->MachSpecificCfg.TiltMap.Data = CalibTblRuby.tilt_comp_gain_data.data();

    LOG_NOTICE( "TiltCompGainScalar %f",weighInitTbl->MachSpecificCfg.TiltComp.TiltCompGainScalar);
    LOG_NOTICE( "TiltCompEmptyBktWtGain %f",weighInitTbl->MachSpecificCfg.TiltComp.TiltCompEmptyBktWtGain);
    LOG_NOTICE( "TiltCompMaxGain %f",weighInitTbl->MachSpecificCfg.TiltComp.TiltCompMaxGain);
    LOG_NOTICE( "NumColumns %i",weighInitTbl->MachSpecificCfg.TiltMap.NumColumns);
    LOG_NOTICE( "NumRows %i",weighInitTbl->MachSpecificCfg.TiltMap.NumRows);


    rubyCfg.get( "DigTargetWt", weighInitTbl->MachSpecificCfg.DigConfig.DigTargetWt );
    rubyCfg.get( "DigDurationMaxLimit", weighInitTbl->MachSpecificCfg.DigConfig.DigDurationMaxLimit );
    rubyCfg.get( "DigDurationMinLimit", weighInitTbl->MachSpecificCfg.DigConfig.DigDurationMinLimit );
    rubyCfg.get( "DigStartLimit", weighInitTbl->MachSpecificCfg.DigConfig.DigStartLimit );
    rubyCfg.get( "DigEndLimit", weighInitTbl->MachSpecificCfg.DigConfig.DigEndLimit );
    rubyCfg.get( "LiftLowerVelocityLimit", weighInitTbl->MachSpecificCfg.DigConfig.LiftLowerVelocityLimit );

    LOG_NOTICE( "DigTargetWt %f",weighInitTbl->MachSpecificCfg.DigConfig.DigTargetWt);
    LOG_NOTICE( "DigDurationMaxLimit %f",weighInitTbl->MachSpecificCfg.DigConfig.DigDurationMaxLimit);
    LOG_NOTICE( "DigDurationMinLimit %f",weighInitTbl->MachSpecificCfg.DigConfig.DigDurationMinLimit);
    LOG_NOTICE( "DigStartLimit %f",weighInitTbl->MachSpecificCfg.DigConfig.DigStartLimit);
    LOG_NOTICE( "DigEndLimit %f",weighInitTbl->MachSpecificCfg.DigConfig.DigEndLimit);
    LOG_NOTICE( "LiftLowerVelocityLimit %f",weighInitTbl->MachSpecificCfg.DigConfig.LiftLowerVelocityLimit);

    rubyCfg.get( "TiltCylExtThreshold", weighInitTbl->MachSpecificCfg.DumpConfig.TiltCylExtThreshold );
    rubyCfg.get( "FullDumpBktAngleThreshold", weighInitTbl->MachSpecificCfg.DumpConfig.FullDumpBktAngleThreshold );
    rubyCfg.get( "PartDumpBktAngleThreshold", weighInitTbl->MachSpecificCfg.DumpConfig.PartDumpBktAngleThreshold );
    rubyCfg.get( "FullRackBktAngleThreshold", weighInitTbl->MachSpecificCfg.DumpConfig.FullRackBktAngleThreshold );
    rubyCfg.get( "TiltAngleABCThreshold", weighInitTbl->MachSpecificCfg.DumpConfig.TiltAngleABCThreshold );

    LOG_NOTICE( "TiltCylExtThreshold %f", weighInitTbl->MachSpecificCfg.DumpConfig.TiltCylExtThreshold);
    LOG_NOTICE( "FullDumpBktAngleThreshold %f", weighInitTbl->MachSpecificCfg.DumpConfig.FullDumpBktAngleThreshold);
    LOG_NOTICE( "PartDumpBktAngleThreshold %f", weighInitTbl->MachSpecificCfg.DumpConfig.PartDumpBktAngleThreshold);
    LOG_NOTICE( "FullRackBktAngleThreshold %f", weighInitTbl->MachSpecificCfg.DumpConfig.FullRackBktAngleThreshold);
    LOG_NOTICE( "TiltAngleABCThreshold %f", weighInitTbl->MachSpecificCfg.DumpConfig.TiltAngleABCThreshold);

    rubyCfg.get( "FastFiltWtCf" , weighInitTbl->MachSpecificCfg.LiveWeighConfig.FastFiltWtCf );
    rubyCfg.get( "SlowFiltWtCf" , weighInitTbl->MachSpecificCfg.LiveWeighConfig.SlowFiltWtCf );

	weighInitTbl->DumpWtBuffer.PtrDumpWtBuffer = LpsWeighPtrDumpWtBuffer;
	weighInitTbl->DumpWtBuffer.bufferSize = WEIGH_LIB_DUMP_BUFF_SIZE;

	/*Read Loader Payload Target Weight and store in info table ,use the same in weighing lib update function*/
	rubyCfg.get( "LoaderBktPayldTrgtWt", LpsSaWeighInfoTbl.LoaderBktPayldTrgtWt );

	LOG_NOTICE( "LoaderBktPayldTrgtWt %f",LpsSaWeighInfoTbl.LoaderBktPayldTrgtWt );
	
	/* Calibration Information used to calculate empty bucket weight and full calibration weight */
	rubyCfg.get( "KgPerLiftKpaAtMidExtension", LpsSaWeighInfoTbl.KgPerLiftKpaAtMidExtension );
	rubyCfg.get( "LiftKpaNoBucketMidExtension", LpsSaWeighInfoTbl.LiftKpaNoBucketMidExtension );

	rubyCfg.get( "FilterTauDelay", LpsSaWeighInfoTbl.FilterTauDelay );
	rubyCfg.get( "PwmcycleRate_hz", LpsSaWeighInfoTbl.PwmcycleRate );

	LOG_NOTICE( "FilterTauDelay %i",LpsSaWeighInfoTbl.FilterTauDelay );
	LOG_NOTICE( "PwmcycleRate %i",LpsSaWeighInfoTbl.PwmcycleRate );
	
    LpsSaLoadKinamaticsTbl();
	
	if (!getTaskParser().getSection("MachineType1",machineType))
	{
		LOG_ERROR("MachineType section not found");
	}
	else
	{
		machineType.get( "InternalMsn", machineMSN );

		/* raise diagnostic if machine model is NOT_SET (default) */
		if ("NOT00000" == machineMSN)
		{
			MachineModelNotSetOut setDiag;
			setAutonomyCondition(setDiag);
			LpsSaWeighInfoTbl.DiagState.flag.MachineModelNotSet = DIAG_ACTIVE;
			LpsSaWeighInfoTbl.MachineModelNotSet = TRUE;
		}
		else
		{
			/* Machine model has been selected */
			clearAutonomyCondition<MachineModelNotSetOut>();
			LpsSaWeighInfoTbl.DiagState.flag.MachineModelNotSet = DIAG_INACTIVE;
			LpsSaWeighInfoTbl.MachineModelNotSet = FALSE;
		}
	}

    return;
}
