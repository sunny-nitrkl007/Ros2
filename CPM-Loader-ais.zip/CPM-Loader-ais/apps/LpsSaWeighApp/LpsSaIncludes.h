/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaIncludes.h
DESCRIPTION:
*******************************************************************************/
#ifndef __LPS_SA_INCLUDES_H__
#define __LPS_SA_INCLUDES_H__
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
using namespace std;
/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/

							
#define PI                (float_32) 3.14159265358979323846264338327

#define WEIGH_LIB_EXEC_RATE  (float_32) 0.02 /* Weigh library executes at every 20ms rate */
//#define WEIGH_LIB_DUMP_BUFF_SIZE (unsigned_8) (1.0/WEIGH_LIB_EXEC_RATE)
#define WEIGH_LIB_DUMP_BUFF_SIZE 50

#define LPS_SA_WEIGH_SUCCESS           (boolean) 0
#define LPS_SA_WEIGH_FAIL              (boolean) 1

#define MIRCOSECONDS_IN_ONE_SECOND    1000000.0     
#define INPUT_SAMPLING_RATE           0.02 /* Sensor inputs sampling rate in second */
#define LIFT_CYL_VEL_LP_FLT_CF        5.0  /* Low pass filter corner frequency in rad/second for
                                            * Lift Cylinder Velocity
										    */
#define TILT_CYL_VEL_LP_FLT_CF        5.0 /* Low pass filter corner frequency in rad/second for
                                            * Tilt Cylinder Velocity
										    */
											
#define LIFT_CYL_EXT_LP_FLT_CF		  (float_32) ( 2.0 * PI * 1) /* Corner Frequency of 
																	1 Hz for lift cylinder
																	extension output
																  */

#define LIFT_CYL_DC_LP_FLT_CF        5.0  /* Low pass filter corner frequency in Hz for
                                            * Lift Cylinder Dutycycle */

#define TILT_CYL_DC_LP_FLT_CF        5.0  /* Low pass filter corner frequency in Hz for
                                            * Tilt Cylinder Dutycycle */

#define TILT_CYL_EXT_MIN_LIMIT       1080 


#define LP_FLT_CF_TO_KFF(CF,T)	  ((float_32) ( 2.0 * PI * CF * T))

#define LIFT_CYL_VEL_LP_FLT_KFF		0.26773053165931 /* based on a 2.5 Hz filter frequency */
#define TILT_CYL_VEL_LP_FLT_KFF		0.26773053165931 /* based on a 2.5 Hz filter frequency */

#define CONVERT_PWM_COUNTS_TO_FREQ(PERIOD)  ((1.0/(float_32) PERIOD) * MIRCOSECONDS_IN_ONE_SECOND)

/* Since A5N2 ECM meassures Toff time as width.Hence Ton = T - Toff */
#define CONVERT_PWM_COUNTS_TO_DC(WIDTH,PERIOD) (float_32) ((((float_32) WIDTH/(float_32) PERIOD) * 100.0))
/* Sensors min and max limits for diagnostics */

#define CYL_POS_SENSOR_MAX_FREQ   (float_32) 600.0
#define CYL_POS_SENSOR_MIN_FREQ   (float_32) 400.0

#define HYD_PRES_SENSOR_MAX_DC 	(float_32)97
#define HYD_PRES_SENSOR_MIN_DC 	(float_32)3
#define HYD_PRES_SENSOR_MAX_FREQ   (float_32) 600.0
#define HYD_PRES_SENSOR_MIN_FREQ   (float_32) 400.0
#define HYD_PRES_SENSOR_SLOPE      0.0018
#define HYD_PRES_SENSOR_INTERCEPT  5.0
#define HYD_PRES_SENSOR_MAX_VALUE_KPA	(float_32)50000
#define HYD_PRES_SENSOR_MIN_VALUE_KPA	(float_32)0
#define MAX_CH                     4 
#define MIN_WEIGH_RANGE_START        35.0
#define MAX_WEIGH_RANGE_END          80.0
#define MIN_WEIGH_RANGE_SIZE         15.0

#define    UNKNOWN1S    -128        /*Unknown 1 Byte Signed Parameter   */
#define    UNKNOWN2S    -32768        /*Unknown 2 Byte Signed Parameter   */
#define    UNKNOWN4S    (-2147483647-1)    /*Unknown 4 Byte Signed Parameter   */

#define    UNKNOWN1U    0xE0        /*Unknown 1 Byte Unsigned Parameter */
#define    UNKNOWN2U    0xFFE0        /*Unknown 2 Byte Unsigned Parameter */
#define    UNKNOWN4U    0xFFFFFFE0    /*Unknown 4 Byte Unsigned Parameter */

/* Sensors min and max limits for diagnostics */
#define LIFT_TILT_CYL_MAX_DC  		(float_32)96.5
#define LIFT_TILT_CYL_MIN_DC  		(float_32)3.5
#define LIFT_TILT_CYL__MAX_FREQ   	(float_32) 600.0
#define LIFT_TILT_CYL__MIN_FREQ   	(float_32) 400.0

typedef struct PWM_Buffer {
	long actualTimeUs;	// actual time in micro-seconds, wrapps around every 99,999
	int execTime;			// execution time in ms to create record
	int diffTime;			// difference from previous actualTimeus, im micro-seconds 
	unsigned int exp;		// number of times timer expired since last read(), should always be 1
	int width[MAX_CH];	// pulse width in micro-seconds, range "0" .. "19999"
	int period[MAX_CH];	// pulse period in micro-seconds,range "0" .. "19999"
} PWM_Buffer_t;

typedef struct
{
  unsigned_16    applicationNumber;
  void const *tablePtr;
}applicationEntry_t;

typedef enum
{
	LIFT_CYL_RE_PRES_SENS_CH_NUM = 0, /*J1-44 pin */
	LIFT_CYL_HE_PRES_SENS_CH_NUM, /*J1-45 pin */
	LIFT_CYL_POS_SENS_CH_NUM, /*J1-46 pin */
    TILT_CYL_POS_SENS_CH_NUM /*J1-47 pin */
}LpsSaEcmChannel_t;

typedef enum
{
	LPS_SA_INIT_SUCCESS = 0,
	LPS_SA_INIT_FAIL,
	LPS_SA_INIT_CONFIG_ERROR,
	LPS_SA_INIT_DEPANDANT_LIBRARY_INIT_FAIL,
}LpsSaInitErrorType_t;

typedef enum
{
	LPS_SA_UPDT_SUCCESS = 0,
	LPS_SA_UPDT_FAIL,
	LPS_SA_UPDT_DEPANDANT_LIBRARY_UPDT_FAIL,
	LPS_SA_UPDT_INPUT_LIB_INCORRECT_RESPONSE,
}LpsSaUpdtErrorType_t;

typedef struct
{
	unsigned_16    AppNumber;
	LpsInitTbl_t   WeighInitTbl;
}LpsSaInitTbl_t;

typedef struct
{
    unsigned_16 invertLiftDc;	// 0= no invert, dc=sensorDc,   	1=invert, dc=(100-sensorDc)
    unsigned_16 invertTiltDc;	// 0= no invert, dc=sensorDc,   	1=invert, dc=(100-sensorDc)
    vector<float> inLiftDc;
    vector<float> outLiftAngle;
    unsigned_16 nLiftAngle;
    vector<float> inTiltDc;
    vector<float> outTiltAngle;
    unsigned_16 nTiltAngle;
    vector<float> inLiftAngle;
    vector<float> outLiftCylExt;
    unsigned_16 nCylExt;
    vector<float> xTiltAngle;
    vector<float> yLiftAngle;
    vector<float> outTiltCylExt;
    unsigned_16 nTiltEntries;
    unsigned_16 nLiftEntries;
	vector<float> inTiltAngle;
	vector<float> outBktAngle;
	unsigned_16 nTiltToBktAngleEntries;
	vector<float> KnmaticsTiltCylExtMinMax;
	vector<float> KnmaticsTiltAngleMinMax;
} LinkageMap_t;


typedef struct
{
	float_32        ExtVal; /*Holds cylinder extension value in millimeters */
	float_32        PerExtVal; /*Holds cylinder extension in percentage extension of full cylinder extension */
	LpsCylExtStat_t Stat;
}LpsSaLiftCylExt_t;

typedef struct
{
	LpsTiltCylExt_t TiltCylExt;/*Holds tilt cylinder extension value in millimeters and status*/
	LpsBktAngle_t	BucketAngle; /* Holds corresponding Bucket Angle data */
	float_32		PerExtVal; /*Holds tilt cylinder extension in percentage extension of full cylinder extension */
	float_32		PerTiltAngleABC; /*Holds tilt cylinder angle ABC in percentage of full cylinder extension angle */
}LpsSaTiltCylExt_t;


#endif /* #ifndef __LPS_SA_INCLUDES_H__ */
