/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaWeighApp.cpp
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  _LPS_SA_WEIGHAPP_H_
#include "LpsSaWeighApp.h"
#endif
/*******************************************************************************/
/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/

/******************************************************************************
FUNCTION NAME: ActivateOrDeactivateDiag
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::ActivateOrDeactivateDiag( void )
{

	if(((CONVERT_PWM_COUNTS_TO_FREQ(TiltCylPeriod) < HYD_PRES_SENSOR_MIN_FREQ ) ||
		(CONVERT_PWM_COUNTS_TO_FREQ(TiltCylPeriod) > HYD_PRES_SENSOR_MAX_FREQ))
	   )
	{
		TiltLinkFreqAbnormal setDiag;
		setAutonomyCondition(setDiag);
	}
	else
	{
		clearAutonomyCondition<TiltLinkFreqAbnormal>();
	}

	if(FALSE == IsTiltCyCalibrated)
	{
		TiltLinkCalibrationOut setDiag;
		setAutonomyCondition(setDiag);
	}
	else
	{
		clearAutonomyCondition<TiltLinkCalibrationOut>();
	}

	if(((CONVERT_PWM_COUNTS_TO_FREQ(TiltCylPeriod) < HYD_PRES_SENSOR_MIN_FREQ ) ||
		(CONVERT_PWM_COUNTS_TO_FREQ(TiltCylPeriod) > HYD_PRES_SENSOR_MAX_FREQ))
	   )
	{
		LiftLinkFreqAbnormal setDiag;
		setAutonomyCondition(setDiag);
	}
	else
	{
		clearAutonomyCondition<LiftLinkFreqAbnormal>();
	}

	if(FALSE == IsLiftCyCalibrated)
	{
		LiftLinkCalibrationOut setDiag;
		setAutonomyCondition(setDiag);
	}
	else
	{
		clearAutonomyCondition<LiftLinkCalibrationOut>();
	}

	if(PidTbl.LiftCylReDc < HEADEND_RODEND_MIN_DC)
	{
		LiftREVoltageBelow setDiag;
		setAutonomyCondition(setDiag);
	}
	else
	{
		clearAutonomyCondition<LiftREVoltageBelow>();
	}

	if(PidTbl.LiftCylReDc > HEADEND_RODEND_MAX_DC)
	{
		LiftREVoltageAbove setDiag;
		setAutonomyCondition(setDiag);
	}
	else
	{
		clearAutonomyCondition<LiftREVoltageAbove>();
	}

	if(((CONVERT_PWM_COUNTS_TO_FREQ(TiltCylPeriod) < HYD_PRES_SENSOR_MIN_FREQ ) ||
		(CONVERT_PWM_COUNTS_TO_FREQ(TiltCylPeriod) > HYD_PRES_SENSOR_MAX_FREQ))
	   )
	{
		LiftREFreqAbnormal setDiag;
		setAutonomyCondition(setDiag);
	}
	else
	{
		clearAutonomyCondition<LiftREFreqAbnormal>();
	}

	if(PidTbl.LiftCylHeDc < HEADEND_RODEND_MIN_DC)
	{
		LiftHEVoltageBelow setDiag;
		setAutonomyCondition(setDiag);
	}
	else
	{
		clearAutonomyCondition<LiftHEVoltageBelow>();
	}

	if(PidTbl.LiftCylHeDc > HEADEND_RODEND_MAX_DC)
	{
		LiftHEVoltageAbove setDiag;
		setAutonomyCondition(setDiag);
	}
	else
	{
		clearAutonomyCondition<LiftHEVoltageAbove>();
	}

	if(((CONVERT_PWM_COUNTS_TO_FREQ(TiltCylPeriod) < HYD_PRES_SENSOR_MIN_FREQ ) ||
		(CONVERT_PWM_COUNTS_TO_FREQ(TiltCylPeriod) > HYD_PRES_SENSOR_MAX_FREQ))
	   )
	{
		LiftHEFreqAbnormal setDiag;
		setAutonomyCondition(setDiag);
	}
	else
	{
		clearAutonomyCondition<LiftHEFreqAbnormal>();
	}
}

/******************************************************************************
FUNCTION NAME: ClearSensorData
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
 void LpsSaWeighApp::ClearSensorData(void)
{
	LiftCylRePeriod = 0;
	LiftCylHePeriod = 0;
	LiftCylPeriod = 0;
	TiltCylPeriod = 0;
}



