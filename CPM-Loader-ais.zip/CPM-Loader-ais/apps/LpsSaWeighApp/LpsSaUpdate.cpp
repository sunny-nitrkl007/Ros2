/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaUpdate.cpp
DESCRIPTION:This file provides the update routines for the application software
            for LPS library.
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  _LPS_SA_WEIGHAPP_H_
#include "LpsSaWeighApp.h"
#endif

extern boolean CalNVMReinitFlag;
/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/

/******************************************************************************
FUNCTION NAME:LpsSaUpdt
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
signed_32 tempPayloadWt;

LpsSaUpdtErrorType_t  LpsSaWeighApp::LpsSaUpdt(void)
{

	LpsSaWeighBktDigStat_t lpsWeighDigStat;
	unsigned_32           weighLibErrCount;
	float_32              liftCylPres;
	LpsUpdtErrorTypes_t   lpsWeighRet;
	LpsInstWtRaw_t        lpsWeighInstWtRaw;
	LpsWeighBestBktWt_t   lpsWeighBestBktWt;
	LpsWeighBktDumpStat_t lpsWeighDumpStat;

	LpsSalowerStallCounter++;

	if(TRUE == CalNVMReinitFlag)
	{

		ReInitWeighLib();
		CalNVMReinitFlag= FALSE;

		LOG_ERROR("\n CalNVMReinitFlag:Weigh Library Reinit:CalNvmBlkVerNo %d CalStat %d FastRaiseEmptyBktDeltaPres %f FastRaiseFullBktDeltaPres %f "
											"EmptyBktSlowRaiseSpd %f EmptyBktFastRaiseSpd %f FullBktSlowRaiseSpd %f FullBktFastRaiseSpd %f "
											"Calwt %f ShmEmptyMain %d ShmFullMain %d EmptyTemp %f FullTemp %f EmptyBucketWeightEst %f "
											"LifeTimeTotalPassCount %d LifeTimeTotalPayloadWeight %f CalAdjust %f ZeroWeight %f"
											"StartOfWeigh %f EndOfWeigh %f LoaderBktPayldTrgtWt %f \n",
									LpsSaWeighNvmCal.CalNvmBlkVerNo,
									LpsSaWeighNvmCal.CalStat,
									LpsSaWeighNvmCal.FastRaiseEmptyBktDeltaPres,
									LpsSaWeighNvmCal.FastRaiseFullBktDeltaPres,
									LpsSaWeighNvmCal.EmptyBktSlowRaiseSpd,
									LpsSaWeighNvmCal.EmptyBktFastRaiseSpd,
									LpsSaWeighNvmCal.FullBktSlowRaiseSpd,
									LpsSaWeighNvmCal.FullBktFastRaiseSpd,
									LpsSaWeighNvmCal.Calwt,
									LpsSaWeighNvmCal.ShmEmptyMain,
									LpsSaWeighNvmCal.ShmFullMain,
									LpsSaWeighNvmCal.EmptyTemp,
									LpsSaWeighNvmCal.FullTemp,
									LpsSaWeighNvmCal.EmptyBucketWeightEst,
									LpsSaWeighNvmCal.LifeTimeTotalPassCount,
									LpsSaWeighNvmCal.LifeTimeTotalPayloadWeight,
									LpsSaWeighNvmCal.CalAdjust,
									LpsSaWeighNvmCal.ZeroWeight,
									LpsSaWeighNvmCal.StartOfWeigh,
									LpsSaWeighNvmCal.EndOfWeigh,
									LpsSaWeighNvmCal.LoaderBktPayldTrgtWt);
		int iCount=0;
		for(iCount=0;iCount<11;iCount++)
		{
			LOG_ERROR("\n SlowRaiseEmptyBktLiftHt[%d] %f"
					"SlowRaiseEmptyBktLiftPres[%d] %f"
					"SlowRaiseFullBktLiftHt[%d] %f"
					"SlowRaiseFullBktLiftPres[%d] %f"
					"SlowLowerEmptyBktLiftHt[%d] %f"
					"SlowLowerEmptyBktLiftPres[%d] %f"
					"SlowLowerFullBktLiftHt[%d] %f"
					"SlowLowerFullBktLiftPres[%d] %f \n ",
					iCount,LpsSaWeighNvmCal.SlowRaiseEmptyBktLiftHt[iCount],
					iCount,LpsSaWeighNvmCal.SlowRaiseEmptyBktLiftPres[iCount],
					iCount,LpsSaWeighNvmCal.SlowRaiseFullBktLiftHt[iCount],
					iCount,LpsSaWeighNvmCal.SlowRaiseFullBktLiftPres[iCount],
					iCount,LpsSaWeighNvmCal.SlowLowerEmptyBktLiftHt[iCount],
					iCount,LpsSaWeighNvmCal.SlowLowerEmptyBktLiftPres[iCount],
					iCount,LpsSaWeighNvmCal.SlowLowerFullBktLiftHt[iCount],
					iCount,LpsSaWeighNvmCal.SlowLowerFullBktLiftPres[iCount]);

		}

		LOG_ERROR("\n REinit lift_full_raise_dc lift_full_lower_dc  %d  %d \n",LpsSaWeighLiftNvmCal.lift_full_raise_dc, LpsSaWeighLiftNvmCal.lift_full_lower_dc);
		LOG_ERROR("\n REinit tilt_full_dump_dc tilt_full_rack_dc %d  %d \n",LpsSaWeighTiltNvmCal.tilt_full_dump_dc, LpsSaWeighTiltNvmCal.tilt_full_rack_dc);


	}

	weighLibErrCount = 0;

    while ( PwmIn->get( InPwm ) )
	{
		memcpy(&InpLibClbBuff,&InPwm.PwmData, sizeof(InpLibClbBuff));

		lpsWeighRet = LpsSaUpdateWeighingLib(InpLibClbBuff);

		if(LPS_UPDT_SUCCESS != lpsWeighRet)
		{
			 LOG_NOTICE( "\n LpsSaUpdateWeighingLib error code = %d\n",lpsWeighRet );
			weighLibErrCount++;
		}

		LOG_NOTICE( "\n\rData Received from PwmInputApp At call back:\n\r%i\n\r%i\n\r%i\n\r%i\n\r%i\n\r%i\n\r%i\n\r%i\n\r%i\n\r%i\n\r%i\n\r%i",InPwm.PwmData.ActualTimeUs,InPwm.PwmData.ExecTime,InPwm.PwmData.DiffTime,InPwm.PwmData.Exp,InPwm.PwmData.Width[0],InPwm.PwmData.Width[1],InPwm.PwmData.Width[2],InPwm.PwmData.Width[3],InPwm.PwmData.Period[0],InPwm.PwmData.Period[1],InPwm.PwmData.Period[2],InPwm.PwmData.Period[3]  );

		/* Collecting difference pressure output from weighing library*/
		liftCylPres = LpsGetLiftCylPres();
		/* Collecting raw instantaneous weight output from weighing library*/
		lpsWeighInstWtRaw = LpsGetRawInstWt();
		/* Collecting Best available bucket weight and payload calculation method
		   output from weighing library */

		lpsWeighBestBktWt = LpsWeighGetBestAvailableBktWt();
		/* Collecting Dig and Dump States from Weigh Library */
		lpsWeighDumpStat  = GetDumpStateStatus();
		lpsWeighDigStat   = (LpsSaWeighBktDigStat_t)LpsWeighGetDigState();

		/* Populating SCS interfaces for Best available bucket weight and payload calculation method */
		LpsSaWeighInfoTbl.BestBktWtInTonnes  = lpsWeighBestBktWt.Wt * activeSimpleCalFactor;
		LpsSaWeighInfoTbl.PayloadCalcMeth = (unsigned_16)lpsWeighBestBktWt.PayloadCalcMeth;
		LpsSaWeighInfoTbl.WeighDecFlag		=  lpsWeighBestBktWt.WeighDecFlag;
		LpsSaWeighInfoTbl.LatchConditionsOK =  lpsWeighBestBktWt.LatchConditionsOK;

			/* Populating Dig and Dump state on SCS Tx interfaces */
		LpsSaWeighInfoTbl.DigStat  = lpsWeighDigStat;
		LpsSaWeighInfoTbl.DumpStat = (LpsSaWeighBktDumpStat_t)lpsWeighDumpStat;

		/* Collecting Weigh Range Indicator state from Weigh Library */
		LpsSaWeighInfoTbl.Indicator = (LpsWeighRangeIndicator_t)LpsWeighGetWeighRangeIndicator();
		 LOG_NOTICE( "\n LpsSaWeighInfoTbl.Indicator = %d\n",LpsSaWeighInfoTbl.Indicator );


		 LOG_NOTICE("\n weighUpdtTbl.LiftCylExt.Val= %f,weighUpdtTbl.TiltCylExt.Val = %f,LiftCylExt.Stat = %d,weighUpdtTbl.TiltCylExt.Stat = %d,weighUpdtTbl.TiltCylVel.Val = %f,weighUpdtTbl.TiltCylVel.Stat = %d \n",weighUpdtTbl.LiftCylExt.Val,
				   weighUpdtTbl.TiltCylExt.Val,weighUpdtTbl.LiftCylExt.Stat,weighUpdtTbl.TiltCylExt.Stat,weighUpdtTbl.TiltCylVel.Val,weighUpdtTbl.TiltCylVel.Stat );


		 LOG_NOTICE( "\n weighUpdtTbl.BktAngle.Val = %f weighUpdtTbl.BktAngle.Stat =  %d \n",
					weighUpdtTbl.BktAngle.Val,weighUpdtTbl.BktAngle.Stat);

		 LOG_NOTICE( "\n lpsWeighDumpStat = %d,lpsWeighDigStat = %d\n",lpsWeighDumpStat,lpsWeighDigStat);

		 LOG_NOTICE( "\n lpsWeighBestBktWt.Wt = %f,lpsWeighBestBktWt.PayloadCalcMeth = %x\n",
					lpsWeighBestBktWt.Wt,lpsWeighBestBktWt.PayloadCalcMeth );

		 LOG_NOTICE( "\n Lift Cylinder Difference Pressure = %f\n",liftCylPres);

		 LOG_NOTICE( "\n Raw Instantaeous Weight = %f,Status = %d \n",lpsWeighInstWtRaw.Val,lpsWeighInstWtRaw.Stat );

		 UpdateEvents();

	}

	if((0 != weighLibErrCount))
	{
		return LPS_SA_UPDT_DEPANDANT_LIBRARY_UPDT_FAIL;
	}


	return LPS_SA_UPDT_SUCCESS;
}


void  LpsSaWeighApp::ReInitWeighLib(void)
{
	if(TRUE == LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_WEIGH_RANGE_INDX])
	{
		LpsSaScsSendReqstResponse(LPS_SA_WEIGH_SCS_REQST_WEIGH_RANGE_INDX,LPS_SA_WEIGH_RANGE_SUCCESS);
	}
	else if(TRUE == LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_NEW_CAL_WT_INDX])
	{
		/* Sending positive response for Weigh Range settings request*/
		LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_NEW_CAL_WT_INDX] = FALSE;
	}
	else if(TRUE == LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_LAST_PAY_LOAD_WT_INDX])
	{
		LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_LAST_PAY_LOAD_WT_INDX] = FALSE;
	}

	else if(TRUE == LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_LOADER_BKT_PAYLOAD_WT_INDX])
	{
		LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_LOADER_BKT_PAYLOAD_WT_INDX] = FALSE;
	}
	LpsSaNvmWeighAppMachSpecificCfgWriteFlag = TRUE;
	InitRet = LpsSaInit(&LpsSaInitTbl);
	if(LPS_SA_INIT_SUCCESS != InitRet)
	{
	   getLogger().log_error( "\n Weigh Library Reinit Failed = %d \n",InitRet);
	}
	else
	{
		getLogger().log_error( "\n Weigh Library Reinit Success = %d \n",InitRet);
	}
	
}

/******************************************************************************
FUNCTION NAME: calibrationUpdate
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::calibrationUpdate()
{
   // Obtain calibration flags
   LpsCalStatus_t CalStatus;
   LpsCalGetCalStatus(&CalStatus);

   CalLibUpdt();

   // If calibration is in progress then send an update to XCP server
   if (CalStatus.CalInProgress)
   {
      // Publish the key-on calibration data from NVM through SCS
      PublishCalOnTheFlyPayload(CalStatus);
   }

//	LpsSaWeighLiftNvmCal.lift_full_lower_dc=(int_32)3;
//	LpsSaWeighLiftNvmCal.lift_full_raise_dc=(int_32)26;
//        	LpsSaLiftNvmWeighAppCalWriteFlag = TRUE;
//
//        				/*Enable Reinit flag*/
//        				CalNVMReinitFlag =TRUE;

	/* Check if request for Best Bucket Weight reset is received*/
    if(TRUE == LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_CAL_INDX])
	{
    	LOG_NOTICE("calibrationUpdate\n");

    	if(LpsSaWeighInfoTbl.Cal_id == SA_EMPTY_BUCKET_CAL_ID)
    	{
    		LpsSaWeighInfoTbl.CalResp = LpsCalEmptyCalMain(LpsSaWeighInfoTbl.Calcmd,
    								LpsSaWeighInfoTbl.Cal_id,
    								&LpsSaWeighInfoTbl.stepNo,
    								&LpsSaWeighInfoTbl.error);

    		LOG_NOTICE("LpsCalEmptyCalMain resp %d cmd %d calId stepNo:%d error%d \n",
    								LpsSaWeighInfoTbl.CalResp,
    								LpsSaWeighInfoTbl.Calcmd,
    								LpsSaWeighInfoTbl.Cal_id,
    								&LpsSaWeighInfoTbl.stepNo,
    								LpsSaWeighInfoTbl.error);
    	}
    	else if(LpsSaWeighInfoTbl.Cal_id == SA_FULL_BUCKET_CAL_ID)
    	{
    		LpsSaWeighInfoTbl.CalResp = LpsCalFullCalMain(LpsSaWeighInfoTbl.Calcmd,
    								LpsSaWeighInfoTbl.Cal_id,
								&LpsSaWeighInfoTbl.stepNo,
								&LpsSaWeighInfoTbl.error);

    		if(LpsSaWeighInfoTbl.Calcmd  == CAL_MGR_MC_SUCCESS &&
    		   LpsSaWeighInfoTbl.CalResp == CAL_MGR_MR_SUCCESS_SAVED)
    		{
    			/* get and store last payload weight (suggested cal weight) */
    			tempPayloadWt = (signed_32)LpsCalGetLastPayloadWeight();
    			WeighPidTbl.LastPloadWt = ((signed_16)tempPayloadWt);
    			WeighPidTbl.LastPloadWt = ((float)WeighPidTbl.LastPloadWt/100);
    			LpsSaWeighNvmMachSpecificCfg.LastPloadWt = WeighPidTbl.LastPloadWt;

    			/* reset simple cal factor and zero weight */

    			LpsSaWeighNvmMachSpecificCfg.activeSimpleCalFactor = activeSimpleCalFactor =
    			        LpsSaWeighDefMachSpecificCfg.activeSimpleCalFactor;

    			LpsSaWeighNvmMachSpecificCfg.updatedSimpleCalFactor = updatedSimpleCalFactor =
    			                        LpsSaWeighDefMachSpecificCfg.updatedSimpleCalFactor;

    			LpsSaWeighNvmCal.CalAdjust = 0.0;
    			LpsSaWeighNvmCal.ZeroWeight = 0.0;

    			LpsSaNvmWeighAppNvmZeroWt = LpsSaNvmWeighAppDefZeroWt;
    			LpsSaNvmWeighAppZeroWtWriteFlag = TRUE;

    			/* reset the calwt and set CalStat to cal wt needed */
    			LOG_NOTICE("calibration weight reset on full cal success\n");
    			LpsSaWeighNvmMachSpecificCfg.CalWt = 0.0f;
    			LpsSaWeighNvmCal.CalStat &= ~CAL_BKT_WT_MASK;
    			LpsSaNvmWeighAppMachSpecificCfgWriteFlag = TRUE;
    			LpsSaNvmWeighAppCalWriteFlag = TRUE;
    		}

    		LOG_NOTICE("LpsCalFullCalMain resp %d cmd %d calId %d \n",
    		    														LpsSaWeighInfoTbl.CalResp,
    		    														LpsSaWeighInfoTbl.Calcmd,
    		    														LpsSaWeighInfoTbl.Cal_id,
    		    														LpsSaWeighInfoTbl.error);
		}
    	else if(LpsSaWeighInfoTbl.Cal_id==SA_LIFT_LINKAGE_CAL_ID)
		{

    		LpsSaWeighInfoTbl.CalResp = LpsSaLiftLinkageSensorCalibration(LpsSaWeighInfoTbl.Calcmd,
					LpsSaWeighInfoTbl.Cal_id,
					&LpsSaWeighInfoTbl.stepNo,&LpsSaWeighInfoTbl.error);
    		LOG_NOTICE("cal_liftlinkage_main resp %d cmd %d calId %d error %d \n",
    		    														LpsSaWeighInfoTbl.CalResp,
    		    														LpsSaWeighInfoTbl.Calcmd,
    		    														LpsSaWeighInfoTbl.Cal_id,
    		    														LpsSaWeighInfoTbl.error);
		}
    	else if(LpsSaWeighInfoTbl.Cal_id==SA_TILT_LINKAGE_CAL_ID)
		{
    		//LpsSaWeighInfoTbl.CalResp = LpsSaTiltLinkageSensorCalibration();
    		//getLogger().log_error("calibrationUpdate:SA_TILT_LINKAGE_CAL_ID\n");
    		LpsSaWeighInfoTbl.CalResp = LpsSaTiltLinkageSensorCalibration(LpsSaWeighInfoTbl.Calcmd,
    							LpsSaWeighInfoTbl.Cal_id,
    							&LpsSaWeighInfoTbl.stepNo,&LpsSaWeighInfoTbl.error);
    		LOG_NOTICE("cal_tiltlinkage_main resp %d cmd %d calId %d %d error \n",
    		    		    														LpsSaWeighInfoTbl.CalResp,
    		    		    														LpsSaWeighInfoTbl.Calcmd,
    		    		    														LpsSaWeighInfoTbl.Cal_id,
    		    		    														LpsSaWeighInfoTbl.error);
		}

		LpsSaScsSendReqstResponse(LPS_SA_WEIGH_SCS_REQST_CAL_INDX,(unsigned char)LPS_SA_CAL_SUCCESS);

		LOG_ERROR("LpsSaWeighNvmCal.CalStat %x cal_id %x\n", LpsSaWeighNvmCal.CalStat, LpsSaWeighInfoTbl.Cal_id);
	}

}

void LpsSaWeighApp::CalLibUpdt(void)
{
	LpsCalUpdate_t  calUpdtTbl;
	LpsCalUpdtErrorTypes_t calRet;

	calUpdtTbl.LiftHePresStat    = weighUpdtTbl.LiftCylHePres.Stat;
	calUpdtTbl.LiftRePresStat    = weighUpdtTbl.LiftCylRePres.Stat;
	calUpdtTbl.DiffPress         = LpsGetLiftCylPres();
	calUpdtTbl.LiftCylExt.Val    = weighUpdtTbl.LiftCylExt.Val;
	calUpdtTbl.LiftCylVel.Val    = weighUpdtTbl.LiftCylVel.Val;
	calUpdtTbl.HydOilTemp.Val    = weighUpdtTbl.HydOilTemp.Val; //test data 0x45
	calUpdtTbl.LiftCylExt.Stat   = weighUpdtTbl.LiftCylExt.Stat;
	calUpdtTbl.LiftCylVel.Stat   = weighUpdtTbl.LiftCylVel.Stat;
	calUpdtTbl.TiltCylExt.Stat   = weighUpdtTbl.TiltCylExt.Stat;
	calUpdtTbl.TiltCylExt.Val    = weighUpdtTbl.TiltCylExt.Val;
	calUpdtTbl.BktAngle.Stat     = weighUpdtTbl.BktAngle.Stat;
	calUpdtTbl.BktAngle.Val  	 = weighUpdtTbl.BktAngle.Val;
	calUpdtTbl.HydOilTemp.Stat   = weighUpdtTbl.HydOilTemp.Stat;
	calUpdtTbl.LiftLeverInfo.LeverInfoAvailable     = FALSE;
	calUpdtTbl.ServiceHourMeter  = 1000;
	calUpdtTbl.DumpState  	     = (LpsWeighBktDumpStat_t)LpsSaWeighInfoTbl.DumpStat; //test data LPS_WEIGHT_BKT_FULLY_RACKED
                                    //Why not leverage common structure in SA Weigh app?

	calRet = LpsCalUpdate(&calUpdtTbl);

    /*
	if(LPS_CAL_INIT_SUCCESS != calRet)
	{
		return false;
	}
	else
	{
		return true;
	}
	*/

	LOG_NOTICE("LiftCylExt %f Vel %f HydOilTemp %f TiltCylExt %f BktAngle %f DumpState %d CalUpdateRet %d\n",
			calUpdtTbl.LiftCylExt.Val, calUpdtTbl.LiftCylVel.Val, calUpdtTbl.HydOilTemp.Val,
			calUpdtTbl.TiltCylExt.Val, calUpdtTbl.BktAngle.Val, calUpdtTbl.DumpState, calRet);

	return;
}

void LpsSaWeighApp:: copyCalNVMValtoWeighInitTable(LpsCalib_t *LpsCalib)
{
	if(true == GetPayLoadMonSysCalStatus())
	{
		LpsCalib->CalStat = LPS_WEIGH_SYSTEM_CALIBRATED;
	}
	else
	{
		LpsCalib->CalStat = LPS_WEIGH_SYSTEM_UNCALIBRATED;
	}

	memcpy(LpsCalib->SlowRaiseEmptyBktLiftHt,&LpsSaWeighInfoTbl.CalInit.Nvm.SlowRaiseEmptyBktLiftHt,sizeof(LpsCalib->SlowRaiseEmptyBktLiftHt));
	memcpy(LpsCalib->SlowRaiseEmptyBktLiftPres,&LpsSaWeighInfoTbl.CalInit.Nvm.SlowRaiseEmptyBktLiftPres,sizeof(LpsCalib->SlowRaiseEmptyBktLiftPres));
	memcpy(LpsCalib->SlowRaiseFullBktLiftHt,&LpsSaWeighInfoTbl.CalInit.Nvm.SlowRaiseFullBktLiftHt,sizeof(LpsCalib->SlowRaiseFullBktLiftHt));
	memcpy(LpsCalib->SlowRaiseFullBktLiftPres,&LpsSaWeighInfoTbl.CalInit.Nvm.SlowRaiseFullBktLiftPres,sizeof(LpsCalib->SlowRaiseFullBktLiftPres));
	memcpy(LpsCalib->SlowLowerEmptyBktLiftHt,&LpsSaWeighInfoTbl.CalInit.Nvm.SlowLowerEmptyBktLiftHt,sizeof(LpsCalib->SlowLowerEmptyBktLiftHt));
	memcpy(LpsCalib->SlowLowerEmptyBktLiftPres,&LpsSaWeighInfoTbl.CalInit.Nvm.SlowLowerEmptyBktLiftPres,sizeof(LpsCalib->SlowLowerEmptyBktLiftPres));
	memcpy(LpsCalib->SlowLowerFullBktLiftHt,&LpsSaWeighInfoTbl.CalInit.Nvm.SlowLowerFullBktLiftHt,sizeof(LpsCalib->SlowLowerFullBktLiftHt));
	memcpy(LpsCalib->SlowLowerFullBktLiftPres,&LpsSaWeighInfoTbl.CalInit.Nvm.SlowLowerFullBktLiftPres,sizeof(LpsCalib->SlowLowerFullBktLiftPres));

	LpsCalib->FastRaiseEmptyBktDeltaPres = LpsSaWeighInfoTbl.CalInit.Nvm.FastRaiseEmptyBktDeltaPres;
	LpsCalib->FastRaiseFullBktDeltaPres =  LpsSaWeighInfoTbl.CalInit.Nvm.FastRaiseFullBktDeltaPres;
	LpsCalib->EmptyBktSlowRaiseSpd =  LpsSaWeighInfoTbl.CalInit.Nvm.EmptyBktSlowRaiseSpd;
	LpsCalib->EmptyBktFastRaiseSpd =  LpsSaWeighInfoTbl.CalInit.Nvm.EmptyBktFastRaiseSpd;
	LpsCalib->FullBktSlowRaiseSpd =  LpsSaWeighInfoTbl.CalInit.Nvm.FullBktSlowRaiseSpd;
	LpsCalib->FullBktFastRaiseSpd =  LpsSaWeighInfoTbl.CalInit.Nvm.FullBktFastRaiseSpd;

	LpsCalib->TopOfLift = LpsSaDefaultWeighCalibTbl.TopOfLift;
	LpsCalib->BottomOfLift = LpsSaDefaultWeighCalibTbl.BottomOfLift;

	LpsCalib->EmptyTemp =  LpsSaWeighInfoTbl.CalInit.Nvm.EmptyTemp;
	LpsCalib->FullTemp =  LpsSaWeighInfoTbl.CalInit.Nvm.FullTemp;
	LpsCalib->CalAdjust =  LpsSaWeighInfoTbl.CalInit.Nvm.CalAdjust;

	LpsCalib->EmptyBktWtEst =  LpsSaWeighInfoTbl.CalInit.Nvm.EmptyBucketWeightEst;
	return;
}
