/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaWeighApp.h
DESCRIPTION:
*******************************************************************************/

/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef _LPS_SA_WEIGHAPP_H_
#define _LPS_SA_WEIGHAPP_H_

#include <ais/task/Task.h>

#include <interfaces/LpsSaWeighReqstChannel/InterfaceTypes.h>

#include <interfaces/LpsSaWeighRespChannel/InterfaceTypes.h>

#include <interfaces/LpsSaWeighTxChannel/InterfaceTypes.h>

#include <interfaces/LpsSaWeighInitDebugChannel/InterfaceTypes.h>

#include <interfaces/LpsSaWeighDebugChannel/InterfaceTypes.h>

#include <interfaces/LpsSaJobMgrTxChannel/InterfaceTypes.h>

#include <interfaces/LpsSaJobMgrReqstChannel/InterfaceTypes.h>

#include <interfaces/AisJhm2TxChannel/InterfaceTypes.h>

#include <interfaces/PwmInputChannels/InterfaceTypes.h>

#include <interfaces/SEAStatus/InterfaceTypes.h>

#include <interfaces/Machine/InterfaceTypes.h>
#include <interfaces/LpsSaNvmCalDataChannel/InterfaceTypes.h>
#include <interfaces/LpsSaNvmCalOnTheFlyDataChannel/InterfaceTypes.h>

#include <interfaces/LpsCalCmdReqstChannel/InterfaceTypes.h>
#include <interfaces/LpsCalCmdRespChannel/InterfaceTypes.h>

#include <autonomyConditions/conditions/PayLdWtTooHeavyToZero.h>

#include <autonomyConditions/conditions/PayLdCtrlSysNotZeroed.h>

#include <autonomyConditions/conditions/PayLdOverLdLimitExceeded.h>


#ifndef _Tpms2DataLinkChannel_h_
#include <interfaces/DataLinkData/InterfaceTypes.h>
#endif

#include <interfaces/DataLinkData/DataLinkData.h>

#include <catdllib_fid_def.h>

#include <stdio.h>

#include <fstream>

#include <stdlib.h>


#ifndef __LPS_COMMON_TYPE_DEF_H__
#include <LpsCommonTypeDef.h>
#endif

#ifndef __CPM_FILTER_H__
#include <cpm_filter.h>
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h>
#endif

#ifndef __LPS_PUBLIC_H__
#include <LpsPublic.h>
#endif

#ifndef __LPS_SA_INCLUDES_H__
#include "LpsSaIncludes.h"
#endif

#ifndef  __LPS_COMMON_LOOKUP_TBL_UTILITY_H__
#include <LpsCommonLookUpTblUtility.h>
#endif

#include <task/commTask/commTask.h>

#include <nvm.h>
#include <scl_prmsw.h>

#include "src_nvm/app_nvm_file_access.h"
#include <time.h>
#ifndef  _LPS_SA_CALMGR_H_
#include "LpsSaCalMgr.h"
#endif


#include <autonomyConditions/conditions/CPMAutonomyGeneric.h>

#ifndef __LPS_CAL_APP_PUBLIC_H__
extern "C" {
#include <LpsCalAppPublic.h>
}
#endif

#ifndef __LPS_CAL_PUBLIC_H__
extern "C" {
#include <LpsCalPublic.h>
}
#endif

#ifndef CAL_MGR_H_
#include <cal_mgr.h>
#endif

#include <autonomyConditions/conditions/TiltLinkVoltageBelow.h>
#include <autonomyConditions/conditions/TiltLinkVoltageAbove.h>
#include <autonomyConditions/conditions/TiltLinkFreqAbnormal.h>
#include <autonomyConditions/conditions/TiltLinkCalibrationOut.h>

#include <autonomyConditions/conditions/LiftLinkVoltageBelow.h>
#include <autonomyConditions/conditions/LiftLinkVoltageAbove.h>
#include <autonomyConditions/conditions/LiftLinkFreqAbnormal.h>
#include <autonomyConditions/conditions/LiftLinkCalibrationOut.h>

#include <autonomyConditions/conditions/LiftREVoltageBelow.h>
#include <autonomyConditions/conditions/LiftREVoltageAbove.h>
#include <autonomyConditions/conditions/LiftREFreqAbnormal.h>


#include <autonomyConditions/conditions/LiftHEVoltageBelow.h>
#include <autonomyConditions/conditions/LiftHEVoltageAbove.h>
#include <autonomyConditions/conditions/LiftHEFreqAbnormal.h>

#include <autonomyConditions/conditions/PayloadMonCalibrationOut.h>

#include <autonomyConditions/conditions/MachineModelNotSetOut.h>

#include <autonomyConditions/conditions/PayLdWtTooHeavyToZero.h>
#include <autonomyConditions/conditions/PayLdCtrlSysNotZeroed.h>
#include <autonomyConditions/conditions/PayLdOverLdLimitExceeded.h>
/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
#define LPS_CAL_LAST_PAYLOAD_WT_COND_NOT_MET_PID_DSI	((signed_16)0x8013)
#define  PidD00C8DDSI  (0x801F)
#define  PidFE2EDSI  (0x8000001F)
#define  Pid0045DSI  (0x801F)
#define PidD01B24DSI  (0x801F)
#define LOWER_STALL_KEY_ON_DELAY  (unsigned char)5    /* Value in seconds */


class  LpsSaWeighApp: public task::Task,LpsSaWeighTxChannelStorage,LpsSaWeighReqstChannelStorage,LpsSaWeighRespChannelStorage,public commTask
{
public:
    LpsSaWeighApp( const std::string& taskName );
    virtual ~ LpsSaWeighApp( );

    virtual bool initialize( );
    virtual bool executive( );
    virtual void cleanup( );

protected:
private:

	typedef enum
	{
		LPS_SA_WEIGH_SCS_REQST_ZERO_INDX,
		LPS_SA_WEIGH_SCS_REQST_BEST_BKT_RST_INDX,
		LPS_SA_WEIGH_SCS_REQST_CAPT_CYL_EXTN_REF_INDX,
		LPS_SA_WEIGH_SCS_REQST_WEIGH_RANGE_INDX,
		LPS_SA_WEIGH_SCS_REQST_CAL_INDX,
		LPS_SA_WEIGH_SCS_REQST_NEW_CAL_WT_INDX,

		LPS_SA_WEIGH_SCS_REQST_CLEAR_REWEIGH_WARNING_INDX,

		LPS_SA_WEIGH_SCS_REQST_LAST_PAY_LOAD_WT_INDX,
		LPS_SA_WEIGH_SCS_REQST_OVR_LOAD_WARN_EN_INDX,
		LPS_SA_WEIGH_SCS_REQST_LOADER_BKT_PAYLOAD_WT_INDX,

		
		/* Add all command indexes above "LPS_SA_WEIGH_SCS_REQST_NO_OF_PARAM_INDX"*/
		LPS_SA_WEIGH_SCS_REQST_NO_OF_PARAM_INDX
	}LpsSaWeighScsReqstStatIndex_t;

	typedef enum
	{
		DIAG_INACTIVE = 0,
		DIAG_ACTIVE
	}DiagnosticsStatus_t;

	typedef enum
	{
		EVENT_INACTIVE = 0,
		EVENT_ACTIVE
	}EventsStatus_t;

	typedef enum
	{
		LIFT_CYL_ROD_END_INPUT = 0,
		LIFT_CYL_HEAD_END_INPUT
	}HeadRodEndIdentifier_t;

	typedef struct
	{
		vector<float> lift_cyl_ext_pct_axis;
		vector<float> tilt_cyl_ext_pct_axis;
		vector<float> tilt_comp_gain_data;
	}CalibTblRuby_t;

	typedef struct
	{
		float 	LiftCylMaxDc;
		float 	LiftCylMinDc;
		float 	TiltCylMaxDc;
		float 	TiltCylMinDc;
	}LiftTiltMinMaxDc_t;

	typedef struct
	{
		/* This structure members may be
		 * update in future based on TX channels
		 */
		/*TX Param*/
		LpsSaWeighBktDigStat_t		DigStat; /* Machine Dig Status */
		LpsSaWeighCalStatus_t 		CalStat; /* Lps System Calibration Status */
		LpsSaWeighBktDumpStat_t 	DumpStat; /* Machine Dump Status */
		float 				        BestBktWtInTonnes; /* Best Available Bucket Weight in metric Tonne */
		unsigned int 			    ZeroNotifyStat; /* Zero bucket notify status*/
		unsigned short int 		    PayloadCalcMeth; /* Payload Calculation method */
		bool						WeighDecFlag;
		bool						LatchConditionsOK;
		LpsSaWeighLiftCylVel_t		LiftCylVel; /* Lift Cyclinder Velocity */
		LpsWeighRangeIndicator_t    Indicator;
		LpsSaJobMgrAutoManualTipOffDumpState_t  LpsSaJobMgrAutoManualTipOffDumpState;
		/*RX Param*/
		short int                   PassCount; /* Pass Count */
	   /*Loader payload Tatget Weight*/
		float_32                    LoaderBktPayldTrgtWt;
		LpsSaWeighLiftCylExt_t		LiftCylExt; /* Lift Cylinder Extension */

		/* Empty bucket weight and full bucket weight calibration values */
		float_32 					KgPerLiftKpaAtMidExtension;
		float_32 					LiftKpaNoBucketMidExtension;

		unsigned char 				FilterTauDelay;
		float						PwmcycleRate;
		LpsSaJobMgrStandbyState_t   StandbyState;
		ACDEventPopUp_t				EventState;
		ACDDiagPopUp_t				DiagState;
		ACDInfoPopUp_t 				InfoState;
		bool						ShowExclamationPoint;
		float_32					CycleRate_hz;
		float						LiftCylExtMax;
		float   			  		liftCylPerExt;

		/* Payload SEA status */
		uint16_t LpsSaPayloadSEAStatus;

		/* Machine/Model not selected flag */
		boolean	MachineModelNotSet;

		/*calibration tx parameters*/
		LpsSaWeighCalParam_t CalibrationTxval;
		/*CAL req data*/
		CAL_MGR_MC_E Calcmd;
		unsigned_16	 Cal_id;		/* Calibration / Service Mode ID */
		/*CAL resp data*/
		CAL_MGR_MR_E CalResp;
		unsigned_8	stepNo;
		unsigned_16 error;
		unsigned_16 warning;
		LpsCalInit_t CalInit;

		unsigned int FilterSettleDelay = 0;
      
                /* Production Measurement Status Summary */
		LpsLiftCylExt_t       	LiftCylExtMillimeter;
		LpsTiltCylExt_t             TiltCylExtMillimeter;
		LpsBktAngle_t			BucketAngle;

	}LpsSaWeighInfoTbl_t;

	float WeighRangeBottom;
	float WeighRangeSize;

	typedef union
	{
		ACDWeighStatus_t WeighWrwReweighStatus;
		unsigned short int Data;
	}ProdMeasureWeighStatus_t;

	typedef union
	{
		LpsZeroNeededStatus_t ZeroNeededStatus;
		unsigned short int Data;
	}PloadSysZeroReqStat_t;

	typedef struct
	{
		float 				TiltCylDc, LiftCylDc, LiftCylHeDc, LiftCylReDc;
		float				LiftCylHePress, LiftCylRePress;
		float 				ZeroedWt;
		PloadSysZeroStat_t	ZeroStat;
		float		 		HydOilTemp;
		float 				PloadConSysCalWt;
		PloadSysZeroReqStat_t PloadSysZeroReqStat;
		BktPayloadData_t 	BktPayloadData;
		PloadSysCalWtEntryReqStat_t	PloadSysCalWtEntryReqStat;
		float				LastPloadWt;
		float				LoaderBktPloadTgtWtPer;
		PloadOvrloadWarnEn_t PloadOvrloadWarnEn;
		ProdMeasureWeighStatus_t ProdMeasureWeighStatus;
	}WeighPidTbl_t;
	WeighPidTbl_t				WeighPidTbl;
    unsigned_16 LpsSaAppNumber;
//    KinamaticsMapRuby_t linkage_table;
    LinkageMap_t  linkage_table_cnfg;
    unsigned_32 TestLogCount;
    CalibTblRuby_t CalibTblRuby;
    LpsCalib_t LpsSaDefaultWeighCalibTbl;
    LiftTiltMinMaxDc_t LiftTiltMinMaxDc;
	float		activeSimpleCalFactor;			/* The simple cal adjustment factor which is currently being used. */
	float		updatedSimpleCalFactor;		/* The latest calculated simple cal adjustment factor which is not being used. This will be assigned to 
													activeSimpleCalFactor when pass count becomes 0, i.e. , store button press or clear button press. */
	float		sumOfAdjustedTruckWts;
	float		sumOfZeroedTruckWts;
	unsigned int 	storePressCount;
    bool IsLiftCyCalibrated;
    bool IsTiltCyCalibrated;
    bool IsPayLoadMonSysCalibrated;
    bool IsCalWtRequired;
    bool KeyswitchIn;
	std::string machineMSN;

   LpsUpdtTbl_t weighUpdtTbl;

   /* Lift Cylinder Head End Pressure */
   int DebugLiftCylHePeriod;
   int DebugLiftCylHeWidth;
   float_32 DebugLiftCylHeDc;
   float_32 DebugLiftCylHePress;

   /* Lift Cylinder Rod End Pressure */
   int DebugLiftCylRePeriod;
   int DebugLiftCylReWidth;
   float_32 DebugLiftCylReDc;
   float_32 DebugLiftCylRePress;

   /* Lift Cylinder */
   int DebugLiftCylPeriod;
   int DebugLiftCylWidth;
   float_32 DebugLiftCylDc;
   float_32 DebugLiftCylRawExt;
   float_32 DebugLiftCylFiltExt;
   float_32 DebugLiftCylNormExt;
   float_32 DebugLiftCylVel;
   float_32 DebugLiftAngle;

   /* Tilt Cylinder */
   int DebugTiltCylPeriod;
   int DebugTiltCylWidth;
   float_32 DebugTiltCylDc;
   float_32 DebugTiltCylRawExt;
   float_32 DebugTiltCylVel;
   float_32 DebugTiltAngle;
   float_32 DebugTiltAngleABC;

   float_32 DebugLpsSaBucketWeight;
   int DebugLpsSaPayloadCalcMethod;

    LpsSaInitTbl_t LpsSaInitTbl;
    PWM_Buffer_t    InpLibClbBuff;
    LPFILT LiftCylVelLpFltConst;
    LPFILT LiftCylExtLpFltConst;
    LPFILT TiltCylVelLpFltConst;

    LPFILT2 LiftCylVelLpFltConst2;
    LPFILT2 TiltCylVelLpFltConst2;
    LPFILT2 TiltCylDc, LiftCylDc;

  	bool LpsSaWeighScsReqstStatFlg[LPS_SA_WEIGH_SCS_REQST_NO_OF_PARAM_INDX];
  	LpsSaWeighInfoTbl_t LpsSaWeighInfoTbl;

    PwmInputChannels InPwm;
    LpsSaInitErrorType_t InitRet;
    LpsSaUpdtErrorType_t UpdtRet;

    LpsSaWeighReqstChannelInput  *LpsSaWeighScsReqstIn;
    LpsSaWeighRespChannelOutput  *LpsSaWeighScsRespOut;
    LpsSaWeighTxChannelOutput    *LpsSaWeighScsTxOut;
    LpsSaJobMgrReqstChannelOutput    *LpsSaJobMgrScsReqstOut;
    PwmInputChannelsInput        *PwmIn;
    LpsSaJobMgrTxChannelInput    *LpsSaJobMgrScsTxIn;
	AisJhm2TxChannelInput		 *AisJhm2TxInputScs;	
	SEAStatusInput				 *SEAStatusInScs;
    MachineInput                 *MachineIn;
    LpsSaWeighInitDebugChannelOutput  *LpsSaWeighScsInitDebugOut;
    LpsSaWeighDebugChannelOutput  *LpsSaWeighScsDebugOut;
    LpsCalCmdReqstChannelInput *LpsCalCmdScsReqstIn;
    LpsCalCmdRespChannelOutput *LpsCalCmdScsRespOut;
    LpsSaNvmCalDataChannelOutput *LpsNvmDumpChanOut;
    LpsSaNvmCalOnTheFlyDataChannelOutput *LpsNvmOnTheFlyDumpChanOut;

    DataLinkDataInput *DataLinkDataInput_;
	struct timespec WeighZeroCurrentTime;

	void LpsSaWeighCalReqstCallback( );
	void PwmInputRead();
	void LpsJobMgrTxRead( );
	void LpsSaMachineRead( );
	void LpsSaWeighingScsRx( );
	void LpsSaWeighScsDebugTx();
	void LpsSaWeighScsInitDebugTx();
	void AisJhmDataServerTxRead();
	void LpsSaSEAStatus();
	boolean LpsSaWeighingScsTx( );
	void LpsSaScsSendZeroRqst( );

	boolean LpsSaScsSendReqstResponse(LpsSaWeighScsReqstStatIndex_t reqstIndx, unsigned char respCode);
	void LpsSaScsChkForReqst();
	LpsSaInitErrorType_t LpsSaInit(LpsSaInitTbl_t *lpsSaInitTbl);
	LpsSaUpdtErrorType_t  LpsSaUpdt(void);
	LpsUpdtErrorTypes_t LpsSaUpdateWeighingLib(PWM_Buffer_t InpBuff);
	LpsHydOilTemp_t LpsSaHydOilTempTransferFunc(void);
	LpsSaTiltCylExt_t LpsSaTiltCylExtTransferFunc(int liftCylExtPwmWidth,int liftCylExtPwmPeriod,int tiltCylExtPwmWidth,int tiltCylExtPwmPeriod);
	LpsSaLiftCylExt_t LpsSaLiftCylExtTransferFunc(int width,int period);
	LpsLiftCylVel_t LpsSaLiftCylVelTransferFunc(LpsLiftCylExt_t liftCylExt);
	LpsTiltCylVel_t LpsSaTiltCylVelTransferFunc(LpsTiltCylExt_t TiltCylExt);
	LpsPresSensorInfo_t LpsSaHydPresTransferFunc(int width,int period,HeadRodEndIdentifier_t HeadOrRodEnd);
	float_32 LpsSaNormaliseDc(float_32 dc,float_32 maxdc,float_32 mindc);

	LpsSaLiftCylExt_t lpsSaGetLiftCylExt(float_32 liftCylExtDc);
	LinkageMap_t * applicationSearch(unsigned_16 applicationNumber, const applicationEntry_t  *ae, unsigned_16 maxApplicationNum);
	LpsSaTiltCylExt_t lpsSaGetTiltCylExt(float_32 liftCylExtDc, float_32 tiltCylExtDc);
	void LpsSaInitWeighTbl(LpsInitTbl_t *weighInitTbl);
	void NvmInitialize(void);
	void LpsSaLoadKinamaticsTbl(void);
	void LpsSaBmiCdlRead( );
	void LpsSaLoadCalibrationTbl(void);

	void LpsSaChkWeighRangeConfig(float_32 weighRangeBottom,float_32 weighRangeSize);

	void CheckForFilterSettleTime(void);
	void CheckCalibrationStatus(void);
	void LpsSaWeighGetAllInfoPopUp(boolean zeroReqstStat);
	unsigned_32	  LpsSalowerStallCounter;
	boolean		  LpsSalowerStallDetectFlag;
	void UpdateEvents(void);
	unsigned int GetSysMonotonicTime();
	PloadSysZeroStat_t GetZeroStat(void);
	void ReInitWeighLib( void );
	/*calibration functions*/
	void calibrationUpdate();
	CAL_MGR_MR_E LpsSaTiltLinkageSensorCalibration (CAL_MGR_MC_E         Cmd,
            unsigned_16	         CalId,
            unsigned_8*	         StepNo,
            unsigned_16*         CalError);
	CAL_MGR_MR_E LpsSaLiftLinkageSensorCalibration (CAL_MGR_MC_E         Cmd,
	            unsigned_16	         CalId,
	            unsigned_8*	         StepNo,
	            unsigned_16*         CalError);

	boolean CalLibInit(void);
	void CalLibUpdt(void);
	bool GetPayLoadMonSysCalStatus(void);
	bool GetLiftCylCalStatus(void);
	bool GetTiltCylCalStatus(void);
	bool GetCalWtRequired(void);
	bool GetPayloadCalStatus(void);
	void copyCalNVMValtoWeighInitTable(LpsCalib_t *CalibTbl);


   void PublishCalFromNvmPayload( void ); // Populates some custom data from calibration table into an SCS object and publishes it for XCP server
   void PublishCalOnTheFlyPayload( LpsCalStatus_t ); // Populates some custom on-the-fly calibration data into an SCS object and publishes it for XCP server
};

#if defined (__cplusplus)
extern "C"
{
#endif

void AppGetCalOvCtrl(boolean enable);
void AppEnableDisableQualRead(unsigned_8 Enable, signed_16* minvalue);
void AppUpdtCalNvmTbl(LpsCalNvmTbl_t CalNvmTbl);

#if defined (__cplusplus)
}
#endif

/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/

/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
#endif
