require "commonLoad.rb"
require "commonTaskParams.rb"
require "Robot.rb"
require "interfaces_Loaders.rb"
require "interfaces_CpmCommon.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
    #"CPMDemoInput" => InterfaceDefs::CPMDemoInput,
    #"MachineInput" => InterfaceDefs::MachineInput,
    #"CpmCycleSegmentationInput" => InterfaceDefs::CpmCycleSegmentationInput,	
    "LpsSaJobMgrTxChannelInput"  => InterfaceDefs_Loaders::LpsSaJobMgrTxChannelInput,
    "LpsSaWeighTxChannelInput" => InterfaceDefs_Loaders::LpsSaWeighTxChannelInput,
    "LpsSaJobMgrRespChannelInput"  => InterfaceDefs_Loaders::LpsSaJobMgrRespChannelInput,
    "LpsSaJobMgrReqstChannelOutput"  => InterfaceDefs_Loaders::LpsSaJobMgrReqstChannelOutput,
    "LpsSaWeighReqstChannelOutput"  => InterfaceDefs_Loaders::LpsSaWeighReqstChannelOutput,
    "AisJhm2TxChannelOutput"  => InterfaceDefs_Loaders::AisJhm2TxChannelOutput,
    "AisJhm2TxChannelInput"  => InterfaceDefs_Loaders::AisJhm2TxChannelInput,
    "MachineSNOutput"  => InterfaceDefs::MachineSNOutput,
    "LpsSaUIAppTxChannelOutput"   => InterfaceDefs_Loaders::LpsSaUIAppTxChannelOutput,
    "LpsSaUIAppRespChannelOutput" => InterfaceDefs_Loaders::LpsSaUIAppRespChannelOutput,
    "LpsSaUIAppReqChannelInput"   => InterfaceDefs_Loaders::LpsSaUIAppReqChannelInput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "cycleRate_hz" => 10.0,
#  "requireGPSTimeSynchronizationOnStart" => true, #added by Joshua
  "loggerThreshold" => "error",  
} )

ScsRxTimeouts = {
  #"CPMDemoInput_rxTimeout_sec"                  => 5.0,    # GPS1 rate is ?? sec
  "LpsSaJobMgrTxChannelInput_rxTimeout_sec"           => 5.0,
  "LpsSaWeighTxChannelInput_rxTimeout_sec"           => 5.0,
  "LpsSaJobMgrRespChannelInput_rxTimeout_sec"           => 5.0,
  "AisJhm2TxChannelInput_rxTimeout_sec"           => 5.0,
  "LpsSaUIAppReqChannelInput_rxTimeout_sec"          => 5.0,
}

ScsTxRates = {
  "LpsSaJobMgrReqstChannelOutput_txRate_sec"          => -1,
  "LpsSaWeighReqstChannelOutput_txRate_sec"          => -1,
  "AisJhm2TxChannelOutput_txRate_sec"          => -1,
  "MachineSNOutput_txRate_sec"          => -1,
  "LpsSaUIAppRespChannelOutput_txRate_sec"        => -1,
  "LpsSaUIAppTxChannelOutput_txRate_sec"         => -1,
}
Execution = {
  "executableName" => "aisJhm2DataServer",
}

