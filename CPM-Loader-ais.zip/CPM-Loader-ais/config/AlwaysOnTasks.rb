#alwaysOnTasks

require "etc"
require "socket"
print "LOADING ALWAYS ON TASK FILE!"

# Discover the proper ethernet interfaces for the autonomy and velodyne networks
# Use "intf" variables as an argument, discarding newline and set up scs networks
autonomyIntf=`/sbin/ifconfig | grep -B 1 '165.26.79' | grep Link |cut -f1 -d' '`
print "After ifconfig autoInf: '", autonomyIntf, "'\n"

if (autonomyIntf == "")
  autonomyIntf="eth0"
  print "using autonomyIntf default ", autonomyIntf, "\n"
end

# Default SCS parameters
scsParameters = ["--advertisedIntf="+autonomyIntf.chomp,"--socketPriority=3"]

# Get the Spoofed name if set
spoofHostname = CommonTaskParams::Parameters["spoofDnsName"];

# if hostname is "A6N2", we are likely on an ECM and require tcp option
# or if the spoofed hostname is "ocs", then we are probably want
# to talk to a robot and need the tcp option
if ( (Socket.gethostname == "A6N2") ||  (spoofHostname == "ocs") ) 
    scsParameters = ["--advertisedIntf="+autonomyIntf.chomp,"--loggerThreshold=warn","--tcp", "--udpDiscoveryPort=11007","--staleFragmentPruningThreshold=1000000"]
end

# Do not use scs with tcp if running in simulation mode on a single PC
simulationMode=ENV['AHS_RUNNING_ON_SINGLE_PC']
if (simulationMode == "TRUE")
  scsParameters = ["--socketPriority=3"]
end


# DEFINE THE ALWAYS ON AUXILIARY PROCESSES!
AuxiliaryProcesses.update({

  "Scs" => {
      "machines" => [ Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],
      "arguments" => scsParameters,
      "executableName" => ENV['CAT_DIR'] + "/bin/scs",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => true,

  },

# Run MachSerialNumTask on multiple machines
  "MachSerialNumTask" => {
     "machines" => [ Machines::MachineMap["one"],
                     Machines::MachineMap["two"],
                     Machines::MachineMap["three"],
                     Machines::MachineMap["four"],
                     Machines::MachineMap["five"],
                     Machines::MachineMap["ocs"],
                  ],
     "arguments" => ["--instanceName=MachSerialNumTask"],
     "executableName" => ENV['CAT_DIR'] + "/bin/machSerialNumTask",
     "autoRestart" => true,
     "timeBetweenRestarts_s" => 2,
     "alwaysOn" => true,
  },

  "aisXcpServer" => {
      "machines" => [ 
                      Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],
      "executableName" => ENV['CAT_DIR'] + "/bin/aisXcpServer",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => false,
  },

  "bmiCdl" => {
      "machines" => [ Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],      
      "executableName" => ENV['CAT_DIR'] + "/bin/bmiCdl",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => true,
  },

  "SwitchInput" => {
      "machines" => [ Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],
      "executableName" => ENV['CAT_DIR'] + "/bin/SwitchInputApp",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => true,
  },

  "OutputApp" => {
      "machines" => [ Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],
      "executableName" => ENV['CAT_DIR'] + "/bin/OutputApp",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => true,
  },

  "AbsIMU" => {
      "machines" => [ Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],
      "executableName" => ENV['CAT_DIR'] + "/bin/AbsIMU",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => true,
  },
  "LpsJobMgr" => {
      "machines" => [ Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],
      "executableName" => ENV['CAT_DIR'] + "/bin/LpsSaJobMgrApp",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => true,
  },
  
  "LpsWeighing" => {
      "machines" => [ Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],
      "executableName" => ENV['CAT_DIR'] + "/bin/LpsSaWeighApp",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => true,
  },

  "AISJhm2DataServer" => {
      "machines" => [ Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],
      "executableName" => ENV['CAT_DIR'] + "/bin/aisJhm2DataServer",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => true,
  },

  "PwmInput" => {
      "machines" => [ Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],
      "executableName" => ENV['CAT_DIR'] + "/bin/PwmInput",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => true,
  },

  "D6Brightness" => {
      "machines" => [ Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],
      "executableName" => ENV['CAT_DIR'] + "/bin/autonomyConditionDiagnostics",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => true,
  },

} )
