require "commonLoad"
require "commonTaskParams.rb"
require "interfaces_Loaders.rb"
require "interfaces_CpmCommon.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
   "LpsSaWeighReqstChannelInput" => InterfaceDefs_Loaders::LpsSaWeighReqstChannelInput,
   "LpsSaWeighRespChannelInput" => InterfaceDefs_Loaders::LpsSaWeighRespChannelInput,
   "LpsSaWeighTxChannelInput" => InterfaceDefs_Loaders::LpsSaWeighTxChannelInput,
   "LpsSaWeighDebugChannelInput" => InterfaceDefs_Loaders::LpsSaWeighDebugChannelInput,
   "LpsSaNvmCalDataChannelInput" => InterfaceDefs_Loaders::LpsSaNvmCalDataChannelInput,
   "LpsSaNvmCalOnTheFlyDataChannelInput" => InterfaceDefs_Loaders::LpsSaNvmCalOnTheFlyDataChannelInput,
   "LpsSaWeighInitDebugChannelInput" => InterfaceDefs_Loaders::LpsSaWeighInitDebugChannelInput,
   "LpsSaJobMgrTxChannelInput" => InterfaceDefs_Loaders::LpsSaJobMgrTxChannelInput,	
   "PwmInputChannelsInput" => InterfaceDefs_CpmCommon::PwmInputChannelsInput,
   "MachineInput" => InterfaceDefs_Loaders::MachineInput,
   "LpsSaJobMgrReqstChannelInput" => InterfaceDefs_Loaders::LpsSaJobMgrReqstChannelInput,
   "LpsSaJobMgrRespChannelInput" => InterfaceDefs_Loaders::LpsSaJobMgrRespChannelInput,
   "LpsSaJobMgrDebugChannelInput" => InterfaceDefs_Loaders::LpsSaJobMgrDebugChannelInput,
   "SwitchInputScsInput" => InterfaceDefs_CpmCommon::SwitchInputScsInput,
} )


ScsRxTimeouts = {
  "LpsSaWeighReqstChannelInput_rxTimeout_sec"                  => 5.0, 
  "LpsSaWeighRespChannelInput_rxTimeout_sec"                  => 5.0, 
  "LpsSaWeighTxChannelInput_rxTimeout_sec"                  => 5.0, 
  "LpsSaWeighDebugChannelInput_rxTimeout_sec"                  => 5.0,
  "LpsSaNvmCalDataChannelInput_rxTimeout_sec"                  => 5.0,
  "LpsSaNvmCalOnTheFlyDataChannelInput_rxTimeout_sec"                  => 5.0,
  "LpsSaWeighInitDebugChannelInput_rxTimeout_sec"                  => 5.0, 
  "LpsSaJobMgrTxChannelInput_rxTimeout_sec"                  => 5.0, 
  "PwmInputChannelsInput_rxTimeout_sec"                  => 5.0, 
  "MachineInput_rxTimeout_sec"                  	=> 5.0, 
  "LpsSaJobMgrReqstChannelInput_rxTimeout_sec"                  => 5.0, 
  "LpsSaJobMgrRespChannelInput_rxTimeout_sec"                  => 5.0, 
  "LpsSaJobMgrDebugChannelInput_rxTimeout_sec"                  => 5.0, 
  "SwitchInputScsInput_rxTimeout_sec"                  	=> 5.0, 
}

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "cycleRate_hz" => 100,
  "loggerThreshold" => "error",
} )

Execution = {
  "executableName" => "aisXcpServer",
}

