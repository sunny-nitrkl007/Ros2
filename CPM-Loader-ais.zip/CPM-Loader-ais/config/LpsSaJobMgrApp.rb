require "commonLoad.rb"
require "commonTaskParams.rb"
require "interfaces_Loaders.rb"
require "interfaces_CpmCommon.rb"
require "Robot.rb"

AppDataBase = "/opt/appdata"
VerityDirectoryName = ENV["CAT_DIR"].split("/").last              # Last directory in the path
ThisAppName = File.basename( __FILE__, File.extname(__FILE__) )   # Script name without extension
AppDataPath = AppDataBase + "/" + VerityDirectoryName + "/" + ThisAppName

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
"LpsSaJobMgrTxChannelOutput"  => InterfaceDefs_Loaders::LpsSaJobMgrTxChannelOutput,##write param to UI
"LpsSaJobMgrReqstChannelInput"  => InterfaceDefs_Loaders::LpsSaJobMgrReqstChannelInput, ##getcmd from UI
"LpsSaJobMgrRespChannelOutput"  => InterfaceDefs_Loaders::LpsSaJobMgrRespChannelOutput,##setRes to UI
"LpsSaJobMgrDebugChannelOutput"  => InterfaceDefs_Loaders::LpsSaJobMgrDebugChannelOutput,##Debug
"LpsSaWeighReqstChannelOutput"  => InterfaceDefs_Loaders::LpsSaWeighReqstChannelOutput,##setCmd to weighing App
"LpsSaWeighRespChannelInput"  => InterfaceDefs_Loaders::LpsSaWeighRespChannelInput,##getRes from weighing App
"LpsSaWeighTxChannelInput"  => InterfaceDefs_Loaders::LpsSaWeighTxChannelInput,##get parameters from weighing app
"SwitchInputScsInput"  => InterfaceDefs_CpmCommon::SwitchInputScsInput,##get parameters from SwitchInput app
"OutputChannelOutput"  => InterfaceDefs_CpmCommon::OutputChannelOutput,##get parameters from SwitchInput app
"AisJhm2TxChannelInput" =>  InterfaceDefs_Loaders::AisJhm2TxChannelInput,
"ShmClockInput" => InterfaceDefs_CpmCommon::ShmClockInput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "error",  ##  All options listed in descending severity order
                                ##  - emerg, fatal, alert, crit, error, warn, notice, info, debug 

    "cycleRate_hz" => 10.0, #every 100 ms changed to match with ACD App
    "DefTargetWeight" => 0.0,#/* Default target weight value as 0 */
    "DefTipOffTriggerType"   => 1, # Tipoff Trigger auto=0,Tipoff Trigger manual=1,Tipoff Trigger disabled=2
    "DefTipOffState"   => 0, #/* Tipoff inactive = 0, tipoff active =1*/
    "SimpleCalMaxTrucksSupported" => 15,  ## Maximum number of trucks supported for simple cal.
    "DefaultHornStoreState" => 0,
    "HornStoreNvmPath" => AppDataPath + "/nvm",
    #"DefaultHornStoreEnable" => 
} )

Execution = {
  "executableName" => "LpsSaJobMgrApp",
}

