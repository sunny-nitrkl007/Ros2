require "commonLoad.rb"
require "commonTaskParams.rb"
require "Robot.rb"
require "commonAutonomyTask.rb"
require "interfaces_Loaders.rb"
require "interfaces_CpmCommon.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
    "LpsSaWeighReqstChannelInput"  => InterfaceDefs_Loaders::LpsSaWeighReqstChannelInput,
    "LpsSaWeighRespChannelOutput"  => InterfaceDefs_Loaders::LpsSaWeighRespChannelOutput,
    "LpsSaWeighInitDebugChannelOutput"  => InterfaceDefs_Loaders::LpsSaWeighInitDebugChannelOutput,
    "LpsSaWeighDebugChannelOutput"  => InterfaceDefs_Loaders::LpsSaWeighDebugChannelOutput,
    "LpsSaNvmCalDataChannelOutput"  => InterfaceDefs_Loaders::LpsSaNvmCalDataChannelOutput,
    "LpsSaNvmCalOnTheFlyDataChannelOutput"  => InterfaceDefs_Loaders::LpsSaNvmCalOnTheFlyDataChannelOutput,
    "LpsSaWeighTxChannelOutput"  => InterfaceDefs_Loaders::LpsSaWeighTxChannelOutput,
    "PwmInputChannelsInput"  => InterfaceDefs_CpmCommon::PwmInputChannelsInput,
    "LpsSaJobMgrTxChannelInput"  => InterfaceDefs_Loaders::LpsSaJobMgrTxChannelInput,
    "LpsSaJobMgrReqstChannelOutput"  => InterfaceDefs_Loaders::LpsSaJobMgrReqstChannelOutput,
    "MachineInput"  => InterfaceDefs_Loaders::MachineInput,
    "LpsCalCmdReqstChannelInput"  => InterfaceDefs_Loaders::LpsCalCmdReqstChannelInput,
    "LpsCalCmdRespChannelOutput"  => InterfaceDefs_Loaders::LpsCalCmdRespChannelOutput,
    "DataLinkDataInput" => InterfaceDefs_CpmCommon::DataLinkDataInput,
    "AisJhm2TxChannelInput" =>  InterfaceDefs_Loaders::AisJhm2TxChannelInput,
    "SEAStatusInput" => InterfaceDefs::SEAStatusInput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {

# Weighing App 100 msec or 10.0 Hz execution rate should be in float data type
"cycleRate_hz" => 10.0,
#Lps Installed state and executes rates at every 20ms
"CPMInstallStat" =>  1,
# Weighing library 20 msec execution rate 
"CPMExecRate" =>  0.02,
"loggerThreshold" => "error",  ##  All options listed in descending severity order
                                ##  - emerg, fatal, alert, crit, error, warn, notice, info, debug 
"DefaultSimpleCalFactor" => 1.0,
}
)

Execution = {
  "executableName" => "LpsSaWeighApp",
}

ConditionConfig =
{
"AutonomyConditions" => [
"TiltLinkVoltageAbove",
"TiltLinkVoltageBelow",
"TiltLinkFreqAbnormal",
"TiltLinkCalibrationOut",
"LiftLinkVoltageAbove",
"LiftLinkVoltageBelow",
"LiftLinkFreqAbnormal",
"LiftLinkCalibrationOut",
"LiftREVoltageAbove",
"LiftREVoltageBelow",
"LiftREFreqAbnormal",
"LiftHEVoltageAbove",
"LiftHEVoltageBelow",
"LiftHEFreqAbnormal",
"PayloadMonCalibrationOut"
        				],
}
