require "interfaces.rb"

module InterfaceDefs_Loaders

#JOB MGR interfaces
LpsSaJobMgrTxChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaJobMgrTxChannel")#get parameters from JobMgr
LpsSaJobMgrTxChannelInput["channel"]["queueSize"] = 20;
LpsSaJobMgrTxChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaJobMgrTxChannel") #set parameters  from JM

LpsSaJobMgrReqstChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaJobMgrReqstChannel") #getcmd from UI
LpsSaJobMgrReqstChannelInput["channel"]["queueSize"] = 20;
LpsSaJobMgrReqstChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaJobMgrReqstChannel")#setcmd to JobMgr

LpsSaJobMgrRespChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaJobMgrRespChannel")#getres from JobMgr
LpsSaJobMgrRespChannelInput["channel"]["queueSize"] = 20;
LpsSaJobMgrRespChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaJobMgrRespChannel")#set res to UI App

LpsSaJobMgrDebugChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaJobMgrDebugChannel")
LpsSaJobMgrDebugChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaJobMgrDebugChannel")

#LpsSa UI App Tx Channel
LpsSaUIAppTxChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaUIAppTxChannel")
LpsSaUIAppTxChannelInput["channel"]["queueSize"] = 20; 
LpsSaUIAppTxChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaUIAppTxChannel")

#TPMS2 UI App Request Channel
LpsSaUIAppReqChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaUIAppReqChannel")
LpsSaUIAppReqChannelInput["channel"]["queueSize"] = 20; 
LpsSaUIAppReqChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaUIAppReqChannel")

#TPMS2 UI App Response Channel
LpsSaUIAppRespChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaUIAppRespChannel")
LpsSaUIAppRespChannelInput["channel"]["queueSize"] = 20; 
LpsSaUIAppRespChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaUIAppRespChannel")




#Weigh App interfaces
LpsSaWeighTxChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaWeighTxChannel")
LpsSaWeighTxChannelInput["channel"]["queueSize"] = 20;
LpsSaWeighTxChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaWeighTxChannel")

LpsSaWeighReqstChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaWeighReqstChannel")
LpsSaWeighReqstChannelInput["channel"]["queueSize"] = 20;
LpsSaWeighReqstChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaWeighReqstChannel")

LpsSaWeighRespChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaWeighRespChannel")
LpsSaWeighRespChannelInput["channel"]["queueSize"] = 20;
LpsSaWeighRespChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaWeighRespChannel")

LpsSaWeighDebugChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaWeighDebugChannel")
LpsSaWeighDebugChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaWeighDebugChannel")

LpsSaWeighInitDebugChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaWeighInitDebugChannel")
LpsSaWeighInitDebugChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaWeighInitDebugChannel")

LpsCalCmdReqstChannelInput = InterfaceDefs.createBasicInputInterface("LpsCalCmdReqstChannel")
LpsCalCmdReqstChannelInput["channel"]["queueSize"] = 5;
LpsCalCmdReqstChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsCalCmdReqstChannel")

LpsCalCmdRespChannelInput = InterfaceDefs.createBasicInputInterface("LpsCalCmdRespChannel")
LpsCalCmdRespChannelInput["channel"]["queueSize"] = 5;
LpsCalCmdRespChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsCalCmdRespChannel")

LpsSaNvmCalDataChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaNvmCalDataChannel")
LpsSaNvmCalDataChannelInput["channel"]["queueSize"] = 1;
LpsSaNvmCalDataChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaNvmCalDataChannel")

LpsSaNvmCalOnTheFlyDataChannelInput = InterfaceDefs.createBasicInputInterface("LpsSaNvmCalOnTheFlyDataChannel")
LpsSaNvmCalOnTheFlyDataChannelInput["channel"]["queueSize"] = 3;
LpsSaNvmCalOnTheFlyDataChannelOutput = InterfaceDefs.createBasicOutputInterface("LpsSaNvmCalOnTheFlyDataChannel")

MachineOutput = InterfaceDefs.createBasicOutputInterface("Machine")
MachineInput = InterfaceDefs.createBasicInputInterface("Machine")


#D6 Display Brightness
AisJhm2TxChannelInput = InterfaceDefs.createBasicInputInterface("AisJhm2TxChannel")
AisJhm2TxChannelInput["channel"]["queueSize"] = 20;
AisJhm2TxChannelOutput = InterfaceDefs.createBasicOutputInterface("AisJhm2TxChannel")

end
