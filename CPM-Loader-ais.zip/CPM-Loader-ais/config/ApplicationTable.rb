##
## Provides a mapping from an internal identification number to a configuration file.
##   key - A number, as a 2-digit string.
##         Counts up so that the computer doesn't have to count all by itself.
##         I don't know what happens when the number gets to 3-digits.
##   min - A number, as a 5-character string.
##         The last 5 characters of a made up 8 character thing that is called machine serial number, but isn't.
##         This is the minimum one of these strings that will match the 'machineName'.
##   max - A number, as a 5-character string.
##         The last 5 characters of a made up 8 character thing that is called machine serial number, but isn't.
##         This is the maximum one of these strings that will match the 'machineName'.
##   machineName - A string that, when prepended with 'Robot_', and appended with '.rb', will match the config file to use.
##   scenarioPath - A string that indicates what 'scenario' should be used to look for config files.
##
CAT = {
#   key => [min, max, machineName, scenarioPath]
#   --------------------------------------------
    "00" => ["00000", "00000", "NOT_SET", "production"],
    "01" => ["50300", "50300", "CAT_950GC_STD", "production"],
    "02" => ["50301", "50301", "CAT_950GC_HL", "production"],
    "03" => ["50000", "50000", "CAT_950H_STD", "production"],
    "04" => ["50100", "50100", "CAT_950H2_STD", "production"],
    "05" => ["50200", "50200", "CAT_950K_STD", "production"],
    "06" => ["50400", "50400", "CAT_950M_STD", "production"],
    "07" => ["50001", "50001", "CAT_950H_HL", "production"],
    "08" => ["50101", "50101", "CAT_950H2_HL", "production"],
    "09" => ["50201", "50201", "CAT_950K_HL", "production"],
    "10" => ["50401", "50401", "CAT_950M_HL", "production"],
    "11" => ["50002", "50002", "CAT_950H_LOG_BKT", "production"],
    "12" => ["50102", "50102", "CAT_950H2_LOG_BKT", "production"],
    "13" => ["50202", "50202", "CAT_950K_LOG_BKT", "production"],
    "14" => ["50402", "50402", "CAT_950M_LOG_BKT", "production"],
    "15" => ["62000", "62000", "CAT_962H_STD", "production"],
    "16" => ["62100", "62100", "CAT_962H2_STD", "production"],
    "17" => ["62200", "62200", "CAT_962K_STD", "production"],
    "18" => ["62400", "62400", "CAT_962M_STD", "production"],
    "19" => ["62001", "62001", "CAT_962H_HL", "production"],
    "20" => ["62101", "62101", "CAT_962H2_HL", "production"],
    "21" => ["62201", "62201", "CAT_962K_HL", "production"],
    "22" => ["62401", "62401", "CAT_962M_HL", "production"],
    "23" => ["62003", "62003", "CAT_962H_SL", "production"],
    "24" => ["62103", "62103", "CAT_962H2_SL", "production"],
    "25" => ["62202", "62202", "CAT_962K_LOG_BKT", "production"],
    "26" => ["62402", "62402", "CAT_962M_LOG_BKT", "production"],
    "27" => ["66000", "66000", "CAT_966H_STD", "production"],
    "28" => ["66200", "66200", "CAT_966K_STD", "production"],
    "29" => ["66500", "66500", "CAT_966L_STD", "production"],
    "30" => ["66400", "66400", "CAT_966M_STD", "production"],
    "31" => ["66001", "66001", "CAT_966H_HL", "production"],
    "32" => ["66201", "66201", "CAT_966K_HL", "production"],
    "33" => ["66501", "66501", "CAT_966L_HL", "production"],
    "34" => ["66401", "66401", "CAT_966M_HL", "production"],
    "35" => ["66002", "66002", "CAT_966H_LOG", "production"],
    "36" => ["66202", "66202", "CAT_966K_LOG", "production"],
    "37" => ["66502", "66502", "CAT_966L_LOG", "production"],
    "38" => ["66402", "66402", "CAT_966M_LOG", "production"],
    "39" => ["72000", "72000", "CAT_972H_STD", "production"],
    "40" => ["72200", "72200", "CAT_972K_STD", "production"],
    "41" => ["72500", "72500", "CAT_972L_STD", "production"],
    "42" => ["72400", "72400", "CAT_972M_STD", "production"],
    "43" => ["72406", "72406", "CAT_972M_HVY", "production"],
    "44" => ["72001", "72001", "CAT_972H_HL", "production"],
    "45" => ["72201", "72201", "CAT_972K_HL", "production"],
    "46" => ["72501", "72501", "CAT_972L_HL", "production"],
    "47" => ["72407", "72407", "CAT_972M_SHL", "production"],
    "48" => ["72003", "72003", "CAT_972H_SL", "production"],
    "49" => ["72203", "72203", "CAT_972K_SL", "production"],
    "50" => ["72403", "72403", "CAT_972M_SL", "production"],
    "51" => ["80600", "80600", "CAT_980G_STD", "production"],
    "52" => ["80000", "80000", "CAT_980H_STD", "production"],
    "53" => ["80200", "80200", "CAT_980K_STD", "production"],
    "54" => ["80500", "80500", "CAT_980L_STD", "production"],
    "55" => ["80400", "80400", "CAT_980M_STD", "production"],
    "56" => ["80601", "80601", "CAT_980G_HL", "production"],
    "57" => ["80001", "80001", "CAT_980H_HL", "production"],
    "58" => ["80201", "80201", "CAT_980K_HL", "production"],
    "59" => ["80401", "80401", "CAT_980M_HL", "production"],
    "60" => ["80004", "80004", "CAT_980H_12T", "production"],
    "61" => ["80204", "80204", "CAT_980K_12T", "production"],
    "62" => ["80005", "80005", "CAT_980H_BLK", "production"],
    "63" => ["80205", "80205", "CAT_980K_BLK", "production"],
    "64" => ["88201", "88201", "CAT_988K_HL", "production"],
    "65" => ["92201", "92201", "CAT_992K_HL", "production"],
    "66" => ["92200", "92200", "CAT_992K_STD", "production"],
    "67" => ["93201", "93201", "CAT_993K_HL", "production"],
    "68" => ["93200", "93200", "CAT_993K_STD", "production"],
    "69" => ["16020", "16020", "CAT_R1600H_STD", "production"],

}
