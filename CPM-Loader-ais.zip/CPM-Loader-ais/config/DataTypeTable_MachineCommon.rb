DataTypes["Types"].concat(
[
   "LpsSaJobMgrTxChannel",
   "LpsSaJobMgrReqstChannel",
   "LpsSaJobMgrRespChannel",
   "LpsSaJobMgrDebugChannel",
   "LpsSaUIAppTxChannel",

   "LpsSaUIAppReqChannel",
   "LpsSaUIAppRespChannel",
   "LpsSaWeighReqstChannel",
   "LpsSaWeighRespChannel",
   "LpsSaWeighDebugChannel",
   "LpsSaWeighInitDebugChannel",
   "LpsCalCmdReqstChannel",
   "LpsCalCmdRespChannel",
   "LpsSaNvmCalDataChannel",
   "LpsSaNvmCalOnTheFlyDataChannel",
   "Machine",

   "AisJhm2TxChannel",
   "PwmInputChannels",
   "FileTransferBridgeRequest",
   "FileTransferBridgeResponse",
   "FileTransferBridgeIndication",
   "AppReg",
   "VP3Record",
   "CreateFileRequest",
   "OutputChannel",
   "SwitchInputScs",

   "DataLinkData",
   "SerialPrinterRequest",
   "CalMgrCmdReqst",
   "CalMgrCmdResp",
   "CalibrationRequestUI",
   "CalibrationResponseUI",
])

LpsSaJobMgrTxChannel = createLogChannel("LpsSaJobMgrTxChannel")
LpsSaJobMgrReqstChannel = createLogChannel("LpsSaJobMgrReqstChannel")
LpsSaJobMgrRespChannel = createLogChannel("LpsSaJobMgrRespChannel")
LpsSaJobMgrDebugChannel = createLogChannel("LpsSaJobMgrDebugChannel")
LpsSaUIAppTxChannel = createLogChannel("LpsSaUIAppTxChannel")
LpsSaUIAppReqChannel = createLogChannel("LpsSaUIAppReqChannel")
LpsSaUIAppRespChannel = createLogChannel("LpsSaUIAppRespChannel")
LpsSaWeighReqstChannel = createLogChannel("LpsSaWeighReqstChannel")
LpsSaWeighRespChannel = createLogChannel("LpsSaWeighRespChannel")
LpsSaWeighDebugChannel = createLogChannel("LpsSaWeighDebugChannel")
LpsSaWeighInitDebugChannel = createLogChannel("LpsSaWeighInitDebugChannel")
LpsCalCmdReqstChannel = createLogChannel("LpsCalCmdReqstChannel")
LpsCalCmdRespChannel = createLogChannel("LpsCalCmdRespChannel")
LpsSaNvmCalDataChannel = createLogChannel("LpsSaNvmCalDataChannel")
LpsSaNvmCalOnTheFlyDataChannel = createLogChannel("LpsSaNvmCalOnTheFlyDataChannel")
Machine = createLogChannel("Machine")
AisJhm2TxChannel = createLogChannel("AisJhm2TxChannel")
PwmInputChannels = createLogChannel("PwmInputChannels")
FileTransferBridgeRequest = createLogChannel("FileTransferBridgeRequest")
FileTransferBridgeResponse = createLogChannel("FileTransferBridgeResponse")
FileTransferBridgeIndication = createLogChannel("FileTransferBridgeIndication")

AppReg = createLogChannel("AppReg")
AppReg["monitorSequenceNumber"] = false;

VP3Record = createLogChannel("VP3Record")
VP3Record["monitorSequenceNumber"] = false;

CreateFileRequest = createLogChannel("CreateFileRequest")
OutputChannel = createLogChannel("OutputChannel")
SwitchInputScs = createLogChannel("SwitchInputScs")

DataLinkData = createLogChannel("DataLinkData")
DataLinkData["monitorSequenceNumber"] = false;

SerialPrinterRequest = createLogChannel("SerialPrinterRequest")
CalMgrCmdReqst = createLogChannel("CalMgrCmdReqst")
CalMgrCmdResp = createLogChannel("CalMgrCmdResp")
CalibrationRequestUI = createLogChannel("CalibrationRequestUI")
CalibrationResponseUI = createLogChannel("CalibrationResponseUI")

