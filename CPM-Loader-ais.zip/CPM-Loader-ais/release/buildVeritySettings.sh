#!/bin/bash

source $CAT_DIR/scripts/vehDataDir # common source for CAT_DIR on the ECM

# Variables to build name of the verity image
APPNAME=$(basename "${vehDataDir}") #name cannot include underscores
BUILD_ID="0"
SOFTWARE_PNUM="5720171"
CHANGE_LEVEL="00"

# Signing key and cert paths
SIGNING_BASEPATH=${CAT_DIR}/prod/machineCommon/content/util/common/veritySetup
DEVMODE_CERT=${SIGNING_BASEPATH}/signing-cert.pem
DEVMODE_KEY=${SIGNING_BASEPATH}/signing-key.pem
