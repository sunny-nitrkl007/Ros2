#!/bin/sh

#check for lighttpd pid
pid_lighttpd=''

while [ "$pid_lighttpd" == '' ]
do
	pid_lighttpd=$(pidof lighttpd)
done

while [ "$pid_lighttpd" != '' ]
do
	#kill lighttpd
	killall -s SIGTERM lighttpd
	pid_lighttpd=$(pidof lighttpd)
done

#create /opt/etc directory and robot file if it does not exist. touch does not change the contents of file..
if [ ! -d /opt/etc ]; then	
	mkdir -p /opt/etc && echo NOT00000 > /opt/etc/robot         #NOT00000 is default config
elif [ ! -f /opt/etc/robot ]; then
	echo NOT00000 > /opt/etc/robot
else
	echo "Robot is good.." 
fi

#---------------------------------------------------------
# app_init.sh: this script is called by OS on the boot.
#---------------------------------------------------------
source vehDataDir # common source for CAT_DIR on the ECM

# Set env variables for current script and child scripts
export CAT_DIR=${vehDataDir}
export CAT_CONFIG_DIR=${CAT_DIR}/config
export LD_LIBRARY_PATH=${CAT_DIR}/lib:${CAT_DIR}/lib32:${CAT_DIR}/usr/lib:${CAT_DIR}/usr/lib32:$LD_LIBRARY_PATH
export HOME=${vehDataHome}

# Set env variables for all ssh sessions
echo "" >> /etc/profile
echo "# Set AIS env variables for all ssh sessions" >> /etc/profile
echo "export CAT_DIR=${vehDataDir}" >> /etc/profile
echo "export CAT_CONFIG_DIR=${CAT_DIR}/config" >> /etc/profile
echo "export LD_LIBRARY_PATH=${CAT_DIR}/lib:${CAT_DIR}/lib32:${CAT_DIR}/usr/lib:${CAT_DIR}/usr/lib32:$LD_LIBRARY_PATH" >> /etc/profile
echo "export HOME=${vehDataHome}" >> /etc/profile

# Install bash
cp ${CAT_DIR}/usr/bin/bash /bin/

# Install bash
cp ${CAT_DIR}/usr/bin/screen /bin/screen

#assign a6n2 with a secondary ip address so that D6 can connect
ip addr add 165.26.79.19 dev eth0.20

#set i/o serial port to low latency(this can be removed when OS is reverted back to low-latency)
setserial /dev/ttyS2 low_latency 

#Restart lighttpd
/opt/ServiceDashboard/bin/lighttpd -f /opt/ServiceDashboard/config/lighttpd.conf -m /opt/ServiceDashboard/lib/

# Start AIS app
${CAT_DIR}/scripts/autostart

# Launch the RPA Client application
if [ -f ${CAT_DIR}/bin/rpa_client ]; then
 screen -h 1000 -d -m -S rpa_client ${CAT_DIR}/bin/rpa_client
fi

# Make sure our appdata exists, if not, create it
if [ ! -d /opt/appdata/CPM ]
then
	mkdir -p /opt/appdata/CPM
fi

# ensure all files under /opt/appdata/CPM are readable
chmod -R 755 /opt/appdata/CPM
BINDIP=165.26.79.19
if [ -n "$BINDIP" ]; then
  FTPCFG="${CAT_CONFIG_DIR}/vsftpd_logger.conf"
  if [ -f "${FTPCFG}" ]; then
    vsftpd "${FTPCFG}" -olisten_address="${BINDIP}"
    echo "Found IP: ${BINDIP}"
  else
    echo "Unable to locate ${FTPCFG}"
  fi
else
  echo "Could not obtain IP to bind for eth0"
fi

if [ -n "$BINDIP" ]; then
  FTPCFG="${CAT_CONFIG_DIR}/vsftpd_nvm.conf"
  if [ -f "${FTPCFG}" ]; then
    vsftpd "${FTPCFG}" -olisten_address="${BINDIP}"
    echo "Found IP: ${BINDIP}"
  else
    echo "Unable to locate ${FTPCFG}"
  fi
else
  echo "Could not obtain IP to bind for eth0"
fi


# wait for RESTART file  /opt/appdata/CPM/restart.txt
while :
do
	if [ -f /opt/appdata/CPM/restart.txt ]
	then
	    ${CAT_DIR}/scripts/launchSystem
	    rm /opt/appdata/CPM/restart.txt
	else
	    # clear rtc wakeup alarm - temporary patch to address potential Iowa issue
	    echo 1 > /sys/class/rtc/rtc0/wakealarm_clear
	    sleep 1
	fi
done


