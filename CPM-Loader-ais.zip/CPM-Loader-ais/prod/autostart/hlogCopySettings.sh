#!/bin/bash
hlog_user="root"
hlog_ecm="165.26.79.19"
hlog_dest="/opt/log/productionLogs" #on the ecm
hlog_output_path="${HOME}/log" #on local pc
ais_sw_path="/opt/CPM" #on the ecm
addtnl_ssh_prms="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
hlogcopy_libs="LD_LIBRARY_PATH=/opt/CPM/lib:/opt/CPM/lib32:/opt/CPM/usr/lib:/opt/CPM/usr/lib32" #on the ecm
hlogcopy_path="${CAT_DIR}/bin" #on local pc
