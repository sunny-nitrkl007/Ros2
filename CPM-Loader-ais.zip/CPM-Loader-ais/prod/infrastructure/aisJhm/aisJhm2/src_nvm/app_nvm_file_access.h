/*******************************************************************************
 Copyright 2017 Caterpillar Inc. All rights reserved.
--------------------------------------------------------------------------------
File name: app_nvm_file_access.h

Description:This file contains test code to test the nvm_file feature 
*******************************************************************************/
#ifndef STD_TYPES_H_
#include <std_types.h>
#endif

typedef struct
{
	unsigned int units;
	unsigned int languageIndx;
	unsigned int brightness;
	unsigned int servicepass;
}jhmNMV_t;


extern volatile boolean OelBootupFlag;
extern volatile boolean jhmNVMDataReadFlag;
extern volatile boolean jhmNVMDataWriteFlag;
extern volatile boolean jhmNVMDataWriteFeedback;
extern volatile jhmNMV_t jhmNVMData;
extern volatile jhmNMV_t jhmNVMDataRd;
extern volatile boolean jhmNVMDataReadStatus;
extern volatile jhmNMV_t jhmNVMDataDefault;

extern void app_nvm_file_read(void);
extern void app_nvm_file_write(void);
