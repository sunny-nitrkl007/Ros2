/*******************************************************************************
 Copyright 2016 Caterpillar Inc. All rights reserved.
--------------------------------------------------------------------------------
File name: app_nvm_file_access.c

Description:This file contains test code to test the nvm_file feature 
 *******************************************************************************/
#include "app_nvm_globals.h"
#include "app_nvm_file_access.h"
#include <stdio.h>
volatile boolean jhmNVMDataReadStatus = FALSE;
volatile boolean jhmNVMDataWriteFeedback = FALSE;

/*******************************************************************************
Function name: app_nvm_file_write

Description:  
test the nvm_file. 

Parameter Description: 

Return Description:     
    None
 *******************************************************************************/
void app_nvm_file_write(void)
{

        if(jhmNVMData.units < 0 || jhmNVMData.units > 2)
	{

	printf("invalid units NVMData  %d \n",jhmNVMData.units);
	jhmNVMData.units = 0;
	}
	if(jhmNVMData.languageIndx < 0 || jhmNVMData.languageIndx >500)
	{
		
	printf("invalid languageIndx NVMData  %d \n",jhmNVMData.languageIndx);
	jhmNVMData.languageIndx = 0;
	}
	if(jhmNVMData.brightness < 0 || jhmNVMData.brightness >100)
	{
		
	printf("invalid displayBrightness NVMData  %d \n",jhmNVMData.brightness);
	jhmNVMData.brightness = 50;
	}

	if((jhmNVMData.servicepass < 0) || (jhmNVMData.servicepass > 99999))
	{
	    printf("invalid operatorId in NVM Data %d\n",jhmNVMData.servicepass);
	    jhmNVMData.servicepass = 1925;
	}

    if(NVM_SUCCESS == nvm_block_write(
    		CalPressDataNvmBlkHndl,
    		sizeof(jhmNMV_t),
            0,
            	(unsigned_8 *)&jhmNVMData,
            NVM_CURRENT_TASK_PRIORITY))
    {
        printf("\n jhm Data units write Success in NVM units:%d  languageIndx:%d  displayBrightness:%d\n",jhmNVMData.units,jhmNVMData.languageIndx,jhmNVMData.brightness);
	jhmNVMDataRd.units = jhmNVMData.units;
        jhmNVMDataRd.languageIndx = jhmNVMData.languageIndx;
        jhmNVMDataRd.brightness = jhmNVMData.brightness;
        jhmNVMDataRd.servicepass = jhmNVMData.servicepass;
    }
    else
    {
	printf("\n jhm Data units write FAILED in NVM: %d\n",jhmNVMData.units);
    }

}
/*******************************************************************************
Function name: app_nvm_file_read

Description:
test the nvm_file.

Parameter Description:

Return Description:
    None
 *******************************************************************************/
void app_nvm_file_read(void)
{
	jhmNVMDataReadStatus = FALSE;

	if(NVM_SUCCESS == nvm_block_read(
			//app_nvm_file_block_table[0],  /* block handle */
			CalPressDataNvmBlkHndl,
			sizeof(jhmNMV_t),                           /* size to be written */
			0,                              /* offset */
			(unsigned_8 *)&jhmNVMDataRd,                    /* destination buffer */
			NVM_CURRENT_TASK_PRIORITY))              /* priority */
	{
		printf("jhmNVMDataRd read success: %d\n",jhmNVMDataRd.units);
		if(jhmNVMDataRd.units < 0 || jhmNVMDataRd.units > 2)
		{
			jhmNVMDataRd.units = 0;
			printf("invalid units NVMDataRd  %d \n",jhmNVMDataRd.units);
		}
		if(jhmNVMDataRd.languageIndx < 0 || jhmNVMDataRd.languageIndx >500)
		{
			jhmNVMDataRd.languageIndx = 0;
			printf("invalid languageIndx NVMDataRd  %d \n",jhmNVMDataRd.languageIndx);
		}
		if(jhmNVMDataRd.brightness < 0 || jhmNVMDataRd.brightness >100)
		{
			jhmNVMDataRd.brightness = 50;
			printf("invalid displayBrightness NVMDataRd  %d \n",jhmNVMDataRd.brightness);
		}
		if(jhmNVMDataRd.servicepass < 0 || jhmNVMDataRd.servicepass >99999)
		{
			jhmNVMDataRd.servicepass = jhmNVMDataDefault.servicepass;
			printf("invalid Servicepass NVMDataRd  %d \n",jhmNVMDataRd.servicepass);
		}

		jhmNVMDataReadStatus = TRUE;
		jhmNVMDataReadFlag = FALSE;
	}
	else
	{
		printf("jhmNVMDataRd read FAILED: %d\n",jhmNVMDataRd.units);
		jhmNVMDataRd = jhmNVMDataDefault;
	}


}
