/******************************************************************************************************************
 Copyright 2017 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------------------------------------------
File name: app_nvm_file_cfg.c

Description:This file contains the nvm_file configuration details
******************************************************************************************************************/

#include "app_nvm_file_cfg.h"
#include "app_nvm_globals.h"
#include "app_nvm_file_access.h"

char NvmFileName[200];
char NvmFilepath[200];

//jhmNMV_t jhmNVMData;
//jhmNMV_t jhmNVMDataRd;

const nvm_file_block_cfg_t app_nvm_file_cfg[]=
{
    {
    	JHM_DATA_NVID,
    	NvmFileName,
        NULL,
        sizeof(jhmNMV_t),
        NVM_FILE_CRC_BLK
    },
};

const unsigned short int BlockSize = (sizeof(app_nvm_file_cfg)/sizeof(app_nvm_file_cfg[0]));
