/******************************************************************************************************************
 Copyright 2017 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------------------------------------------
File name: app_nvm_file_init.c

Description:This file contains startup and initialization code for nvm_file
******************************************************************************************************************/

#include "app_nvm_file_init.h"
#include "app_nvm_file_cfg.h"
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/types.h>
#include "app_nvm_file_access.h"

NVM_block_handle_t CalPressDataNvmBlkHndl ;
volatile jhmNMV_t jhmNVMData = {0,0,50,1925};
volatile jhmNMV_t jhmNVMDataDefault = {0,0,50,1925};
struct stat nvm ={0};
boolean NvmJHMFileCreateFlag=FALSE;

/******************************************************************************************************************
Function name: app_nvm_file_init

Description:  
Intialzie the nvm_file. 

Parameter Description: 
    
Return Description:     
    None
*****************************************************************************************************************/
void app_nvm_file_init(void)
{
    int sys_ret,indx;
    char command[200];
    char id_char[30];
    struct stat nvmfile ={0};
    unsigned int ret;

    jhmNVMDataWriteFlag = FALSE;
    jhmNVMDataReadFlag  = FALSE;
    jhmNVMDataWriteFeedback = FALSE;

    strcpy(NvmFilepath, getenv("HOME"));
    strcat(NvmFilepath, "/appdata/CPM/JHM/nvm");

    strcpy(id_char,"/NvmjhmApp.txt");
    strcpy(NvmFileName, NvmFilepath);
    strcat(NvmFileName, id_char);
    strcpy(command, "mkdir --mode=755 -p ");
    strcat(command, NvmFilepath);

    // Create location for NVM log, if it doesn't already exist.
    if(stat(NvmFilepath, &nvm) == -1)
    {
        sys_ret = system(command);
        (void) sys_ret;
    }

    if(stat(NvmFileName, &nvmfile) == -1)
    {
        printf("nvm calibration file does not exist \n");
        NvmJHMFileCreateFlag = TRUE;
    }

    if(NVM_SUCCESS == nvm_file_init(BlockSize))
    {
    	for(indx = 0; indx < BlockSize; indx++)
        {
    		ret = nvm_file_block_cfg(&app_nvm_file_cfg[indx]);

        	if(NVM_SUCCESS == ret)
            {
        		printf("jhm nvm_file_block_cfg SUCCESs \n");

        		ret = nvm_block_init(
                		NVM_BLOCK_CACHED,
                		(unsigned_8 *)&jhmNVMData,
                        JHM_DATA_NVID,
                        NVM_CURRENT_TASK_PRIORITY,
                        &CalPressDataNvmBlkHndl);

                if(NVM_SUCCESS == ret)
                {
                    printf("jhm nvm_block_init %d success\n", indx);
                    if(NvmJHMFileCreateFlag == TRUE) {
                        jhmNVMData = jhmNVMDataDefault;
                        jhmNVMDataWriteFlag = TRUE;
                        NvmJHMFileCreateFlag = FALSE;
                    }
                    jhmNVMDataReadFlag = TRUE;
                }
                else
                {
                	jhmNVMData = jhmNVMDataDefault;

                	printf("nvm_block_init %d failed\n", indx);

                	//app_nvm_file_write(); 
                }

                //jhmNVMDataWriteFlag = TRUE;

            }
            else
            {
                printf("nvm_file_block_cfg  %d failed\n", indx);
            }
        }
    }
    else
    {
        printf("nvm_file_init failed\n");
        jhmNVMDataRd.units = 0;
        		jhmNVMDataRd.languageIndx = 0;
        		jhmNVMDataRd.brightness = 50;

     			jhmNVMDataRd.servicepass = 1925;
    }

    return;
}
