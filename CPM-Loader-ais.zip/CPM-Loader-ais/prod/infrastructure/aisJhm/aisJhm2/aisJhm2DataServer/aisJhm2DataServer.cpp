///////////////////////////////////////////////////////////////////////////////
/// @file      aisJhm2DataServer.cpp
/// @author    Josh Struble
/// @date      Aug 15, 2014
/// @brief     App to serve data to CGI web script
///
/// @attention Copyright (C) 2013
/// @attention Caterpillar, Inc.
///////////////////////////////////////////////////////////////////////////////
#include "aisJhm2DataServer.h"
#include "AisJhm2RequestProcessor/AisJhm2RequestProcessor.h"

using namespace task;
using namespace std;
int msn;
char *msn1;
///////////////////////////////////////////////////////////////////////////////
/// @brief This is the task creation method.
/// @return Task* Pointer to the instance of the task.
///////////////////////////////////////////////////////////////////////////////
AbstractTaskCore* task::getTaskImplementation(void)
{
  static aisJhm2DataServer thisTask("AisJhm2DataServer");
  return &thisTask;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Constructor
///
/// @param taskName Unique name for this task
///////////////////////////////////////////////////////////////////////////////
aisJhm2DataServer::aisJhm2DataServer( const std::string& taskName ):
  Task( taskName ),
  m_requestServer(),
  m_requestProc()
{
commInitialize();
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Destructor
///////////////////////////////////////////////////////////////////////////////
aisJhm2DataServer::~aisJhm2DataServer( )
{

}

///////////////////////////////////////////////////////////////////////////////
/// @brief Initialize method.
///
/// This method initializes the task's interfaces and configurable parameters.
///
/// @return True if successful, False otherwise
///////////////////////////////////////////////////////////////////////////////
bool aisJhm2DataServer::initialize( )
{
  if ( !m_requestProc.configure( getTaskParser() ) )
  {
    LOG_FATAL("Could not configure task parameters");
    return false;
  }

  ConfigSection machineData;

  if(!getTaskParser().get("MachineType1", machineData))
  {
    getLogger().log_error("Couldnt find MachineType1 config in Robot_CAT_972M_STD.rb for Machine model");
    return false;
  }
  
  machineData.get( "InternalMsn", machineMSN );

  std::vector<std::string> machineNames;

  if(!machineData.get("Types", machineNames))
  {
    getLogger().log_fatal("Couldnt find MachineType1->Type in ruby file");
    return false;
  }

  if(machineNames.empty())
  {
    getLogger().log_fatal("machine model in ruby is empty");
    return false;
  }

 MM_Selected_Make_Rd = machineNames[0];
MM_Selected_Machine_Rd = machineNames[1];
MM_Selected_Linkage_Rd=machineNames[2];
  for(std::vector<std::string>::iterator ii = machineNames.begin(); ii != machineNames.end(); ++ii)
  {

getLogger().log_error( " Selected Machine model from ruby file %s",ii->c_str() );
}


  return true;
}


///////////////////////////////////////////////////////////////////////////////
/// @brief This is the task's executive method.
///
/// This method will process user input from the keyboard.  Each key press
/// event is possibly a command to be relayed to the other PCM processes.
///
/// @return True if the task should continue executing, False otherwise.
///////////////////////////////////////////////////////////////////////////////
bool aisJhm2DataServer::executive( )
{
  static boolean globals_initialized = FALSE;

  m_requestProc.update();

  if (OelBootupFlag && !globals_initialized) {
	  units = jhmNVMDataRd.units;
	  languIndx = jhmNVMDataRd.languageIndx;
	  servicepass = jhmNVMDataRd.servicepass;
	  displayBrightness = jhmNVMDataRd.brightness;

	  LOG_INFO("\n jhm Data units initialized Success in NVM units:%d  languageIndx:%d  displayBrightness:%d ServicePassword: %d\n",jhmNVMDataRd.units,jhmNVMDataRd.languageIndx,jhmNVMDataRd.brightness,jhmNVMDataRd.servicepass);

	  globals_initialized = TRUE;
  }

  m_requestProc.PublishtoUITxChannel();

  if ( m_requestServer.initialized() )
  {
    m_requestServer.update( m_requestProc );
  } else
  {
    if ( !m_requestServer.initialize() )
    {
      LOG_CRIT("Failed to initialize request server");
    }
  }

  return true;
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Cleanup task
///////////////////////////////////////////////////////////////////////////////
void aisJhm2DataServer::cleanup( )
{
	m_requestProc.cleanup();
}

