///////////////////////////////////////////////////////////////////////////////
/// @file      SatsJhm2ScsOutputs.h
/// @author    Safeer
/// @date      3/28/2017
/// @brief     Structure containing all going out to SCS
///
/// @attention COPYRIGHT (C) 2012 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////
#ifndef SATSJHM2SCSOUTPUTS_H_
#define SATSJHM2SCSOUTPUTS_H_

#include <ais/config/ConfigSection.h>
#include <scsIOContainer/SCSOutputs.h>
#include <scsIOContainer/SCSOutData.h>

//Interfaces we want to receive and store

#include <interfaces/LpsSaJobMgrReqstChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighReqstChannel/InterfaceTypes.h>
#include <interfaces/AisJhm2TxChannel/InterfaceTypes.h>
#include <interfaces/LpsSaUIAppRespChannel/InterfaceTypes.h>
#include <interfaces/LpsSaUIAppTxChannel/InterfaceTypes.h>
#include <../../../machineCommon/content/prod/common/interfaces/MachineSN/InterfaceTypes.h>

class AisJhm2ScsOutputs : public SCSOutputs
{

 public:
  
  SCSOutData<LpsSaJobMgrReqstChannel>  m_jhm_jobMgrReq;
  SCSOutData<LpsSaWeighReqstChannel>   m_jhm_WeighReq;
  SCSOutData<AisJhm2TxChannel>         m_jhm_payLoadReq;
  SCSOutData<MachineSN>                m_jhm_MachineSN;
  SCSOutData<LpsSaUIAppTxChannel>     m_jhm_LpsSaUITxRes;
  SCSOutData<LpsSaUIAppRespChannel>   m_jhm_LpsSaUIRes;
  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Run "send" on all of the scs channels in the structure
  ///
  /// @return true if any channel has new data, false otherwise
  ///////////////////////////////////////////////////////////////////////////////

  bool send()
  {
    bool retVal = false;
    if ( m_jhm_jobMgrReq.send() ) retVal = true;
    if ( m_jhm_WeighReq.send() ) retVal = true;
    if ( m_jhm_payLoadReq.send() ) retVal = true;
    if ( m_jhm_MachineSN.send() ) retVal = true;
    if ( m_jhm_LpsSaUIRes.send() ) retVal = true;
    if ( m_jhm_LpsSaUITxRes.send() ) retVal = true;
    printf("AisJhm2TxChannelOutput send  retVal:%d \n",retVal);
    return retVal;
}

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Run "initPublishInterface" on all of the scs channels in the structure
  ///
  /// @return true if all interfaces were successfully configured, false if any failed
  ///////////////////////////////////////////////////////////////////////////////
  bool initPublishInterface( ConfigSection& cs )
  {
cout<<"#################################################################################################################333"<<"pbulisheed"<<endl;
    bool retVal = true;
    
    if ( !m_jhm_jobMgrReq.initPublishInterface("LpsSaJobMgrReqstChannelOutput", cs) ) retVal = false;
    if ( !m_jhm_WeighReq.initPublishInterface("LpsSaWeighReqstChannelOutput", cs) ) retVal = false;
    printf("LpsSaWeighReqstChannelOutput publish  retVal:%d \n",retVal);
    if ( !m_jhm_LpsSaUIRes.initPublishInterface("LpsSaUIAppRespChannelOutput",cs)) retVal =false;
    if ( !m_jhm_payLoadReq.initPublishInterface("AisJhm2TxChannelOutput", cs) ) retVal = false;
    if ( !m_jhm_LpsSaUITxRes.initPublishInterface("LpsSaUIAppTxChannelOutput",cs)) retVal = false;
    printf("AisJhm2TxChannelOutput publish  retVal:%d \n",retVal);
    cout<<"#################################################################################################################333"<<"pbulisheed"<<endl;
    if ( !m_jhm_MachineSN.initPublishInterface("MachineSNOutput", cs) ) retVal = false;
    printf("MachineSNOutput publish  retVal:%d \n",retVal);

    return retVal;
  }

};

#endif /*SATSJHM2SCSOUTPUTS_H_*/
