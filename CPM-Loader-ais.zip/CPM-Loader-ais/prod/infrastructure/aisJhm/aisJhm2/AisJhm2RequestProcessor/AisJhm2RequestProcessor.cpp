///////////////////////////////////////////////////////////////////////////////
/// @file      AisJhm2RequestProcessor.cpp
/// @author    strubjc
/// @date      Aug 15, 2013
/// @brief     
///
///
/// @attention COPYRIGHT (C) 2012 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////

#define LAST(k,n) ((k) & ((1<<(n))-1))
#define MID(k,m,n) LAST((k)>>(m),((n)-(m)))
#include "AisJhm2RequestProcessor.h"
#include <ais/config/ConfigSection.h>
#include <ais/log/Logger.h>
#include <ais/time/ConvertTime.h>
#include <ais/util/stringUtils.h>
#include <jhm2/Jhm2Param/Jhm2SimpleParam.h>
#include <jhm2/Jhm2Param/XmlTypeConverters.h>
#include <nvm.h>
#include "../src_nvm/app_nvm_file_access.h"
#include "boost/property_tree/json_parser.hpp"
#include <boost/property_tree/ptree.hpp>
#include <boost/foreach.hpp>
#include <interfaces/LpsSaJobMgrReqstChannel/LpsSaJobMgrReqstChannel.h>
#include <interfaces/LpsSaUIAppTxChannel/InterfaceTypes.h>
#include <fstream>
#include <dirent.h>
#include "machineModelList.h"
#include <errno.h>
#include <unistd.h>
#include <queue>

using boost::property_tree::ptree;
/*****global variables for password*********/
bool ServiceModeEnable_Status = 0;

bool PwdAuthorized = 0;
/*******************************************/
int selectedMachine_rd = -1;
float CalibrationWeightEntry = 0,jhmWeighRangeBottom = 0,jhmWeighRangeSize = 0;
const std::string AisJhm2RequestProcessor::m_PARAMSREQUETED_KEY = "paramsRequested";
const std::string AisJhm2RequestProcessor::m_IMAGEREQUETED_KEY = "imageRequested";
const std::string AisJhm2RequestProcessor::m_COMMANDREQUETED_KEY = "commandRequested";
const std::string AisJhm2RequestProcessor::m_COMMANDID_KEY = "commandId";
const std::string AisJhm2RequestProcessor::m_TESTTYPE_KEY = "testType";

 //=============================================================================
AisJhm2RequestProcessor::AisJhm2RequestProcessor()
{
	// TODO Auto-generated constructor stub
}

//=============================================================================
AisJhm2RequestProcessor::~AisJhm2RequestProcessor()
{
  // TODO Auto-generated destructor stub
}

/******************************************************************************
FUNCTION:                   configure
DESCRIPTION:                Initialize to configure the SCS channels
PARAMETER DESCRIPTION:
RETURN VALUE:               boolean  
*******************************************************************************/
bool AisJhm2RequestProcessor::configure( TaskParser& tp )
{
    ConfigSection cs;
    if ( !tp.getSection("ScsRxTimeouts", cs) )
    {
      LOG_FATAL( "Couldn't find ScsRxTimeouts Config Section in rb file" );
      return false;
    }
    m_scsInputs.initReadInterface( cs );

    if ( !tp.getSection("ScsTxRates", cs) )
    {
      LOG_FATAL( "Couldn't find ScsRxTimeouts Config Section in rb file" );
      return false;
    }

    if(!m_scsOutputs.initPublishInterface(cs))
     return false;   
    
    return true;
}

/******************************************************************************
FUNCTION:                   update
DESCRIPTION:                call the SCS INPUTS update function
PARAMETER DESCRIPTION:
RETURN VALUE:               Boolean  
*******************************************************************************/
bool AisJhm2RequestProcessor::update( )
{
  return m_scsInputs.update();
}

void AisJhm2RequestProcessor::cleanup( )
{
	
}

/******************************************************************************
FUNCTION:                   getResponse
DESCRIPTION:                get the respose from the Jhm2ParamMsgRequest
PARAMETER DESCRIPTION:
RETURN VALUE:               address  
*******************************************************************************/

Jhm2Msg* AisJhm2RequestProcessor::getResponse( const Jhm2ParamMsgRequest& req )
{
  {
    //This request needs parameters requested
    if ( req.hasReqData(m_PARAMSREQUETED_KEY) )
    {
      Jhm2ParamMsg* newResp = new Jhm2ParamMsg();
      if ( processRequest( req, *newResp ) )
      {
        return newResp;
      }
      delete newResp;
      return NULL;
    }
  }

//  {
//    //This request is for an image
//    if ( req.hasReqData(m_IMAGEREQUETED_KEY) )
//    {
//      Jhm2ImageMsg* newResp = new Jhm2ImageMsg();
//      if ( processRequest( req, *newResp ) )
//      {
//        return newResp;
//      }
//      delete newResp;
//      return NULL;
//    }
//  }
//
  {
    //This request is to execute a command
    if ( req.hasReqData(m_COMMANDREQUETED_KEY) )
    {
      Jhm2CmdResponseMsg* newResp = new Jhm2CmdResponseMsg();
      if ( processRequest( req, *newResp ) )
      {
        return newResp;
      }
      delete newResp;
      return NULL;
    }
  }

  //Can't process this request
  return NULL;
}

/******************************************************************************
FUNCTION:                   processRequest
DESCRIPTION:                extract the HTTP request Query String and pass that to the function named as processRequestFromGPSPosition1 as a argument and proceed to give the response to UI
PARAMETER DESCRIPTION:
RETURN VALUE:               boolean
*******************************************************************************/

bool AisJhm2RequestProcessor::processRequest( const Jhm2ParamMsgRequest& req, Jhm2ParamMsg& resp )
{
  const Jhm2ParamMsgRequest::ReqDataT& paramsRequested = req.getReqData(m_PARAMSREQUETED_KEY);
  for ( Jhm2ParamMsgRequest::ReqDataT_Cit it = paramsRequested.begin(); it != paramsRequested.end(); ++it )
  {
    LOG_DEBUG( "Processing Parameter Request %s", (*it).c_str() );

    processRequestFromGPSPosition1( *it, resp );

  }

  return true;
}

/******************************************************************************
FUNCTION:                   unitConversion
DESCRIPTION:                used to convert the weight to whether TonnesToTon(US) or TonnesToPounds
PARAMETER DESCRIPTION:
RETURN VALUE:               
********************************************m_scsOutputs.m_jhm_MachineSN.m_machineSN.m_status = 0;
	m_scsOutputs.m_jhm_MachineSN.m_machineSN.m_value = calibstr[0].second;
	***********************************/

void AisJhm2RequestProcessor::unitConversion( float valReadfrmCPM,int unitStoredInNVM, float &unitConverted1)//, float &CurUnit)
{

  /**
  0 Metric tonnes,1 ton, 2 pounds
  **/
	float TonnesToPounds = 2.20462;//TonnesToPounds with *1000 factor
	float TonnesToTon = 1.10231;//TonnesToTon(US)

    switch(unitStoredInNVM)
    {

    case 0:
	unitConverted1 = valReadfrmCPM;
	break;
    case 1:
	unitConverted1 = TonnesToTon * valReadfrmCPM;
	break;
    case 2:
	unitConverted1 = TonnesToPounds * valReadfrmCPM;
	break;

    default:
	unitConverted1 = valReadfrmCPM;
	break;
    }

}
/******************************************************************************
FUNCTION:                   unitConversiontoDefaultMetric
DESCRIPTION:                used to convert the weight to whether TonToPounds or PoundsToTonnes
PARAMETER DESCRIPTION:
RETURN VALUE:                
*******************************************************************************/

void AisJhm2RequestProcessor::unitConversiontoDefaultMetric(float valReadfrmWebApp,int unit2StoredInNVM, float &unitConverted2)
{

	/**
	0 Metric tonnes,1 ton, 2 pounds
	**/
	float PoundsToTonnes = 0.4535929094356397;//PoundsToTonnes with *1000 factor  = 1/(2.20462) =0.4535929094356397
	float TonToTonnes = 0.9071858188712794;//TonnesToTon(US) = 1/1.10231 = 0.9071858188712794

	
    switch(unit2StoredInNVM)
    {

		case 0:
			unitConverted2 = valReadfrmWebApp;
			break;
		case 1:
			unitConverted2 = TonToTonnes * valReadfrmWebApp;
			break;
		case 2:
			unitConverted2 = PoundsToTonnes * valReadfrmWebApp;
			break;

		default:
			unitConverted2 = valReadfrmWebApp;
			break;
    }

}
/******************************************************************************

FUNCTION:                   processRequestFromGPSPosition1
DESCRIPTION:                Read the http request Query string and send the Respose in JSON format to UI
PARAMETER DESCRIPTION:
RETURN VALUE:               boolean 
*******************************************************************************/

bool AisJhm2RequestProcessor::processRequestFromGPSPosition1( const std::string& req, Jhm2ParamMsg& resp )
{
  unsigned char dsi = 0;
  unsigned short int AccuracyStartbit = 8;
  unsigned short int AccuracyEndbit = 12;
  //unsigned short int AccuracyHigh = 3;
  float unitConverted = 0.0;
  string rawstr,res;
  DIR *dir;
  struct dirent *ent;
 
  std::string str = "3,351-1,849-2,459-3";

  if ( req == "PassCount" )
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi, m_scsInputs.m_jhm_jobMgr.PassCount ));
  }
  else if ( req == "TargetWeight" )
  {	
	/* Wait till OEL layer boot up*/
    while(FALSE == OelBootupFlag);
    unitConversion(m_scsInputs.m_jhm_jobMgr.TargetWeight, jhmNVMDataRd.units, unitConverted);
    resp.insertParam( new Jhm2SimpleParam( req, dsi, unitConverted ));
  }
  else if ( req == "TruckWeight" )
  {
	/* Wait till OEL layer boot up*/
    while(FALSE == OelBootupFlag);
    unitConversion(m_scsInputs.m_jhm_jobMgr.TruckWeight, jhmNVMDataRd.units, unitConverted);
    resp.insertParam( new Jhm2SimpleParam( req, dsi, unitConverted ));

  }
  else if ( req == "MaterialID" )
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi,m_scsInputs.m_jhm_jobMgr.MaterialID));
  }
  else if ( req == "BestBktWtInTonnes" )
  {
	  /* Wait till OEL layer boot up*/
    while(FALSE == OelBootupFlag);
    unitConversion(m_scsInputs.m_jhm_weigh.BestBktWtInTonnes, jhmNVMDataRd.units, unitConverted);
    resp.insertParam( new Jhm2SimpleParam( req, dsi, unitConverted ));	
  }
  else if ( req == "BWAccuracyEnable" )
  {
    
   if((m_scsInputs.m_jhm_jobMgr.DispBestBktWt.Stat == 1) )
   {
   resp.insertParam( new Jhm2SimpleParam( req, dsi,0));//to show ***
   }
   else
   {
	if((MID(m_scsInputs.m_jhm_weigh.PayloadCalcMeth,AccuracyStartbit,AccuracyEndbit) == 3) && (m_scsInputs.m_jhm_jobMgr.DispBestBktWt.Stat == 0))
	{
	resp.insertParam( new Jhm2SimpleParam( req, dsi,MID(m_scsInputs.m_jhm_weigh.PayloadCalcMeth,AccuracyStartbit,AccuracyEndbit)));
	}
	/*else if(MID(m_scsInputs.m_jhm_weigh.PayloadCalcMeth,AccuracyStartbit,AccuracyEndbit) == 0 && m_scsInputs.m_jhm_jobMgr.DispBestBktWt.Stat == 0)
	{
	resp.insertParam( new Jhm2SimpleParam( req, dsi,0));//to show ****
	}*/
	else
	{
	resp.insertParam( new Jhm2SimpleParam( req, dsi,1));
	}
   }
  }
  else if( req == "StandByStatus")
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi, m_scsInputs.m_jhm_jobMgr.StandbyState));
  }
  else if( req == "MinusOneClearStatus")
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi, m_scsInputs.m_jhm_jobMgr.ClearMinusOneEnableStat));
  }
  else if( req == "TipOffState")
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi, m_scsInputs.m_jhm_jobMgr.TipOffState ));
  }
  else if( req == "ManualTipOffState")
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi, m_scsInputs.m_jhm_jobMgr.ManualTipOffState ));
  }
//  else if( req == "Units_Rd" )
//  {
//    resp.insertParam( new Jhm2SimpleParam( req, dsi,jhmNVMDataRd.units));
//  }
  else if(  req == "WeighRangeBottom" )
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi,m_scsInputs.m_jhm_weigh.WeighRange.WeighRangeBottom ));
  }
  else if( req == "WeighRangeSize" )
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi,m_scsInputs.m_jhm_weigh.WeighRange.WeighRangeSize ));
  }
  else if( req == "LiftCylinderPos_Rd" )
  {
	  resp.insertParam( new Jhm2SimpleParam( req, dsi,m_scsInputs.m_jhm_weigh.LiftCylExt.Val ));
  }



  /************************************NVM read and write operations   **********************************************************************/
    else if( req == "Units_Rd" )
    {

  	  LOG_INFO("\nm_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqFlag %d",m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqFlag);

    	  if(m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqFlag == 1)
    	  {
    	    jhmNVMData.units = m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqVal;
    	  	jhmNVMDataWriteFlag = TRUE;
    	  	units = m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqVal;
         resp.insertParam( new Jhm2SimpleParam( req, dsi,m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqVal));
         LOG_INFO("\n the value of the Units_Rd from LpsSaUIAppRequestChannel SCSObjectName:PidTable.PidF25B_InfoUnitStat.ReqVal is %d", m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqVal );
         LOG_INFO("\n the value of the Units_Rd written in NVM is %d",jhmNVMDataRd.units);
    	  }
    	  else
    	  {

    		  resp.insertParam( new Jhm2SimpleParam( req, dsi,units));
    		  LOG_INFO("\n the value of the Units_Rd written in NVM is %d and no new changes",jhmNVMDataRd.units);
  	  }
    }

    else if( req == "Language_Rd" )
     {

  	  LOG_INFO("\n m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqFlag%d",m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqFlag);

   	  if(m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqFlag == 1)
   	  {

   	   resp.insertParam( new Jhm2SimpleParam( req,dsi,m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqVal));
   	   jhmNVMData.languageIndx = m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqVal;
   	   jhmNVMDataWriteFlag = TRUE;
   	   languIndx = m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqVal;
   	   LOG_INFO("\n the value of the Language_Rd from LpsSaUIAppReqChannel SCSObjectname:PidTable.PidD0022C_DispLangStat.ReqVal is %d",m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqVal);
   	   LOG_INFO("\n the value of the language read from the NVM is %d",jhmNVMDataRd.languageIndx);
   	  }
   	  else
   	  {

   	   resp.insertParam( new Jhm2SimpleParam( req,dsi,languIndx));
   	  LOG_INFO("\n the value of the language read from the NVM is %d and no new changes",jhmNVMDataRd.languageIndx);
 	  }
     }



  else if( req == "DisplayBrightness_Rd" )
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi,jhmNVMDataRd.brightness));
    LOG_INFO("DispBrightness Read %d \n",jhmNVMDataRd.brightness);
  }
  else if( req == "TipOffTriggerMode_Rd")
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi, m_scsInputs.m_jhm_jobMgr.TipOffTriggerType ));
  }
  else if( req == "TipOffMode_Rd")
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi, m_scsInputs.m_jhm_jobMgr.TipOffStateCfg));
  }
  else if(req == "Active_Faultlist_Rd")
  {
    resp.insertParam( new Jhm2SimpleParam( req, dsi,str) );
  }
   else if(req == "MM_Selected_Rd")
  {
	if(MM_Selected_Make_Rd.empty())
	resp.insertParam( new Jhm2SimpleParam(req, dsi,selectedMachine_rd));
	else
	{
    	resp.insertParam( new Jhm2SimpleParam( "MM_Selected_Make_Rd",MM_Selected_Make_Rd));
	resp.insertParam( new Jhm2SimpleParam( "MM_Selected_Machine_Rd",MM_Selected_Machine_Rd));
	resp.insertParam( new Jhm2SimpleParam( "MM_Selected_Linkage_Rd",MM_Selected_Linkage_Rd));
	}
        LOG_INFO("\n MM_Selected_Make_Rd  %s \n",MM_Selected_Make_Rd.c_str());
        LOG_INFO("\n MM_Selected_Machine_Rd  %s \n",MM_Selected_Machine_Rd.c_str());
        LOG_INFO("\n MM_Selected_Linkage_Rd  %s \n",MM_Selected_Linkage_Rd.c_str());    
    
  }

  else if(req == "LifeTimeTruckLoadCount_Rd")
  {

    resp.insertParam( new Jhm2SimpleParam( req, dsi,m_scsInputs.m_jhm_jobMgr.LifetimeTruckLoadCount));
  }
  else if(req == "LifeTimeTotalPayLoad_Rd")
  {
    while(FALSE == OelBootupFlag);
    unitConversion(m_scsInputs.m_jhm_jobMgr.LifetimeTotalPayload, jhmNVMDataRd.units, unitConverted);
    resp.insertParam( new Jhm2SimpleParam( req, dsi,unitConverted));

  }

  else if(req == "LifeTimeCycleCount_Rd")

  {

    resp.insertParam( new Jhm2SimpleParam( req, dsi,m_scsInputs.m_jhm_jobMgr.LifetimeCycleCount));

  }

  else if(req == "SuggestedCalWeightEntry_Rd")
  {

	  /* Wait till OEL layer boot up*/
    while(FALSE == OelBootupFlag);
    if(m_scsInputs.m_jhm_weigh.PidData.LastPloadWt <= 0) {
    	unitConversion(m_scsInputs.m_jhm_weigh.CalWt, jhmNVMDataRd.units, unitConverted);
    }
    else {
        unitConversion(m_scsInputs.m_jhm_weigh.PidData.LastPloadWt, jhmNVMDataRd.units, unitConverted);
    }
    resp.insertParam( new Jhm2SimpleParam( req, dsi, unitConverted ));
    
  }
  else if(req == "WeighRangeIndicate_Rd")
  {
    
     if((m_scsInputs.m_jhm_weigh.LiftCylExt.Val >= m_scsInputs.m_jhm_weigh.WeighRange.WeighRangeBottom) && ( m_scsInputs.m_jhm_weigh.LiftCylExt.Val <= (m_scsInputs.m_jhm_weigh.WeighRange.WeighRangeBottom + m_scsInputs.m_jhm_weigh.WeighRange.WeighRangeSize)))
     {
	resp.insertParam( new Jhm2SimpleParam( req, dsi,1));
     }
     else
     {
	resp.insertParam( new Jhm2SimpleParam( req, dsi,0));
     }
  }
 else if(req == "SimpleCalList_Rd" )                               //SimpleCalList response to UI if UI requests SimpleCalList_Rd and the data fetched from the LpsSaJobMgrTxChannel SCS object 
   {      
       resp.insertParam( new Jhm2SimpleParam( req, dsi,fetchSimpleCalList()));
   }
 
  else if( req == "ServiceMode_Rd")                                //Service mode enable status response to UI if the UI requests ServiceMode_Rd and respose data fetched from Global boolean variable  
   {                                                               //ServiceModeEnable_Status
     if(ServiceModeEnable_Status)
     {
      resp.insertParam( new Jhm2SimpleParam( "ServiceMode_Rd", "1" ) );
      
     }
     else
     {
       resp.insertParam( new Jhm2SimpleParam( "ServiceMode_Rd", "0" ) );
      }  
   }
    else if( req == "ServicePassword_Rd")                          //service password authundicate state response to UI if the UI requests ServicePassword_Rd and response data fetched from Global Variable 
   {                                                               //PwdAuthorized
     if (PwdAuthorized == 1)
        {
          resp.insertParam( new Jhm2SimpleParam( "ServicePassword_Rd", "1" ) ); 
         
        }
     else
        {
          resp.insertParam( new Jhm2SimpleParam( "ServicePassword_Rd", "0" ) );
        } 
   }
   else if( req == "ActiveEvent_Rd")                                //event state response to UI if UI requests ActiveEvent_Rd and response data fetched from the LpsSaWeighTxChannel scs object 
   {
      resp.insertParam( new Jhm2SimpleParam(req,dsi,m_scsInputs.m_jhm_weigh.EventState.Data));
      } 
   else if( req == "ActiveDiag_Rd")                                 //diagonostic state response to UI if UI requests ActiveDiag_Rd and response data fetched from the LpsSaWeighTxChannel scs object 
   {
      resp.insertParam( new Jhm2SimpleParam( req,dsi,m_scsInputs.m_jhm_weigh.DiagState.Data));
   }
   else if( req == "ActiveInfo_Rd")                                 //Info state response to UI if UI requests ActiveInfo_Rd and the response data fetched from the LpsSaWeighTxChannel scs object
   {
     resp.insertParam( new Jhm2SimpleParam( req,dsi,m_scsInputs.m_jhm_weigh.InfoState.Data));
   } 
   else if( req == "FaultIdentifier_Rd")                            //FaultIdentifier response to UI if UI requests the FaultIdentifier_Rd and response data fetched from the LpsSaWeighTxChannel scs object
   {
      resp.insertParam( new Jhm2SimpleParam( req,dsi,m_scsInputs.m_jhm_weigh.ShowExclamationPoint));
   }
   else if(req == "HornStoreState")
   {
      resp.insertParam( new Jhm2SimpleParam( req,dsi,m_scsInputs.m_jhm_jobMgr.ReadHornStoreEnable()));
   }

  return true;
}



/******************************************************************************
FUNCTION:                   fetchSimpleCalList
DESCRIPTION:                copy the data from LpsSaJobMgrTxChannel deque to aisSimplCaldeque and convert the parameters as JSON format.
PARAMETER DESCRIPTION:
RETURN VALUE:               character array 
*******************************************************************************/

std::string AisJhm2RequestProcessor::fetchSimpleCalList()
{

	int len  = 18;
	char *aisResponse = (char*)malloc(sizeof(char)*len*75);
	char *aisResponse_Cpy = aisResponse;
	float truckweightConv = 0.0;
	float zeroedTruckWtConv = 0.0;
	aisResponse += sprintf( aisResponse,"{\"CalEntries\":[");
	int LpsSaJobMgrQue_size = m_scsInputs.m_jhm_jobMgr.simpleCalData.size();
	if(!aisSimplCaldeque.empty())
	{
		aisSimplCaldeque.clear();
	}
	if (LpsSaJobMgrQue_size < 16) {                                          //this avoids copy the data from LpsSaJobMgrTxChannel deque, if the size of the LpsSaJobMgrTxChannel SimpleCaldeque size    	    	                                                                         //greater than 15
		for(int s = 0;s < LpsSaJobMgrQue_size;++s)                      //for loop to copy the data from LpsSaJobMgrTxChannel deque to aisSimplCaldeque and frame the JSON format.
		{
			aisSimpleCalStruct  aisSimpleCalstructtemp;
			aisSimpleCalstructtemp.timeStamp = m_scsInputs.m_jhm_jobMgr.simpleCalData.at(s).timeStamp;
			aisSimpleCalstructtemp.truckWt   = m_scsInputs.m_jhm_jobMgr.simpleCalData.at(s).truckWt;
			aisSimpleCalstructtemp.zeroedTruckWt = m_scsInputs.m_jhm_jobMgr.simpleCalData.at(s).zeroedTruckWt;
			aisSimplCaldeque.push_back(aisSimpleCalstructtemp); 
			unitConversion(aisSimpleCalstructtemp.truckWt, jhmNVMDataRd.units,truckweightConv );
			unitConversion(aisSimpleCalstructtemp.zeroedTruckWt, jhmNVMDataRd.units,zeroedTruckWtConv );
			aisResponse += sprintf (aisResponse,"{\"Timestamp\":\"%s\",\"Weight\":\"%f\",\"ZeroedTruckWeight\":\"%f\"},",(aisSimpleCalstructtemp.timeStamp).c_str(), truckweightConv,zeroedTruckWtConv );
		}
	}
	if(!aisSimplCaldeque.empty())                          
		aisResponse -= 1;
	
	aisResponse += sprintf(aisResponse,"]}");
	int len1 = strlen(aisResponse_Cpy);
	char aryresp[len1 +1];
	strcpy(aryresp,aisResponse_Cpy);
	free(aisResponse_Cpy);
	return aryresp;                                                  //JSON format contained array returned to send the JSON object to UI
}


/******************************************************************************
FUNCTION:                   PublishtoLpsSaUITxChannel
DESCRIPTION:                this function will publish the units,language, service password to LpsSaUIAppReqChannel at every 40ms  25Hz
PARAMETER DESCRIPTION:
RETURN VALUE:               bool
*******************************************************************************/

bool AisJhm2RequestProcessor::PublishtoUITxChannel()
{
	static unsigned char publishCounter = 25;	// publish every 1 sec

	LOG_INFO("\nm_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqFlag %d",m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqFlag);
	if (m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqFlag == 1)
    {
		if(units != m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqVal){
		    jhmNVMData.units = m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqVal;
		  	jhmNVMDataWriteFlag = TRUE;
		  	units = m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqVal;
		}
		  	m_scsOutputs.m_jhm_LpsSaUITxRes.PidTable.PidF25B_InfoUnitStat = (InfoUnitStat_t)m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqVal;
	        LOG_INFO("\n the value of the units read from the m_jhm_LpsSaUIAppReq app is %d", m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidF25B_InfoUnitStat.ReqVal );
	        LOG_INFO("\n the value of the units written in NVM is %d",jhmNVMDataRd.units);
    }
    else
    {
    	m_scsOutputs.m_jhm_LpsSaUITxRes.PidTable.PidF25B_InfoUnitStat = (InfoUnitStat_t)units;
    }

	 LOG_INFO("\nm_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqFlag  %d",m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqFlag );
     if(m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqFlag == 1)
    {
    	 if(languIndx != m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqVal){
	        jhmNVMData.languageIndx = m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqVal;
	        jhmNVMDataWriteFlag = TRUE;
	        languIndx = m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqVal;
    	 }
	        m_scsOutputs.m_jhm_LpsSaUITxRes.PidTable.PidD0022C_DispLangStat  = (DispLangStat_t)m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqVal;
	        LOG_INFO("\n the value of the language value read from the app is %d",m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD0022C_DispLangStat.ReqVal);
	        LOG_INFO("\n the value of the language read from the NVM is %d",jhmNVMDataRd.languageIndx);
    }
    else
    {
    	 m_scsOutputs.m_jhm_LpsSaUITxRes.PidTable.PidD0022C_DispLangStat = (DispLangStat_t)languIndx;
    }

     if(m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD00144_ServModEnCode.ReqFlag == 1)
    {
    	 if(servicepass != m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD00144_ServModEnCode.ReqVal){
    	    jhmNVMData.servicepass = m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD00144_ServModEnCode.ReqVal;
    	 	jhmNVMDataWriteFlag = TRUE;
    	 	servicepass =  m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD00144_ServModEnCode.ReqVal;
    	 }
    	 	m_scsOutputs.m_jhm_LpsSaUITxRes.PidTable.PidD00144_ServModEnCode = m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD00144_ServModEnCode.ReqVal;
	        LOG_INFO("\n the value of the service pass value read from the app is %d",m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD00144_ServModEnCode.ReqVal);

    }
    else
    {
    	 m_scsOutputs.m_jhm_LpsSaUITxRes.PidTable.PidD00144_ServModEnCode = servicepass;
    	 LOG_INFO("PidTable.PidD00144_ServModEnCode.ReqFlag is not enabled");
    }

   LOG_INFO("service password periodic(var,nvmvar): %d : %d \n", servicepass, jhmNVMData.servicepass);
   publishCounter--;
   if (publishCounter <=0)	// publish every 1sec
   {
 	m_scsOutputs.m_jhm_LpsSaUITxRes.setNewDataFlag();
 	m_scsOutputs.send();
 	publishCounter = 25;
   	LOG_INFO("\n the value of the service pass code is %d, reqflag %d",servicepass,m_scsInputs.m_jhm_LpsSaUIAppReq.PidTable.PidD00144_ServModEnCode.ReqFlag);
   }

   return false;
}






/******************************************************************************
FUNCTION:                   processRequest
DESCRIPTION:                Extract the Response String from HTTP response and call the processCmdRequest with argument of Response String
PARAMETER DESCRIPTION:
RETURN VALUE:               bool  
*******************************************************************************/

bool AisJhm2RequestProcessor::processRequest( const Jhm2ParamMsgRequest& req, Jhm2CmdResponseMsg& resp )
{

  const Jhm2ParamMsgRequest::ReqDataT& cmdsRequested = req.getReqData(m_COMMANDREQUETED_KEY);
  if ( cmdsRequested.empty() )
  {
    resp.insertParam( new Jhm2SimpleParam( "CommandStatus", "CannotExecute" ) );
    resp.insertParam( new Jhm2SimpleParam( "CommandFailDetails", "No Command Given" ) );
    return true;
  }

  processCmdRequest(*(cmdsRequested.begin()), resp );

  return true;
}

/******************************************************************************
FUNCTION:                   processCmdRequest
DESCRIPTION:                according to the UI response publish the data via SCS object or store in NVM  
PARAMETER DESCRIPTION:
RETURN VALUE:                     
*******************************************************************************/

void AisJhm2RequestProcessor::processCmdRequest( const std::string& cmd, Jhm2CmdResponseMsg& resp )
{

  namespace pt1 = boost::property_tree;
  m_scsOutputs.m_jhm_jobMgrReq.StoreReqst = 0;
  m_scsOutputs.m_jhm_WeighReq.ZeroReqst = 0;
  m_scsOutputs.m_jhm_jobMgrReq.MinusOneReqst = 0;
  m_scsOutputs.m_jhm_jobMgrReq.ClearReqst = 0;
  m_scsOutputs.m_jhm_jobMgrReq.StandByActReqst = 0;
  m_scsOutputs.m_jhm_jobMgrReq.StandByDeactReqst = 0;
  m_scsOutputs.m_jhm_jobMgrReq.TargetWeightReqst.ReqstFlag = 0;
  m_scsOutputs.m_jhm_jobMgrReq.ManualTipOffActReqst = 0;
  m_scsOutputs.m_jhm_jobMgrReq.ManualTipOffDeactReqst = 0;
  m_scsOutputs.m_jhm_jobMgrReq.TruckPileTipOffToggleReqst = 0;
  m_scsOutputs.m_jhm_WeighReq.WeighRangeRequest.WeighRangeReqstFlag = 0;
  m_scsOutputs.m_jhm_jobMgrReq.ReWeighReqst = 0;
  m_scsOutputs.m_jhm_jobMgrReq.TipOffTrigger.ReqstFlag = 0;
  m_scsOutputs.m_jhm_jobMgrReq.TipOffState.ReqstFlag = 0;
  m_scsOutputs.m_jhm_WeighReq.SetCalWtRequest.newCalWtFlag = 0;
  m_scsOutputs.m_jhm_MachineSN.m_machineSN.m_status = 1;
  

  std::vector< std::pair<std::string, float> > calib;
  std::vector<std::pair<std::string,std::string>> calibstr;
  std::string str(cmd);
  boost::property_tree::ptree pt;
  std::stringstream ss(str.c_str());
  boost::property_tree::read_json(ss, pt);

  float calibVal = 0;
  std::string convstr;
ConfigSection dataTypesCS;

  if(!pt.empty() && pt.data().empty())
  {
     BOOST_FOREACH(boost::property_tree::ptree::value_type &v, pt)
     {
        if(!v.first.empty())
        {

           std::string name = v.first;
           if((name == "MM_Selected_MSN_Wr") | (name == "SimpleCalAdjWeight_Wr") | (name ==   "SimpleCalTimestamp_Wr" )|(name == "SimpleCalZeroWeight_Wr" ))
           {
              calib = {{"",0.0}};
              convstr = v.second.data();
              LOG_INFO("name %s %s",name.c_str(),convstr.c_str());
              calibstr.push_back(std::make_pair(name, convstr));
           }
           else
           {
              calibstr={{"",""}};
              convstr = v.second.data();
              calibVal = atof(convstr.c_str());
              calib.push_back(std::make_pair(name, calibVal));
           }
        }
     }
  }

   
   if((calibstr[0].first == "SimpleCalAdjWeight_Wr" )|(calibstr[0].first == "SimpleCalTimestamp_Wr" )|(calibstr[0].first == "SimpleCalZeroWeight_Wr" ))
   {
     
		m_scsOutputs.m_jhm_payLoadReq.simplecal_data.timeStamp = calibstr[0].second;                              //simplecal timestamp publish through aisJhm2Txchannel
	 float unitConverted4;
	    	/* Wait till OEL layer boot up*/
	        while(FALSE == OelBootupFlag);
	        m_scsOutputs.m_jhm_payLoadReq.simplecal_data.zeroedTruckWt = atof((calibstr[1].second).c_str());
	    	unitConversiontoDefaultMetric(m_scsOutputs.m_jhm_payLoadReq.simplecal_data.zeroedTruckWt, jhmNVMDataRd.units, unitConverted4);
	    	m_scsOutputs.m_jhm_payLoadReq.simplecal_data.zeroedTruckWt  = unitConverted4; /* Value updated after conversion*/

	 //simplecal zeroed weight publish through aisJhm2Txchannel

	 float unitConverted5;
	    	/* Wait till OEL layer boot up*/
	        while(FALSE == OelBootupFlag);
	        m_scsOutputs.m_jhm_payLoadReq.simplecal_data.adjtruckweight = atof((calibstr[2].second).c_str());
	    	unitConversiontoDefaultMetric(m_scsOutputs.m_jhm_payLoadReq.simplecal_data.adjtruckweight, jhmNVMDataRd.units, unitConverted5);
	    	m_scsOutputs.m_jhm_payLoadReq.simplecal_data.adjtruckweight  = unitConverted5; /* Value updated after conversion*/


		         //simplecal adjweight publish through aisJhm2txchannel
		m_scsOutputs.m_jhm_payLoadReq.simplecal_data.newDataFlag = true;
		m_scsOutputs.m_jhm_payLoadReq.setNewDataFlag();
		m_scsOutputs.send();
		LOG_INFO("the value returned from the aistxchannel is %s", (m_scsInputs.m_jhm_payLoad.simplecal_data.timeStamp).c_str());
	    }

  if((calibstr[0].first == "MM_Selected_MSN_Wr"))
  {
	m_scsOutputs.m_jhm_MachineSN.m_machineSN.m_status = 0;
	m_scsOutputs.m_jhm_MachineSN.m_machineSN.m_value = calibstr[0].second;
	std::string newMachineMSN;
	newMachineMSN = m_scsOutputs.m_jhm_MachineSN.m_machineSN.m_value;
		if(machineMSN.compare(newMachineMSN) != 0)
	{
		m_scsOutputs.m_jhm_MachineSN.setNewDataFlag();
		m_scsOutputs.send();

		sleep(1);                       // sleep 1 second to let other apps get the new MSN.
		system("echo 1 > /opt/appdata/CPM/restart.txt");  // app_init.sh is looking for this file to restart the system
	}
  }
  else if ( calib[0].first == "ReWeighEnable" )
  {
       m_scsOutputs.m_jhm_jobMgrReq.ReWeighReqst = 1;
       m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
       m_scsOutputs.send();
       resp.insertParam( new Jhm2SimpleParam( "ReWeighEnable", "1" ) );
     
  }
  else if(calib[0].first == "StoreReqstEnable")
  {
        m_scsOutputs.m_jhm_jobMgrReq.StoreReqst = 1;
	m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
	m_scsOutputs.send();

  }
  else if(calib[0].first == "ZeroEnable" )
  {
	m_scsOutputs.m_jhm_WeighReq.ZeroReqst = 1;
	m_scsOutputs.m_jhm_WeighReq.setNewDataFlag();
	m_scsOutputs.send();

        LOG_ERROR("ZeroEnable Button Press Executed");
  }
  else if(calib[0].first == "MinusOneEnable" )
  {
	m_scsOutputs.m_jhm_jobMgrReq.MinusOneReqst = 1;
	m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
	m_scsOutputs.send();

	//resp.insertParam( new Jhm2SimpleParam( "MinusOneEnable", "1" ) );
        LOG_ERROR("MinusOneEnable Button Press Executed");         
  }
  else if(calib[0].first == "ClearEnable" )
  {
	m_scsOutputs.m_jhm_jobMgrReq.ClearReqst = 1;
	m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
	m_scsOutputs.send();

	//resp.insertParam( new Jhm2SimpleParam( "ClearReqst", "1" ) );
        LOG_ERROR("ClearEnable Button Press Executed");
	     
  }
  else if(calib[0].first == "StandByEnable" )
  {
	m_scsOutputs.m_jhm_jobMgrReq.StandByActReqst = 1;   
	m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
	m_scsOutputs.send();

  }
  else if(calib[0].first == "StandByDisable" )
  {
	m_scsOutputs.m_jhm_jobMgrReq.StandByDeactReqst = 1;
	m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
	m_scsOutputs.send();

  }
  else if(calib[0].first == "TargetWeightEntry")
  {
	m_scsOutputs.m_jhm_jobMgrReq.TargetWeightReqst.ReqstFlag = 1;
	m_scsOutputs.m_jhm_jobMgrReq.TargetWeightReqst.TargetWeightVal = calib[0].second;  
	/* Wait till OEL layer boot up*/
        while(FALSE == OelBootupFlag);

	float unitConverted2;

	unitConversiontoDefaultMetric(m_scsOutputs.m_jhm_jobMgrReq.TargetWeightReqst.TargetWeightVal, jhmNVMDataRd.units, unitConverted2);
	m_scsOutputs.m_jhm_jobMgrReq.TargetWeightReqst.TargetWeightVal = unitConverted2; /* Value updated after conversion*/
	m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
	m_scsOutputs.send();
    }
    else if(calib[0].first == "ManualTipOffActReqst" )
    {
	m_scsOutputs.m_jhm_jobMgrReq.ManualTipOffActReqst = 1;   
	m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
	m_scsOutputs.send();

    }else if(calib[0].first == "ManualTipOffDeactReqst")
    {
	m_scsOutputs.m_jhm_jobMgrReq.ManualTipOffDeactReqst = 1;   
	m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
	m_scsOutputs.send();
	
	LOG_ERROR("ManualTipOffDeactReqst Button Press Executed");
    }
    else if((calib[0].first == "TruckTipOffEnable") || (calib[0].first == "PileTipOffEnable"))
    {
	m_scsOutputs.m_jhm_jobMgrReq.TruckPileTipOffToggleReqst = 1;   
	m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
	m_scsOutputs.send();
	LOG_ERROR("TruckPileTipOffToggleReqst Button Press Executed");
    }
    else if(calib[0].first == "Units_Wr")
    {
   	 if(units != (unsigned int)calib[0].second)
              {
      	         jhmNVMData.units =  calib[0].second;
      	         jhmNVMDataWriteFlag = TRUE;
      	         units =  calib[0].second;
      	         LOG_INFO("the value of Units_Wr to store in NVM is %d",units);
              }
               else
               LOG_INFO("the value of Units_Wr failed duo to same value selected again old value of units in NVM is %d",units);
    }
    else if( calib[0].first == "Language_Wr" )
    {
    	if(languIndx != (unsigned int)calib[0].second)
    	           {
    	        	jhmNVMData.languageIndx = calib[0].second;
    	   	        jhmNVMDataWriteFlag = TRUE;
    	   	        languIndx =  calib[0].second;
    	   	        LOG_INFO("the value of Language_Wr %d",languIndx);
    	   	       }
    	        else
    	           LOG_INFO("the value of Language_Wr  failed due to same value selected again %d",languIndx);
    }
    else if(calib[0].first == "DisplayBrightness_Wr")
    {
    	if(jhmNVMDataRd.brightness != (unsigned int)calib[0].second)
            	{
            	    if((calib[0].second >= 0) && (calib[0].second <= 100))
            	    {
        	        jhmNVMData.brightness = calib[0].second;
        	        jhmNVMDataWriteFlag = TRUE;
                    LOG_INFO("the value of brightness_Wr writing into NVM done %f",jhmNVMDataRd.brightness);
            	    }
            	    else
                 	{
            	    	LOG_INFO("the value of brightness writing failed because of entered vlaue is not inbetween 0-100 in NVM old brightness value is %f",jhmNVMDataRd.brightness);
            	    }
            	}
            	else
            	{
            		LOG_INFO("the value of brightness writing failed because of same value entered and the old brightness value is %f",jhmNVMDataRd.brightness);
            	}

    }
    else if(calib[0].first == "SetWeigh_LowLimit_Wr")
    {
	m_scsOutputs.m_jhm_WeighReq.WeighRangeRequest.WeighRangeReqstFlag = 1;
	m_scsOutputs.m_jhm_WeighReq.WeighRangeRequest.WeighRangeBottom = calib[0].second;
	jhmWeighRangeBottom = calib[0].second;
        m_scsOutputs.m_jhm_WeighReq.WeighRangeRequest.WeighRangeSize = calib[1].second;
	jhmWeighRangeSize = calib[1].second;
	m_scsOutputs.m_jhm_WeighReq.setNewDataFlag();
	m_scsOutputs.send();
	LOG_INFO("SetWeigh_LowLimit_Wr: Bottom:%d  Size:%d",jhmWeighRangeBottom, jhmWeighRangeSize);
    } 
    else if(calib[0].first == "TipOffTriggerMode_Wr" )  
    {   
	m_scsOutputs.m_jhm_jobMgrReq.TipOffTrigger.ReqstFlag = 1;
	m_scsOutputs.m_jhm_jobMgrReq.TipOffTrigger.Type = LpsSaTipOffTriggerType_t(calib[0].second);
	m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
	m_scsOutputs.send();
	LOG_INFO("\n ###########  DATA SERVER TIP OFF TRIGGER MODE = %d ########### \n", m_scsOutputs.m_jhm_jobMgrReq.TipOffTrigger.Type);
    }
    else if(calib[0].first == "TipOffMode_Wr" )  
    {   
	m_scsOutputs.m_jhm_jobMgrReq.TipOffState.ReqstFlag = 1;
	m_scsOutputs.m_jhm_jobMgrReq.TipOffState.State = LpsSaJobMgrTipOffState_t(calib[0].second);
	m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
	m_scsOutputs.send();
	LOG_INFO("\n ###########  DATA SERVER TIP OFF STATE = %d ########### \n", m_scsOutputs.m_jhm_jobMgrReq.TipOffState.State);
    }
    else if(calib[0].first == "CalibrationWeightEntry_Wr")
    {
        float unitConverted3;
    	/* Wait till OEL layer boot up*/
        while(FALSE == OelBootupFlag);
        m_scsOutputs.m_jhm_WeighReq.SetCalWtRequest.newCalWt = calib[0].second;
    	unitConversiontoDefaultMetric(m_scsOutputs.m_jhm_WeighReq.SetCalWtRequest.newCalWt, jhmNVMDataRd.units, unitConverted3);
    	m_scsOutputs.m_jhm_WeighReq.SetCalWtRequest.newCalWt  = unitConverted3; /* Value updated after conversion*/
	m_scsOutputs.m_jhm_WeighReq.SetCalWtRequest.newCalWtFlag = 1;
	m_scsOutputs.m_jhm_WeighReq.setNewDataFlag();
	m_scsOutputs.send();
    }
    else if( calib[0].first == "ServiceMode_Wr")
    {

      if(calib[0].second)
      {
      ServiceModeEnable_Status = 1;

      }
      else
      {
      ServiceModeEnable_Status = 0;
      }
     }
   
    else if( calib[0].first == "ServicePassword_Wr")  
    {

        LOG_INFO("the value of the service password is %d",servicepass);
      		   if((unsigned int)atoi(convstr.c_str()) == servicepass )
		             {
		                  PwdAuthorized = 1;
                         LOG_INFO("the value of the service password verification is from webapp %d from service pass %d PwdAuthorized %d",atoi(convstr.c_str()),servicepass);
		              }
		             else
		             {
		                  PwdAuthorized = 0;
		                  LOG_INFO("the value of the service password verification is from webapp %d from service pass %d PwdAuthorized %d",atoi(convstr.c_str()),servicepass);
		             }
   }
    else if( calib[0].first == "HornStoreState")
    {
       if(calib[0].second)
       {
          m_scsOutputs.m_jhm_jobMgrReq.HornStoreStateReqst.ReqstFlag = true;
          m_scsOutputs.m_jhm_jobMgrReq.HornStoreStateReqst.Enable = true;
       }
       else
       {
          m_scsOutputs.m_jhm_jobMgrReq.HornStoreStateReqst.ReqstFlag = true;
          m_scsOutputs.m_jhm_jobMgrReq.HornStoreStateReqst.Enable = false;
       }
       m_scsOutputs.m_jhm_jobMgrReq.setNewDataFlag();
       m_scsOutputs.send();
    }
    else
    {
        resp.insertParam( new Jhm2SimpleParam( "CommandStatus", "CannotExecute" ) );
        resp.insertParam( new Jhm2SimpleParam( "CommandFailDetails", "Unknown Command" ) );
    }

}
