///////////////////////////////////////////////////////////////////////////////
/// @file      AisJhm2ScsInputs.h
/// @author    J Struble
/// @date      3/22/2013
/// @brief     Structure containing all data coming in from SCS that needs
///            to displayed in jhm2
///
/// @attention COPYRIGHT (C) 2012 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////
#ifndef AISJHM2SCSINPUTS_H_
#define AISJHM2SCSINPUTS_H_

#include <scsIOContainer/SCSInputs.h>
#include <scsIOContainer/SCSInData.h>
#include <ais/config/ConfigSection.h>

//Interfaces we want to receive and store
#include <interfaces/CPMDemo/CPMDemo.h>
#include <interfaces/LpsSaJobMgrTxChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighTxChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrRespChannel/InterfaceTypes.h>
#include <interfaces/AisJhm2TxChannel/InterfaceTypes.h>
#include <interfaces/LpsSaUIAppReqChannel/InterfaceTypes.h>

class AisJhm2ScsInputs : public SCSInputs
{

 public:
  //SCSInData<CPMDemo>                  m_cpm_demo;
  SCSInData<LpsSaJobMgrTxChannel>     m_jhm_jobMgr;
  SCSInData<LpsSaWeighTxChannel>      m_jhm_weigh;
  SCSInData<AisJhm2TxChannel>         m_jhm_payLoad;
  SCSInData<LpsSaUIAppReqChannel>    m_jhm_LpsSaUIAppReq;
  //SCSInData<LpsSaJobMgrRespChannel>   m_jhm_jobMgrResp;

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Run "update" on all of the scs channels in the structure
  ///
  /// @return true if any channel has new data, false otherwise
  ///////////////////////////////////////////////////////////////////////////////
  bool update()
  {
    bool retVal = false;

   // if ( m_cpm_demo.update() ) retVal = true;
    if ( m_jhm_jobMgr.update() ) retVal = true;
    if ( m_jhm_weigh.update() ) retVal = true;
    if ( m_jhm_LpsSaUIAppReq.update() ) retVal = true;
    if ( m_jhm_payLoad.update() ) retVal = true;
	printf(" read update retVal: %d \n",retVal);
    //if ( m_jhm_jobMgrResp.update() ) retVal = true;
    return retVal;
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Run "initReadInterface" on all of the scs channels in the structure
  ///
  /// @return true if all interfaces were successfully configured, false if any failed
  ///////////////////////////////////////////////////////////////////////////////
  bool initReadInterface( ConfigSection& cs )
  {
    bool retVal = true;

    //if ( !m_cpm_demo.initReadInterface("CPMDemoInput", cs) ) retVal = false;
    if ( !m_jhm_jobMgr.initReadInterface("LpsSaJobMgrTxChannelInput", cs) ) retVal = false;
    if ( !m_jhm_weigh.initReadInterface("LpsSaWeighTxChannelInput", cs) ) retVal = false;
    if ( !m_jhm_LpsSaUIAppReq.initReadInterface("LpsSaUIAppReqChannelInput",cs)) retVal = false;
	printf(" LpsSaWeighTxChannelInput retVal: %d \n",retVal);
    if ( !m_jhm_payLoad.initReadInterface("AisJhm2TxChannelInput", cs) ) retVal = false;
	//printf(" ReadInterface retVal: %d \n",retVal);
    //if ( !m_jhm_jobMgrResp.initReadInterface("LpsSaJobMgrRespChannelInput", cs) ) retVal = false;
    
    return retVal;
  }

};

#endif /*AISJHM2SCSINPUTS_H_*/
