///////////////////////////////////////////////////////////////////////////////
/// @file      AisJhm2RequestProcessor.h
/// @author    strubjc
/// @date      Aug 15, 2014
/// @brief     
///
///
/// @attention COPYRIGHT (C) 2012 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////

#ifndef AISJHM2REQUESTPROCESSOR_H_
#define AISJHM2REQUESTPROCESSOR_H_


//Config Types
#include "ais/config/ConfigParser.h"
#include "ais/config/TaskParser.h"
#include "ais/config/ConfigSection.h"
#include <jhm2/Jhm2RequestProcessor/Jhm2RequestProcessor.h>
#include <jhm2/Jhm2Param/Jhm2ParamMsgRequest.h>
#include <jhm2/Jhm2Param/Jhm2ParamMsg.h>
#include <jhm2/Jhm2Param/Jhm2ImageMsg.h>
#include <jhm2/Jhm2Param/Jhm2CmdResponseMsg.h>
#include <vector>
#include <string>
#include "AisJhm2ScsOutputs.h"
#include "AisJhm2ScsInputs.h"
//#define DEBUG

class AisJhm2RequestProcessor: public Jhm2RequestProcessor
{
  public:
    AisJhm2RequestProcessor();
    
    virtual ~AisJhm2RequestProcessor();

    virtual bool configure( TaskParser& tp);
    virtual bool update( );
    virtual void cleanup( );
    virtual bool PublishtoUITxChannel();

    virtual Jhm2Msg* getResponse( const Jhm2ParamMsgRequest& req );
    typedef struct{
                 string	timeStamp;  	 		//tm type contains sec,min,hrs,mm,dd,yy
	         float truckWt;
                 float zeroedTruckWt;
	         }aisSimpleCalStruct;
     std::deque<aisSimpleCalStruct> aisSimplCaldeque;
    protected:
    AisJhm2ScsInputs  m_scsInputs;
    AisJhm2ScsOutputs m_scsOutputs;
  
  private:
    bool processRequest( const Jhm2ParamMsgRequest& req, Jhm2ParamMsg& resp );
    bool processRequest( const Jhm2ParamMsgRequest& req, Jhm2ImageMsg& resp );
    void processCmdRequest( const std::string& cmd,Jhm2CmdResponseMsg& resp );
    bool processRequest( const Jhm2ParamMsgRequest& req, Jhm2CmdResponseMsg& resp );

    bool processRequestFromGPSPosition1( const std::string& req, Jhm2ParamMsg& resp );
    void unitConversion(float valReadfrmCPM,int unitStoredInNVM , float &unitConverted);
    void unitConversiontoDefaultMetric(float valReadfrmWebApp,int unit2StoredInNVM , float &unitConverted2);
    std::string fetchMchnMdlDataFrmFile();
    std::string fetchSimpleCalList();
    void fetchMSNFromrb();
    //void SimpleCalAppList();

    static const std::string m_PARAMSREQUETED_KEY;
    static const std::string m_IMAGEREQUETED_KEY;
    static const std::string m_COMMANDREQUETED_KEY;
    static const std::string m_TESTTYPE_KEY;
    static const std::string m_COMMANDID_KEY;
    
};

#endif /* AISJHM2REQUESTPROCESSOR_H_ */
