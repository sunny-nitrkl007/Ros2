#ifndef MACHINEMODELLIST_H_
#define MACHINEMODELLIST_H_

string MM_Selected_Make_Rd = "",MM_Selected_Machine_Rd = "",MM_Selected_Linkage_Rd="", machineMSN="";

unsigned int units = 0;
unsigned int languIndx = 0;
unsigned int servicepass = 1925;
unsigned int displayBrightness=50;

#endif /* MACHINEMODELLIST_H_ */
