/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: AcdCalMgrInf.h
DESCRIPTION:
*******************************************************************************/
#ifndef ACDCALMGRINF_H_
#define ACDCALMGRINF_H_
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <CalInfConnect.h>

#include <cat_std_types.h>
#include <scl_j1939_struct.h>
#include <scl_qr_j1939.h>

#include <oel_pack.h>
#include <oel_assert.h>
#include <std_t.h>
#include <scl_j1939.h>
#include <scl_pgb_j1939.h>
#include <oel_rtos.h>
#include<cdl2_proto.h>
#include <scl_util.h>
#include <sys/time.h>

#if defined (__cplusplus)
extern "C"
{
#endif
#ifndef CAL_MGR_H_
#include  <cal_mgr.h>
#endif
#ifndef CDL2_MOD_PROTO_H_
#include  <cdl2_mod_proto.h>
#endif

#include <oel_rtos_posix.h>
#include <oel_oop.h>
#include <clock_struct.h>
#ifndef boolean
#include <cat_std_types.h>
#endif
#include <cdl2_struct.h>
#include <cdl_mod_struct.h>
#include <scl_j1939_struct.h>
#include <cdl_critics_defs.h>
#include <cdl2_defs.h>
#include <oel_rtos.h>
#include <cdl2_mod_defs.h>

#if defined (__cplusplus)
}
#endif

extern CAL_MGR_Work_t cal_mgr_workspace;
extern  const CAL_MGR_Cnfg_t     cal_mgr_cnfg;
extern scl_j1939_link_t Ph_Link_app;

/*******************************************************************************
***
*** File scope symbols defined for this file
*** -- Symbols --
***
*******************************************************************************/
extern CAL_MGR_MR_E cal_mgr_callback(CAL_MGR_MC_E cmd,
    	                                   CAL_MGR_Work_t   *cmw,
    	                                   CAL_MGR_Cnfg_t   *cmc,
    	                                   CAL_MGR_Cal_t    *cal);


extern void init_calibration();
extern void enable_calibration();
extern void acd_cal_mgr_update();
extern void cal_cdl_pid_reg();
extern void init_cal_can();
//extern void update_calibration_device_id(unsigned_8 *device_id);

extern int_least32_t app_qualified_data_clbk(void *context);
//extern void app_scl_pgb_j1939_server_init(scl_j1939_link_t link);
extern void app_scl_qr_j1939_server_init(scl_j1939_link_t link);
extern void app_scl_pgb_cdl_server_init(void);
extern void app_scl_qr_j1939_server_add_entry(void);
extern void app_scl_qr_j1939_server_remove_entry(void);
/* tx handler */
//extern int_16 app_cal_scl_pgb_cdl_fr_tx_hdlr(void *tx_pie, unsigned_8 *data);
/*******************************************************************************
***
*** Constants defined for this file
*** -- #Define's --
***
*******************************************************************************/
/* Calibration ID's for SA */

#define SA_EMPTY_BUCKET_CAL_ID   (0x0256)
#define SA_FULL_BUCKET_CAL_ID  (0x0257)
#define SA_LIFT_LINKAGE_CAL_ID (0x00D0)
#define SA_TILT_LINKAGE_CAL_ID    (0x00D1)

#define SA_EMPTY_BUCKET_ENTRY           \
{                                         \
	SA_EMPTY_BUCKET_CAL_ID,           \
	cal_mgr_callback,                       \
  &cal_sa_work,                      \
  &cal_sa_cnfg                       \
}

#define SA_FULL_BUCKET_ENTRY          \
{                                         \
	SA_FULL_BUCKET_CAL_ID,          \
	cal_mgr_callback,                       \
  &cal_sa_work,                      \
  &cal_sa_cnfg                       \
}

#define SA_LIFT_LINKAGE_ENTRY \
{                                         \
	SA_LIFT_LINKAGE_CAL_ID,         \
	cal_mgr_callback,                       \
  &cal_sa_work,                      \
  &cal_sa_cnfg                       \
}

#define SA_TILT_LINKAGE_ENTRY            \
{                                         \
	SA_TILT_LINKAGE_CAL_ID,            \
	cal_mgr_callback,                       \
  &cal_sa_work,                      \
  &cal_sa_cnfg                       \
}


#define EH_ARRAY_ENTRIES(ARRAY_VARIABLE_NAME)                                \
                                         (  sizeof (ARRAY_VARIABLE_NAME) /   \
                                            sizeof (ARRAY_VARIABLE_NAME[0])  \
                                         )

#define CAL_MGR_APP_CAL_LIST  SA_EMPTY_BUCKET_ENTRY, \
								SA_FULL_BUCKET_ENTRY, \
								SA_LIFT_LINKAGE_ENTRY, \
								SA_TILT_LINKAGE_ENTRY


#define CAL_MGR_CALS    ( EH_ARRAY_ENTRIES( cal_mgr_cals ) )

#define CAL_MGR_SRVS   ( EH_ARRAY_ENTRIES( cal_mgr_srvs ) )

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/

#define CCM_CALS        4
#define CAL_MGR_PRD_MS		250
/*Calibration Module Loop Time In Nano-Seconds*/
#define    CAL_NS_LPTIM        10000000

/*Calibration Module Loop Time In Seconds*/
#define    CAL_LPTIM          (CAL_NS_LPTIM/1000000000.0)
#define CDL_NUM_RXB 42
#define CDL_NUM_TXB 25
#define CDL_NUM_RX_PIT 1
#define CDL_NUM_TX_PIT 1
#define CDL_NUM_QRPSB 1
#define CDL2_NUM_TX_PIT 20
#define CDL2_SUBLIST_D0_NUM_TX_PIT 10
#define CDL2_SUBLIST_D1_NUM_TX_PIT 10
#define CDL2_SUBLIST_D2_NUM_TX_PIT 1
#define CDL2_SUBLIST_D3_NUM_TX_PIT 1
#define CDL2_SUBLIST_F916_NUM_TX_PIT 1

/* This defines the size of  the connection receive pit */
#define CDL2_NUM_CON_RX_PIT 50
/* This defines the size of the receive pit.  Set this to the number of
parameters that this module will be receiving. */
#define CDL2_NUM_RX_PIT 20
/* This defines the size of the receive data pit.  Set this to the number of
parameters that will be requested from other modules. */
#define CDL2_NUM_RX_DATA_PIT 30
/* This defines the number of ECMs from which the application is requesting data. */
#define CDL2_NUM_RX_DATA_PIT_MID_TABLE 3

/* The following WR definitions determine the sizes of the individual write tables. */
#define CDL2_NUM_WR_PIT 10
#define CDL2_SUBLIST_D0_NUM_WR_PIT 1
#define CDL2_SUBLIST_D1_NUM_WR_PIT 1
#define CDL2_SUBLIST_D2_NUM_WR_PIT 1
#define CDL2_SUBLIST_D3_NUM_WR_PIT 1
#define CDL2_SUBLIST_F916_NUM_WR_PIT 1

/* Define the number of queued receive parameter storage blocks.  These are
   used by the general queued receive parameter handler.
   */
#define CDL2_NUM_QRPSB 25
/* Define the maximum number of supported standard broadcast message requests
to this ecm. */
#define CDL2_SPB_MSG_MAX 8
/* Define the maximum number of supported group broadcast message requests
to this ecm. */
#define CDL2_PGB_MSG_MAX 8
#define CDL2_TRANSMIT_BUF_SIZE   10
#define CDL2_CBS_MAX_NUM_ECM            3
#define CDL2_PGB_MAX_NUM_REFTAG         10
#define CDL2_PGB_MAX_NUM_REQ_PARM       10
#define CDL2_ADT_MAX_NUM_REQ_PARM       10
#define CDL2_ADT_MAX_NUM_REQUESTOR      3

#define CDL2_ADT_MAX_NUM_DATA_STATUS    10

#define CDL2_ADT_MAX_NUM_REF_ENTRIES     20

#define CDL2_CBS_MAX_READ_POLL_ENTRIES   1

#define COM_INF_INPUT_QUE_SIZE            5

/* SA calibration configuration dummy structure */
typedef struct {

 char a;

} CAL_SACnfg_t;

/* SA calibration workspace structure */
typedef struct {

  void *ptr;

} CAL_SAWork_t;
#endif /* ACDCALMGRINF_H_ */

