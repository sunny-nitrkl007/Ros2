/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: acd_cal_connector.cpp
DESCRIPTION:This file call ACD c++ API from cal C functions.
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/


#include <AcdCalScsInf.h>
///////////////////////////////////////////////////////////////////////////////
// -- #Define, Struct's, Typedef's, Enum's --

extern unsigned_16				Cal_id;		/* Calibration cmd data */
extern CAL_MGR_MC_E Calcmd;

extern CAL_MGR_MR_E CalResp;
extern unsigned_8	stepNo;
extern unsigned_16 CalError;
extern unsigned_16 warning;
extern unsigned_8 EnableQualRead;

extern boolean LpsSaCalScsCmdStatFlg;
extern boolean LpsSaCalScsRespStatFlg;

///////////////////////////////////////////////////////////////////////////////
// -- Start of code for this file --
///////////////////////////////////////////////////////////////////////////////
using namespace task;

/* Null, because instance will be initialized on demand. */

AcdCalScsInf *AcdCalScsInf::AcdCalScsInf_instance=NULL;

///////////////////////////////////////////////////////////////////////////////
/// @brief AcdCalScsInf Constructor
///////////////////////////////////////////////////////////////////////////////
AcdCalScsInf::AcdCalScsInf():
 // LpsSaWeighScsTxIn( NULL),
  LpsCalCmdScsReqstOut( NULL ),
  LpsCalCmdScsRespIn( NULL )
{

}

AcdCalScsInf* AcdCalScsInf:: AcdCalGetInstance()
	{
    if (AcdCalScsInf_instance == NULL)
    {
    	AcdCalScsInf_instance = new AcdCalScsInf;
    }
    return AcdCalScsInf_instance;
}


///////////////////////////////////////////////////////////////////////////////
/// @brief AcdCalScsInf Destructor
///////////////////////////////////////////////////////////////////////////////
AcdCalScsInf::~AcdCalScsInf( )
{
}

/******************************************************************************
FUNCTION AcdCalScsInitInterface( )
DESCRIPTION:It will  initialize the scs channels for calibration data send/receive
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void AcdCalScsInf::AcdCalScsInitInterface(){
	   LpsCalCmdScsReqstOut  = dynamic_cast<LpsCalCmdReqstChannelOutput*>( InterfaceDb::fetch("LpsCalCmdReqstChannelOutput") );

	   if ( LpsCalCmdScsReqstOut )
	   	{
	   		printf( "LpsSaWeighScsCmdOut  configured as a producer/sender." );
	   	}
	   	else
	   	{
	   		printf( "\n LpsSaWeighScsCmdOut Interface  not configured." );
	   	}
	   LpsCalCmdScsRespIn  = dynamic_cast<LpsCalCmdRespChannelInput*>( InterfaceDb::fetch("LpsCalCmdRespChannelInput") );

	   if ( LpsCalCmdScsRespIn )
	   	{
	   		printf( "LpsSaWeighScsRespIn  configured as a producer/sender." );

	   	}
	   	else
	   	{
	   		printf( "\n LpsSaWeighScsRespIn Interface  not configured." );
	   	}
}


/******************************************************************************
FUNCTION AcdCalScsCmd
DESCRIPTION: It will send the cmd to weighing App through SCS channel by polling method
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void AcdCalScsInf::AcdCalScsCmd()
{
    bool scsCmdRet;
    LpsCalCmdReqstChannel calCmdReqCh;

    {
    	LOG_INFO("AcdCalScsCmd\n");
    	/*Set Default values*/
    	calCmdReqCh.CalibrationRequest.CalibrationReqstFlag=true;
    	calCmdReqCh.CalibrationRequest.Calcmd=Calcmd;
    	calCmdReqCh.CalibrationRequest.Cal_id=Cal_id;
    	memcpy(calCmdReqCh.CalibrationRequest.CalIterm, cal_iterm, sizeof(calCmdReqCh.CalibrationRequest.CalIterm));
		scsCmdRet = LpsCalCmdScsReqstOut->publish( calCmdReqCh );

		LOG_INFO("\n Line no = %d,'AcdCalScsCmd' function return code = %d iterm size %d\n",__LINE__,scsCmdRet, sizeof(calCmdReqCh.CalibrationRequest.CalIterm));

		LOG_INFO("----CAL_MGR_KEY_CONT %d LineNo %d File %s\n", CAL_MGR_KEY_CONT, __LINE__, __FILE__);

     if(true == scsCmdRet)
     {
    	 LOG_INFO("AcdCalScsCmd-success\n");
    	 LpsSaCalScsCmdStatFlg = FALSE;
    	 LpsSaCalScsRespStatFlg = TRUE;
     }
    else
    {
        /* Do not send the command as a previous command is already sent */
    }

    }
   return;
}

/******************************************************************************
FUNCTION  AcdCalScsCmdResp
DESCRIPTION: It will get the resp from weighing App through SCS channel and send the same to
in info table and  ET.
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
unsigned int AcdCalScsInf::AcdCalScsCmdResp(void)
{
	LOG_INFO("AcdCalScsCmdResp-1\n");
	LpsCalCmdRespChannel calCmdRespCh;
	{
		 /* Retreive SCS channel data */
			while(LpsCalCmdScsRespIn->get( calCmdRespCh ))
			{
				/*set the response flag*/
				LpsSaCalScsCmdStatFlg = FALSE;
				//LpsSaCalScsRespStatFlg=FALSE;
				if (calCmdRespCh.CalibrationResp.RespCode == LPS_SA_CAL_SUCCESS)
				{
					LOG_INFO("\n  Line no = %d,Received response for %d command \n ",__LINE__,LpsSaCalScsRespStatFlg);
					m_acdInfoTbl.CalError = 0;
					CalError = 0;
					/*Acknowlegement received for the issued command */
					m_acdInfoTbl.CalResp		=	calCmdRespCh.CalibrationResp.CalResp;
					m_acdInfoTbl.CalError		=	calCmdRespCh.CalibrationResp.error;
					m_acdInfoTbl.warning		=	calCmdRespCh.CalibrationResp.warning;
					m_acdInfoTbl.stepNo			=	calCmdRespCh.CalibrationResp.stepNo;
					m_acdInfoTbl.EnableQualRead	=	calCmdRespCh.CalibrationResp.EnableQualRead;

					CalResp   		= m_acdInfoTbl.CalResp;
					CalError  		= m_acdInfoTbl.CalError;
					warning   		= m_acdInfoTbl.warning;
					stepNo 	  		= m_acdInfoTbl.stepNo;
					EnableQualRead  = m_acdInfoTbl.EnableQualRead;

					LOG_INFO("AcdCalScsCmdResp-2-if-success %d \n",CalResp);
					if( CalResp ==CAL_MGR_MR_SAMPLE_PT_COLLECTED)
					{
						LOG_INFO("AcdCalScsCmdResp-2-if-success CAL_MGR_MR_SAMPLE_PT_COLLECTED %d \n",CalResp);
					}
					LpsSaCalScsRespStatFlg = FALSE;
					return TRUE;
				}
				else
				{
					LpsSaCalScsRespStatFlg = FALSE;
					LOG_ERROR("AcdCalScsCmdResp-2-else-fail\n");
				}
			}

			return FALSE;
	 }

}

