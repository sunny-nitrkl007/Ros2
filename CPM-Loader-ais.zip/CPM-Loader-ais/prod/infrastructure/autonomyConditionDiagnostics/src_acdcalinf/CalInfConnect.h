/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: CalInfConnect..h
DESCRIPTION:
*******************************************************************************/
#ifndef CALINFCONNECT_H
#define CALINFCONNECT_H

#ifdef __cplusplus
extern "C" {
#endif

	  /*send  calibration request to weighing app*/
void AcdCalScsCmd();

	  /*Read resp from weighing app*/
unsigned int AcdCalScsCmdResp();

#ifdef __cplusplus
}
#endif


#endif //CALINFCONNECT_H
