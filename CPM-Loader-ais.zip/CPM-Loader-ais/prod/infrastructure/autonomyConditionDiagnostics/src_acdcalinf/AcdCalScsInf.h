///////////////////////////////////////////////////////////////////////////////
// @attention COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
//
// @file    AcdCalScsInf.h
//
// @brief   This is the definition include file for the module.
///////////////////////////////////////////////////////////////////////////////
#ifndef ACDCALSCSINF_H_
#define ACDCALSCSINF_H_

///////////////////////////////////////////////////////////////////////////////
// -- #Include's --
///////////////////////////////////////////////////////////////////////////////
#include <ais/task/Task.h>
#include <interfaces/LpsSaWeighTxChannel/InterfaceTypes.h>
#include <interfaces/LpsCalCmdRespChannel/InterfaceTypes.h>
#include <interfaces/LpsCalCmdReqstChannel/InterfaceTypes.h>

///////////////////////////////////////////////////////////////////////////////
// -- #Define, Struct's, Typedef's, Enum's --
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// -- Class Definition
///////////////////////////////////////////////////////////////////////////////
class AcdCalScsInf:public LpsSaWeighTxChannelStorage
{

   public:
	  AcdCalScsInf();
	  virtual ~AcdCalScsInf( );

		 //calibration
	  void AcdCalScsCmd();
	  unsigned int AcdCalScsCmdResp(void);
	  void AcdCalScsInitInterface();
	  static AcdCalScsInf* AcdCalGetInstance();

   protected:

   private:
	  /* Here will be the instance stored. */
		  static AcdCalScsInf* AcdCalScsInf_instance;
      //Configuration
  	typedef struct
  	    {
  	    LpsSaWeighCalParam_t LpsSaCalParam;/*calibration tx parameters*/

  	    /*cal req data*/
    	CAL_MGR_MC_E Calcmd;
  	  	unsigned_16	 Cal_id;		/* Calibration / Service Mode ID */
  	  	/*CAL resp data*/
  	  	CAL_MGR_MR_E CalResp;
  	  	unsigned_8	stepNo;
  	  	unsigned_16 CalError;
  	  	unsigned_16 warning;
  	    unsigned_8	EnableQualRead;
  	    }ACDInfoTbl_t;

      LpsCalCmdRespChannelInput    *LpsCalCmdScsRespIn;/*getRes from weighing App*/
      LpsCalCmdReqstChannelOutput  *LpsCalCmdScsReqstOut;/*setCmd to weighing App*/
      ACDInfoTbl_t m_acdInfoTbl;
};

#endif //ACDCALSCSINF_H_
