/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: AcdCalInf.c
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  ACDCALMGRINF_H_
#include <AcdCalMgrInf.h>
#endif

/* calibration work space data starts here*/
CAL_MGR_Work_t cal_mgr_workspace;

/* Workspace and dummy configuration for cal mechanism, used by all
   calibrations */
CAL_SAWork_t cal_sa_work;

const CAL_SACnfg_t cal_sa_cnfg =
{
    0
};
typedef struct {

  void *ptr;

} SrvStallTestWork_t;
typedef struct
{
		 void *ptr;
}SrvStallTestCnfg_t;

typedef struct
{
	CAL_MGR_MC_E Cmd;
	boolean RespRcvd;
}AcdCalMgrLastCmdInfo;

//scs values
unsigned_16				Cal_id;		/* Calibration ID */
CAL_MGR_MC_E Calcmd;

/*CAL resp data*/
CAL_MGR_MR_E CalResp;
unsigned_8	stepNo;
unsigned_16 CalError;
unsigned_16 warning;
unsigned_8	EnableQualRead;

boolean LpsSaCalScsCmdStatFlg=FALSE;
boolean LpsSaCalScsRespStatFlg=FALSE;
boolean enable_calupdate_flag=FALSE;

AcdCalMgrLastCmdInfo PrevCalReqCmdInfo;
unsigned_8 QREnabled = FALSE;

/*****************************************************************************/
/*****     Application Defined Calibration Module Global Definitions     *****/

/*Calibration Information Storage
//     This variable is space for the calibration routines
//     to hold the needed information for each calibration.
*/
SrvStallTestWork_t        srv_stall_test_workspace;
SrvStallTestCnfg_t        srv_stall_test_configuraton;

#define SRV_TEST_STALL_DIAG_TEST_ENTRY              \
{                                                   \
    0xaa,                          \
    cal_mgr_callback,                      \
    &srv_stall_test_workspace,            \
    &srv_stall_test_configuraton          \
}

static CAL_MGR_Cal_t      cal_mgr_cals[] = {
    CAL_MGR_APP_CAL_LIST,
};


static cal_step_tbl_entry_t cal_registration_space[ CCM_CALS + CAL_MGR_CALS + 1 ];


/*Calibration interface configuration. */
const cal_interface_init_t ccm_interface = {
    ((unsigned_32)(CAL_LPTIM/0.0001)),  /* application periodic task period,  100ms */
    cal_registration_space,
    EH_ARRAY_ENTRIES(cal_registration_space),
    0,
    0
};

//static const CAL_MGR_Cnfg_t     cal_mgr_cnfg = {
	const CAL_MGR_Cnfg_t     cal_mgr_cnfg = {
    CAL_MGR_CALS,   /* Number of cals using CAL_MGR */
    cal_mgr_cals,   /* pointer to cal entries using CAL_MGR */

    0,   /* Number of app srvmodes using CAL_MGR */
    0,   /* pointer to srvmode entries using CAL_MGR */
   (cal_interface_init_t*)&ccm_interface  /* pointer to Core's CCM interface configuration */

};

struct timeval t3;
///////////////////////////////////////////////////////////////////////////////

/******************************************************************************
FUNCTION init_calibration
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void init_calibration()
{
	  cal_mgr_j1939_init(&cal_mgr_workspace, &cal_mgr_cnfg);
}
/******************************************************************************
FUNCTION enable_calibration
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void enable_calibration()
{
	unsigned_8 ret;
	ret=cal_mgr_enable_cal(SA_EMPTY_BUCKET_CAL_ID);
	printf("LpsSaCalInit -1  %d \n",ret);
	ret=cal_mgr_enable_cal(SA_FULL_BUCKET_CAL_ID);
	printf("LpsSaCalInit -2  %d  \n",ret);
	ret=cal_mgr_enable_cal(SA_LIFT_LINKAGE_CAL_ID);
	printf("LpsSaCalInit -3  %d  \n",ret);
	ret=cal_mgr_enable_cal(SA_TILT_LINKAGE_CAL_ID);
	printf("LpsSaCalInit -4  %d \n",ret);

	PrevCalReqCmdInfo.RespRcvd = TRUE;
	PrevCalReqCmdInfo.Cmd = 0xFFFFFFFF;
}

/******************************************************************************
FUNCTION cal_mgr_update
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void acd_cal_mgr_update()
{
	if(PrevCalReqCmdInfo.RespRcvd == TRUE)
	{
		cal_mgr_main(&cal_mgr_workspace, &cal_mgr_cnfg);
	}
}

/******************************************************************************
FUNCTION LpsSaEmptyBucketWeightCalibration
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
CAL_MGR_MR_E cal_mgr_callback(CAL_MGR_MC_E cmd,
                                   CAL_MGR_Work_t   *cmw,
                                   CAL_MGR_Cnfg_t   *cmc,
                                   CAL_MGR_Cal_t    *cal)
{
	struct timeval t1, t2;
	double elapsedTime1, elapsedTime2;
	boolean tempRcvd = FALSE;
	
	gettimeofday(&t1, NULL);

	LpsSaCalScsCmdStatFlg = TRUE;
	enable_calupdate_flag = FALSE;

	Calcmd=cmd;
	Cal_id=cal->id;

	(void)cal; /* touch variables to avoid compiler warnings */
	(void)cmc; /* touch variables to avoid compiler warnings */

	 /*send  calibration request to weighing app*/
	 //TODO: check function returns for successful scs msg sent, AcdCalScsCmd, AcdCalScsCmdResp.
	//Handle spl case Abort, exit etc.
	 AcdCalScsCmd();
	 PrevCalReqCmdInfo.Cmd = cmd;
	 PrevCalReqCmdInfo.RespRcvd = FALSE;


	 int counter = 0;
	 while(tempRcvd == FALSE && counter < 50)
	 {
		 tempRcvd = AcdCalScsCmdResp();
		 /*Read resp from weighing app*/
		 usleep(5000);	// 5 micro-sec
	 }

	 if(cmd != PrevCalReqCmdInfo.Cmd)
	 {
	 	 printf("cmd didn't match. something went wrong. %d\n.", cmd);
	 	 //We should probably send current command again if responded command and requested command didn't match.
	 	 //At the same time we don't want to stuck in while loop, time to think...sg.
	 }

	 if(FALSE == QREnabled && TRUE == EnableQualRead)
	 {
		 app_scl_qr_j1939_server_add_entry();
		 QREnabled = TRUE;
	 }
	 else if(TRUE == QREnabled && FALSE == EnableQualRead)
	 {
		 app_scl_qr_j1939_server_remove_entry();
		 QREnabled = FALSE;
	 }

	 if(CalError != 0)
	 {
		 cal_add_error(CalError);
	 }

	if(stepNo != 0xFF)
    	{
        	CAL_MGR_STEPNUMBER(cmw)  = stepNo;
    	}

	enable_calupdate_flag = TRUE;

	gettimeofday(&t2, NULL);

	elapsedTime1 = (t2.tv_sec - t1.tv_sec) * 1000.0;   // sec to ms
	elapsedTime1 += (t2.tv_usec - t1.tv_usec) / 1000.0;   // usec to ms
	elapsedTime2 = (t1.tv_sec - t3.tv_sec) * 1000.0;   // sec to ms
	elapsedTime2 += (t1.tv_usec - t3.tv_usec) / 1000.0;   // usec to ms
	t3 = t1;

	printf("calID: %d cmd:%d resp %d stepno %d CalError %d   time:%f  TIME:%f \n\n", Cal_id, Calcmd, CalResp, stepNo, CalError, elapsedTime1, elapsedTime2);
 
	PrevCalReqCmdInfo.RespRcvd = tempRcvd;

	return CalResp;	// CalResp is global variable, set by AcdCalScsCmdResp()
}


