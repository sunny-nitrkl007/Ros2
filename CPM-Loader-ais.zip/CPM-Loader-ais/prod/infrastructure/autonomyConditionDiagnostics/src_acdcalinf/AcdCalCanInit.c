/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: AcdCalCanInit.c
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  ACDCALMGRINF_H_
#include <AcdCalMgrInf.h>
#endif

///////////////////////////////////////////////////////////////////////////////
// -- #Define, Struct's, Typedef's, Enum's --

#if 0
#define LIB_MAP_ENTRY_RESERVE 25

const scl_j1939_ma_param_list_t app_scl_j1939_ma_param_tbl[] =
 {
    {
       0,     /* unsigned_16 Mu16_num_spn; */
       NULL,  /* scl_j1939_ma_param_def_t* Mpast_spn_list; */

       0,     /* unsigned_16 Mu16_num_pid; */
       NULL,  /* scl_j1939_ma_param_def_t* Mpast_pid_list; */

       NULL,  /* scl_j1939_ma_param_process_cb_t *process_cb_f; */

       1,     /* size_t Msz_max_overrides */

       0,     /* Mu16_num_rd_spn_hdlr */
       0,     /* Mu16_num_wr_spn_hdlr */
       0,     /* Mu16_num_ovr_spn_hdlr */

       ( LIB_MAP_ENTRY_RESERVE ),  /* Mu16_num_rd_pid_hdlr */
       (LIB_MAP_ENTRY_RESERVE),                                        /* Mu16_num_wr_pid_hdlr */
       0,     /* Mu16_num_ovr_pid_hdlr */
    }
 };
#endif
/******************************************************************************
FUNCTION init_cal_can
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void init_cal_can()
{
#if 0
	 scl_j1939_set_ma_configuration(
	    		Ph_Link_app,        /* scl_j1939_link_t Ph_link */
	                                      1,                            /* Pi8_ma_param_size */
	                                      app_scl_j1939_ma_param_tbl,   /* scl_j1939_ma_param_list_t* Ppast_ma_param_tbl */
	                                      2);                           /* unsigned_8 Pu8_max_ma_sessions */
#endif
	    cal_set_j1939_link(Ph_Link_app);
	    cal_set_j1939_ecm_index(0);

	    app_scl_qr_j1939_server_init(Ph_Link_app);
}
