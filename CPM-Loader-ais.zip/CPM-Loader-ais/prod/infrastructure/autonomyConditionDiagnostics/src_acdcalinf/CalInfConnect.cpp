/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: acd_cal_connector.cpp
DESCRIPTION:This file call ACD c++ API from cal C functions.
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/

#include <CalInfConnect.h>
#include <AcdCalScsInf.h>

#ifdef __cplusplus
extern "C" {
#endif

// Inside this "extern C" block, I can define C functions that are able to call C++ code


  /*send  calibration request to weighing app*/
 void  AcdCalScsCmd(){

	 AcdCalScsInf::AcdCalGetInstance()->AcdCalScsCmd();

 }

  /*Read resp from weighing app*/
 unsigned int AcdCalScsCmdResp()
 {
	 return AcdCalScsInf::AcdCalGetInstance()->AcdCalScsCmdResp();
 }

#ifdef __cplusplus

}
#endif
