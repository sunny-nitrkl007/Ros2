/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: AcdCalCdlPidReg.c
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef  ACDCALMGRINF_H_
#include <AcdCalMgrInf.h>
#endif

//** CAL:LINKAGESENSOR:01LV:1 - Lift Linkage Sensor Calibration **
//
//	- Calibration-enable PID(s):
//	0x00030175:0 - 0x00D10045 - Loader Lift Linkage Position Sensor Configuration
//
//** CAL:LINKAGESENSOR:02TV:1 - Tilt Linkage Sensor Calibration **
//
//	- Calibration-enable PID(s):
//	0x00030176:0 - 0x00D10046 - Loader Tilt Linkage Position Sensor Configuration

//- Calibration-enable PID(s):
//	0x00031018:0 - 0x00D10EE7 - Production Measurement Feature Enable Status
//	0x00030E20:0 - 0x00D10DA0 - Production Measurement Feature Installation Status
//	0x00030FCA:0 - 0x00D10EE6 - Production Measurement Feature Temporary Installation Status
//
//	- Qualified Reads(s):
//	0x0001005E:0 - 0x0045 - Hydraulic Oil Temperature(MIN_VALUE)
//	0x000125D2:0 - 0x00D01961 - Lift Cylinder Velocity(CAL_VALUE)
//	0x000125D2:0 - 0x00D01961 - Lift Cylinder Velocity(MIN_VALUE)
//
//** CAL:PCS:07FFBW:0 - Full Bucket Weight Calibration (Fast Raise) **
//
//	- Calibration-enable PID(s):
//	0x00031018:0 - 0x00D10EE7 - Production Measurement Feature Enable Status
//	0x00030FCA:0 - 0x00D10EE6 - Production Measurement Feature Temporary Installation Status
//	0x00030E20:0 - 0x00D10DA0 - Production Measurement Feature Installation Status
//
//	- Qualified Reads(s):
//	0x0001005E:0 - 0x0045 - Hydraulic Oil Temperature(MIN_VALUE)
//	0x000125D2:0 - 0x00D01961 - Lift Cylinder Velocity(CAL_VALUE)
//	0x000125D2:0 - 0x00D01961 - Lift Cylinder Velocity(MIN_VALUE)




/*unsigned short int pidF5D9_pdata = 0;
Cdl_gen_tx_pie_t pidF5D9_pie = { sizeof(pidF5D9_pdata), &pidF5D9_pdata };*/


///////////////////
unsigned short int pidD10045_pdata = 0x1C3;
Cdl_gen_tx_pie_t pidD10045_pie = { sizeof(pidD10045_pdata), &pidD10045_pdata };

unsigned short int  pidD10046_pdata = 0x1C3;
Cdl_gen_tx_pie_t pidD10046_pie = { sizeof(pidD10046_pdata), &pidD10046_pdata };

//////////////////////
unsigned short int  pid00D10EE7_pdata = 0x0C;
Cdl_gen_tx_pie_t pid00D10EE7_pie = { sizeof(pid00D10EE7_pdata), &pid00D10EE7_pdata };
unsigned short int  pid00D10DA0_pdata = 0x0010 ;
Cdl_gen_tx_pie_t pid00D10DA0_pie = { sizeof(pid00D10DA0_pdata), &pid00D10DA0_pdata };
unsigned short int  pid00D10EE6_pdata = 0x0010;
Cdl_gen_tx_pie_t pid00D10EE6_pie = { sizeof(pid00D10EE6_pdata), &pid00D10EE6_pdata };



/******************************************************************************
FUNCTION cal_cdl_pid_reg
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void cal_cdl_pid_reg(){
	//////////////////////
			 /*update the pie for the equipment id PID*/
			 cdl2_add_to_tx_pit(0xD10046,
					 /*fixed byte non-reversed data handler*/
					 cdl2_tx_f_hdlr,
					 &pidD10046_pie);
		 /*update the pie for the equipment id PID*/
			 cdl2_add_to_tx_pit(0xD10045,
					 /*fixed byte non-reversed data handler*/
					 cdl2_tx_f_hdlr,
					 &pidD10045_pie);


	////////////////////////////CAL ENABLE IDs

	 /*update the pie for the equipment id PID*/
			 cdl2_add_to_tx_pit(0x00D10EE7,
					 /*fixed byte non-reversed data handler*/
					 cdl2_tx_f_hdlr,
					 &pid00D10EE7_pie);
	 /*update the pie for the equipment id PID*/
			 cdl2_add_to_tx_pit(0x00D10DA0,
					 /*fixed byte non-reversed data handler*/
					 cdl2_tx_f_hdlr,
					 &pid00D10DA0_pie);
	 /*update the pie for the equipment id PID*/
			 cdl2_add_to_tx_pit(0x00D10EE6,
					 /*fixed byte non-reversed data handler*/
					 cdl2_tx_f_hdlr,
					 &pid00D10EE6_pie);
}
