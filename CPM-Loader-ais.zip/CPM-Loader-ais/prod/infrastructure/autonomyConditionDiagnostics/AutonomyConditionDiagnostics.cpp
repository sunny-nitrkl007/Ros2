///////////////////////////////////////////////////////////////////////////////
// @attention COPYRIGHT (C) 2011-2015 CATERPILLAR INC. ALL RIGHTS RESERVED.
//
// @file    AutonomyConditionDiagnostics.cpp
//
// @brief   This is the autonomyCondition diagnostics and events application.
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// -- #Include's --
///////////////////////////////////////////////////////////////////////////////

#include "AutonomyConditionDiagnostics.h"
#include <clock_tm_zone_proto.h>
#include <std_types.h>
#include <chrono>
#include <ctime>

#include <LoaderdiagnosticEventConfig/Loader_autonomy_diagnostics_config.h>
#include <LoaderdiagnosticEventConfig/Loader_autonomy_event_config.h>

#include "src_scl_info/app_scl_obd_es_config.h"
#include "src_j1939/app_can_init.h"
#include "src_j1939/app_j1939_map.h"
#include "src_nvm/app_nvm_file_init.h"
#include "src_j1939/app_et_j1939_support.h"
#include "src_catdl/app_catdl_init.h"
#include "src_hour/app_clock_init.h"
#include <ecminfolib_private.h>
#include "src_prmsw/app_prmsw_config.h"
#include <datalink_communication_fault2.h>
#include "src_catdl/app_disp_brightness.h"
#include <sys/stat.h>
#include "LpsCommonStructures.h"


using namespace std;
using namespace task;

///////////////////////////////////////////////////////////////////////////////
// -- #Define, Struct's, Typedef's, Enum's --
#ifdef __cplusplus
#define EXTERNC extern "C"
#else
#define EXTERNC
#endif


/******************************************************************************
 ***
 ***    Data types defined for this file
 ***    -- Struct's, Typedef's, Enum's --
 ***
 ******************************************************************************/

/* This is to export port configurations to app_can_init() */
int can_port1; 

/* This is to export EngineRunning State to clock_nvm */
unsigned_8 EngineRunning = 1; 

unsigned_8 app_master_mid;

unsigned_8 rtc_master_mid;
unsigned_8 rtc_type;
unsigned_8 rtc_security;

/* Used to make sure can is initialized before initializing EDDT */
bool_t can_init_completed = FALSE; 


/* Needed for scl_info diag/evnt support */
scl_obd_es_t              *app_scl_obd_es;
bool_t                    nvm_reset_flag = FALSE;


/* Needed for EDDT over J1939 support */
scl_diag_pj1939_t         *app_pj1939_diag_obj;
scl_obd_handle_gen_t      *app_handle_gen;
scl_obd_test_handle_t     app_test_handle;

int prmsw_feat_size;
scl_prmsw_free_use_cfg_t* prmsw_free_use_cfg;
scl_prmsw_feat_cfg_t* prmsw_feat_cfg;

int nvm_file_block_size;
nvm_file_block_cfg_t* app_nvm_file_cfg;


vector<std::string> block_filename;

struct stat nvm ={0};

/* MID of the D6 display.. used to send CDL over J1939 message toset brightness to 100% */
unsigned_8  mid_D6_display = 0x54;	

/*  frequency of ACD task used to set periodic timer to send D^ brightness write request to 100% */
unsigned_8 cycleRate_hz = 10;	       

extern int_16 LiftCylinderVelocity_val;

///////////////////////////////////////////////////////////////////////////////
// -- Symbols --
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
// -- Start of code for this file --
///////////////////////////////////////////////////////////////////////////////

AbstractTaskCore* task::getTaskImplementation( )
{
   static AutonomyConditionDiagnostics thisTask("AutonomyConditionDiagnostics");
   return dynamic_cast<Task *>(&thisTask);
}

///////////////////////////////////////////////////////////////////////////////
/// @brief AutonomyConditionDiagnostics Constructor
///////////////////////////////////////////////////////////////////////////////
AutonomyConditionDiagnostics::AutonomyConditionDiagnostics( const std::string& taskName ):
   AutonomyTask(taskName),
   m_enableOutfileWriter( false ),
   m_EDDT_init( false ),
   m_pAutonomyConditionMessageIn( NULL ),
   m_pDiagStatusOut( NULL ),
   m_pHealthInput(NULL),
   m_pDispBrightness(NULL),
   m_hostnameWhiteList(),
   m_useHostnameWhiteList(false),
   m_diagEventList(),
   LpsSaUIAppTxIn(NULL),
   LpsSaUIAppReqOut(NULL),
   LpsSaUIAppRespIn(NULL),
   m_autoCondList(),
   m_inhibitList(),
   m_outfileWriter(),
   m_initDone(false)
{

}


///////////////////////////////////////////////////////////////////////////////
/// @brief AutonomyConditionDiagnostics Destructor
///////////////////////////////////////////////////////////////////////////////
AutonomyConditionDiagnostics::~AutonomyConditionDiagnostics( )
{
	free(prmsw_free_use_cfg);
	free(prmsw_feat_cfg);
	free(app_nvm_file_cfg);
}

bool AutonomyConditionDiagnostics::loadNVMconfig()
{
    bool ret = true;
    ConfigSection section;

    std::string filepath(getenv("HOME"));
    filepath += "/appdata/CPM/ACD/nvm/";

    /* Create location for NVM log, if it doesn't already exist */
    if(stat(filepath.c_str(), &nvm) == -1)
    {
         system(("mkdir --mode=755 -p " + filepath).c_str());
    }

    if( getTaskParser().getSection( "NVM", section ))
    {
        list<std::string>  keys = section.getParameterNames();

        nvm_file_block_size = 0;
        for( list<std::string>::const_iterator it = keys.begin(); it != keys.end(); it++ )
        {
        	nvm_file_block_size++;
        }

        app_nvm_file_cfg = malloc(nvm_file_block_size * sizeof(nvm_file_block_cfg_t));

        for( list<std::string>::const_iterator it = keys.begin(); it != keys.end(); it++ )
        {
            vector<std::string> configArray;
            section.getArray(*it, configArray);
            int indx = atoi(it->c_str());

            uint_least32_t  blockid = strtol(configArray.at(0).c_str(), NULL, 16);
            uint_least32_t  blocksize = atoi( configArray.at(1).c_str() );
            uint_least8_t  block_int = atoi( configArray.at(2).c_str() );
            std::string filename = configArray.at(3);
            app_nvm_file_cfg[indx].data_id = blockid;
            app_nvm_file_cfg[indx].block_size = blocksize;
            app_nvm_file_cfg[indx].block_integrity = block_int;
            block_filename.push_back((filepath + filename));
            app_nvm_file_cfg[indx].filepathname1 = block_filename.at(indx).c_str();
            app_nvm_file_cfg[indx].filepathname2 = NULL;
        }
    }

    return ret;
}



bool AutonomyConditionDiagnostics::loadSEAconfig()
{
    bool ret = true;
    ConfigSection section;

    if( getTaskParser().getSection( "DeviceID_J1939", section ))
    {
        if ( !section.get("MID", j1939_mid) )
        {
            LOG_FATAL("Could not find MID");
            ret = ret & false;
        }
        if ( !section.get("ST_app_num", st_app_num) )
        {
            LOG_FATAL("Could not find ST_app_num");
            ret = ret & false;
        }
        if ( !section.get("ST_chg_lvl", st_chg_lvl) )
        {
            LOG_FATAL("Could not find ST_chg_lvl");
            ret = ret & false;
        }

        ret = ret & true;
    }
    else
    {
    	ret = ret & false;
    }

    if( getTaskParser().getSection( "SEA", section ))
    {
        list<std::string>  keys = section.getParameterNames();

        prmsw_feat_size = 0;
        for( list<std::string>::const_iterator it = keys.begin(); it != keys.end(); it++ )
        {
        	prmsw_feat_size++;
        }

        prmsw_free_use_cfg = malloc(prmsw_feat_size * sizeof(scl_prmsw_free_use_cfg_t));
        prmsw_feat_cfg = malloc(prmsw_feat_size * sizeof(scl_prmsw_feat_cfg_t));

        int prmsw_ind = 0;
        for( list<std::string>::const_iterator it = keys.begin(); it != keys.end(); it++, prmsw_ind++ )
        {
        	vector<std::string> configArray;
        	section.getArray(*it, configArray);
        	int indx = atoi(it->c_str());
        	uint_least32_t nvid = app_nvm_file_cfg[indx].data_id;
        	uint_least16_t tempcnt = (uint_least16_t) atoi(configArray.at(6).c_str());
        	scl_security_sec_level_t seclvl = (scl_security_sec_level_t) atoi(configArray.at(3).c_str());
        	scl_prmsw_free_use_cfg_t *ptr_prmsw_free_use_cfg;

        	if(0 == tempcnt)
        	{
        		ptr_prmsw_free_use_cfg = NULL;
        	}
        	else
        	{
        		prmsw_free_use_cfg[prmsw_ind] = SCL_PRMSW_FREE_USE_CFG_I1(
        		 (scl_prmsw_data_id_type_t) SCL_PRMSW_DATA_ID_TYPE_CDL,     //FREE_USE_DATA_ID_TYPE
			 (uint_least32_t) strtol(configArray.at(7).c_str(), NULL, 16),  //FREE_USE_DATA_ID
			 (scl_prmsw_data_id_type_t) SCL_PRMSW_DATA_ID_TYPE_CDL,  //FREE_USE_COUNT_DATA_ID_TYPE
			 (uint_least32_t) strtol(configArray.at(8).c_str(), NULL, 16),//FREE_USE_COUNT_DATA_ID
			 tempcnt                                                    //FREE_USE_COUNT_MAX
        		);
        		
 			ptr_prmsw_free_use_cfg = &prmsw_free_use_cfg[prmsw_ind];
        	}

        	if(0 == seclvl)
        	{
        		prmsw_feat_cfg[prmsw_ind] = SCL_PRMSW_FEAT_CFG_I1(
        		 (uint_least16_t) atoi(configArray.at(0).c_str()),   //REASON_CODE
			 (uint_least16_t) atoi(configArray.at(4).c_str()),  //ENCODING_BYTE_POS
			 (uint_least8_t) atoi(configArray.at(5).c_str()),   //ENCODING_BIT_INDEX
			 (uint_least32_t) nvid,                            //NVM_BLOCK_ID
			 (scl_prmsw_data_id_type_t) SCL_PRMSW_DATA_ID_TYPE_CDL, //PERM_FEAT_INSTALL_DATA_ID_TYPE
			 (uint_least32_t) strtol(configArray.at(1).c_str(), NULL, 16), //PERM_FEAT_INSTALL_DATA_ID
			 (scl_prmsw_data_id_type_t) SCL_PRMSW_DATA_ID_TYPE_CDL, //PERM_FEAT_ENABLE_DATA_ID_TYPE
			 (uint_least32_t) strtol(configArray.at(2).c_str(), NULL, 16), //PERM_FEAT_ENABLE_DATA_ID
			 ptr_prmsw_free_use_cfg,                                    //FREE_USE_CFG
			 app_prmsw_get_feat_status,                                 //FEAT_STATUS_CHANGE_FN_PTR
			 (void*) atoi(configArray.at(0).c_str())              //FEAT_STATUS_CHANGE_CONTEXT_PTR
        		);
        	}
        	else
        	{

        		prmsw_feat_cfg[prmsw_ind] = SCL_PRMSW_FEAT_CFG_I2(
        		 (uint_least16_t) atoi(configArray.at(0).c_str()),     //REASON_CODE
			 (uint_least16_t) atoi(configArray.at(4).c_str()),     //ENCODING_BYTE_POS
			 (uint_least8_t) atoi(configArray.at(5).c_str()),      //ENCODING_BIT_INDEX
			 (uint_least32_t) nvid,                        //NVM_BLOCK_ID
			 (scl_prmsw_data_id_type_t) SCL_PRMSW_DATA_ID_TYPE_CDL,     //PERM_FEAT_INSTALL_DATA_ID_TYPE
			 (uint_least32_t) strtol(configArray.at(1).c_str(), NULL, 16),  //PERM_FEAT_INSTALL_DATA_ID
 			 (scl_prmsw_data_id_type_t) SCL_PRMSW_DATA_ID_TYPE_CDL,     //PERM_FEAT_ENABLE_DATA_ID_TYPE
			 (uint_least32_t) strtol(configArray.at(2).c_str(), NULL, 16), //PERM_FEAT_ENABLE_DATA_ID
			 ptr_prmsw_free_use_cfg,                                    //FREE_USE_CFG
			 app_prmsw_get_feat_status,                                 //FEAT_STATUS_CHANGE_FN_PTR
			 (void*) atoi(configArray.at(0).c_str()),             //FEAT_STATUS_CHANGE_CONTEXT_PTR
			 seclvl                                               //SEC_LEVEL_ENABLE_PID
        		);
        	}

        	LOG_DEBUG("prmsw_feat_cfg[prmsw_ind].perm_install_data_id: %x", prmsw_feat_cfg		
				[prmsw_ind].perm_install_data_id);
        	LOG_DEBUG("prmsw_feat_cfg[prmsw_ind].perm_enable_data_id: %x", prmsw_feat_cfg[prmsw_ind].perm_enable_data_id);

        	if(prmsw_feat_cfg[prmsw_ind].free_use_cfg != NULL)
        	{
        	    LOG_DEBUG("prmsw_feat_cfg[prmsw_ind].free_use_cfg->free_use_data_id: %x", prmsw_feat_cfg[prmsw_ind].free_use_cfg->free_use_data_id);
        	    LOG_DEBUG("prmsw_feat_cfg[prmsw_ind].free_use_cfg->free_use_cnt_data_id: %x", prmsw_feat_cfg[prmsw_ind].free_use_cfg->free_use_cnt_data_id);
        	    LOG_DEBUG("prmsw_feat_cfg[prmsw_ind].free_use_cfg->free_use_count_max: %d", prmsw_feat_cfg[prmsw_ind].free_use_cfg->free_use_count_max);
        	}
        }

        ret = ret & true;
    }
    else
    {
    	ret = ret & false;
    }

    return ret;
}



///////////////////////////////////////////////////////////////////////////////
/// @brief AutonomyConditionDiagnostics Initialize
///
/// @return
///
///////////////////////////////////////////////////////////////////////////////
bool AutonomyConditionDiagnostics::autonomyInitialize( )
{
  if (!getTaskConfig().get("EDDT_CAN_port", can_port1))
  {
    can_port1 = 1; //default
    LOG_FATAL("EDDT_CAN_port NOT found");
  }

  // Check for invalid port configuration
  if ( can_port1 > 3 || can_port1 < 0 )
  {
    LOG_FATAL("Invalid port configuration. Configure ports in the range (0-3)");
    return false;
  }

  if (!getTaskConfig().get("MID_D6_Display", mid_D6_display))
  {
	  mid_D6_display = 0x54; //default
	  LOG_FATAL("mid_D6_display NOT found, set to default 0x54");
  }

  if (!getTaskConfig().get("cycleRate_hz", cycleRate_hz))
  {
	  cycleRate_hz = 10; //default
	  LOG_FATAL("cycleRate_hz NOT found, set to default 10");
  }

  if( !getEcmJ1939Name() )
  {
	   LOG_FATAL("ECM Name not found");
	   return false;
  }

  if( !getRTCconfig() )
  {
       LOG_FATAL("RTCconfig not found");
       return false;
  }

  if( !loadNVMconfig() )
  {
       LOG_FATAL("NVMconfig not found");
       return false;
  }

  if( !loadSEAconfig() )
  {
       LOG_FATAL("SEAconfig not found");
       return false;
  }

  if ( !initializeScsChannels() )
  {
    LOG_FATAL("Could not initialize SCS channels");
    return false;
  }

  m_useHostnameWhiteList = true;
  if (!getTaskConfig().getArray("hostnameWhiteList", m_hostnameWhiteList))
  {
    LOG_WARN("Could not initialize hostname whitelist - accepting conditions from all hosts");
    m_useHostnameWhiteList = false;
  }

  if ( !m_inhibitList.configure( getTaskParser(), m_autoCondList ) )
  {
    LOG_FATAL("Cound not initilize inhibits");
    return false;
  }

  if( !getTaskConfig().get( "EnableDiagnosticOutputFileWriter", m_enableOutfileWriter ))
  {
    LOG_FATAL("Could not get EnableDiagnosticOutputFileWriter from task config.");
    return false;
  }
  else if( m_enableOutfileWriter )
  {
    if ( !m_outfileWriter.configure( getTaskConfig() ) )
    {
      LOG_FATAL("Could not initialize output file writer");
      return false;
    }
  }

  m_seaStatusTimer.connect(boost::bind(&AutonomyConditionDiagnostics::publishSEAStatus,  this));
  m_seaStatusTimer.setInterval(1000);
  m_seaStatusTimer.start();
  
  // Initialize SHM publish Timer
  m_shmPublishTimer.setInterval(1000);
  m_shmPublishTimer.connect(boost::bind(&AutonomyConditionDiagnostics::publishSHM, this));
  m_shmPublishTimer.start();

  if (!getTaskConfig().get("ID_Master", app_master_mid))
  {
    app_master_mid = 0x1C; //default MID
    LOG_FATAL("ID_Master NOT found");
  }
  
  // Initialize j1939 communication stack. Call this at the end of autonomyInitialize()
  // so that j1939 stack can accept config parameteres from ruby file
  commInitialize();

  while(FALSE == can_init_completed)
  {
      sleep(1);
  }

  postInitialize();


  return true;
}

void AutonomyConditionDiagnostics::publishSEAStatus( )
{
    if(!m_initDone)
    {
        return;
    }

    m_seaStatus.m_seaList.clear();

    for(int indx = 0; indx < prmsw_feat_size; indx++)
    {
        SEA status;
        uint_least16_t cnt;

        scl_prmsw_get_free_use_cnt( prmsw_feat_cfg[indx].reason_code, &cnt);

        status.free_count = cnt;
        status.reason_code = prmsw_feat_cfg[indx].reason_code;
        status.status = scl_prmsw_get_feat_status(prmsw_feat_cfg[indx].reason_code);

        LOG_DEBUG("Reason code:%d, Status:=%d, Free Use:%d", prmsw_feat_cfg[indx].reason_code, scl_prmsw_get_feat_status(prmsw_feat_cfg[indx].reason_code), cnt);
        m_seaStatus.m_seaList.push_back(status);
    }

    m_seaStatusOutput->publish(m_seaStatus);

}

void AutonomyConditionDiagnostics::publishSHM()
{
	ShmClock shmStatus;

	shmStatus.attributes.originationTime = commonNow();
	shmStatus.set_SHM(currentHour_Sec);

	/* set the tzone info */
    #include <clock_tm_zone_proto.h>
    #include <clock_struct.h>
	bool_least_t sec = FALSE;
	tzone_tx_comm_struct app_tm_zone_tx_tbl;
	if(clock_tzone_get(&app_tm_zone_tx_tbl, &sec) == clock_RESULT_SUCCESS)
	{
	    shmStatus.setTzoneCommStruct(app_tm_zone_tx_tbl);
	}

	if(m_pSHMOutput)
	{
		m_pSHMOutput->publish( shmStatus );
	}
}

void AutonomyConditionDiagnostics::postInitialize( )
{
    if (TRUE == can_init_completed && FALSE == m_EDDT_init)
    {
        m_EDDT_init = initializeEDDT();
        m_initDone = m_EDDT_init;
        LOG_DEBUG("Post Init: %d",m_initDone);
    }
}

bool AutonomyConditionDiagnostics::initializeScsChannels( )
{
  //Initialize the Calibration channels
  AcdCalScsInf::AcdCalGetInstance()->AcdCalScsInitInterface();

  // Initialize the AutonomyConditions channel
  m_pAutonomyConditionMessageIn = fetch<AutonomyConditionMessageInput>("AutonomyConditionMessageInput");


  // Initialize the SCS output channel for DiagnosticStatus
  m_pDiagStatusOut  = fetch<DiagnosticStatusOutput>("DiagnosticStatusOutput");

  // Initialize the SCS input channel for SystemHardwareHealth
  m_pHealthInput  = fetch<SystemHardwareHealthInput>("SystemHardwareHealthInput");
  if (!m_pHealthInput )
  {
      LOG_FATAL("Failed to create SystemHardwareHealthInput");
      return false;
  }

  m_seaStatusOutput  = fetch<SEAStatusOutput>("SEAStatusOutput");
  
  // Initialize the SCS input channel for DispBrightness 
  //m_pDispBrightness  = dynamic_cast<AisJhm2TxChannelInput*>(InterfaceDb::fetch("AisJhm2TxChannelInput") );
  
  m_pDispBrightness  = fetch<AisJhm2TxChannelInput>("AisJhm2TxChannelInput");
  if (!m_pDispBrightness)
  {
      LOG_FATAL("Failed to create DispBrightnessInput");
      return false;
  }

   LpsSaWeighScsReqstOut  = dynamic_cast<LpsSaWeighReqstChannelOutput*>( InterfaceDb::fetch("LpsSaWeighReqstChannelOutput"));
   LpsSaWeighScsRespIn  = dynamic_cast<LpsSaWeighRespChannelInput*>( InterfaceDb::fetch("LpsSaWeighRespChannelInput"));
   LpsSaWeighScsTxIn    = dynamic_cast<LpsSaWeighTxChannelInput*>( InterfaceDb::fetch("LpsSaWeighTxChannelInput") );
   NewLpsSaWeighScsTxIn_ = 0;
   FlushLpsSaWeighScsTxIn_ = 0;
   LpsSaSwitchInput = dynamic_cast<SwitchInputScsInput*>( InterfaceDb::fetch("SwitchInputScsInput") );
   LpsSaJobMgrScsTxIn  = dynamic_cast<LpsSaJobMgrTxChannelInput*>( InterfaceDb::fetch("LpsSaJobMgrTxChannelInput") );
   LpsSaJobMgrScsReqstOut  = dynamic_cast<LpsSaJobMgrReqstChannelOutput*>( InterfaceDb::fetch("LpsSaJobMgrReqstChannelOutput"));
   LpsSaJobMgrScsRespIn  = dynamic_cast<LpsSaJobMgrRespChannelInput*>( InterfaceDb::fetch("LpsSaJobMgrRespChannelInput"));



   /* Initializing UI Tx channel as Input */
   LpsSaUIAppTxIn = dynamic_cast<LpsSaUIAppTxChannelInput*>( InterfaceDb::fetch("LpsSaUIAppTxChannelInput") );
  	if( LpsSaUIAppTxIn )
  	{
  		getLogger().log_info( "LpsSaUIAppTxIn  configured as a sender." );
  	}
  	else
  	{
  		getLogger().log_error( "t\n  LpsSaUIAppTxIn Interface  not configured." );
  		return false;
  	}
  	/* Initializing UI Request channel as Output */
     LpsSaUIAppReqOut = dynamic_cast<LpsSaUIAppReqChannelOutput*>( InterfaceDb::fetch("LpsSaUIAppReqChannelOutput") );
  	if( LpsSaUIAppReqOut )
  	{
  		getLogger().log_info( "LpsSaUIAppReqOut  configured as a sender." );
  	}
  	else
  	{
  		getLogger().log_error( "t\n  LpsSaUIAppReqOut Interface  not configured." );
  		return false;
  	}
  	/* Initializing UI Response channel as Input */
     LpsSaUIAppRespIn = dynamic_cast<LpsSaUIAppRespChannelInput*>( InterfaceDb::fetch("LpsSaUIAppRespChannelInput") );
  	if( LpsSaUIAppRespIn )
  	{
  		getLogger().log_info( "LpsSaUIAppRespIn  configured as a sender." );
  	}
  	else
  	{
  		getLogger().log_error( "t\n  LpsSaUIAppRespIn Interface  not configured." );
  		return false;
  	}


   // Initialize the SCS output channel for ShmClockOutput
	m_pSHMOutput  = fetch<ShmClockOutput>("ShmClockOutput");

	if (!m_pSHMOutput)
	{
	  LOG_FATAL("Failed to create ShmClockOutput");
	  return false;
	}

   if( LpsSaWeighScsReqstOut )
   {
	   getLogger().log_error( "LpsSaWeighReqstOut  configured as a producer/sender." );
   }
   else
   {
	   getLogger().log_error( "t\n  LpsSaWeighReqstOut Interface  not configured." );
	   return false;
   }

   if( LpsSaWeighScsRespIn )
   {
    	getLogger().log_error( "LpsSaWeighRespIn  configured as a producer/sender." );
   }
   else
   {
    	getLogger().log_error( "t\n  LpsSaWeighRespIn Interface  not configured." );
    	return false;
   }

   if( LpsSaWeighScsTxIn )
   {
    	getLogger().log_error( "LpsSaWeighScsTxIn  configured as a producer/sender." );
   }
   else
   {
    	getLogger().log_error( "t\n  LpsSaWeighScsTxIn Interface  not configured." );
    	 return false;
   }

   if ( LpsSaSwitchInput )
   {
	   getLogger().log_error( "LpsSaSwitchInput  configured as a producer/sender." );
   }
   else
   {
	   getLogger().log_error( "\n LpsSaSwitchInput Interface  not configured." );
	   return false;
   }

  return true;
}


bool AutonomyConditionDiagnostics::initDiagEvent( scl_ci_es_fault_cfg_eddt_t* logConfig, AutoDiagEvent::DiagEventType type, const std::string& name )
{
    app_test_handle = scl_obd_handle_gen_get(app_handle_gen);

    AutoDiagEvent diagEvent( name, logConfig, type, app_test_handle );

    ConfigSection cs;
    if ( !getTaskParser().getSection( name, cs ) )
    {
      LOG_FATAL("Could not find %s ConfigSection", name.c_str());
      return false;
    }

    if ( !diagEvent.configure( cs ) )
    {
      LOG_FATAL("Could not configure %s", name.c_str());
      return false;
    }

    m_diagEventList.push_back( diagEvent );
    return true;
}

bool AutonomyConditionDiagnostics::initializeDiagEvents( )
{
  // AIS diags/events
  if ( !initDiagEvent( &app_evntcfg_taskS_evnt_lv1, AutoDiagEvent::AUTO_EVENT, "TaskStalledEvent" ) ) return false;
  if ( !initDiagEvent( &app_evntcfg_taskC_evnt_lv1, AutoDiagEvent::AUTO_EVENT, "TaskCrashedEvent" ) ) return false;
  if ( !initDiagEvent( &app_evntcfg_low_ecu_power_input_voltage_evnt_lv3, AutoDiagEvent::AUTO_EVENT, "Battery_Low_Event" ) ) return false;
  if ( !initDiagEvent( &app_evntcfg_high_ecu_power_input_voltage_evnt_lv2, AutoDiagEvent::AUTO_EVENT, "Battery_High_Event" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_prod_id_not_recd_lv2, AutoDiagEvent::AUTO_DIAGNOSTIC, "ProdIDNotRecdDiagnostic" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_robot_file_missing_lv2, AutoDiagEvent::AUTO_DIAGNOSTIC, "RobotFileMissingDiagnostic" ) ) return false;

  //CPM diags/events
  if ( !initDiagEvent( &app_diagcfg_tilt_link_pos_vlt_abv_norm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "TiltLinkVoltageAboveDiagnostic" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_tilt_link_pos_vlt_blw_norm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "TiltLinkVoltageBelowDiagnostic" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_tilt_link_pos_abnorm_pwm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "TiltLinkFreqAbnormalDiagnostic" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_tilt_link_pos_out_calib_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "TiltLinkCalibrationOutDiagnostic" ) ) return false;

  if ( !initDiagEvent( &app_diagcfg_lift_link_pos_vlt_abv_norm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "LiftLinkVoltageAboveDiagnostic" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_lift_link_pos_vlt_blw_norm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "LiftLinkVoltageBelowDiagnostic" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_lift_link_pos_abnorm_pwm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "LiftLinkFreqAbnormalDiagnostic" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_lift_link_pos_out_calib_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "LiftLinkCalibrationOutDiagnostic" ) ) return false;

  if ( !initDiagEvent( &app_diagcfg_lift_re_pos_vlt_abv_norm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "LiftREVoltageAboveDiagnostic" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_lift_re_pos_vlt_blw_norm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "LiftREVoltageBelowDiagnostic" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_lift_re_pos_abnorm_pwm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "LiftREFreqAbnormalDiagnostic" ) ) return false;

  if ( !initDiagEvent( &app_diagcfg_lift_he_pos_vlt_abv_norm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "LiftHEVoltageAboveDiagnostic" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_lift_he_pos_vlt_blw_norm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "LiftHEVoltageBelowDiagnostic" ) ) return false;
  if ( !initDiagEvent( &app_diagcfg_lift_he_pos_abnorm_pwm_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "LiftHEFreqAbnormalDiagnostic" ) ) return false;

  if ( !initDiagEvent( &app_diagcfg_pay_load_mon_sys_out_calib_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "PayloadMonCalibrationOutDiagnostic" ) ) return false;

  if ( !initDiagEvent( &app_diagcfg_mach_not_set_lv1, AutoDiagEvent::AUTO_DIAGNOSTIC, "MachineModelNotSetOutDiagnostic" ) ) return false;

  if ( !initDiagEvent( &app_evntcfg_Payload_Weight_Too_Heavy_evnt_lv2, AutoDiagEvent::AUTO_EVENT, "PayLdWtTooHeavyToZeroEvent" ) ) return false;
  if ( !initDiagEvent( &app_evntcfg_Payload_CtrlSys_Not_Zeroed_evnt_lv2, AutoDiagEvent::AUTO_EVENT, "PayLdCtrlSysNotZeroedEvent" ) ) return false;
  if ( !initDiagEvent( &app_evntcfg_PayLd_OverLd_LimitExceeded_evnt_lv2, AutoDiagEvent::AUTO_EVENT, "PayLdOverLdLimitExceededEvent" ) ) return false;

  if ( !initializeAutoGenDiagEvents()) return false;


  return true;
}


int AutonomyConditionDiagnostics::getDiagEvent( const std::string& name )
{
  for ( unsigned int i = 0; i < m_diagEventList.size(); ++i )
  {
    if ( m_diagEventList.at( i ).name() == name )
      return i;
  }

  // This diag/event was not found
  return -1;
}

bool AutonomyConditionDiagnostics::getRTCconfig()
{
    ConfigSection RTC_TZName;
    bool ret = true;
    if (!getTaskParser().getSection("RTC_TZ",RTC_TZName))
    {
        LOG_ERROR("RTC_TZ config section not found");
        return false;
    }

    if (!getTaskConfig().get("EDDT_CAN_port", can_port1))
    {
      can_port1 = 1; //default
      LOG_FATAL("EDDT_CAN_port NOT found");
    }

    if ( !RTC_TZName.get("RTC_Security", rtc_security) )
    {
        rtc_security = 0; //security disabled
        LOG_FATAL("Could not find RTC_TZ::RTC_Security");
        ret = false;
    }

    if ( !RTC_TZName.get("RTC_Type", rtc_type) )
    {
        rtc_type = 0; //Standalone
        LOG_FATAL("Could not find RTC_TZ::RTC_Type");
        ret = false;
    }

    if(1 == rtc_type) //for client, server address is needed
    {
        if ( !RTC_TZName.get("RTC_Master", rtc_master_mid) )
        {
            rtc_master_mid = 0xCD;
            LOG_FATAL("Could not find RTC_TZ::RTC_Master");
            ret = false;
        }
    }

    return ret;
}

bool AutonomyConditionDiagnostics::getEcmJ1939Name()
{
    ConfigSection EcmJ1939Name;
    bool ret = true;
    if (!getTaskParser().getSection("Ecm_J1939_Name",EcmJ1939Name))
    {
        LOG_ERROR("Ecm_J1939_Name config section not found");
        return false;
    }

    if ( !EcmJ1939Name.get("Industry_Group", j1939_name_address.Mu8_industry_group) )
    {
        LOG_FATAL("Could not find Ecm_J1939_Name::Industry_Group info");
        ret = false;
    }

    if ( !EcmJ1939Name.get("Vehicle_System", j1939_name_address.Mu8_vehicle_system) )
    {
        LOG_FATAL("Could not find Ecm_J1939_Name::Vehicle_System info");
        ret = false;
    }

    if ( !EcmJ1939Name.get("Vehicle_System_Instance",j1939_name_address.Mu8_vehicle_system_instance) )
    {
        LOG_FATAL("Could not find Ecm_J1939_Name::Vehicle_System_Instance info");
        ret = false;
    }

    if ( !EcmJ1939Name.get("Function", j1939_name_address.Mu8_function) )
    {
        LOG_FATAL("Could not find Ecm_J1939_Name::Function info");
        ret = false;
    }

    if ( !EcmJ1939Name.get("Function_Instance", j1939_name_address.Mu8_function_instance) )
    {
        LOG_FATAL("Could not find Ecm_J1939_Name::Function_Instance info");
        ret = false;
    }

    if ( !EcmJ1939Name.get("ECU_Instance", j1939_name_address.Mu8_ecu_instance) )
    {
        LOG_FATAL("Could not find Ecm_J1939_Name::ECU_Instance info");
        ret = false;
    }

    if ( !EcmJ1939Name.get("Manufacturer_Code", j1939_name_address.Mu16_manufacturer_code) )
    {
        LOG_FATAL("Could not find Ecm_J1939_Name::Manufacturer_Code info");
        ret = false;
    }

    if ( !EcmJ1939Name.get("Identity_Number", j1939_name_address.Mu32_identity_number) )
    {
        LOG_FATAL("Could not find Ecm_J1939_Name::Identity_Number info");
        ret = false;
    }

    if ( !EcmJ1939Name.get("Preferred_Address", j1939_name_address.Mu8_preferred_address) )
    {
        LOG_FATAL("Could not find Ecm_J1939_Name::Preferred_Address info");
        ret = false;
    }

    return ret;
}

bool AutonomyConditionDiagnostics::initializeEDDT( )
{
  bool ret_val = true;
  scl_obd_es_error_t        es_error_code = SCL_OBD_ES_SUCCESS;
  scl_diag_pj1939_error_t   app_scl_diag_pj1939_error = SCL_DIAG_PJ1939_SUCCESSFUL;

  // These need to be added after commInitialize because they require oel to be initialized

     /* Initialize obd event system */
     app_scl_obd_es = scl_obd_es_init(&app_scl_obd_es_config,
                                      nvm_reset_flag,
                                      &es_error_code);
     LOG_DEBUG("scl_obd_es_init error:%d",es_error_code);

     if(SCL_OBD_ES_SUCCESS == es_error_code)
     {
         /* Initialize eddt on j1939 */
         app_pj1939_diag_obj = scl_diag_pj1939_init(&app_scl_diag_pj1939_config,
                                                    Ph_Link_app,
                                                    0,
                                                    app_scl_obd_es,
                                                    NULL,
                                                    &app_scl_diag_pj1939_error);
         LOG_DEBUG("scl_diag_pj1939_init error:%d",app_scl_diag_pj1939_error);

         if(SCL_DIAG_PJ1939_SUCCESSFUL == app_scl_diag_pj1939_error)
         {
             /* Initialize the handle generator */
             app_handle_gen = scl_obd_handle_gen_init();

             // This needs to be added after commInitialize because it requires j1939 to be initialized
             if ( !initializeDiagEvents() )
             {
               LOG_FATAL("Could not initialize diagnostics/events");
               ret_val = false;
             }

             //Add of the diagnostics and events to the inhibit list as well
             for ( unsigned int i = 0; i < m_diagEventList.size(); ++i )
             {
               if ( !m_inhibitList.addCondition( &(m_diagEventList.at(i)) ) )
               {
                 LOG_FATAL( "Error adding %s as an inhibit condition", m_diagEventList.at(i).name().c_str() );
                 ret_val = false;
               }
             }
         }
         else
         {
             ret_val = false;
         }
     }
     else
     {
         ret_val = false;
     }

  return ret_val;
}

////////////////////////////////////////////////////////////////////////////////////
/// @brief Returns true if the passed hostname is in the whitelist or if the whitelist is not being used
/// @return true if the passed hostname is in the whitelist or if the whitelist is not being used, false otherwise
/// @param thisHostName the hostname to check
////////////////////////////////////////////////////////////////////////////////////
bool AutonomyConditionDiagnostics::acceptedHost(const std::string& thisHostName) const
{
  if(m_useHostnameWhiteList)
  {
    for(unsigned int hni = 0; hni < m_hostnameWhiteList.size(); ++hni)
    {
      if(m_hostnameWhiteList[hni] == thisHostName)
      {
        return true;  // a match in the whitelist was found
      }
    }
    return false;  // no match in the whitelist was found
  }
  else
  {
    return true;  // all hosts are accepted if not using whitelist
  }
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Update the gui based in the current list of messages to process
///////////////////////////////////////////////////////////////////////////////
void AutonomyConditionDiagnostics::processHardwareHealthStatus()
{

    SystemHardwareHealth data;
    if (m_pHealthInput->get(data))
    {
        if(std::strcmp(data.ecmHwVersion.serialnum.c_str(), "NOT AVAILABLE") != 0)
        {
            std::strncpy(ecm_serial_number, data.ecmHwVersion.serialnum.c_str(), ECM_SERIAL_NUMBER_MAX_SIZE);
        }

        if(std::strcmp(data.ecmHwVersion.partnum.c_str(), "NOT AVAILABLE") != 0)
        {
            std::strncpy(ecm_part_number, data.ecmHwVersion.partnum.c_str(), ECM_PART_NUMBER_MAX_SIZE);
        }

        char* temp = data.ecmSwVersion.c_str();
        std::strncpy(software_group_part_number, temp, SOFTWARE_GROUP_PN_LENGTH); //  TODO
        temp += SOFTWARE_GROUP_PN_LENGTH;
        std::strncpy(software_group_date_code, temp, SOFTWARE_GROUP_DATE_CODE_LENGTH);//  TODO
        temp += SOFTWARE_GROUP_DATE_CODE_LENGTH;
        std::strncpy(app_description_dl_tx_pie, temp, APPLICATION_TEXT_MAX_SIZE);//  TODO

    }

    //std::strncpy(pidF82D_pdata, m_machineSN.c_str(), 8);
    //std::strncpy(pidF81A_pdata, m_equipmentID.c_str(), 17);
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Update the gui based in the current list of messages to process
///////////////////////////////////////////////////////////////////////////////
void AutonomyConditionDiagnostics::processDispBrightness()
{
	static int  dispbrightness_write_request_timer = 0;

    /* Send CDL Parameter Write Request with Param Data Resp(0x9E) for Disp Brightness PID D0022B */
    unsigned_8 tx_message[6] = {0x9E, 0xD0, 0x02, 0x2B, 0xFF, 0xFF};  // D0022B

    /* DispBrightness code always set to 100%  */
    dispbrightness_write_request_timer --;	// used to send message every 10 seconds to D6

    if (0 >=  dispbrightness_write_request_timer)
   {
        dispbrightness_write_request_timer = (unsigned_16)(cycleRate_hz * 10);	// every 10 seconds loops send write request
		// cycleRate_hz = 20 ==   50ms * 200 = 10000 = 10 seconds
		// cycleRate_hz = 10 == 100ms * 100 = 10000 = 10 seconds
		// cycleRate_hz = 5 ==   200ms *   50 = 10000 = 10 seconds
		// cycleRate_hz = 1 ==  1000ms *   10 = 10000 = 10 seconds

	/* Send a write request */
 	tx_message[4] = (0x0064 & 0x00FF);	    /* Set to 100% brightness */
 	tx_message[5] = (0x0000 & 0xFF00);       /* Set to 100% brightness */

     	scl_j1939_que_tx_msg_by_address(
     		Ph_Link_app,                /* Handle identifying J1939 connection */
        	0x00EF00,                   /* Proprietary PGN */
        	6,                          /* priority identifier field */
        	mid_D6_display,          /* destination address used in the PS field */
        	0,                          /* Index to ecm in address table */
        	tx_message,                 /* pointer to the data field that will be transmitted */
        	6                           /* the length of the data field in number of bytes */
    	);
    }
  
    return;
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Main loop for AutonomyConditionDiagnostics.
///
/// @return true/false
///
///////////////////////////////////////////////////////////////////////////////
bool AutonomyConditionDiagnostics::autonomyExecutive( )
{


    if(!m_initDone)
    {
        return true;
    }
	//struct clock_tm* clock_rtc_local_time;
	//clock_rtc_local_time = clock_tzone_get_local_tm();
	//printf("SA Local RTC:%d/%d/%d %d:%d:%d\n", clock_rtc_local_time->tm_mday, clock_rtc_local_time->tm_mon + 1, clock_rtc_local_time->tm_year + clock_TM_0_YEAR, clock_rtc_local_time->tm_hour,clock_rtc_local_time->tm_min,clock_rtc_local_time->tm_sec);

  if ( m_pAutonomyConditionMessageIn )
  {
    bool newMsgRx=true;
    while( newMsgRx )
    {
      AutonomyConditionMessage msg;
      newMsgRx = m_pAutonomyConditionMessageIn->get( msg );

      if ( newMsgRx )
      {
        if(acceptedHost(msg.getReporterHostname()))
        {
          m_autoCondList.update( msg );
        }
      }
    }
  }

  if (TRUE == m_EDDT_init)
  {
    //Update the evnt/diag code based on the autonomy conditions
    int dummy=0;
    for ( unsigned int i = 0; i < m_diagEventList.size(); ++i )
    {
      m_diagEventList.at(i).update(m_autoCondList, m_inhibitList, dummy, dummy, i, m_diagEventList);
    }

    /* OBD Event System related periodic tasks */
    scl_obd_es_update(app_scl_obd_es);

    /* PJ1939 diag update to support EDDT on J1939 link */
    scl_diag_pj1939_update(app_pj1939_diag_obj);


    for ( unsigned int i = 0; i < m_diagEventList.size(); ++i )
    {
      scl_obd_es_fault_rep_t fault_report;
      scl_obd_es_occur_info_t  occur_info;
      scl_obd_es_error_t  error;

      /* get the current fault status */
      error = scl_obd_es_get_fault_rep(app_scl_obd_es,
                                       i,
									   &fault_report);
      (void) error;
      scl_obd_es_get_occur_info(app_scl_obd_es, i, &occur_info);

      if(m_diagEventList.at(i).active())
      {
          LOG_DEBUG("fault_report for %s :Time(%d::%d::%d::%d::%d::%d)",m_diagEventList.at(i).name().c_str(), occur_info.last_rtc.year, occur_info.last_rtc.month, occur_info.last_rtc.day, occur_info.last_rtc.hour, occur_info.last_rtc.minute, occur_info.last_rtc.second);
      }
    }

  }


  { //Startup Event

    double timeRemaining_sec;
    bool startingUp = m_inhibitList.startupInhibitActive( timeRemaining_sec );

    //get the vector index of the startup in progress event
    int startupEventInd = getDiagEvent( "StartupInProgress" );
    //if the startup in progress event exists, set it's activation if the startup inhibit is active
    if ( startupEventInd >= 0 )
    {
      if ( startingUp )
      {
        std::stringstream ss;
        ss.setf(ios::fixed,ios::floatfield);   // floatfield set to fixed
        ss << "There are " << setprecision (2) << timeRemaining_sec << " Seconds Remaining." << std::endl;
        m_diagEventList.at( startupEventInd ).setConditionString( ss.str() );
        m_diagEventList.at( startupEventInd ).setStatus( true );
      } else
      {
        m_diagEventList.at( startupEventInd ).setConditionString( "" );
        m_diagEventList.at( startupEventInd ).setStatus( false );
      }
    }
  }

  // Publish DiagnosticStatus
  if ( m_pDiagStatusOut )
  {
    static DiagnosticStatus diagStat;
    //Update the diagnostic Status
    for ( unsigned int i = 0; i < m_diagEventList.size(); ++i )
    {
      if ( i >= diagStat.m_diagEventStatList.size() )
      {
        DiagnosticStatus::DiagEventStatus newDiagEventStatus;
        diagStat.m_diagEventStatList.push_back( newDiagEventStatus );
      }
      m_diagEventList.at(i).getDiagEventStatus( diagStat.m_diagEventStatList.at(i) );

      if(m_diagEventList.at(i).firstActivated())
      {
    	  diagStat.m_diagEventStatList.at(i).m_gpsTime = commonNow();

    	  //Moved the logic temporarily here. until additional info is supported
		  if(m_diagEventList.at(i).logEnabled() )
		  {
			  if( m_enableOutfileWriter )
			  {
				//Print to output file
				m_outfileWriter.log( m_diagEventList.at(i), 0, 0 );
			  }
		  }
      }
    }
    //Update Origination Time
    diagStat.attributes.originationTime = commonNow();
    //And Send
    m_pDiagStatusOut->publish( diagStat );
  }
 	ReadWeighAppScsTx();
	ReadJobMgrAppScsTx();
	ReadStoreSwitchTx();

	CheckForWeighAppCmdResp();
  //processHardwareHealthStatus();
  //processDispBrightness();

	IssueCmdToWeighApp();
	IssueCmdToJobMgrApp();
	processHardwareHealthStatus();
	processDispBrightness();
	ReadSystemParam();/* Which will read System parameter PIDs */
		ReadFromUITx();
		IssueCmdToUIApp();

  LOG_DEBUG("Service Hour: %d",currentHour_Sec);
  return true;
}

/******************************************************************************
FUNCTION ReadSystemParam
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void AutonomyConditionDiagnostics::ReadSystemParam(void)
{
	PidF42A = CONVERT_TO_PT001_RES(24.01);/*System Voltage*/
	PidF2C4 = 0x01 ;/*ECM Location Code*/
	getLogger().log_debug( "\n PidF2C4 = %i ", PidF2C4);
	PidF2C5 = 0x02;/*Desired ECM Location Code*/
	getLogger().log_debug( "\n PidF2C5 = %i ", PidF2C5);
}

/******************************************************************************
FUNCTION IssueCmdToWeighApp
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void AutonomyConditionDiagnostics::IssueCmdToWeighApp(void)
{
	LpsSaWeighReqstChannel cmdOut;

	cmdOut.WeighRangeRequest.WeighRangeReqstFlag = false;
	cmdOut.ZeroReqst = false;
	cmdOut.BestBktRstReqst = false;
	cmdOut.CaptCylExtRef = false;
	cmdOut.SetCalWtRequest.newCalWtFlag = false;
	cmdOut.PloadOvrloadWarnEnReq = false;
	cmdOut.LastPloadWtSetReq = false;
	cmdOut.LoaderBktPloadTgtWtSetReq = false;

	if ( LpsSaWeighScsReqstOut )
	{
	    bool publish = true;
		if((true == WeighRangeBottomRqstFlg) || (true == WeighRangeSizeRqstFlg))
		{
			//unsigned_16 tempVar = 0;
			WeighRangeBottomRqstFlg = false;
			WeighRangeSizeRqstFlg   = false;
			cmdOut.WeighRangeRequest.WeighRangeReqstFlag = true;
			//tempVar = (PidWrD00C9F >>);
			cmdOut.WeighRangeRequest.WeighRangeBottom = (float)((float) PidWrD00C9F * 0.1);
			cmdOut.WeighRangeRequest.WeighRangeSize = (float)((float) PidWrD0102D * 0.1);
		}

		else if(PidWrD009A7Flag)
		{
			cmdOut.SetCalWtRequest.newCalWtFlag = true;
			cmdOut.SetCalWtRequest.newCalWt = (float) DIV_BY_1000((float)PidWrD009A7);/* - Payload Control System Calibration Weight [1]*/
			PidWrD009A7Flag = false;
		}		
		
		else if(PidWrD10ACCFlag)
		{
			cmdOut.PloadOvrloadWarnEnReq =true;
			cmdOut.PidWrData.PloadOvrloadWarnEn = PidWrD10ACC;/* - Payload Overload Warning Enable [1] (RECM)*/
			//OEL_PACK_BE_16_NO_INCR(cmdOut.PidWrData.PloadOvrloadWarnEn, PidWrD10ACC);
			PidWrD10ACCFlag = false;
		}

		else if(PidWrD01B24Flag)
		{
			cmdOut.LastPloadWtSetReq = true;
			cmdOut.PidWrData.LastPloadWt = (float) DIV_BY_100((float)PidWrD01B24);/* - Last Payload Weight [255]*/
			PidWrD01B24Flag = false;
		}


		else if(PidWrD009F5Flag)
		{
			cmdOut.LoaderBktPloadTgtWtSetReq = true;
			cmdOut.PidWrData.LoaderBktPloadTgtWt = (float) DIV_BY_10((float)PidWrD009F5);/* - Loader Bucket Payload Target Weight [1]*/
			PidWrD009F5Flag = false;
		}

		else
		{
			/* Do nothing */
		    publish = false;
		}

        if (publish) {
            LpsSaWeighScsReqstOut->publish(cmdOut);
            FlushLpsSaWeighScsTxIn_ = 1;
        }
	}
}


/******************************************************************************
FUNCTION IssueCmdToJobMgrApp
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void AutonomyConditionDiagnostics::IssueCmdToJobMgrApp(void)
{
	bool scsCmdRet;
	LpsSaJobMgrReqstChannel cmdOut;

	cmdOut.ZeroReqst = false;
	cmdOut.MinusOneReqst = false;
	cmdOut.ClearReqst = false;
	cmdOut.StoreReqst = false;
	cmdOut.StandByActReqst = false;
	cmdOut.StandByDeactReqst = false;
	cmdOut.TruckPileTipOffToggleReqst = false;
	cmdOut.ManualTipOffActReqst = false;
	cmdOut.ManualTipOffDeactReqst = false;
	cmdOut.TipOffTrigger.ReqstFlag = false;
	cmdOut.TipOffState.ReqstFlag = false;
	cmdOut.ReWeighReqst = false;
	cmdOut.TargetWeightReqst.ReqstFlag = false;
	cmdOut.TipOffTrigger.ReqstFlag = false;

	cmdOut.LifetimePayloadPassCount.ReqstFlag = false;
	cmdOut.LifetimeTotalPayload.ReqstFlag = false;
	cmdOut.LifetimeTruckLoadCount.ReqstFlag = false;
	cmdOut.HornStoreStateReqst.ReqstFlag = false;
	cmdOut.HornStoreStateReqst.Enable = false;
	
	if(PidWrFC06Flag)
	{
		cmdOut.LifetimeTruckLoadCount.Data = PidFC06;
		cmdOut.LifetimeTruckLoadCount.ReqstFlag = true;
		PidWrFC06Flag = false;
	}

	else if(PidWrFCF8Flag)
	{
		cmdOut.LifetimeTotalPayload.Data = (double) PidFCF8;
		cmdOut.LifetimeTotalPayload.ReqstFlag = true;
		PidWrFCF8Flag = false;
	}

	else if(PidWrFCF7Flag)
	{
		cmdOut.LifetimePayloadPassCount.Data = PidFCF7;
		cmdOut.LifetimePayloadPassCount.ReqstFlag = true;
		PidWrFCF7Flag = false;
	}

	else if(PidWrD112B2Flag)
	{
		cmdOut.TipOffTrigger.ReqstFlag = true;
		PidWrD112B2Flag = false;
		switch (PidWrD112B2)
		{
			case TIP_OFF_AUTO :
				cmdOut.TipOffTrigger.Type = LPS_SA_JOB_MGR_TIP_OFF_TRIGGER_AUTO;/* - Tip-Off Trigger Type Configuration [1] (RECM)*/
				break;
			case TIP_OFF_MANUAL :
				cmdOut.TipOffTrigger.Type = LPS_SA_JOB_MGR_TIP_OFF_TRIGGER_MANUAL;/* - Tip-Off Trigger Type Configuration [1] (RECM)*/
				break;
		/* you can have any number of case statements */
		   default : /* Optional */
			   cmdOut.TipOffTrigger.Type = LPS_SA_JOB_MGR_TIP_OFF_TRIGGER_DISABLED;
		}
	}

	else if(PidWrD10E4EFlag)
	{
		cmdOut.TipOffState.ReqstFlag = true;
		PidWrD10E4EFlag = false;
		//printf("PidWrD10E4E SCS= %d",PidWrD10E4E);
		switch (PidWrD10E4E)
		{
			case TIP_OFF_PILE :
				cmdOut.TipOffState.State = LPS_SA_JOB_MGR_TIP_OFF_PILE_ENABLE;/* - Tip-Off Trigger Type Configuration [1] (RECM)*/
				break;
			case TIP_OFF_TRUCK :
				cmdOut.TipOffState.State = LPS_SA_JOB_MGR_TIP_OFF_TRUCK_ENABLE;/* - Tip-Off Trigger Type Configuration [1] (RECM)*/
				break;
		}
	}
	else if(PidWrD106C4Flag)
	{
	   cmdOut.HornStoreStateReqst.ReqstFlag = true;
	   PidWrD106C4Flag = false;
	   switch( PidWrD106C4 )
	   {
	      case StorePloadHornStat_t::SOUND_HORN:
	         cmdOut.HornStoreStateReqst.Enable = true;
	         break;
	      case StorePloadHornStat_t::NOT_SOUND_HORN:
            cmdOut.HornStoreStateReqst.Enable = false;
	         break;
	   }
	}
	else
	{
		/* Do nothing */
	}

	scsCmdRet = LpsSaJobMgrScsReqstOut->publish(cmdOut);
	getLogger().log_debug( "\n Line no = %d,'CheckForWeighAppCmds' function return code = %d PidWrD00C9F = %d PidWrD0102D = %d\n",__LINE__,scsCmdRet,PidWrD00C9F,PidWrD0102D );

}

/******************************************************************************
FUNCTION CheckForWeighAppCmdResp
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void AutonomyConditionDiagnostics::CheckForWeighAppCmdResp(void)
{
	LpsSaWeighRespChannel respIn;

	/* Retreive SCS channel data */
	while(LpsSaWeighScsRespIn->get( respIn ))
	{
		getLogger().log_debug( "\n Line no = %d,'CheckForWeighAppCmdResp' \n",__LINE__);
	}

}

/******************************************************************************
FUNCTION CheckForJobMgrAppCmdResp
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void AutonomyConditionDiagnostics::CheckForJobMgrAppCmdResp(void)
{
	LpsSaJobMgrRespChannel respIn;

	/* Retreive SCS channel data */
	while(LpsSaJobMgrScsRespIn->get( respIn ))
	{
		getLogger().log_debug( "\n Line no = %d,'CheckForJobMgrAppCmdResp' \n",__LINE__);
	}

}

void AutonomyConditionDiagnostics::ReadWeighAppScsTx(void)
{
	LpsSaWeighTxChannel WeighParam;
	unsigned_16 zeroReqStat[3]= {0x001B,0x03D4,0x03D3};

	if ( LpsSaWeighScsTxIn)
	{
	    if (FlushLpsSaWeighScsTxIn_) {
	        /*
	         * Throw away all inputs that came before we sent our
	         * write request.  This is not bullet-proof because we
	         * still cannot completely get rid of the race condition
	         * without a redesign.
	         *
	         * The race condition is that we do a write request, then
	         * receive an 'old' value via TxIn, then later receive
	         * the result of the write request via TxIn.  This intermediate
	         * 'old' value is requested by the service tool and the write
	         * appears to have failed.
	         */
	        while (LpsSaWeighScsTxIn->get(WeighParam));
	        NewLpsSaWeighScsTxIn_ = 0;
	        FlushLpsSaWeighScsTxIn_ = 0;
	    }
	    else {

	        while(LpsSaWeighScsTxIn->get( WeighParam ))
	        {
	            PidD00C9F = (unsigned_16) (WeighParam.WeighRange.WeighRangeBottom/0.1);
	            PidD0102D = (unsigned_16) (WeighParam.WeighRange.WeighRangeSize/0.1);
	            getLogger().log_debug( "\n PidD00C9F = %d , PidD0102D = %d,rxParam.WeighRange.WeighRangeBottom = %f, rxParam.WeighRange.WeighRangeSize = %f\n",PidD00C9F,
	                    PidD0102D,WeighParam.WeighRange.WeighRangeBottom, WeighParam.WeighRange.WeighRangeSize);
	            PidD00E9B = (unsigned_16)WeighParam.PidData.ProdMeasureWeighStatus.Data;
	            getLogger().log_debug( "\n PidD00E9B = %i ", PidD00E9B);


	            /*Production Measurement Sensor Status*/
		    /*Lift Linkage Position Sensor Duty Cycle*/
	            PidF13D = (unsigned_8) WeighParam.PidData.ProdMeasureSensorStatus.LiftLinkDC;
	            getLogger().log_debug( "\n PidF13D = %i ", PidF13D);
	            
		    /*Lift Cylinder Position*/
		    PidF5AE = (unsigned_16) CONVERT_TO_PT1_RES(WeighParam.PidData.ProdMeasureSensorStatus.LiftCylPos);
	            getLogger().log_debug( "\n PidF5AE = %i ", PidF5AE);
	            
		    /*Lift Cylinder Head End Pressure*/
		    PidF47B = (unsigned_16) WeighParam.PidData.ProdMeasureSensorStatus.LiftCylHEPres;
	            getLogger().log_debug( "\n PidF47B = %i ", PidF47B);

		    /*Lift Cylinder Rod End Pressure*/
	            PidF5AF = (unsigned_16) WeighParam.PidData.ProdMeasureSensorStatus.LiftCylREPres;
	            getLogger().log_debug( "\n PidF5AF = %i ", PidF5AF);

		    /*Tilt Linkage Position Sensor Duty Cycle*/
	            PidF13E = (unsigned_8) WeighParam.PidData.ProdMeasureSensorStatus.TiltLinkDC;
	            getLogger().log_debug( "\n PidF13E = %i ", PidF13E);
	            
		    /*Hydraulic Oil Temperature*/
                    Pid0045 = (int_16) WeighParam.PidData.ProdMeasureSensorStatus.HydOilTemp;
	            if((int_16)WeighParam.PidData.ProdMeasureSensorStatus.HydOilTemp == -32736)
	            {
	                Pid0045 = UNKNOWN2S + FMICNM;
	            }
	            getLogger().log_debug( "\n Pid0045 = %i ", Pid0045);
			   
                    /*Lift Cylinder Extension (Absolute)*/
		    Pid00D0018B = (unsigned_16) WeighParam.PidData.ProdMeasureSensorStatus.LiftCylExtMm;
	            getLogger().log_debug( "\n Pid00D0018B = %i ", Pid00D0018B);

                    /*Tilt Cylinder Extension (Absolute)*/
		    Pid00D0018C = (unsigned_16) WeighParam.PidData.ProdMeasureSensorStatus.TiltCylExtMm;
		    getLogger().log_debug( "\n Pid00D0018C = %i ", Pid00D0018C);

                    /*Loader Bucket Angle */
                    /* Apply scaling of 0.1%/bit only if it is not a DSI */
		    if((int_16) ( (WeighParam.PidData.ProdMeasureSensorStatus.BktAngle) == (UNKNOWN2S + FMIIUA)))
	            {
                        Pid00D00A70  = (int_16) (WeighParam.PidData.ProdMeasureSensorStatus.BktAngle);
	            }	
                    else
		    {
                    	Pid00D00A70  = (int_16) ( (WeighParam.PidData.ProdMeasureSensorStatus.BktAngle) / (0.1));
		    }
		    getLogger().log_debug( "\n Pid000D00A70 = %i ", Pid00D00A70);

                    /*Lift Linkage Position Sensor Full Raise Duty Cycle*/
	            PidD010FA = (unsigned_16) CONVERT_TO_PT01_RES(WeighParam.PidData.LinkSensorCalLim.LiftPosSensorFullRaiseDC);
	            getLogger().log_debug( "\n PidD010FA = %i ", PidD010FA);
	            
                    /*Lift Linkage Position Sensor Full Lower Duty Cycle*/
                    PidD010FB = (unsigned_16) CONVERT_TO_PT01_RES(WeighParam.PidData.LinkSensorCalLim.LiftPosSensorFullLowerDC);
	            getLogger().log_debug( "\n PidD010FB = %i ", PidD010FB);

                    /*Tilt Linkage Position Sensor Full Rackback Duty Cycle*/
	            PidD010FC = (unsigned_16) CONVERT_TO_PT01_RES(WeighParam.PidData.LinkSensorCalLim.TiltPosSensorFullRackDC);
	            getLogger().log_debug( "\n PidD010FC = %i ", PidD010FC);

                    /*Tilt Linkage Position Sensor Full Dump Duty Cycle*/
	            PidD010FD = (unsigned_16) CONVERT_TO_PT01_RES(WeighParam.PidData.LinkSensorCalLim.TiltPosSensorFullDumpDC);
	            getLogger().log_debug( "\n PidD010FD = %i ", PidD010FD);
	            
                    /*Payload Calculation Method*/
                    PidD01788 = WeighParam.PayloadCalcMeth;
	            getLogger().log_debug( "\n PidD01788 = %i ", PidD01788);
	            
                    /* - Payload Overload Warning Enable [1] (RECM)*/
                    PidD10ACC = (unsigned_16) WeighParam.PidData.PloadOvrloadWarnEn;
	            getLogger().log_debug( "\n PidD10ACC = %i ", PidD10ACC);
	            
                    PidD01B24 = (int_16) CONVERT_TO_PT01_RES(WeighParam.PidData.LastPloadWt);
	            if(WeighParam.PidData.LastPloadWt <= 0)
	            {
	                PidD01B24 = UNKNOWN2S + FMICNM;
	            }
	            getLogger().log_debug( "\n PidD01B24 = %i ", PidD01B24);
	            
                    PidD106DF = (unsigned_16) WeighParam.Indicator;
	            getLogger().log_debug( "\n PidD106DF = %i ", PidD106DF);
	            
                    PidD10822 = (unsigned_16) WeighParam.PidData.PloadSysZeroStat;
	            getLogger().log_debug( "\n PidD10822 = %i ", PidD10822);

                    /* - Payload Control System Calibration Weight [1]*/
	            PidD009A7 = (unsigned_16) CONVERT_TO_PT001_RES(WeighParam.CalWt);
	            if(LPS_SA_WEIGH_SYSTEM_UNCALIBRATED == WeighParam.CalStat)
	            {
	                PidD009A7 = UNKNOWN2U + FMICNM;
	            }
	            getLogger().log_debug( "\n PidD009A7 = %i ", PidD009A7);
	            
                    /* - Loader Bucket Payload Target Weight [1]*/
                    PidD009F5 = (unsigned_16) CONVERT_TO_PT1_RES(WeighParam.PidData.LoaderBktPloadTgtWt);
	            getLogger().log_debug( "\n PidD009F5 = %i ", PidD009F5);

                    /*Payload System Calibration Weight Entry Requirement Status*/
	            PidD109A5 = (unsigned_16) WeighParam.PidData.PloadSysCalWtEntryReqStat;
	            getLogger().log_debug( "\n PidD109A5 = %i ", PidD109A5);
	            
                    /*Payload System Zero Requirement Status*/
                    PidD10933 = (unsigned_16) zeroReqStat[WeighParam.PidData.PloadSysZeroReqStat];
	            getLogger().log_debug( "\n WeighParam.PidData.PloadSysZeroReqStat = %d ", WeighParam.PidData.PloadSysZeroReqStat);
	            
                    PidD00D67 = (unsigned_16) CONVERT_TO_PT1_RES(WeighParam.PidData.LoaderBktPloadTgtWtPer);
	            if(WeighParam.PidData.LoaderBktPloadTgtWtPer > 100)
	            {
	                PidD00D67 = UNKNOWN2U + FMICNM;
	            }

	            getLogger().log_debug( "\n PidD00D67 = %i ", PidD00D67);

	            LiftCylinderVelocity_val = (int_16)WeighParam.CalParam.LiftCylVel;
	            
                    /*Production Measurement Loading Status [-75716]*/
                    /*Bucket Payload Data*/
	            PidF2C6 = (unsigned_8) WeighParam.PidData.BktPayloadData;
	            getLogger().log_debug( "\n PidF2C6 = %x ", PidF2C6);

                    /*Bucket Payload*/
                    PidD00C8D = (int_16)CONVERT_TO_PT01_RES(WeighParam.BestBktWtInTonnes);
	            if(NOT_AVAILABLE == WeighParam.PidData.BktPayloadData)
	            {
	                PidD00C8D = UNKNOWN2S + FMI14;
	            }
	            getLogger().log_debug( "\n PidD00C8D = %i ", PidD00C8D);

	            NewLpsSaWeighScsTxIn_ = 1;
	        }
	    }
	}
}

void AutonomyConditionDiagnostics::ReadJobMgrAppScsTx()
{
	unsigned short int PayLoadOperModePIDMap[5] = {0x0346,0x0009,0x034F,0x00AF,0x034E};
	unsigned short int TipOffConfPIDMap[3]={TIP_OFF_AUTO,TIP_OFF_MANUAL, TIP_OFF_DISABLED};
	unsigned short int TipOffModPIDMap[3]={TIP_OFF_PILE,TIP_OFF_TRUCK,TIP_OFF_DISABLED};

	LpsSaJobMgrTxChannel JobMgrParam;

	if ( LpsSaJobMgrScsTxIn)
	{
		while(LpsSaJobMgrScsTxIn->get( JobMgrParam ))
		{

			PidFCF8 = ((unsigned_32) JobMgrParam.LifetimeTotalPayload + 0.5);/* Adding 0.5 to truncate the float to nearest rounded integer */
			PidFC06 = JobMgrParam.LifetimeTruckLoadCount;
			PidFCF7 = JobMgrParam.LifetimePayloadPassCount;

			PidFD39 = (unsigned_32) CONVERT_TO_PT001_RES(JobMgrParam.TruckWeight) ;/*Weigh Cycle Total Truck Payload*/
			getLogger().log_debug( "\n PidFD39 = %i ", PidFD39);
			PidFE2E = (int_32) CONVERT_TO_PT001_RES(JobMgrParam.TargetWeight);/*Remaining Payload to Load*/
			getLogger().log_debug( "\n PidFE2E = %i ", PidFE2E);
			PidFD38 = (unsigned_32) (PidFD39 + PidFE2E);// CONVERT_TO_PT001_RES(JobMgrParam.TargetWeight + JobMgrParam.TruckWeight);/*Truck Payload Target Weight*/
			getLogger().log_debug( "\n PidFD38 = %i ", PidFD38);
			Pid00D00BD3 = JobMgrParam.PassCount;/*Load Cycle Pass Count*/
			getLogger().log_debug( "\n Pid00D00BD3 = %i ", Pid00D00BD3);
			PidD10748  = (unsigned_16) PayLoadOperModePIDMap[JobMgrParam.OperationMode];/*Payload Operating Mode*/
			getLogger().log_debug( "\n PidD10748 = %x ", PidD10748);

			/*Loader Payload State*/
			PidD10972 = (unsigned_16) JobMgrParam.ReqPloadCtrlSysStat;/*Requested Payload Control System Status*/
			getLogger().log_debug( "\n PidD10972 = %x ", PidD10972);

			if(LPS_SA_JOB_MGR_CLEAR_BTN_ENABLED == JobMgrParam.ClearMinusOneEnableStat)
			{
				PidD10FAD = (unsigned_16) MINUS_ONE_DISABLED ;
				PidD10FAC = (unsigned_16) CLEAR_BUTTON_ENABLED;/* Payload Clear Button Display Status */
			}
			else
			{
				PidD10FAD = (unsigned_16) MINUS_ONE_ENABLED ;
				PidD10FAC = (unsigned_16) CLEAR_BUTTON_DISABLED ;/* Payload Clear Button Display Status */

			}
			getLogger().log_debug( "\n PidD10FAC = %x ", PidD10FAC);
			getLogger().log_debug( "\n PidD10FAD = %x ", PidD10FAD);
			/*Configurable Parameters*/
			PidD10E4E = (unsigned_16) TipOffModPIDMap[JobMgrParam.TipOffStateCfg];/* - Tip-Off Mode [1] (RECM)*/
			getLogger().log_debug( "\n PidD10E4E = %x ", PidD10E4E);
			PidD112B2 = (unsigned_16) TipOffConfPIDMap[JobMgrParam.TipOffTriggerType];
			getLogger().log_debug( "\n PidD112B2 = %x ", PidD112B2);
			PidD106C4 = (unsigned_16) JobMgrParam.HornStoreState;
		}
	}
}

void AutonomyConditionDiagnostics::ReadStoreSwitchTx(void)
{
	SwitchInputScs STG_Input;

	 while(LpsSaSwitchInput->get( STG_Input ))
		 {
			 if(STG_Input.get_STG_value(3) == STG::CLOSED)
			 {
				 PidF1AA = 0x01; /* Store Switch is depressed */
			 }
			 else
			 {
				 PidF1AA = 0x00; /* Store Switch is released  */
			 }
		 }
}


/********************************************************************************
FUNCTION NAME:
DESCRIPTION:
PARAMETER DESCRIPTION: No parameter
RETURN VALUE: void
*******************************************************************************/
void AutonomyConditionDiagnostics::ReadFromUITx()
{
	if(LpsSaUIAppTxIn)
		{

         LpsSaUIAppTxChannel TxIn;
			while(LpsSaUIAppTxIn->get( TxIn ))
			{
				LOG_INFO( "\n TxIn.PidTable.PidD0022C_DispLangStat %x\n", TxIn.PidTable.PidD0022C_DispLangStat);
				LOG_INFO( "\n TxIn.PidTable.PidD00144_ServModEnCode %d\n", TxIn.PidTable.PidD00144_ServModEnCode);
				LOG_INFO( "\n TxIn.PidTable.PidF25B_InfoUnitStat %d\n", TxIn.PidTable.PidF25B_InfoUnitStat);


				/* Read UI Tx channel */
				PidD0022C   = TxIn.PidTable.PidD0022C_DispLangStat;
				PidD00144 = TxIn.PidTable.PidD00144_ServModEnCode;
				PidF25B   = TxIn.PidTable.PidF25B_InfoUnitStat;
				LOG_INFO( "\n TxIn.PidTable.PidD0022C_DispLangStat %x\n", TxIn.PidTable.PidD0022C_DispLangStat);
				LOG_INFO( "\n TxIn.PidTable.PidD00144_ServModEnCode %d\n", TxIn.PidTable.PidD00144_ServModEnCode);
				LOG_INFO( "\n TxIn.PidTable.PidF25B_InfoUnitStat %d\n", TxIn.PidTable.PidF25B_InfoUnitStat);

			}
		}
}


/********************************************************************************
FUNCTION NAME:
DESCRIPTION:
PARAMETER DESCRIPTION: No parameter
RETURN VALUE: void
*******************************************************************************/
void AutonomyConditionDiagnostics::IssueCmdToUIApp()
{
	bool scsCmdRet;
	LpsSaUIAppReqChannel cmdOut;
	cmdOut.PidTable.PidD0022C_DispLangStat.ReqFlag = false;
	cmdOut.PidTable.PidD00144_ServModEnCode.ReqFlag = false;
	cmdOut.PidTable.PidF25B_InfoUnitStat.ReqFlag = false;
		/*Configurable Parameters*/
		/*Production Measurement Settings*/
		/* Issue command to UI through request channel */


	LOG_INFO( "\n PidWrD0022CFlag = %d ", PidWrD0022CFlag);
	LOG_INFO( "\n PidWrD00144Flag = %d ", PidWrD00144Flag);
	LOG_INFO( "\n PidWrF25BFlag = %d ", PidWrF25BFlag);
		if(PidWrD0022CFlag)
		{
			cmdOut.PidTable.PidD0022C_DispLangStat.ReqFlag = true;
			PidWrD0022CFlag = false;
			cmdOut.PidTable.PidD0022C_DispLangStat.ReqVal = PidWrD0022C;
			LOG_INFO("\ncmdOut.PidTable.PidD0022C_DispLangStat.ReqVal = %x\n", cmdOut.PidTable.PidD0022C_DispLangStat.ReqVal);
			LOG_INFO("\ncmdOut.PidTable.PidD0022C_DispLangStat.ReqFlag = %d \n", cmdOut.PidTable.PidD0022C_DispLangStat.ReqFlag);

		}
		else if(PidWrD00144Flag)
		{
			cmdOut.PidTable.PidD00144_ServModEnCode.ReqFlag = true;
			PidWrD00144Flag = false;
			cmdOut.PidTable.PidD00144_ServModEnCode.ReqVal = PidWrD00144;
			LOG_INFO("\ncmdOut.PidTable.PidD00144_ServModEnCode.ReqVal = %d\n", cmdOut.PidTable.PidD00144_ServModEnCode.ReqVal);
			LOG_INFO("\ncmdOut.PidTable.PidD00144_ServModEnCode.ReqFlag  = %d\n", cmdOut.PidTable.PidD00144_ServModEnCode.ReqFlag );

		}
		else if(PidWrF25BFlag)
		{
			cmdOut.PidTable.PidF25B_InfoUnitStat.ReqFlag = true;
			PidWrF25BFlag = false;
			cmdOut.PidTable.PidF25B_InfoUnitStat.ReqVal = PidWrF25B;
			LOG_INFO("\ncmdOut.PidTable.PidF25B_InfoUnitStat.ReqVal = %x\n", cmdOut.PidTable.PidF25B_InfoUnitStat.ReqVal);

			LOG_INFO("\ncmdOut.PidTable.PidF25B_InfoUnitStat.ReqFlag = %d \n", cmdOut.PidTable.PidF25B_InfoUnitStat.ReqFlag);
					}

		else
		{
			/* Do nothing */
		}

		scsCmdRet = LpsSaUIAppReqOut->publish(cmdOut);
		LOG_INFO( "\n Line no = %d,'IssueCmdToUIApp' function return code = %d " );

}


///////////////////////////////////////////////////////////////////////////////
/// @brief Cleanup for the AutonomyConditionDiagnostics
///////////////////////////////////////////////////////////////////////////////
void AutonomyConditionDiagnostics::autonomyCleanup( )
{
   LOG_INFO( "AutonomyConditionDiagnostics::cleanup" );
}
