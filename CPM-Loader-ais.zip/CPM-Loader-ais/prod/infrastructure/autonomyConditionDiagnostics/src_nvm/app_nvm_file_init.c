/******************************************************************************************************************
 Copyright 2011 - 2015 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------------------------------------------
File name: app_nvm_file_init.c

Description:This file contains startup and initialization code for nvm_file
******************************************************************************************************************/

#ifndef __APP_NVM_FILE_INIT_H__
#include "app_nvm_file_init.h"
#endif

#ifndef __APP_NVM_FILE_CFG_H__
#include "app_nvm_file_cfg.h"
#endif

//#include <string.h>
//#include <stdlib.h>
//#include <sys/stat.h>
//#include <unistd.h>
//#include <sys/types.h>

#include "../src_j1939/app_j1939_map.h"
//struct stat nvm ={0};
/******************************************************************************************************************
Function name: app_nvm_file_init

Description:  
Intialzie the nvm_file. 

Parameter Description: 
    
Return Description:     
    None
*****************************************************************************************************************/
void app_nvm_file_init(void)
{
    int indx;

    if(NVM_SUCCESS == nvm_file_init(nvm_file_block_size))
    {
        for(indx = 0; indx < nvm_file_block_size; indx++)
        {
            if(NVM_SUCCESS == nvm_file_block_cfg(&app_nvm_file_cfg[indx]))
            {
                if(NVM_SUCCESS == nvm_block_init(
                        NVM_BLOCK_UNCACHED,              /* block_type, not used for nvm_file */
                        NULL,                            /* block_cache_ptr, not used for nvm_file */
                        app_nvm_file_cfg[indx].data_id,              /* unique data id */
                        0,                               /* priority, not used for nvm_file */
                        &app_nvm_file_block_table[indx]))
                {
                    printf("nvm_block_init %d success\n", indx);
                }
                else
                {
                    printf("nvm_block_init %d failed\n", indx);
                }
            }
            else
            {
                printf("nvm_file_block_cfg  %d failed\n", indx);
            }
        }
    }
    else
    {
        printf("nvm_file_init failed\n");
    }

    return;
}

void app_nvm_file_update(void)
{
	uint_least8_t read_buffer[8];
    memset(read_buffer, 0, 8);

	if(NVM_SUCCESS == nvm_block_read(
		    app_nvm_file_block_table[6],	   /* reference handle to access block*/
			8,	   /* size of data block to read      */
			0,	   /* offset into block to be read    */
			read_buffer,  /* pointer to destination buffer   */
			0))  /* priority */
	{
		if(memcmp(read_buffer, pidF82D_pdata, 8) != 0)
		{
			memcpy(pidF82D_pdata, read_buffer, 8);
		}
	}
}
