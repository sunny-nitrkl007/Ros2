/*******************************************************************************
 Copyright 2011-2016 Caterpillar Inc. All rights reserved.
--------------------------------------------------------------------------------
File name: app_nvm_file_cfg.h

Description:This file contains the nvm_file configuration details
*******************************************************************************/

#ifndef __APP_NVM_FILE_CFG_H__
#define __APP_NVM_FILE_CFG_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <nvm.h>
#include <nvm_data_id_defs.h>
#include "app_flags.h"

/* Number of nvm file blocks */
extern int nvm_file_block_size;
extern nvm_file_block_cfg_t* app_nvm_file_cfg;

/* NVM file block handles */
extern NVM_block_handle_t app_nvm_file_block_table[];
#ifdef __cplusplus
}
#endif

#endif /* __APP_NVM_FILE_CFG_H__ */
