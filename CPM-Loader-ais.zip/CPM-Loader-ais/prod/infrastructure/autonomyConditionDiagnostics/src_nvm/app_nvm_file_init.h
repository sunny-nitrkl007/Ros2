/******************************************************************************************************************
 Copyright 2011 - 2012 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------------------------------------------
File name: app_nvm_file_init.h

Description:This file contains startup and initialization code for nvm_file
******************************************************************************************************************/

#ifndef __APP_NVM_FILE_INIT_H__
#define __APP_NVM_FILE_INIT_H__

#include "app_nvm_file_cfg.h"
#include <oel_assert.h>
#include "app_nvm_globals.h"

void app_nvm_file_init(void);
void app_nvm_file_update(void);

#endif /* __APP_NVM_FILE_INIT_H__ */
