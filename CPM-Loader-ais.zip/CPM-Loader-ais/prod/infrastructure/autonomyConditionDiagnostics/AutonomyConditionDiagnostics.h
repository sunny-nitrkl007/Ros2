///////////////////////////////////////////////////////////////////////////////
// @attention COPYRIGHT (C) 2011-2011 CATERPILLAR INC. ALL RIGHTS RESERVED.
//
// @file    AutonomyConditionDiagnostics.h
//
// @brief   This is the definition include file for the module.
///////////////////////////////////////////////////////////////////////////////
#ifndef AUTONOMYCONDITIONDIAGNOSTICS_H_
#define AUTONOMYCONDITIONDIAGNOSTICS_H_

///////////////////////////////////////////////////////////////////////////////
// -- #Include's --
///////////////////////////////////////////////////////////////////////////////
#include "task/AutonomyTask.h"
#include <ais/time/TimeStamp.h>
#include <ais/time/EventTimer.h>
#include <ais/interfaces/AutonomyConditionMessage/InterfaceTypes.h>
#include <interfaces/DiagnosticStatus/InterfaceTypes.h>
#include <interfaces/ShmClock/InterfaceTypes.h>
#include <task/commTask/commTask.h>
#include "AutoDiagEvent.h"
#include "AutonomyConditionsList.h"
#include "InhibitConditionList.h"
#include "DiagOutFileWriter.h"

#include <ais/interfaces/SystemHardwareHealth/InterfaceTypes.h>
#include <interfaces/AisJhm2TxChannel/InterfaceTypes.h>
#include "ais/time/EventTimer.h"
#include <scl_prmsw.h>
#include <interfaces/SEAStatus/InterfaceTypes.h>
#include <AcdCalScsInf.h>
#include <interfaces/LpsSaWeighReqstChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighRespChannel/InterfaceTypes.h>
#include <interfaces/LpsSaWeighTxChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrTxChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrReqstChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrRespChannel/InterfaceTypes.h>
#include <interfaces/LpsSaUIAppTxChannel/InterfaceTypes.h>
#include <interfaces/LpsSaUIAppRespChannel/InterfaceTypes.h>
#include <interfaces/LpsSaUIAppReqChannel/InterfaceTypes.h>
#include <interfaces/SwitchInputScs/InterfaceTypes.h>


///////////////////////////////////////////////////////////////////////////////
// -- #Define, Struct's, Typedef's, Enum's --
///////////////////////////////////////////////////////////////////////////////

#define  PidD00C8DDSI  (0x801F)
#define  PidFE2EDSI  (0x8000001F)
#define  Pid0045DSI  (0x801F)
#define PidD01B24DSI  (0x801F)
#define NONE_AVAILABLE  (0xFF)

#define CONVERT_TO_PT01_RES(value)	((value/0.01) + 0.5)
#define CONVERT_TO_PT1_RES(value)	((value/0.1) + 0.5)
#define CONVERT_TO_PT001_RES(value)	((value/0.001) + 0.5)

#define DIV_BY_10(value)	(value/10)
#define DIV_BY_100(value)	(value/100)
#define DIV_BY_1000(value)	(value/1000)

#define CONV_TO_BE_16(val)	( (((val) >> 8) & 0x00FF) | (((val) << 8) & 0xFF00) )

typedef enum
{
	TIP_OFF_TRUCK = 0x0581,
	TIP_OFF_PILE = 0x0582,
	TIP_OFF_DISABLED = 0x000D,
	TIP_OFF_MANUAL = 0x0070,
	TIP_OFF_AUTO = 0x00D7
}TipOff_t;

typedef enum
{
	MINUS_ONE_ENABLED = 0x000C,
	MINUS_ONE_DISABLED = 0x000D
}PloadRemLastPassButtonDispStat_t;

typedef enum
{
	CLEAR_BUTTON_ENABLED = 0x000C,
	CLEAR_BUTTON_DISABLED = 0x000D
}PloadClrButtonDispStat_t;

///////////////////////////////////////////////////////////////////////////////
// -- Class Definition
///////////////////////////////////////////////////////////////////////////////
class AutonomyConditionDiagnostics: public task::AutonomyTask, public commTask,LpsSaWeighReqstChannelStorage,LpsSaWeighRespChannelStorage
{
   public:
      AutonomyConditionDiagnostics( const std::string& taskName );
      virtual ~AutonomyConditionDiagnostics( );

  		virtual bool autonomyInitialize(void);
	  	virtual bool autonomyExecutive(void);
	  	virtual void autonomyCleanup(void);

   protected:

   private:
      bool initializeScsChannels( );
      bool initDiagEvent( scl_ci_es_fault_cfg_eddt_t* logConfig, AutoDiagEvent::DiagEventType type, const std::string& name );
      bool initializeAutoGenDiagEvents( );
      bool initializeDiagEvents( );
      bool initializeEDDT( );
      bool acceptedHost(const std::string& thisHostName) const;
      int  getDiagEvent( const std::string& name );
      void processHardwareHealthStatus();
      void processDispBrightness();
      //NVM Testing - Diagnostic Control
      void diagnosticControl(void);
      void postInitialize();
      bool getRTCconfig();
      bool getEcmJ1939Name();
      bool loadSEAconfig();
      bool loadNVMconfig();
      void publishSEAStatus();
      void publishSHM();
	  void IssueCmdToWeighApp(void);
      void CheckForWeighAppCmdResp(void);
      void ReadWeighAppScsTx(void);
      void ReadStoreSwitchTx(void);
      void ReadFromUITx();
      void IssueCmdToUIApp();
      void ReadJobMgrAppScsTx();
      void IssueCmdToJobMgrApp(void);
      void CheckForJobMgrAppCmdResp(void);	
      void ReadSystemParam(void);
      //Configuration

      bool                            m_enableOutfileWriter;       // Whether or not to write diagnostic details to output file.
      bool                            m_EDDT_init;

      //SCS Channels
      AutonomyConditionMessageInput*  m_pAutonomyConditionMessageIn; // Input SCS channel to receive Conditions
      DiagnosticStatusOutput*         m_pDiagStatusOut;            // Output SCS channel for DiagnosticStatus
      SystemHardwareHealthInput*      m_pHealthInput;
      AisJhm2TxChannelInput*          m_pDispBrightness;             // Input SCS channel to receive DispBrightness from UI

      ShmClockOutput*                 m_pSHMOutput;

      //Internal State
      std::vector<std::string>        m_hostnameWhiteList;         // List of hosts to listen to conditions from
      bool                            m_useHostnameWhiteList;      // True if the hostnames should be checked against the whitelist/false otherwise
      std::vector<AutoDiagEvent>      m_diagEventList;             // List of configured Diagnostics/Events
      AutonomyConditionsList          m_autoCondList;              // Combined list of all incoming autonomyConditions
      InhibitConditionList            m_inhibitList;               // Entire list of available inhibit conditions
      DiagOutFileWriter               m_outfileWriter;             // Writer to send information to diagnostic output file

      //NVM Testing - Diagnostic Control
//      EventTimer                      m_delayTimer;                // To set time interval for diagnostics - NVM Testing
//      bool                            m_enable;                    // Enabled to make the Diagnostic Active, Disabled otherwise
      bool                            m_initDone;
      EventTimer                      m_seaStatusTimer;
      SEAStatusOutput*                m_seaStatusOutput;
      SEAStatus                       m_seaStatus;
      EventTimer                      m_shmPublishTimer;
	  LpsSaWeighTxChannelInput    	  *LpsSaWeighScsTxIn;
	  LpsSaJobMgrTxChannelInput    	  *LpsSaJobMgrScsTxIn;
	  LpsSaWeighReqstChannelOutput    *LpsSaWeighScsReqstOut;/*Send request to Weigh App*/
	  LpsSaJobMgrReqstChannelOutput   *LpsSaJobMgrScsReqstOut;/*get request from UI*/
	  LpsSaJobMgrRespChannelInput     *LpsSaJobMgrScsRespIn;/*setRes to UI*/
	  LpsSaWeighRespChannelInput      *LpsSaWeighScsRespIn;/*Receive response from Weigh App*/
	  SwitchInputScsInput 		      *LpsSaSwitchInput; /* Receive Store switch input */
	  LpsSaUIAppTxChannelInput* 	  LpsSaUIAppTxIn;
	  LpsSaUIAppReqChannelOutput* 	  LpsSaUIAppReqOut;
	  LpsSaUIAppRespChannelInput* 	  LpsSaUIAppRespIn;
};

#endif //AUTONOMYCONDITIONDIAGNOSTICS_H_
