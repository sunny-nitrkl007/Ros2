/******************************************************************************************************************
 Copyright 2008 Caterpillar Inc. All rights reserved.
 -------------------------------------------------------------------------------------------------------------------
 File name: app_scl_fps_j1939_config.h

Description:    This file contains the public interface to scl_fps.
 ******************************************************************************************************************/
#ifndef APP_SCL_FPS_CONFIG_H_
#define APP_SCL_FPS_CONFIG_H_

#ifdef __cplusplus
extern "C"
{
#endif
#include <oel_rtos_posix.h>
#include <std_t.h>
#include <scl_fps.h>
#include <oel_rtos.h>
#include <scl_j1939.h>

#define OPEN_RC_MAX 16

    extern scl_fps_cfg_t app_scl_fps_config;
    extern const scl_fps_rc_cfg_t app_scl_fps_rc_5_config;
    extern const void* scl_fps_key_context;

    extern const oel_rtos_resource_config_t *scl_fps_resource_config;
    extern void fps_auth_data(void* context,scl_fps_auth_data_t* auth_data, scl_fps_rc_cfg_t* rc_cfg);

    extern uint_least8_t app_comp_id_length;
    extern uint_least8_t app_product_id_length;
    extern scl_fps_data_quality_t app_comp_id_data_quality;
    extern scl_fps_data_quality_t app_product_id_data_quality;

#ifdef __cplusplus
}
#endif
#endif /* #ifndef APP_SCL_FPS_CONFIG_H_ */
