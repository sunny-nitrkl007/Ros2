/*******************************************************************************
 ***
 *** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 *** %%                                                                        %%
 *** %%  COPYRIGHT (C) 2001 CATERPILLAR INC.   ALL RIGHTS RESERVED.            %%
 *** %%      This work contains proprietary information which may              %%
 *** %%      constitute a trade secret and/or be confidential.                 %%
 *** %%                                                                        %%
 *** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 ***
 ***
 *** DESCRIPTION :
 ***   Header file for application module global data.
 ***
 *** LANGUAGE :
 ***    ANSI C
 ***
 *** NOTES:
 ***
 *** MACRO LIST:
 ***
 *** HISTORY:
 ***   29MAR95 AGVerheyen - new code
 ***
 *******************************************************************************/
#ifndef __APP_FPS_SUPT_MOD_H__
#define __APP_FPS_SUPT_MOD_H__

#include <cat_std_types.h>
#include <scl_j1939_struct.h>
#include <scl_fps.h>
#include <string.h>

#define RC_1_FLS_FTS          1
#define RC_2_CUST_PASSWORD    2
#define RC_4_TOTALS           4
#define RC_9_ENG_SER_NUM      9
#define RC_127_CCP_READ       127

/* Reason Codes supported by this application 

$D0 $1294	Full Load and Full Torque Setting (RC1)
   - Supports From and To Value Tracking
   - One Change per Authorization

0xF829 - Customer Password #1 (RC2)
0xF82A - Customer Password #2 (RC2)
   - No From and To Value Tracking
   - One Change per PID (Must only allow one program per PID per Authorization)

0xFC21 - Total Idle Time (RC4)
0x00C8 - Total Fuel  (RC4)
   - No From and To Value Tracking
   - Unlimited changes until the connection is lost

0xF810 - Engine Serial Num (RC9)
   - No From and To Value Tracking
   - One Change per Authorization

0x00D1097A - CCP Read Security  (RC127)
   - Supports From and To Value Tracking
   - One Change per Authorization

 */

typedef struct test_key_info_s {
    uint_least16_t amid;
    uint_least16_t alg_id;
    uint_least16_t key_id;
    uint_least16_t key_len;
    const uint_least8_t *key_material;
}test_key_info_t;  /* scl_crypto_key_info_t */


uint_least16_t app_fps_rc_1_token_callbk(void *context, uint_least16_t reason_code);
uint_least16_t app_fps_rc_2_token_callbk(void *context, uint_least16_t reason_code);
uint_least16_t app_fps_rc_4_token_callbk(void *context, uint_least16_t reason_code);
uint_least16_t app_fps_rc_9_token_callbk(void *context, uint_least16_t reason_code);
uint_least16_t app_fps_rc_127_token_callbk(void *context, uint_least16_t reason_code);

extern scl_fps_rc_cfg_t app_scl_fps_rc_1_config;
extern scl_fps_rc_cfg_t app_scl_fps_rc_2_config;
extern scl_fps_rc_cfg_t app_scl_fps_rc_4_config;
extern scl_fps_rc_cfg_t app_scl_fps_rc_9_config;
extern scl_fps_rc_cfg_t app_scl_fps_rc_127_config;

extern uint_least16_t rc_1_feature_token;
extern uint_least16_t rc_2_feature_token;
extern uint_least16_t rc_4_feature_token;
extern uint_least16_t rc_9_feature_token;
extern uint_least16_t rc_127_feature_token;

bool_t format_todata_rc9
(
    void *context,
    uint_least16_t reason_code,
    scl_fps_data_id_type_t data_id_type,
    uint_least32_t data_id,
    uint_least8_t data_len,
    uint_least8_t* data,
    scl_fps_parameter_t* format_data
);

bool_t get_fromdata_rc9
(
    void *context,
    uint_least16_t reason_code,
    scl_fps_data_id_type_t data_id_type,
    uint_least32_t data_id,
    scl_fps_parameter_t* parm
);

bool_t format_todata_rc1
(
    void *context,
    uint_least16_t reason_code,
    scl_fps_data_id_type_t data_id_type,
    uint_least32_t data_id,
    uint_least8_t data_len,
    const uint_least8_t* data,
    scl_fps_parameter_t* format_data
);

bool_t get_fromdata_rc1
(
    void *context,
    uint_least16_t reason_code,
    scl_fps_data_id_type_t data_id_type,
    uint_least32_t data_id,
    scl_fps_parameter_t* parm
);

bool_t format_todata_rc127
(
    void *context,
    uint_least16_t reason_code,
    scl_fps_data_id_type_t data_id_type,
    uint_least32_t data_id,
    uint_least8_t data_len,
    const uint_least8_t* data,
    scl_fps_parameter_t* format_data
);

bool_t get_fromdata_rc127
(
    void *context,
    uint_least16_t reason_code,
    scl_fps_data_id_type_t data_id_type,
    uint_least32_t data_id,
    scl_fps_parameter_t* parm
);

extern void app_fps_add_rc_cfgs( void );



#endif /* __APP_FPS_SUPT_MOD_H__ */
