/*******************************************************************************
Copyright 2015 Caterpillar Inc.  All rights reserved.
--------------------------------------------------------------------------------

Filename:   app_scl_obd_es_config.c

Description
This file contains all the configuration information needed by the OBD event
system.

*******************************************************************************/

#include "app_scl_obd_es_config.h"

#include "../src_nvm/app_nvm_globals.h"
#include "../src_nvm/app_nvm_file_cfg.h"

#include "LoaderdiagnosticEventConfig/Loader_autonomy_diagnostics_config.h"
#include "LoaderdiagnosticEventConfig/Loader_autonomy_event_config.h"
//#include "diagnosticEventConfig/pose_autonomy_diagnostics_config.h"
//#include "diagnosticEventConfig/pose_autonomy_event_config.h"
#include "diagnosticEventConfig/auto_gen_diagnostics_config.h"
#include "diagnosticEventConfig/auto_gen_event_config.h"


#define  APP_POSE_AUTONOMY_DIAG_SCL_OBD_MAX_FAULTS  7
#define  APP_POSE_AUTONOMY_EVENT_SCL_OBD_MAX_FAULTS  4

#define  APP_SCL_OBD_MAX_FAULTS         APP_AUTONOMY_EVENT_SCL_OBD_MAX_FAULTS + \
                                        APP_AUTONOMY_DIAG_SCL_OBD_MAX_FAULTS +  \
                                        APP_AUTO_GEN_EVENT_SCL_OBD_MAX_FAULTS + \
                                        APP_AUTO_GEN_DIAG_SCL_OBD_MAX_FAULTS

#define  APP_SCL_OBD_MAX_FAULT_ENTRIES     20

//NVM RAM memory
unsigned_32  nvm_array[150];


uint_least8_t app_get_security_lvl(void);

/* overall configuration */
const scl_obd_es_config_t app_scl_obd_es_config =
{
   APP_SCL_OBD_MAX_FAULTS,
   20,                           /* evt_que_size */
   30,                           /* cont_fault_que_size */
   20,                           /* max_delays */
   40,                           /* max_annunc_entries */
   5,                            /* max_readiness_grps */
   5,                            /* max_subsc_fault_clear */
   5,                            /* max_subsc_fault_rep */
   APP_SCL_OBD_MAX_FAULT_ENTRIES,/* persistent_ready_list_size */
   20,                            /* persistent_fault_list_size */
   {                             /* persist_config */
      &app_nvm_file_block_table[0],                      /* nvm_block_handle */
      NULL,                 /* persistent_mem_ptr */
      0        /* persistent_mem_size */
   },
   SCL_OBD_ES_FEAT_USE_RTC,  /* persistent_features */
   1,                            /* min_active_drv_cycles */
   100,                          /* min_active_shm_time */
   10,                           /* auto_clear_warmup_cycles */
   100,                          /* auto_clear_shm_time */
   1,
   0,
   0                             /* auto_clear_extended_shm_time*/
};


/* J1939 Diagnostics Configuration */
const scl_diag_pj1939_config_t app_scl_diag_pj1939_config =
{
   20,
   APP_SCL_OBD_MAX_FAULTS,
   6,
   5,
   app_get_security_lvl,
   1
};

uint_least8_t app_get_security_lvl(void)
{
   return 1;
}

//void app_obd_get_security_lvl(uint_least8_t *security_lvl)
//{
//   *security_lvl = sec_lvl;
//}

