/*******************************************************************************
Copyright 2015 Caterpillar Inc.  All rights reserved.

--------------------------------------------------------------------------------	
Filename:   app_scl_obd_es_config.h

Description
This file contains configuration information for the OBD event system.	
*******************************************************************************/

#ifndef APP_SCL_OBD_ES_CONFIG_H_
#define APP_SCL_OBD_ES_CONFIG_H_

#include <scl_obd_es.h>
#include <scl_diag_pj1939.h>


extern const scl_obd_es_config_t         app_scl_obd_es_config;
extern const scl_diag_pj1939_config_t    app_scl_diag_pj1939_config;

extern scl_obd_es_t          *app_scl_obd_es;
extern scl_diag_pj1939_t     *app_pj1939_diag_obj;


#endif /* APP_SCL_OBD_ES_CONFIG_H_ */
