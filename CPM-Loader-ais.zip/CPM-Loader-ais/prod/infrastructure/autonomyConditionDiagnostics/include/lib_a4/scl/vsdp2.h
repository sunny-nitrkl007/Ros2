/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 2002 CATERPILLAR INC.   ALL RIGHTS RESERVED.            %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** $Source: .../vsdp2_proto.h,v $
***
*** DESCRIPTION : 
***
*** REQUIRED HEADER :
***
*** LANGUAGE :                  
***    ANSI C
***
*** COMPILE FLAGS :
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** FUNCTIONS CALLED:
***
*******************************************************************************/

#ifndef VSDP2_H_
#define VSDP2_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif

/*******************************************************************************
***
***    Data declared in this file
***    -- Global Symbols --
***
*******************************************************************************/

extern unsigned_32 * vsdp2_system_iterm;

/*******************************************************************************
***
***    Constants defined in this file
***    -- #Define's --
***
*******************************************************************************/

#define EOT        0x80000000 /* marker for end of state transition table */
#define EOT_STATE  0xFF
#define MAX_ITERMS 32

/**
*** ORI8 BIT_MASK,ADDRESS
**      - OR IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define vsdp2_SETSTBIT(sys_id, sys_iterm)\
{\
   (sys_iterm[sys_id/MAX_ITERMS] |= (1<<(sys_id%MAX_ITERMS) ) ); \
}\
   
/**
*** AND8 BIT_MASK,ADDRESS
**      - AND IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define vsdp2_CLRSTBIT(sys_id, sys_iterm)\
{\
   (sys_iterm[sys_id/MAX_ITERMS] &= (unsigned_32)(~(1<<(sys_id%MAX_ITERMS))));\
}\

/**
*** AND8 BIT_MASK,ADDRESS
**      - AND IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define vsdp2_CHKSTBIT(sys_id, local_itermbit, local_iterm, sys_iterm) \
{\
   if((sys_iterm[sys_id/MAX_ITERMS]) & (1<<(sys_id%MAX_ITERMS)))\
      {\
      local_iterm |= local_itermbit;\
      }\
}\


/**
*** ORI8 BIT_MASK,ADDRESS
**      - OR IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define SETSTBIT(id)\
{\
   (*(vsdp2_system_iterm + ((id/32)-1))) |= (1<<(id%32));\
}\
   
/**
*** AND8 BIT_MASK,ADDRESS
**      - AND IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define CLRSTBIT(id)\
{\
   (*(vsdp2_system_iterm + ((id/32)))) &= (unsigned_32)(~(1<<(id%32)));\
}\

/**
*** AND8 BIT_MASK,ADDRESS
**      - AND IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define CHKSTBIT(id,itermbit,iterm) \
{\
   if((*(vsdp2_system_iterm + ((id/32)))) & (1<<(id%32)))\
   {\
      iterm |= itermbit;\
   }\
}\

/** Generic iterm bit macros - 
*** b=bit location within a global iterm
*** i=iterm ptr (u32array) to a global iterm
*** m=local mask vsdp generated mask
*** l=local iterm vsdp generated iterm 			*/

/* iterm_STBIT returns a 1 if bit is set within a global iterm */
#define iterm_STBIT(b,i)		( ( *(i+(b>>5)) & (1<<(b%32)) ) ? 1 : 0 )

/* iterm_SETBIT sets a bit within a global iterm */
#define iterm_SETBIT(b,i)		( *(i+(b>>5)) |= (1<<(b%32)) )

/* iterm_CLRBIT clears a bit within a global iterm */
#define iterm_CLRBIT(b,i)		( *(i+(b>>5)) &= (~(1<<(b%32))) )

/* iterm_CHKBIT copies a bit from global iterm to local vsdp iterm */
#define iterm_CHKBIT(b,i,m,l)	( iterm_STBIT(b,i) ? (l |= m) : (l &= (~m)) )

typedef void vsdp2_action_t (void *, void *);

typedef struct
{
   unsigned_8 vsdp_present;    /* Present State */
   unsigned_8 vsdp_next;       /* Next State */
   unsigned_32 vsdp_bterm;     /* 32 Bit B-term */
   unsigned_32 vsdp_cterm;     /* 32 Bit C-term */
   vsdp2_action_t *vsdp_action; /* Pointer to action function */
   unsigned_16 vsdp_o1;        /* First offset */                        
   unsigned_16 vsdp_o2;        /* Second offset */                        
} vsdp2_stt_e;


unsigned_8 vsdp2_state_machine(unsigned_8 ps,
                               unsigned_32 I_term,
                               vsdp2_stt_e *tab,
                               void *p1,
                               void *p2
                              );


#ifdef __cplusplus
}
#endif

#endif /* VSDP2_H_ */
