/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 1997 CATERPILLAR INC.   ALL RIGHTS RESERVED.            %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
***
*** DESCRIPTION:
***    cdl2 mod macros.
***
*** REQUIRED HEADER:
***
*** LANGUAGE:                  
***    ANSI C
***
*** COMPILE FLAGS:
***
*** NOTES:
***
*** MACRO LIST:
***	CDL2_ADT_UPDATE_TX_DATA
***	CDL2_ADT_NEXT_SEQUENCE_NUM
***	CDL2_CBS_LOOP_UPDATE_DELAY
***	CDL2_CATLINK_BUFFER_FREE
***	CDL2_ASSIGN_SIZEOF_PARM_TYPE
***	CDL2_SET_RX_NOT_AVAILABLE
***
*** INTERRUPTS:
***
*******************************************************************************/
#ifndef CDL2_MOD_MACROS_H_
#define CDL2_MOD_MACROS_H_

#ifdef __cplusplus
extern "C" {
#endif

#define CDL2_ADT_UPDATE_TX_DATA( data, tx_pie, tx_hdlr )\
{  \
   tx_hdlr( (void *)tx_pie, (unsigned_8 *)&data);\
};

#define CDL2_ADT_NEXT_SEQUENCE_NUM(seqnum)   ( seqnum == CDL2_ADT_SEQUENCE_NUM_MASK ? (seqnum = 0) : seqnum++ )

#define CDL2_CBS_LOOP_UPDATE_DELAY(rate_ms)  ( (CDL2_CBS_UPDATES_PER_SECOND*(rate_ms)*4)/1000)   /* 4x number of loops passing before data update received */

/* Macro to decode the status of the cdl buffer */
#define CDL2_CATLINK_BUFFER_FREE(cdl_buf)  (cdl_tx_msg_stat(cdl_buf) < 3)   /* as defined in cdl_utils.c */


#define CDL2_ASSIGN_SIZEOF_PARM_TYPE( len, parameter_type) \
switch (parameter_type)\
{\
   case CDL2_U8_DSI:\
   case CDL2_I8_DSI:\
   case CDL2_U8_NO_DSI:\
   case CDL2_I8_NO_DSI:\
     len = 1;\
     break;\
   case CDL2_U16_DSI:\
   case CDL2_I16_DSI:\
   case CDL2_U16_NO_DSI:\
   case CDL2_I16_NO_DSI:\
     len = 2;\
     break;\
   case CDL2_U32_DSI:\
   case CDL2_I32_DSI:\
   case CDL2_U32_NO_DSI:\
   case CDL2_I32_NO_DSI:\
     len = 4;\
     break;\
   default:\
     len = 0xFF;\
     break;\
   /* Set to -1, this is unknown or variable length */\
};

#define CDL2_SET_RX_NOT_AVAILABLE(rxpit_index)  \
   cdl2_rx_data_pit[rxpit_index].receive_status = CDL2_RX_STATUS_NOT_AVAILABLE;

#ifdef __cplusplus
}
#endif

#endif /* __CDL2_MACROS_H__ */
