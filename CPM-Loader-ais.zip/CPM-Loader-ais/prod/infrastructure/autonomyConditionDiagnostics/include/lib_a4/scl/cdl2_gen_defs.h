/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 1999-2000 CATERPILLAR INC.   ALL RIGHTS RESERVED.       %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
***
*** DESCRIPTION:
***     Basic cdl2 definitions.
***
*** REQUIRED HEADER:
***
*** LANGUAGE:
***    ANSI C
***
*** COMPILE FLAGS:
***
*** NOTES:
***
*** FUNCTIONS:
***
*** INTERRUPTS:
***
*******************************************************************************/
#ifndef CDL2_GEN_DEFS_H_
#define CDL2_GEN_DEFS_H_

#ifdef __cplusplus
extern "C" {
#endif

#define CDL2_EXT_HDLR_OK    0   /* everything is okay */
#define CDL2_EXT_HDLR_ERR	1	/* error detected from the ext handler */

#define MAX_SVTEST_CAL_SUPDATA_SIZE  20 /* max number of optional inputs */
#define MAX_SVTEST_CAL_ERROR_LISTING  9 /* max number of error listings */

#define SVTEST_CAL_GET_REQ_PARAM_OK  0  /* there is new request */
#define SVTEST_CAL_NO_NEW_REQ_PARAM  1  /* no new request has arrived */

#define SVTEST_REQUEST_PID  0xF847      
#define SVTEST_RESPONSE_PID 0xF848

#define CALIBRATION_REQUEST_PID  0xF840
#define CALIBRATION_RESPONSE_PID 0xF841

#define CDL2_CBS_HDLR_OK    	0   	/* everything is okay */
#define CDL2_CBS_HDLR_ERR	1	/* error detected from the handler */

#define CDL2_GEN_DATALINK_VALUE_NOT_OVERRIDDEN	0
#define CDL2_GEN_DATALINK_VALUE_OVERRIDDEN		1

#ifdef __cplusplus
}
#endif

#endif /* CDL2_GEN_DEFS_H_ */
