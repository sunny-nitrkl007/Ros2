/*******************************************************************************
**
**   COPYRIGHT (C) 2012 CATERPILLAR INC.   ALL RIGHTS RESERVED.
**
*******************************************************************************/

#ifndef CAL_MGR_H_
#define CAL_MGR_H_

/*
**	--- Include's ---
*/
#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif

#ifndef VSDP_H_
#include <vsdp.h>			/* VSDP */
#endif

#ifndef CAL_PROTO_H_
#include <cal_proto.h>		/* CCM Prototypes */
#endif

#ifndef CAL_ITERM_H_
#include <cal_iterm.h>		/* CCM Iterm */
#endif


/**************************** PRIVATES *******************************/
/**************************** PRIVATES *******************************/
/**************************** PRIVATES *******************************/
/*
**	--- Private Defines ---
*/

/*
**	--- Private Enumerations ---
*/

/*
**	--- Private Typedefs ---
*/

/*
**	--- Private Structure/Union Tags ---
*/
typedef struct CAL_MGR_Cnfg_tag		CAL_MGR_Cnfg_t;
typedef struct CAL_MGR_CalOrSrv_tag	CAL_MGR_CalOrSrv_t;

/*
**	--- Private Proto-typedefs ---
*/


/*
**	--- Private Structures ---
*/

typedef struct {
	union {
		CAL_MGR_CalOrSrv_t	*cal;	/* Active Calibration Pointer or */
		CAL_MGR_CalOrSrv_t	*srv;	/* Active Service Mode Pointer */	
	} active;
	unsigned_8				*pstep;	/* Step Number sent to ET */
} CAL_MGR_Work_t;

/*
**	--- Private Unions ---
*/

/*
**	--- Private Globals ---
*/

/*
**	--- Private Macros ---
*/

/* These Macros should be included within the vsdp_macros.h */
/* Remove from here when identical macros are added to VSDP */
/* b = global iterm bit number (not a mask)
** i = global iterm POINTER
** m = local iterm mask
** l = local iterm (not a pointer)
*/
#ifdef iterm_STBIT
#undef iterm_STBIT
#undef iterm_SETBIT
#undef iterm_CLRBIT
#undef iterm_CHKBIT
#endif

#define iterm_STBIT(b,i)		( ( *((i)+((b)>>5)) & (1<<((b)%32)) ) ? 1 : 0 )
#define iterm_SETBIT(b,i)		( *((i)+((b)>>5)) |= (1<<((b)%32)) )
#define iterm_CLRBIT(b,i)		( *((i)+((b)>>5)) &= (~(1<<((b)%32))) )
#define iterm_CHKBIT(b,i,m,l)	( iterm_STBIT(b,i) ? ((l) |= (m)) : ((l) &= (~(m))) )

/*
**	--- Private Function Prototypes ---
*/

/*#include <cal_mod_proto.h>	 for Clearing Errors/Warnings */
extern void cal_init_err_warn( void );
extern unsigned_8 cal_get_action_cmd_u8(unsigned_8* u8_ptr);

/**************************** PUBLICS *******************************/
/**************************** PUBLICS *******************************/
/**************************** PUBLICS *******************************/
/*
**	--- Public Defines ---
*/

/******************* External Global declaration ********************/
/*Active Calibration Manager Configuration Pointer*/
extern const CAL_MGR_Cnfg_t *cmc;
/* Active Calibration Manager Workspace Pointer */
extern CAL_MGR_Work_t *cmw;
/* Calibration Manager flow table */
extern cal_flow_tbl_entry_t cal_mgr_flow_table[];

/*
**	--- Public Enumerations ---
*/

typedef enum {
	CAL_MGR_EW_ACTIVE_DIAGNOSTIC		= 0x0002
} CAL_MGR_EW_E;	/* Error/Warnings */

typedef enum {
	CAL_MGR_STAT_FAIL_W_ERRORS			= 0x01,
	CAL_MGR_STAT_SUCCESS				= 0x02,
	CAL_MGR_STAT_SUCCESS_W_WARNINGS		= 0x03
} CAL_MGR_STAT_E;	/* Calibration Statuses
					**	(used within last status report handlers)
					*/

typedef enum {

	/* CAL_MGR Main Commands (not shown on State Machine) */
	CAL_MGR_MC_INIT_LAST_STAT,	/* when calibration is enabled */
	CAL_MGR_MC_ADIAGCHK,		/* Active Diagnostic Checking */
	CAL_MGR_MC_GET_INPUTS,		/* Get Calibration Inputs */
	CAL_MGR_MC_SET_OUTPUTS,		/* Set Calibration Outputs */

	/* CAL_MGR Control Main Commands (straight from State Machine) */
	CAL_MGR_MC_INITIALIZE,		/* First calibration execution command */
	CAL_MGR_MC_SETUPCHK,
	CAL_MGR_MC_INIT_FLOW,
	CAL_MGR_MC_FLOW,
	CAL_MGR_MC_RESTART_FLOW,
	CAL_MGR_MC_EXIT_FLOW,
	CAL_MGR_MC_STOP,
	CAL_MGR_MC_QUIT,
	CAL_MGR_MC_TERMINATE,
	CAL_MGR_MC_CLEANUP,
	
	/* CAL_MGR Flow Main Commands (straight from State Machine) */
	CAL_MGR_MC_READY,
	CAL_MGR_MC_SAMPLE_INIT,
	CAL_MGR_MC_SAMPLE,
	CAL_MGR_MC_RESET_INIT,
	CAL_MGR_MC_RESET,
	CAL_MGR_MC_VALIDATE,
	CAL_MGR_MC_NEXT_PT,
	CAL_MGR_MC_SUCCESS,
	CAL_MGR_MC_DONE,
	CAL_MGR_MC_FAIL,
	
	
	/* Last CAL_MGR_CMD */
	CAL_MGR_MC_LAST_CMD		/* Use this value to build main/supt Command list from */

} CAL_MGR_MC_E;		/* Calibration Main Command */

typedef enum {

	/* General Main Response Values */
	CAL_MGR_MR_SUCCESS = 0,
	CAL_MGR_MR_FAIL,
	CAL_MGR_MR_SURE_WHATEVER 			= CAL_MGR_MR_SUCCESS,
	CAL_MGR_MR_NOT_SUPPORTED			= CAL_MGR_MR_FAIL,
	
	/* Main Response for CAL_MGR_MC_INIT_LAST_STAT */
	CAL_MGR_MR_INIT_LAST_STAT_OK		= CAL_MGR_MR_SUCCESS,	/* Exists & OK */
	CAL_MGR_MR_INIT_LAST_STAT_NA		= CAL_MGR_MR_SUCCESS,	/* Cal does not have last status report (Not Applicable) */
	CAL_MGR_MR_INIT_LAST_STAT_NOT_OK	= CAL_MGR_MR_FAIL,		/* Unable to init (Not OK) */
	CAL_MGR_MR_INIT_LAST_STAT_NS		= CAL_MGR_MR_FAIL,		/* Cal cannot support CAL_ID (Not Supported) */
	
	/* Main Response for CAL_MGR_MC_GET_INPUTS */
	CAL_MGR_MR_GET_INPUTS_OK			= CAL_MGR_MR_SUCCESS,	/* Inputs Acquired */
	CAL_MGR_MR_GET_INPUTS_NOT_OK		= CAL_MGR_MR_FAIL,		/* Inputs Not Acquired */
	
	/* Main Response for CAL_MGR_MC_SET_OUTPUTS */
	CAL_MGR_MR_SET_OUTPUTS_OK			= CAL_MGR_MR_SUCCESS,	/* Inputs Acquired */
	CAL_MGR_MR_SET_OUTPUTS_NOT_OK		= CAL_MGR_MR_FAIL,		/* Inputs Not Acquired */
	
	/* Main Response for CAL_MGR_MC_ADIAGCHK */
	CAL_MGR_MR_ADIAGCHK_OK				= CAL_MGR_MR_SUCCESS,	/* Not Active Diagnostics Present */
	CAL_MGR_MR_ADIAGCHK_NOT_OK			= CAL_MGR_MR_FAIL,		/* Active Diagnostics Present */
	
	/* Main Response for CAL_MGR_MC_INITIALIZE */
	CAL_MGR_MR_INITIALIZE_OK			= CAL_MGR_MR_SUCCESS,	/* Initialization is OK */
	CAL_MGR_MR_INITIALIZE_AGAIN			= CAL_MGR_MR_FAIL,		/* Continue to initialize */
	CAL_MGR_MR_INITIALIZE_NOT_OK,								/* Something did not initialize correctly */
	
	/* Main Response for CAL_MGR_MC_SETUPCHK */
	CAL_MGR_MR_SETUPCHK_OK				= CAL_MGR_MR_SUCCESS,	/* Setup conditions OK */
	CAL_MGR_MR_SETUPCHK_NOT_OK			= CAL_MGR_MR_FAIL,		/* Setup conditions Not OK */
	
	/* Main Response for CAL_MGR_MC_INIT_FLOW */
	CAL_MGR_MR_INIT_FLOW_OK				= CAL_MGR_MR_SURE_WHATEVER,
	
	/* Main Response for CAL_MGR_MC_INIT_LAST_STAT */
	CAL_MGR_MR_FLOW_OK					= CAL_MGR_MR_SUCCESS,	/* Flow Conditions for step number are OK */
	CAL_MGR_MR_FLOW_RESTART				= CAL_MGR_MR_FAIL,		/* Flow Conditions Not OK, restart Calibration */
	CAL_MGR_MR_FLOW_ABORT,										/* Flow Conditions Not OK, Abort Calibration */
	CAL_MGR_MR_FLOW_NONE,										/* Do not run the flow state machine */
	
	/* Main Response for CAL_MGR_MC_RESTART_FLOW */
	CAL_MGR_MR_RESTART_FLOW_OK 			= CAL_MGR_MR_SUCCESS,	/* Restart Flow Complete */
	CAL_MGR_MR_RESTART_FLOW_AGAIN		= CAL_MGR_MR_FAIL,		/* Continue to restart the calibration */
	
	/* Main Response for CAL_MGR_MC_EXIT_FLOW */
	CAL_MGR_MR_EXIT_FLOW_DONE			= CAL_MGR_MR_SUCCESS,	/* Machine is back in normal operation mode (no cleanup required) */
	CAL_MGR_MR_EXIT_FLOW_CLEANUP_REQ	= CAL_MGR_MR_FAIL,		/* Machine is in calibration operation mode (cleanup required) */
	
	/* Main Response for CAL_MGR_MC_STOP */
	CAL_MGR_MR_STOP_OK					= CAL_MGR_MR_SUCCESS,	/* Exit Flow Not Required */
	CAL_MGR_MR_STOP_EXIT_REQ			= CAL_MGR_MR_FAIL,		/* Exit Flow Required */
	
	/* Main Response for CAL_MGR_MC_QUIT */
	CAL_MGR_MR_QUIT_OK					= CAL_MGR_MR_SUCCESS,	/* Exit Flow Not Required */
	CAL_MGR_MR_QUIT_EXIT_REQ			= CAL_MGR_MR_FAIL,		/* Exit Flow Required */
	
	/* Main Response for CAL_MGR_MC_TERMINATE */
	CAL_MGR_MR_TERMINATE_OK				= CAL_MGR_MR_SUCCESS,	/* Exit Flow Not Required */
	CAL_MGR_MR_TERMINATE_EXIT_REQ		= CAL_MGR_MR_FAIL,		/* Exit Flow Required */
	
	/* Main Response for CAL_MGR_MC_CLEANUP */
	CAL_MGR_MR_CLEANUP_DONE				= CAL_MGR_MR_SUCCESS,	/* Cleanup is complete */
	CAL_MGR_MR_CLEANUP_NOT_DONE			= CAL_MGR_MR_FAIL,		/* Cleanup must continue */
	
	/* Main Response for CAL_MGR_MC_READY */
	CAL_MGR_MR_READY_YES				= CAL_MGR_MR_SUCCESS,	/* Machine is in a position to sample a point */
	CAL_MGR_MR_READY_NO					= CAL_MGR_MR_FAIL,		/* Machine is not in a position to sample a point */
	
	/* Main Response for CAL_MGR_MC_SAMPLE_INIT */
	CAL_MGR_MR_SAMPLE_INIT_OK			= CAL_MGR_MR_SURE_WHATEVER,
	
	/* Main Response for CAL_MGR_MC_SAMPLE */
	CAL_MGR_MR_SAMPLE_PT_COLLECTED		= CAL_MGR_MR_SUCCESS,	/* Proceed (Point Collected needs validation) */
	CAL_MGR_MR_SAMPLE_WAIT				= CAL_MGR_MR_FAIL,		/* Do not proceed */
	CAL_MGR_MR_SAMPLE_SKIP,										/* Proceed (No Point Collected or Collected point needs no validation) */
	
	/* Main Response for CAL_MGR_MC_RESET_INIT */
	CAL_MGR_MR_RESET_INIT_OK			= CAL_MGR_MR_SURE_WHATEVER,
	CAL_MGR_MR_RESET_INIT_NONE,									/* No Reset is needed */
	
	/* Main Response for CAL_MGR_MC_RESET */
	CAL_MGR_MR_RESET_DONE				= CAL_MGR_MR_SUCCESS,	/* Machine conditions are ok to move to next point */
	CAL_MGR_MR_RESET_NOT_DONE			= CAL_MGR_MR_FAIL,		/* Machine conditions are ok to move to next point */
	
	
	/* Main Response for CAL_MGR_MC_VALIDATE */
	CAL_MGR_MR_VALIDATE_OK				= CAL_MGR_MR_SUCCESS,	/* Collected sample is valid (proceed to next point) */
	CAL_MGR_MR_VALIDATE_NOT_OK			= CAL_MGR_MR_FAIL,		/* Collected sample is not valid (Terminate the calibration) */
	CAL_MGR_MR_VALIDATE_RESTART,
	
	/* Main Response for CAL_MGR_MC_NEXT_PT */
	CAL_MGR_MR_NEXT_PT_MORE				= CAL_MGR_MR_SUCCESS,	/* More samples to collect */
	CAL_MGR_MR_NEXT_PT_NO_MORE			= CAL_MGR_MR_FAIL,		/* No more samples to collect */
	
	/* Main Response for CAL_MGR_MC_SUCCESS */
	CAL_MGR_MR_SUCCESS_SAVED			= CAL_MGR_MR_SUCCESS,	/* Calibration Data has been saved */
	CAL_MGR_MR_SUCCESS_WAIT				= CAL_MGR_MR_FAIL,		/* Calibration is waiting for user input on
																**	how to save the data or main requires
																**	more time to save
																*/
	
	/* Main Response for CAL_MGR_MC_DONE */
	CAL_MGR_MR_DONE_OK					= CAL_MGR_MR_SURE_WHATEVER,
	CAL_MGR_MR_DONE_RESTART,									/* Calibration has chosen to restart */
	
	/* Main Response for CAL_MGR_MC_FAIL */
	CAL_MGR_MR_FAIL_OK					= CAL_MGR_MR_SURE_WHATEVER
	
	
} CAL_MGR_MR_E;			/* Calibration Main Response */


/*
**	--- Public Structure/Union Tags ---
*/

/*
**	--- Public Typedefs ---
*/
typedef CAL_MGR_CalOrSrv_t		CAL_MGR_Cal_t;
typedef CAL_MGR_CalOrSrv_t		CAL_MGR_Srv_t;

/*
**	--- Public Proto-typedefs ---
*/
typedef CAL_MGR_MR_E	(CAL_MGR_CalOrSrvMain_t)(	CAL_MGR_MC_E		cmd,
													CAL_MGR_Work_t		*cmw,
													const CAL_MGR_Cnfg_t		*cmc,
													CAL_MGR_CalOrSrv_t	*cal_or_srv );
typedef CAL_MGR_CalOrSrvMain_t	CAL_MGR_CalMain_t;
typedef CAL_MGR_CalOrSrvMain_t	CAL_MGR_SrvMain_t;
													
typedef unsigned_32	(CAL_MGR_CalOrSrvSupt_t)(	unsigned_32		cmd,
												CAL_MGR_Work_t		*cmw,
												CAL_MGR_Cnfg_t		*cmc,
												CAL_MGR_CalOrSrv_t	*cal_or_srv );
typedef CAL_MGR_CalOrSrvSupt_t	CAL_MGR_CalSupt_t;
typedef CAL_MGR_CalOrSrvSupt_t	CAL_MGR_SrvSupt_t;

/*
**	--- Public Structures ---
*/
struct CAL_MGR_CalOrSrv_tag {
	unsigned_16				id;		/* Calibration / Service Mode ID */
	CAL_MGR_CalOrSrvMain_t	*main;	/* Calibration / Service Mode Main Function Pointer */
	void					*work;	/* Calibration / Service Mode Specific Workspace */
	const void			*cnfg;	/* Calibration / Service Mode Specific Configuration */
};

struct CAL_MGR_Cnfg_tag {
	unsigned_16				cals;	/* Number of cals under control */
	CAL_MGR_Cal_t			*cal;	/* Available Calibration Array */
	
	unsigned_16				srvs;	/* Number of service modes under control */
	CAL_MGR_Srv_t			*srv;	/* Available Service Mode Array */
	
	cal_interface_init_t	*init;	/* CCM Interface Init */
	
};

typedef struct {
	CAL_MGR_Cal_t	cal;
	cal_last_stat_t	*stat;
} CAL_MGR_LStat_t;

/*
**	--- Public Unions ---
*/

/*
**	--- Public Globals ---
*/

/*
**	--- Public Macros ---
*/
/* Use this macro if the CAL_MGR_Workspace_Pointer is known
** or use cal_mgr_set_stepnumber() or cal_mgr_get_stepnumber() if needed
*/
#define CAL_MGR_STEPNUMBER( cmw ) (*((cmw)->pstep))

/* User inputs from cal_iterm */
#define CAL_MGR_KEY_CONT	(iterm_STBIT( CAL_KEY_CONT,		cal_iterm))
#define CAL_MGR_KEY_YES		(iterm_STBIT( CAL_KEY_YES,		cal_iterm))
#define CAL_MGR_KEY_NO		(iterm_STBIT( CAL_KEY_NO,		cal_iterm))
#define CAL_MGR_KEY_SAVE	(iterm_STBIT( CAL_CMD_SAVE,		cal_iterm))
#define CAL_MGR_KEY_PREV	(iterm_STBIT( CAL_CMD_REVPRE,	cal_iterm))
#define CAL_MGR_KEY_DFLT	(iterm_STBIT( CAL_CMD_REVDEF,	cal_iterm))
#define CAL_MGR_KEY_INCSM	(iterm_STBIT( CAL_KEY_INCSM,	cal_iterm))
#define CAL_MGR_KEY_INCLG	(iterm_STBIT( CAL_KEY_INCLG,	cal_iterm))
#define CAL_MGR_KEY_DECSM	(iterm_STBIT( CAL_KEY_DECSM,	cal_iterm))
#define CAL_MGR_KEY_DECLG	(iterm_STBIT( CAL_KEY_DECLG,	cal_iterm))

/* Return TRUE if a Button is pressed and update the button number @ unsigned_8 ptr. */
#define CAL_MGR_KEY_BTN_GET(U8_PTR)        ((iterm_STBIT( CAL_CMD_BTN_PRESS,  cal_iterm)) ? \
                                            ( cal_get_action_cmd_u8(U8_PTR)) : 0 \
                                           )

/* Return TRUE if a Check-box is selected and update the checkbox number @ unsigned_8 ptr. */
#define CAL_MGR_KEY_CBOX_SEL_GET(U8_PTR)   ((iterm_STBIT( CAL_CMD_CBOX_SEL,   cal_iterm)) ? \
                                            ( cal_get_action_cmd_u8(U8_PTR)) : 0 \
                                           )

/* Return TRUE if Check-box is un-checked and update the checkbox number @ unsigned_8 ptr. */
#define CAL_MGR_KEY_CBOX_DESEL_GET(U8_PTR) ((iterm_STBIT( CAL_CMD_CBOX_DESEL, cal_iterm)) ? \
                                            ( cal_get_action_cmd_u8(U8_PTR)) : 0 \
                                           )

/*
**	--- Public Function Prototypes ---
*/
/* Executables */
/* init for applications using cdl */
void cal_mgr_init(	CAL_MGR_Work_t	*work,  const CAL_MGR_Cnfg_t	*cnfg );
/* init for applications using scl_j1939 */
void cal_mgr_j1939_init(	CAL_MGR_Work_t	*work,  const CAL_MGR_Cnfg_t	*cnfg );
void cal_mgr_main(	CAL_MGR_Work_t	*work,	const CAL_MGR_Cnfg_t	*cnfg );

/* init for applications using both datalinks cdl and scl_j1939 */
void cal_mgr_cdl_j1939_init( CAL_MGR_Work_t *work, const CAL_MGR_Cnfg_t *cnfg );

/* Utilities */	
unsigned_8 cal_mgr_set_cal_cnfg( unsigned_16 id, const void *cnfg );

unsigned_8	cal_mgr_enable_cal( unsigned_16 cal_id );
unsigned_8	cal_mgr_enable_srv( unsigned_16 srv_id );
void		cal_mgr_disable_cal( unsigned_16 cal_id );
void		cal_mgr_disable_srv( unsigned_16 srv_id );

unsigned_8	cal_mgr_get_stepnumber( void );
void		cal_mgr_set_stepnumber( unsigned_8 sn );

CAL_MGR_CalOrSrv_t *cal_mgr_get_active_calorsrv( void );

void cal_mgr_clear_warnings( void );

/******************************************************************************
***
*** FUNCTION NAME: cal_mgr_add_cal()
***
*** DESCRIPTION:
*** This function is used to add a calibration in the calibration table
*** during run time
***
******************************************************************************/
unsigned_8 cal_mgr_add_cal(CAL_MGR_Cal_t *cal_mgr_cals);

/******************************************************************************
***
*** FUNCTION NAME: cal_mgr_add_srv()
***
*** DESCRIPTION:
*** This function is used to add a service mode in the service mode table
*** during run time
***
******************************************************************************/
unsigned_8 cal_mgr_add_srv(CAL_MGR_Srv_t *cal_mgr_srvs);

#endif /* CAL_MGR_H_ */
