/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 2000 CATERPILLAR INC.   ALL RIGHTS RESERVED.            %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** $Source: .../vsdp.h,v $
***
*** DESCRIPTION : 
***
*** REQUIRED HEADER :
***
*** LANGUAGE :                  
***    ANSI C
***
*** COMPILE FLAGS :
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** FUNCTIONS CALLED:
***
*******************************************************************************/
#ifndef VSDP_H_
#define VSDP_H_
#ifdef __cplusplus
extern "C" {
#endif

#ifndef VSDP_STRUCT_H_
#include <vsdp_struct.h>
#endif

#ifndef VSDP_PROTO_H_
#include <vsdp_proto.h>
#endif

#ifndef VSDP_DEFS_H_
#include <vsdp_defs.h>
#endif

#ifndef VSDP_MACROS_H_
#include <vsdp_macros.h>
#endif

#ifndef VSDP_GLOBALS_H_
#include <vsdp_globals.h>
#endif

#ifdef __cplusplus
}
#endif
#endif /* VSDP_H_ */

