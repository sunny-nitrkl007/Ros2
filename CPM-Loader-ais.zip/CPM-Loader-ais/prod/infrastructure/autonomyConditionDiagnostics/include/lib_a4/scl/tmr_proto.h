/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%    COPYRIGHT (C) 1994-1996 CATERPILLAR INC.   ALL RIGHTS RESERVED.     %%
*** %%         This work contains proprietary information which may           %%
*** %%           constitute a trade secret and/or be confidential.            %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** FILE:	tmr_proto.h
***
*** AUTHOR(S):	Michael A. Dvorsky
***
*** DESCRIPTION :
***	Header file for all timer function prototypes.
***
*** LANGUAGE :                  
***    ANSI C
***
*******************************************************************************/


#ifndef TMR_PROTO_H_
#define TMR_PROTO_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif
#ifndef TMR_STRUCT_H_
#include <tmr_struct.h>
#endif

/******************/
/* TMR PROTOTYPES */
/******************/

/* FUNCTIONDEF: tmr_main - Timer main routine */
extern void tmr_main(void);

/* FUNCTIONDEF: tmr_init - Timer initialization routine (tmr_main() every tick) */
extern void tmr_init(void);

/* FUNCTIONDEF: tmr_init2 - Timer initialization routine */
extern void tmr_init2(unsigned_16 ticks_per_loop);

/* FUNCTIONDEF: tmr_rept_init - Initialization of a repetitive timer */
extern void tmr_rept_init(TMR_rept_t *timer, int_32 tLow, int_32 tHigh);

/* FUNCTIONDEF: tmr_rept_square_init - Initialization of a square repetitive
   timer */
extern void tmr_rept_square_init(TMR_rept_t *timer, int_32 period);

/* FUNCTIONDEF: tmr_rept_change - Change high/low time of a repetitive timer */
extern void tmr_rept_change(TMR_rept_t *timer, int_32 tLow, int_32 tHigh);

/* FUNCTIONDEF: tmr_rept_square_change - Change period of a square repetitive
   timer */
extern void tmr_rept_square_change(TMR_rept_t *timer, int_32 period);

/* FUNCTIONDEF: tmr_rept_remove - Remove a repetitive timer */
extern void tmr_rept_remove(TMR_rept_t *timer);

/* FUNCTIONDEF: tmr_ss_init - Initialization of a single-shot timer */
extern void tmr_ss_init(TMR_ss_t *timer);

/* FUNCTIONDEF: tmr_ss_remove - Remove a single-shot timer */
extern void tmr_ss_remove(TMR_ss_t *timer);

/* FUNCTIONDEF: tmr_elapsed_init - Initialization of an elapsed timer */
extern void tmr_elapsed_init(TMR_elapsed_t *timer);

/* FUNCTIONDEF: tmr_elapsed_remove - Remove an elapsed timer */
extern void tmr_elapsed_remove(TMR_elapsed_t *timer);


#ifdef __cplusplus
}
#endif

#endif /* TMR_PROTO_H_ */
