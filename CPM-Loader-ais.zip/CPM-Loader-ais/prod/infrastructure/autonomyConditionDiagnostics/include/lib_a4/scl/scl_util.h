/******************************************************************************************************************
 Copyright 2011 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------------------------------------------
File name: scl_util.h

Description: 
             
******************************************************************************************************************/

#ifndef SCL_UTIL_H_
#define SCL_UTIL_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <std_t.h>

/*==============================================================================
** Function:
**    scl_util_assign_dsi_value()
**
** Description:
**    This operation assigns a dsi value based on the flags for a particular PID and
**    the dsi code assigned.
**
**
** 
** Parameter:
**    uint_least8_t *dsi_value: This parameter contains the dsi value
**    uint_least16_t dsi_code: This parameter contains the dsi code assigned to the PID.
**    uint_least8_t data_length: This parameter contains the data length of the PID.
**    uint_least8_t flags: This parameter contains the flags of the PID.
** 
** Return:     
**    void

**============================================================================*/
void scl_util_assign_dsi_value
(
   uint_least8_t *dsi_value,
   uint_least16_t dsi_code,
   uint_least8_t data_length,
   uint_least8_t flags
);

/*==============================================================================
** Function:
**    scl_util_assign_dsi()
**
** Description:
**    This operation will assign the DSI code based on the data received.
**
** Parameter:
**    uint_least8_t data_length: This parameter contains the data length of the PID.
**    uint_least8_t flags: This parameter contains the flags of the PID.
**    uint_least8_t *data: This parameter points to the data that was received
**    uint_least16_t *dsi_code: The dsi code assigned to the PID will be placed in 
**                              this parameter.
** 
** Return:     
**    void
**============================================================================*/
void scl_util_assign_dsi
(
   uint_least8_t data_length,
   uint_least8_t flags,
   uint_least8_t *data,
   uint_least16_t *dsi_code
);
#ifdef __cplusplus
}
#endif
#endif /* #ifndef SCL_UTIL_H_ */

