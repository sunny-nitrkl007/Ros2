/******************************************************************************************************************
 Copyright 2011 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------------------------------------------
File name: scl_qr_lib.h

Description:
******************************************************************************************************************/
#ifndef SCL_QR_LIB_H_
#define SCL_QR_LIB_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <scl_qr_config.h>

/******************************************************************************************************************
Function name: scl_qr_get_qual_data

Description: Get qualified data from an external database. 

Parameter Description:
uint_least32_t pid: PID whose qualified data is requested
uint_least16_t qual_type: Qualifier of the pid
uint_least8_t *qr_data_buf: A buffer where data will be copied
uint_least8_t qr_data_buf_size: The size of the buffer. 
uint_least8_t *data_len_ptr: The actual length of the data being copied.

Return Description:
TRUE if data is copied, FALSE otherwise.
******************************************************************************************************************/
bool_t scl_qr_get_qual_data( 
   uint_least32_t pid,
   uint_least16_t qual_type, 
   uint_least8_t *qr_data_buf,
   uint_least8_t qr_data_buf_size,
   uint_least8_t *data_len_ptr);


/******************************************************************************************************************
Function name: scl_qr_get_entry

Description: This searches pid and qaulified type list

Parameter Description:
pid: pid to look for
type: type of the pid. Allowed values are
   SCL_QUAL_READ_MAX_POSSIBLE
   SCL_QUAL_READ_MIN_POSSIBLE
   SCL_QUAL_READ_NOMINAL
   SCL_QUAL_READ_SETPOINT
   SCL_QUAL_READ_CALIBRATION
   SCL_QUAL_READ_MAX_ACTUAL
   SCL_QUAL_READ_MIN_ACTUAL

Return Description:
A pointer to scl_qr_data_pie_t if pid and qualified type is found, NULL otherwise
******************************************************************************************************************/
scl_qr_data_pie_t* scl_qr_get_entry(uint_least32_t pid, uint_least16_t qtype);

#ifdef __cplusplus
}
#endif
#endif /* #ifndef SCL_QR_LIB_H_ */
