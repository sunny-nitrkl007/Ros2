/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 2000 CATERPILLAR INC.   ALL RIGHTS RESERVED.            %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** $Source: .../vsdp_struct.h,v $
***
***
*** DESCRIPTION : 
***
*** REQUIRED HEADER :
***
*** LANGUAGE :                  
***    ANSI C
***
*** COMPILE FLAGS :
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** FUNCTIONS CALLED:
***
*******************************************************************************/

#ifndef VSDP_STRUCT_H_
#define VSDP_STRUCT_H_
#ifdef __cplusplus
extern "C" {
#endif

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif

typedef struct  {
		unsigned_8 vsdp_present;    	/* Present State */
		unsigned_8 vsdp_next;	        /* Next State */
		unsigned_32 vsdp_bterm;    	/* 32 Bit B-term */
		unsigned_32 vsdp_cterm;     	/* 32 Bit C-term */
		void (*vsdp_action)(void *); 	/* Pointer to action function */
                void * vsdp_data;	     	/* Pointer to action data */                        
		} vsdp_stt_e;

#ifdef __cplusplus
}
#endif

#endif /* VSDP_STRUCT_H_ */
