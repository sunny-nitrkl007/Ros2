/*******************************************************************************
Copyright 2006-2010 Caterpillar Inc.  All rights reserved.
--------------------------------------------------------------------------------

Filename:   scl_qr_j1939.h
Language:   C89

Summary
This file contains the public interface to J1939 qualified reads.

Portability
There are no known portability issues.

Change History
2006-03-06 JRW -- Original version.

*******************************************************************************/

#ifndef SCL_QR_J1939_H_
#define SCL_QR_J1939_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <std_t.h>
#include <scl_j1939.h>

typedef struct scl_qr_j1939_s scl_qr_j1939_t;
typedef struct scl_qr_j1939_server_s scl_qr_j1939_server_t;
typedef struct scl_qr_j1939_client_s scl_qr_j1939_client_t;

/* This class contains the configuration for the J1939 qualified read library.
*/
typedef struct scl_qr_j1939_config_s
{
   /* This attribute indicates the maximum possible J1939 qualified read data
      requests supported.  There must be at least one client supported to send a
      request. */
   uint_least8_t max_requests;
} scl_qr_j1939_config_t;

/* This class describes the pid type. */
typedef uint_least8_t scl_qr_j1939_pid_type_t;
enum scl_qr_j1939_pid_type_e
{
   SCL_QR_J1939_PID_TYPE_CDLPID = 2,
   SCL_QR_J1939_PID_TYPE_J1939_SPN
};

/* This class describes the type of the qualified data. */
enum scl_qr_j1939_qualifier_type_e
{
   SCL_QR_J1939_MAX_POSSIBLE = 3,
   SCL_QR_J1939_MIN_POSSIBLE,
   SCL_QR_J1939_NOMINAL,
   SCL_QR_J1939_SETPOINT,
   SCL_QR_J1939_CALIBRATION,
   SCL_QR_J1939_MAX_ACTUAL,
   SCL_QR_J1939_MIN_ACTUAL,
   SCL_QR_J1939_MIN_GRAPH,
   SCL_QR_J1939_MAX_GRAPH,
   SCL_QR_J1939_FACTORY_DEFAULT,
   SCL_QR_J1939_CALIBRATION_OFFSET
};
typedef uint_least8_t scl_qr_j1939_qualifier_type_t;

/* This class describes the datalink endiam of the parameter specified. */
enum scl_qr_j1939_datalink_endian_e
{
   SCL_QR_J1939_DL_ENDIAN_LSB,
   SCL_QR_J1939_DL_ENDIAN_MSB
};
typedef uint_least8_t scl_qr_j1939_datalink_endian_t;

/* This class describes the data sign of the parameter specified. */
enum scl_qr_j1939_data_sign_e
{
   SCL_QR_J1939_DATA_SIGNED,
   SCL_QR_J1939_DATA_UNSIGNED
};
typedef uint_least8_t scl_qr_j1939_data_sign_t;

/* This class represents a single J1939 qualified read data entry. */
typedef struct scl_qr_j1939_entry_s
{
   /* This attribute indicates the PID of this entry.  It can either be a CDL
      PID or a J1939 SPN. */
   uint_least32_t pid;
   /* This attribute indicates the type of PID that is being used (CDL PID or
      J1939 SPN).  Possible values are:
         SCL_QR_J1939_PID_TYPE_CDLPID
         SCL_QR_J1939_PID_TYPE_J1939_SPN  */
   scl_qr_j1939_pid_type_t pid_type;
   /* This attribute indicates what type of qualified data is stored in the
      qualified data. */
   scl_qr_j1939_qualifier_type_t qualifier_type;
   /* This attribute indicates the length of the qualified data. */
   uint_least8_t data_length;
   /* This attribute indicates the datalink endian of the parameter data. */
   scl_qr_j1939_datalink_endian_t datalink_endian;
} scl_qr_j1939_entry_t;

/*------------------------------------------------------------------------------
Name:       scl_qr_j1939_init()

Arguments:  scl_j1939_link_t link: This parameter identifies the J1939 link that
               qualified reads will operating on.
            const scl_qr_j1939_config_t *config: This parameter points to the
               configuration of J1939 qualified reads.

Return:     scl_qr_j1939_t *: This points to the allocated and initialized J1939
               qualified reads class.

Description
This operation will initialize J1939 qualified reads with the specified
configuration.
*/
extern scl_qr_j1939_t* scl_qr_j1939_init
(
   scl_j1939_link_t link,
   const scl_qr_j1939_config_t *config
);

/*------------------------------------------------------------------------------
Name:       scl_qr_j1939_add_server()

Arguments:  scl_qr_j1939_t *itself: This parameter points to the J1939 qualified
               reads class itself.
            int_least8_t ecm_idx: This parameter contains the J1939 virtual ecm
               index that is adding the server.
            uint_least8_t max_entries: This atribute indicates the maximum
               possible qualified read entries that the server will support.

Return:     scl_qr_j1939_server_t*: This points to the newly created server or
               NULL if the operation fails.

Description
This operation will add a J1939 qualified read server.  This server is capable
of responding to qualified read requests from remote ECMs and sending the
responses.  It must be called at initialization because it does memory
allocation.
*/
extern scl_qr_j1939_server_t* scl_qr_j1939_add_server
(
   scl_qr_j1939_t *itself,
   int_least8_t ecm_idx,
   uint_least8_t max_entries
);

/*------------------------------------------------------------------------------
Name:       scl_qr_j1939_add_client()

Arguments:  scl_qr_j1939_t *itself: This parameter points to the J1939 qualified
               reads class itself.
            int_least8_t ecm_idx: This parameter contains the J1939 virtual ecm
               index that is adding the client.
            uint_least8_t max_remote_nodes: This parameter indicates the maximum
               number of remote nodes that will support J1939 qualified reads.

Return:     scl_qr_j1939_client_t*: This points to the newly created client or
               NULL if the operation fails.

Description
This operation will add a J1939 qualified read client.  This client is capable
of sending qualified read requests to remote ECMs and receiving the responses.
It must be called at initialization because it does memory allocation.
*/
extern scl_qr_j1939_client_t* scl_qr_j1939_add_client
(
   scl_qr_j1939_t *itself,
   int_least8_t ecm_idx,
   uint_least8_t max_remote_nodes
);

/*------------------------------------------------------------------------------
Name:       scl_qr_j1939_qualified_data_clbk_t()

Arguments:  void *context: This parameter points to the J1939 qualified reads
               callback context.

Return:     int_least32_t: This function should return the qualified data
               buffer.

Description
This type represents a function pointer to a callback function to retrieve
qualified data.  It should be filled in qualified data buffer.
*/
typedef int_least32_t (scl_qr_j1939_qualified_data_clbk_t)
(
   void *context
);

/*------------------------------------------------------------------------------
Name:       scl_qr_j1939_server_add_entry()

Arguments:  scl_qr_j1939_server_t *itself: This parameter points to the
               scl_qr_j1939_server_t class itself.
            const scl_qr_j1939_entry_t *entry: This parameter points to the
               J1939 qualified read entry to be added.
            scl_qr_j1939_qualified_data_clbk_t *qualified_data_callback: This
               parameter points to a callback to be used for this entry to
               retrieve the qualified read data.
            void *qualified_data_context: This parameter points to the context
               pointer to be used with the callback function.

Return:     bool_t: Indicates whether the entry was successfully added.

Description
This operation will add a qualified read entry to the particular server given.

Only 1, 2, and 4 byte sign or unsigned parameters are supported.  3 byte
unsigned parameters are also supported.  Bit length parameters are supported as
long as they are unsigned.

*/
extern bool_t scl_qr_j1939_server_add_entry
(
   scl_qr_j1939_server_t *itself,
   const scl_qr_j1939_entry_t *entry,
   scl_qr_j1939_qualified_data_clbk_t *qualified_data_callback,
   void *qualified_data_context
);

/*------------------------------------------------------------------------------
Name:       scl_qr_j1939_server_remove_entry()

Arguments:  scl_qr_j1939_server_t *itself: This parameter points to the
               scl_qr_j1939_server_t class itself.
            const scl_qr_j1939_entry_t *entry: This parameter points to the
               J1939 qualified reads entry that is being added.

Return:     bool_t: Indicates whether the entry was successfully removed.

Description
This operation will remove a qualified read entry.  It must be called at
initialization or in the same task running scl_j1939_periodic_ctrl_task().
*/
extern bool_t scl_qr_j1939_server_remove_entry
(
   scl_qr_j1939_server_t *itself,
   const scl_qr_j1939_entry_t *entry
);

/*------------------------------------------------------------------------------
Name:       scl_qr_j1939_rqst_clbk_t()

Arguments:  void *context: This parameter points to the context pointer supplied
               when submitting a client J1939 qualified read request.
            uint_least32_t pid: This parameter indicates the pid that was
               requested.
            scl_qr_j1939_pid_type_t pid_type: This parameter indicates the pid
               type that was requested.
            scl_qr_j1939_qualifier_type_t qualifier_type: This parameter
               indicates the qualifier type that was requested.
            bool_t is_ack: This parameter indicates whether the response to the
               request was an acknowledge.
            int_least32_t qualified_data: This parameter contains the qualified
               read data received from the request that was transmitted.
               While this data is a signed value, it can be assigned to an
               unsigned value.  The parameter is_ack should be checked for the
               validity of this data.

Return:     void

Description
This function pointer describes the callback when a response to a J1939
qualified read request has been received.
*/
typedef void (scl_qr_j1939_rqst_clbk_t)
(
   void *context,
   uint_least32_t pid,
   scl_qr_j1939_pid_type_t pid_type,
   scl_qr_j1939_qualifier_type_t qualifier_type,
   bool_t is_ack,
   int_least32_t qualified_data
);

/*------------------------------------------------------------------------------
Name:       scl_qr_j1939_tx_request()

Arguments:  scl_qr_j1939_t *itself: This parameter points to the scl_qr_j1939_t
               class itself.
            int_least8_t ecm_idx: This parameter contains the virtual ecm index
               sending the request.
            uint_least8_t remote_addr: This parameter contains the remote
               address to send the request to.
            uint_least32_t pid: This parameter indicates the pid in which the
               J1939 qualified read data is being requested for.
            scl_qr_j1939_pid_type_t pid_type: This parameter indicates the pid
               type that is being requested.
            scl_qr_j1939_qualifier_type_t qualifier_type: This parameter
               indicates the qualifier type that is being requested.
            scl_qr_j1939_datalink_endian_t datalink_endian: This parameter
               indicates the datalink endian.
            uint_least8_t data_length: This parameter indicates the length of
               data being requested.
            scl_qr_j1939_data_sign_t data_sign: This parameter indicates the
               sign of the requested data.
            scl_qr_j1939_rqst_clbk_t *rqst_clbk: This parameter points to
               a function that will be called when a response to the request is
               received or a timeout occurs.
            void *rqst_clbk_context: This parameter points to the context
               pointer for the request callback function.

Return:     bool_t: Indicates whether the request was successfully transmitted.

Description
This operation will transmit a J1939 qualified read request by the given client
to the given remote address.  It must be called from the same task running
scl_j1939_periodic_ctrl_task().

Only 1, 2, and 4 byte sign or unsigned parameters are supported.  3 byte
unsigned parameters are also supported.  Bit length parameters are supported as
long as they are unsigned.
*/
extern bool_t scl_qr_j1939_tx_request
(
   scl_qr_j1939_t *itself,
   int_least8_t ecm_idx,
   uint_least8_t remote_addr,
   uint_least32_t pid,
   scl_qr_j1939_pid_type_t pid_type,
   scl_qr_j1939_qualifier_type_t qualifier_type,
   scl_qr_j1939_datalink_endian_t datalink_endian,
   uint_least8_t data_length,
   scl_qr_j1939_data_sign_t data_sign,
   scl_qr_j1939_rqst_clbk_t *rqst_clbk,
   void *rqst_clbk_context
);

#ifdef __cplusplus
}
#endif

#endif
