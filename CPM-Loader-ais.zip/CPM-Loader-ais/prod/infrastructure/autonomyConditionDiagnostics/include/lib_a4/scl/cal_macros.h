/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 2001-06 CATERPILLAR INC.   ALL RIGHTS RESERVED.         %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** $Source:  $
***
*** $Author: $
***
*** $Locker:  $
***
*** $Date: $
***
*** $Revision: $
***
*** $State: $
***
*** $Header: $
***
*** $Log: $
***
*** DESCRIPTION : Calibration macros
***
*** REQUIRED HEADER :
***
*** LANGUAGE :                  
***    ANSI C
***
*** COMPILE FLAGS :
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** FUNCTIONS CALLED:
***
*******************************************************************************/

#ifndef CAL_MACROS_H_
#define CAL_MACROS_H_
#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
** -- #Include's --
*******************************************************************************/

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/

/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/

/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/

/*******************************************************************************
** -- Macro Definitions --
*******************************************************************************/

#define ADD_CAL_ST_BITS \
    CAL_MSG_RX,         \
    CAL_ACTIVE,         \
    CAL_MSG_PEND,       \
    CAL_MID_MATCH,      \
    CAL_SUPPORTED,      \
    CAL_BAD_DISP_TYPE,  \
    CAL_INTERLOCK_LOST, \
    CAL_REQ_ENABLE,     \
    CAL_BUSY_EXE,       \
\
    CAL_CMD_IDLE,       \
    CAL_CMD_INIT,       \
    CAL_CMD_RPORT,      \
    CAL_CMD_GOTO,       \
    CAL_CMD_SAVE,       \
    CAL_CMD_REVDEF,     \
    CAL_CMD_REVPRE,     \
    CAL_CMD_ABORT,      \
    CAL_CMD_SHUTDOWN,   \
    CAL_CMD_START,      \
\
    CAL_KEY_YES,        \
    CAL_KEY_NO,         \
    CAL_KEY_CONT,       \
    CAL_KEY_INCSM,      \
    CAL_KEY_DECSM,      \
    CAL_KEY_INCLG,      \
    CAL_KEY_DECLG,      \
\
    CAL_ECM_ABORT,      \
    CAL_ECM_DONE,       \
\
    CAL_CMD_BTN_PRESS,  \
    CAL_CMD_CBOX_SEL,   \
    CAL_CMD_CBOX_DESEL
#ifdef __cplusplus
}
#endif
#endif /* CAL_MACROS_H_ */
