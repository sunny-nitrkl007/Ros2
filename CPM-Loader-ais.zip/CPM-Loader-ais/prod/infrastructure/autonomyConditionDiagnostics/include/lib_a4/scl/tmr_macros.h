/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%    COPYRIGHT (C) 1994-1996 CATERPILLAR INC.   ALL RIGHTS RESERVED.     %%
*** %%         This work contains proprietary information which may           %%
*** %%           constitute a trade secret and/or be confidential.            %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** FILE:	tmr_macros.h
***
*** AUTHOR(S):	Michael A. Dvorsky
***
*** DESCRIPTION :
***	Definition of timer macros.
***
*** LANGUAGE :                  
***    ANSI C
***
*** COMPILE FLAGS :
***
*** MACRO LIST :
***	tmr_rept_state
***	tmr_rept_edge
***	tmr_ss_state
***	tmr_ss_edge
***	tmr_ss_remaining
***	tmr_ss_trigger
***	tmr_ss_retrigger
***	tmr_ss_reset
***	tmr_elapsed_ms
***	tmr_elapsed_reset
***	tmr_elapsed_start
***	tmr_elapsed_stop
***
*******************************************************************************/

/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
<<<<<<<<<<<<                                             >>>>>>>>>>>>>>>>>>>>>>>
<<<<<<<<<<<<         Start of Code for this file         >>>>>>>>>>>>>>>>>>>>>>>
<<<<<<<<<<<<                                             >>>>>>>>>>>>>>>>>>>>>>>
<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/


#ifndef TMR_MACROS_H_
#define TMR_MACROS_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif

/*******************************************************************************
***
*** MACRO NAME: TMR_REPT_STATE
***
*** DESCRIPTION: Return TRUE if the timer is in the HIGH portion of its cycle,
***              and FALSE if it is in the LOW portion.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_rept_t	timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_REPT_STATE(timer) (timer.count >= 0)

/*******************************************************************************
***
*** MACRO NAME: TMR_REPT_EDGE
***
*** DESCRIPTION:  Return TRUE if the timer has transitioned from LOW to HIGH
***               since the last time this macro was used, and FALSE if not.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_rept_t  timer      The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_REPT_EDGE(timer) (timer.edge ? timer.edge = FALSE, TRUE : FALSE)

/*******************************************************************************
***
*** MACRO NAME: TMR_REPT_RESET
***
*** DESCRIPTION:  Clear the edge flag and reset the cycle count to one full
***               cycle prior to the next edge.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_rept_t  timer      The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_REPT_RESET(timer) \
   timer.count = (timer.high_offs + timer.low_limit -1), timer.edge = FALSE


/*******************************************************************************
***
*** MACRO NAME: TMR_SS_STATE
***
*** DESCRIPTION: Return TRUE if is triggered, and FALSE if not.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_ss_t  timer	The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_SS_STATE(timer) (timer.count > 0)

/*******************************************************************************
***
*** MACRO NAME: TMR_SS_EDGE
***
*** DESCRIPTION:  Return TRUE if the timer has expired since the last time
***               this macro was used, and FALSE if not.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_ss_t  timer	The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_SS_EDGE(timer) (timer.edge ? timer.edge = FALSE, TRUE : FALSE)

/*******************************************************************************
***
*** MACRO NAME: TMR_SS_REMAINING
***
*** DESCRIPTION:  Return the number of milliseconds remaining before the
***               timer expires, or 0 if the timer is not triggered.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_ss_t  timer	The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_SS_REMAINING(timer) (timer.count < 0 ? 0 : timer.count)

/*******************************************************************************
***
*** MACRO NAME: TMR_SS_TRIGGER
***
*** DESCRIPTION:  If the timer is not already triggered, set it up to expire
***               after the specified number of milliseconds.  If the timer is
***               already triggered, do nothing.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_ss_t  timer	The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_SS_TRIGGER(timer, delay) \
    if (timer.count <= 0) timer.count = (delay)

/*******************************************************************************
***
*** MACRO NAME: TMR_SS_RETRIGGER
***
*** DESCRIPTION:  Set the timer up to expire after the specified number of
***               milliseconds, regardless of whether it is already triggered.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_ss_t  timer	The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_SS_RETRIGGER(timer, delay) \
    timer.count = (delay)

/*******************************************************************************
***
*** MACRO NAME: TMR_SS_RESET
***
*** DESCRIPTION:  Reset the edge flag.  If the timer is triggered, reset it to
***               the un-triggered state.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_ss_t  timer	The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_SS_RESET(timer) timer.count = -1, timer.edge = 0

/*******************************************************************************
***
*** MACRO NAME: TMR_ELAPSED_MS
***
*** DESCRIPTION:  Return the number of milliseconds counted since the timer was
***               last reset.  This may or may not be the actual time expired,
***               since the timer may have been stopped for an interval.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_elapsed_t  timer	The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_ELAPSED_MS(timer) (timer.count + 0)

/*******************************************************************************
***
*** MACRO NAME: TMR_ELAPSED_RESET
***
*** DESCRIPTION:  Reset the timer count to zero.  Do not change the started/
***               stopped state of the timer.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_elapsed_t  timer	The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_ELAPSED_RESET(timer) timer.count = 0

/*******************************************************************************
***
*** MACRO NAME: TMR_ELAPSED_START
***
*** DESCRIPTION:  Start the timer.  Do not change the count.  If the timer is
***               already running, this macro changes nothing.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_elapsed_t  timer	The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_ELAPSED_START(timer) timer.running = TRUE

/*******************************************************************************
***
*** MACRO NAME: TMR_ELAPSED_STOP
***
*** DESCRIPTION:  Stop the timer.  Do not change the count.  If the timer is
***               already stopped, this macro changes nothing.
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** MACROS CALLED:
***
*** PARMS:
***	TMR_elapsed_t  timer	The timer
***
*** HISTORY:
***	Author: Michael A. Dvorsky
***
*******************************************************************************/

#define TMR_ELAPSED_STOP(timer) timer.running = FALSE



/*******************************************************************************
*** Lower-case macro names are included for backwards compatibility.  The
*** upper-case names should be used in new code.
*******************************************************************************/
#define tmr_rept_state    TMR_REPT_STATE
#define tmr_rept_edge     TMR_REPT_EDGE
#define tmr_rept_reset    TMR_REPT_RESET
#define tmr_ss_state      TMR_SS_STATE
#define tmr_ss_edge       TMR_SS_EDGE
#define tmr_ss_remaining  TMR_SS_REMAINING
#define tmr_ss_trigger    TMR_SS_TRIGGER
#define tmr_ss_retrigger  TMR_SS_RETRIGGER
#define tmr_ss_reset      TMR_SS_RESET
#define tmr_elapsed_ms    TMR_ELAPSED_MS
#define tmr_elapsed_reset TMR_ELAPSED_RESET
#define tmr_elapsed_start TMR_ELAPSED_START
#define tmr_elapsed_stop  TMR_ELAPSED_STOP

#ifdef __cplusplus
}
#endif

#endif /* TMR_MACROS_H_ */
