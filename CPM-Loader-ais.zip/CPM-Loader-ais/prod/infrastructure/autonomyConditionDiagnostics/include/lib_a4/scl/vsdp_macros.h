/******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                       %%
*** %%  COPYRIGHT (C) 2000 CATERPILLAR INC.   ALL RIGHTS RESERVED.           %%
*** %%      This work contains proprietary information which may             %%
*** %%      constitute a trade secret and/or be confidential.                %%
*** %%                                                                       %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** $Source: $
***
*** $Author: $
***
*** $Locker:  $
***
*** $Date: $
***
*** $Revision: $
***
*** $State: $
***
*** $Header: $
***
*** SLog:	$
***
*** DESCRIPTION :	Macros header file for vsdp module
***
*** REQUIRED HEADER :
***
*** LANGUAGE :   ANSI C
***			(vims hardware) Hewlett Packard C 68000 Cross Compiler
*** 			(hppa) Hewlett Packard Softbench C compiler
***			(adem,abl) Microtec C Cross-Compiler
***
***
******************************************************************************/

#ifndef VSDP_MACROS_H_
#define VSDP_MACROS_H_
#ifdef __cplusplus
extern "C" {
#endif

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif

/*******************************************************************************
***
***    Constants defined in this file
***    -- #Define's --
***
*******************************************************************************/


/**
*** ORI8 BIT_MASK,ADDRESS
**      - OR IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define vsdp_SETSTBIT(sys_id, sys_iterm)\
{\
   (sys_iterm[sys_id/MAX_ITERMS] |= (1<<(sys_id%MAX_ITERMS) ) ); \
}\
   
/**
*** AND8 BIT_MASK,ADDRESS
**      - AND IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define vsdp_CLRSTBIT(sys_id, sys_iterm)\
{\
   (sys_iterm[sys_id/MAX_ITERMS] &= (unsigned_32)(~(1<<(sys_id%MAX_ITERMS))));\
}\

/**
*** AND8 BIT_MASK,ADDRESS
**      - AND IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define vsdp_CHKSTBIT(sys_id, local_itermbit, local_iterm, sys_iterm) \
{\
   if((sys_iterm[sys_id/MAX_ITERMS]) & (1<<(sys_id%MAX_ITERMS)))\
      {\
      local_iterm |= local_itermbit;\
      }\
}\


/**
*** ORI8 BIT_MASK,ADDRESS
**      - OR IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define SETSTBIT(id)\
{\
   (*(system_iterm + ((id/32)-1))) |= (1<<(id%32));\
}\
   
/**
*** AND8 BIT_MASK,ADDRESS
**      - AND IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define CLRSTBIT(id)\
{\
   (*(system_iterm + ((id/32)))) &= (unsigned_32)(~(1<<(id%32)));\
}\

/**
*** AND8 BIT_MASK,ADDRESS
**      - AND IMMEDIATE AN 8 BIT VALUE WITH A MEMORY LOCATION.        */
#define CHKSTBIT(id,itermbit,iterm) \
{\
   if((*(system_iterm + ((id/32)))) & (1<<(id%32)))\
   {\
      iterm |= itermbit;\
   }\
}\

/** Generic iterm bit macros - 
*** b=bit location within a global iterm
*** i=iterm ptr (u32array) to a global iterm
*** m=local mask vsdp generated mask
*** l=local iterm vsdp generated iterm 			*/

/* iterm_STBIT returns a 1 if bit is set within a global iterm */
#define iterm_STBIT(b,i)		( ( *(i+(b>>5)) & (1<<(b%32)) ) ? 1 : 0 )

/* iterm_SETBIT sets a bit within a global iterm */
#define iterm_SETBIT(b,i)		( *(i+(b>>5)) |= (1<<(b%32)) )

/* iterm_CLRBIT clears a bit within a global iterm */
#define iterm_CLRBIT(b,i)		( *(i+(b>>5)) &= (~(1<<(b%32))) )

/* iterm_CHKBIT copies a bit from global iterm to local vsdp iterm */
#define iterm_CHKBIT(b,i,m,l)	( iterm_STBIT(b,i) ? (l |= m) : (l &= (~m)) )

#ifdef __cplusplus
}
#endif
#endif /* VSDP_MACROS_H_ */
