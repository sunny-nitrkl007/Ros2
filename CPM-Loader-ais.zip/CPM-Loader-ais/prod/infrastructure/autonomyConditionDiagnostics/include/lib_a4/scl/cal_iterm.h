/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 2001 CATERPILLAR INC.   ALL RIGHTS RESERVED.            %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** $Source:  $
***
*** $Author: $
***
*** $Locker:  $
***
*** $Date: $
***
*** $Revision: $
***
*** $State: $
***
*** $Header: $
***
*** $Log: $
***
*** DESCRIPTION : Calibration prototypes
***
*** REQUIRED HEADER :
***
*** LANGUAGE :                  
***    ANSI C
***
*** COMPILE FLAGS :
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** FUNCTIONS CALLED:
***
*******************************************************************************/

#ifndef CAL_ITERM_H_
#define CAL_ITERM_H_
#ifdef __cplusplus
extern "C" {
#endif

/** -- #Include's --
*******************************************************************************/

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif
#ifndef CAL_MACROS_H_
#include <cal_macros.h>
#endif

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/

enum CAL_ITERM_BITS {
	ADD_CAL_ST_BITS,
	CAL_LAST_ITERM_BIT
};
extern unsigned_32 cal_iterm[];

/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/

#ifdef __cplusplus
}
#endif
#endif /* CAL_ITERM_H_ */
