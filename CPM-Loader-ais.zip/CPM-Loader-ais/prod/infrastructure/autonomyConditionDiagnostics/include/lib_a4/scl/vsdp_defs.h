/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 2000 CATERPILLAR INC.   ALL RIGHTS RESERVED.            %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** $Source: .../vsdp_mach_defs.h,v $
***
***
*** DESCRIPTION : 
***
*** REQUIRED HEADER :
***
*** LANGUAGE :                  
***    ANSI C
***
*** COMPILE FLAGS :
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** FUNCTIONS CALLED:
***
*******************************************************************************/
#ifndef VSDP_DEFS_H_
#define VSDP_DEFS_H_

#ifdef __cplusplus
extern "C" {
#endif


#define EOT 		0x80000000 /* marker for end of state transition table */
#define EOT_STATE 	0xFF
#define MAX_ITERMS   	32

#ifdef __cplusplus
}
#endif
#endif /* VSDP_DEFS_H_ */
