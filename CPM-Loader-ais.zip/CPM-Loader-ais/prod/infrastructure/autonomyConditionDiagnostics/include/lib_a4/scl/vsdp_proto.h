/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 1994-1995 CATERPILLAR INC.   ALL RIGHTS RESERVED.       %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** $Source: .../vsdp_mach_proto.h,v $
***
*** DESCRIPTION : 
***
*** REQUIRED HEADER :
***
*** LANGUAGE :                  
***    ANSI C
***
*** COMPILE FLAGS :
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** FUNCTIONS CALLED:
***
*******************************************************************************/



#ifndef VSDP_PROTO_H_
#define VSDP_PROTO_H_
#ifdef __cplusplus
extern "C" {
#endif

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif

unsigned_8 vsdp_state_machine(unsigned_8, unsigned_32, const vsdp_stt_e *);

#ifdef __cplusplus
}
#endif
#endif /* VSDP_PROTO_H_ */
