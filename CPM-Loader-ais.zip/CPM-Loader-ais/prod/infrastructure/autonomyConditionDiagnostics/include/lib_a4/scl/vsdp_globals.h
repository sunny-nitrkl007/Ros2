/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                       %%
*** %%  COPYRIGHT (C) 2000 CATERPILLAR INC.   ALL RIGHTS RESERVED.           %%
*** %%      This work contains proprietary information which may             %%
*** %%      constitute a trade secret and/or be confidential.                %%
*** %%                                                                       %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
**
*
* DESCRIPTION :
*
* LANGUAGE :   
*       ANSI C
*
* PORTABILITY ISSUES :  
*******************************************************************************/

/*******************************************************************************
***
***   Configuration Management Information (customized for Clear Case or RCS):
***
*** $Source: $
***
*** $Author: $
***
*** $Locker: $
***
*** $Date: $
***
*** $Revision: $
***
*** $View: $
***
*******************************************************************************/
#ifndef VSDP_GLOBALS_H_
#define VSDP_GLOBALS_H_
#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
***
***    External function prototypes, data, & symbols
***    -- nested #Include's --
***
*******************************************************************************/
#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif

/*******************************************************************************
***
***    Data declared in this file
***    -- Global Symbols --
***
*******************************************************************************/

extern unsigned_32 * system_iterm;

#ifdef __cplusplus
}
#endif
#endif /* VSDP_GLOBALS_H_ */
