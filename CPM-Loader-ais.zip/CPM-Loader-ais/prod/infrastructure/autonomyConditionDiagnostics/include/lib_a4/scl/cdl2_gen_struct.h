/******************************************************************************************************************
Copyright 1999 - 2013 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------------------------------------------
File name: cdl2_gen_struct.h

Description: Basic cdl2 structures definitions.

******************************************************************************************************************/
#ifndef CDL2_GEN_STRUCT_H_
#define CDL2_GEN_STRUCT_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif
#ifndef SDS_STRUCT_H_
#include <sds_struct.h>
#endif
#ifndef CDL2_GEN_DEFS_H_
#include <cdl2_gen_defs.h>
#endif
#ifndef CDL2_STRUCT_H_
#include <cdl2_struct.h>
#endif
#ifndef TMR_STRUCT_H_
#include <tmr_struct.h>
#endif
#include <std_t.h>

/* types of pit (parameter information table) */ 
typedef enum_packed 
{
   TX_HDLR,       /* TX handler */
   RX_HDLR,       /* RX handler */
   WR_HDLR,       /* WR handler */
   CON_RX_HDLR    /* RX handler, which supports scl_rw_j1939 and cdl2_ rx handler */
} Cdl_Pit_e; 

/*typedef the cdl_pit*/  
typedef unsigned_8 Cdl_Pit_t;

#if __MINGW64__
typedef   uint_least64_t cdl_ptr_idx_t;
#else   
typedef unsigned_32 cdl_ptr_idx_t;
#endif  

/* structure of host data */
typedef struct
{
   cdl_ptr_idx_t    ptr_idx; /* pointer or index to host data */
   unsigned_8     length;  /* length of host data */
   unsigned_8     scale;   /* scale factor of host data */
} Cdl_Host_Data_t;

/* structure of CDL data */
typedef struct
{
   unsigned_8  length;     /* length of CDL data */
   unsigned_16 scale;      /* scale factor of CDL data */
} Cdl_Data_t;

/* standard handler types 
Note: VC is expecting return type instead of considering default return type , So return type changed to int_16 
      to get ride of compiler errors in VC environment
 */
typedef int_16 (*Cdl2_hdlr_2param_t)(void *, unsigned_8 *);
typedef int_16 (*Cdl2_hdlr_3param_t)(void *, unsigned_16, unsigned_8 *);
typedef int_16 (*Cdl2_hdlr_6param_t)(void *, unsigned_8, unsigned_8,
               unsigned_32, unsigned_8, unsigned_8 *);
typedef int_16 (*Cdl2_hdlr_9param_t)(cdl2_con_rx_data_link_t, unsigned_32, cdl2_con_rx_event_t, void *, unsigned_8, 
                              unsigned_8, unsigned_32, unsigned_8, unsigned_8 *);

/* union of standard handlers */
typedef union
{
   Cdl2_hdlr_2param_t   hdlr_t1; /* 2 params */
   Cdl2_hdlr_6param_t   hdlr_t2; /* 6 params */
   Cdl2_hdlr_3param_t   hdlr_t3; /* 3 params */
   Cdl2_hdlr_9param_t   hdlr_t4; /* 9 params */
} Cdl_Std_Hdlr_t;

typedef struct cdl2pie *Pieptr;
/* pointer to the extension handler function */
typedef unsigned_32 (*Cdl_Ext_Hdlr_t)(Pieptr, unsigned_8 *, unsigned_8);

/* Builder tool pie structure */
typedef struct cdl2pie
{
   Cdl_Data_t  cdl_data;   /* CDL data */ 
   unsigned_32 pid;     /* PID */
   Cdl_Pit_t   pit_type;   /* parameter information table type */
   boolean     reversed;   /* Data reversion */
   boolean     signed_data;   /* Un/signed data */
   Cdl_Host_Data_t   host_data;  /* Host data */
   Cdl_Std_Hdlr_t    std_tx_hdlr;   /* ptr to TX standard handler */
   Cdl_Std_Hdlr_t    std_rd_hdlr;   /* ptr to RD (wr/rx/con_rx) standard handler */
   Cdl_Ext_Hdlr_t    ext_tx_hdlr;   /* ptr to TX extension handler */
   Cdl_Ext_Hdlr_t    ext_rd_hdlr;   /* ptr to RD (wr/rx) extension handler */
} Cdl2_btool_pie_t;

/* Generic input data from analog sensor */
typedef struct {
   unsigned_16 val;         /* val    */  
   SDS_IN_Stat_t  stat;    /* status */
} Cdl2_In_Sensor_t;

/* RX data storage - fixed byte */
typedef struct {                                                          
   unsigned_8 counter;   /* reception counter                              */
   unsigned_8 sid;       /* Source ID of message the parameter was in      */
   unsigned_8 did;       /* Destination ID of message the parameter was in */
   unsigned_8 pdl;       /* Length of the parameter data                   */
   unsigned_32 data;     /* parameter data                                 */
} Cdl2_gen_ovr_parm_fbyte_t;

/* RX data storage - variable byte */
typedef struct {                                                          
   unsigned_8 counter;   /* reception counter                              */
   unsigned_8 sid;       /* Source ID of message the parameter was in      */
   unsigned_8 did;       /* Destination ID of message the parameter was in */
   unsigned_8 pdl;       /* Length of the parameter data                   */
   unsigned_8 data[28];  /* parameter data                                 */
} Cdl2_gen_ovr_parm_nbyte_t;

/* type of services requested */ 
typedef enum_packed 
{
   SERVICETEST,         /* Diagnostic service test */
   CALIBRATION       /* Calibration */
} Cdl2_svtest_cal_e;

/* Defined the enum type to smallest size, to maintain consistent memory with any
   compiler */
typedef unsigned_8 Cdl2_svtest_cal_t;
   
/* Request parameters for service test and calibration */
typedef struct {
   Cdl2_svtest_cal_t type;        /* service type */
   unsigned_16 id;                /* service test or calibration ID */
   unsigned_8  ctrl_bits;         /* general control bit */
   unsigned_16 command;           /* input action/key stroke command */
   unsigned_8  supdata_byte_cnt;  /* num of bytes actually in the supplemental data */
   unsigned_8  supplemental_data[MAX_SVTEST_CAL_SUPDATA_SIZE]; /* supplemental data */
   boolean     new_req_arrived;    /* TRUE if new request has yet to be read */                 
} Cdl2_svtest_cal_request_t;

/* Response parameters for service test and calibration */
typedef struct {
   unsigned_8  status;            /* svtest/cal status */
   unsigned_16 step_no;           /* svtest/cal step number */
   unsigned_8  err_count;         /* warning/error count */
   unsigned_16 error[MAX_SVTEST_CAL_ERROR_LISTING];    /* warning/error description */
} Cdl2_svtest_cal_response_t;

/* service test and calibration datalink interface */
typedef struct {
   unsigned_8  msg_handshake_num;  /* message handshake number */
   unsigned_8  sid;                /* SID (service tool ID) */
   unsigned_8  did;                /* DID (ECM ID) */
   Cdl2_svtest_cal_request_t req;  /* request param recv from the service tool */
} Cdl2_svtest_cal_dlnkifc_t;

/* CBS BTOOL Config Structure */

typedef struct {
   unsigned_16 cdl_data_scale;     /* CDL data scale factor */
   Cdl_Host_Data_t   host_data;    /* Host data */
   cdl2_rx_data_hdlr_t  *ext_hdlr;/* extension handler */
   unsigned_32 data_max_limit;   /* upper limit for data limiting */
   unsigned_32 data_min_limit;   /* upper limit for data limiting */
   unsigned_8  data_limiting_enabled:1; /* TRUE / FALSE to enable or disable data imiting on the incomming data */
   unsigned_8  unused:7;         /* unused bits in the field */
} cdl2_cbs_btool_pie_t;

/*BEU*/
typedef
   SDS_IN_int_32_t cdl2_gen_datalink_get_val_t (void);

typedef
   void cdl2_gen_datalink_set_val_t (int_32);

typedef
   void cdl2_gen_datalink_over_set_val_t (SDS_IN_int_32_t);

typedef
   void cdl2_gen_datalink_fill_tx_buffer_t (unsigned_8 *buffer, unsigned_8 len);

typedef struct
{
   TMR_ss_t    timer;       /* single-shot timer         */
   unsigned_32 time_span;   /* timeout value             */
   unsigned_8  in_use;      /* timer status              */
} CDL2_GEN_intlck_t;

#ifdef __cplusplus
}
#endif

#endif /* CDL2_GEN_STRUCT_H_ */
