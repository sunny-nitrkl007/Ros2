/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%    COPYRIGHT (C) 1994-1996 CATERPILLAR INC.   ALL RIGHTS RESERVED.     %%
*** %%         This work contains proprietary information which may           %%
*** %%           constitute a trade secret and/or be confidential.            %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** FILE:	tmr_struct.h
***
*** AUTHOR(S):	Michael A. Dvorsky
***
*** DESCRIPTION :
***	Header file for all timer module structures.
***
*** LANGUAGE :                  
***    ANSI C
***
*******************************************************************************/

#ifndef TMR_STRUCT_H_
#define TMR_STRUCT_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif

/*******************************************************************************
* Defined timer types are repetitive, single-shot, and elapsed.
*******************************************************************************/
typedef enum {
   
   TMR_NO_TYPE = 0,
   TMR_REPT_TYPE,
   TMR_SS_TYPE,
   TMR_ELAPSED_TYPE
   
} TMR_type_t;

/*******************************************************************************
* Generic timer type.  All timers must begin with the same fields as this
* type.  Do not allocate any timers of this type.
*******************************************************************************/
typedef struct TMR_generic_s {
    struct TMR_generic_s *next;
    struct TMR_generic_s *prev;
    TMR_type_t type;
} TMR_generic_t;

/*******************************************************************************
* Repetitive timer.  Useful for generating a pulse waveform or a regular 
* sequence of edges.
*******************************************************************************/
typedef struct {
    struct TMR_generic_s *next;
    struct TMR_generic_s *prev;
    TMR_type_t  type;
    int_32      count;
    int_32      low_limit;
    int_32      high_offs;
    boolean_t     edge;
} TMR_rept_t;

/*******************************************************************************
* Single-shot timer.  Useful for generating some event after a time delay, or
* a single pulse of known duration.
*******************************************************************************/
typedef struct {
    struct TMR_generic_s *next;
    struct TMR_generic_s *prev;
    TMR_type_t  type;
    int_32      count;
    boolean_t     edge;
} TMR_ss_t;

/*******************************************************************************
* Elapsed timer.  Useful for measuring duration, or for any general timing   
* application.
*******************************************************************************/
typedef struct {
    struct TMR_generic_s *next;
    struct TMR_generic_s *prev;
    TMR_type_t  type;
    unsigned_32 count;
    boolean_t     running;
} TMR_elapsed_t;


#ifdef __cplusplus
}
#endif

#endif /* TMR_STRUCT_H_ */
