/******************************************************************************
Copyright 2012-2013 Caterpillar Inc. All rights reserved.
-------------------------------------------------------------------------------
File name : cdl_critics_defs.h

Description : Cat data link critical sections functions
*******************************************************************************/

#ifndef CDL_CRITICS_DEFS_H_
#define CDL_CRITICS_DEFS_H_
#ifdef __cplusplus
extern "C"
{
#endif

#if defined (__arm)
#include <oel_rtos.h>
#endif

/* Mutex resource declaration for Linux & Infodisplay platforms */
#if defined(__linux) || defined(WIN32) || defined(WINCE) 
#include <oel_rtos.h>
/* This is the main resource used by cdl to guarantee synchronization
   between tasks. */
extern oel_rtos_resource_t * cdl_resource;
/* static flag to initialize the critical section only once */
extern boolean_t cdl_mutex_flag;
#endif

/* Mutex Initializations */
#if defined(__linux)
#include <oel_rtos_posix.h>
#define CDL_INITIALIZE_CRITICAL_SECTION()                                                               \
{                                                                                                       \
   if(cdl_mutex_flag == FALSE)                                                                          \
   {                                                                                                    \
      static const oel_rtos_resource_pi_vconfig_t cdl_resource_vconfig = OEL_RTOS_RESOURCE_PI_VCONFIG();\
      const oel_rtos_resource_config_t *cdl_resource_config = OEL_BASE(&cdl_resource_vconfig);          \
      cdl_resource = oel_rtos_resource_new(cdl_resource_config);                                        \
      cdl_mutex_flag = TRUE;                                                                            \
   }                                                                                                    \
}


#elif defined(WIN32) || defined (WINCE)
#if __MINGW64__
#define CDL_INITIALIZE_CRITICAL_SECTION()
#else

#include <oel_rtos_wince.h>
/* This macro Initializes the Resource with Critical Section(CS) configuration for Infodisplay platform */
#define CDL_INITIALIZE_CRITICAL_SECTION()                                                            \
{                                                                                                    \
   if(cdl_mutex_flag == FALSE)                                                                       \
   {                                                                                                 \
   static const oel_rtos_resource_cs_vconfig_t cdl_resource_vconfig = OEL_RTOS_RESOURCE_CS_VCONFIG();\
   const oel_rtos_resource_config_t *cdl_resource_config = OEL_BASE(&cdl_resource_vconfig);          \
   cdl_resource = oel_rtos_resource_new(cdl_resource_config);                                        \
   cdl_mutex_flag = TRUE;                                                                            \
   }                                                                                                 \
}
#endif

#else   /* For all other platforms this macro does nothing */

#define CDL_INITIALIZE_CRITICAL_SECTION()  

#endif

/* These macros handles mutex lock/unlock functionalities based on the Resource initialized */
#if defined (__linux) || defined(WIN32) || defined (WINCE) 

#if __MINGW64__
#define CDL_ENTER_CRITICAL_SECTION() OEL_RTOS_DISABLE_INTERRUPTS()
#define CDL_LEAVE_CRITICAL_SECTION(status) OEL_RTOS_RESTORE_INTERRUPTS(status)
#else
#define CDL_ENTER_CRITICAL_SECTION()                   \
0;                                                     \
{                                                      \
   oel_rtos_resource_lock(cdl_resource);               \
}

#define CDL_LEAVE_CRITICAL_SECTION(status)              \
{                                                       \
   (void) status;                                       \
   oel_rtos_resource_unlock(cdl_resource);              \
}
#endif

#else   /* For all other platforms these macros include Disable/Restore calls */
#define CDL_ENTER_CRITICAL_SECTION() OEL_RTOS_DISABLE_INTERRUPTS()
#define CDL_LEAVE_CRITICAL_SECTION(status) OEL_RTOS_RESTORE_INTERRUPTS(status)

#endif

#ifdef __cplusplus
}
#endif
#endif /* #ifndef CDL_CRITICS_DEFS_H_ */
