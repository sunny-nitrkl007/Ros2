/*******************************************************************************
** COPYRIGHT (C) 2010-2012 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME:  scl_error.h

DESCRIPTION: SCL Error public include file.
*******************************************************************************/
#ifndef SCL_ERROR_H_
#define SCL_ERROR_H_

#ifdef __cplusplus
extern "C"
{
#endif


/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <oel_rtos.h>

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/

/*
The scl_error_t will use the following SCL_ERROR_... defines to specifiy the 
error that has occurred.  
 
The most significant 4 bits is the category.  
The least significant 4 bits is the component layer.
The second byte is the component.
The third byte is the function.
The fourth byte is the line number.
*/

/* masks used for the scl_error structure */
#define SCL_ERROR_CATAGORY_MASK              0xF0000000
#define SCL_ERROR_LAYER_MASK                 0x0F000000
#define SCL_ERROR_COMPONENT_SHIFT            16    
#define SCL_ERROR_COMPONENT_MASK             0x00FF0000     
#define SCL_ERROR_FUNCTION_SHIFT             8     
#define SCL_ERROR_FUNCTION_MASK              0x0000FF00 
#define SCL_ERROR_LINE_NUM_MASK              0x000000FF

/* component identifiers used to invoke oel_rtos_error */
#define SCL_ERR_COMPONENT_SECURITY           0x01
#define SCL_ERR_COMPONENT_FPS                0x02
#define SCL_ERR_COMPONENT_FPS_J1939          0x03
#define SCL_ERR_COMPONENT_PASSWD             0x04
#define SCL_ERR_COMPONENT_NVM                0x05
#define SCL_ERR_COMPONENT_HFP                0x06
#define SCL_ERR_COMPONENT_FCM                0x07
#define SCL_ERR_COMPONENT_FM                 0x08
#define SCL_ERR_COMPONENT_BRCP               0x09
#define SCL_ERR_COMPONENT_TATTLETALE         0x0A
#define SCL_ERR_COMPONENT_CLOCK_REALTIME     0x0B
#define SCL_ERR_COMPONENT_RTC_J1939          0x0C
#define SCL_ERR_COMPONENT_CLOCK              0x0D
/* qualified read scl_qr */
#define SCL_ERR_COMPONENT_QR                 0x0E
#define SCL_ERR_COMPONENT_TZ_J1939           0x0F
#define SCL_ERR_COMPONENT_BDT                0x10
#define SCL_ERR_COMPONENT_ADT_J1939          0x11
#define SCL_ERR_COMPONENT_WASH               0x12
#define SCL_ERR_COMPONENT_SCL_SYNCLK         0x13
/*CSF -ATS and PMF */
#define SCL_ERR_COMPONENT_CSF_PMF            0x14
#define SCL_ERR_COMPONENT_CSF_ATS            0x15
/* CSF_SIDMC */
#define SCL_ERR_COMPONENT_CSF_SIDMC          0x16
#define SCL_ERR_COMPONENT_ODV                0x17
#define SCL_ERR_COMPONENT_CSE                0x18

/*
If condition detected that should cause a warning but not a reset use the 
macro SCL_ERROR_WARNING. By default function should only use SCL_ERROR_WARNING.
*/
#define SCL_ERROR_WARNING(component, function)     \
   oel_rtos_err_report((__LINE__ % 255)            \
   | ((function) << SCL_ERROR_FUNCTION_SHIFT)   \
   | ((component) << SCL_ERROR_COMPONENT_SHIFT) \
   | OEL_RTOS_ERR_LAYER_SCL            \
   | OEL_RTOS_ERR_CATEGORY_WARNING)

/*
If condition detected that should cause a reset use the macro 
SCL_ERROR_SYS_FATAL.
Reserve SCL_ERROR_SYS_FATAL for cases where something has happened that will
corrupt all function, and there is no possible recovery other than to reset.  
The architect for the activity must approve the use of SCL_ERROR_SYS_FATAL.
*/ 
#define SCL_ERROR_SYS_FATAL(component, function)   \
   oel_rtos_err_report((__LINE__ % 255)      \
   | ((function) << SCL_ERROR_FUNCTION_SHIFT)   \
   | ((component) << SCL_ERROR_COMPONENT_SHIFT) \
   | OEL_RTOS_ERR_LAYER_SCL      \
   | OEL_RTOS_ERR_CATEGORY_SYS_FATAL)

#ifdef __cplusplus
}
#endif

#endif /* SCL_ERROR_H_ */
