/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 1994-1995 CATERPILLAR INC.   ALL RIGHTS RESERVED.       %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** $Source: /nfs/eve/user1/cpu32_lib/src_RCS/sds_struct.h,v $
***
*** $Author: schmile $
***
*** $Locker:  $
***
*** $Date: 96/09/05 09:23:02 $
***
*** $Revision: 1.17 $
***
*** $State: Exp $
***
*** $Header: sds_struct.h,v 1.17 96/09/05 09:23:02 schmile Exp $
***
*** $Log:	sds_struct.h,v $
***Revision 1.17  96/09/05  09:23:02  09:23:02  schmile (Larry E. Schmidt)
***Added ENGFUEL_TRANS to SDS_Engfuel_Stat_t.
***
***Revision 1.16  96/08/09  12:34:59  12:34:59  schmile (Larry E. Schmidt)
***Added types for MPa, usec, and degF.
***
***Revision 1.15  96/05/30  09:49:52  09:49:52  mcbrijr (James R. McBride)
***Changed SDS_KW_t from unsinged_16 to int_16.
***
***Revision 1.14  96/03/29  16:14:00  16:14:00  mcbrijr (James R. McBride)
***Added a enum variable for altitude-compensated overide timing.
***
***Revision 1.13  96/03/21  08:21:42  08:21:42  mcbrijr (James R. McBride)
***Added two enum values to SDS_Engspd_Stat_t, for derate.
***
***Revision 1.12  96/03/20  09:57:19  09:57:19  schmile (Larry E. Schmidt)
***Added gallons/hour magnitude type.
***
***Revision 1.11  96/03/12  12:47:29  12:47:29  schmile (Larry E. Schmidt)
***Added elements to SDS_IN_Stat_t and SDS_Engspd_Stat_t and added the
***composite type SDS_IN_Bitfield_t.
***
***Revision 1.10  96/02/21  10:24:02  10:24:02  mcbrijr (James R. McBride)
***Changed or added the following customer parameters:  set_switch_config_cp,
***engmonit_cp, and coolant_lvl_mode_cp.
***
***Revision 1.9  96/01/16  07:44:16  07:44:16  schmile (Larry E. Schmidt)
***Added new types.
***
***Revision 1.8  96/01/02  15:30:48  15:30:48  schmile (Larry E. Schmidt)
***Altered the engine fuel stat structure and the engine timing stat structure.
***
***Revision 1.7  95/12/21  09:22:08  09:22:08  schmile (Larry E. Schmidt)
***Added new types.
***
***Revision 1.6  95/12/12  16:07:46  16:07:46  schmile (Larry E. Schmidt)
***To type SDS_IN_Stat_t, I added ISshrt and ISshrt_db.
***
***Revision 1.5  95/12/11  09:43:36  09:43:36  schmile (Larry E. Schmidt)
***Added SDS_4PiRadian_t.
***
***Revision 1.4  95/12/10  13:49:57  13:49:57  schmile (Larry E. Schmidt)
***Added typedefs for SDS_DAmp_t and several input structures.
***
***Revision 1.3  95/12/08  12:48:00  12:48:00  schmile (Larry E. Schmidt)
***Updated for new SDS.
***
***Revision 1.2  95/05/18  08:39:45  08:39:45  schmile (Larry E. Schmidt)
***Added SDS_Inj_Data_t.
***
***Revision 1.1  95/03/30  14:21:47  14:21:47  schmile (Larry E. Schmidt)
***Initial revision
***
 * Revision 1.3  95/03/07  15:14:58  15:14:58  verheag (Andrew G. Verheyen)
 * updated output types to change status field to mode
 * 
 * Revision 1.2  95/01/11  09:12:50  09:12:50  verheag (Andrew G. Verheyen)
 * added output SDS structures
 * 
 * Revision 1.1  95/01/11  09:05:17  09:05:17  verheag (Andrew G. Verheyen)
 * Initial revision
 * 
***Revision 1.1  94/11/30  08:20:00  08:20:00  schmile (Larry E. Schmidt)
***Initial revision
***
***
*** DESCRIPTION :
***   SDS standard structure typedefs
***
*** LANGUAGE :                  
***    ANSI C
***
*** NOTES:
***
*** MACRO LIST:
***
*** HISTORY:
***   19-oct-1995 LESchmidt - new code
***
*******************************************************************************/
#ifndef SDS_STRUCT_H_
#define SDS_STRUCT_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif

/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   Magnitude Data Types
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_2PiRadian_t - Angular values measured in parts of 2*Pi radians
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_16 SDS_2PiRadian_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_4PiRadian_t - Angular values measured in parts of 4*Pi radians
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_16 SDS_4PiRadian_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Amp_t - Electrical current measured in Amperes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_Amp_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_AmpL_t - Electrical current measured in Amperes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_32 SDS_AmpL_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Bitfield16_t - 16 bit bitfields
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_16	SDS_Bitfield16_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Bitfield32_t - 32 bit bitfields
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_32	SDS_Bitfield32_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Bitfield8_t - 8 bit bitfields
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_8	SDS_Bitfield8_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Boolean_t - type for true/false parameters
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef boolean_t	SDS_Boolean_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_CentiVolt_t - type to define a voltage centivolts
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_CentiVolt_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Count16_t - 16 bit counters
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_16	SDS_Count16_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Count32_t - 32 bit counters
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_32	SDS_Count32_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Count8_t - 8 bit counters
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_8	SDS_Count8_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_DAmp_t - Electrical current measured in DecaAmperes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_DAmp_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_DeciAmp_t - Electrical current measured in Deci-amperes
   (i.e., Amperes*10^-1)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16		SDS_DeciAmp_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_DeciVolt_t - Voltages measured in Deci-Volts (i.e., volts * 10^-1)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16		SDS_DeciVolt_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_DegC_t - temperatures which can be represented in degrees C
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16		SDS_DegC_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_DegF_t - temperatures which can be represented in degrees F
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16		SDS_DegF_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_DFrac_t - Fractional values multiplied by 10
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_DFrac_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Frac_t - fractional values
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_Frac_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_FracL_t - fractional values
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_32 SDS_FracL_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Gal_Per_Hour_t - Fuel rate in gallons/hour
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_Gal_Per_Hour_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Hz_t - Values measured in Hertz
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_16 SDS_Hz_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_HzL_t - Values measured in Hertz
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_32 SDS_HzL_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_KHz_t - Values measured in Kilohertz
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_16 SDS_KHz_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_KPa_t - type used for pressures which can be  represented in KPa
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_KPa_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_KW_t - Power measured in Kilowatts
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_KW_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_KWH_t - Energy measured in Kilowatt Hours
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_32 SDS_KWH_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_MilliVolt_t - type to define a voltage millivolts
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_MilliVolt_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_MM3_t - quantities measured in mm^3
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_16	SDS_MM3_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_MPa_t - type used for pressures which can be  represented in MPa
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_MPa_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_MPH_t - vehicle speed in miles per hour type
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_MPH_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Offset16_t - 16 bit offsets
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16	SDS_Offset16_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Offset32_t - 32 bit offsets
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_32	SDS_Offset32_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Offset8_t - 8 bit offsets
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_8	SDS_Offset8_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_PercentL_t - Percent values
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_32 SDS_PercentL_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Ratio4_t - data type for ratios which are scaled 2^4
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_16 SDS_Ratio4_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_RPM_t - engine speed in RPM type
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_16 SDS_RPM_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Second_t - Times measured in seconds
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef unsigned_32 SDS_Second_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Volt_t - Voltages measured in volts
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_16 SDS_Volt_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_VoltL_t - Voltages measured in volts
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef int_32 SDS_VoltL_t;

/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   Status Data Types
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_Stat_t - status values for inputs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef enum
   {
   /* Healthy */
   ISok = 0,	
   /* Debouncing to ISok */
   ISok_db,
   /* Initialization State */
   ISinit,	
   /* Debouncing out of ISinit */
   ISinit_db,
   /* Short */
   ISshrt,
   /* Debouncing to ISshrt */
   ISshrt_db,
   /* Short to ground */
   ISshrtgnd,
   /* Debouncing to ISshrtgnd */
   ISshrtgnd_db,
   /* Short to Battery */
   ISshrtbatt,
   /* Debouncing to ISshrtbatt */
   ISshrtbatt_db,
   /* Open circuit */
   ISopen,
   /* Debouncing to ISopen */
   ISopen_db,
   /* Out of Range High */
   ISorh,
   /* Debouncing to ISorh */
   ISorh_db,
   /* Out of Range Low */
   ISorl,
   /* Debouncing to ISorl */
   ISorl_db,
   /* In range fault */
   ISirf,
   /* Debouncing to ISirf */
   ISirf_db,
   /* Input active */
   ISactive,
   /* Debouncing to ISactive */
   ISactive_db,
   /* Input inactive */
   ISinactive,
   /* Debouncing to ISinactive */
   ISinactive_db,
   /* Input is disabled */
   ISdisabled,
   /* Debouncing to ISdisabled */
   ISdisabled_db,
   /* Input is faulting with an illegal fractional value */
   ISfrac,
   /* Debouncing to ISfrac */
   ISfrac_db,
   /* Input is deviating in an illegal way */
   ISdev,
   /* Debouncing to ISdev */
   ISdev_db,
   /* input is not being received */
   IStime_out,
   /* debouncing to IStime_out */
   IStime_out_db
   
   } SDS_IN_Stat_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Intlock_Mode_t - type for specifying ECM interlock mismatches
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef enum
{
   INTRLCK_OK,
   INTRLCK_HRSPWR,
   INTRLCK_ENG
   
} SDS_Intlock_Mode_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_OUT_Stat_t - Status values for Outputs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef enum
   {
   
   OSfull_off = 0,
   OSfull_on,
   OSnormal
   
   } SDS_OUT_Stat_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Switch_t - type used for switches
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef enum
{
   SW_OFF = 0,
   SW_ON  = 1
   
} SDS_Switch_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Trans_Cntrl_Mode_t - type for specifying the transmission control mode
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef enum
{
   TRAN_NO_CONTROL,
   TRAN_DESENGSPD,
   TRAN_TORQUE_OV,
   TRAN_TORQUE_SPEED
   
} SDS_Trans_Cntrl_Mode_t;

/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   General Composite Data Types
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_*_t - Types used for generic input module write methods.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   int_8		val;
   SDS_IN_Stat_t	stat;
   
} SDS_IN_int_8_t;

typedef struct
{
   unsigned_8		val;
   SDS_IN_Stat_t	stat;
   
} SDS_IN_unsigned_8_t;

typedef struct
{
   int_16		val;
   SDS_IN_Stat_t	stat;
   
} SDS_IN_int_16_t;

typedef struct
{
   unsigned_16		val;
   SDS_IN_Stat_t	stat;
   
} SDS_IN_unsigned_16_t;

typedef struct
{
   int_32		val;
   SDS_IN_Stat_t	stat;
   
} SDS_IN_int_32_t;

typedef struct
{
   unsigned_32		val;
   SDS_IN_Stat_t	stat;
   
} SDS_IN_unsigned_32_t;

/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   Composite Data Types
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_Cust_Params_t - Temporary Type to take care of customer parmeters until
                       the file system is complete.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct {
   
   SDS_Bitfield8_t 	set_switch_config_cp;
   SDS_Boolean_t 	pto_to_set_speed_cp;
   SDS_Boolean_t 	pto_config_cp;
   SDS_RPM_t 		ext_idle_engspd_max_cp;
   SDS_RPM_t 		ext_idle_bump_engspd_cp;
   SDS_RPM_t 		ext_idle_ramp_engspd_cp;
   SDS_MPH_t 		ext_idle_vehicle_speed_max_cp;
   SDS_MPH_t 		cruise_vehicle_speed_max_cp;
   SDS_MPH_t 		cruise_vehicle_speed_min_cp;
   SDS_RPM_t 		pto_engspd_set_cp;
   SDS_RPM_t 		pto_engspd_max_cp;
   SDS_RPM_t 		engspd_min_cp;		
   SDS_RPM_t 		engspd_max_cp;		
   SDS_RPM_t 		engspd_max_pto_cp;	
   SDS_MPH_t 		engspd_vehspd_max_cp;	
   SDS_MPH_t 		vehspd_max_protect_cp;
   SDS_Boolean_t 	engspd_max_droop_enable_cp; 
   SDS_RPM_t 		prog_shift_low_gear_cp;	
   SDS_MPH_t 		prog_shift_low_spd_off_cp;	
   SDS_RPM_t 		prog_shift_int_gear_cp;	
   SDS_MPH_t 		prog_shift_int_spd_off_cp;	
   SDS_RPM_t 		prog_shift_gear_down_cp;	
   SDS_MPH_t 		prog_shift_gear_down_spd_cp; 
   SDS_Boolean_t 	soft_vehspd_enable_cp; 
   SDS_Bitfield16_t	engmonit_cp;
   SDS_Boolean_t	coolant_lvl_mode_cp;
   
} SDS_Cust_Params_t; 

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_2PiRadian_t - angular measurements from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_2PiRadian_t val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_2PiRadian_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_AmpL_t - Type for currents received from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_AmpL_t      val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_AmpL_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_Bitfield16_t - 16 bit bitfields from external devices
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct 
{
   SDS_Bitfield16_t   val;
   SDS_IN_Stat_t      stat;
   
} SDS_IN_Bitfield16_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_Bitfield32_t - 32 bit bitfields from external devices
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_Bitfield32_t   val;
   SDS_IN_Stat_t      stat;
   
} SDS_IN_Bitfield32_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_Bitfield8_t - 8 bit bitfields from external devices
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct 
{
   SDS_Bitfield8_t   val;
   SDS_IN_Stat_t      stat;
   
} SDS_IN_Bitfield8_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_Boolean_t - Boolean values from external devices
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_Boolean_t   val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_Boolean_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_CentiVolt_t - type for voltages in centivolt range received from
                        external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct 
{
   SDS_CentiVolt_t   val;
   SDS_IN_Stat_t     stat;
   
} SDS_IN_CentiVolt_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_Count16_t - 16-bit counts from external devices
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_Count16_t   val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_Count16_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_Count32_t - 32-bit counts from external devices
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_Count32_t   val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_Count32_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_Count8_t - 8-bit counts from external devices
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_Count8_t   val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_Count8_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_DAmp_t - Type for currents received from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_DAmp_t       val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_DAmp_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_DeciVolt_t - Voltages in the Decivolt range received from external
                       sources.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_DeciVolt_t  val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_DeciVolt_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_DegC_t - type for temperatures received from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_DegC_t      val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_DegC_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_DFrac_t - decafractional values received from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_DFrac_t      val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_DFrac_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_Frac_t - type for fractional values received from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_Frac_t      val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_Frac_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_FracL_t - type for fractional values received from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_FracL_t      val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_FracL_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_Hz_t - Frequency measurements from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct 
{
   SDS_Hz_t        val;
   SDS_IN_Stat_t   stat; 
   
} SDS_IN_Hz_t;  

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_HzL_t - Frequency measurements from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct 
{
   SDS_HzL_t       val;
   SDS_IN_Stat_t   stat; 
   
} SDS_IN_HzL_t;  

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_KPa_t - type for pressures in the KPa range receive from external 
                  sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_KPa_t       val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_KPa_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_KW_t - Power measurements from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct 
{
   SDS_KW_t        val;
   SDS_IN_Stat_t   stat; 
   
} SDS_IN_KW_t;  

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_KWH_t - Energy measurements from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct 
{
   SDS_KWH_t        val;
   SDS_IN_Stat_t   stat; 
   
} SDS_IN_KWH_t;  

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_MilliVolt_t - type for voltages in millivolt range received from
                        external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct 
{
   SDS_MilliVolt_t   val;
   SDS_IN_Stat_t     stat;
   
} SDS_IN_MilliVolt_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_MPa_t - type for pressures in the MPa range receive from external 
                  sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_MPa_t       val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_MPa_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_MPH_t - type for vehicle speeds received from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct 
{
   SDS_MPH_t       val;
   SDS_IN_Stat_t   stat; 
   
} SDS_IN_MPH_t;  

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_PercentL_t - type for percent values received from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_PercentL_t      val;
   SDS_IN_Stat_t       stat;
   
} SDS_IN_PercentL_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_RPM_t - type for engine speeds received from external sources
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_RPM_t       val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_RPM_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_Volt_t - Voltages in the volt range received from external sources.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_Volt_t  val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_Volt_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_IN_VoltL_t - Voltages in the volt range received from external sources.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_VoltL_t  val;
   SDS_IN_Stat_t   stat;
   
} SDS_IN_VoltL_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_OUT_Count16_t - 16-bit counts from external devices
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_Count16_t   val;
   SDS_OUT_Stat_t   stat;
   
} SDS_OUT_Count16_t;

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   SDS_OUT_Frac_t - Type for fractional values written to external outputs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
typedef struct
{
   SDS_Frac_t      val;
   SDS_OUT_Stat_t  stat;
   
} SDS_OUT_Frac_t;


#ifdef __cplusplus
}
#endif
#endif /* SDS_STRUCT_H_ */
