/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 1999-2010 CATERPILLAR INC.   ALL RIGHTS RESERVED        %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
***
*** DESCRIPTION:
***     Basic cdl2 handler and function prototypes.
***
*** REQUIRED HEADER:
***
*** LANGUAGE:
***    ANSI C
***
*** COMPILE FLAGS:
***
*** NOTES:
*** 
*** 19JAN99 - MHDESAI - Added two new handlers for BBRAM
***         cdl2_std_wr_bbram_ref_fbyte
***         cdl2_std_tx_bbram_ref_fbyte
*** 13SEP00 - CIKOJA - Removed bbram dependent handlers
***
***
*** FUNCTIONS:
***
*** INTERRUPTS:
***
*******************************************************************************/
#ifndef CDL2_GEN_PROTO_H_
#define CDL2_GEN_PROTO_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif
#ifndef CDL2_GEN_STRUCT_H_
#include <cdl2_gen_struct.h>
#endif
#include <cdl2_gen_proto.h>
/* FUNCTIONDEF: cdl2_app_pid_init - parse the PID table and submit handlers*/
void cdl2_app_pid_init (const Cdl2_btool_pie_t *);

/* FUNCTIONDEF: cdl2_memcpy - protected memory copy */
void cdl2_memcpy(unsigned_16 *, unsigned_16 *, unsigned_8);


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*              Transmit Handlers                                             */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/


/* FUNCTIONDEF: cdl2_std_tx_dram_fbyte_hdlr -  fixed size dram TX standard handler
               Supports both signed and unsigned data
*/
int_16 cdl2_std_tx_dram_fbyte_hdlr(void *, unsigned_8 *);

/* FUNCTIONDEF: cdl2_std_tx_dram_nbyte_hdlr - multi-byte dram TX standard handler */
int_16 cdl2_std_tx_dram_nbyte_hdlr(void *pie, unsigned_8 *);

/* FUNCTIONDEF: cdl2_std_tx_dram_msrc_hdlr - multisource TX standard handler */
int_16 cdl2_std_tx_dram_msrc_hdlr(void *, unsigned_8 *);


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*              Write Handlers                    */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/


/* FUNCTIONDEF: cdl2_std_wr_dram_fbyte_hdlr - fixed size dram WR standard handler */
int_16 cdl2_std_wr_dram_fbyte_hdlr(void *, unsigned_16, unsigned_8 *);

/* FUNCTIONDEF: cdl2_std_wr_dram_nbyte_hdlr - multibyte dram WR standard handler */
int_16 cdl2_std_wr_dram_nbyte_hdlr(void *, unsigned_16, unsigned_8 *);

/* FUNCTIONDEF: cdl2_std_wr_dram_mdst_hdlr - multidestinations WR standard handler */
int_16 cdl2_std_wr_dram_mdst_hdlr(void *, unsigned_16, unsigned_8 *);


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*              Receive Handlers                  */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/


/* FUNCTIONDEF: cdl2_std_rx_dram_fbyte_hdlr - fixed byte dram RX standard handler */
int_16 cdl2_std_rx_dram_fbyte_hdlr(void *, unsigned_8 , unsigned_8 ,
        unsigned_32 , unsigned_8 , unsigned_8 *);

/* FUNCTIONDEF: cdl2_std_rx_dram_nbyte_hdlr - multibyte dram RX standard handler */
int_16 cdl2_std_rx_dram_nbyte_hdlr(void *, unsigned_8 , unsigned_8 ,
        unsigned_32 , unsigned_8 , unsigned_8 *);


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*              Extension Handlers                */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/


/* FUNCTIONDEF: cdl2_ext_asensor_stat_hdlr -  analog sensor status extention handler */
unsigned_32 cdl2_ext_asensor_stat_hdlr(Cdl2_btool_pie_t *, unsigned_8 *,
                       unsigned_8);

/* FUNCTIONDEF: cdl2_ext_gauge_sensor_stat_hdlr -  gauge sensor status extension
   handler*/
unsigned_32 cdl2_ext_gauge_sensor_stat_hdlr(Cdl2_btool_pie_t *, unsigned_8 *,
                            unsigned_8);

/* FUNCTIONDEF: cdl2_ext_tx_ttl -  extension hdlr to read total tattletale */
unsigned_32 cdl2_ext_tx_ttl(Cdl2_btool_pie_t *ppie, unsigned_8 *data, 
                                         unsigned_8 len);
                                         
/* FUNCTIONDEF: cdl2_ext_tx_service_hrs_hdlr - extention handler to read hourmeter*/
unsigned_32 cdl2_ext_tx_service_hrs_hdlr(Cdl2_btool_pie_t *ppie, 
                        unsigned_8 *data, unsigned_8 len); 

/* FUNCTIONDEF: cdl2_ext_wr_service_hrs_hdlr - extention handler to program hourmeter*/                     
unsigned_32 cdl2_ext_wr_service_hrs_hdlr(Cdl2_btool_pie_t *ppie, 
                unsigned_8 *data, unsigned_8 len);

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*              Service Test/Calibration              */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/


/* FUNCTIONDEF: cdl2_svtest_cal_get_request -  get the svtest/cal request parameters */
unsigned_8 cdl2_svtest_cal_get_request(Cdl2_svtest_cal_request_t *);

/* FUNCTIONDEF: cdl2_svtest_cal_req_rx_hdlr -  svtest/cal request RX handler */
int_16 cdl2_svtest_cal_req_rx_hdlr(void *, unsigned_8, unsigned_8,
        unsigned_32, unsigned_8, unsigned_8 *);

/* FUNCTIONDEF: cdl2_svtest_cal_queue_resp - put the message on the queue */
int_32 cdl2_svtest_cal_queue_resp(Cdl2_svtest_cal_response_t *);

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*              CBS Handlers                      */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
int_16 cdl2_cbs_std_rx_hdlr (unsigned_8 *data, /* pointer to message receive data*/
                 unsigned_8 data_len, /* message sid */
                 cdl2_cbs_btool_pie_t *pie_data, /* pointer to pie or data */ 
                 unsigned_16 rx_data_dsi_code /* receive data DSI */
                );



/* FUNCTIONDEF: cdl2_ecm_to_datalink_copy -- copy data from ECM to datalink */
void cdl2_ecm_to_datalink_copy(Cdl2_btool_pie_t *pie,
                               unsigned_8 *ecm,
                               unsigned_8 *datalink);

/* FUNCTIONDEF: cdl2_datalink_to_ecm_copy -- copy data from datalink to ECM */
void cdl2_datalink_to_ecm_copy(Cdl2_btool_pie_t *pie,
                               unsigned_8 *datalink,
                               unsigned_8 *ecm);

int_16 cdl2_gen_tx_fbyte_hdlr(Cdl2_btool_pie_t *ppie, unsigned_8 *dest_data);
int_16 cdl2_gen_ovr_tx_fbyte_hdlr(Cdl2_btool_pie_t *pie, unsigned_8 *dest_data);
int_16 cdl2_gen_tx_nbyte_hdlr(Cdl2_btool_pie_t *ppie, unsigned_8 *dest_data);

int_16 cdl2_gen_wr_fbyte_hdlr(Cdl2_btool_pie_t *ppie, unsigned_16 len, unsigned_8 *src_data);
int_16 cdl2_gen_ovr_wr_fbyte_hdlr(Cdl2_btool_pie_t *ppie, unsigned_16 len, unsigned_8 *src_data);
int_16 cdl2_gen_wr_nbyte_hdlr(Cdl2_btool_pie_t *ppie, unsigned_16 len, unsigned_8 *src_data);

unsigned_32 cdl2_gen_calc_error_value (unsigned_8 data_length, unsigned_8 signed_data, SDS_IN_Stat_t status);
int_32 cdl2_gen_scale_host_data (unsigned_8 length, unsigned_16 dl_data_scale, unsigned_8 host_data_scale, 
                                           int_32 dl_data);

void cdl2_gen_remove_pid_table (const Cdl2_btool_pie_t *pid_table);

/*BEU*/
void cdl2_gen_datalink_to_ecm_copy (unsigned_8 dl_data_length, unsigned_8 host_data_length,
                               boolean reversed, unsigned_8 *datalink, unsigned_8 *ecm);
/* FUNCTIONDEF: beu_intlck_maintain -- maintain the interlock */
void cdl2_gen_intlck_maintain(void);

/* FUNCTIONDEF: cdl2_gen_intlck_query -- query the interlock status */
unsigned_8 cdl2_gen_intlck_query(void);


#ifdef __cplusplus
}
#endif

#endif /* CDL2_GEN_PROTO_H_ */
