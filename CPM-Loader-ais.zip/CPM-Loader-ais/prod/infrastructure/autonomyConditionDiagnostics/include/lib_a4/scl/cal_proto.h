/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 2001 - 2011 CATERPILLAR INC.   ALL RIGHTS RESERVED.     %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*** $Source:  $
***
*** $Author: $
***
*** $Locker:  $
***
*** $Date: $
***
*** $Revision: $
***
*** $State: $
***
*** $Header: $
***
*** $Log: $
***
*** DESCRIPTION : Calibration prototypes
***
*** REQUIRED HEADER :
***
*** LANGUAGE :                  
***    ANSI C
***
*** COMPILE FLAGS :
***
*** METHOD:
***
*** NOTES:
***
*** GLOBALS USED:
***
*** FUNCTIONS CALLED:
***
*******************************************************************************/

#ifndef CAL_PROTO_H_
#define CAL_PROTO_H_
#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
** -- #Include's --
*******************************************************************************/

#ifndef STD_TYPES_H_
#include <cat_std_types.h>
#endif
#ifndef CAL_STRUCT_H_
#include <cal_struct.h>
#endif
#ifndef CAL_DEFS_H_
#include <cal_defs.h>
#endif

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/

/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/

/* Calibration Manager Prototypes */

/* use this function if your calibration/service test uses cdl */
void cal_interface_init( cal_interface_init_t *p);

/* use this function if your calibration/service test uses j1939 */
void cal_interface_j1939_init( cal_interface_init_t *p);

/* use this function if your calibration/service test uses both cdl and j1939 */
void cal_interface_cdl_j1939_init( cal_interface_init_t *p);


void cal_interface_main (void);

void set_ecm_abort (void *input);


/* Calibration Error / Warning Prototypes */
void cal_init_err_warn (void);
unsigned_8 cal_add_error (unsigned_16 error);
unsigned_8 cal_add_warning (unsigned_16 warning);
unsigned_8 cal_del_warning (unsigned_16 warning);
unsigned_8 cal_msg_put_errors (void *buffer);
unsigned_8 cal_msg_put_warnings (void *buffer);


/* Calibration Step Manager Prototypes */
void cal_define_cal_tbl (cal_step_tbl_entry_t *pCalTable, unsigned_16 wEntries);
void cal_reset_cal_tbl (void);
unsigned_8 cal_add_calibration (unsigned_16 wId,
                      const cal_setup_tbl_entry_t *pSetup,
                      const cal_flow_tbl_entry_t *pFlow,
                     void (*pFunc)(enum CAL_HSIG signal, void *pData),
                     void *pData,
                     cal_last_stat_t *pLastCalStat);
cal_step_tbl_entry_t* cal_find_calibration (unsigned_16 wId);

void cal_define_srv_tbl (cal_step_tbl_entry_t *pSrvTable, unsigned_16 wEntries);
void cal_reset_srv_tbl (void);
unsigned_8 cal_add_servicemode (unsigned_16 wId,
                     const cal_setup_tbl_entry_t *pSetup,
                     const cal_flow_tbl_entry_t *pFlow,
                     void (*pFunc)(enum CAL_HSIG signal, void * pData),
                     void *pData);
cal_step_tbl_entry_t* cal_find_servicemode (unsigned_16 wId);

/* get currently using display type */
unsigned_16 cal_get_display_type( void );

/******************************************************************************************************************
Function name: cal_get_action_command

Description: This function returns 2 byte action command from the cal_rx_msg structure.

Parameter Description: void

Return Description: unsigned_16
   Action Command
******************************************************************************************************************/
unsigned_16 cal_get_action_command( void );

/* set the display type */
void cal_set_display_type(unsigned_16  display_type);

/* specify the j1939 link calibration will operate on */
void cal_set_j1939_link(int_8 link);

/* specify the j1939 ecm index calibration will operate on */
void cal_set_j1939_ecm_index(int_8 ecm_index);

/*Get the Service Test Mode Active Status*/
unsigned_8 srvtest_get_active_status(void);

/*Get the Calibration Mode Active Status*/
unsigned_8 cal_get_active_status(void);

#ifdef __cplusplus
}
#endif
#endif /* CAL_PROTO_H_ */
