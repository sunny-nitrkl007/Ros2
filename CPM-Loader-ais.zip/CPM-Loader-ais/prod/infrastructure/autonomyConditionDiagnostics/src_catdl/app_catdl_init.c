/*******************************************************************************
 ***
 *** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 *** %%                                                                        %%
 *** %%  COPYRIGHT (C) 2015 CATERPILLAR INC.   ALL RIGHTS RESERVED.            %%
 *** %%      This work contains proprietary information which may              %%
 *** %%      constitute a trade secret and/or be confidential.                 %%
 *** %%                                                                        %%
 *** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 **
 *
 * FILE NAME: app_catdl_init.c
 *
 * DESCRIPTION: Product ID support for CDL over J1939
 *
 * LANGUAGE: ANSI C
 *
 * FUNCTION LIST: app_catdl_init()
 *
 * HISTORY :
 *
 *******************************************************************************/
#ifndef   STD_TYPES_H_
#include <std_types.h>
#endif

#ifndef __APP_CATDL_INIT_H__
#include "app_catdl_init.h"
#endif

#include <cdl2_proto.h>
#include <oel_rtos_posix.h>

#ifndef __APP_DISP_BRIGHTNESS_H__
#include "app_disp_brightness.h"
#endif

#ifndef  ACDCALMGRINF_H_
#include <AcdCalMgrInf.h>
#endif
/*******************************************************************************
 ***
 ***    Referenced Functions, Data, & Symbols
 ***    -- #Include's --
 ***
 *******************************************************************************/

oel_rtos_resource_t *cdl_resource;


char pidF82D_pdata1[] = "JEL12346";
Cdl_gen_tx_pie_t pidF82D_pie = { 8, pidF82D_pdata1 };

char pidF81A_pdata1[] = "NOT AVAILABLE    ";
Cdl_gen_tx_pie_t pidF81A_pie = { 17, pidF81A_pdata1 };

void app_catdl_init(void)
{
#if 0
	/*update the pie for the product id PID*/
    cdl2_add_to_tx_pit(0xF82D,
            /*fixed byte non-reversed data handler*/
            cdl2_tx_f_hdlr,
            &pidF82D_pie);

    /*update the pie for the equipment id PID*/
    cdl2_add_to_tx_pit(0xF81A,
            /*fixed byte non-reversed data handler*/
            cdl2_tx_f_hdlr,
            &pidF81A_pie);
#endif

    /*update the pie for the display brightness PID*/
    appget_disp_brightness_init_j1939();

	/*call calibration enable pid register*/
    cal_cdl_pid_reg();

}
