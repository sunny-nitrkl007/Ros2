#include "app_j1939_map.h"
#include <oel_pack.h>
#include <string.h>

char pidF82D_pdata[8] = "ABC12345";
char pidF810_pdata[8] = "ABC12345";
char pidF81A_pdata[17] = "NOT AVAILABLE    ";

int_least16_t app_j1939_f82d_wr_hndl( void *wr_pie, unsigned_16 len, unsigned_8 *wr_data )
{
	int_least16_t ret = 0;

	unsigned_8 *from = &wr_data[1];

	if(from != NULL && len <= 9 && len > 0)
	{
		memcpy((unsigned_8 *)pidF82D_pdata, from, len-1);

		nvm_block_write(
				app_nvm_file_block_table[6],    /* block handle */
				8,                              /* size to be written */
				0,                              /* offset */
				(unsigned_8 *)pidF82D_pdata,    /* source buffer */
				0);                             /* priority */
		ret = len;
	}

	return( ret ); /* total bytes added */
}

int_least16_t app_j1939_f82d_tx_hndl( void *tx_pie, unsigned_8 *txData )
{
	unsigned_8 len = 8;
    (void) tx_pie;

    memcpy( txData, pidF82D_pdata, len);

    return( len ); /* total bytes added */
}

int_least16_t app_j1939_f810_tx_hndl( void *tx_pie, unsigned_8 *txData )
{
	unsigned_8 len = 8;
    (void) tx_pie;

    memcpy( txData, pidF810_pdata, len);

    return( len ); /* total bytes added */
}


int_least16_t app_j1939_f81a_tx_hndl( void *tx_pie, unsigned_8 *txData )
{
	unsigned_8 len = 17;
    (void) tx_pie;

    memcpy( txData, pidF81A_pdata, len);

    return( len ); /* total bytes added */
}

int_least16_t app_j1939_f012_tx_hdlr( void *tx_pie, unsigned_8 *txData )
{
	unsigned_8 len = 1;
    (void) tx_pie;

    txData[0] =   (uint_least8_t)0x1;

    return( len );
}


int_least16_t app_j1939_59_tx_hdlr( void *tx_pie, unsigned_8 *txData )
{
	unsigned_8 len = 2;
    (void) tx_pie;

    txData[0] =   (uint_least8_t)passwd_pkg_work.ttt & 0xFF;
    txData[1] =  (uint_least8_t)(passwd_pkg_work.ttt & 0xFF00);

    return( len );
}

/********* Memory Access Parameters *********/

/* Memory Access Parameter Processing callback */
unsigned_32 app_scl_j1939_ma_param_process_callback(
    scl_j1939_link_t  Ph_link,
    unsigned_8     Pu8_session,
    unsigned_8     Pu8_param_type,
    unsigned_32    Pu32_param,
    unsigned_8     Pu8_service,
    unsigned_16    Pu16_length,
    unsigned_16*   Ppu16_data_size,
    unsigned_8*    Pau8_data );

/* Memory Access Parameter Processing callback */
unsigned_32 app_scl_j1939_ma_param_process_callback(
    scl_j1939_link_t  Ph_link,
    unsigned_8     Pu8_session,
    unsigned_8     Pu8_param_type,
    unsigned_32    Pu32_param,
    unsigned_8     Pu8_service,
    unsigned_16    Pu16_length,
    unsigned_16*   Ppu16_data_size,
    unsigned_8*    Pau8_data )
{
    /* touch unused arguments to avoid compiler warnings, remove these
      statements if arguments are used */
    (void)Ph_link;
    (void)Pu8_session;
    (void)Pu8_param_type;
    (void)Pu32_param;
    (void)Pu8_service;
    (void)Pu16_length;
    (void)Ppu16_data_size;
    (void)Pau8_data;

    return MA_TRANS_ERROR_SECURITY_GENERAL;
}


/*********************************************************************************
 Memory Access Parameter and Security Definitions are used to associate
 an MA parameter (SPN or PID) with a security level.
 This data is used in the MA Parameter table entries in the lists of parameters
 that are supported by a virtual ECM.  Members:

   Mu32_param  The SPN or PID value associated with this parameter.
   Mu8_read_security The security level that is required to read this parameter.
   Mu8_write_security   The security level that is required to write this parameter.

 */


scl_j1939_ma_param_def_t app_pid_list_ecm_0[] =
{
    {
        0x59,
        0,
        0,
    },
    {
        0xf82d,
        0,
        0,
    },
    {
        0xf81a,
        0,
        0,
    },
    {
        0xf810,
        0,
        0,
    },
};


const scl_j1939_ma_param_list_t app_scl_j1939_ma_param_tbl[] =
{
    {
        /* unsigned_16 Mu16_num_spn; */
        0,
        /* scl_j1939_ma_param_def_t* Mpast_spn_list; */
        NULL,

        /* unsigned_16 Mu16_num_pid; */
        sizeof(app_pid_list_ecm_0) / sizeof(app_pid_list_ecm_0[0]),
        /* scl_j1939_ma_param_def_t* Mpast_pid_list; */
        app_pid_list_ecm_0,

        /* scl_j1939_ma_param_process_cb_t  *process_cb_f; */
        (scl_j1939_ma_param_process_cb_t*)app_scl_j1939_ma_param_process_callback,

        /* size_t Msz_max_overrides */
        5,

        0,       /* Mu16_num_rd_spn_hdrl */
        0,       /* Mu16_num_wr_spn_hdrl */
        0,      /* Mu16_num_ovr_spn_hdrl */
        30,/* Mu16_num_rd_pid_hdrl */
        30,/* Mu16_num_wr_pid_hdrl */
        0    /* Mu16_num_ovr_pid_hdrl */

    }
};

const scl_j1939_ma_wr_param_config_t app_map_wr_config[] =
{
	{
		{ 0xf82d,0,0 },
		app_j1939_f82d_wr_hndl,
		NULL
	},
};

const scl_j1939_ma_rd_param_config_t app_map_rd_config[] =
{
    {
        { 0x59,0,0 },
        app_j1939_59_tx_hdlr,
        NULL
    },
    {
        { 0xf82d,0,0 },
        app_j1939_f82d_tx_hndl,
        NULL
    },
    {
        { 0xf81a,0,0 },
		app_j1939_f81a_tx_hndl,
        NULL
    },
    {
        { 0xf810,0,0 },
        app_j1939_f810_tx_hndl,
        NULL
    },
};

unsigned_8 app_scl_j1939_get_ma_num( void )
{
    return ( sizeof(app_scl_j1939_ma_param_tbl) /
        sizeof(app_scl_j1939_ma_param_tbl[0]) );
}

const unsigned_8 app_scl_j1939_max_ma_sessions = 2;


void app_j1939_map_init(scl_j1939_link_t link,int_least8_t ecm_indx)
{
    unsigned_8 i;

    for (i = 0; i < sizeof(app_map_rd_config) / sizeof(app_map_rd_config[0]);  i++)
    {
        scl_j1939_add_ma_rd_cdlpid(link, ecm_indx, &app_map_rd_config[i]);
    }

    for (i = 0; i < sizeof(app_map_wr_config) / sizeof(app_map_wr_config[0]);  i++)
    {
        scl_j1939_add_ma_wr_cdlpid(link, ecm_indx, &app_map_wr_config[i]);
    }
    return;
}


