/*******************************************************************************
***     COPYRIGHT (C) 2011-2015 CATERPILLAR INC. ALL RIGHTS RESERVED.
*** ****************************************************************************
***
***  FILE:  app_et_j1939_support.c
***
***  DESCRIPTION: ET support over J1939
******************************************************************************/

/******************************************************************************
***
***    External function prototypes, data, & symbols
***    -- #Include's --
***
******************************************************************************/
#include "app_et_j1939_support.h"
#ifndef  ACDCALMGRINF_H_
#include <AcdCalMgrInf.h>
#endif

extern unsigned_16 j1939_mid;
extern unsigned_16 st_app_num;
extern unsigned_16 st_chg_lvl;

/*******************************************************************************
***
***    Constants defined for this file
***    -- #Define's --
***
*******************************************************************************/
# define DEBUG
/******************************************************************************* 
*** 
***
***    Data types defined for this file
***    -- Struct's, Typedef's, Enum's --
***
*******************************************************************************/
extern unsigned_8 device_id_data_j1939[];
char app_description_dl_tx_pie[APPLICATION_TEXT_MAX_SIZE];
char ecm_serial_number[ECM_SERIAL_NUMBER_MAX_SIZE]; /* ECM Serial Number */
char ecm_part_number[ECM_PART_NUMBER_MAX_SIZE]; /* ECM Part Number */
char software_group_part_number[SOFTWARE_GROUP_PN_LENGTH];
char software_group_date_code[SOFTWARE_GROUP_DATE_CODE_LENGTH];
char WeighRangeBottomRqstFlg;
char WeighRangeSizeRqstFlg;
char NewLpsSaWeighScsTxIn_;
char FlushLpsSaWeighScsTxIn_;

/******************************************************************************
***
***   File scope symbols defined for this file
***   -- Symbols --
***
******************************************************************************/

/******************************************************************************
NAME:        app_scl_j1939_build_extid_f016   
DESCRIPTION: Builds the PGN EF00 for Cat Ext ID F016.  
NOTES:       It is the responsibility of this function to make sure, the PGN
             will be sent. Also make sure,the Destination address is extracted
             from the message.
61184 $F016 a b b c c d d
  a - Set to 0 for CDL Device ID Format
  b b - CDL Module ID for ECM Function (LSB First)
  c c - Service Tool Support Change Level (LSB First)
  d d - Application Code (LSB First)
GLOBALS:     
*****************************************************************************/    

void app_scl_j1939_build_extid_f016(scl_j1939_mbuf_hdr_t *mbuf_ptr) 
{

	unsigned_16 length = 9; //The length and data size are hardcoded.
	unsigned_8 i=0, data[9];
	memset( data, 0xFF, length );
    scl_j1939_set_mbuf_da(mbuf_ptr, scl_j1939_get_mbuf_sa(mbuf_ptr));
   
	/* Update device id data for Cat Ext ID $F016 */
	 data[ 0 ] = (unsigned_8)  0xF0;
	 data[ 1 ] = (unsigned_8)  0x16;

	 //Device ID version Supported. Set to 0 for CDL Device ID Format
	 data[ 2 ] = (unsigned_8)  SCL_J1939_TEST_DEVICE_ID_VER;

	 data[ 3 ] = (unsigned_8)(j1939_mid & 0x00FF);
	 data[ 4 ] = (unsigned_8)(j1939_mid>>8 & 0x00FF);

	 /*save device service tool change level(LSB first)*/
	 data[ 5 ] = (unsigned_8)(st_chg_lvl    & 0x00FF);
	 data[ 6 ] = (unsigned_8)(st_chg_lvl>>8 & 0x00FF);

	 /*save device service tool application number(LSB first)*/
	 data[ 7 ] = (unsigned_8)(st_app_num    & 0x00FF);
	 data[ 8 ] = (unsigned_8)(st_app_num>>8 & 0x00FF);

	(void)scl_j1939_fill_mbuf_data(mbuf_ptr,data,length);

    return;
}

/*******************************************************************************/

/******************************************************************************
NAME:        app_scl_j1939_build_extid_f01a   
DESCRIPTION: Builds the PGN EF00 for Cat Ext ID F01A.  
NOTES:       It is the responsibility of this function to make sure, the PGN
             will be sent. Also make sure,the Destination address is extracted
             from the message.
ECM Service Support Identification
61184 $F016 a b b c c d d
  a - Set to 0 for CDL Device ID Format
  b b - CDL Module ID for ECM Function (LSB First)
  c c - Service Tool Support Change Level (LSB First)
  d d - Application Code (LSB First)

GLOBALS:     
*****************************************************************************/    
void app_scl_j1939_build_extid_f01a(scl_j1939_mbuf_hdr_t *mbuf_ptr) 
{
    unsigned_16 i = 0;
    unsigned_8 data[50]; //Max size for this ext id (data)

    //pad the entire data buffer with 0xFF
    memset( data, 0xFF, 50 );
    scl_j1939_set_mbuf_da(mbuf_ptr, scl_j1939_get_mbuf_sa(mbuf_ptr));

    data[ i++ ] = (unsigned_8)  0xF0;
    data[ i++ ] = (unsigned_8)  0x1A;
    memcpy(&data[i], ecm_part_number, ECM_PART_NUMBER_MAX_SIZE);
    /* delimit the data with ASCII "*" */
    i += ECM_PART_NUMBER_MAX_SIZE;
    data[ i++ ] = 0x2A;
    
    memcpy(&data[i], ecm_serial_number, ECM_SERIAL_NUMBER_MAX_SIZE);
    /* delimit the data with ASCII "*" */
    i += ECM_SERIAL_NUMBER_MAX_SIZE;
    data[ i++ ] = 0x2A;
    
    scl_j1939_fill_mbuf_data(mbuf_ptr,data,i);

    return;
};

/******************************************************************************
NAME:        app_scl_j1939_build_extid_f019   
DESCRIPTION: Builds the PGN EF00 for Cat Ext ID F01F.  
NOTES:       It is the responsibility of this function to make sure, the PGN
             will be sent. Also make sure,the Destination address is extracted
             from the message.

$F019 Software Group Information
Message Format: $F019 a [a � a] $2A b [b � b] $2A c [c � c] $2A
   a � Software Group Part Number (ASCII) (see below for defn)
   Delimiter (ASCII "*" ($2A))
   b � Software Group Description (ASCII) (see below for defn)
   Delimiter (ASCII "*" ($2A))
   c � Software Group Release Date (ASCII) (see below for defn)
   Delimiter (ASCII "*" ($2A))
GLOBALS:     
*****************************************************************************/   
void app_scl_j1939_build_extid_f019(scl_j1939_mbuf_hdr_t *mbuf_ptr) 
{
    //Get the buffer. 2 Bytes for Cat Ext ID, 3 *s equals 5 more bytes
    unsigned_8 data[SOFTWARE_GROUP_PN_LENGTH+APPLICATION_TEXT_MAX_SIZE+
                                             SOFTWARE_GROUP_DATE_CODE_LENGTH+5];
    unsigned_8 i = 0, length = sizeof(data);

    //pad the entire data buffer with 0xFF
    memset( data, 0xFF, length );
    scl_j1939_set_mbuf_da(mbuf_ptr, scl_j1939_get_mbuf_sa(mbuf_ptr));

    //Set the first two fields with the Ext ID
    data[ i++ ] = (unsigned_8)0xF0;
    data[ i++ ] = (unsigned_8)0x19;

    //Update the software group part number - Get from getversion
    memcpy(&data[i], software_group_part_number, SOFTWARE_GROUP_PN_LENGTH);
    i += SOFTWARE_GROUP_PN_LENGTH;
    data[ i++ ] = 0x2A;   //Append the delimiter character

    //Update with description - Get from getversion
    memcpy(&data[i], app_description_dl_tx_pie, APPLICATION_TEXT_MAX_SIZE );
    i += APPLICATION_TEXT_MAX_SIZE;
    data[ i++ ] = 0x2A;
    
    //Update with software group code - Get from getversion
    memcpy(&data[i], software_group_date_code, SOFTWARE_GROUP_DATE_CODE_LENGTH);
    i += SOFTWARE_GROUP_DATE_CODE_LENGTH;
    data[ i++ ] = 0x2A;

    scl_j1939_fill_mbuf_data(mbuf_ptr,data,i);
    
    return;
};


/******************************************************************************* 
NAME:        app_scl_j1939_build_extid_f0a6
DESCRIPTION: Build the PGN EF00 CAT EXT id 0xF0A6
NOTES:      $F0A6 ECM Communication Preference
            Specifies the preferred communication mechanism used by the ECM 
            for communicating with other devices on the link for instance 
            Service Tool. For example the Service Tools read this message 
            to find out which protocol to use for writing the Data Link 
            configurations Parameters to the ECM.
            Data Length: 6-1783 Bytes
            Priority: 6
            DP: 0
            PF: 239
            PS: Destination Address
            Transmission Rate: As needed
            Data Format:
            Byte 1 Preferred CDL PID Read/Write Method
            2 Reserved for Future Assignment (Set to $FF) (1 byte)
            3 Reserved for Future Assignment (Set to $FF) (1 byte)
            4 Reserved for Future Assignment (Set to $FF) (1 byte)
            5 Reserved for Future Assignment (Set to $FF) (1 byte)
            6 Reserved for Future Assignment (Set to $FF) (1 byte)
GLOBALS:
*******************************************************************************/
void app_scl_j1939_build_extid_f0a6(scl_j1939_mbuf_hdr_t *mbuf_ptr)
{
    unsigned_8 data[8] = { 0xF0, 0xA6, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    unsigned_8 dst_add = scl_j1939_get_mbuf_da(mbuf_ptr);
    scl_j1939_set_mbuf_da(mbuf_ptr, scl_j1939_get_mbuf_sa(mbuf_ptr));
    scl_j1939_set_mbuf_sa(mbuf_ptr, dst_add);

    /*  Preferred CDL PID Write Method ($F0A6, Byte 1)
        Specifies the preferred method by the ECM for writing all the CDL 
        configuration parameters. For example the Service Tools read this 
        message to find out which protocol to use for writing the CDL PIDs 
        to the ECM.
        Data Length: 1 byte
        Type: Status
        $0 = Memory Access Protocol (MAP)
        $1 = CDL PID Read/Write over J1939
        $FE = Error
        $FF = Not Available 
     */
    /* Fill the entire bytes of the data message that needs to be transmitted */
    scl_j1939_fill_mbuf_data((scl_j1939_mbuf_hdr_t*)mbuf_ptr,data,8);
    return; 
}

int_16 CdlWrPidD00C9FWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data)
{
	 (void) pie;

	  if (len != sizeof(PidWrD00C9F))
	     {
	         return(1);
	     }

	  PidWrD00C9F = PidD00C9F = ((*(src_data + 1) <<8) | (*src_data));
	  PidWrD0102D = PidD0102D;
#ifdef DEBUG
	  printf("PidWrD00C9F = %d",PidWrD00C9F);
#endif
	  /* Set flag to send request to Weigh App */
	  WeighRangeBottomRqstFlg = 1;

	  /* Set flag to flush SCS buffer */
	  FlushLpsSaWeighScsTxIn_ = 1;

	  return(0);
}

int_16 CdlWrPidD0102DWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data)
{
	 (void) pie;

	  if (len != sizeof(PidWrD0102D))
	     {
	         return(1);
	     }

	  PidD0102D = PidWrD0102D =   ((*(src_data + 1) <<8) | (*src_data));
	  PidWrD00C9F = PidD00C9F;
#ifdef DEBUG
	  printf("PidWrD0102D = %d",PidWrD0102D);
#endif
	  /* Set flag to send request to Weigh App */
	  WeighRangeSizeRqstFlg = 1;

	  /* Set flag to flush SCS buffer */
	  FlushLpsSaWeighScsTxIn_ = 1;

	  return(0);
}

int_16 CdlWrPidWrFC06WrHdlr(void *pie,unsigned_16  len,unsigned_32  *src_data)
{
	 (void) pie;
	if (len != sizeof(PidWrFC06))
	     {
	         return(1);
	     }

	  PidFC06 = PidWrFC06 =   *src_data;
	  /* Set flag to send request to Weigh App */
	  PidWrFC06Flag = 1;

	  /* Set flag to flush SCS buffer */
	  FlushLpsSaWeighScsTxIn_ = 1;

	  return(0);
}

int_16 CdlWrPidWrFCF8WrHdlr(void *pie,unsigned_16  len, unsigned_32  *src_data)
{
	 (void) pie;

	  if (len != sizeof(PidWrFCF8))
	     {
	         return(1);
	     }

	  PidFCF8 = PidWrFCF8 =   *src_data;
	  /* Set flag to send request to Weigh App */
	  PidWrFCF8Flag = 1;

	  /* Set flag to flush SCS buffer */
	  FlushLpsSaWeighScsTxIn_ = 1;

	  return(0);
}

int_16 CdlWrPidWrD009F5WrHdlr(void *pie,unsigned_16  len,unsigned_16  *src_data)
{
	 (void) pie;
	  if (len != sizeof(PidWrD009F5))
	     {
	         return(1);
	     }

	  PidD009F5 = PidWrD009F5 =   *src_data;
#ifdef DEBUG
	  printf("PidWrD009F5 = %d",PidWrD009F5);
#endif
	  PidWrD009F5Flag = 1;

	  /* Set flag to flush SCS buffer */
	  FlushLpsSaWeighScsTxIn_ = 1;

	  return(0);
}

int_16 CdlWrPidWrD009A7WrHdlr(void *pie,unsigned_16  len,unsigned_16  *src_data)
{
	 (void) pie;

	  if (len != sizeof(PidWrD009A7))
	     {
	         return(1);
	     }

	  PidD009A7 = PidWrD009A7 =  *src_data;
#ifdef DEBUG
	  printf("PidWrD009A7 = %d",PidWrD009A7);
#endif
	  PidWrD009A7Flag = 1;

      /* Set flag to flush SCS buffer */
      FlushLpsSaWeighScsTxIn_ = 1;

	  return(0);
}

int_16 CdlWrPidWrD112B2WrHdlr(void *pie,unsigned_16  len,unsigned_16  *src_data)
{
	 (void) pie;

	  if (len != sizeof(PidWrD112B2))
	     {
	         return(1);
	     }

	  PidD112B2 = PidWrD112B2 =  CONV_TO_BE_16(*src_data);
#ifdef DEBUG
	  printf("PidWrD112B2 = %d",PidWrD112B2);
#endif
	  PidWrD112B2Flag = 1;

      /* Set flag to flush SCS buffer */
      FlushLpsSaWeighScsTxIn_ = 1;

	  return(0);
}


int_16 CdlWrPidWrD10ACCWrHdlr(void *pie,unsigned_16  len,unsigned_16  *src_data)
{
	 (void) pie;

	  if (len != sizeof(PidWrD10ACC))
	     {
	         return(1);
	     }

	  PidD10ACC = PidWrD10ACC =  CONV_TO_BE_16(*src_data);
#ifdef DEBUG
	  printf("PidWrD10ACC = %d",PidWrD10ACC);
#endif
	  PidWrD10ACCFlag = 1;

      /* Set flag to flush SCS buffer */
      FlushLpsSaWeighScsTxIn_ = 1;

	  return(0);
}

//int_16 CdlWrPidWrD0022CWrHdlr(void *pie,unsigned_16  len,unsigned_16  *src_data)
//{
//	 (void) pie;
//
//	  if (len != sizeof(PidWrD0022C))
//	     {
//	         return(1);
//	     }
//
//	  PidD0022C = PidWrD0022C =  *src_data;
//#ifdef DEBUG
//	  printf("PidWrD0022C = %d",PidWrD0022C);
//#endif
//	  PidWrD0022CFlag = 1;
//	  return(0);
//}



int_16 CdlWrPidWrFCF7WrHdlr(void *pie,unsigned_16  len,unsigned_32  *src_data)
{
	 (void) pie;

	  if (len != sizeof(PidWrFCF7))
	     {
	         return(1);
	     }

	  PidFCF7 = PidWrFCF7 =   *src_data;
	  /* Set flag to send request to Weigh App */
	  PidWrFCF7Flag = 1;

      /* Set flag to flush SCS buffer */
      FlushLpsSaWeighScsTxIn_ = 1;

	  return(0);
}

int_16 CdlWrPidWrD10E4EWrHdlr(void *pie,unsigned_16  len,unsigned_16  *src_data)
{
	 (void) pie;

	  if (len != sizeof(PidWrD10E4E))
	     {
	         return(1);
	     }

	  PidD10E4E = PidWrD10E4E =  CONV_TO_BE_16(*src_data);
#ifdef DEBUG
	  printf("PidWrD10E4E = %d",PidWrD10E4E);
#endif
	  PidWrD10E4EFlag = 1;

      /* Set flag to flush SCS buffer */
      FlushLpsSaWeighScsTxIn_ = 1;

	  return(0);
}

//int_16 CdlWrPidWrF25BWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data)
//{
//	 (void) pie;
//
//	  if (len != sizeof(PidWrF25B))
//	     {
//	         return(1);
//	     }
//
//	  PidF25B = PidWrF25B =   *src_data;
//#ifdef DEBUG
//	  printf("PidWrF25B = %d",PidWrF25B);
//#endif
//	  PidWrF25BFlag = 1;
//	  return(0);
//}
//int_16 CdlWrPidWrD00144WrHdlr(void *pie,unsigned_16  len,unsigned_16  *src_data)
//{
//	 (void) pie;
//
//	  if (len != sizeof(PidWrD00144))
//	     {
//	         return(1);
//	     }
//
//	  PidD00144 = PidWrD00144 =  *src_data;
//#ifdef DEBUG
//	  printf("PidWrD00144 = %d",PidWrD00144);
//#endif
//	  PidWrD00144Flag = 1;
//	  return(0);
//}

int_16 CdlWrPidWrD01B24WrHdlr(void *pie,unsigned_16  len,unsigned_16  *src_data)
{
	 (void) pie;

	  if (len != sizeof(PidWrD01B24))
	     {
	         return(1);
	     }

	  PidD01B24 = PidWrD01B24 =  *src_data;
#ifdef DEBUG
	  printf("PidWrD01B24 = %d",PidWrD01B24);
#endif
	  PidWrD01B24Flag = 1;

      /* Set flag to flush SCS buffer */
      FlushLpsSaWeighScsTxIn_ = 1;

	  return(0);
}

int_16 CdlWrPidWrD106C4WrHdlr(void *pie,unsigned_16  len,unsigned_16  *src_data)
{

   (void) pie;

    if (len != sizeof(PidWrD106C4))
       {
           return(1);
       }

    PidD106C4 = PidWrD106C4 =  CONV_TO_BE_16(*src_data);  // flip bytes
#ifdef DEBUG
    printf("PidWrD106C4 = %d",PidWrD106C4);
#endif
    PidWrD106C4Flag = 1;

    /* Set flag to flush SCS buffer */
    FlushLpsSaWeighScsTxIn_ = 1;

    return(0);
}
