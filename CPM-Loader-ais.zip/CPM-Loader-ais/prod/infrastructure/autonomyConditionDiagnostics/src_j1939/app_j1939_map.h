#ifndef APP_J1939_MAP_H_
#define APP_J1939_MAP_H_

#include <scl_j1939_struct.h>
#include <scl_j1939_proto.h>
#include <stdlib.h>
#include <cat_std_types.h>
#include "../src_prmsw/passwd.h"
#include "../src_nvm/app_nvm_file_cfg.h"

extern char pidF82D_pdata[];
extern char pidF810_pdata[];
extern char pidF81A_pdata[];

extern const unsigned_8 app_scl_j1939_max_ma_sessions;
extern int_least16_t app_j1939_59_tx_hdlr( void *tx_pie, unsigned_8 *txData );
extern int_least16_t app_j1939_f82d_tx_hndl( void *tx_pie, unsigned_8 *txData );
extern int_least16_t app_j1939_f810_tx_hndl( void *tx_pie, unsigned_8 *txData );
extern int_least16_t app_j1939_f81a_tx_hndl( void *tx_pie, unsigned_8 *txData );

extern unsigned_8 app_scl_j1939_get_ma_num( void );
/* Map Init function */
extern void app_j1939_map_init(scl_j1939_link_t link,int_least8_t ecm_indx);
extern void app_j1939_param_init(scl_j1939_link_t link);
extern const scl_j1939_ma_param_list_t app_scl_j1939_ma_param_tbl[];

#endif

