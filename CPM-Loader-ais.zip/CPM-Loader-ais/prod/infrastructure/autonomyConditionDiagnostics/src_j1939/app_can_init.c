/*******************************************************************************
 ***
 *** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 *** %%                                                                        %%
 *** %%  COPYRIGHT (C) 2014 CATERPILLAR INC.   ALL RIGHTS RESERVED.            %%
 *** %%      This work contains proprietary information which may              %%
 *** %%      constitute a trade secret and/or be confidential.                 %%
 *** %%                                                                        %%
 *** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 **
 *
 * FILE NAME: app_can_init.c
 *
 * DESCRIPTION: HAL CAN Interface to j1939 limited support version
 *
 * LANGUAGE: ANSI C
 *
 * FUNCTION LIST: app_can_init()
 *
 * HISTORY :
 *
 *******************************************************************************/

/*******************************************************************************
 ***
 ***    Referenced Functions, Data, & Symbols
 ***    -- #Include's --
 ***
 *******************************************************************************/
#ifndef   STD_TYPES_H_
#include <std_types.h>
#endif

#ifndef   HAL_J1939V2_PORT_H_
#include <hal_j1939v2_port.h>
#endif

#ifndef   SCL_J1939_H_
#include <scl_j1939.h>
#endif

#ifndef   APP_J1939_TABLES_H_
#include "app_j1939_tables.h"
#endif

#ifndef __APP_CAN_INIT_H__
#include "app_can_init.h"
#endif

#include <oel_rtos_posix.h>

#ifndef APP_J1939_MAP_H_
#include "app_j1939_map.h"
#endif

#include <cdl2_proto.h>

#ifndef  ACDCALMGRINF_H_
#include <AcdCalMgrInf.h>
#endif


#include <scl_pgb_j1939.h>


#include <catdllib_fid_def.h>

#define  PidD00C8DDSI  (0x801F)
#define  PidFE2EDSI  (0x8000001F)
#define  Pid0045DSI  (0x801F)
#define PidD01B24DSI  (0x801F)
#define NONE_AVAILABLE  (0xFF)

// ECM J1939 Name
j1939_name_address_t j1939_name_address;
unsigned_16 j1939_mid;
unsigned_16 st_app_num;
unsigned_16 st_chg_lvl;

static const oel_rtos_resource_pi_vconfig_t resource_hal_canv3_vconfig = OEL_RTOS_RESOURCE_PI_VCONFIG();

const oel_rtos_resource_config_t *app_hal_canv3_resource_config = OEL_BASE(&resource_hal_canv3_vconfig);


static const oel_rtos_resource_pi_vconfig_t app_scl_j1939_semaphore_vconfig = OEL_RTOS_RESOURCE_PI_VCONFIG();


const scl_j1939_config_t app_scl_j1939_config =
{
            OEL_BASE(&app_scl_j1939_semaphore_vconfig),
            TRUE,
            FALSE
};
/* Stores the j1939 link information
// This is stored here because we need
// to change the tx msg control byte
// from within retarder main
 */
scl_j1939_link_t Ph_Link_app;


/*
 *****************************************************************************
 *
 *Name:         app_can_init
 *Description:
 * This function checks if the CAN chip is supported and sets the number of
 * objects needed by the application. It then calls each component init
 * function, passing the appropriate object numbers.
 *
 *****************************************************************************
 */


/*HAL CAN V3 Packet & Packet Reader Heap Limits
//     This operation pre-allocates memory in heap for the number of
//     packet objects and packet reader objects allowed.
//
//     It also limits the memory that can be allocated to this amount.
//
//     If we don't do this, then the HAL CANV3 layer will continue to
//     allocate memory every time a new packet occurs.  This can cause
//     us to use all of the available heap space during times when
//     we would rather the packets just be lost (e.g. initialization).
//
//     The pools of packets are used for transmit as well as receive.
//
//     Each time a packet comes in, a packet reader is associated with
//     that packet for each HAL CANV3 client that exists in the system.
//     For this application, here is a list of the clients:
//       *  SCL J1939 (Port A/B) (Extended Ids Only)
//       *  SCL CCP              (Extended Ids Only)
//       *  Network Module       (Standard Ids Only)
//       *  Bridge (Port A/B)    (Extended Ids Only)
//     We need to provide a packet reader for the worst case.  But
//     there is filtering available in the HALCANV3 port update function, so
//     some packets will never get attached to the client, if the client
//     does not care about it.
//
//     Here is a rough estimate of the limits required:
//                   +--------+--------+--------+--------+
//                   |    Transmit     |    Receive      |
//                   | 29-bit | 11-bit | 29-bit | 11-bit |
//          +--------+--------+--------+--------+--------+
//          | Port A |    6   |    0   |    6   |    0   |
//          | Port B |    1   |    0   |    4   |    1   |
//          +--------+--------+--------+--------+--------+
//     If we assume that all of these messages go out every
//     loop (they don't), and we use an outrageous safety
//     factor (times 2), then we come up with the values below.
//
//     We also need to provide a little margin for transmit messages
//     during initialization.  The address claimed message can get
//     choked out if all of the packets get used up because of the
//     other stuff on the link.  Reserve 20 packets for this (usually 10
//     pre-allocation errors end up occuring).  Note that we don't need
//     Packet Readers for these packets, as they are only used for transmit.
 */


/*SCL J1939 Maximum Number Of Nodes
//     This operation reserves memory for the J1939 Name/Address Table.
//     In order for the address claim process to work properly, there
//     needs to be space reserved in this list so that the worst case
//     number of nodes can be stored.  
//
 */

#define SCL_J1939_MAX_PORTA_NODE_NUMBER  ( 2+18 )
#define SCL_J1939_MAX_PORTB_NODE_NUMBER  ( 2+18 )
#define PID_BACKLIGHT_PERCENT            ( 0xD0022B )

volatile hal_canv3_port_t* P_port;

/* Backlight Percentage (Desired) 
//     This variable tells desired backlight percentage.
//     Will be set to unsigned 16.
//     It is scaled 1%/bit.
//     Will be set to unsigned fault ids when the value is unknown.
*/
uint16_t backlight_percentage_des;


/*Backlight Percentage Transmit Parameter Information Entry
//     This variable indicates the size and address of the data
//     associated with this parameter.
*/
const Cdl_gen_tx_pie_t backlight_percentage_tx_pie = 
{ 
                                                   /*Parameter To Transmit*/
    sizeof        (backlight_percentage_des),      /*     Size            */
    (unsigned_8 *) &backlight_percentage_des       /*     Address         */
};


/*Backlight Percentage Desired Overwrite
//     This is the parameter that the service tool writes to 
//     in order to set the backlight percentage.
//     Will be set to unsigned 16.
//     It is scaled 1%/bit.
//     Will be set to unsigned fault ids when the value is unknown.
*/
uint16_t backlight_percentage_over;

/*Backlight Percentage Desired Overwrite Parameter Information Entry
//     This variable indicates the size and address of the data
//     associated with this parameter.
*/
const Cdl_wr_m_1_pie_t backlight_percentage_cf_wr_pie =
{
                                                     /*Parameter To Write*/
     sizeof        (backlight_percentage_over),      /*     Size         */
     (unsigned_8 *) &backlight_percentage_over       /*     Address      */
};



/** Totals [130] **/
unsigned_32	PidFC06 = UNKNOWN4U + FMI14; // - Load Count [3]  (RECM)
unsigned_32	PidFCF8 = UNKNOWN4U + FMI14;// - Lifetime Total Payload Weight [1]  (RECM)
unsigned_32	PidFCF7 = UNKNOWN4U + FMI14;// - Total Pass Count [1]  (RECM)

unsigned_32	PidWrFC06; // - Load Count [3]  (RECM)
unsigned_32	PidWrFCF8;// - Lifetime Total Payload Weight [1]  (RECM)
unsigned_32	PidWrFCF7;// - Total Pass Count [1]  (RECM)

boolean	PidWrFC06Flag; // - Load Count [3]  (RECM)
boolean	PidWrFCF8Flag;// - Lifetime Total Payload Weight [1]  (RECM)
boolean	PidWrFCF7Flag;// - Total Pass Count [1]  (RECM)

unsigned_8 PidF1AA;
unsigned_16 PidD00C9F;
unsigned_16 PidWrD00C9F;

unsigned_16 PidD0102D;
unsigned_16 PidWrD0102D;

//int_16 HydraulicOilTemperature_val = 0;
int_16 LiftCylinderVelocity_val = 0;
//unsigned_16 LiftCylinderPositionPercentage_val = 0;
//unsigned_16 LiftCylinderHeadEndPressure_val = 0;
//unsigned_16 LiftCylinderRodEndPressure_val = 0;
unsigned_16 ParkingBrkStatus_val =  IS_KNOWN2S(FMIDNI);
unsigned_8 ImplLockoutSwitchPos =  IS_KNOWN2S(FMIDNI);
//unsigned_8 LiftLinkagePosDC = 0;
//unsigned_8 TiltLinkagePosDC = 0;

//System Parameters
unsigned_16 PidF42A = UNKNOWN2U + FMI14;//System Voltage
unsigned_8 PidF2C4 = NONE_AVAILABLE;//ECM Location Code
unsigned_8 PidF2C5 = NONE_AVAILABLE;//Desired ECM Location Code

//Production Measurement Loading Status
unsigned_8 PidF2C6 = UNKNOWN1U + FMI14;//Bucket Payload Data
int_16 PidD00C8D = UNKNOWN2S + FMI14;//Bucket Payload
unsigned_16 PidD00D67 = UNKNOWN2U + FMI14;//Loader Bucket Payload Target Weight Percentage
unsigned_32 PidFD39 = UNKNOWN4U + FMI14;//Weigh Cycle Total Truck Payload
unsigned_32 PidFD38 = UNKNOWN4U + FMI14;//Truck Payload Target Weight
int_32 PidFE2E = UNKNOWN4S + FMI14;//Remaining Payload to Load
unsigned_16 Pid00D00BD3 = UNKNOWN2U + FMI14;//Load Cycle Pass Count
unsigned_16 PidD10748 = UNKNOWN2U + FMI14;//Payload Operating Mode
unsigned_16 PidD01788 = UNKNOWN2U + FMI14;//Payload Calculation Method

//Production Measurement Weigh Status
unsigned_16 PidD00E9B = UNKNOWN4U + FMI14;//Payload Weigh Status - Insufficient Data

//Production Measurement Sensor Status
unsigned_16 PidF5AE = UNKNOWN2U + FMI14;//Lift Cylinder Position
unsigned_16 PidF47B = UNKNOWN2U + FMI14;//Lift Cylinder Head End Pressure
unsigned_16 PidF5AF = UNKNOWN2U + FMI14;//Lift Cylinder Rod End Pressure
int_16      Pid0045 = UNKNOWN2S + FMI14;     //Hydraulic Oil Temperature
unsigned_16 Pid00D0018B = UNKNOWN2U + FMI14;//Lift Tilt Cylinder Extension (Absolute)
unsigned_16 Pid00D0018C = UNKNOWN2U + FMI14;//Tilt Cylinder Extension (Absolute)
int_16      Pid00D00A70 = UNKNOWN2S + FMI14;     //Loader Bucket Angle


//Production Measurement Switches
unsigned_8 PidF1AA = UNKNOWN1U + FMI14;// Payload Store Switch
//Production Measurement System Status
unsigned_16 PidD106DF = UNKNOWN2U + FMI14;//Loader Payload State
unsigned_16 PidD10972 = UNKNOWN2U + FMI14;//Requested Payload Control System Status
unsigned_16 PidD10933 = UNKNOWN2U + FMI14;//Payload System Zero Requirement Status
unsigned_16 PidD10822 = UNKNOWN2U + FMI14;//Payload System Zeroed Status
unsigned_16 PidD109A5 = UNKNOWN2U + FMI14;//Payload System Calibration Weight Entry Requirement Status
unsigned_16 PidD10FAD = UNKNOWN2U + FMI14;//Payload Remove Last Pass Button Display Status
unsigned_16 PidD10FAC = UNKNOWN2U + FMI14;//Payload Clear Button Display Status


//Production Measurement Simple Calibration

 unsigned_16 PidD01686 = UNKNOWN2U + FMI14;// - Truck History List Selected Index Number
 unsigned_32 PidFE25 = UNKNOWN4U + FMI14; // -  Truck History List Truck Payload Weight



// Linkage Sensor Calibrated Limits
unsigned_8 PidF13D = UNKNOWN1U + FMI14;//Lift Linkage Position Sensor Duty Cycle
unsigned_16 PidD010FA = UNKNOWN2U + FMI14;//Lift Linkage Position Sensor Full Raise Duty Cycle
unsigned_16 PidD010FB = UNKNOWN2U + FMI14;//Lift Linkage Position Sensor Full Lower Duty Cycle
unsigned_8 PidF13E = UNKNOWN1U + FMI14;//Tilt Linkage Position Sensor Duty Cycle
unsigned_16 PidD010FC = UNKNOWN2U + FMI14;//Tilt Linkage Position Sensor Full Rackback Duty Cycle
unsigned_16 PidD010FD = UNKNOWN2U + FMI14;//Tilt Linkage Position Sensor Full Dump Duty Cycle

//Configurable Parameters
//Production Measurement Settings
int_16 PidD01B24 = UNKNOWN2S + FMI14;// - Last Payload Weight
unsigned_16 PidD009A7 = UNKNOWN2U + FMI14;// - Payload Control System Calibration Weight
unsigned_16 PidD009F5 = UNKNOWN2U + FMI14;// - Loader Bucket Payload Target Weigh
unsigned_16 PidD112B2 = UNKNOWN2U + FMI14;// - Tip-Off Trigger Type Configuration
unsigned_16 PidD10E4E = UNKNOWN2U + FMI14;;// - Tip-Off Mode [1] (RECM)
//Production Measurement Advanced Settings
unsigned_16 PidD00C9F = UNKNOWN2U + FMI14;// - Payload Weigh Activate Lift Position [1] (RECM)
unsigned_16 PidD0102D = UNKNOWN2U + FMI14;// - Payload Weigh Range Configuration [1] (RECM)
unsigned_16 PidD10ACC = UNKNOWN2U + FMI14;// - Payload Overload Warning Enable [1] (RECM)
//Display Settings
unsigned_8 PidF25B = DSI9_1U;//Information Units Status 
unsigned_16 PidD00144 = DSI9_2U;// Service Mode Enable Code 
unsigned_16 PidD0022C = DSI9_2U;//Display Language Status
unsigned_16 PidD106C4 = DSI9_2U;//Store Payload Data Horn Configuration  //TODO: what is the default value?

int_16 PidWrD01B24;// - Last Payload Weight [255]
unsigned_16 PidWrD009A7;// - Payload Control System Calibration Weight [1]
unsigned_16 PidWrD009F5;// - Loader Bucket Payload Target Weight [1]
unsigned_16 PidWrD112B2;// - Tip-Off Trigger Type Configuration [1] (RECM)
unsigned_16 PidWrD10E4E;// - Tip-Off Mode [1] (RECM)
//Production Measurement Advanced Settings
unsigned_16 PidWrD00C9F;// - Payload Weigh Activate Lift Position [1] (RECM)
unsigned_16 PidWrD0102D;// - Payload Weigh Range Configuration [1] (RECM)
unsigned_16 PidWrD10ACC;// - Payload Overload Warning Enable [1] (RECM)
unsigned_16 PidWrD106C4;// - Store Payload Data Horn Configuration

//Configurable Parameters
boolean PidWrD01B24Flag ;// - Last Payload Weight [255]
boolean PidWrD009A7Flag ;// - Payload Control System Calibration Weight [1]
boolean PidWrD009F5Flag ;// - Loader Bucket Payload Target Weight [1]
boolean PidWrD112B2Flag ;// - Tip-Off Trigger Type Configuration [1] (RECM)
boolean PidWrD10E4EFlag ;// - Tip-Off Mode [1] (RECM)
//Production Measurement Advanced Settings
boolean PidWrD00C9FFlag ;// - Payload Weigh Activate Lift Position [1] (RECM)
boolean PidWrD0102DFlag ;// - Payload Weigh Range Configuration [1] (RECM)
boolean  PidWrD10ACCFlag ;// - Payload Overload Warning Enable [1] (RECM)
//Display Settings
boolean PidWrF25BFlag ;// - Information Units Status [1] (RECM)
boolean PidWrD00144Flag ;// - Service Mode Enable Code [1] (RECM)
boolean PidWrD0022CFlag ;// - Display Language Status [1] (RECM)

boolean PidWrD106C4Flag;// - Store Payload Data Horn Configuration

unsigned_8 PidWrF25B;
unsigned_16 PidWrD00144;
unsigned_16 PidWrD0022C;
char WeighRangeBottomRqstFlg;
char WeighRangeSizeRqstFlg;


/* ECM 01 is transmitting PGB groups.  ECM 02 is receiving PGB groups.  */
 static const scl_pgb_j1939_ecm_config_t app_scl_pgb_j1939_ecm_config_01 =
 {
    0,       /* ecm_idx */
    10,       /* num rx connections */
    10,       /* num tx connections */
    10,       /* num rx_groups */
    25,      /* num tx_groups */
    20,       /* num bcasts */
 };
 scl_pgb_j1939_t *app_scl_pgb_j1939_1, *app_scl_pgb_j1939_2;

const app_scl_pgb_cdl_pie_t app_scl_pgb_cdl_pie[] =
{
	{
		sizeof(PidF42A),
		(unsigned_8 *)&PidF42A,
		0xF42A,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidF2C4),
		(unsigned_8 *)&PidF2C4,
		0xF2C4,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidF2C5),
		(unsigned_8 *)&PidF2C5,
		0xF2C5,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidF2C6),
		(unsigned_8 *)&PidF2C6,
		0xF2C6,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD00C8D),
		(unsigned_8 *)&PidD00C8D,
		0x00D00C8D,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD00D67),
		(unsigned_8 *)&PidD00D67,
		0xD00D67,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidFD39 ),
		(unsigned_8 *)&PidFD39 ,
		0xFD39,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidFD38),
		(unsigned_8 *)&PidFD38,
		0xFD38,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidFE2E),
		(unsigned_8 *)&PidFE2E,
		0xFE2E,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(Pid00D00BD3),
		(unsigned_8 *)&Pid00D00BD3,
		0x00D00BD3,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},

	{
		sizeof(PidD10748),
		(unsigned_16 *)&PidD10748,
		0xD10748,
		&app_scl_pgb_cdl_f_tx_hdlr
	},
	{
		sizeof(PidD01788),
		(unsigned_8 *)&PidD01788,
		0xD01788,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD00E9B),
		(unsigned_16 *)&PidD00E9B,
		0xD00E9B,
		&app_scl_pgb_cdl_f_tx_hdlr
	},

	{
		sizeof(PidF1AA),
		(unsigned_8 *)&PidF1AA,
		0xF1AA,
		&app_scl_pgb_cdl_fr_tx_hdlr

    },    
     {
     	sizeof(PidFC06),
     	&PidFC06,
     	0xFC06,
     	&app_scl_pgb_cdl_fr_tx_hdlr
     },
     {
     	sizeof(PidFCF8),
     	&PidFCF8,
     	0xFCF8,
     	&app_scl_pgb_cdl_fr_tx_hdlr
     },
     {
     	sizeof(PidFCF7),
     	&PidFCF7,
     	0xFCF7,
     	&app_scl_pgb_cdl_fr_tx_hdlr
     },
	{
		sizeof(PidD00C9F),
		(unsigned_8 *)&PidD00C9F,
		0xD00C9F,
		&app_scl_pgb_cdl_fr_tx_hdlr

	},
	{
		sizeof(PidD0102D),
		(unsigned_8 *)&PidD0102D,
		0xD0102D,
		&app_scl_pgb_cdl_fr_tx_hdlr
     },
//     {
//     	 2,
//     	 (int_16 *)&HydraulicOilTemperature_val,
//     	 0x45,
//     	 &app_cal_scl_pgb_cdl_fr_tx_hdlr
//       },
       {
     	  2,
     	  (int_16 *)&LiftCylinderVelocity_val,
     	  0xD01961,
     	  &app_scl_pgb_cdl_fr_tx_hdlr
        },
//        {
//     	 2,
//     	 (unsigned_16 *)&LiftCylinderPositionPercentage_val,
//     	 0xF5AE,
//     	 &app_cal_scl_pgb_cdl_fr_tx_hdlr
//        },
//        {
//     	 2,
//     	(unsigned_16 *)&LiftCylinderHeadEndPressure_val,
//     	 0xF47B,
//     	 &app_cal_scl_pgb_cdl_fr_tx_hdlr
//        },
//        {
//     	 2,
//     	 (unsigned_16 *)&LiftCylinderRodEndPressure_val,
//     	 0xF5AF,
//     	 &app_cal_scl_pgb_cdl_fr_tx_hdlr
//        },
        {
      	 2,
      	(unsigned_16 *)&ParkingBrkStatus_val,
      	 0xF602,
      	 &app_scl_pgb_cdl_fr_tx_hdlr
        },
        {
       	 1,
       	(unsigned_8 *)&ImplLockoutSwitchPos,
       	 0xF0B8,
       	 &app_scl_pgb_cdl_fr_tx_hdlr
        },
//        {
//       	 1,
//       	(unsigned_8 *)&LiftLinkagePosDC,
//       	 0xF13D,
//       	 &app_cal_scl_pgb_cdl_fr_tx_hdlr
//        },
//        {
//       	 1,
//       	(unsigned_8 *)&TiltLinkagePosDC,
//       	 0xF13E,
//       	 &app_cal_scl_pgb_cdl_fr_tx_hdlr
//	},
	{
		sizeof(PidF13D ),
		(unsigned_8 *)&PidF13D,
		0xF13D,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidF5AE ),
		(unsigned_8 *)&PidF5AE,
		0xF5AE,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidF47B ),
		(unsigned_8 *)&PidF47B,
		0xF47B,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidF5AF ),
		(unsigned_8 *)&PidF5AF,
		0xF5AF,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidF13E ),
		(unsigned_8 *)&PidF13E,
		0xF13E,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(Pid0045),
		(unsigned_8 *)&Pid0045,
		0x0045,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
        {
		sizeof(Pid00D0018B),
		(unsigned_8 *)&Pid00D0018B,
		0x00D0018B,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
        {
		sizeof(Pid00D0018C),
		(unsigned_8 *)&Pid00D0018C,
		0x00D0018C,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
        {
		sizeof(Pid00D00A70),
		(unsigned_8 *)&Pid00D00A70,
		0x00D00A70,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidF1AA),
		(unsigned_8 *)&PidF1AA,
		0xF1AA,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},

	{
		sizeof(PidD106DF),
		(unsigned_16 *)&PidD106DF,
		0x00D106DF,
		&app_scl_pgb_cdl_f_tx_hdlr
	},
	{
		sizeof(PidD10972),
		(unsigned_16 *)&PidD10972,
		0x00D10972,
		&app_scl_pgb_cdl_f_tx_hdlr
	},
	{
		sizeof(PidD10933),
		(unsigned_16 *)&PidD10933,
		0x00D10933,
		&app_scl_pgb_cdl_f_tx_hdlr
	},
	{
		sizeof(PidD10822),
		(unsigned_16 *)&PidD10822,
		0x00D10822,
		&app_scl_pgb_cdl_f_tx_hdlr
	},
	{
		sizeof(PidD109A5),
		(unsigned_16 *)&PidD109A5,
		0x00D109A5,
		&app_scl_pgb_cdl_f_tx_hdlr
	},

	{
		sizeof(PidD10FAD),
		(unsigned_16 *)&PidD10FAD,
		0x00D10FAD,
		&app_scl_pgb_cdl_f_tx_hdlr
	},
	{
		sizeof(PidD10FAC),
		(unsigned_16 *)&PidD10FAC,
		0x00D10FAC,
		&app_scl_pgb_cdl_f_tx_hdlr
	},
	{
		sizeof(PidD01686),
		(unsigned_16 *)&PidD01686,
		0x00D01686,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidFE25),
		(unsigned_32 *)&PidFE25,
		0x00FE25,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD010FA),
		(unsigned_8 *)&PidD010FA,
		0x00D010FA,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD010FB),
		(unsigned_8 *)&PidD010FB,
		0x00D010FB,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD010FC),
		(unsigned_8 *)&PidD010FC,
		0x00D010FC,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD010FD),
		(unsigned_8 *)&PidD010FD,
		0x00D010FD,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	/* Write Config Data */

	{
		sizeof(PidD01B24),
		(unsigned_8 *)&PidD01B24,
		0x00D01B24,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD009A7),
		(unsigned_8 *)&PidD009A7,
		0x00D009A7,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD009F5),
		(unsigned_8 *)&PidD009F5,
		0x00D009F5,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},

	{
		sizeof(PidD112B2),
		(unsigned_16 *)&PidD112B2,
		0x00D112B2,
		&app_scl_pgb_cdl_f_tx_hdlr
	},
	{
		sizeof(PidD10E4E),
		(unsigned_16 *)&PidD10E4E,
		0x00D10E4E,
		&app_scl_pgb_cdl_f_tx_hdlr
	},
	{
		sizeof(PidD00C9F),
		(unsigned_8 *)&PidD00C9F,
		0x00D00C9F,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD0102D),
		(unsigned_8 *)&PidD0102D,
		0x00D0102D,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD10ACC),
		(unsigned_16 *)&PidD10ACC,
		0x00D10ACC,
		&app_scl_pgb_cdl_f_tx_hdlr
	},
	{
		sizeof(PidF25B),
		(unsigned_8 *)&PidF25B,
		0x00F25B,
		&app_scl_pgb_cdl_fr_tx_hdlr
	},
	{
		sizeof(PidD00144),
		(unsigned_16 *)&PidD00144,
		0x00D00144,
		&app_scl_pgb_cdl_f_tx_hdlr
	},
   {
      sizeof(PidD0022C),
      (unsigned_16  *)&PidD0022C,
      0x00D0022C,
      &app_scl_pgb_cdl_f_tx_hdlr

   },
   {
      sizeof(PidD106C4),
      (unsigned_16  *)&PidD106C4,
      0x00D106C4,
      &app_scl_pgb_cdl_f_tx_hdlr
   }

};

/* Write PID Config Array */
const app_scl_cdl_wr_pie_t app_scl_cdl_wr_pie[] =
{
	  {
		 sizeof(PidWrD00C9F),
		(unsigned_8 *)&PidWrD00C9F,
		 0xD00C9F,
		 CdlWrPidD00C9FWrHdlr
	  },
	  {
		 sizeof(PidWrD0102D),
		 (unsigned_8 *)&PidWrD0102D,
		 0xD0102D,
		 CdlWrPidD0102DWrHdlr
	  },
	{
		sizeof(PidWrFC06),
		(unsigned_8 *)&PidWrFC06,
		0xFC06,
		CdlWrPidWrFC06WrHdlr
	},
	{
		sizeof(PidWrFCF8),
		(unsigned_8 *)&PidWrFCF8,
		0xFCF8,
		CdlWrPidWrFCF8WrHdlr
	},
	{
		sizeof(PidWrFCF7),
		(unsigned_8 *)&PidWrFCF7,
		0xFCF7,
		CdlWrPidWrFCF7WrHdlr
	},
	  {
		 sizeof(PidWrD01B24 ),
		 (unsigned_8 *)&PidWrD01B24 ,
		 0xD01B24,
		 CdlWrPidWrD01B24WrHdlr
	  },
	  {
		 sizeof(PidWrD009A7 ),
		 (unsigned_8 *)&PidWrD009A7 ,
		 0xD009A7,
		 CdlWrPidWrD009A7WrHdlr
	  },
	  {
		 sizeof(PidWrD009F5 ),
		 (unsigned_8 *)&PidWrD009F5 ,
		 0xD009F5,
		 CdlWrPidWrD009F5WrHdlr
	  },

	  {
		 sizeof(PidWrD112B2 ),
		 (unsigned_8 *)&PidWrD112B2 ,
		 0xD112B2,
		 CdlWrPidWrD112B2WrHdlr
	  },
	  {
		 sizeof(PidWrD10E4E  ),
		 (unsigned_8 *)&PidWrD10E4E  ,
		 0xD10E4E,
		 CdlWrPidWrD10E4EWrHdlr
	  },
	  {
		 sizeof(PidWrD00C9F ),
		 (unsigned_8 *)&PidWrD00C9F ,
		 0xD00C9F,
		 CdlWrPidD00C9FWrHdlr
	  },
	  {
		 sizeof(PidWrD0102D ),
		 (unsigned_8 *)&PidWrD0102D ,
		 0xD0102D,
		 CdlWrPidD0102DWrHdlr
	  },
	  {
		 sizeof(PidWrD10ACC  ),
		 (unsigned_8 *)&PidWrD10ACC  ,
		 0xD10ACC,
		 CdlWrPidWrD10ACCWrHdlr
	  },
	  {
		 sizeof(PidWrF25B ),
		 (unsigned_8 *)&PidWrF25B ,
		 0xF25B,
		 CdlWrPidWrF25BWrHdlr
	  },
	  {
		 sizeof(PidWrD00144 ),
		 (unsigned_16  *)&PidWrD00144 ,
		 0xD00144,
		 CdlWrPidWrD00144WrHdlr
	  },
     {
       sizeof(PidWrD0022C  ),
       (unsigned_16  *)&PidWrD0022C  ,
       0xD0022C,
       CdlWrPidWrD0022CWrHdlr
     },
     {
       sizeof(PidWrD106C4  ),
       (unsigned_16  *)&PidWrD106C4  ,
       0xD106C4,
       CdlWrPidWrD106C4WrHdlr
     }

};

/******************************************************************************
FUNCTION NAME: cdl_wr_backlight_percentage_hdlr()
DESCRIPTION: This is the write handler to program the Display Brightness via ET
BEFORE:  Assumes that the input arguments are initialized as follows:
         pie = pointer to data structure of type CdlWriteProgrammablePie_t
               pie->len = length of the write message
                          (programmable data length)
               pie->pdata = pointer to programmable data
                            (actually, data not used)
         len = length of the write message that was received
               (programmable data length)
         src_data = Pointer to where this routine should read the written
                    parameter data.  This pointer is to the internal area
                    where the J11939 data link message is being held.
AFTER:  Returns 1 if error occurred.
             Only caused by the display brightness message length being the
             wrong size.
        Returns 0 if OK.
             Everything worked correctly.
 
RETURN VALUE: Returns 1 if error occurred.
********************************************************************************/
unsigned_16 cdl_wr_backlight_percentage_hdlr(void *pie,
                          unsigned_16 len,
                          unsigned_8  *src_data
                         )
{

     unsigned_16 value_l;

     /*This condition is put to remove QAC warning 3112*/
     if(pie)
     {
         /*Do nothing*/
     }

     if (len != (unsigned_16)sizeof(*src_data))
     {
          /*return error since speed limit value not right size*/
          return(1);
     }

    /* Determine the value when data is reversed */
    value_l   = (unsigned_16) *src_data++;
    value_l  |= (unsigned_16) (((unsigned_16)(*src_data  ))<<8);

     /*return okay status*/
     return(0);
}

/******************************************************************************
FUNCTION app_scl_pgb_cdl_fr_tx_hdlr
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
/* tx handler */
int_16 app_scl_pgb_cdl_fr_tx_hdlr(void *tx_pie, unsigned_8 *data)
{
	//printf("app_scl_pgb_cdl_tx_hdlr\n");
   app_scl_pgb_cdl_pie_t *temp_tx_pie = tx_pie;

   int timeout_us = 1000000; /* 1 sec */
   int counter_us = 0;
   while ((!NewLpsSaWeighScsTxIn_ || FlushLpsSaWeighScsTxIn_) && counter_us < timeout_us ){
       usleep(1000);
       counter_us+=1000;
   }

   switch(temp_tx_pie->len)
   {
      case 1:
      {
         OEL_PACK_LE_8_NO_INCR(data, (unsigned_8)(*(temp_tx_pie->data)));
      }
      break;

      case 2:
      {
         OEL_PACK_LE_16_NO_INCR(data, (unsigned_16)(*(temp_tx_pie->data)));
      }
      break;

      case 4:
      {
         OEL_PACK_LE_32_NO_INCR(data, *(temp_tx_pie->data));
      }
      break;

      default:
      break;
   }

   return temp_tx_pie->len;
}

/******************************************************************************
FUNCTION app_scl_pgb_cdl_f_tx_hdlr
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
/* tx handler */
int_16 app_scl_pgb_cdl_f_tx_hdlr(void *tx_pie, unsigned_8 *data)
{
	//printf("app_scl_pgb_cdl_tx_hdlr\n");
   app_scl_pgb_cdl_pie_t *temp_tx_pie = tx_pie;

   int timeout_us = 1000000; /* 1 sec */
   int counter_us = 0;
   while ((!NewLpsSaWeighScsTxIn_ || FlushLpsSaWeighScsTxIn_) && counter_us < timeout_us ){
       usleep(1000);
       counter_us+=1000;
   }

   switch(temp_tx_pie->len)
   {
      case 1:
      {
         OEL_PACK_BE_8_NO_INCR(data, (unsigned_8)(*(temp_tx_pie->data)));
      }
      break;

      case 2:
      {
         OEL_PACK_BE_16_NO_INCR(data, (unsigned_16)(*(temp_tx_pie->data)));
      }
      break;

      case 4:
      {
         OEL_PACK_BE_32_NO_INCR(data, *(temp_tx_pie->data));
      }
      break;

      default:
      break;
   }

   return temp_tx_pie->len;
}

/******************************************************************************
FUNCTION app_scl_pgb_cdl_server_init
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
/* Add all the pids to tx pit */
void app_scl_pgb_cdl_server_init(void)
{
   unsigned_8 idx;
   unsigned_8 pid_num = sizeof(app_scl_pgb_cdl_pie)/sizeof(app_scl_pgb_cdl_pie[0]);

   for(idx = 0; idx < pid_num ; idx++)
   {
      cdl2_add_to_tx_pit(app_scl_pgb_cdl_pie[idx].pid,
    		  	  	  	 app_scl_pgb_cdl_pie[idx].tx_hdlr,
                         &app_scl_pgb_cdl_pie[idx]);
   }


   /* Configuring  Write PID's and handles */
   pid_num = sizeof(app_scl_cdl_wr_pie)/sizeof(app_scl_cdl_wr_pie[0]);

   for(idx = 0; idx < pid_num ; idx++)
   {
	   cdl2_add_to_wr_pit(app_scl_cdl_wr_pie[idx].pid,
			   	   	   	  app_scl_cdl_wr_pie[idx].tx_hdlr,
	                      &app_scl_cdl_wr_pie[idx]
	                     );
   }

}

/*------------------------------------------------------------------------------
Name:       app_scl_pgb_j1939_server_init()

Arguments:  scl_j1939_link_t link: This parameter contains the link that will
               use scl_pgb_j1939.

Return:     void

Description
This operation will initialize a server for scl_pgb_j1939 for the application
to be able to broadcast PIDs.
*/
void app_scl_pgb_j1939_server_init(scl_j1939_link_t link)
{
   uint_least8_t i;

   app_scl_pgb_j1939_1 = scl_pgb_j1939_init(link);

   oel_assert( app_scl_pgb_j1939_1 != NULL );

   {
      if ( scl_pgb_j1939_add_ecm
           (
              app_scl_pgb_j1939_1,
              &app_scl_pgb_j1939_ecm_config_01
           ) == FALSE )
      {
         oel_assert(0);
         return;
      }
      else
      {
    	  /* add pids to tx pit */
         app_scl_pgb_cdl_server_init();

      }
   }

 }

void app_can_init(void)
{
    J1939Table_t *table_ptr;
    unsigned_8 i;
    bool_t can_init = TRUE;

    /* Try to find a match in the array */
    table_ptr = application_search(LTTT_P5_D11T_00,
            j1939_directory,
            j1939_max_applications
    );

    if ( !table_ptr )
    {
        /* Match was not found, return */
        return;
    }

    switch(can_port1)
    {
    case 0:
        P_port = HAL_CANV3_PORT_01;
        break;
    case 1:
        P_port = HAL_CANV3_PORT_02;
        break;
    default:
        P_port = HAL_CANV3_PORT_02;
        break;
    }


    hal_canv3_port_set_resource(
            P_port,
            app_hal_canv3_resource_config);


    /*This operation pre-allocates memory in heap for the number of
   //packet objects specified.
   //
   //It also limits the memory that can be allocated to this amount.
   //
   //If we don't do this, then the HAL CANV3 layer will continue to
   //allocate memory every time a new packet occurs.  This can cause
   //us to use all of the available heap space during times when
   //we would rather the packets just be lost (e.g. initialization).
   //
   //This pool of packets are used for transmit as well as receive.
     */

    hal_canv3_pckt_prealloc_objects(P_port, 150);

    /*This operation pre-allocates memory in heap for the number of
   //packet reader objects specified.
   //
   //It also limits the memory that can be allocated to this amount.
   //
   //If we don't do this, then the HAL CANV3 layer will continue to
   //allocate memory every time a new packet occurs.  This can cause
   //us to use all of the available heap space during times when
   //we would rather the packets just be lost (e.g. initialization).
   //
   //Each time a packet comes in, a packet reader is associated with
   //that packet for each HAL CANV3 client that exists in the system.
     */

    hal_canv3_preader_prealloc_objects(P_port, 350);

    can_init = (can_init) ?  scl_j1939_set_num_links(1) : FALSE; // Set to maximum available ports
    Ph_Link_app =
            scl_j1939_establish_link
            (
                    P_port,                 /* hal_j1939v2 port */
                    &(table_ptr->can_a_address_table[0]),

                    /*Maximum Number Of Virtual ECMs*/
                    1,

                    100,                                /* number of mbufs */
                    40,                                /* number of extentions */
                    4,                                 /* number of tpcbs */

                    /*Maximum Number Of Nodes On The Network [Including Virtual ECMs]*/
                    (unsigned_8)(1 + SCL_J1939_MAX_PORTA_NODE_NUMBER),

                    /* addr status callback */
                    (scl_j1939_ac_status_cb_t *)(app_scl_j1939_ac_status_callback),
                    &app_scl_j1939_config              /* app config for J1939 */
            );

    /*Proprietary messaging support */
    can_init = (can_init) ?  scl_j1939_set_ppgn_enable_table(
            Ph_Link_app,                          /* scl_j1939_link_t Ph_link */
            table_ptr->can_a_ppgn_enable_num,     /* Pi8_ppgn_enable_size */
            table_ptr->can_a_ppgn_enable          /* scl_j1939_prop_enable_t* Ppast_ppgn_enable_tbl */
    ) : FALSE;
    scl_j1939_set_enable_global_ppgna(Ph_Link_app,TRUE);

    /*Register Proprietary PGN Command With Extended Ids*/
    for (i = 0; i < table_ptr->can_a_ppgn_ext_msg_num; i++)
    {
        can_init = (can_init) ?  scl_j1939_cat_ppgn_id_install_command_id
        (
                /* Identify J1939 link to application */
                Ph_Link_app,

                /* Pointer to a Proprietary PGN Command entry */
                &(table_ptr->can_a_ppgn_ext_msg[i])) : FALSE;
    }

#if 1
    scl_j1939_set_ma_configuration(
        Ph_Link_app, /* scl_j1939_link_t Ph_link */
        app_scl_j1939_get_ma_num(), /* Pi8_ma_param_size */
        app_scl_j1939_ma_param_tbl, /* scl_j1939_ma_param_list_t* Ppast_ma_param_tbl */
        app_scl_j1939_max_ma_sessions); /* unsigned_8 Pu8_max_ma_sessions */

    app_j1939_map_init(Ph_Link_app, 0);
#endif
    /* Proprietary j1939 connection management is required for SCL PGN J1939 */
    can_init = (can_init) ?  scl_j1939_cmgr_init(Ph_Link_app, 1,1) : FALSE;

    /* Initialize server for J1939 read/write protocol*/
    can_init = (can_init) ?  scl_rw_j1939_server_init(Ph_Link_app) : FALSE;

    /*Initializes CDL R/W protocol over J1939 for CAN A */
    can_init = (can_init) ?  scl_rw_j1939_client_init(Ph_Link_app) : FALSE;

    /* Initialization done */
    scl_j1939_init_tasks(app_scl_j1939_tsk_period);

   /* PGB protocol init  */
    app_scl_pgb_j1939_server_init(Ph_Link_app);

	/*CAl CAN Init starts*/
    init_cal_can();

    can_init_completed = TRUE;

    return;
}


int_16 CdlWrPidWrF25BWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data)
{
	  if (len != sizeof(PidWrF25B))
	     {
	         return(1);
	     }

	  PidF25B = PidWrF25B = *src_data;

	  printf("PidWrF25B = %x\n",PidWrF25B);

	  /* Set flag to send request to Weigh App */
	  PidWrF25BFlag = 1;
	  printf("PidWrF25BFlag = %d\n",PidWrF25BFlag);
	  return(0);
}

int_16 CdlWrPidWrD00144WrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data)
{
	  if (len != sizeof(PidWrD00144))
	     {
	         return(1);
	     }
	  OEL_UNPACK_BE_16_NO_INCR(src_data,PidWrD00144);
	  PidD00144 = PidWrD00144;

	  printf("PidWrD00144 = %x\n",PidWrD00144);

	  /* Set flag to send request to Weigh App */
	  PidWrD00144Flag = 1;
	  printf("PidWrD00144Flag = %d\n",PidWrD00144Flag);
	  return(0);
}

int_16 CdlWrPidWrD0022CWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data)
{
	  if (len != sizeof(PidWrD0022C))
	     {
	         return(1);
	     }
	  OEL_UNPACK_BE_16_NO_INCR(src_data,PidWrD0022C);
	  PidD0022C = PidWrD0022C;
	 // getLogger().log_error("\nPidWrD0022C = %x\n",PidWrD0022C);
	  printf("PidWrD0022C = %x\n",PidWrD0022C);

	  /* Set flag to send request to Weigh App */
	  PidWrD0022CFlag = 1;
	  printf("PidWrD0022CFlag = %d\n",PidWrD0022CFlag);
	  return(0);
}
