/*******************************************************************************
***
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%                                                                        %%
*** %%  COPYRIGHT (C) 2013 CATERPILLAR INC.   ALL RIGHTS RESERVED.            %%
*** %%      This work contains proprietary information which may              %%
*** %%      constitute a trade secret and/or be confidential.                 %%
*** %%                                                                        %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***
*
*  File: app_can_init.h
*
*/

#ifndef __APP_CAN_INIT_H__
#define __APP_CAN_INIT_H__

#ifndef   APP_J1939_TABLES_H_
#include "app_j1939_tables.h"
#endif


#ifndef   SCL_RW_J1939_H_
#include <scl_rw_j1939.h>
#endif

#include <scl_j1939.h>
#include <cdl2_proto.h>

#ifndef   OEL_RTOS_POSIX_H_
#include <oel_rtos_posix.h>
#endif

#define DSI9_2U (UNKNOWN2U+FMIIUA)
#define DSI9_1U (UNKNOWN1U+FMIIUA)
/*********** Global procedures *******************************************/

 /* tx pit configuration for j1939 pgb */
 typedef struct app_scl_pgb_cdl_pie_s
 {
    unsigned_8 len;
    unsigned_32 *data;
    unsigned_32 pid;
    cdl2_tx_hdlr_t *tx_hdlr;
 }app_scl_pgb_cdl_pie_t;

 typedef struct
 {
	unsigned_8 len;
	unsigned_8 *data;
	unsigned_32 pid;
	Cdl_wr_hdlr_t *tx_hdlr;
 }app_scl_cdl_wr_pie_t;

void app_can_init(void);


/******************************************************************************
FUNCTION NAME: cdl_wr_backlight_percentage_hdlr()
DESCRIPTION: This is the write handler to program the Display Brightness via ET
BEFORE:  Assumes that the input arguments are initialized as follows:
         pie = pointer to data structure of type CdlWriteProgrammablePie_t
               pie->len = length of the write message
                          (programmable data length)
               pie->pdata = pointer to programmable data
                            (actually, data not used)
         len = length of the write message that was received
               (programmable data length)
         src_data = Pointer to where this routine should read the written
                    parameter data.  This pointer is to the internal area
                    where the J11939 data link message is being held.
AFTER:  Returns 1 if error occurred.
             Only caused by the display brightness message length being the
             wrong size.
        Returns 0 if OK.
             Everything worked correctly.
 
RETURN VALUE: Returns 1 if error occurred.
********************************************************************************/
unsigned_16 cdl_wr_backlight_percentage_hdlr(void  *pie,
                          unsigned_16  len,
                          unsigned_8  *src_data );
extern int can_port1;
// ECM J1939 Name
extern j1939_name_address_t j1939_name_address;
extern bool_t can_init_completed;
extern unsigned_8 app_master_mid;
extern unsigned_8 rtc_master_mid;
extern unsigned_8 rtc_type;
extern unsigned_8 rtc_security;
extern unsigned_16 j1939_mid;
extern unsigned_16 st_app_num;
extern unsigned_16 st_chg_lvl;
extern scl_j1939_link_t Ph_Link_app;

/* Backlight Percentage (Desired) 
//     This variable tells desired backlight percentage.
//     Will be set to unsigned 16.
//     It is scaled 1%/bit.
//     Will be set to unsigned fault ids when the value is unknown.
*/
extern uint16_t backlight_percentage_des;

/*Backlight Percentage Desired Overwrite
//     This is the parameter that the service tool writes to 
//     in order to set the backlight percentage.
//     Will be set to unsigned 16.
//     It is scaled 1%/bit.
//     Will be set to unsigned fault ids when the value is unknown.
*/
extern uint16_t backlight_percentage_over;

extern int_16 app_scl_pgb_cdl_fr_tx_hdlr(void *tx_pie, unsigned_8 *data);
extern int_16 app_scl_pgb_cdl_f_tx_hdlr(void *tx_pie, unsigned_8 *data);

extern int_16 CdlWrPidWrD01B24WrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrD009A7WrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrD009F5WrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrD112B2WrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrD10E4EWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrD00C9FWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrD0102DWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrD10ACCWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrF25BWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrD00144WrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrD0022CWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrD106C4WrHdlr(void *pie,unsigned_16  len,unsigned_16  *src_data);

extern char NewLpsSaWeighScsTxIn_;
extern char FlushLpsSaWeighScsTxIn_;
extern char WeighRangeBottomRqstFlg;
extern char WeighRangeSizeRqstFlg;


extern int_16 app_scl_pgb_cdl_fr_tx_hdlr(void *tx_pie, unsigned_8 *data);
extern int_16 app_scl_pgb_cdl_f_tx_hdlr(void *tx_pie, unsigned_8 *data);
extern int_16 CdlWrPidD00C9FWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidD0102DWrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);

extern int_16 CdlWrPidWrFC06WrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrFCF8WrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);
extern int_16 CdlWrPidWrFCF7WrHdlr(void *pie,unsigned_16  len,unsigned_8  *src_data);

#endif /* __APP_CAN_INIT_H__ */
 
