///////////////////////////////////////////////////////////////////////////////
/// @file      PayLdCtrlSysNotZeroed
/// @author    pf
/// @date      11/13/2017
/// @brief     Autonomy Condition for PayLdCtrlSysNotZeroed
///                                                                            
/// @attention Copyright (C) 2012                                              
/// @attention National Robotics Engineering Center                            
/// @attention Carnegie Mellon University                                      
/// @attention All rights reserved                                             
///////////////////////////////////////////////////////////////////////////////
#ifndef PayLdCtrlSysNotZeroed_h
#define PayLdCtrlSysNotZeroed_h

#include <string>
#include <ais/task/AutonomyCondition.h>

class PayLdCtrlSysNotZeroed : public AutonomyCondition
{
public:

  static std::string getConditionTypeString() {return "PayLdCtrlSysNotZeroed";}
  static const unsigned int activationDebounce_ms = 0;
  static const unsigned int deactivationDebounce_ms = 0;
  static const unsigned int timeToLive_ms = 86400000;

  PayLdCtrlSysNotZeroed(/*insert any needed arguments for message string*/):
    AutonomyCondition(getConditionTypeString(),
                      "/* insert condition message here*/",
                      activationDebounce_ms,
                      deactivationDebounce_ms,
                      timeToLive_ms)
  {}
};

#endif
