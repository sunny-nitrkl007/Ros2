///////////////////////////////////////////////////////////////////////////////
/// @file      TiltLinkFreqAbnormal
/// @author    pf
/// @date      10/4/2017
/// @brief     Autonomy Condition for TiltLinkFreqAbnormal
///                                                                            
/// @attention Copyright (C) 2012                                              
/// @attention National Robotics Engineering Center                            
/// @attention Carnegie Mellon University                                      
/// @attention All rights reserved                                             
///////////////////////////////////////////////////////////////////////////////
#ifndef TiltLinkFreqAbnormal_h
#define TiltLinkFreqAbnormal_h
#include <ais/task/AutonomyCondition.h>
#include <string>

class TiltLinkFreqAbnormal : public AutonomyCondition
{
public:

  static std::string getConditionTypeString() {return "TiltLinkFreqAbnormal";}
  static const unsigned int activationDebounce_ms = 1000;
  static const unsigned int deactivationDebounce_ms = 200;
  static const unsigned int timeToLive_ms = 86400000;

  TiltLinkFreqAbnormal(/*insert any needed arguments for message string*/):
    AutonomyCondition(getConditionTypeString(),
                      "Tilt Linkage Position Sensor: Abnormal Frequency, Pulse Width, or Period",
                      activationDebounce_ms,
                      deactivationDebounce_ms,
                      timeToLive_ms)
  {}
};

#endif
