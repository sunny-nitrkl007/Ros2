///////////////////////////////////////////////////////////////////////////////
/// @file      LiftREFreqAbnormal
/// @author    pf
/// @date      11/14/2017
/// @brief     Autonomy Condition for LiftREFreqAbnormal
///                                                                            
/// @attention Copyright (C) 2012                                              
/// @attention National Robotics Engineering Center                            
/// @attention Carnegie Mellon University                                      
/// @attention All rights reserved                                             
///////////////////////////////////////////////////////////////////////////////
#ifndef LiftREFreqAbnormal_h
#define LiftREFreqAbnormal_h

#include <string>
#include <ais/task/AutonomyCondition.h>

class LiftREFreqAbnormal : public AutonomyCondition
{
public:

  static std::string getConditionTypeString() {return "LiftREFreqAbnormal";}
  static const unsigned int activationDebounce_ms = 1000;
  static const unsigned int deactivationDebounce_ms = 200;
  static const unsigned int timeToLive_ms = 86400000;

  LiftREFreqAbnormal(/*insert any needed arguments for message string*/):
    AutonomyCondition(getConditionTypeString(),
                      "/* insert condition message here*/",
                      activationDebounce_ms,
                      deactivationDebounce_ms,
                      timeToLive_ms)
  {}
};

#endif
