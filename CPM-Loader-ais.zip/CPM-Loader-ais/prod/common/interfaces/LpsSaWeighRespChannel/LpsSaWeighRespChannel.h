#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>

#ifndef _LpsSaWeighRespChannel_h_
#define _LpsSaWeighRespChannel_h_

typedef enum
{
	  LPS_SA_WEIGH_ZERO_SUCCESS,
	  LPS_SA_WEIGH_ZERO_FAIL,
	  LPS_SA_WEIGH_ZERO_UNKNOWN
}LpsSaWeighZeroRespCode_t;

typedef enum
{
	  LPS_SA_WEIGH_BEST_BKT_RST_SUCCESS,
	  LPS_SA_WEIGH_BEST_BKT_RST_FAIL,
	  LPS_SA_WEIGH_BEST_BKT_RST_UNKNOWN
}LpsSaBestBktRstRespCode_t;

typedef enum
 {
	  LPS_SA_WEIGH_CAPT_CYL_EXTN_REF_SUCCESS,
	  LPS_SA_WEIGH_CAPT_CYL_EXTN_REF_FAIL,
	  LPS_SA_WEIGH_CAPT_CYL_EXTN_REF_UNKNOWN
}LpsSaCaptCylExtRefRespCode_t;

typedef enum
 {
	  LPS_SA_WEIGH_CLEAR_REWEIGH_WARNING_SUCCESS,
	  LPS_SA_WEIGH_CLEAR_REWEIGH_WARNING_FAIL,
	  LPS_SA_WEIGH_CLEAR_REWEIGH_WARNING_UNKNOWN
}LpsSaClearReweighWarningRespCode_t;

typedef enum
{
	  LPS_SA_WEIGH_RANGE_SUCCESS,
	  LPS_SA_WEIGH_RANGE_FAIL,
	  LPS_SA_WEIGH_RANGE_UNKNOWN
}LpsSaWeighRangeRespCode_t;


class LpsSaWeighRespChannelStorage: public csvable
{  
public:  

	
	/* SCS Weigh App Interfaces */
	LpsSaWeighZeroRespCode_t  ZeroResp;
	LpsSaBestBktRstRespCode_t BestBktRstResp;
	LpsSaCaptCylExtRefRespCode_t CaptCylExtRefResp;
	LpsSaWeighRangeRespCode_t  WeighRangeResp;
	LpsSaClearReweighWarningRespCode_t  ClearReweighWarningResp;

     LpsSaWeighRespChannelStorage() /* Initialize Fields Here */{ }

     template <class Archive>
     void serialize(Archive &ar, unsigned int version)
     {
         	ar & ZeroResp;
    	 	ar & BestBktRstResp;
    	 	ar & CaptCylExtRefResp;
    	 	ar & WeighRangeResp;

    	 	ar & ClearReweighWarningResp;

     }

     void toCsv(CsvOutStream& out) const
     {
        out("Best Available Bucket Weight Response Code",BestBktRstResp);
        out("Zero Response Code",ZeroResp);
        out("CaptCylExtRef Response Code",CaptCylExtRefResp);
        out("Weigh Range Response Code",WeighRangeResp);
        out("Clear Reweigh Warning Response Code",WeighRangeResp);
     }

 private:  
     /* Add Fields Here */
};  

typedef Datum<LpsSaWeighRespChannelStorage> LpsSaWeighRespChannel;

BOOST_CLASS_VERSION(LpsSaWeighRespChannelStorage, 1);
#endif

