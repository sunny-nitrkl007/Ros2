#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>
#include <interfaces/LpsSaWeighTxChannel/InterfaceTypes.h>

#ifndef _LpsSaWeighReqstChannel_h_
#define _LpsSaWeighReqstChannel_h_

typedef struct
{
    bool 	WeighRangeReqstFlag;
    float 	WeighRangeBottom; /* weigh range Bottom in % */
    float 	WeighRangeSize; /* weigh range Size in %  */
}WeighRangeRequest_t;

typedef struct
{
	bool  newCalWtFlag;
	float newCalWt;
}CalWt_t;

class LpsSaWeighReqstChannelStorage: public csvable
{
public:
	typedef struct
	{
		PloadOvrloadWarnEn_t 		PloadOvrloadWarnEn;
		float 						LoaderBktPloadTgtWt;/* - Loader Bucket Payload Target Weight [1]*/
		PloadSysCalWtEntryReqStat_t PloadSysCalWtEntryReqStat;
		float 						LastPloadWt;/* - Last Payload Weight [255]*/
	}WeighPidWrData_t;

	bool PloadOvrloadWarnEnReq;
	bool LastPloadWtSetReq ;/*  - Payload Control System Calibration Weight [1] */
	bool LoaderBktPloadTgtWtSetReq;
	bool ZeroReqst;
	bool BestBktRstReqst;
	bool CaptCylExtRef;
	bool ClearReweighWarnReqst;

	LpsSaWeighRange_t           WeighRange; /* weigh range */
	WeighRangeRequest_t 		WeighRangeRequest;
	CalWt_t 					SetCalWtRequest;
	WeighPidWrData_t 			PidWrData;

	/* Initialize Fields Here */
	LpsSaWeighReqstChannelStorage() : ZeroReqst ( false ),
			BestBktRstReqst ( false ),
			CaptCylExtRef ( false ),
			ClearReweighWarnReqst( false ),
			LastPloadWtSetReq( false ),
			LoaderBktPloadTgtWtSetReq (false ),
			PloadOvrloadWarnEnReq (false )
	{
		WeighRangeRequest.WeighRangeReqstFlag = false;
		WeighRangeRequest.WeighRangeBottom = 0;
		WeighRangeRequest.WeighRangeSize = 0;
		SetCalWtRequest.newCalWtFlag = false;
		SetCalWtRequest.newCalWt = 0;
		WeighRange.WeighRangeBottom = 0;
		WeighRange.WeighRangeSize = 0;
		PidWrData.PloadOvrloadWarnEn = OVR_LOAD_WARN_DISABLED;
		PidWrData.LastPloadWt = 0;
		PidWrData.LoaderBktPloadTgtWt = 0;
	}

	template <class Archive>
	void serialize(Archive &ar, unsigned int version)
	{
		ar & ZeroReqst;
		ar & BestBktRstReqst;
		ar & CaptCylExtRef;
		ar & ClearReweighWarnReqst;
		ar & WeighRangeRequest.WeighRangeReqstFlag;
		ar & WeighRangeRequest.WeighRangeBottom;
		ar & WeighRangeRequest.WeighRangeSize;
		ar & SetCalWtRequest.newCalWtFlag;
		ar & SetCalWtRequest.newCalWt;
		ar & LastPloadWtSetReq;
		ar & WeighRange.WeighRangeBottom;
		ar & WeighRange.WeighRangeSize;
		ar & PidWrData.PloadOvrloadWarnEn;
		ar & PidWrData.LastPloadWt;
		ar & PidWrData.LoaderBktPloadTgtWt;
		ar & LoaderBktPloadTgtWtSetReq;
		ar & PloadOvrloadWarnEnReq;
	}

	void toCsv(CsvOutStream& out) const
	{
		out("Best Available Bucket Weight Request Code",(unsigned int)BestBktRstReqst);
		out("Zero Response Code",(unsigned int)ZeroReqst);
		out("Capture cylinder ext reference",(unsigned int)CaptCylExtRef);
		out("Clear reweigh warning request",(unsigned int)ClearReweighWarnReqst);
		out("Weigh Range Request Flag",WeighRangeRequest.WeighRangeReqstFlag);
		out("Weigh Range Bottom Val",WeighRangeRequest.WeighRangeBottom);
		out("Weigh Range Size",WeighRangeRequest.WeighRangeSize);
		out("New Cal weight flag",SetCalWtRequest.newCalWtFlag);
		out("New Cal Weight Value",SetCalWtRequest.newCalWt);
		//out("Cal id ",CalibrationRequest.Cal_id);
		out("PloadOvrloadWarnEnReq",(unsigned int)PloadOvrloadWarnEnReq);
		out("LastPloadWtSetReq",(unsigned int)LastPloadWtSetReq);
		out("PidWrData.LastPloadWt", PidWrData.LastPloadWt);
		out("PidWrData.LoaderBktPloadTgtWt", PidWrData.LoaderBktPloadTgtWt);
		out("LoaderBktPloadTgtWtSetReq",(unsigned int)LoaderBktPloadTgtWtSetReq);
		out("PidWrData.PloadOvrloadWarnEn",(unsigned int)PidWrData.PloadOvrloadWarnEn);
	}

private:
     /* Add Fields Here */
};

typedef Datum<LpsSaWeighReqstChannelStorage> LpsSaWeighReqstChannel;

BOOST_CLASS_VERSION(LpsSaWeighReqstChannelStorage, 1);
#endif



