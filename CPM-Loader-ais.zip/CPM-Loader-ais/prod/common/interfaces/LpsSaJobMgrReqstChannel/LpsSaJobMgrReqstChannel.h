#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>
#ifndef _LpsSaJobMgrReqstChannel_h_
#define _LpsSaJobMgrReqstChannel_h_
#include <interfaces/LpsSaJobMgrTxChannel/InterfaceTypes.h>

/*Target Weight request structure*/
typedef struct
{
	bool      ReqstFlag;
	float     TargetWeightVal;
}TargetWeightReqst_t;


typedef struct
{
	bool     ReqstFlag;
	LpsSaTipOffTriggerType_t   Type;

}LpsSaTipOffTriggerTypeReqst_t;


typedef struct
{
	bool     ReqstFlag;
	LpsSaJobMgrTipOffState_t  State;

}LpsSaTipOffStateReqst_t;

typedef struct
{
	bool     ReqstFlag;
	int      Data;

}LifetimeTruckLoadCount_t;

typedef struct
{
	bool     ReqstFlag;
	double      Data;

}LifetimeTotalPayload_t;

typedef struct
{
	bool     ReqstFlag;
	int      Data;

}LifetimePayloadPassCount_t;


/*Horn Store State request structure*/
typedef struct
{
   bool      ReqstFlag;
   bool      Enable;
}HornStoreStateReqst_t;


class LpsSaJobMgrReqstChannelStorage: public csvable
{
public:
	/* All below Request to Job Manager App,if
		"true" =  command/request issued to Job Manager App
		 if "false" =  command/request cleared to Job Manager App
		 */
	/* SCS Weigh App Interfaces */
	bool ZeroReqst;
	bool MinusOneReqst;
	bool ClearReqst;
	bool StoreReqst;
	bool StandByActReqst;
	bool StandByDeactReqst;
	bool TruckPileTipOffToggleReqst;
	bool ManualTipOffActReqst;
	bool ManualTipOffDeactReqst;
   bool ReWeighReqst;
	LpsSaTipOffTriggerTypeReqst_t TipOffTrigger;
	LpsSaTipOffStateReqst_t TipOffState;
	TargetWeightReqst_t TargetWeightReqst;
	LifetimeTruckLoadCount_t LifetimeTruckLoadCount;
	LifetimeTotalPayload_t LifetimeTotalPayload;
	LifetimePayloadPassCount_t LifetimePayloadPassCount;
	HornStoreStateReqst_t HornStoreStateReqst;

     LpsSaJobMgrReqstChannelStorage() : /* Initialize Fields Here */
    	 ZeroReqst(false),
    	 MinusOneReqst(false),
    	 ClearReqst(false),
    	 StoreReqst(false),
    	 StandByActReqst(false),
    	 StandByDeactReqst(false),
    	 TruckPileTipOffToggleReqst(false),
    	 ManualTipOffActReqst(false),
    	 ManualTipOffDeactReqst(false),
    	 ReWeighReqst(false)
     {
    		 TipOffTrigger.ReqstFlag = false;
          TipOffTrigger.Type = 0;
    		 TipOffState.ReqstFlag = false;
    		 TipOffState.State = 0;
    		 TargetWeightReqst.ReqstFlag = false;
          TargetWeightReqst.TargetWeightVal = 0.0;
    		 LifetimeTruckLoadCount.ReqstFlag = false;
          LifetimeTruckLoadCount.Data = 0;
    		 LifetimeTotalPayload.ReqstFlag = false;
          LifetimeTotalPayload.Data = 0.0;
    		 LifetimePayloadPassCount.ReqstFlag = false;
          LifetimePayloadPassCount.Data = 0;
    		 HornStoreStateReqst.ReqstFlag = false;
          HornStoreStateReqst.Enable = false;
     }

     template <class Archive>
	void serialize(Archive &ar, unsigned int version)
    {
		/* Archive Fields Here */
		ar & ZeroReqst;
		ar & MinusOneReqst;
		ar & ClearReqst;
		ar & StoreReqst;
		ar & StandByActReqst;
		ar & StandByDeactReqst;
		ar & TruckPileTipOffToggleReqst;
		ar & ManualTipOffActReqst;
		ar & ManualTipOffDeactReqst;
		ar & ReWeighReqst;
        ar & TipOffTrigger.ReqstFlag;
		ar & TipOffTrigger.Type;
		ar & TipOffState.ReqstFlag;
		ar & TipOffState.State;
		ar & TargetWeightReqst.ReqstFlag;
		ar & TargetWeightReqst.TargetWeightVal;


		ar & LifetimeTruckLoadCount.ReqstFlag;
		ar & LifetimeTruckLoadCount.Data;
		ar & LifetimeTotalPayload.ReqstFlag;
		ar & LifetimeTotalPayload.Data;
		ar & LifetimePayloadPassCount.ReqstFlag;
		ar & LifetimePayloadPassCount.Data;
		ar & HornStoreStateReqst.ReqstFlag;
		ar & HornStoreStateReqst.Enable;
    }
	void toCsv(CsvOutStream& out) const
	{
		out("Zero  Request", (unsigned int) ZeroReqst);
		out("Minus One Request", (unsigned int) MinusOneReqst);
		out("Clear Request", (unsigned int) ClearReqst);
		out("Store  Request", (unsigned int) StoreReqst);
		out("StandBy Act  Request", (unsigned int) StandByActReqst);
		out("StandBy Deact  Request", (unsigned int) StandByDeactReqst);
		out("TruckPile_Tip_Off  Request", (unsigned int) TruckPileTipOffToggleReqst);
		out("Manual Tip_Off_Activated  Request", (unsigned int) ManualTipOffActReqst);
		out("Manual Tip_Off_Deactivated  Request", (unsigned int) ManualTipOffDeactReqst);
		out("ReWeigh  Request", (unsigned int) ReWeighReqst);
		out("Tip-off Trigger Type  Request flag", (unsigned int) TipOffTrigger.ReqstFlag);
		out("Tip-off Trigger Type Request", (unsigned int) TipOffTrigger.Type);
		out("Tip-off State Request flag", (unsigned int) TipOffState.ReqstFlag);
		out("Tip-off State Request", (unsigned int) TipOffState.State);
		out("Target Weight  Request", (unsigned int) TargetWeightReqst.ReqstFlag);
		out("Horn Store State Request Flag", (unsigned int) HornStoreStateReqst.ReqstFlag);
		out("Horn Store State Request Enable", (unsigned int) HornStoreStateReqst.Enable);
	}

 private:  
     /* Add Fields Here */
};  

typedef Datum<LpsSaJobMgrReqstChannelStorage> LpsSaJobMgrReqstChannel;

BOOST_CLASS_VERSION(LpsSaJobMgrReqstChannelStorage, 1);
#endif

