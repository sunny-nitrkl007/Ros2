#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>
#include <string.h>

#ifndef __LPS_COMMON_TYPE_DEF_H__
#include <LpsCommonTypeDef.h>
#endif

#ifndef __CPM_FILTER_H__
#include <cpm_filter.h>
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h>
#endif

#ifndef __LPS_PUBLIC_H__
#include <LpsPublic.h>
#endif

#ifndef __LPS_PRIVATE_H__
#include <LpsPrivate.h>
#endif

#ifndef __LPS_SA_INCLUDES_H__
#include <LpsSaWeighApp/LpsSaIncludes.h>
#endif


#ifndef _LpsSaWeighDebugChannel_h_
#define _LpsSaWeighDebugChannel_h_
class LpsSaWeighDebugChannelStorage: public csvable
{  
public:  
     LpsSaWeighDebugChannelStorage()  /* Initialize Fields Here */
     {
    	 m_weighUpdtTbl.ZeroButtonPress = false;
    	 m_LpsWrk.DigDetectData.DigDetected = false;
    	 m_LpsWrk.DigDetectData.WtStabilized = false;
    	 m_LpsWrk.WrwTbl.WkTbl.BeenBelowRange = false;
    	 m_LpsWrk.ZeroAdjTbl.TooHeavyToZero = false;
    	 m_LpsWrk.ZeroAdjTbl.ZeroAccepted = false;
     }

     template <class Archive>
     void serialize(Archive &ar, unsigned int version)
     {
       /* Archive Fields Here */
    	 /* Lift Cylinder Head End Pressure */
    	 ar & DebugLiftCylHePeriod;
    	 ar & DebugLiftCylHeWidth;
    	 ar & DebugLiftCylHeDc;
    	 ar & DebugLiftCylHePress;

    	 /* Lift Cylinder Rod End Pressure */
    	 ar & DebugLiftCylRePeriod;
    	 ar & DebugLiftCylReWidth;
    	 ar & DebugLiftCylReDc;
    	 ar & DebugLiftCylRePress;

    	 /* Lift Cylinder */
    	 ar & DebugLiftCylPeriod;
    	 ar & DebugLiftCylWidth;
    	 ar & DebugLiftCylDc;
    	 ar & DebugLiftCylRawExt;
    	 ar & DebugLiftCylFiltExt;
    	 ar & DebugLiftCylNormExt;
    	 ar & DebugLiftCylVel;
    	 ar & DebugLiftAngle;

    	 /* Tilt Cylinder */
    	 ar & DebugTiltCylPeriod;
    	 ar & DebugTiltCylWidth;
    	 ar & DebugTiltCylDc;
    	 ar & DebugTiltCylRawExt;
    	 ar & DebugTiltCylVel;
    	 ar & DebugTiltAngle;
    	 ar & DebugTiltAngleABC;

    	 /* LpsUpdtTbl_t m_weighUpdtTbl */
    	 ar & m_weighUpdtTbl.BktAngle.Stat;
    	 ar & m_weighUpdtTbl.BktAngle.Val;
    	 ar & m_weighUpdtTbl.HydOilTemp.Stat;
    	 ar & m_weighUpdtTbl.HydOilTemp.Val;
    	 ar & m_weighUpdtTbl.LiftCylExt.Stat;
    	 ar & m_weighUpdtTbl.LiftCylExt.Val;
    	 ar & m_weighUpdtTbl.LiftCylHePres.Stat;
    	 ar & m_weighUpdtTbl.LiftCylHePres.Val;
    	 ar & m_weighUpdtTbl.LiftCylRePres.Stat;
    	 ar & m_weighUpdtTbl.LiftCylRePres.Val;
    	 ar & m_weighUpdtTbl.LiftCylVel.Stat;
    	 ar & m_weighUpdtTbl.LiftCylVel.Val;
    	 ar & m_weighUpdtTbl.LoaderBktPayldTrgtWt;
    	 ar & m_weighUpdtTbl.ClockKeyonSec;
    	 ar & m_weighUpdtTbl.PassCount;
    	 ar & m_weighUpdtTbl.RequestedGear.Val;
    	 ar & m_weighUpdtTbl.RequestedGear.Stat;
    	 ar & m_weighUpdtTbl.TiltCylExt.Stat;
    	 ar & m_weighUpdtTbl.TiltCylExt.Val;
    	 ar & m_weighUpdtTbl.TiltCylVel.Stat;
    	 ar & m_weighUpdtTbl.TiltCylVel.Val;
    	 ar & m_weighUpdtTbl.UseFastFilter;
    	 ar & m_weighUpdtTbl.ZeroButtonPress;

    	 /* LpsWrkTbl_t m_LpsWrk */
    	 ar & m_LpsWrk.BestBktWt.PayloadCalcMeth;
    	 ar & m_LpsWrk.BestBktWt.Wt;
    	 ar & m_LpsWrk.CylFlowConst.LiftHeFlowConst;
    	 ar & m_LpsWrk.CylFlowConst.LiftReToHeFlowRatio;
    	 ar & m_LpsWrk.DigDetectData.DigDetected;
    	 ar & m_LpsWrk.DigDetectData.DigDuration;
    	 ar & m_LpsWrk.DigDetectData.DigStarted;
    	 ar & m_LpsWrk.DigDetectData.DigState;
    	 ar & m_LpsWrk.DigDetectData.WtStabilized;
    	 ar & m_LpsWrk.DumpWtChangeData.DumpCumulativeWtChange;
    	 ar & m_LpsWrk.InstWtDer;
    	 ar & m_LpsWrk.InstWtFilt;
    	 ar & m_LpsWrk.InstWtLlwFilt;
    	 ar & m_LpsWrk.InstWtRaw.Stat;
    	 ar & m_LpsWrk.InstWtRaw.Val;
    	 ar & m_LpsWrk.LiftCylPres;
    	 ar & m_LpsWrk.LiveWeighTbl.Stat;
    	 ar & m_LpsWrk.LiveWeighTbl.Wt;
    	 ar & m_LpsWrk.LowLiftWt.Wt;
    	 ar & m_LpsWrk.LowLiftWt.Confidence;
    	 ar & m_LpsWrk.LowLiftWt.ConfidenceEst;
    	 ar & m_LpsWrk.LowLiftWt.ConfidenceTimer;
    	 ar & m_LpsWrk.LowLiftWt.LastInput;
    	 ar & m_LpsWrk.LowLiftWt.MeanEst;
    	 ar & m_LpsWrk.LowLiftWt.MeanEstComp;
    	 ar & m_LpsWrk.LowLiftWt.Stat;
    	 ar & m_LpsWrk.LowLiftWt.StdevEst;
    	 ar & m_LpsWrk.LowLiftWt.VarianceEst;
    	 ar & m_LpsWrk.DumpStateStatus;
    	 ar & m_LpsWrk.LpsStallDetect.LiftStallStat;
    	 ar & m_LpsWrk.LinkageMovement.lift;
    	 ar & m_LpsWrk.LinkageMovement.tilt;
    	 ar & m_LpsWrk.WrwTbl.OpTbl.Wt;
    	 ar & m_LpsWrk.WrwTbl.OpTbl.Warning;
    	 ar & m_LpsWrk.WrwTbl.OpTbl.Indicator;
    	 ar & m_LpsWrk.WrwTbl.OpTbl.Status;
    	 memcpy (&reweighWarn, &m_LpsWrk.WrwTbl.ReweighWarn, sizeof(reweighWarn));
    	 ar & reweighWarn;
    	 ar & m_LpsWrk.WrwTbl.WkTbl.BeenBelowRange;
    	 ar & m_LpsWrk.ZeroAdjTbl.TooHeavyToZero;
    	 ar & m_LpsWrk.ZeroAdjTbl.ZeroAccepted;
    	 ar & m_LpsWrk.ZeroAdjTbl.ZeroAdjStatus;
     }

     void toCsv(CsvOutStream& out) const
     {
    	 //out("Minus One JobMgr Response Code", MinusOneResp);
     }

     LpsUpdtTbl_t m_weighUpdtTbl;
     LpsWrkTbl_t m_LpsWrk;

     /* bitwise to unsigned_16 */
     unsigned_16 reweighWarn;

     /* Lift Cylinder Head End Pressure */
     int DebugLiftCylHePeriod;
     int DebugLiftCylHeWidth;
     float_32 DebugLiftCylHeDc;
     float_32 DebugLiftCylHePress;

     /* Lift Cylinder Rod End Pressure */
     int DebugLiftCylRePeriod;
     int DebugLiftCylReWidth;
     float_32 DebugLiftCylReDc;
     float_32 DebugLiftCylRePress;

     /* Lift Cylinder */
     int DebugLiftCylPeriod;
     int DebugLiftCylWidth;
     float_32 DebugLiftCylDc;
     float_32 DebugLiftCylRawExt;
     float_32 DebugLiftCylFiltExt;
     float_32 DebugLiftCylNormExt;
     float_32 DebugLiftCylVel;
     float_32 DebugLiftAngle;

     /* Tilt Cylinder */
     int DebugTiltCylPeriod;
     int DebugTiltCylWidth;
     float_32 DebugTiltCylDc;
     float_32 DebugTiltCylRawExt;
     float_32 DebugTiltCylVel;
     float_32 DebugTiltAngle;
     float_32 DebugTiltAngleABC;

 private:
     /* Add Fields Here */

};  

typedef Datum<LpsSaWeighDebugChannelStorage> LpsSaWeighDebugChannel;

BOOST_CLASS_VERSION(LpsSaWeighDebugChannelStorage, 1);
#endif

