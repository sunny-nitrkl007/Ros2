///////////////////////////////////////////////////////////////////////////////
// @attention COPYRIGHT (C) 2011-2015 CATERPILLAR INC. ALL RIGHTS RESERVED.
//
// @file    LpsSaWeighTxChannel.h
//
// @brief   This is the interface parameters for Weighing App
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// -- #Include's --
///////////////////////////////////////////////////////////////////////////////

#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>
#include <cat_std_types.h>

#ifndef _LpsSaWeighTxChannel_h_
#define _LpsSaWeighTxChannel_h_

typedef enum
{
    LPS_SA_WEIGH_CYL_VEL_STAT_OK = 0,
	LPS_SA_WEIGH_CYL_VEL_STAT_BAD
}LpsSaWeighLiftCylVelStat_t;


typedef enum
{		
	LPS_SA_WEIGH_SYSTEM_CALIBRATED = 0,
	LPS_SA_WEIGH_SYSTEM_UNCALIBRATED
}LpsSaWeighCalStatus_t;


typedef enum
{
 	LPS_SA_WEIGHT_BKT_DUMP_STATE_UNKNOWN = 0,
 	LPS_SA_WEIGHT_BKT_FULLY_RACKED,
 	LPS_SA_WEIGHT_BKT_NOT_RACKED_AND_NOT_DUMPED,
 	LPS_SA_WEIGHT_BKT_PARTIALLY_DUMPED,
 	LPS_SA_WEIGHT_BKT_FULLY_DUMPED
}LpsSaWeighBktDumpStat_t;


typedef enum{
 LPS_SA_WEIGHT_BKT_DIG_STATE_UNKNOWN = 0,
 LPS_SA_WEIGHT_BKT_NOT_DIGGING,
 LPS_SA_WEIGHT_BKT_TENTATIVE_DIGGING,
 LPS_SA_WEIGHT_BKT_DIGGING
}LpsSaWeighBktDigStat_t;


typedef struct
{
  float	WeighRangeBottom; /* weigh range Bottom in % */
  float	WeighRangeSize;   /* weigh range Size in %   */
}LpsSaWeighRange_t;


typedef enum
{
    LPS_SA_WEIGH_CYL_EXT_STAT_OK = 0,
    LPS_SA_WEIGH_CYL_EXT_STAT_BAD
}LpsSaWeighCylExtStat_t;


typedef struct
{
	LpsSaWeighCylExtStat_t Stat; /* Lift Cylinder Extension Status */
	float      Val; /* Lift Cylinder Extension in % of full cylinder extension */
}LpsSaWeighLiftCylExt_t;


typedef struct
{
	float 				LiftCylVel;

}LpsSaWeighCalParam_t;


typedef struct
{
	float LiftLinkDC;     /* 0xF13D  */
	float LiftCylPos;     /* 0xF5AE  */
	float LiftCylHEPres;  /* 0xF47B  */
	float LiftCylREPres;  /* 0xF5AF  */
	float TiltLinkDC;     /* 0xF13E  */
	float HydOilTemp;     /* 0x0045  */
	float LiftCylExt;     
        float TiltCylExt;        
	float LiftCylExtMm;   /* 0x00D0018B - 1 mm/bit */
        float TiltCylExtMm;   /* 0x00D0018C - 1 mm/bit*/     
        float BktAngle;       /* 0x00D00A70 -  0.1 degree/bit  */
}ProdMeasureSensorStatus_t;


typedef struct
{
	float LiftPosSensorDC; /* 0xF13D  */
	float 	LiftPosSensorFullRaiseDC; /* 0x00D010FA  */
	float 	LiftPosSensorFullLowerDC; /* 0x00D010FB  */
	float TiltPosSensorDC; /* 0xF13E  */
	float	TiltPosSensorFullRackDC; /* 0x00D010FC  */
	float	TiltPosSensorFullDumpDC; /* 0x00D010FD  */
}LinkSensorCalLim_t;

typedef enum
{
	ZEROED =0x0394,
	NOT_ZEROED = 0x0395
}PloadSysZeroStat_t;

typedef enum
{
	OVR_LOAD_WARN_ENABLED = 0x000C,
	OVR_LOAD_WARN_DISABLED = 0x000D
}PloadOvrloadWarnEn_t;

typedef enum
{
	CAL_ENTRY_REQUIRED = 0x001A,
	CAL_ENTRY_NOT_REQUIRED = 0x001B
}PloadSysCalWtEntryReqStat_t;

typedef enum
{
	NOT_AVAILABLE =0,
	AVAILABLE =1,
	STORED =2
}BktPayloadData_t;

typedef union
{
	struct bitfield
	{
		unsigned int Unused:22;	 					 				/* LSB. bit 0 */
		unsigned int SimpleCalAccepted:1;
		unsigned int ZeroUpdateZeroAccepted:1;
		unsigned int ReWeighLiftTooSlow:1;
		unsigned int ReWeighStoppedInWRG:1;
		unsigned int ReWeighBucketNotRacked:1;
		unsigned int ReWeighSpeedCHG2HI:1;
		unsigned int ReWeighInconsistent:1;
		unsigned int ReWeighPressureCHG2HI:1;
		unsigned int UpperStall:1;
		unsigned int LowerStall:1;    				 				/* MSB. bit 31 */
	}flag;

	unsigned int Data;

}ACDInfoPopUp_t;

typedef union
{
	struct bitfield
	{
		unsigned int Unused:7;                      /* LSB. bit 0 */
		unsigned int LowerStall:1;
		unsigned int UpperStall:1;
		unsigned int InsufficentData:1;
		unsigned int ReWeighPressureCHG2HI:1;
		unsigned int ReWeighInconsistent:1;
		unsigned int ReWeighSpeedCHG2HI:1;
		unsigned int ReWeighBucketNotRacked:1;
		unsigned int ReWeighStoppedInWRG:1;
		unsigned int ReWeighLiftTooSlow:1;            /* MSB. bit 15 */

	}flag;

	unsigned int Data;

}ACDWeighStatus_t;



typedef union
{
	struct bitfield
	{
		unsigned int Unused:14;	 					/* LSB. bit 0 */
		unsigned int HydraulicOilTempBad:1;
		unsigned int MachineModelNotSet:1;
		unsigned int PaylodMonSystemNotInstalled:1;
		unsigned int PayloadMonSystemOutOfCal:1;
		unsigned int LiftREFreqAbnormal:1;
		unsigned int LiftREVoltageBelow:1;
		unsigned int LiftREVoltageAbove:1;

		unsigned int LiftHEFreqAbnormal:1;
		unsigned int LiftHEVoltageBelow:1;
		unsigned int LiftHEVoltageAbove:1;

		unsigned int LiftLinkOutOfCal:1;
		unsigned int LiftLinkFreqAbnormal:1;
		unsigned int LiftLinkVoltageBelow:1;
		unsigned int LiftLinkVoltageAbove:1;

		unsigned int TiltLinkOutOfCal:1;
		unsigned int TiltLinkFreqAbnormal:1;
		unsigned int TiltLinkVoltageBelow:1;
		unsigned int TiltLinkVoltageAbove:1;		 /* MSB. bit 31 */
	}flag;

	unsigned int Data;

}ACDDiagPopUp_t;

typedef union
{
	struct bitfield
	{
		unsigned int Unused:28;									   /* LSB. bit 0 */
		unsigned int ctrlSysNotZeroEvntTemp:1;
		unsigned int zeroTooHeavyEvnt:1;
		unsigned int ctrlSysNotZeroEvntTime:1;
		unsigned int overLoadLimitExceed:1;    				 	   /* MSB. bit 31 */
	}flag;

	unsigned int Data;

}ACDEventPopUp_t;


class LpsSaWeighTxChannelStorage: public csvable
{  
public:

	typedef struct
	{
		PloadSysZeroStat_t	PloadSysZeroStat; /* 0x00D10822  */
		unsigned short int	LdrPayloadStat;/* 0x00D106DF   */
		PloadOvrloadWarnEn_t PloadOvrloadWarnEn;/* 0x00D10ACC   */
		ProdMeasureSensorStatus_t 	ProdMeasureSensorStatus;/* 0x00D10822  */
		LinkSensorCalLim_t	LinkSensorCalLim;/* 0x00D10822  */
		float LoaderBktPloadTgtWt;/* 0x00D10822  */
		float LoaderBktPloadTgtWtPer;/* 0x00D10822  */
		float PloadConSysCalWt;/* 0x00D10822  */
		unsigned short int PloadSysZeroReqStat;/* 0x00D10822  */
		PloadSysCalWtEntryReqStat_t PloadSysCalWtEntryReqStat;/* 0x00D10822  */
		float 		LastPloadWt;/* 0x00D10822  */
		ACDWeighStatus_t ProdMeasureWeighStatus;
		//unsigned short int	ProdMeasureWeighStatus;/* 0x00D10822  */
		BktPayloadData_t BktPayloadData;/* 0x00D10822  */
	}WeighPidData_t;

    typedef struct
	{
		LpsSaWeighLiftCylVelStat_t 	Stat;
		float 				MilliPerSec; /* Lift Cyclinder Velocity in mm/sec */
	}LpsSaWeighLiftCylVel_t;

	typedef enum{
	    LPS_BELOW_WEIGH_RANGE = 0x0323,
	    LPS_IN_WEIGH_RANGE_WEIGHING = 0x0325,
	    LPS_ABOVE_WEIGH_RANGE = 0x0326,
	    LPS_IN_WEIGH_RANGE_NOT_WEIGHING = 0x06CD
	}LpsWeighRangeIndicator_t;

	/* SCS Weigh App Interfaces */
	LpsSaWeighBktDigStat_t		DigStat; /* Machine Dig Status */
	LpsSaWeighCalStatus_t 		CalStat; /* Lps System Calibration Status */
	LpsSaWeighBktDumpStat_t 	DumpStat; /* Machine Dump Status */
	float 						BestBktWtInTonnes; /* Best Available Bucket Weight in metric Tonne */
	unsigned int 				ZeroNotifyStat; /* Zero bucket notify status*/
	unsigned short int 			PayloadCalcMeth; /* Payload Calculation method */
	bool						bktWtLatchedFlag;	/* indicates if we have a latched bucket weight */
	bool						latchConditionsMet; /* indicates if latch conditions are ok */
	LpsSaWeighLiftCylVel_t		LiftCylVel; /* Lift Cyclinder Velocity */
	LpsSaWeighRange_t           WeighRange; /* weigh range */
	LpsSaWeighLiftCylExt_t		LiftCylExt; /* Lift Cylinder Extension */
	LpsSaWeighCalParam_t 		CalParam;/* calibration parameter */
	LpsWeighRangeIndicator_t    Indicator;
	float 						CalWt;

    bool                    	PayloadAvailable;
	ACDEventPopUp_t				EventState;
	ACDDiagPopUp_t				DiagState;
	ACDInfoPopUp_t 				InfoState;
	bool						ShowExclamationPoint;
	float						SimpleCalAdjustment; /* The Simple Cal Adjustment Factor calculated and sent. */
	WeighPidData_t 				PidData; /* Data needs to be sent to AutonomyconditionDiagnostics App */
	
	LpsSaWeighTxChannelStorage() : ShowExclamationPoint(false), /* Initialize Fields Here */
				PayloadAvailable(false),
				latchConditionsMet(false),
				bktWtLatchedFlag(false)
	{}

     template <class Archive>

     void serialize(Archive &ar, unsigned int version)
     {
      	ar & DigStat;
      	ar & CalStat;
      	ar & DumpStat;
      	ar & BestBktWtInTonnes;
      	ar & PidData.BktPayloadData;
      	ar & ZeroNotifyStat;
      	ar & PayloadCalcMeth;
		ar & bktWtLatchedFlag;
		ar & latchConditionsMet;
      	ar & LiftCylVel.Stat;
      	ar & LiftCylVel.MilliPerSec;
      	ar & WeighRange.WeighRangeBottom;
      	ar & WeighRange.WeighRangeSize;
      	ar & PidData.PloadOvrloadWarnEn;
      	ar & LiftCylExt.Val;
      	ar & LiftCylExt.Stat;
		ar & CalParam.LiftCylVel;
		ar & Indicator;
		ar & CalWt;
		ar & PayloadAvailable;
		ar & EventState.Data;
		ar & DiagState.Data;
		ar & InfoState.Data;
		ar & ShowExclamationPoint;
		ar & SimpleCalAdjustment;
		ar & PidData.ProdMeasureWeighStatus.Data;
		ar & PidData.ProdMeasureSensorStatus.LiftCylHEPres;
		ar & PidData.ProdMeasureSensorStatus.LiftCylPos;
		ar & PidData.ProdMeasureSensorStatus.LiftCylREPres;
		ar & PidData.ProdMeasureSensorStatus.LiftLinkDC;
		ar & PidData.ProdMeasureSensorStatus.TiltLinkDC;
		ar & PidData.ProdMeasureSensorStatus.HydOilTemp;
                ar & PidData.ProdMeasureSensorStatus.LiftCylExt;
		ar & PidData.ProdMeasureSensorStatus.TiltCylExt;
		ar & PidData.ProdMeasureSensorStatus.LiftCylExtMm;
		ar & PidData.ProdMeasureSensorStatus.TiltCylExtMm;
		ar & PidData.ProdMeasureSensorStatus.BktAngle;
		ar & PidData.LinkSensorCalLim.LiftPosSensorDC;
		ar & PidData.LinkSensorCalLim.LiftPosSensorFullLowerDC;
		ar & PidData.LinkSensorCalLim.LiftPosSensorFullRaiseDC;
		ar & PidData.LinkSensorCalLim.TiltPosSensorDC;
		ar & PidData.LinkSensorCalLim.TiltPosSensorFullDumpDC;
		ar & PidData.LinkSensorCalLim.TiltPosSensorFullRackDC;
		ar & PidData.LdrPayloadStat;
		ar & InfoState.Data;
		ar & PidData.PloadSysCalWtEntryReqStat;
		ar & PidData.LastPloadWt;
		ar & PidData.PloadConSysCalWt;
		ar & PidData.LoaderBktPloadTgtWt;
		ar & PidData.LoaderBktPloadTgtWtPer;
		ar & PidData.PloadSysZeroReqStat;
		ar & PidData.PloadSysZeroStat;
     }

     void toCsv(CsvOutStream& out) const
     {
		out("Dig Stat",(unsigned int )DigStat);
		out("Cal Stat",CalStat);
		out("Dump Stat",DumpStat);
		out("Best Bucket Weight in tonnes",BestBktWtInTonnes);
		out("Zero Notify Stat",ZeroNotifyStat);
		out("Payload Calc Method",PayloadCalcMeth);
		out("Status",LiftCylVel.Stat);
		out("Lift Cyl Vel in mm/sec",LiftCylVel.MilliPerSec);
		out("Weigh Range Bottom Val",WeighRange.WeighRangeBottom);
		out("Weigh Range Size",WeighRange.WeighRangeSize);
		out("Lift Cyl Ext Val",LiftCylExt.Val);
		out("Lift Cyl Ext Stat",LiftCylExt.Stat);
		out("Lift Cyl Vel",CalParam.LiftCylVel);
		out("weigh range Indicator ",Indicator);
		out("Cal weight",CalWt);
		out("Payload Available",PayloadAvailable);
		out("Event States",EventState.Data);
		out("Diag States",DiagState.Data);
		out("Info Pop Up States",InfoState.Data);
		out("Show ! Symbol",ShowExclamationPoint);
		out("HydOilTemp Value",PidData.ProdMeasureSensorStatus.HydOilTemp);
		out("LiftCylExt Value",PidData.ProdMeasureSensorStatus.LiftCylExt);
		out("TiltCylExt Value",PidData.ProdMeasureSensorStatus.TiltCylExt);
		out("PidData.ProdMeasureSensorStatus.LiftCylExtMillimeter Value",PidData.ProdMeasureSensorStatus.LiftCylExtMm);
		out("PidData.ProdMeasureSensorStatus.TiltCylExt Value",PidData.ProdMeasureSensorStatus.TiltCylExtMm);
		out("PidData.ProdMeasureSensorStatus.BucketAngle Value",PidData.ProdMeasureSensorStatus.BktAngle);
 		out("PidData.ProdMeasureWeighStatus",PidData.ProdMeasureWeighStatus.Data);
		out("PidData.ProdMeasureSensorStatus.LiftCylHEPres",PidData.ProdMeasureSensorStatus.LiftCylHEPres);
		out("PidData.ProdMeasureSensorStatus.LiftCylPos",PidData.ProdMeasureSensorStatus.LiftCylPos);
		out("PidData.ProdMeasureSensorStatus.LiftCylREPres",PidData.ProdMeasureSensorStatus.LiftCylREPres);
		out("PidData.ProdMeasureSensorStatus.LiftLinkDC",PidData.ProdMeasureSensorStatus.LiftLinkDC);
		out("PidData.ProdMeasureSensorStatus.TiltLinkDC",PidData.ProdMeasureSensorStatus.TiltLinkDC);
		out("PidData.LinkSensorCalLim.LiftPosSensorDC",PidData.LinkSensorCalLim.LiftPosSensorDC);
		out("PidData.LinkSensorCalLim.LiftPosSensorFullLowerDC",PidData.LinkSensorCalLim.LiftPosSensorFullLowerDC);
		out("PidData.LinkSensorCalLim.LiftPosSensorFullRaiseDC",PidData.LinkSensorCalLim.LiftPosSensorFullRaiseDC);
		out("PidData.LinkSensorCalLim.TiltPosSensorDC",PidData.LinkSensorCalLim.TiltPosSensorDC);
		out("PidData.LinkSensorCalLim.TiltPosSensorFullDumpDC",PidData.LinkSensorCalLim.TiltPosSensorFullDumpDC);
		out("PidData.LinkSensorCalLim.TiltPosSensorFullRackDC",PidData.LinkSensorCalLim.TiltPosSensorFullRackDC);
		out("PidData.LdrPayloadStat",(unsigned int )PidData.LdrPayloadStat);
		out("InfoState.Data",(unsigned int )InfoState.Data);
		out("PidData.PloadSysCalWtEntryReqStat",(unsigned int )PidData.PloadSysCalWtEntryReqStat);
		out("PidData.LastPloadWt",PidData.LastPloadWt);
		out("PidData.PloadConSysCalWt",PidData.PloadConSysCalWt);
		out("PidData.LoaderBktPloadTgtWt",PidData.LoaderBktPloadTgtWt);
		out("PidData.LoaderBktPloadTgtWtPer",PidData.LoaderBktPloadTgtWtPer);
		out("PidData.PloadSysZeroReqStat",(unsigned int )PidData.PloadSysZeroReqStat);
		out("PidData.PloadSysZeroStat",(unsigned int )PidData.PloadSysZeroStat);
    };

 private:  
     /* Add Fields Here */
};  

typedef Datum<LpsSaWeighTxChannelStorage> LpsSaWeighTxChannel;

BOOST_CLASS_VERSION(LpsSaWeighTxChannelStorage, 1);
#endif
