/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: Tpms2UIAppTxChannel.h
DESCRIPTION:
*******************************************************************************/

/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>

#ifndef _LpsSaUIAppTxChannel_h_
#define _LpsSaUIAppTxChannel_h_

typedef enum
{
	 UI_METRIC_UNITS = 0,
	UI_ENGLISH_UNITS = 1,
	UI_UNKNOWN_INFO_UNIT=3
}InfoUnitStat_t;
typedef enum
{
	English = 0,
	Spanish,
	French,
	Portuguese,
	German,
	Norwegian,
	Swedish,
	Finnish,
	Dutch,
	Danish,
	Italian,
	Greek,
	Turkish,
	Indonesian,
	Russian,
	Japanese,
	Hungarian,
	Icelandic,
	Arabic,
	Traditional_Chinese,
	Czech,
	Polish,
	Simplified_Chinese,
	Thai,
	Slovenian,
	Slovakian,
	Estonian,
	Latvian,
	Lithuanian,
	Malaysian,
	Korean,
	Portuguese_Brazil,
	Farsi,
	Hebrew,
	Serbian,
	Croatian,
	Bulgarian,
	Romanian,
	Vietnamese,
	Mongolian,
	Macedonian,
 	Burmese,
 	Khmer,
 	Ukrainian,
	Spanish_Castilian_EAME,
	French_EAME,
	Portuguese_EAME,
	Dutch_Netherlands,
	Burmese_Myanmasa,
	Afrikaans,
	Albanian,
	Armenian,
	Bosnian,
	Dari,
	Dutch_Belgium,
	French_Canadian,
	Hindi,
	Kazakh,
	Laotian,
	Spanish_LACD,
	Tamil,
	Turkmen,
	Urdu
}DispLangStat_t;

class LpsSaUIAppTxChannelStorage : public csvable
{
public:

  LpsSaUIAppTxChannelStorage() /* Initialize Fields Here */
  {
      PidTable.PidF25B_InfoUnitStat = UI_UNKNOWN_INFO_UNIT;
  }
  typedef struct
  {
  	  DispLangStat_t PidD0022C_DispLangStat;
  	  InfoUnitStat_t PidF25B_InfoUnitStat;
  	  unsigned short int PidD00144_ServModEnCode;
  }PidTable_t;
  PidTable_t PidTable;

  template <class Archive>

  	 void serialize(Archive &ar, unsigned int version)
  	 {
  		 /* Archive Fields Here */
  		ar & PidTable.PidD0022C_DispLangStat;
  		ar & PidTable.PidF25B_InfoUnitStat;
  		ar & PidTable.PidD00144_ServModEnCode;
  	 }

  	 void toCsv(CsvOutStream& out) const
  	{
  		out("DispLangStat",  PidTable.PidD0022C_DispLangStat);
  		out("InfoUnitStat", PidTable.PidF25B_InfoUnitStat);
  		out("ServModEnCode", PidTable.PidD00144_ServModEnCode);
  	}

private:
  /* Add Fields Here */
};

typedef Datum<LpsSaUIAppTxChannelStorage> LpsSaUIAppTxChannel;

BOOST_CLASS_VERSION(LpsSaUIAppTxChannelStorage, 1);
#endif

