#ifndef _LpsSaUIAppTxChannelInterfaceTypes_h_
#define _LpsSaUIAppTxChannelInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "LpsSaUIAppTxChannel.h"

typedef interfaces::baseTypes::InputInterface<LpsSaUIAppTxChannel> LpsSaUIAppTxChannelInput;
typedef interfaces::baseTypes::OutputInterface<LpsSaUIAppTxChannel> LpsSaUIAppTxChannelOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<LpsSaUIAppTxChannelInput>()
  {
    return "LpsSaUIAppTxChannelInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<LpsSaUIAppTxChannelOutput>()
  {
    return "LpsSaUIAppTxChannelOutput";
  }
}

#endif
