#include <ais/serialization/Datum.h> // For Boost serialization
#include "LpsCommonStructures.h"

#ifndef _LpsSaNvmCalOnTheFlyDataChannel_h_
#define _LpsSaNvmCalOnTheFlyDataChannel_h_

class LpsSaNvmCalOnTheFlyDataChannelStorage : public csvable
{
public:
   typedef struct LpsSaNvmCalOnTheFlyDataChannel_StatusFlags_s
   {
      bool  CalInProgress;
      bool  PayloadCalFlag;
      bool  EmptyBktCalDone;
      bool  FullBktCalDone;
   } LpsSaNvmCalOnTheFlyDataChannel_StatusFlags_t; // LpsCalStatus_t

   typedef struct LpsSaNvmCalOnTheFlyDataChannel_CurveFitInfo_s
   {
      bool HydOilTempMet;
      bool EnforceRaiseDetent;
      bool EnforceLowerDetent;
      bool RaiseFastVelDone;
      bool RaiseSlowFitDone;
      bool RaiseFastFitDone;
      bool LowerSlowFitDone;
      uint8_t InternalStep;
   } LpsSaNvmCalOnTheFlyDataChannel_CurveFitInfo_t; // Part of LpsCalCurveFitInfo_t

   typedef struct LpsSaNvmCalOnTheFlyDataChannel_MiscUpdates_s
   {
      LpsPresSensorStat_t LiftHePres_Stat;
      LpsPresSensorStat_t LiftRePres_Stat;
      LpsCylExtStat_t LiftCylExt_Stat;
      LpsHydOilTempSensorStat_t HydOilTemp_Stat;
      LpsCylVelStat_t LiftCylVel_Stat;
      LpsCylExtStat_t TiltCylExt_Stat;
      LpsBktAngleStat_t BktAngle_Stat;
      bool LiftLeverInfo_LeverInfoAvailable;
      bool LiftLeverInfo_Faulted;
   } LpsSaNvmCalOnTheFlyDataChannel_MiscUpdates_t; // Part of LpsCalUpdate_t

   typedef struct LpsSaNvmCalOnTheFlyDataChannel_DataOnTheFly_s
   {
      LpsSaNvmCalOnTheFlyDataChannel_StatusFlags_t       statusFlags;
      LpsSaNvmCalOnTheFlyDataChannel_CurveFitInfo_t      curveInfo;
      LpsSaNvmCalOnTheFlyDataChannel_MiscUpdates_t       calUpdates;
   } LpsSaNvmCalOnTheFlyDataChannel_DataOnTheFly_t;

   LpsSaNvmCalOnTheFlyDataChannel_DataOnTheFly_t lps_sa_nvm_calibration_data_on_the_fly;

   LpsSaNvmCalOnTheFlyDataChannelStorage() : lps_sa_nvm_calibration_data_on_the_fly() { }

   template <class Archive>
   void serialize(Archive& ar, unsigned int version)
   {
      // Serialize lps_sa_nvm_calibration_data_on_the_fly
      ar & lps_sa_nvm_calibration_data_on_the_fly.statusFlags.CalInProgress;
      ar & lps_sa_nvm_calibration_data_on_the_fly.statusFlags.PayloadCalFlag;
      ar & lps_sa_nvm_calibration_data_on_the_fly.statusFlags.EmptyBktCalDone;
      ar & lps_sa_nvm_calibration_data_on_the_fly.statusFlags.FullBktCalDone;

      ar & lps_sa_nvm_calibration_data_on_the_fly.curveInfo.HydOilTempMet;
      ar & lps_sa_nvm_calibration_data_on_the_fly.curveInfo.EnforceRaiseDetent;
      ar & lps_sa_nvm_calibration_data_on_the_fly.curveInfo.EnforceLowerDetent;
      ar & lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseFastVelDone;
      ar & lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseSlowFitDone;
      ar & lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseFastFitDone;
      ar & lps_sa_nvm_calibration_data_on_the_fly.curveInfo.LowerSlowFitDone;
      ar & lps_sa_nvm_calibration_data_on_the_fly.curveInfo.InternalStep;

      ar & lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftHePres_Stat;
      ar & lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftRePres_Stat;
      ar & lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftCylExt_Stat;
      ar & lps_sa_nvm_calibration_data_on_the_fly.calUpdates.HydOilTemp_Stat;
      ar & lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftCylVel_Stat;
      ar & lps_sa_nvm_calibration_data_on_the_fly.calUpdates.TiltCylExt_Stat;
      ar & lps_sa_nvm_calibration_data_on_the_fly.calUpdates.BktAngle_Stat;
      ar & lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftLeverInfo_LeverInfoAvailable;
      ar & lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftLeverInfo_Faulted;
   }

   void toCsv(CsvOutStream& out) const
   {
      // Dump lps_sa_nvm_calibration_data_on_the_fly
      out ("CalInProgress", lps_sa_nvm_calibration_data_on_the_fly.statusFlags.CalInProgress);
      out ("PayloadCalFlag", lps_sa_nvm_calibration_data_on_the_fly.statusFlags.PayloadCalFlag);
      out ("EmptyBktCalDone", lps_sa_nvm_calibration_data_on_the_fly.statusFlags.EmptyBktCalDone);
      out ("FullBktCalDone", lps_sa_nvm_calibration_data_on_the_fly.statusFlags.FullBktCalDone);

      out ("HydOilTempMet", lps_sa_nvm_calibration_data_on_the_fly.curveInfo.HydOilTempMet);
      out ("EnforceRaiseDetent", lps_sa_nvm_calibration_data_on_the_fly.curveInfo.EnforceRaiseDetent);
      out ("EnforceLowerDetent", lps_sa_nvm_calibration_data_on_the_fly.curveInfo.EnforceLowerDetent);
      out ("RaiseFastVelDone", lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseFastVelDone);
      out ("RaiseSlowFitDone", lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseSlowFitDone);
      out ("RaiseFastFitDone", lps_sa_nvm_calibration_data_on_the_fly.curveInfo.RaiseFastFitDone);
      out ("LowerSlowFitDone", lps_sa_nvm_calibration_data_on_the_fly.curveInfo.LowerSlowFitDone);
      out ("InternalStep", lps_sa_nvm_calibration_data_on_the_fly.curveInfo.InternalStep);

      out ("LiftHePres_Stat", lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftHePres_Stat);
      out ("LiftRePres_Stat", lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftRePres_Stat);
      out ("LiftCylExt_Stat", lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftCylExt_Stat);
      out ("HydOilTemp_Stat", lps_sa_nvm_calibration_data_on_the_fly.calUpdates.HydOilTemp_Stat);
      out ("LiftCylVel_Stat", lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftCylVel_Stat);
      out ("TiltCylExt_Stat", lps_sa_nvm_calibration_data_on_the_fly.calUpdates.TiltCylExt_Stat);
      out ("BktAngle_Stat", lps_sa_nvm_calibration_data_on_the_fly.calUpdates.BktAngle_Stat);
      out ("LiftLeverInfo_LeverInfoAvailable", lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftLeverInfo_LeverInfoAvailable);
      out ("LiftLeverInfo_Faulted", lps_sa_nvm_calibration_data_on_the_fly.calUpdates.LiftLeverInfo_Faulted);
   }

private:
   // Nothing here yet
};

typedef Datum<LpsSaNvmCalOnTheFlyDataChannelStorage> LpsSaNvmCalOnTheFlyDataChannel;

BOOST_CLASS_VERSION(LpsSaNvmCalOnTheFlyDataChannelStorage, 1);
#endif

