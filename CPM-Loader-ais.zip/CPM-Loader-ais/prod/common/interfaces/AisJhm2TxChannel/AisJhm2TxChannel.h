
#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>
#ifndef _AisJhm2TxChannel_h_
#define _AisJhm2TxChannel_h_
class AisJhm2TxChannelStorage :public csvable
{  
public:  
     AisJhm2TxChannelStorage() /* Initialize Fields Here */{ }
     int DispBrightness;
	 typedef struct  
     {
      std::string timeStamp;
      float adjtruckweight;
      float zeroedTruckWt;
      bool newDataFlag;
      
     }simplecal_data_t;
    simplecal_data_t simplecal_data;

     template <class Archive>
     void serialize(Archive &ar, unsigned int version)
     {
       /* Archive Fields Here */
       ar & DispBrightness;
       ar & simplecal_data.timeStamp;
       ar & simplecal_data.adjtruckweight;
       ar & simplecal_data.zeroedTruckWt;
	   ar & simplecal_data.newDataFlag;
     }
     void toCsv(CsvOutStream& out) const
     {	
		out("Display Brightness",DispBrightness);
		out("simplecaldata timestamp",simplecal_data.timeStamp);
		out("simplecaldata truck weight",simplecal_data.adjtruckweight);
		out("simplecaldata adjusted truck weight",simplecal_data.zeroedTruckWt);
		out("simplecaldata adjusted truck weight",simplecal_data.newDataFlag);
     }

 private:  
     /* Add Fields Here */
};  

typedef Datum<AisJhm2TxChannelStorage> AisJhm2TxChannel;

BOOST_CLASS_VERSION(AisJhm2TxChannelStorage, 1);
#endif

