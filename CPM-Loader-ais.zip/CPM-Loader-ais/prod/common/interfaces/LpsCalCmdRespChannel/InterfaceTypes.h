#ifndef _LpsCalCmdRespChannelInterfaceTypes_h_
#define _LpsCalCmdRespChannelInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "LpsCalCmdRespChannel.h"

typedef interfaces::baseTypes::InputInterface<LpsCalCmdRespChannel> LpsCalCmdRespChannelInput;
typedef interfaces::baseTypes::OutputInterface<LpsCalCmdRespChannel> LpsCalCmdRespChannelOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<LpsCalCmdRespChannelInput>()
  {
    return "LpsCalCmdRespChannelInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<LpsCalCmdRespChannelOutput>()
  {
    return "LpsCalCmdRespChannelOutput";
  }
}

#endif
