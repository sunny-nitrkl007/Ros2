#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>
#include <time.h>
#include <deque>
#include <boost/serialization/deque.hpp>
#ifndef _LpsSaJobMgrTxChannel_h_
#define _LpsSaJobMgrTxChannel_h_

using namespace std;


/* Tip Off Trigger Type */
typedef enum
{
	LPS_SA_JOB_MGR_TIP_OFF_TRIGGER_AUTO = 0,
	LPS_SA_JOB_MGR_TIP_OFF_TRIGGER_MANUAL,
	LPS_SA_JOB_MGR_TIP_OFF_TRIGGER_DISABLED
}LpsSaTipOffTriggerType_t;

typedef enum
{
	LPS_SA_JOB_MGR_TIP_OFF_PILE_ENABLE = 0, /* To highlight Pile tip off button on display */
	LPS_SA_JOB_MGR_TIP_OFF_TRUCK_ENABLE, /* To highlight Pile tip off button on display */
	LPS_SA_JOB_MGR_TIP_OFF_UNAVAILABLE, /* Tip off buttons (Pile/Truck) not available to operator on display,
	                                       Tip off buttons will be replaced by Zero button on display */
} LpsSaJobMgrTipOffState_t;

typedef enum
{
    LPS_SA_JOB_MGR_MAN_TIP_OFF_AVAILABLE = 0, /* Status to show manual tip off button on display */
    LPS_SA_JOB_MGR_MAN_TIP_OFF_UNAVAILABLE, /* Status to no show manual tip off button on display */
    LPS_SA_JOB_MGR_MAN_TIP_OFF_ACTIVE,/* Status to show active status of manual tip off button on display */
    LPS_SA_JOB_MGR_MAN_TIP_OFF_INACTIVE,/* Status to show inactive status of manual tip off button on display */
}LpsSaJobMgrManualTipOffState_t;

typedef enum
{
	LPS_SA_JOB_MGR_UNCALIBRATED = 0,
	LPS_SA_JOB_MGR_WEIGH_MODE,
	LPS_SA_JOB_MGR_ADJUST_CAL_MODE,
	LPS_SA_JOB_MGR_STANDBY_MODE,
	LPS_SA_JOB_MGR_EXCESS_MODE
} LpsSaJobMgrOperationMode_t;

typedef enum
{
	LPS_SA_JOB_MGR_STANDBY_ACTIVATED = 0,
	LPS_SA_JOB_MGR_STANDBY_DEACTIVATED
} LpsSaJobMgrStandbyState_t;

typedef enum
{
	LPS_SA_JOB_MGR_CLEAR_BTN_ENABLED = 0,
	LPS_SA_JOB_MGR_MINUS_ONE_BTN_ENABLED
} LpsSaJobMgrClearMinusOneEnableStat_t;

typedef enum
{
       	LPS_SA_BEST_BKT_WEIGHT_STAT_OK = 0,
       	LPS_SA_BEST_BKT_WEIGHT_STAT_BAD
}DispBestBktWtStat_t;

typedef struct
{
		float 					Val;
		DispBestBktWtStat_t 	Stat;
}DispBestBktWt_t;


typedef enum
{
    LPS_SA_JOB_MGR_AUTO_MANUAL_TIP_OFF_DUMP_STATE_INACTIVE = 0,/* Status  of auto tip off */
    LPS_SA_JOB_MGR_AUTO_MANUAL_TIP_OFF_DUMP_STATE_ACTIVE,/* Status of auto tip off */
}LpsSaJobMgrAutoManualTipOffDumpState_t;


typedef struct
{
	string	timeStamp;  	 		//contains sec,min,hrs,mm,dd,yy
	float truckWt;
	float zeroedTruckWt;
	
	template <class Archive>
	void serialize(Archive& ar, unsigned int version)
	{
		ar & timeStamp;
		ar & truckWt;
		ar & zeroedTruckWt;
	}
}SimpleCalData_t;

typedef enum
{
   NONE = 0x003A,
   CLEAR = 0x0227,
   REWEIGH = 0x02FB,
   ZERO =0x035E,
   STORE = 0x035F,
   TIPOFFTOGGLE = 0x059E,
   MINUS_ONE = 0x0630
}ReqPloadCtrlSysStat_t;

typedef enum
{
   SOUND_HORN      = 0x031A,
   NOT_SOUND_HORN  = 0x031B
}StorePloadHornStat_t;

class LpsSaJobMgrTxChannelStorage: public csvable
{
public:
     LpsSaJobMgrTxChannelStorage() /* Initialize Fields Here */{ }
	/* Add Fields Here */
      
     /* SCS Job Manager App Interfaces */

	short int PassCount;
	float     TargetWeight;
	double    TruckWeight;
	int       LifetimeTruckLoadCount;
	int       LifetimeCycleCount;
	double    LifetimeTotalPayload;
	int       LifetimePayloadPassCount;
	int       MaterialID;
	string    MaterialName;
	LpsSaJobMgrManualTipOffState_t 			ManualTipOffState; /* Status variable to indicate manual tip off state on display */
	LpsSaTipOffTriggerType_t       			TipOffTriggerType;
	LpsSaJobMgrTipOffState_t       			TipOffState; /* Status variable to indicates the tip off button state on display */
	LpsSaJobMgrOperationMode_t     			OperationMode;
	LpsSaJobMgrStandbyState_t      			StandbyState;
	LpsSaJobMgrClearMinusOneEnableStat_t 	ClearMinusOneEnableStat;
	DispBestBktWt_t          				DispBestBktWt;
	LpsSaJobMgrTipOffState_t 				TipOffStateCfg; /* Tip Off of State Configuration in NVM */
	LpsSaJobMgrAutoManualTipOffDumpState_t  LpsSaJobMgrAutoManualTipOffDumpState;
	std::deque<SimpleCalData_t> 			simpleCalData;
	unsigned int 							storeCount;
	ReqPloadCtrlSysStat_t					ReqPloadCtrlSysStat;
	StorePloadHornStat_t                HornStoreState;
        
    template <class Archive>

	void serialize(Archive &ar, unsigned int version)
    {
		/* Archive Fields Here */
		ar & PassCount;
		ar & TargetWeight;
		ar & TruckWeight;
		ar & MaterialID;
		ar & LifetimeTruckLoadCount;
		ar & LifetimeCycleCount;
		ar & LifetimeTotalPayload;
		ar & LifetimePayloadPassCount;
		ar & MaterialName;
		ar & ManualTipOffState;
		ar & TipOffTriggerType;
		ar & TipOffState;
		ar & OperationMode;
		ar & StandbyState;
		ar & ClearMinusOneEnableStat;
		ar & DispBestBktWt.Val;
		ar & DispBestBktWt.Stat;
		ar & TipOffStateCfg;
		ar & LpsSaJobMgrAutoManualTipOffDumpState;
		ar & simpleCalData;
		ar & storeCount;
		ar & ReqPloadCtrlSysStat;
		ar & HornStoreState;
    }

     void toCsv(CsvOutStream& out) const
     {
		out("Pass Count",PassCount);
		out("Target Weight",TargetWeight);
		out("Truck Weight",TruckWeight);
		out("Material ID", MaterialID);
		out("Life time Truck Load Count",LifetimeTruckLoadCount);
		out("Life time Cycle Count",LifetimeCycleCount);
		out("Life time Total Payload",LifetimeTotalPayload);
		out("Life time Payload Pass Count",LifetimePayloadPassCount);
		out("Material Name",MaterialName);
		out("Manual Tip off State",ManualTipOffState);
		out("Tip Off TriggerType", TipOffTriggerType);
		out("Tip Off", TipOffState);
		out("Operation Mode", OperationMode);
		out("Standby state", StandbyState);
		out("Clear MinusOne Enable Status", ClearMinusOneEnableStat);
		out("Display Best Bkt Wt", DispBestBktWt.Val);
		out("Display Best Bkt Wt Status", DispBestBktWt.Stat);
		out("TipOffStateCfg", TipOffStateCfg);
		out("Auto ManualTipOff DumpState active status", LpsSaJobMgrAutoManualTipOffDumpState);
		out("Horn Store State", HornStoreState);
     }


     inline bool ReadHornStoreEnable( void ){ return HornStoreState == SOUND_HORN? true : false;}

 private:  
     /* Add Fields Here */
};  

typedef Datum<LpsSaJobMgrTxChannelStorage> LpsSaJobMgrTxChannel;

BOOST_CLASS_VERSION(LpsSaJobMgrTxChannelStorage, 1);
#endif

