#ifndef _LpsCalCmdReqstChannelInterfaceTypes_h_
#define _LpsCalCmdReqstChannelInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "LpsCalCmdReqstChannel.h"

typedef interfaces::baseTypes::InputInterface<LpsCalCmdReqstChannel> LpsCalCmdReqstChannelInput;
typedef interfaces::baseTypes::OutputInterface<LpsCalCmdReqstChannel> LpsCalCmdReqstChannelOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<LpsCalCmdReqstChannelInput>()
  {
    return "LpsCalCmdReqstChannelInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<LpsCalCmdReqstChannelOutput>()
  {
    return "LpsCalCmdReqstChannelOutput";
  }
}

#endif
