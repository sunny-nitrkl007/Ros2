#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>
#ifndef _LpsSaJobMgrRespChannel_h_
#define _LpsSaJobMgrRespChannel_h_

typedef enum
{
	LPS_SA_JOB_MGR_ZERO_SUCCESS = 0,
	LPS_SA_JOB_MGR_ZERO_FAIL,
	LPS_SA_JOB_MGR_ZERO_UNKNOWN
} LpsSaJobMgrZeroRespCode_t;

typedef enum
{
	LPS_SA_JOB_MGR_MINUS_ONE_SUCCESS = 0,
	LPS_SA_JOB_MGR_MINUS_ONE_FAIL,
	LPS_SA_JOB_MGR_MINUS_ONE_UNKNOWN
} LpsSaMinusOneRespCode_t;

typedef enum
{
	LPS_SA_JOB_MGR_CLEAR_SUCCESS = 0,
	LPS_SA_JOB_MGR_CLEAR_FAIL,
	LPS_SA_JOB_MGR_CLEAR_UNKNOWN
} LpsSaJobMgrClearRespCode_t;

typedef enum
{
	LPS_SA_JOB_MGR_STORE_SUCCESS = 0,
	LPS_SA_JOB_MGR_STORE_FAIL,
	LPS_SA_JOB_MGR_STORE_UNKNOWN
} LpsSaJobMgrStoreRespCode_t;

typedef enum
{
	LPS_SA_JOB_MGR_STANDBY_ACTIVE_SUCCESS = 0,
	LPS_SA_JOB_MGR_STANDBY_ACTIVE_FAIL,
	LPS_SA_JOB_MGR_STANDBY_ACTIVE_UNKNOWN
} LpsSaJobMgrStandByActiveRespCode_t;

typedef enum
{
	LPS_SA_JOB_MGR_STANDBY_DEACTIVE_SUCCESS = 0,
	LPS_SA_JOB_MGR_STANDBY_DEACTIVE_FAIL,
	LPS_SA_JOB_MGR_STANDBY_DEACTIVE_UNKNOWN
} LpsSaJobMgrStandByDeActiveRespCode_t;


typedef enum
{
	LPS_SA_JOB_MGR_TIP_OFF_TRUCK_PILE_TOGGLE_SUCCESS = 0,
	LPS_SA_JOB_MGR_TIP_OFF_TRUCK_PILE_TOGGLE_FAIL,
	LPS_SA_JOB_MGR_TIP_OFF_TRUCK_PILE_TOGGLE_UNKNOWN
} LpsSaJobMgrTipOffTruckPileRespCode_t;
typedef enum
{
	LPS_SA_JOB_MGR_TIP_OFF_ACT_SUCCESS = 0,
	LPS_SA_JOB_MGR_TIP_OFF_ACT_FAIL,
	LPS_SA_JOB_MGR_TIP_OFF_ACT_UNKNOWN
} LpsSaJobMgrTipOffActRespCode_t;

typedef enum
{
	LPS_SA_JOB_MGR_TIP_OFF_DEACT_SUCCESS = 0,
	LPS_SA_JOB_MGR_TIP_OFF_DEACT_FAIL,
	LPS_SA_JOB_MGR_TIP_OFF_DEACT_UNKNOWN
} LpsSaJobMgrTipOffDeactRespCode_t;

typedef enum
{
	LPS_SA_JOB_MGR_TARGET_WEIGHT_SUCCESS = 0,
	LPS_SA_JOB_MGR_TARGET_WEIGHT_FAIL,
	LPS_SA_JOB_MGR_TARGET_WEIGHT_UNKNOWN
} LpsSaJobMgrTargetWeightRespCode_t;

typedef enum
{
	LPS_SA_JOB_MGR_REWEIGH_SUCCESS = 0,
	LPS_SA_JOB_MGR_REWEIGH_FAIL,
	LPS_SA_JOB_MGR_REWEIGH_UNKNOWN
} LpsSaJobMgrReWeighRespCode_t;

typedef enum
{
	LPS_SA_JOB_MGR_TIP_OFF_TRIGGER_TYPE_SUCCESS = 0,
	LPS_SA_JOB_MGR_TIP_OFF_TRIGGER_TYPE_FAIL,
	LPS_SA_JOB_MGR_TIP_OFF_TRIGGER_TYPE_UNKNOWN
} LpsSaJobMgrTipOffTriggerTypeRespCode_t;

typedef enum
{
	LPS_SA_JOB_MGR_TIP_OFF_STATE_SUCCESS = 0,
	LPS_SA_JOB_MGR_TIP_OFF_STATE_FAIL,
	LPS_SA_JOB_MGR_TIP_OFF_STATE_UNKNOWN
} LpsSaJobMgrTipOffStateRespCode_t;

class LpsSaJobMgrRespChannelStorage: public csvable
{  
public:  
	/* SCS JobMgr App Interfaces */
	LpsSaJobMgrZeroRespCode_t ZeroResp;
	LpsSaMinusOneRespCode_t MinusOneResp;
	LpsSaJobMgrClearRespCode_t ClearResp;
	LpsSaJobMgrStoreRespCode_t StoreResp;
	LpsSaJobMgrStandByActiveRespCode_t StandByActResp;
	LpsSaJobMgrStandByDeActiveRespCode_t StandByDeActResp;

	LpsSaJobMgrTipOffTruckPileRespCode_t TipOffTruckPileToggleResp;
	LpsSaJobMgrTipOffActRespCode_t TipOffActResp;
	LpsSaJobMgrTipOffDeactRespCode_t TipOffDeactResp;
	LpsSaJobMgrReWeighRespCode_t ReWeighResp;
	LpsSaJobMgrTargetWeightRespCode_t TargetWeightResp;
	LpsSaJobMgrTipOffTriggerTypeRespCode_t TipOffTriggerTypeResp;
	LpsSaJobMgrTipOffStateRespCode_t TipOffStateResp;

    LpsSaJobMgrRespChannelStorage() /* Initialize Fields Here */{ }

    template <class Archive>

	void serialize(Archive &ar, unsigned int version)
    {
		/* Archive Fields Here */
		ar & ZeroResp;
		ar & MinusOneResp;
		ar & ClearResp;
		ar & StoreResp;
		ar & StandByActResp;
		ar & StandByDeActResp;
		ar & TipOffTruckPileToggleResp;
		ar & TipOffActResp;
		ar & TipOffDeactResp;
		ar & ReWeighResp;
		ar & TargetWeightResp;
		ar & TipOffTriggerTypeResp;
		ar & TipOffStateResp;
	}

	void toCsv(CsvOutStream& out) const
	{
		out("Minus One JobMgr Response Code", MinusOneResp);
		out("Zero Response Code", ZeroResp);
		out("Clear Response Code", ClearResp);
		out("Store Response Code", StoreResp);
		out("StandBy Act Response Code", StandByActResp);
		out("StandBy DeAct Response Code", StandByDeActResp);
		out("Truck_Tip_Off Response Code", TipOffTruckPileToggleResp);
		out("Tip_Off_Activated Response Code", TipOffActResp);
		out("Tip_Off_Deactivated Response Code", TipOffDeactResp);
		out("ReWeigh Response Code", ReWeighResp);
		out("Target Weight Response Code", TargetWeightResp);
		out("TipOff TriggerType  Response Code", TipOffTriggerTypeResp);
		out("TipOff State Response Code", TipOffStateResp);
	}

 private:  
     /* Add Fields Here */
};  

typedef Datum<LpsSaJobMgrRespChannelStorage> LpsSaJobMgrRespChannel;

BOOST_CLASS_VERSION(LpsSaJobMgrRespChannelStorage, 1);
#endif

