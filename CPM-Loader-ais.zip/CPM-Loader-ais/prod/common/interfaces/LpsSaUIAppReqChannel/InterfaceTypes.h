#ifndef _LpsSaUIAppReqChannelInterfaceTypes_h_
#define _LpsSaUIAppReqChannelInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "LpsSaUIAppReqChannel.h"

typedef interfaces::baseTypes::InputInterface<LpsSaUIAppReqChannel> LpsSaUIAppReqChannelInput;
typedef interfaces::baseTypes::OutputInterface<LpsSaUIAppReqChannel> LpsSaUIAppReqChannelOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<LpsSaUIAppReqChannelInput>()
  {
    return "LpsSaUIAppReqChannelInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<LpsSaUIAppReqChannelOutput>()
  {
    return "LpsSaUIAppReqChannelOutput";
  }
}

#endif
