/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: Tpms2UIAppReqChannel.h
DESCRIPTION:
*******************************************************************************/

/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>
#include <interfaces/LpsSaUIAppTxChannel/InterfaceTypes.h>

#ifndef _LpsSaUIAppReqChannel_h_
#define _LpsSaUIAppReqChannel_h_

typedef struct
{
	DispLangStat_t ReqVal;
	bool ReqFlag;
}PidD0022C_DispLangStat_t;

typedef struct
{
	InfoUnitStat_t ReqVal;
	bool ReqFlag;
}PidF25B_InfoUnitStat_t;

typedef struct
{
	unsigned short int ReqVal;
	bool ReqFlag;
}PidD00144_ServModEnCode_t;

class LpsSaUIAppReqChannelStorage : public csvable
{
public:
	  typedef struct
	  {
		  PidD0022C_DispLangStat_t PidD0022C_DispLangStat;
		  PidF25B_InfoUnitStat_t PidF25B_InfoUnitStat;
		  PidD00144_ServModEnCode_t PidD00144_ServModEnCode;
	  }PidTable_t;
	  PidTable_t PidTable;

	  LpsSaUIAppReqChannelStorage() /* Initialize Fields Here */ {
	 PidTable.PidD0022C_DispLangStat.ReqFlag = false;
	PidTable.PidD00144_ServModEnCode.ReqFlag = false;
	PidTable.PidF25B_InfoUnitStat.ReqFlag = false;
  }


    template <class Archive>

    	 void serialize(Archive &ar, unsigned int version)
    	 {
    		 /* Archive Fields Here */
    		ar & PidTable.PidD0022C_DispLangStat.ReqVal;
    		ar & PidTable.PidD0022C_DispLangStat.ReqFlag;
    		ar & PidTable.PidD00144_ServModEnCode.ReqFlag;
    		ar & PidTable.PidD00144_ServModEnCode.ReqVal;
    		ar & PidTable.PidF25B_InfoUnitStat.ReqFlag;
    		ar & PidTable.PidF25B_InfoUnitStat.ReqVal;

    	 }

    	 void toCsv(CsvOutStream& out) const
    	{
    		out("DispLangStat Val",  PidTable.PidD0022C_DispLangStat.ReqVal);
    		out("InfoUnitStat val", PidTable.PidF25B_InfoUnitStat.ReqVal);
    		out("ServModEnCode val", PidTable.PidD00144_ServModEnCode.ReqVal);
    		out("DispLangStat Flag",  PidTable.PidD0022C_DispLangStat.ReqFlag);
			out("InfoUnitStat Flag", PidTable.PidF25B_InfoUnitStat.ReqFlag);
			out("ServModEnCode Flag", PidTable.PidD00144_ServModEnCode.ReqFlag);
    	}

private:
  /* Add Fields Here */
};

typedef Datum<LpsSaUIAppReqChannelStorage> LpsSaUIAppReqChannel;

BOOST_CLASS_VERSION(LpsSaUIAppReqChannelStorage, 1);
#endif

