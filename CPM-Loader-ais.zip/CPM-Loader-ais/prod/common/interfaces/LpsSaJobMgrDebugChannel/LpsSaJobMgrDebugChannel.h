#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>

#ifndef __LPS_COMMON_TYPE_DEF_H__
#include <LpsCommonTypeDef.h>
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h>
#endif

#ifndef __LPS_PT_PUBLIC_H__
#include <LpsPtPublic.h>
#endif

#ifndef _LpsSaJobMgrDebugChannel_h_
#define _LpsSaJobMgrDebugChannel_h_

class LpsSaJobMgrDebugChannelStorage: public csvable
{  
public:  
     LpsSaJobMgrDebugChannelStorage() /* Initialize Fields Here */{ }

     template <class Archive>
     void serialize(Archive &ar, unsigned int version)
     {
       /* Archive Fields Here */
    	 ar & CurrentState;
     }

     void toCsv(CsvOutStream& out) const
     {
    	 //out("Zero  Request", (unsigned int) ZeroReqst);
     }

     unsigned_32  CurrentState;

 private:  
     /* Add Fields Here */
};  



typedef Datum<LpsSaJobMgrDebugChannelStorage> LpsSaJobMgrDebugChannel;

BOOST_CLASS_VERSION(LpsSaJobMgrDebugChannelStorage, 1);
#endif

