/*******************************************************************************
** COPYRIGHT (C) 2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: Tpms2UIAppReqChannel.h
DESCRIPTION:
*******************************************************************************/

/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/interfaces/traits/csvable.h>

#ifndef _LpsSaUIAppRespChannel_h_
#define _LpsSaUIAppRespChannel_h_

class LpsSaUIAppRespChannelStorage : public csvable
{
public:
	LpsSaUIAppRespChannelStorage() /* Initialize Fields Here */ { }

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    /* Archive Fields Here */
  }
  void toCsv(CsvOutStream& out) const
  	{

  	}

private:
  /* Add Fields Here */
};

typedef Datum<LpsSaUIAppRespChannelStorage> LpsSaUIAppRespChannel;

BOOST_CLASS_VERSION(LpsSaUIAppRespChannelStorage, 1);
#endif

