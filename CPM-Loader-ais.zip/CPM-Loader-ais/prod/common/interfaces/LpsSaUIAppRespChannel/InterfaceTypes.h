#ifndef _LpsSaUIAppRespChannelInterfaceTypes_h_
#define _LpsSaUIAppRespChannelInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "LpsSaUIAppRespChannel.h"

typedef interfaces::baseTypes::InputInterface<LpsSaUIAppRespChannel> LpsSaUIAppRespChannelInput;
typedef interfaces::baseTypes::OutputInterface<LpsSaUIAppRespChannel> LpsSaUIAppRespChannelOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<LpsSaUIAppRespChannelInput>()
  {
    return "LpsSaUIAppRespChannelInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<LpsSaUIAppRespChannelOutput>()
  {
    return "LpsSaUIAppRespChannelOutput";
  }
}

#endif
