/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME:BestBktWt
DESCRIPTION: Finds best bucket weight available for the given weights.


*******************************************************************************/

/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef __LPS_COMMON_TYPE_DEF_H__
#include <LpsCommonTypeDef.h> /* Contains type definitions of standard datatypes */
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h> /* Contains structures which are common between all LPS
                                  * system libraries
								  */
#endif

#ifndef __LPS_PUBLIC_H__
#include <LpsPublic.h> /*******************************************************/ 
                       /* Containes prototypes of interfaces and functions    */
                       /* which are exported to the application using the     */
                       /* library                                             */
                       /*******************************************************/
#endif

#include "LpsPrivate.h" /*******************************************************/ 
                        /* Containes prototypes of interfaces and functions    */
                        /* which are used within the payload computation       */
                        /* library                                             */
                        /*******************************************************/

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
#define CALC_METHOD_CONCAT(FilterType, Accracy, SensorType) ((FilterType<<12) | (Accracy<<8) | (0<<4) | (SensorType))


/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
static boolean LpsWeighLiveWtCheckLatchConditionsOk(void);

LpsWeighBestBktWt_t LpsWeighGetBestAvailableBktWt(void)
{
	return (LpsWrk.BestBktWt);
}

void LpsWeighResetBestAvailableBktWt(void)
{
   LpsWrk.BestBktWt.Wt = 0;
   LpsWrk.BestBktWt.PayloadCalcMeth = CALC_METHOD_CONCAT(LPS_WEIGH_PCM_PRIMARY_FILTER_TYPE_BUTTERWORTH_LP, 
														LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_NONE,
														LPS_WEIGH_PCM_SENSOR_TYPE_HPS_HE_RE);
   LpsWrk.WeighDecFlag = FALSE;
   LpsWeighResetWeighRangeWeight();
   LpsWeighResetLlwWt();
   LpsWeighSetTooHeavyToZero(FALSE);
   return;
}

LpsInitErrorTypes_t LpsOverloadWeightInit()
{
	LpsWeighOverloadWarnings_t *pOverloadWarningData	= &LpsWrk.OverloadWarnTbl;

	LpsWrk.InitErr = LPS_INIT_UNKNOWN_ERROR;

	pOverloadWarningData->PrevDigState 		= LPS_WEIGHT_BKT_NOT_DIGGING;
	pOverloadWarningData->DigReverseFlag 	= FALSE;
	pOverloadWarningData->OverloadActive	= FALSE;
	pOverloadWarningData->InOverloadRange   = FALSE;

	SetBucketStateWaitForLatch(TRUE);

	LpsWrk.InitErr = LPS_INIT_SUCCESS;
	return LpsWrk.InitErr;
}

boolean LpsWeighOverloadWarningActive(void)
{
	LpsWeighOverloadWarnings_t *pOverloadWarningData	= &LpsWrk.OverloadWarnTbl;

	return pOverloadWarningData->OverloadActive;
}

static boolean LpsWeighLiveWtCheckLatchConditionsOk(void)
{
	//LpsWeighDigDetect_t *pDigDetectData	= 	&LpsWrk.DigDetectData;
    LpsUpdtTbl_t *pUpdtTbl 				= 	LpsWrk.UpdtTbl;
	boolean conditionsOk;
	
    if ((LPS_WEIGHT_BKT_FULLY_DUMPED != GetDumpStateStatus()) &&
        (LPS_LIFT_STALL_STALLED      != LpsWrk.LpsStallDetect.LiftStallStat) &&
        (LPS_LINKAGE_MOVEMENT_NEGATIVE != LpsWrk.LinkageMovement.tilt) &&
        (LPS_WEIGH_SYSTEM_CALIBRATED == LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.CalStat) &&
		(TRUE == LpsWrk.UpdtTbl->UseFilterDataFlag))
        //(FALSE == pDigDetectData->DigDetected) &&
    {
        conditionsOk = TRUE;
    }
    else
    {
        conditionsOk = FALSE;
    }

    return conditionsOk;
}
	
LpsUpdtErrorTypes_t LpsWeighBestBktWtUpdate(void)
{
	LpsWeighBestBktWt_t			*pBestBkt   				= &LpsWrk.BestBktWt;
	LpsWeighLlw_t     			*pLowLiftWt    				= &LpsWrk.LowLiftWt;
	LpsWeighWrwOpTbl_t			*pWeighRangeWt  			= &LpsWrk.WrwTbl.OpTbl;
	LpsWeighWrwWkTbl_t			*pWrwWkTbl 					= &LpsWrk.WrwTbl.WkTbl;
	LpsCalib_t         			*pCal       				= &LpsWrk.InitTbl.MachSpecificCfg.CalibTbl;
	LpsWeighLiveWeigh_t			*pLiveWtTbl	    			= &LpsWrk.LiveWeighTbl;
	LpsWeighOverloadWarnings_t 	*pOverloadWarningData		= &LpsWrk.OverloadWarnTbl;
	LpsWeighDigDetect_t 		*pDigDetectData				= &LpsWrk.DigDetectData;

	unsigned_8 accuracy;
	LpsWrk.UpdtErr = LPS_UPDT_UNKNOWN_ERROR;
	
	if(LPS_WEIGH_SYSTEM_UNCALIBRATED == pCal->CalStat)
	{
		pBestBkt->Wt = 0;
		pBestBkt->PayloadCalcMeth = CALC_METHOD_CONCAT(LPS_WEIGH_PCM_PRIMARY_FILTER_TYPE_BUTTERWORTH_LP, 
														LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_NONE,
														LPS_WEIGH_PCM_SENSOR_TYPE_HPS_HE_RE);
	}
	else if(LPS_WEIGH_WRW_STATUS_VALID == pWeighRangeWt->Status)
	{
		if(LPS_WEIGH_NO_WARNING_ACTIVE == pWeighRangeWt->Warning)
		{
			LpsWrk.WeighDecFlag = TRUE;
			pBestBkt->Wt   = pWeighRangeWt->Wt;
			pBestBkt->PayloadCalcMeth = CALC_METHOD_CONCAT(LPS_WEIGH_PCM_PRIMARY_FILTER_TYPE_DYNAMIC_AVG, 
														LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_HIGH,
														LPS_WEIGH_PCM_SENSOR_TYPE_HPS_HE_RE);
		}
		else if(LPS_WEIGH_LLW_STATUS_VALID == pLowLiftWt->Stat)
		{
			LpsWrk.WeighDecFlag = TRUE;
			pBestBkt->Wt = pLowLiftWt->Wt;
			pBestBkt->PayloadCalcMeth = CALC_METHOD_CONCAT(LPS_WEIGH_PCM_PRIMARY_FILTER_TYPE_BUTTERWORTH_LP, 
														LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_MED,
														LPS_WEIGH_PCM_SENSOR_TYPE_HPS_HE_RE);
		}
		else
		{
			LpsWrk.WeighDecFlag = TRUE;
			pBestBkt->Wt = pWeighRangeWt->Wt;
			pBestBkt->PayloadCalcMeth = CALC_METHOD_CONCAT(LPS_WEIGH_PCM_PRIMARY_FILTER_TYPE_DYNAMIC_AVG, 
														LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_MED,
														LPS_WEIGH_PCM_SENSOR_TYPE_HPS_HE_RE);
		}
	}
	else if(LPS_WEIGH_LLW_STATUS_VALID == pLowLiftWt->Stat)
	{
		LpsWrk.WeighDecFlag = TRUE;
		pBestBkt->Wt = pLowLiftWt->Wt;
		pBestBkt->PayloadCalcMeth = CALC_METHOD_CONCAT(LPS_WEIGH_PCM_PRIMARY_FILTER_TYPE_BUTTERWORTH_LP, 
														LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_MED,
														LPS_WEIGH_PCM_SENSOR_TYPE_HPS_HE_RE);
	}
	else if(TRUE == LpsWeighLiveWtCheckLatchConditionsOk())
	{
		/* Standalone team asked to add Live weight feature in new release of weighing lib and
		 from Nov 30th meeting, they decided to comment this piece of code in best bucket weight. */
		
		LpsWrk.WeighDecFlag = TRUE;
		pBestBkt->Wt = pLiveWtTbl->Wt;
		pBestBkt->PayloadCalcMeth = CALC_METHOD_CONCAT(LPS_WEIGH_PCM_PRIMARY_FILTER_TYPE_BUTTERWORTH_LP, 
														LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_LOW,
														LPS_WEIGH_PCM_SENSOR_TYPE_HPS_HE_RE);
																
	}
	else if(TRUE == LpsWrk.WeighDecFlag)
	{
		/* Latch on to declared weight */
	}
	else
	{
		pBestBkt->Wt = pLiveWtTbl->Wt;
		if((LPS_WEIGH_SYSTEM_CALIBRATED == LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.CalStat) &&
		   (TRUE == LpsWrk.UpdtTbl->UseFilterDataFlag) && (LPS_LIFT_STALL_STALLED  != LpsWrk.LpsStallDetect.LiftStallStat))
		{
			pBestBkt->PayloadCalcMeth = CALC_METHOD_CONCAT(LPS_WEIGH_PCM_PRIMARY_FILTER_TYPE_BUTTERWORTH_LP,
																LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_LOW,
																LPS_WEIGH_PCM_SENSOR_TYPE_HPS_HE_RE);
		}

		else
		{
			pBestBkt->PayloadCalcMeth = CALC_METHOD_CONCAT(LPS_WEIGH_PCM_PRIMARY_FILTER_TYPE_BUTTERWORTH_LP,
																			LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_NONE,
																			LPS_WEIGH_PCM_SENSOR_TYPE_HPS_HE_RE);
		}
		LpsWrk.WeighDecFlag = FALSE;
	}

	/* update latch conditions ok flag */
	pBestBkt->LatchConditionsOK = LpsWeighLiveWtCheckLatchConditionsOk();

	/* update weight declared flag to indicate weight is latched */
	pBestBkt->WeighDecFlag = LpsWrk.WeighDecFlag;

							/****** CHECK FOR OVERLOAD WARNINGS ******/

	/*	If we are going from Not Digging to Digging, this should mean
		that machine is not in reverse	*/
	if( (LPS_WEIGHT_BKT_DIGGING == pDigDetectData->DigState) &&
		(LPS_WEIGHT_BKT_DIGGING != pOverloadWarningData->PrevDigState))
	{
		pOverloadWarningData->DigReverseFlag = FALSE;
	}
	if(LpsWeighIsRequestedGearReverse())
	{
		pOverloadWarningData->DigReverseFlag = TRUE;
	}
	/* Assigning current dig state to the previous dig state for next loop */
	pOverloadWarningData->PrevDigState = pDigDetectData->DigState;

	/* LHD Wrapper/Job Mgr gets to know when the bucket is in Wait for Latch condition and sets it accordingly */
	if(FALSE == GetBucketStateWaitForLatch())
	{
		accuracy = (unsigned_8)GET_ACCURACY(pBestBkt->PayloadCalcMeth);

		/* Checking if WRW or LLW */
		if(accuracy >= LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_MED)
		{
			/* Check if there are any reweigh warnings, bucket not racked is a reweigh warning */
			if(TRUE == pWrwWkTbl->ReweighPosted)
			{
				/* don't activate overload with reweigh warnings */
				pOverloadWarningData->BucketLoadFactor = 0.0;
			}
			else
			{
				/* Implies either a LLW or a WRW without reweigh warnings */
				if(0 == LpsWrk.UpdtTbl->LoaderBktPayldTrgtWt)
				{
					pOverloadWarningData->BucketLoadFactor = 0;
				}
				else
				{
					pOverloadWarningData->BucketLoadFactor = ((pBestBkt->Wt/LpsWrk.UpdtTbl->LoaderBktPayldTrgtWt)*100);
				}
			}
		}
		/* if transitioning from no weight, non-overload LLW, or non-overload WRW to live weight, make sure overload doesn't activate   */
		else if((LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_LOW == accuracy)&&(FALSE == pOverloadWarningData->InOverloadRange))
		{
			/* Currently displaying live weight, deactivate overload warnings */

			pOverloadWarningData->BucketLoadFactor = 0.0;
		}
	}
	else
	{
		/*Display is showing *** now, disable overload warnings */
		pOverloadWarningData->BucketLoadFactor = 0.0;
	}

	/*
		Set overload event if LLW or warning free WRW with bucket weight > 116.5% of Target Weight & Machine in Reverse
		Clear overload event if LLW or a warning free WRW with bucket weight < 110% of Target Weight

		PS: We need to make sure that the warnings are not cleared once the
			bucket weight goes above 116.5% till it goes below 110%
	*/
	pOverloadWarningData->InOverloadRange  =  ( (pOverloadWarningData->BucketLoadFactor >= LPS_OVERLOAD_DISABLE_THRESHOLD) &&
												((pOverloadWarningData->BucketLoadFactor > LPS_OVERLOAD_WT_THRESHOLD) ||
												(TRUE == pOverloadWarningData->InOverloadRange))) ? TRUE : FALSE;

    /* Removing the DigReverseFlag(TRUE == pOverloadWarningData->DigReverseFlag) check, as in stand alone reverse gear not applicable */
	if(TRUE == pOverloadWarningData->InOverloadRange)
	{
		pOverloadWarningData->OverloadActive = TRUE;
	}
	else
	{
		pOverloadWarningData->OverloadActive = FALSE;
	}
	
	LpsWrk.UpdtErr = LPS_UPDT_SUCCESS;
	
	return LpsWrk.UpdtErr;
}	



void LpsLiftStallDetectUpdate()
{

	unsigned_8 accuracy;
	LpsWeighBestBktWt_t BucketWt = LpsWeighGetBestAvailableBktWt();
	if (LPS_WEIGH_SYSTEM_CALIBRATED == LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.CalStat)
	{

		/*  Has 5 sec passed since coming out of stall? (live weight only) ***5 sec debounce no longer used, now just resets
		        first entrance to update*/
		if(LpsWrk.LpsStallDetect.reset_stall_timer)
		{
			// no longer considered stalled, remove ***'s from display
			LpsWrk.LpsStallDetect.payload_available =TRUE;
			LpsWrk.LpsStallDetect.stall_debounce_counter = 0;
			LpsWrk.LpsStallDetect.reset_stall_timer = FALSE;
			LpsWrk.LpsStallDetect.live_wt_stall = FALSE;
		}


		if(LPS_LIFT_STALL_NOT_STALLED == LpsWrk.LpsStallDetect.LiftStallStat)
		{

			if (LpsWrk.UpdtTbl->LiftCylExt.Val >= LPS_LIFT_HT_CLOSE_TO_FULL_RAISE)
			{
				LpsWrk.LpsStallDetect.lift_pos_too_high = TRUE;
			}
			else
			{
				LpsWrk.LpsStallDetect.lift_pos_too_high = FALSE;
			}

			if (LpsWrk.UpdtTbl->LiftCylExt.Val <= LPS_LIFT_HT_CLOSE_TO_FULL_LOWER)
			{
				LpsWrk.LpsStallDetect.lift_pos_too_low = TRUE;
			}
			else
			{
				LpsWrk.LpsStallDetect.lift_pos_too_low = FALSE;
			}

		}

		else if ((LpsWrk.UpdtTbl->LiftCylExt.Val < LPS_LIFT_HT_NOT_FULL_RAISE) &&
				(LpsWrk.UpdtTbl->LiftCylExt.Val > LPS_LIFT_HT_NOT_FULL_LOWER))
		{
			LpsWrk.LpsStallDetect.lift_pos_too_high = FALSE;
			LpsWrk.LpsStallDetect.lift_pos_too_low= FALSE;
		}

		accuracy = (unsigned_8)(GET_ACCURACY(BucketWt.PayloadCalcMeth));

		/* We are currently stalled.*/
		if (LpsWrk.LpsStallDetect.LiftStallStat == LPS_LIFT_STALL_STALLED)
		{
			if ((accuracy < LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_MED) && (LpsWrk.UpdtTbl->AutoManulDumpStateActiveFlag) &&
					!(LpsWrk.LpsStallDetect.live_wt_stall))
			{
				if ((LpsWrk.UpdtTbl->LiftCylExt.Val >= LPS_LIFT_HT_CLOSE_TO_FULL_RAISE) ||
						(LpsWrk.UpdtTbl->LiftCylExt.Val <= LPS_LIFT_HT_CLOSE_TO_FULL_LOWER) )
				{

					LpsWrk.LpsStallDetect.live_wt_stall = TRUE;
					LpsWrk.LpsStallDetect.payload_available = FALSE;
					LpsWrk.LpsStallDetect.stall_debounce_counter=0;

				}

			}
			/* Are we coming out of stall? */
			else if ((LpsWrk.UpdtTbl->LiftCylExt.Val < LPS_LIFT_HT_NOT_FULL_RAISE )&& (LpsWrk.UpdtTbl->LiftCylExt.Val > LPS_LIFT_HT_NOT_FULL_LOWER))
			{
				LpsWrk.LpsStallDetect.LiftStallStat = LPS_LIFT_STALL_NOT_STALLED;

				if (accuracy < LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_MED)
				{
					LpsWrk.LpsStallDetect.live_wt_stall = TRUE;
					LpsWrk.LpsStallDetect.payload_available = FALSE;
					LpsWrk.LpsStallDetect.reset_stall_timer=TRUE;
					LpsWrk.LpsStallDetect.stall_debounce_counter=0;
				}
				else if (LpsWrk.LpsStallDetect.live_wt_stall) // Live Weight
				{
					LpsWrk.LpsStallDetect.reset_stall_timer = TRUE;
					LpsWrk.LpsStallDetect.stall_debounce_counter = 0 ;
				}
			}
		}
		/* We are not currently stalled. Check if we are (only for live weight) */
		else
		{
			// Greater than highest allowable or Less than lowest allowable. Stalled
			if ((LpsWrk.UpdtTbl->LiftCylExt.Val >= LPS_LIFT_HT_CLOSE_TO_FULL_RAISE) ||
					(LpsWrk.UpdtTbl->LiftCylExt.Val <= LPS_LIFT_HT_CLOSE_TO_FULL_LOWER))
			{
				LpsWrk.LpsStallDetect.LiftStallStat = LPS_LIFT_STALL_STALLED;

				if((accuracy > LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_LOW))
				{
					//Do nothing, is latched weight, we do not want to cause reweigh or pop-up
				}
				else // Live weight
				{
					LpsWrk.LpsStallDetect.payload_available = FALSE;
					LpsWrk.LpsStallDetect.live_wt_stall = TRUE;
					LpsWrk.LpsStallDetect.stall_debounce_counter = 0 ;
				}
			}
		}
	}
	else
	{
		LpsWrk.LpsStallDetect.LiftStallStat = LPS_LIFT_STALL_NOT_STALLED;
	}

}

LpsGetStallStat_t LpsWeighGetStallStat (void)
{
	LpsWrk.UpdtTbl->LpsGetStallStat.LowerStall= LpsWrk.LpsStallDetect.lift_pos_too_low;
	LpsWrk.UpdtTbl->LpsGetStallStat.UpperStall= LpsWrk.LpsStallDetect.lift_pos_too_high;


	return (LpsWrk.UpdtTbl->LpsGetStallStat);
}

float LpsWeighGetBucketLoadFactor()
{
	return LpsWrk.OverloadWarnTbl.BucketLoadFactor;
}




