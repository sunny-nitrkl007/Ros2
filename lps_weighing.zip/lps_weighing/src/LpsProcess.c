/*******************************************************************************
** COPYRIGHT (C) 2016 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsProcess.c
DESCRIPTION:This file provides functionality for various calculations/algorithms
            performed by LPS library.
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <string.h>
#include <math.h>

#ifndef __LPS_COMMON_TYPE_DEF_H__
/* Contains type definitions of standard datatypes */
#include <LpsCommonTypeDef.h>
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h> /* Contains structures which are common between all LPS
                                  * system libraries
                  */
#endif

#ifndef  __LPS_COMMON_LOOKUP_TBL_UTILITY_H__
#include <LpsCommonLookUpTblUtility.h>
#endif

#ifndef __LPS_PUBLIC_H__
#include <LpsPublic.h> /*******************************************************/ 
                       /* Containes prototypes of interfaces and functions    */
                       /* which are exported to the application using the     */
                       /* library                                             */
                       /*******************************************************/
#endif

#include "LpsPrivate.h" /*******************************************************/ 
                        /* Containes prototypes of interfaces and functions    */
                        /* which are used within the payload computation       */
                        /* library                                             */
                        /*******************************************************/

#ifndef __CPM_FILTER_H__
#include <cpm_filter.h> /* Contains the functions from CPM Filter library of MAAL */
#endif

/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/******************************************************************************
FUNCTION NAME:LpsCalcCylFlowConst
DESCRIPTION: This function calculates the lift cylinder hydraulic oil flow constand
             based on machine specific configuration table passed on to the library
             by the application.
             
PARAMETER DESCRIPTION: LpsWrk.InitTbl.MachSpecificCfg.LiftCylBoreDia,
                       LpsWrk.InitTbl.MachSpecificCfg.LiftCylRodDia -> Lift cylinder bore
                       and rod diameter.
RETURN VALUE: LpsWrk.CylFlowConst.LiftHeFlowConst,LpsWrk.CylFlowConst.LiftReToHeFlowRatio
*******************************************************************************/
void LpsCalcCylFlowConst(void)
{
    float_32 liftCylBoreArea;
    float_32 liftCylRodArea;
  
    /* Calculating lift cylinder and lift piston rod areas for determining flow constand  - Cylinder area = (Pi * cylinder radius^2) */
    liftCylBoreArea  =  (PI_CONST * (LpsWrk.InitTbl.MachSpecificCfg.LiftCylBoreDia/(float_32)2.0) * 
                        (LpsWrk.InitTbl.MachSpecificCfg.LiftCylBoreDia/(float_32)2.0));
    liftCylRodArea   =  (PI_CONST * (LpsWrk.InitTbl.MachSpecificCfg.LiftCylRodDia/(float_32)2.0)  * 
                        (LpsWrk.InitTbl.MachSpecificCfg.LiftCylRodDia/(float_32)2.0));
  
    if( (liftCylRodArea > 0.0) &&
        (liftCylBoreArea > liftCylRodArea)
      )
    {
        LpsWrk.CylFlowConst.LiftHeFlowConst     = ((float_32)60.0 * liftCylBoreArea * LpsWrk.InitTbl.MachSpecificCfg.NoOfLiftCyls / (float_32)1000000.0);
        LpsWrk.CylFlowConst.LiftReToHeFlowRatio = (liftCylBoreArea - liftCylRodArea)/liftCylBoreArea;
    }
    else
    {
        LpsWrk.CylFlowConst.LiftHeFlowConst     = (float_32) 0.0;
        LpsWrk.CylFlowConst.LiftReToHeFlowRatio = (float_32)1.0;      
    }
  
    return;
}

/******************************************************************************
FUNCTION NAME:LpsGetHydOilVisc
DESCRIPTION: This function accepts hydraulic oil temperature as input and outputs the corresponding
             oil viscosity.The interpolation between the temperature and viscosity is determined using
             predefined maps for corresponding oil types. 
PARAMETER DESCRIPTION: hydOilTemp-> This interface holds the hydraulic oil temperature in degC
RETURN VALUE: Viscosity-> hold hydraulic oil viscosity for a particular temperature in Kg/m-3
*******************************************************************************/
static float_32 LpsGetHydOilVisc(float_32 hydOilTemp)
{
    /* Hydraulic oil temperature Vs Viscosity map x = temp in DegC ,y = Viscosity in Kg/m-3 */
    static const float_32 tempSAE10W[]  = { 0, 5, 10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100 }; /* Degrees C */
    static const float_32 viscSAE10W[]  = { 0.401163657, 0.271392082, 0.189249493, 0.135629739, 0.099636096, 0.074851526, 0.057384532, 0.035582067, 0.023450402, 0.016257589, 0.01175743, 0.008809872, 0.006801861, 0.005386759 }; /* kg/m-s */
    static const float_32 tempSAE0W20[] = { -40, -32, -18, 0, 21, 50, 80 };
    static const float_32 viscSAE0W20[] = { 4.16344705, 1.899216267, 0.600904802, 0.188654307, 0.067443573, 0.023985969, 0.011154169 };
    float_32 viscosity;
    

    if (LPS_OIL_TYPE_SAE_0W20 == LpsWrk.InitTbl.MachSpecificCfg.HydOilType)
    {
        viscosity = LpsLookup(hydOilTemp, tempSAE0W20, viscSAE0W20, sizeof(tempSAE0W20)/sizeof(float_32));
    }
    else
    { /* Assume Standard Oil as default */
        viscosity = LpsLookup(hydOilTemp, tempSAE10W, viscSAE10W, sizeof(tempSAE10W)/sizeof(float_32));
    }

    return viscosity;
}

/******************************************************************************
FUNCTION NAME:LpsGetHydOilDensity
DESCRIPTION: This function accepts hydraulic oil temperature as input and outputs the corresponding
             oil density.The interpolation between the temperature and density is determined using
             predefined maps for corresponding oil types. 
PARAMETER DESCRIPTION: hydOilTemp-> This interface holds the hydraulic oil temperature in degC
RETURN VALUE:  Density-> hold hydraulic oil density for a particular temperature in Kg/m^3
*******************************************************************************/
static float_32 LpsGetHydOilDensity(float_32 hydOilTemp)
{
  /* Hydraulic oil temperature Vs Viscosity map x = temp in DegC ,y = Density in Kg/m^3 */
    static const float_32 tempSAE10W[]  = { -20, 0, 20, 30, 40, 50, 60, 70, 80, 90, 100 }; /* Degrees C */
    static const float_32 densSAE10W[]  = { 903.1, 891.1, 877.7, 871, 864.4, 857.8, 851.2, 844.7, 838.2, 831.7, 825.2 }; /* kg/m3 */
    static const float_32 tempSAE0W20[] = { -40, -32, -18, 0, 21, 50, 80 };
    static const float_32 densSAE0W20[] = { 909.7, 904.1, 894.3, 881.7, 867, 846.7, 825.7 };
    float_32 density;
    

    if (LPS_OIL_TYPE_SAE_0W20 == LpsWrk.InitTbl.MachSpecificCfg.HydOilType)
    {
        density = LpsLookup(hydOilTemp, tempSAE0W20, densSAE0W20, sizeof(tempSAE0W20)/sizeof(float_32));
    }
    else
    { /* Assume Standard Oil as default */
        density = LpsLookup(hydOilTemp, tempSAE10W, densSAE10W, sizeof(tempSAE10W)/sizeof(float_32));
    }

    return density;
}

/******************************************************************************
FUNCTION NAME:LpsCalcDiffPres
DESCRIPTION: This function computes the lift cylinder effective pressure.The pressure
             is calculated taking into considerations of the head end and rod end
             hydraulic pressure difference.Hrdraulic line losses are calculated by
             determining orfice loss and line loss based on machine physics which
             are acquired through machine specfic configuration inputs from application
             software.  
 
PARAMETER DESCRIPTION: LpsWrk.CylFlowConst.LiftHeFlowConst-> predetermined Head end 
                       flow constand to calculate lift cylinder head end oil flow.
                       LpsWrk.CylFlowConst.LiftReToHeFlowRatio) -> predetermined head end 
                       to rod end ratio for rod end oil flow computation
                       LpsWrk.InitTbl.MachSpecificCfg.HydPressLossCoeff.LiftCylHeLineLoss2ndOrdrCoeff,
                       LpsWrk.InitTbl.MachSpecificCfg.HydPressLossCoeff.LiftCylHeLineLoss1stOrdrCoeff
                       LpsWrk.InitTbl.MachSpecificCfg.HydPressLossCoeff.LiftCylHeLineLoss2ndOrdrCoeff,
                       LpsWrk.InitTbl.MachSpecificCfg.HydPressLossCoeff.LiftCylHeLineLoss1stOrdrCoeff
                       -> hydraulic Line loss coefficients calulated for a particular machine.
RETURN VALUE: LpsWrk.LiftCylPres-> Hold the hydraulic pressure loss compensated
              lift cylinder pressure in Kpa      
*******************************************************************************/
void LpsCalcDiffPres(void)
{
    float_32 liftCylHePres;
    float_32 liftCylRePres;
    float_32 diffPres;
    float_32 hydOilTemp;
    float_32 hydOilVisc;
    float_32 hydOilDensity;
    float_32 liftCylHeOilFlow;
    float_32 liftCylReOilFlow;
    float_32 liftCylVel;
    float_32 oilFlowSquaredCoeff;
    float_32 OilFlowCoeff;
    float_32 oilPresLoss;
    LpsUpdtTbl_t *updtTbl;
  

	updtTbl = LpsWrk.UpdtTbl;

	if((TRUE == LpsWrk.UpdtTbl->UseFilterDataFlag))
	{
		liftCylHePres = updtTbl->LiftCylHePres.Val;
		liftCylRePres = updtTbl->LiftCylRePres.Val;
		hydOilTemp    = updtTbl->HydOilTemp.Val;
		hydOilVisc    = LpsGetHydOilVisc(hydOilTemp);
		hydOilDensity = LpsGetHydOilDensity(hydOilTemp);
		liftCylVel    = updtTbl->LiftCylVel.Val;

		/* Calculating the Head End and Rod End cylinder hydraulic oil flow*/
		liftCylHeOilFlow = (liftCylVel * LpsWrk.CylFlowConst.LiftHeFlowConst);
		liftCylReOilFlow = (liftCylHeOilFlow * LpsWrk.CylFlowConst.LiftReToHeFlowRatio);

		/* The temperature compensation strategy models the pressure losses with a quadratic equation in flow
								P = Orifice Loss + Line Loss
								Orifice Loss = (rho * Q^2) / (2 * Cd^2 * pi^2 * R^4)
								Line Loss = (8 * Kg * mu * Q * l) / (pi * R^4)

								rho = Density (kg/m^3)
								Q = Flow (LPM)
								Cd = Discharge Coefficient
								R = Effective Radius of Line
								Kg = Line Loss Geometry Coefficient
								mu = Viscosity (kg/m-s)
								l = Line Length

								rho, mu are determined from oil type and hydraulic oil temperature
								Q is measured
								R and l are calculated from the lines geometry
								Cd and Kg are determined by regression analysis on test machine data where we have the pressures
									measured at the cylinders as well as the production location of the pressure sensors.
									An alternative method of determining Cd and Kg is to estimate them from CFD analysis.
									(CFD - Computational Fluid Dynamics)

								In the end, it doesn't matter much what you pick for R and l because the regression coefficients
									Cd and Kg will account for any error there.  The coefficients are lumped up together for
									implementation in the PCS code.
		   */

		 /* Determining Lift Cylinder Head End pressure drop */
		oilFlowSquaredCoeff = (LpsWrk.InitTbl.MachSpecificCfg.HydPressLossCoeff.LiftCylHeLineLoss2ndOrdrCoeff * hydOilDensity);
		OilFlowCoeff        = (LpsWrk.InitTbl.MachSpecificCfg.HydPressLossCoeff.LiftCylHeLineLoss1stOrdrCoeff * hydOilVisc);

		if(liftCylHeOilFlow >= 0)
		{
			oilPresLoss   = (liftCylHeOilFlow * liftCylHeOilFlow * oilFlowSquaredCoeff + liftCylHeOilFlow * OilFlowCoeff);
			liftCylHePres = (liftCylHePres - oilPresLoss);
		}
		else
		{
			oilPresLoss   = (liftCylHeOilFlow * liftCylHeOilFlow * oilFlowSquaredCoeff - liftCylHeOilFlow * OilFlowCoeff);
			liftCylHePres = (liftCylHePres + oilPresLoss);
		}

		 /* Determining Lift Cylinder Rod End pressure drop */
		oilFlowSquaredCoeff = (LpsWrk.InitTbl.MachSpecificCfg.HydPressLossCoeff.LiftCylReLineLoss2ndOrdrCoeff * hydOilDensity);
		OilFlowCoeff        = (LpsWrk.InitTbl.MachSpecificCfg.HydPressLossCoeff.LiftCylReLineLoss1stOrdrCoeff * hydOilVisc);

		if(liftCylReOilFlow >= 0)
		{
			oilPresLoss   = (liftCylReOilFlow * liftCylReOilFlow * oilFlowSquaredCoeff + liftCylReOilFlow * OilFlowCoeff);
			liftCylRePres = (liftCylRePres - oilPresLoss);
		}
		else
		{
			oilPresLoss   = (liftCylReOilFlow * liftCylReOilFlow * oilFlowSquaredCoeff - liftCylReOilFlow * OilFlowCoeff);
			liftCylRePres = (liftCylRePres + oilPresLoss);
		}

		 /* Determining/calculating Lift cylinder Rod End Pressure by eleminating the Rod area */
		if((LpsWrk.CylFlowConst.LiftReToHeFlowRatio > (float_32) 0.0) &&
		   (LpsWrk.CylFlowConst.LiftReToHeFlowRatio <= 1.0)
		  )
		{
			liftCylRePres = (liftCylRePres * LpsWrk.CylFlowConst.LiftReToHeFlowRatio);
		}

		if(liftCylHePres > liftCylRePres)
		{
			diffPres = liftCylHePres - liftCylRePres;
		}
		else
		{
			diffPres = 0.0;
		}

		LpsWrk.LiftCylPres = diffPres;
    }
      
    return;
}

/******************************************************************************
FUNCTION NAME: LpsUpdateLinkageMovement
DESCRIPTION: Calculates the state of linkage movement.
             Lift could be Raising (Positive), Lowering (Negative), or Stopped
             Tilt could be Racking (Positive), Dumping (Negative), or Stopped
******************************************************************************/
void LpsUpdateLinkageMovement(void) {
    LpsUpdtTbl_t* updtTbl = LpsWrk.UpdtTbl;
    
    if (NULL != updtTbl) {
        // Update lift movement state
        if (LPS_CYL_VEL_STATUS_OK == updtTbl->LiftCylVel.Stat) {
            float_32 velocity = updtTbl->LiftCylVel.Val; // Lift cylinder velocity in mm/s
            LpsLinkageMovementStat_t state;
            if (velocity > 20.0f) {
                state = LPS_LINKAGE_MOVEMENT_POSITIVE;
            } else if (velocity < -20.0f) {
                state = LPS_LINKAGE_MOVEMENT_NEGATIVE;
            } else {
                state = LpsWrk.LinkageMovement.lift;
                if ((LPS_LINKAGE_MOVEMENT_POSITIVE == state) && (velocity <= 0.0f)) {
                    state = LPS_LINKAGE_MOVEMENT_STOPPED;
                } else if ((LPS_LINKAGE_MOVEMENT_NEGATIVE == state) && (velocity >= 0.0f)) {
                    state = LPS_LINKAGE_MOVEMENT_STOPPED;
                }
            }
            LpsWrk.LinkageMovement.lift = state;
        } else {
            // Default to 'stopped'.
            LpsWrk.LinkageMovement.lift = LPS_LINKAGE_MOVEMENT_STOPPED;
        }
        
        // Update tilt movement state
        if (LPS_CYL_VEL_STATUS_OK == updtTbl->TiltCylVel.Stat) {
            float_32 velocity = updtTbl->TiltCylVel.Val; // Tilt cylinder velocity in mm/s
            LpsLinkageMovementStat_t state;
            if (velocity > 20.0f) {
                state = LPS_LINKAGE_MOVEMENT_POSITIVE;
            } else if (velocity < -20.0f) {
                state = LPS_LINKAGE_MOVEMENT_NEGATIVE;
            } else {
                state = LpsWrk.LinkageMovement.tilt;
                if ((LPS_LINKAGE_MOVEMENT_POSITIVE == state) && (velocity <= 0.0f)) {
                    state = LPS_LINKAGE_MOVEMENT_STOPPED;
                } else if ((LPS_LINKAGE_MOVEMENT_NEGATIVE == state) && (velocity >= 0.0f)) {
                    state = LPS_LINKAGE_MOVEMENT_STOPPED;
                }
            }
            LpsWrk.LinkageMovement.tilt = state;
        } else {
            // Default to 'stopped'.
            LpsWrk.LinkageMovement.tilt = LPS_LINKAGE_MOVEMENT_STOPPED;
        }
    } else {
        // Default to 'stopped'.
        LpsWrk.LinkageMovement.lift = LPS_LINKAGE_MOVEMENT_STOPPED;
        LpsWrk.LinkageMovement.tilt = LPS_LINKAGE_MOVEMENT_STOPPED;
    }
}

/******************************************************************************
FUNCTION NAME:LpsCalcInstantWt
DESCRIPTION: Instantaneous Weight is computed in this function.The function uses
             various calibration maps passed by application to interpolate the
             difference pressure based on lift cyclinder externsion percentage.
             Lift cyclinder velocity is used to determine the direction of movement
             of the linkage and velocity compensation is done to differnce pressure
             to determine the weight. 
PARAMETER DESCRIPTION:LpsCalib_t -> calibration table passed by application.
                      LpsWrk.UpdtTbl.LiftCylVel->Lift cylinder velocity.
RETURN VALUE: LpsWrk.InstWtRaw.Val,LpsWrk.InstWtRaw.Stat->Instantaneous weight in Tonnes
              and status.
*******************************************************************************/
void LpsCalcInstantWt(void)
{
    float_32 emptyBktPres;
    float_32 fullBktPres;
    float_32 instRawWtSlope = 0;
  
    LpsUpdtTbl_t *updtTbl;
    LpsCalib_t   *calib;
  
    updtTbl = LpsWrk.UpdtTbl;
    calib   = &LpsWrk.InitTbl.MachSpecificCfg.CalibTbl;
    
    { // Update the static weigh factor
        float_32 raw;
        boolean mode;

        if (LPS_LINKAGE_MOVEMENT_POSITIVE == LpsWrk.LinkageMovement.lift) {
            mode = FALSE;
            raw = 0.5;
        } else if (LPS_LINKAGE_MOVEMENT_NEGATIVE == LpsWrk.LinkageMovement.lift) {
            mode = FALSE;
            raw = 0.0;
        } else {
            mode = TRUE;
            raw = 0.3;
        }
        
        LpsWrk.StaticWtFactor.OlRaw = raw;
        LpsWrk.StaticWtFactor.OlFilt += ((LpsWrk.InitTbl.ExecRate)/LpsWrk.StaticWtFactor.Tau) * (raw - LpsWrk.StaticWtFactor.OlFilt);
        LpsWrk.StaticWtFactor.Curr = LpsWrk.StaticWtFactor.OlFilt;
    }

    if (LPS_LINKAGE_MOVEMENT_POSITIVE == LpsWrk.LinkageMovement.lift) /* Checking if the linkage is raising */
    {
        float_32 emptyBktVelCompPres;
        float_32 fullBktVelCompPres;
        float_32 linkageSpd = updtTbl->LiftCylVel.Val;
      
        /* Determining calibration empty and full bucket pressure (for raise) based on linkage height/lift cylinder extension */
        emptyBktPres = LpsLookupExtrap(updtTbl->LiftCylExt.Val,calib->SlowRaiseEmptyBktLiftHt,
                                 calib->SlowRaiseEmptyBktLiftPres,
                     sizeof(calib->SlowRaiseEmptyBktLiftHt) / sizeof(calib->SlowRaiseEmptyBktLiftHt[0]));
          
        fullBktPres  = LpsLookupExtrap(updtTbl->LiftCylExt.Val,calib->SlowRaiseFullBktLiftHt,
                               calib->SlowRaiseFullBktLiftPres,
                     sizeof(calib->SlowRaiseFullBktLiftHt) / sizeof(calib->SlowRaiseFullBktLiftHt[0]));
    
        /* Velocity compensation */
        if(linkageSpd < calib->EmptyBktSlowRaiseSpd)
        {
            emptyBktVelCompPres = 0.0;
        }
        else if(linkageSpd > calib->EmptyBktFastRaiseSpd)
        {
            emptyBktVelCompPres = calib->FastRaiseEmptyBktDeltaPres;
        }
        else if (calib->EmptyBktFastRaiseSpd > calib->EmptyBktSlowRaiseSpd)
        {
            emptyBktVelCompPres = ((calib->FastRaiseEmptyBktDeltaPres/(calib->EmptyBktFastRaiseSpd - calib->EmptyBktSlowRaiseSpd)) *
                         (linkageSpd - calib->EmptyBktSlowRaiseSpd));
        }
        else
        {
            emptyBktVelCompPres = 0.0;
        }
      
        if(linkageSpd < calib->FullBktSlowRaiseSpd)
        {
            fullBktVelCompPres = 0.0;
        }
        else if(linkageSpd > calib->FullBktFastRaiseSpd)
        {
            fullBktVelCompPres = calib->FastRaiseFullBktDeltaPres;
        }
        else if (calib->FullBktFastRaiseSpd > calib->FullBktSlowRaiseSpd)
        {
            fullBktVelCompPres = ((calib->FastRaiseFullBktDeltaPres/(calib->FullBktFastRaiseSpd - calib->FullBktSlowRaiseSpd)) *
                          (linkageSpd - calib->FullBktSlowRaiseSpd));
        }
        else
        {
            fullBktVelCompPres = 0.0;
        }
      
        emptyBktPres = (emptyBktPres + emptyBktVelCompPres);
        fullBktPres  = (fullBktPres + fullBktVelCompPres);
    }
    else if (LPS_LINKAGE_MOVEMENT_NEGATIVE == LpsWrk.LinkageMovement.lift) /* Checking if the linkage is lowering */
    {
        emptyBktPres = LpsLookupExtrap(updtTbl->LiftCylExt.Val,calib->SlowLowerEmptyBktLiftHt,
                    calib->SlowLowerEmptyBktLiftPres, 
                    sizeof(calib->SlowLowerEmptyBktLiftHt) / sizeof(calib->SlowLowerEmptyBktLiftHt[0]));
                
        fullBktPres  = LpsLookupExtrap(updtTbl->LiftCylExt.Val,calib->SlowLowerFullBktLiftHt,
                               calib->SlowLowerFullBktLiftPres,
                     sizeof(calib->SlowLowerFullBktLiftHt) / sizeof(calib->SlowLowerFullBktLiftHt[0]));
    }
    else /* Linkage is not moving */
    {
        float_32 emptyBktRaisePres;
        float_32 fullBktRaisePres;
        float_32 emptyBktLowerPres;
        float_32 fullBktLowerPres;

        emptyBktRaisePres = LpsLookupExtrap(updtTbl->LiftCylExt.Val,calib->SlowRaiseEmptyBktLiftHt,
                                            calib->SlowRaiseEmptyBktLiftPres,
                      sizeof(calib->SlowRaiseEmptyBktLiftHt) / sizeof(calib->SlowRaiseEmptyBktLiftHt[0]));
      
        emptyBktLowerPres = LpsLookupExtrap(updtTbl->LiftCylExt.Val,calib->SlowLowerEmptyBktLiftHt,
                                            calib->SlowLowerEmptyBktLiftPres,
                      sizeof(calib->SlowLowerEmptyBktLiftHt) / sizeof(calib->SlowLowerEmptyBktLiftHt[0]));
      
        fullBktRaisePres  = LpsLookupExtrap(updtTbl->LiftCylExt.Val,calib->SlowRaiseFullBktLiftHt,
                                            calib->SlowRaiseFullBktLiftPres,
                      sizeof(calib->SlowRaiseFullBktLiftHt) / sizeof(calib->SlowRaiseFullBktLiftHt[0]));
      
        fullBktLowerPres  = LpsLookupExtrap(updtTbl->LiftCylExt.Val,calib->SlowLowerFullBktLiftHt,
                                            calib->SlowLowerFullBktLiftPres,
                      sizeof(calib->SlowLowerFullBktLiftHt) / sizeof(calib->SlowLowerFullBktLiftHt[0]));

        emptyBktPres = ((emptyBktRaisePres - emptyBktLowerPres) * LpsWrk.StaticWtFactor.Curr) + emptyBktLowerPres;
        fullBktPres  = ((fullBktRaisePres  -  fullBktLowerPres) * LpsWrk.StaticWtFactor.Curr) + fullBktLowerPres;
    }

    /* Determining Instantaneous Weight based on calibration payload weight */
    if(fullBktPres > emptyBktPres)
    {
        instRawWtSlope        = (calib->Calwt / (fullBktPres - emptyBktPres));
        LpsWrk.InstWtRaw.Val  = (instRawWtSlope * (LpsWrk.LiftCylPres - emptyBktPres));
        LpsWrk.InstWtRaw.Stat = LPS_INST_RAW_WT_STATUS_OK;
    }
    else
    {
        LpsWrk.InstWtRaw.Val  = 0.0;
        LpsWrk.InstWtRaw.Stat = LPS_INST_RAW_WT_STATUS_BAD;
    }
  
    LpsTiltCompensation(instRawWtSlope);

    return;
}

/******************************************************************************
FUNCTION NAME:LpsTiltCompensation
DESCRIPTION: This function computes the Tilt Compensation factor to be scaled on 
             the raw instantaneous weight. 
PARAMETER DESCRIPTION:InstRawWtSlope -> This is the Raw Weight Slope which is 
              ((Cal Weight)/(Full pressure - empty pressure))*(Current pressure - empty pressure)
RETURN VALUE: None
*******************************************************************************/
void LpsTiltCompensation(float_32 instRawWtSlope)
{
    float_32 tiltcompH;
    float_32 tiltcompGain;
    float_32 num;
    LpsMachSpecificCfg_t* LpsMachSpecConfTbl = &LpsWrk.InitTbl.MachSpecificCfg;

    /*We want to proceed with tilt compensation only if none of the sensors are faulted and 
     the tilt cylinder extension percentage is greater 0%*/
    if((LpsChkInputStat() == STATUS_GOOD))
    {
        /*In the case that any of the compensation maps are NULL, then we need go to Lookup2d and we can 
          safely assumet that the tilt compensation gain to be 0*/
        if((NULL == LpsMachSpecConfTbl->TiltMap.ColumnAxis) || (NULL == LpsMachSpecConfTbl->TiltMap.RowAxis)
           || (NULL == LpsMachSpecConfTbl->TiltMap.Data))
        {
            tiltcompH = 0;
        }
        else
        {
            tiltcompH = LpsLookup2d(LpsWrk.UpdtTbl->LiftCylExt.Val,LpsWrk.UpdtTbl->TiltCylExt.Val,
                                                       LpsMachSpecConfTbl->TiltMap.ColumnAxis,LpsMachSpecConfTbl->TiltMap.RowAxis,
                                                       LpsMachSpecConfTbl->TiltMap.Data,LpsMachSpecConfTbl->TiltMap.NumColumns,
                                                       LpsMachSpecConfTbl->TiltMap.NumRows);
        }

        /*We are obtaining the tilt compensation gain by scaling on the Raw Weight Slope based on the tunable factor to reduce/increase the 
          effect of tilt compensation from the app side and Lookup tilt compensation gain */
        tiltcompGain = instRawWtSlope * tiltcompH * LpsMachSpecConfTbl->TiltComp.TiltCompGainScalar;

        /*We want to limit the range of the calculated tilt gain value to the maximum limiting value*/
        if(tiltcompGain > LpsMachSpecConfTbl->TiltComp.TiltCompMaxGain)
        {
            tiltcompGain = LpsMachSpecConfTbl->TiltComp.TiltCompMaxGain;
        }
        /*Here we want to limit the range of the calculated tilt gain value not only to the positive maximum limit, 
          but also to the negative minimum limit*/
        else if(tiltcompGain < ((float_32)-1.0 * LpsMachSpecConfTbl->TiltComp.TiltCompMaxGain))
        {
            tiltcompGain = (float_32)-1.0 * LpsMachSpecConfTbl->TiltComp.TiltCompMaxGain;
        }

        /*If the Tilt Compensation gain is at the highest limit, then retain the old weight*/
        if(((float_32)0.0 == ((float_32)1.0 - tiltcompGain)) || (LpsMachSpecConfTbl->CalibTbl.EmptyBktWtEst <= (float_32)0.0))
        {
            /*Retain the old weight*/
        }
        else
        {
            /*Here the actual scaling factor is added to the raw instantaneous weight*/
            num = LpsWrk.InstWtRaw.Val + tiltcompGain * LpsMachSpecConfTbl->CalibTbl.EmptyBktWtEst * LpsMachSpecConfTbl->TiltComp.TiltCompEmptyBktWtGain;

            LpsWrk.InstWtRaw.Val = num/((float_32)1.0 - tiltcompGain);
        }
    }
    else
    {
        /*Retain the old weight*/
    }
}

