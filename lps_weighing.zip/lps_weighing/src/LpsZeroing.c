/*******************************************************************************
** COPYRIGHT (C) 2016 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsZeroing.c
DESCRIPTION:This file provides the method to process the request to adjust the 
            Tare weight of the implement. 
            This is referred to as the zero value or zero function in previous 
            PCS library.
******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef __LPS_COMMON_TYPE_DEF_H__
/* Contains type definitions of standard datatypes */
#include <LpsCommonTypeDef.h>
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
/* Contains structures which are common between all LPS system libraries  */
#include <LpsCommonStructures.h> 
#endif

#ifndef  __LPS_COMMON_LOOKUP_TBL_UTILITY_H__
#include <LpsCommonLookUpTblUtility.h>
#endif

#ifndef __LPS_PUBLIC_H__
/* Containes prototypes of interfaces and functions    */
/* which are exported to the application using the     */
/* library                                             */
#include <LpsPublic.h> 
#endif

#include "LpsPrivate.h"

#ifndef __LPS_COMMON_TYPE_DEF_H__
/* Contains type definitions of standard datatypes */
#include <LPSCommonTypeDef.h>
#endif

#ifndef __CPM_FILTER_H__
/* Contains the functions from CPM Filter library of MAAL */
#include <cpm_filter.h> 
#endif

#include <string.h>
#include <math.h>
#include <stdio.h>


/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/******************************************************************************
FUNCTION NAME:LpsWeighZeroInit
DESCRIPTION: Initialize zero function required vairables.
PARAMETER DESCRIPTION:None
RETURN VALUE: None
*******************************************************************************/
void LpsWeighZeroInit(void)
{
	LpsWrk.ZeroAdjTbl.ZeroTemp = LPS_LOW_TEMP_ZER0_DEFAULT;
	LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.PwrOn = TRUE;
	LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.LiftStatus = TRUE;
	LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.LastZeroTimerReset = 0;
}

/******************************************************************************
FUNCTION NAME:  LpsWeighZeroAdjust()

DESCRIPTION:  Process the request to zero the implement weight from the operator
                (Zero Button function)

METHOD:     

REENTRANCY:

NOTES:  None.

GLOBALS USED:   None.

PARAMETER DESCRIPTION:  None.

RETURN VALUE:   None.

*******************************************************************************/
void LpsWeighZeroAdjust(void)
{
    LpsZeroErrorTypes_t ZAStatus;
    LpsWeighBestBktWt_t BucketWt;
    LpsMachSpecificCfg_t* pMachSpecConf = &LpsWrk.InitTbl.MachSpecificCfg;
	LpsCalib_t* pCalTbl = &pMachSpecConf->CalibTbl;
    BucketWt = LpsWeighGetBestAvailableBktWt();
	
	LpsWeighSetZeroAcceptedStatus(FALSE);
    
    /* check for calibration complete, can't adjust if not calibrated */
    if(LPS_WEIGH_SYSTEM_UNCALIBRATED  == LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.CalStat)
    {
        ZAStatus = LPS_ZERO_UPDATE_NOT_CALIBRATED;
    }
    /* check accuracy of bucket weight, need to be at accepted level to adjust */
    else if ( LpsWrk.InitTbl.MachSpecificCfg.ZeroBktWtAccuracyLimit > (unsigned_8)(GET_ACCURACY(BucketWt.PayloadCalcMeth)))
    {
        ZAStatus = LPS_ZERO_UPDATE_BUCKET_WT_NOT_ACCURATE;
    }
    else
    {
        /* If the zero'd weight is +/- Max Zero Weight
        then we can accept this lift */             
        if((LpsWrk.WrwTbl.WkTbl.WtAvg < (LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.Calwt * LpsWrk.InitTbl.MachSpecificCfg.ZeroRangeLimit)) &&
        (LpsWrk.WrwTbl.WkTbl.WtAvg > -LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.Calwt * LpsWrk.InitTbl.MachSpecificCfg.ZeroRangeLimit))
        {
            
			pCalTbl->ZeroWeight = LpsWrk.WrwTbl.WkTbl.WtAvg;
			

            /* Set the last temperature zero variable to the current temperature */
            if (LPS_HYD_OIL_TEMP_STATUS_OK == LpsWrk.UpdtTbl->HydOilTemp.Stat)
            {
                LpsWrk.ZeroAdjTbl.ZeroTemp = LpsWrk.UpdtTbl->HydOilTemp.Val;
            }
            /*Added to stop the ZeroAdjAutoSnooze.PowrOn timer*/
            LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.PwrOn = FALSE;
            LpsWeighZeroNotify(FALSE); /* Remove zero lift needed EID and reset 4 hour timer */
            ZAStatus = LPS_ZERO_UPDATE_SUCCESS;   

            LpsWeighSetZeroAcceptedStatus(TRUE);
            LpsWeighResetBestAvailableBktWt();
			LpsWeighSetTooHeavyToZero(FALSE);
        }
        else
        {
            ZAStatus = LPS_ZERO_UPDATE_TOO_HEAVY_TO_ZERO;
			LpsWeighSetTooHeavyToZero(TRUE);
        }
    }
    LpsWeighSetZeroAdjStatus(ZAStatus);
    return;
}


/******************************************************************************
FUNCTION NAME:LpsWeighAutoZeroSnooze
DESCRIPTION: When weighing auto snooze zero required status.
PARAMETER DESCRIPTION:None
RETURN VALUE: None
*******************************************************************************/
void LpsWeighAutoZeroSnooze(void)
{
    /* If there is something to snooze */
    if (LPS_ZERO_UPDATE_ZERO_NOT_REQUIRED != LpsWeighGetAutoZeroUpdateStatus())
    {
        /* And we are not already snoozed */
        if (!(LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed))
        {
            /* Snooze this for 10 minutes */
            LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.SnoozedStatus = LpsWrk.ZeroAdjTbl.AutoZeroStatus;
            LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.LastSnoozedTime = LpsWrk.UpdtTbl->ClockKeyonSec;
            LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed = TRUE;
            LpsWeighSetAutoZeroUpdateStatus(LPS_ZERO_UPDATE_ZERO_NOT_REQUIRED);
        }
    }
}

/******************************************************************************
FUNCTION NAME:  LpsWeighAutoZeroUpdate()

DESCRIPTION:  Calculates when to alert the operator that a zero lift is needed

METHOD:     Use the key_on_ms_clock to determine when 4 hours has elasped.

REENTRANCY:

NOTES:  None.

GLOBALS USED:   None.

PARAMETER DESCRIPTION:  None.
        ZAError = LPS_ZERO_UPDATE_BUCKET_WT_NOT_ACCURATE;   

RETURN VALUE:   None. 
*******************************************************************************/
LpsUpdtErrorTypes_t LpsWeighAutoZeroUpdate(void)
{
    LpsZeroNeededStatus_t AZUStat = LPS_ZERO_UPDATE_ZERO_NOT_REQUIRED;
	LpsWrk.UpdtErr = LPS_UPDT_UNKNOWN_ERROR;

    /* check for calibration complete, can't adjust if not calibrated */
    if(LPS_WEIGH_SYSTEM_CALIBRATED  == LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.CalStat)
    {
        //clock will be an issue on standalone A5m4 kit
        /* Get the current keyon sec clock */
        unsigned_32 CurrentTimeSec = LpsWrk.UpdtTbl->ClockKeyonSec;
        // Yes, StandbyActiveState == FALSE does actually mean we are in Standby...call me crazy
        if (( LpsWrk.WrwTbl.WkTbl.Weighing ) || (FALSE == LpsWrk.UpdtTbl->StandbyActiveState))
        {
            LpsWeighAutoZeroSnooze();
        }
        if (LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed)
        {
            /* check if we have any passes recorded yet */

            if ((0 == LpsWrk.UpdtTbl->PassCount) &&
                (LPS_ZERO_SNOOZE_INTERVAL < LpsCommonGetTimeDiffSec(CurrentTimeSec, LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.LastSnoozedTime)))
            {
                /* Snooze has expired set zero required flag */
                AZUStat = LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.SnoozedStatus;
                LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed = FALSE;
            }
        }         
        else if (0 == LpsWrk.UpdtTbl->PassCount)
        {
            /* If the hydraulic oil temperature is below the empty cal temp + 5 and has increased more
               than 10 degress C. or if hyrdaulic temperature is below empty cal temp -5 deg C and has
               decreased more than 10 degrees C*/
            if ((LpsWrk.ZeroAdjTbl.ZeroTemp != LPS_LOW_TEMP_ZER0_DEFAULT) &&
                (LpsWeighHydraulicOilTempValid(LpsWrk.UpdtTbl->HydOilTemp.Val, LpsWrk.UpdtTbl->HydOilTemp.Stat)) &&
                ((((LpsWrk.UpdtTbl->HydOilTemp.Val <= LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.EmptyTemp) || (LpsWrk.UpdtTbl->HydOilTemp.Val < LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjOilTempWarnThreshold)) &&
                  (LpsWrk.UpdtTbl->HydOilTemp.Val >= LpsWrk.ZeroAdjTbl.ZeroTemp + LPS_OIL_TEMP_DELTA)) ||
                 ((LpsWrk.UpdtTbl->HydOilTemp.Val <= LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.EmptyTemp - LPS_EMPTY_CAL_OIL_TEMP_DELTA) &&
                  (LpsWrk.UpdtTbl->HydOilTemp.Val <= LpsWrk.ZeroAdjTbl.ZeroTemp - LPS_OIL_TEMP_DELTA))))
            {
                /* Notify operator he needs to zero bucket */
                LpsWeighZeroNotify(TRUE);
                AZUStat = LPS_ZERO_UPDATE_TEMPERATURE_CHANGE_ZERO_REQUIRED;
            }
            else if (LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.LiftStatus)
            {
            	if (LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.PwrOn)
                {
                    if (LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjInitTimeInterval <= LpsCommonGetTimeDiffSec(CurrentTimeSec, LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.LastZeroTimerReset))
                    {
                        /* Notify operator he needs to zero bucket */
                        LpsWeighZeroNotify(TRUE);
                        AZUStat = LPS_ZERO_UPDATE_TIMER_EXPIRED_ZERO_REQUIRED;
                    }
                }
                else
                {
                    if (LpsWrk.InitTbl.MachSpecificCfg.ZeroAdjAutoTimeInterval <= LpsCommonGetTimeDiffSec(CurrentTimeSec, LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.LastZeroTimerReset))
                    {
                        /* Notify operator he needs to zero bucket  */
                        LpsWeighZeroNotify(TRUE);
                        AZUStat = LPS_ZERO_UPDATE_TIMER_EXPIRED_ZERO_REQUIRED;
                    }
                }
            }
            else
            {
                /* To hold the PowerOn status untill zero is pressed added */
            	AZUStat = LpsWeighGetAutoZeroUpdateStatus();
            }
            /* Else let clocks continue to increment */
        }
    }
    else
    {   /* zero update is not required */
        LpsWeighZeroNotify(FALSE);
    }
    LpsWeighSetAutoZeroUpdateStatus(AZUStat);
	
	LpsWrk.UpdtErr = LPS_UPDT_SUCCESS;
    return LpsWrk.UpdtErr;
}

/******************************************************************************
FUNCTION NAME:  LpsWeighZeroNotify()

DESCRIPTION:  Post zero lift needed EID and resets the four hour timer for
              the auto zero.

METHOD:     Stores the current time into the last time variable.

REENTRANCY:

NOTES:  None.

GLOBALS USED:   None.

PARAMETER DESCRIPTION:  None.

RETURN VALUE:   None.

*******************************************************************************/
void LpsWeighZeroNotify(boolean zeroRequiredState)
{
    /* Saved current rtc clock */
    LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.LastZeroTimerReset = LpsWrk.UpdtTbl->ClockKeyonSec;

    if (FALSE == zeroRequiredState)
    {
        LpsWeighSetAutoZeroUpdateStatus(LPS_ZERO_UPDATE_ZERO_NOT_REQUIRED);
        /* Zero perform, start the 4 hour timer again */
        LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.LiftStatus = TRUE;
    }
    else
    {
        /* Do not calcuate zero warning while it is active */
        LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.LiftStatus = FALSE;
    }

    /* Sets the needed zero status */
    LpsWrk.ZeroAdjTbl.ZeroAdjAutoSnooze.Snoozed = FALSE;
}

/******************************************************************************
FUNCTION NAME:  LpsWeighSetZeroAdjError(error)

DESCRIPTION:  Set the zero adjust error for access by calling function.


PARAMETER DESCRIPTION:  uses LpsZeroErrorTypes_t enum.

RETURN VALUE:   None.

*******************************************************************************/
void LpsWeighSetZeroAdjStatus(LpsZeroErrorTypes_t Status)
{    
    LpsWrk.ZeroAdjTbl.ZeroAdjStatus = Status;
}

/******************************************************************************
FUNCTION NAME:  LpsWeighGetZeroAdjError(void)

DESCRIPTION:  Return the zero adjust error for access by calling function.


PARAMETER DESCRIPTION:  uses LpsZeroErrorTypes_t enum.

RETURN VALUE:   None.
>>>>>>NOTE this needs to be accessible to calling function or App so declare in public interface 
*******************************************************************************/
LpsZeroErrorTypes_t LpsWeighGetZeroAdjStatus(void)
{    
    return LpsWrk.ZeroAdjTbl.ZeroAdjStatus;
}

/******************************************************************************
FUNCTION NAME:  LpsWeighSetAutoZeroUpdateStatus(void)

DESCRIPTION:  Set the auto zero update status for access by calling function.


PARAMETER DESCRIPTION:  uses LpsZeroNeededStatus_t enum.

RETURN VALUE:   None.

*******************************************************************************/
void LpsWeighSetAutoZeroUpdateStatus(LpsZeroNeededStatus_t Status)
{    
    LpsWrk.ZeroAdjTbl.AutoZeroStatus = Status;
}
/******************************************************************************
FUNCTION NAME:  LpsWeighGetAutoZeroUpdateStatus(void)

DESCRIPTION:  Return the auto zero update status for access by calling function.


PARAMETER DESCRIPTION:  uses LpsZeroNeededStatus_t enum.

RETURN VALUE:   None.
>>>>>>NOTE this needs to be accessible to calling function or App so declare in public interface 
*******************************************************************************/
LpsZeroNeededStatus_t LpsWeighGetAutoZeroUpdateStatus(void)
{    
    return LpsWrk.ZeroAdjTbl.AutoZeroStatus;
}

/* Set the Zero Accepted Status */
void LpsWeighSetZeroAcceptedStatus(boolean status)
{
	LpsWrk.ZeroAdjTbl.ZeroAccepted = status;
}

/* Get the Zero Accepted Status */
boolean LpsWeighGetZeroAcceptedStatus(void)
{
    return LpsWrk.ZeroAdjTbl.ZeroAccepted;
}

/* Set TooHeavyToZero Status */
void LpsWeighSetTooHeavyToZero(boolean status)
{
	LpsWrk.ZeroAdjTbl.TooHeavyToZero = status;
}

/* Get TooHeavyToZero Status */
boolean LpsWeighGetTooHeavyToZero(void)
{
    return LpsWrk.ZeroAdjTbl.TooHeavyToZero;
}

boolean LpsWeighHydraulicOilTempValid(float_32 temp, unsigned_16 status )
{
    if(temp > HYDRAULIC_OIL_TEMP_MIN_VALID_DATA && LPS_HYD_OIL_TEMP_STATUS_OK == status)

    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

float_32 LpsWeighGetZeroWeight(void)
{
	LpsMachSpecificCfg_t* pMachSpecConf = &LpsWrk.InitTbl.MachSpecificCfg;
	LpsCalib_t* pCalTbl = &pMachSpecConf->CalibTbl;
	
	return pCalTbl->ZeroWeight;
}	
