/*******************************************************************************
** COPYRIGHT (C) 2016 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: DigDetect
DESCRIPTION: Dig Detection logic


*******************************************************************************/

/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <string.h>

#ifndef __LPS_COMMON_TYPE_DEF_H__
#include <LpsCommonTypeDef.h>
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h>
#endif

#ifndef __LPS_PUBLIC_H__
#include <LpsPublic.h>
#endif

#include "LpsPrivate.h"

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
# define LPS_WEIGH_MIN_WEIGHT_STABILITY_INDEX (float)1.0
/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/******************************************************************************
FUNCTION NAME:
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
LpsInitErrorTypes_t PayloadDigDetectInit(LpsWeighDumpWtBuffer_t DumpWtBuffer)
{
	LpsWeighWtRateChangePtrs_t 	*pWtRateChangePtrs 	=	&LpsWrk.WtRateChangePtrs;
		
	LpsWrk.InitErr = LPS_INIT_UNKNOWN_ERROR;
	
	if (NULL != DumpWtBuffer.PtrDumpWtBuffer)
	{
		memset((unsigned_8*)DumpWtBuffer.PtrDumpWtBuffer, 0x00, (DumpWtBuffer.bufferSize * sizeof(float_32)));
	}
	else
	{
		LpsWrk.InitErr = LPS_INIT_FAIL;
		return (LpsWrk.InitErr);
	}
	
	pWtRateChangePtrs->MaxSamples = (unsigned_8)(DumpWtBuffer.bufferSize);
	pWtRateChangePtrs->FixedStartPtr = DumpWtBuffer.PtrDumpWtBuffer;
	pWtRateChangePtrs->FixedEndPtr = pWtRateChangePtrs->FixedStartPtr + (pWtRateChangePtrs->MaxSamples - 1);
	pWtRateChangePtrs->StartPtr = DumpWtBuffer.PtrDumpWtBuffer;
	pWtRateChangePtrs->EndPtr = DumpWtBuffer.PtrDumpWtBuffer;
	
	LpsWrk.InitErr = LPS_INIT_SUCCESS;	
	return LpsWrk.InitErr;
}

/* This is not my favorite code structure of state machine, this can be rewritten much better.
Porting pcs code over as is since not having given enough time to restructure code. */
LpsUpdtErrorTypes_t PayloadDigDetectUpdate(void)
{
	LpsCalib_t				*pCal				=	&LpsWrk.InitTbl.MachSpecificCfg.CalibTbl;
	LpsWeighDumpWtChange_t 	*pDumpWtChangeData 	= 	&LpsWrk.DumpWtChangeData;
	LpsWeighDigDetect_t 	*pDigDetectData 	= 	&LpsWrk.DigDetectData;
	LpsWeighDigCfg_t 		*pDigConfig			= 	&LpsWrk.InitTbl.MachSpecificCfg.DigConfig;
	LpsMachSpecificCfg_t	*pMachConfig		= 	&LpsWrk.InitTbl.MachSpecificCfg;
	LpsInitTbl_t			*pInitTbl			=	&LpsWrk.InitTbl;
	LpsUpdtTbl_t			*pUpdateTbl			=	LpsWrk.UpdtTbl;
	
	LpsWrk.UpdtErr = LPS_UPDT_UNKNOWN_ERROR;
	
	if((LPS_WEIGH_SYSTEM_CALIBRATED == pCal->CalStat) && (TRUE == LpsWrk.UpdtTbl->UseFilterDataFlag))
	{
		//Check if the weight is stable
		if (pDumpWtChangeData->WtStabilityIndex >= (float_32)LPS_WEIGH_MIN_WEIGHT_STABILITY_INDEX)
        {
            pDigDetectData->WtStabilized = TRUE;
        }
        else
        {
            pDigDetectData->WtStabilized = FALSE;
        }

		 //check if we are detecting a dig
        if ((pDumpWtChangeData->DumpCumulativeWtChange < ((pDigConfig->DigStartLimit)*(pDigConfig->DigTargetWt))) &&
            (TRUE == LpsWeighIsRequestedGearForward()) &&
            (pUpdateTbl->LiftCylExt.Val < pMachConfig->StartOfWeigh) &&
            (FALSE == pDigDetectData->DigDetected) &&
            (FALSE == pDigDetectData->DigStarted) &&
            (pUpdateTbl->LiftCylVel.Val >= pDigConfig->LiftLowerVelocityLimit) &&
            (FALSE == LpsWeighFullRackDetect()))
        {
            //set flag that we might be in dig
            pDigDetectData->DigStarted = TRUE;
            pDigDetectData->DigState =  LPS_WEIGHT_BKT_TENTATIVE_DIGGING;
            //pcs_data.stat.dig_handshake_flag = TRUE;
        }
		
		// if we have started a dig start counting how long before we think it might have ended
        if (pDigDetectData->DigStarted)
        {
            pDigDetectData->DigDuration++;
            //make sure it hasn't been too long
            if (pDigDetectData->DigDuration > ((pDigConfig->DigDurationMaxLimit) / pInitTbl->ExecRate))
            {
                //too long, this is not a dig
                pDigDetectData->DigStarted = FALSE;
                pDigDetectData->DigDuration = 0;
                pDigDetectData->DigState =  LPS_WEIGHT_BKT_NOT_DIGGING;
            }
        }
        else if (pDigDetectData->DigState ==  LPS_WEIGHT_BKT_DIG_STATE_UNKNOWN)
        {
            pDigDetectData->DigState = LPS_WEIGHT_BKT_NOT_DIGGING;
        }
		
		//check if we think a dig might have ended
        if ((pDigDetectData->DigStarted) &&
            (pDumpWtChangeData->DumpCumulativeWtChange > ((pDigConfig->DigEndLimit)* (pDigConfig->DigTargetWt))))
        {
            //find out if it has been long enough for this to be a dig
            if (pDigDetectData->DigDuration < ((pDigConfig->DigDurationMinLimit) / pInitTbl->ExecRate))
            {
                //duration was not long enough, cancel the dig
                pDigDetectData->DigStarted = FALSE;
                pDigDetectData->DigState = LPS_WEIGHT_BKT_NOT_DIGGING;
                pDigDetectData->DigDuration = 0;
            }
            else
            {
                //has been the right amount of time, mark as a dig
                 pDigDetectData->DigState = LPS_WEIGHT_BKT_DIGGING;
                 pDigDetectData->DigDetected = TRUE;
                 pDigDetectData->DigStarted = FALSE;
                 pDigDetectData->DigDuration = 0;
            }
        }
		
		/*check if we have detected the end of a dig and wait for the weight to settle out or full dump */
        if ((pDigDetectData->DigDetected) &&
            (pDigDetectData->WtStabilized || LpsWeighFullDumpDetect()))
        {
            pDigDetectData->DigDetected = FALSE;
            pDigDetectData->DigState = LPS_WEIGHT_BKT_NOT_DIGGING;
        }
	}
	else
	{
		pDigDetectData->DigState = LPS_WEIGHT_BKT_DIG_STATE_UNKNOWN;
        pDigDetectData->DigDuration = 0;
        pDigDetectData->WtStabilized = FALSE;
        pDigDetectData->DigStarted = FALSE;
        pDigDetectData->DigDetected = FALSE;
	}
	
	LpsWrk.UpdtErr = LPS_UPDT_SUCCESS;
	return LpsWrk.UpdtErr;
}

LpsWeighBktDigStat_t LpsWeighGetDigState(void)
{
	return LpsWrk.DigDetectData.DigState;
}
