/*******************************************************************************
** COPYRIGHT (C) 2016 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsPrivate.h
DESCRIPTION:
*******************************************************************************/
#ifndef __LPS_PRIVATE_H__
#define __LPS_PRIVATE_H__
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <LpsPublic.h>
#ifndef __CPM_FILTER_H__
#include <cpm_filter.h>
#endif
/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
#define PI_CONST  (float_32) 3.1415926535897932384626433832795
#define HYDRAULIC_OIL_TEMP_MIN_VALID_DATA (-32736.0) /* PID data */
/* Auto Zero Timer */
#define LPS_INIT_ZERO_INTERVAL          (300)       /*  seconds */
#define LPS_AUTO_ZERO_INTERVAL          (7200)     /*  seconds */
#define LPS_ZERO_SNOOZE_INTERVAL        (600)      /*  seconds */
#define LPS_LOW_TEMP_ZER0_DEFAULT       (-100.0)    /* -100.0 degrees C */
#define LPS_EMPTY_CAL_OIL_TEMP_DELTA    (5.0)       /* 5.0 degrees C */
#define LPS_OIL_TEMP_DELTA              (10.0)      /* 10.0 degrees C */

#define LPS_SQUARE(a) ((a) * (a))
#define LPS_CUBE(a) ((a) * (a) * (a))
#define TOO_SLOW_NUMBER_OF_SAMPLES 32766
#define MIN_LIFT_VELOCITY 1.0

#define LPS_TILT_CYL_EXT_DUMP_DELTA 5.0
#define LPS_TILT_EXT_FULL_DUMP_LIMIT 2.0
#define PCS_TILT_ANG_ABC_PCT_FULL_DUMP_LIMIT 2.0

#define LPS_OVERLOAD_DISABLE_THRESHOLD 110.0
#define LPS_OVERLOAD_WT_THRESHOLD 116.5

#define LPS_OVERLOAD_DISABLE_THRESHOLD 110.0
#define LPS_OVERLOAD_WT_THRESHOLD 116.5

/* Stall Detect Lift Height Thresholds */
#define LPS_LIFT_HT_CLOSE_TO_FULL_RAISE (98.0)
#define LPS_LIFT_HT_NOT_FULL_RAISE (97.0)
#define LPS_LIFT_HT_CLOSE_TO_FULL_LOWER (2.0)
#define LPS_LIFT_HT_NOT_FULL_LOWER (3.0)

typedef struct
{
	float_32 LiftHeFlowConst;
	float_32 LiftReToHeFlowRatio;
}LpsCylFlowConst_t;

typedef enum
{
    LPS_LIFT_STALL_STALLED = 0,
	LPS_LIFT_STALL_NOT_STALLED
}LpsLiftStallStat_t;

typedef enum {
  LPS_WEIGH_LIVE_WEIGH_STATUS_VALID = 0,
  LPS_WEIGH_LIVE_WEIGH_STATUS_INVALID
}LpsLiveWeighStat_t;

typedef struct
{
	boolean live_wt_stall;
	boolean reset_stall_timer;
	boolean payload_available;
	unsigned_16 stall_debounce_counter;
	boolean lift_pos_too_high;
	boolean lift_pos_too_low;
	LpsLiftStallStat_t LiftStallStat;
}LpsStallDetect_t;

typedef enum {
    LPS_LINKAGE_MOVEMENT_STOPPED = 0,
    LPS_LINKAGE_MOVEMENT_POSITIVE,
    LPS_LINKAGE_MOVEMENT_NEGATIVE
} LpsLinkageMovementStat_t;

typedef struct {
    LpsLinkageMovementStat_t lift;
    LpsLinkageMovementStat_t tilt;
} LpsLinkageMovement_t;

typedef struct
{
	float_32 lastInput;
	float_32 meanEst;
	float_32 meanEstComp;
	float_32 varianceEst;
	float_32 stdevEst;
	float_32 confidenceEst;
	float_32 confidenceTimer;
}LpsLlwFactors_t;

typedef struct
{
	float_32                   Wt;
	LpsWeighRangeWarning_t     Warning;
	LpsWeighRangeLatched_t     Status;
	LpsWeighRangeIndicator_t   Indicator;
}LpsWeighWrwOpTbl_t;   		 

typedef struct
{	
	boolean  	BeenBelowRange;
	boolean     Weighing;
	unsigned_32 Count;
	float_32 	WtSum;
	float_32 	WtWtSum;
	float_32 	WtWtWtSum;
	float_32 	VelSum;
	float_32 	VelVelSum;
	float_32 	WtAvg;
	float_32 	WtSd;
	float_32 	WtAbsDiff;
	float_32 	WtHigh;
	float_32 	WtLow;
	float_32 	VelAvg;
	float_32 	VelSd;
	float_32 	SecondMoment;
	float_32 	ThirdMoment;
	float_32 	Skew;
	boolean  	WrwFirstExec;
	boolean     ReweighPosted;
	boolean     FullyRackedStat;
	boolean     NotFullyDumpedStat;	
}LpsWeighWrwWkTbl_t;

typedef struct
{
	float_32    MinSdPcnt;
	signed_16   MaxWtSd;
	signed_16   MaxWtAbsDiff;
	signed_16   MaxWtSkew;
	signed_16   MaxVelSd;
}LpsWeighWrwErrorLimits_t;

typedef struct
{
	LpsWeighWrwOpTbl_t   	      OpTbl;
	LpsWeighWrwWkTbl_t  		  WkTbl;
	LpsWeighWrwErrorLimits_t      ErrLmt;
	LpsWeighWrwReweighStatus_t    ReweighWarn;
}LpsWeighWrwTbl_t;

typedef struct
{
	float_32 Tau;
	float_32 OlRaw;
	float_32 OlFilt;
	float_32 Curr;
}LpsStaticWtFactor_t;

typedef struct
{
    unsigned_32 	LastZeroTimerReset;     /* Time of last auto zero timer reset */
    boolean      	PwrOn;
    boolean      	LiftStatus;
    boolean      	Snoozed;
    unsigned_32 	LastSnoozedTime;
    LpsZeroNeededStatus_t 		SnoozedStatus;
}LpsZeroAdjAutoSnooze_t;

typedef struct            
{
	boolean			ZeroAccepted;
	boolean			TooHeavyToZero;
	float_32 		ZeroTemp;
	LpsZeroErrorTypes_t	ZeroAdjStatus;
	LpsZeroNeededStatus_t AutoZeroStatus;
	LpsZeroAdjAutoSnooze_t	ZeroAdjAutoSnooze;
}LpsZeroAdjTbl_t;

typedef struct
{
    BSFILT   BSOne;
    BSFILT   BSTwo;
    BSFILT   BSThree;
    LPFILT   WtFilter;
	float_32 LastInput;
	float_32 MeanEst;
	float_32 MeanEstComp;
	float_32 VarianceEst;
	float_32 StdevEst;
	float_32 Confidence;
	float_32 ConfidenceEst;
	float_32 ConfidenceTimer;
	float_32 Wt;
	LpsLlwStat_t Stat;	
}LpsWeighLlw_t;

/******* Dig State ************/
typedef struct {
    boolean Initialized;
    unsigned_16 StartupDelay;
    unsigned_8 NumSamples;
    float_32 DumpCumulativeWtChange;
    float_32 WtStabilityGain;
    float_32 WtStabilityThreshold;
    float_32 WtStabilityIndex;
} LpsWeighDumpWtChange_t;

typedef struct {
    boolean DigStarted;
    boolean DigDetected;
    LpsWeighBktDigStat_t DigState;
    boolean WtStabilized;
    unsigned_32 DigDuration;
} LpsWeighDigDetect_t;

typedef struct
{
    float_32 *StartPtr;
    float_32 *EndPtr;
    float_32 *FixedEndPtr;
    float_32 *FixedStartPtr;
    float_32 *IndexPtr;
    unsigned_8 MaxSamples;
} LpsWeighWtRateChangePtrs_t;

/******* Live Weight ************/
typedef struct
{
    LPFILT   			FastFilter;
    LPFILT   			SlowFilter;
	float_32 			Wt;
	LpsLiveWeighStat_t 	Stat;
	boolean 			PrevFastFilt;
}LpsWeighLiveWeigh_t;

/**********Overload Warnings**********/
typedef struct
{
	float_32	BucketLoadFactor;
	unsigned_8 	PrevDigState;
	boolean 	DigReverseFlag;
	boolean		InWaitForLatch;
	boolean		InOverloadRange;
	boolean		OverloadActive;
}LpsWeighOverloadWarnings_t;

typedef struct
{
	float_32					LiftCylPres;
	float_32            		InstWtLlwFilt;
	float_32 	     			InstWtDer;
	LpsInstWtRaw_t      		InstWtRaw;
	float_32            		InstWtFilt;
	LpsInitErrorTypes_t 		InitErr;
	LpsUpdtErrorTypes_t 		UpdtErr;
	LpsInitTbl_t        		InitTbl;
	LpsUpdtTbl_t        		*UpdtTbl;
	LpsCylFlowConst_t   		CylFlowConst;
    LpsLinkageMovement_t        LinkageMovement;
	LpsStaticWtFactor_t 		StaticWtFactor;
	LpsLlwFactors_t     		LlwFactors;
	LpsWeighWrwTbl_t    		WrwTbl;	
	LpsStallDetect_t    		LpsStallDetect;
	LpsWeighBktDumpStat_t		DumpStateStatus;
	LpsWeighBestBktWt_t 		BestBktWt;
	LpsWeighLlw_t       		LowLiftWt;	
	LpsZeroAdjTbl_t				ZeroAdjTbl;
	LpsWeighDumpWtChange_t 		DumpWtChangeData;
	LpsWeighDigDetect_t 		DigDetectData;
	LpsWeighWtRateChangePtrs_t 	WtRateChangePtrs;
	LpsWeighLiveWeigh_t 		LiveWeighTbl;
	LpsWeighOverloadWarnings_t	OverloadWarnTbl;
	bool						WeighDecFlag;
}LpsWrkTbl_t;


/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
extern void LpsResetWrkTbl(void);
extern void LpsCopyAppInitTbl(LpsInitTbl_t *newInitTbl);
extern void LpsCalcCylFlowConst(void);
extern void LpsUpdateLinkageMovement(void);
extern void LpsCalcDiffPres(void);
extern void LpsCalcInstantWt(void);
extern boolean LpsIsBucketFullRack(void);
extern boolean lpsBucketNotFullDump(void);
extern unsigned_8 lpsCalibStatus(void);

extern void LowPassFiltInit(void);

extern LpsInitErrorTypes_t LpsLlwInit(void);
LpsUpdtErrorTypes_t LpsLowLiftWeighCalcUpdate(void);
extern void LpsWeighResetLlwWt(void);

void LpsAutoWeighRangeUnlatchWt(void);
LpsInitErrorTypes_t LpsWeighRangeWeighInit(void);
LpsUpdtErrorTypes_t LpsWeighRangeWeighUpdate(void);
void LpsWeighResetWeighRangeWeight(void);
void LpsWeighRangeCalcWt(void);
void LpsClearWeighRangeData(void);
void LpsClearReweighWarningStatus(void);

extern void LpsWeighZeroNotify(boolean);
extern void LpsWeighSetZeroAdjStatus(LpsZeroErrorTypes_t);
extern void LpsWeighSetAutoZeroUpdateStatus(LpsZeroNeededStatus_t);
extern LpsUpdtErrorTypes_t LpsWeighAutoZeroUpdate(void);
extern void LpsWeighZeroAdjust(void);
void LpsWeighZeroInit(void);

extern float_32 LpsCalAdjustWeight(float_32 ZeroedWeight);
extern boolean LpsWeighHydraulicOilTempValid(float_32, unsigned_16 );
extern void LpsWeighResetLowLiftWeight(void);
void LpsSetDefaultErrLimits(void);

/******* Finding out the Gear Status **********/
boolean LpsWeighIsRequestedGearForward(void);
boolean LpsWeighIsRequestedGearReverse(void);

extern void LpsTiltCompensation(float_32 InstRawWtSlope);
extern void LpsTiltCylExtPercentStatus(void);

/******* Best bucket weight ************/
LpsUpdtErrorTypes_t LpsWeighBestBktWtUpdate(void);

/******* Dig State ************/
LpsInitErrorTypes_t PayloadDigDetectInit(LpsWeighDumpWtBuffer_t DumpWtBuffer);
LpsUpdtErrorTypes_t PayloadDigDetectUpdate(void);
LpsUpdtErrorTypes_t LpsWeighDumpWtChangeUpdate(void);

/******* Dump State ************/
void SetTiltExtensionThreshold(void);
boolean LpsWeighFullRackDetect(void);
boolean LpsWeighFullDumpDetect(void);
boolean LpsWeighPartialDumpDetect(void);
LpsUpdtErrorTypes_t LpsWeighDumpDetectUpdate(void);
void SetDumpStateStatus(LpsWeighBktDumpStat_t dumpState);
extern LpsInitErrorTypes_t PayloadDumpStateInit(void);

/******* Live Weight ************/
void LpsLiveWeighInit(void);
void LpsLiveWeighCalc(void);
void LpsWeighResetLiveWt(void);

/**********Overload Warnings***********/
LpsInitErrorTypes_t LpsOverloadWeightInit(void);

/**********Stall detect***********/
void  LpsLiftStallDetectUpdate(void);

/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
extern LpsWrkTbl_t LpsWrk;
extern LpsWeighBktDumpStat_t DumpStateStatus;


#endif /* #ifndef __LPS_PRIVATE_H__ */
