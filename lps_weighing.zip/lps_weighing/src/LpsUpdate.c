/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsUpdate.c
DESCRIPTION:This file provides the update routines for the application software
            for LPS library.
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include<stdio.h>

#ifndef __LPS_COMMON_TYPE_DEF_H__
#include <LpsCommonTypeDef.h> /* Contains type definitions of standard datatypes */
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h> /* Contains structures which are common between all LPS
                                  * system libraries
								  */
#endif

#ifndef __LPS_PUBLIC_H__
#include <LpsPublic.h> /*******************************************************/ 
                       /* Containes prototypes of interfaces and functions    */
                       /* which are exported to the application using the     */
                       /* library                                             */
                       /*******************************************************/
#endif

#include "LpsPrivate.h" /*******************************************************/ 
                        /* Containes prototypes of interfaces and functions    */
                        /* which are used within the payload computation       */
                        /* library                                             */
                        /*******************************************************/

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/******************************************************************************
FUNCTION NAME:LpsUpdt
DESCRIPTION: This function is an API interface for the application software. Application software
             invokes this API at predetermined intervals. LPS library performs the algorithms/functionalities
             to compute instantaneous weight when this API is invoked.The algorithm goes through various
             stages like hydraulic flow calculation, Difference pressure computation, Pressure loss calculation,
             hydraulic Oil temperature compensation and calibration adjustments to output instantaneous weight.
             Computations from one stage to other is interfaced through work table. 
PARAMETER DESCRIPTION: LpsAppUpdtTbl-> Application software provides inputs to the LPS 
                       library through this interface. It holds values of pressure sensors,hydraulic oil
                       temperature, Cylinder extention percentage, operator input, etc.
RETURN VALUE: LpsUpdtErrorTypes_t-> This enum interface reports various error types reported by
              LpsUpdt function to the application software.
*******************************************************************************/
LpsUpdtErrorTypes_t LpsUpdt(LpsUpdtTbl_t *LpsAppUpdtTbl)
{
	LpsWrk.UpdtErr = LPS_UPDT_UNKNOWN_ERROR;

	if(NULL == LpsAppUpdtTbl)
	{
		LpsWrk.UpdtErr = LPS_UPDT_INPUT_ERROR;
		return(LpsWrk.UpdtErr);
	}
	
	if(LPS_INIT_SUCCESS != LpsWrk.InitErr)
	{
		LpsWrk.UpdtErr = LPS_UPDT_NOT_INIT;
		return(LpsWrk.UpdtErr);				
	}

	LpsWrk.UpdtTbl = LpsAppUpdtTbl;

    LpsUpdateLinkageMovement();
	
	if(STATUS_GOOD == LpsChkInputStat())
	{
		/* Determing Lift Cylinder head end to rod end difference pressure after compensating
		 * for hydraulic oil (temperature compensated) pressure loss */
		LpsCalcDiffPres();
        			
		LpsCalcInstantWt();

		if(TRUE == LpsAppUpdtTbl->CaptCylExtnRef)
		{
		   SetTiltExtensionThreshold();
		}

		if(FALSE == LpsAppUpdtTbl->StandbyActiveState)
		{
			LpsClearReweighWarningStatus();
		}

		//Call weight change update
		LpsWeighDumpWtChangeUpdate();
		
		//Call dump detect update
		LpsWeighDumpDetectUpdate();
		
		//Call dig detect update
		PayloadDigDetectUpdate();
		
		LpsWeighRangeWeighUpdate();
		LpsLowLiftWeighCalcUpdate();
		
		//Live Weight Calculation - This function should follow LLW as zero adjust for 
		// LLW is done in Live Weight Calc
		LpsLiveWeighCalc();
		
		/* Do Zero Adjust if Zero Button has been pressed */
        	if( TRUE == LpsAppUpdtTbl->ZeroButtonPress )
	        {
         	   LpsWeighZeroAdjust();
	            /* reset the button press indicator to avoid multiple actions */
        	   LpsAppUpdtTbl->ZeroButtonPress = FALSE;
	        }

		/* check for conditions to alert the operator that a zero lift is needed */
	        LpsWeighAutoZeroUpdate();
		
		//Call best bucket weight update function.
		LpsWeighBestBktWtUpdate();

		//Call stall detect update function.

		LpsLiftStallDetectUpdate();

		LpsWrk.UpdtErr = LPS_UPDT_SUCCESS;	
	}
	else
	{
		/* To Be Decided - Faulty input handling need to be discussed
		   within the team and handled in software in future versions
		 */
		LpsWrk.UpdtErr = LPS_UPDT_FAIL;
		LpsWrk.InstWtRaw.Val  = 0.0;
       	LpsWrk.InstWtRaw.Stat = LPS_INST_RAW_WT_STATUS_BAD;
		LpsWrk.LiftCylPres = 0;
	}
	
		
	return(LpsWrk.UpdtErr);
}

/******************************************************************************
FUNCTION NAME:LpsGetRawInstWt
DESCRIPTION: This API function gets/returns the raw instantaneous weight computed by the 
             LPS library.
PARAMETER DESCRIPTION: NULL
RETURN VALUE: InstWtRaw.Val->Instantaneous Weight in Tonnes,InstWtRaw.Stat-> Status
*******************************************************************************/
LpsInstWtRaw_t LpsGetRawInstWt(void)
{
	LpsInstWtRaw_t instWtRaw = {0}; 	
	
	instWtRaw = LpsWrk.InstWtRaw; 
	
   return(instWtRaw);
}

/******************************************************************************
FUNCTION NAME:LpsGetLiftCylPres
DESCRIPTION: This API function gets/returns the hydraulic oil temperature compensated
             Lift Cylinder pressure (Difference presseure between Head end and Rod end
			 of lift cylinder piston)computed by the LPS library.
PARAMETER DESCRIPTION: NULL
RETURN VALUE: liftCylPres->Lift Cylinder pressure (Difference pressure) in Kpa
*******************************************************************************/
float_32 LpsGetLiftCylPres(void)
{
    float_32	liftCylPres;
  
    liftCylPres = LpsWrk.LiftCylPres;
  
  return(liftCylPres);
}

