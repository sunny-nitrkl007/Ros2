/*******************************************************************************
** COPYRIGHT (C) 2016 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsUtility.c
DESCRIPTION:This files provide utility functions to be used by LPS library for
            internal processing.
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef __LPS_COMMON_TYPE_DEF_H__
 /* Contains type definitions of standard datatypes */
#include <LpsCommonTypeDef.h>
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
 /* Contains structures which are common between all LPS system libraries */
#include <LpsCommonStructures.h>
#endif

#ifndef __LPS_PUBLIC_H__
/*******************************************************/ 
/* Containes prototypes of interfaces and functions    */
/* which are exported to the application using the     */
/* library                                             */
/*******************************************************/
#include <LpsPublic.h> 
#endif

/*******************************************************/ 
/* Contains prototypes of interfaces and functions     */
/* which are used within the payload computation       */
/* library                                             */
/*******************************************************/
#include "LpsPrivate.h"

#include <string.h>

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
#define REQUESTED_GEAR_FWD		0x4000
#define REQUESTED_GEAR_REV		0x07FF
#define REQUESTED_GEAR_MATCH 	0x17FF
/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/******************************************************************************
FUNCTION NAME:LpsResetWrkTbl
DESCRIPTION:Utility function to reset work table
PARAMETER DESCRIPTION:NULL
RETURN VALUE:LpsWrk
*******************************************************************************/
void LpsResetWrkTbl(void)
{
    memset((void *)&LpsWrk,0,sizeof(LpsWrkTbl_t));
	
    LpsWrk.StaticWtFactor.Tau    = 1.93;        
    LpsWrk.StaticWtFactor.OlRaw  = 0.3;      
    LpsWrk.StaticWtFactor.OlFilt = 0.3;     
    LpsWrk.StaticWtFactor.Curr   = 0.3; 
	
    return;
}

/******************************************************************************
FUNCTION NAME:LpsCopyAppInitTbl
DESCRIPTION:Utility function to copy new configuration to work table
PARAMETER DESCRIPTION:NewInitTbl -> LPS configuration table to be copied to work table for
                      library processing
RETURN VALUE: LpsWrk.InitTbl-> application configuration copy for LPS library computation
*******************************************************************************/
void LpsCopyAppInitTbl(LpsInitTbl_t *newInitTbl)
{
    memcpy(&LpsWrk.InitTbl,newInitTbl,sizeof(LpsInitTbl_t));
	
    return;	
}

/******************************************************************************
FUNCTION NAME:LpsChkInputStat
DESCRIPTION:This utility function checks all the inputs to LPS library for faulty condition.
PARAMETER DESCRIPTION:LpsWrk.UpdtTbl -> LPS library inputs passed by application software
RETURN VALUE:STATUS_GOOD->LPS library Inputs are good and ok to for further processing,
             STATUS_BAD->LPS library Inputs are faulty.
*******************************************************************************/
boolean LpsChkInputStat(void)
{
    LpsUpdtTbl_t *updtTbl;
		
    updtTbl = LpsWrk.UpdtTbl;
	
    if((LPS_PRES_STATUS_OK         == updtTbl->LiftCylHePres.Stat) &&
       (LPS_PRES_STATUS_OK         == updtTbl->LiftCylRePres.Stat) &&
       (LPS_HYD_OIL_TEMP_STATUS_OK == updtTbl->HydOilTemp.Stat) &&
       (LPS_CYL_VEL_STATUS_OK      == updtTbl->LiftCylVel.Stat) &&
       (LPS_CYL_EXT_STAT_OK        == updtTbl->LiftCylExt.Stat) &&
       (LPS_CYL_EXT_STAT_OK        == updtTbl->TiltCylExt.Stat) &&
	   (LPS_BKT_ANGLE_STATUS_OK    == updtTbl->BktAngle.Stat)
      )
    {
        return(STATUS_GOOD);
    }
    else
    {
        return(STATUS_BAD);
    }
}

/******************************************************************************
FUNCTION NAME:LpsCalAdjustWeight
DESCRIPTION: Clears all the weigh range data parameters
PARAMETER DESCRIPTION: None
RETURN VALUE: float_32 adjustedWeight
*******************************************************************************/
float_32 LpsCalAdjustWeight(float_32 ZeroedWeight)
{
    LpsCalib_t* pCalTbl;
    LpsMachSpecificCfg_t* pMachSpecConf;
    float_32 adjustedWeight;
	float_32 scaleFactor;

    pMachSpecConf = &LpsWrk.InitTbl.MachSpecificCfg;
    pCalTbl = &pMachSpecConf->CalibTbl;

    scaleFactor = (float_32)1.0 - pCalTbl->CalAdjust;

    if(scaleFactor > (float_32)0.0)
    {
        adjustedWeight =  ZeroedWeight * scaleFactor;
    }
    else
    {
        adjustedWeight = ZeroedWeight;
    }

    return adjustedWeight;
}

/******************************************************************************
FUNCTION NAME:LpsWeighIsRequestedGearForward
DESCRIPTION: Determines if the machine is in Forward Gear or not
PARAMETER DESCRIPTION: None
RETURN VALUE: boolean isPossiblyForward
*******************************************************************************/
boolean LpsWeighIsRequestedGearForward(void)
{	
    boolean isPossiblyForward;	
	LpsUpdtTbl_t *pUpdateTbl = LpsWrk.UpdtTbl;
	
    if (LPS_REQUESTED_GEAR_STAT_OK == pUpdateTbl->RequestedGear.Stat)
    {
        if (0 != (pUpdateTbl->RequestedGear.Val & REQUESTED_GEAR_FWD))
        {
            isPossiblyForward = TRUE;
        }
        else
        {
            isPossiblyForward = FALSE;
        }
    }
    else
    {
        isPossiblyForward = TRUE;
    }
    return isPossiblyForward;
}


/******************************************************************************
FUNCTION NAME:LpsWeighIsRequestedGearReverse
DESCRIPTION: Determines if the machine is in Reverse Gear or not
PARAMETER DESCRIPTION: None
RETURN VALUE: boolean isReverse
*******************************************************************************/
boolean LpsWeighIsRequestedGearReverse(void)
{
    boolean isReverse;	
	LpsUpdtTbl_t *pUpdateTbl = LpsWrk.UpdtTbl;
		
    if (LPS_REQUESTED_GEAR_STAT_OK == pUpdateTbl->RequestedGear.Stat)
    {
        if (REQUESTED_GEAR_MATCH == (pUpdateTbl->RequestedGear.Val | REQUESTED_GEAR_REV))
        {
            isReverse = TRUE;
        }
        else
        {
            isReverse = FALSE;
        }
    }
    else
    {
        isReverse = TRUE;
    }
    return isReverse;
}

/******************************************************************************
FUNCTION NAME:GetBucketStateWaitForLatch
DESCRIPTION: To get the value of InWaitForLatch variable
PARAMETER DESCRIPTION: None
RETURN VALUE: boolean InWaitForLatch. Returns TRUE if in Wait for Latch, else returns FALSE
*******************************************************************************/
boolean GetBucketStateWaitForLatch(void)
{
	return LpsWrk.OverloadWarnTbl.InWaitForLatch;
}

/******************************************************************************
FUNCTION NAME:SetBucketStateWaitForLatch
DESCRIPTION: To set the InWaitForLatch variable to TRUE if it is in Wait For Latch and vice versa
PARAMETER DESCRIPTION: None
RETURN VALUE: None
*******************************************************************************/
void SetBucketStateWaitForLatch(boolean val)
{
	LpsWrk.OverloadWarnTbl.InWaitForLatch = val;
}
