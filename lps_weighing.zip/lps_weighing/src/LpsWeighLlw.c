/*******************************************************************************
** COPYRIGHT (C) 2016 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME:LpsWeight
DESCRIPTION: Calculates the low lift weight
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef __LPS_COMMON_TYPE_DEF_H__
#include <LpsCommonTypeDef.h> /* Contains type definitions of standard datatypes */
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h> /* Contains structures which are common between all LPS
                                  * system libraries
                  */
#endif

#ifndef  __LPS_COMMON_LOOKUP_TBL_UTILITY_H__
#include <LpsCommonLookUpTblUtility.h>
#endif

#ifndef __LPS_PUBLIC_H__
#include <LpsPublic.h> /*******************************************************/ 
                       /* Containes prototypes of interfaces and functions    */
                       /* which are exported to the application using the     */
                       /* library                                             */
                       /*******************************************************/
#endif

#include "LpsPrivate.h"

#ifndef __CPM_FILTER_H__
#include <cpm_filter.h> /* Contains the functions from CPM Filter library of MAAL */
#endif

#include <string.h>
#include <math.h>
/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/

/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
static float_32 LpsCalculateConfidence(float_32 tolerance, float_32 stdev);
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/******************************************************************************
FUNCTION NAME:LpsLowLiftWeighCalc
DESCRIPTION: Low lift weigh calculation is done here. The instantaneous weight raw value is passed through 3 band stop filters to get the filtered instantaneous weight. Now mean and standard variation are calculated and from these values weight confidence is calculated. Upon the confidence value the auto weigh range data is determined, which is the low lift weigh data.
PARAMETER DESCRIPTION:None
RETURN VALUE: None
*******************************************************************************/
LpsUpdtErrorTypes_t LpsLowLiftWeighCalcUpdate(void)
{
    float_32 newSample;
    float_32 lastMeanEst;
		
	LpsWeighDigCfg_t *pDigCfg = &LpsWrk.InitTbl.MachSpecificCfg.DigConfig;
	LpsUpdtTbl_t *pUpdtTbl    =  LpsWrk.UpdtTbl;
	
	LpsWrk.UpdtErr = LPS_UPDT_UNKNOWN_ERROR;
	
    /* Bandstop filter the pressure to remove resonant frequencies caused by machine and tire mass resonance */	
    cpm_filter_band_stop_filter(&LpsWrk.LowLiftWt.BSOne, LpsWrk.InstWtRaw.Val);
    cpm_filter_band_stop_filter(&LpsWrk.LowLiftWt.BSTwo, LpsWrk.LowLiftWt.BSOne.output[0]);
    cpm_filter_band_stop_filter(&LpsWrk.LowLiftWt.BSThree, LpsWrk.LowLiftWt.BSTwo.output[0]);

    /* Calculate the derivative */
    cpm_filter_low_pass_filter(&LpsWrk.LowLiftWt.WtFilter, LpsWrk.LowLiftWt.BSThree.output[0]);
    LpsWrk.InstWtDer = LpsWrk.LowLiftWt.WtFilter.yprimestate;
	
    /* Extract the filtered value */
    LpsWrk.InstWtLlwFilt = LpsWrk.LowLiftWt.BSThree.output[0];
	LpsWrk.InstWtFilt = LpsWrk.InstWtLlwFilt;
	
    /* Weight Confidence Calculation */
    {
        /*  The prefilter is kind of a hack to try and protect against signal aliasing that was seen near low idle.
            The calculation of the variance amplifies high frequency noise and if the signal is aliased such that we
            unfairly get something that looks like high frequency noise (pump piston pass frequency) it makes the
            variance calculation worse.  The pre-filter chosen just puts a zero at the nyquist frequency with minumum filter delay.
            This is the same as averaging the most recent two samples.
        */
        newSample = (LpsWrk.InstWtLlwFilt + LpsWrk.LowLiftWt.LastInput) / (float_32)2.0;
        LpsWrk.LowLiftWt.LastInput = LpsWrk.InstWtLlwFilt;
        lastMeanEst = LpsWrk.LowLiftWt.MeanEst;
        LpsWrk.LowLiftWt.MeanEst = LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.FilterFactorMean * LpsWrk.LowLiftWt.MeanEst + ((float_32)1.0 - LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.FilterFactorMean) * newSample;
        LpsWrk.LowLiftWt.VarianceEst = LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.FilterFactorVariance * LpsWrk.LowLiftWt.VarianceEst + ((float_32)1.0 - LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.FilterFactorVariance) * ((float_32)1.0 + LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.FilterFactorMean) * (newSample - lastMeanEst) * (newSample - lastMeanEst) / (float_32)2.0;
        LpsWrk.LowLiftWt.StdevEst = (float_32)(sqrt((double_64)LpsWrk.LowLiftWt.VarianceEst));
    }
    
	/* calculation of dig target weight from the machine specific target wegiht */
    if ((pDigCfg->DigTargetWt >= (float_32)0.0) && (TRUE == LpsWrk.UpdtTbl->UseFilterDataFlag))
    {
        LpsWrk.LowLiftWt.ConfidenceEst = LpsCalculateConfidence(LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.ErrorBand, (LpsWrk.LowLiftWt.StdevEst * (float_32)100.0) / (pDigCfg->DigTargetWt));	
    }
    else
    {
        LpsWrk.LowLiftWt.ConfidenceTimer = 0.0;
        LpsWrk.LowLiftWt.ConfidenceEst = 0.0;
    }
		
    if ((LPS_LINKAGE_MOVEMENT_STOPPED == LpsWrk.LinkageMovement.lift) ||
        (LPS_LINKAGE_MOVEMENT_NEGATIVE == LpsWrk.LinkageMovement.tilt))
	{
        LpsWrk.LowLiftWt.ConfidenceTimer = 0.0;
        LpsWrk.LowLiftWt.ConfidenceEst = 0.0;
	}
	else if(LpsWrk.LowLiftWt.ConfidenceTimer < LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.MinimumConfidenceTime)
	{
        LpsWrk.LowLiftWt.ConfidenceTimer += LpsWrk.InitTbl.ExecRate;
        LpsWrk.LowLiftWt.ConfidenceEst = 0.0;	
	}

    /* Capture the low lift weight */
    if ((LpsWrk.LowLiftWt.ConfidenceEst >= (float_32)LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.AutoWeighRangeConfThr) &&
        (LPS_LINKAGE_MOVEMENT_POSITIVE == LpsWrk.LinkageMovement.lift) &&
        (LpsWrk.UpdtTbl->LiftCylExt.Val >= (float_32)LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.AutoWeighMinLiftHt) &&
        (LPS_WEIGHT_BKT_FULLY_RACKED == GetDumpStateStatus()) &&
        (LPS_LIFT_STALL_STALLED != LpsWrk.LpsStallDetect.LiftStallStat) &&
        (FALSE == LpsWrk.DigDetectData.DigDetected) &&
        (LPS_WEIGH_SYSTEM_CALIBRATED == LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.CalStat) &&
        (STATUS_GOOD == LpsChkInputStat()) && (TRUE == LpsWrk.UpdtTbl->UseFilterDataFlag))
    {
        if ((LpsWrk.LowLiftWt.ConfidenceEst >= LpsWrk.LowLiftWt.Confidence) ||
            (LPS_WEIGH_LLW_STATUS_INVALID == LpsWrk.LowLiftWt.Stat))
        {
            LpsWrk.LowLiftWt.Confidence = LpsWrk.LowLiftWt.ConfidenceEst;
			
            LpsWrk.LowLiftWt.MeanEstComp = LpsWrk.LowLiftWt.MeanEst; /*Need to be updated when calibrated weight and zero weight are available */
			/*Zero Weight Adjust*/
			LpsWrk.LowLiftWt.MeanEstComp = LpsCalAdjustWeight(LpsWrk.LowLiftWt.MeanEst - LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.ZeroWeight);
            LpsWrk.LowLiftWt.Wt = LpsWrk.LowLiftWt.MeanEstComp;
			LpsWeighSetZeroAcceptedStatus(FALSE);

			/* remove too heavy to zero popup on next lift */
			if (TRUE == LpsWeighGetTooHeavyToZero()) {
				LpsWeighSetTooHeavyToZero(FALSE);
			}
        }
        LpsWrk.LowLiftWt.Stat = LPS_WEIGH_LLW_STATUS_VALID;
    }
	
	LpsWrk.UpdtErr = LPS_UPDT_SUCCESS;
	return LpsWrk.UpdtErr;
}

/******************************************************************************
FUNCTION NAME:LpsCalculateConfidence
DESCRIPTION: Weight calculation confidence is determined here. Standard deviation is the reciprocal of confidence.
	         Using lookup table, tolerance/standard deviation is interpolated with a 2D map. 
PARAMETER DESCRIPTION: float_32 tolerance, float_32 stdev
RETURN VALUE: float_32 confidence
*******************************************************************************/
static float_32 LpsCalculateConfidence(float_32 tolerance, float_32 stdev)
{
    float_32 confidence,n;
    if (stdev <= (float_32)0.0)
    {
        confidence = 1.0;
    }
    else
    {
        static const float_32 xN[] = { 0.0, 0.3, 0.5, 0.7, 0.9, 1.1, 1.3, 1.5, 1.7, 1.9, 2.1, 2.3, 2.5, 2.7, 3.0, 3.5, 4.0 }; /* Sigma Level */
        static const float_32 yConfidence[] = { 0.0, 0.235822844, 0.382924922, 0.516072694, 0.631879747, 0.728667676, 0.806398927, 0.866385543, 0.910869057, 0.942566872, 0.964271153, 0.978551778, 0.987580668, 0.993066052, 0.997300204, 0.999534742, 1.0 }; /* Confidence */
        n = tolerance / stdev;
        confidence = LpsLookup(n, xN, yConfidence, sizeof(xN)/sizeof(float_32));
    }
    return confidence;
}

/******************************************************************************
FUNCTION NAME:LpsLlwInit
DESCRIPTION: Initializes the filter parameters used for LLW calculation
PARAMETER DESCRIPTION: None
RETURN VALUE: None
*******************************************************************************/
LpsInitErrorTypes_t LpsLlwInit()
{
	LpsInitTbl_t	*pInitTbl	= &LpsWrk.InitTbl;
	LpsWrk.InitErr 				= LPS_INIT_UNKNOWN_ERROR;
	
    LpsWrk.LowLiftWt.BSOne.cf = LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.StageOneCf;
    LpsWrk.LowLiftWt.BSOne.damping = LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.DampingRate;
    LpsWrk.LowLiftWt.BSOne.ts = pInitTbl->ExecRate;
    LpsWrk.LowLiftWt.BSOne.init = FALSE;

    LpsWrk.LowLiftWt.BSTwo.cf = LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.StageTwoCf;
    LpsWrk.LowLiftWt.BSTwo.damping = LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.DampingRate;
    LpsWrk.LowLiftWt.BSTwo.ts = pInitTbl->ExecRate;
    LpsWrk.LowLiftWt.BSTwo.init = FALSE;

    LpsWrk.LowLiftWt.BSThree.cf = LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.StageThreeCf;
    LpsWrk.LowLiftWt.BSThree.damping = LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.DampingRate;
    LpsWrk.LowLiftWt.BSThree.ts = pInitTbl->ExecRate;
    LpsWrk.LowLiftWt.BSThree.init = FALSE;

	cpm_filter_low_pass_filter_reset(&LpsWrk.LowLiftWt.WtFilter, 0.0);
	LpsWrk.LowLiftWt.WtFilter.cf = LpsWrk.InitTbl.MachSpecificCfg.LlwTbl.WtCf;
    LpsWrk.LowLiftWt.WtFilter.ts = pInitTbl->ExecRate;
    LpsWrk.LowLiftWt.WtFilter.init = FALSE;
	
	LpsWrk.LpsStallDetect.LiftStallStat = LPS_LIFT_STALL_NOT_STALLED;
	
	LpsWeighResetLlwWt();
	
	LpsWrk.InitErr = LPS_INIT_SUCCESS;
	return LpsWrk.InitErr;
}

/******************************************************************************
FUNCTION NAME:LpsWeighResetLlwWt
DESCRIPTION: Reset the low lift weigh data to unlatch the current weight
PARAMETER DESCRIPTION: None
RETURN VALUE: None
*******************************************************************************/
void LpsWeighResetLlwWt()
{
    LpsWrk.LowLiftWt.Wt = 0.0;
    LpsWrk.LowLiftWt.Stat = LPS_WEIGH_LLW_STATUS_INVALID;
}
