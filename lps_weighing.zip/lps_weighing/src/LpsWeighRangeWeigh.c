/*******************************************************************************
** COPYRIGHT (C) 2016 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsWeighRange.c
DESCRIPTION:This file provides functionality for various calculations/algorithms
            performed by WRW functionality in LPS library.
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <math.h>
#include <string.h>

#ifndef __LPS_COMMON_TYPE_DEF_H__
#include <LpsCommonTypeDef.h> /* Contains type definitions of standard datatypes */
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h> /* Contains structures which are common between all LPS
                                  * system libraries
								  */
#endif

#ifndef  __LPS_COMMON_LOOKUP_TBL_UTILITY_H__
#include <LpsCommonLookUpTblUtility.h>
#endif

#ifndef __LPS_PUBLIC_H__
#include <LpsPublic.h> /*******************************************************/ 
                       /* Containes prototypes of interfaces and functions    */
                       /* which are exported to the application using the     */
                       /* library                                             */
                       /*******************************************************/
#endif

#include "LpsPrivate.h"

/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/******************************************************************************
FUNCTION NAME:LpsClearReweighWarningStatus
DESCRIPTION: Clears all the reweigh warning parameters
PARAMETER DESCRIPTION: None
RETURN VALUE: None
*******************************************************************************/
void LpsClearReweighWarningStatus(void)
{
    LpsWeighWrwWkTbl_t* pWrwWkTbl = &LpsWrk.WrwTbl.WkTbl;

    /*We are Resetting the Reweigh Warning Structure here*/
    memset(&LpsWrk.WrwTbl.ReweighWarn,0x00,sizeof(LpsWrk.WrwTbl.ReweighWarn));
    /*Reweigh Posted has to be reset before WRW core computations. Hence done here*/
    pWrwWkTbl->ReweighPosted = FALSE;
}

/******************************************************************************
FUNCTION NAME:LpsClearWeighRangeData
DESCRIPTION: Clears all the weigh range data parameters
PARAMETER DESCRIPTION: None
RETURN VALUE: None
*******************************************************************************/
void LpsClearWeighRangeData(void)
{
    LpsWeighWrwWkTbl_t* pWrwWkTbl;
    pWrwWkTbl = &LpsWrk.WrwTbl.WkTbl;

    pWrwWkTbl->Count 		= 0;
    pWrwWkTbl->SecondMoment = 0.0;
    pWrwWkTbl->Skew 		= 0.0;
    pWrwWkTbl->ThirdMoment 	= 0.0;
    pWrwWkTbl->VelAvg 		= 0.0;
    pWrwWkTbl->VelSd 		= 0.0;
    pWrwWkTbl->VelSum 		= 0.0;
    pWrwWkTbl->VelVelSum 	= 0.0;
    pWrwWkTbl->WtAvg 		= 0.0;
    pWrwWkTbl->WtHigh 		= 0.0;
    pWrwWkTbl->WtLow 		= 0.0;
    pWrwWkTbl->WtSd 		= 0.0;
    pWrwWkTbl->WtSum 		= 0.0;
    pWrwWkTbl->WtWtSum 		= 0.0;
    pWrwWkTbl->WtWtWtSum 	= 0.0;
}

/******************************************************************************
FUNCTION NAME:LpsWeighRangeCalcWt
DESCRIPTION: Computes the final WRW weight and based on the condition of lift in weigh range, warnings are raised
PARAMETER DESCRIPTION: None
RETURN VALUE: None
*******************************************************************************/
void LpsWeighRangeCalcWt(void)
{
    LpsWeighWrwWkTbl_t* pWrwWkTbl = &LpsWrk.WrwTbl.WkTbl;
    LpsWeighWrwOpTbl_t* pWrwOpTbl = &LpsWrk.WrwTbl.OpTbl;
    LpsMachSpecificCfg_t* pMachSpecConf = &LpsWrk.InitTbl.MachSpecificCfg;
    LpsWeighWrwErrorLimits_t* pWrwErrLimits = &LpsWrk.WrwTbl.ErrLmt;
    LpsWeighWrwReweighStatus_t* pWrwReweighTbl = &LpsWrk.WrwTbl.ReweighWarn;
    LpsCalib_t* pCalTbl = &pMachSpecConf->CalibTbl;

	float_32 temp;	
	float_32 count;
	float_32 variance;

    /*We need to ascertain if the number of samples in the weigh range taken is greater than 0, failing which 
      it essentially indicates that there was an issue that we were not in the weigh range and hence no weight
      computations be done*/
    if(pWrwWkTbl->Count > 0)
    {
        count = (float_32)(pWrwWkTbl->Count);

        pWrwWkTbl->WtAvg = pWrwWkTbl->WtSum/count;

        pWrwWkTbl->SecondMoment = (pWrwWkTbl->WtWtSum/count) - LPS_SQUARE(pWrwWkTbl->WtAvg);
        pWrwWkTbl->ThirdMoment  = (pWrwWkTbl->WtWtWtSum - (3*pWrwWkTbl->WtAvg*pWrwWkTbl->WtWtSum))/count 
                                       + 2*LPS_CUBE(pWrwWkTbl->WtAvg);

        /*If the second moment of weight variation is very less, then we are not going to generate any reweigh 
          warnings pertaining to bucket weight variations within the weigh range*/
        if((float_32)0.00002 > pWrwWkTbl->SecondMoment)
        {
            pWrwWkTbl->WtSd = 0;
            pWrwWkTbl->Skew = 0;
        }
        else
        {
            pWrwWkTbl->WtSd = (float_32)sqrt((double_64)pWrwWkTbl->SecondMoment);

            {
                temp = LPS_SQUARE(pWrwWkTbl->ThirdMoment)/LPS_CUBE(pWrwWkTbl->SecondMoment);
                pWrwWkTbl->Skew = (float_32)sqrt((double_64)temp);
            }
        }

        /*We are recording the maximum bucket weight variation within the weigh range*/
        pWrwWkTbl->WtAbsDiff = pWrwWkTbl->WtHigh - pWrwWkTbl->WtLow;

        pWrwWkTbl->VelAvg = pWrwWkTbl->VelSum/count;
        {
            variance = (pWrwWkTbl->VelVelSum/count) - LPS_SQUARE(pWrwWkTbl->VelAvg);
            pWrwWkTbl->VelSd = (float_32)sqrt((double_64)variance);
        }

        /*We are trying to determine here if the bucket load during its movement in weigh range was changing 
          rapidly, thereby generating a final weight not very accurate. Hence we raise a Reweigh Warning stating
          the same*/
        if((pWrwWkTbl->WtSd > (float_32)pWrwErrLimits->MaxWtSd) || 
           (pWrwWkTbl->WtAbsDiff > (float_32)pWrwErrLimits->MaxWtAbsDiff))
        {
        	/* If in standby, no reweighs go active */

        	if (TRUE == LpsWrk.UpdtTbl->StandbyActiveState)
        	{
				/* Flag set to warn operator about a reweigh */
				pWrwReweighTbl->RateOfChangeHi = TRUE;
				if(pWrwWkTbl->ReweighPosted == FALSE)
				{
					pWrwWkTbl->ReweighPosted = TRUE;
				}
        	}
        }

        /*We are trying to determine here whether the bucket movement in the weigh range was smooth and 
          consistent. If not, we raise a reweigh warning stating the same*/
        if(pWrwWkTbl->WtSd > (pWrwWkTbl->WtAvg*pWrwErrLimits->MinSdPcnt))
        {
            if((pWrwWkTbl->Skew*(float_32)100.0) > pWrwErrLimits->MaxWtSkew)
            {
            	   /* If in standby, no reweighs go active */

				if (TRUE == LpsWrk.UpdtTbl->StandbyActiveState)
				{
					/* Flag set to warn operator about a reweigh */
                    pWrwReweighTbl->Inconsistent = TRUE;
                if(pWrwWkTbl->ReweighPosted == FALSE)
                {
                    pWrwWkTbl->ReweighPosted = TRUE;
                }
				}
            }
        }

        /*If the velocity of bucket movement within the weigh range has changed frequently, we want to raise a 
          reweigh warning that there was a Jerky movement because Jerk is essentially rate of variation in
          acceleration which further happens when velocity is changing with respect to time*/

        /* If in standby, no reweighs go active */

        /*if (TRUE == LpsWrk.UpdtTbl->StandbyActiveState)
        {
        if(pWrwWkTbl->VelSd > (pWrwErrLimits->MaxVelSd*((pCalTbl->TopOfLift - pCalTbl->BottomOfLift)/((float_32)pMachSpecConf->EndOfWeigh - pMachSpecConf->StartOfWeigh))/(float_32)10))
        {
            pWrwReweighTbl->Jerky = TRUE;
            if(pWrwWkTbl->ReweighPosted == FALSE)
            {
                pWrwWkTbl->ReweighPosted = TRUE;
            }
        }
        }*/

        /* If in standby, no reweighs go active */

        if (TRUE == LpsWrk.UpdtTbl->StandbyActiveState)
        {

        if(pWrwReweighTbl->Stopped)
        {
            if(pWrwWkTbl->ReweighPosted == FALSE)
            {
                pWrwWkTbl->ReweighPosted = TRUE;
            }
        }
        }

        /* If in standby, no reweighs go active */

        if (TRUE == LpsWrk.UpdtTbl->StandbyActiveState)
        {

        if(pWrwReweighTbl->TooSlow)
        {
            if(pWrwWkTbl->ReweighPosted == FALSE)
            {
                pWrwWkTbl->ReweighPosted = TRUE;
            }
        }
        }

        /* If in standby, no reweighs go active */

        if (TRUE == LpsWrk.UpdtTbl->StandbyActiveState)
        {

        if(pWrwReweighTbl->NotRacked)
        {
            if(pWrwWkTbl->ReweighPosted == FALSE)
            {
                pWrwWkTbl->ReweighPosted = TRUE;
            }
        }
        }


        /*Adjust the current weight against any weight previosuly present in the bucket before starting WRW*/
        pWrwOpTbl->Wt = LpsCalAdjustWeight(pWrwWkTbl->WtAvg - pCalTbl->ZeroWeight);

        /*If any one of the reweigh warning flags are true, we are going to say that warning is ACTIVE*/
        if(pWrwWkTbl->ReweighPosted > FALSE)
        {
            pWrwOpTbl->Warning = LPS_WEIGH_WARNING_ACTIVE;
        }
        else
        {
            pWrwOpTbl->Warning = LPS_WEIGH_NO_WARNING_ACTIVE;
        }
        pWrwOpTbl->Status = LPS_WEIGH_WRW_STATUS_VALID;
    }
}

/******************************************************************************
FUNCTION NAME:lpsCalibStatus
DESCRIPTION: Returns the calibration status 
PARAMETER DESCRIPTION: None
RETURN VALUE: unsigned_8 CalStat
*******************************************************************************/
unsigned_8 lpsCalibStatus(void)
{
    LpsCalib_t   *calib;
    LpsMachSpecificCfg_t* pMachSpecConf;

    pMachSpecConf = &LpsWrk.InitTbl.MachSpecificCfg;
    calib   = &pMachSpecConf->CalibTbl;

    return calib->CalStat;
}

/******************************************************************************
FUNCTION NAME:LpsWeighResetWeighRangeWeight
DESCRIPTION: Clears the latched status to FALSE 
PARAMETER DESCRIPTION: None
RETURN VALUE: NONE
*******************************************************************************/
void LpsWeighResetWeighRangeWeight(void)
{
    LpsWeighWrwOpTbl_t* pWrwOpTbl;
    pWrwOpTbl = &LpsWrk.WrwTbl.OpTbl;

    pWrwOpTbl->Status = LPS_WEIGH_WRW_STATUS_INVALID;
    pWrwOpTbl->Wt = 0;

    LpsClearReweighWarningStatus();
}

/******************************************************************************
FUNCTION NAME:LpsSetDefaultErrLimits
DESCRIPTION: Defaults the error limits for WRW parameters 
PARAMETER DESCRIPTION: None
RETURN VALUE: NONE
*******************************************************************************/
void LpsSetDefaultErrLimits(void)
{
    LpsWeighWrwErrorLimits_t* pWrwErrLimits = &LpsWrk.WrwTbl.ErrLmt;

    pWrwErrLimits->MinSdPcnt 		= 0.5;	/* in % */
    pWrwErrLimits->MaxWtSd   		= 1; 	/* in tonnes */
    pWrwErrLimits->MaxWtAbsDiff 	= 2; 	/* no units */
    pWrwErrLimits->MaxWtSkew 		= 300; 	/* no units */
    pWrwErrLimits->MaxVelSd 		= 15; 	/* in 0.1%/s */
}

/******************************************************************************
FUNCTION NAME:LpsGetWrwReweighWarning
DESCRIPTION: Returns the reweigh warning flags' status
PARAMETER DESCRIPTION: None
RETURN VALUE: NONE
*******************************************************************************/
LpsWeighWrwReweighStatus_t LpsGetWrwReweighWarning(void)
{
	LpsWeighWrwWkTbl_t* pWrwWkTbl = &LpsWrk.WrwTbl.WkTbl;
	
	if(pWrwWkTbl->ReweighPosted == TRUE)
	{
		return LpsWrk.WrwTbl.ReweighWarn;
	}
	else
	{
	   LpsWeighWrwReweighStatus_t tempWarning = {0};
	   return tempWarning;
	}
}

/******************************************************************************
FUNCTION NAME:LpsGetWeighRangeWeight
DESCRIPTION: Returns the final latched weight 
PARAMETER DESCRIPTION: None
RETURN VALUE: NONE
*******************************************************************************/
float_32 LpsGetWeighRangeWeight(void)
{
    LpsWeighWrwOpTbl_t* pWrwOpTbl = &LpsWrk.WrwTbl.OpTbl;

    return pWrwOpTbl->Wt;
}

/******************************************************************************
FUNCTION NAME:LpsWeighRangeWeighInit
DESCRIPTION: This initializes the basic filter parameters and default error limits
RETURN VALUE: None
*******************************************************************************/
LpsInitErrorTypes_t LpsWeighRangeWeighInit(void)
{
	LpsWrk.InitErr = LPS_INIT_UNKNOWN_ERROR;
	
    LpsSetDefaultErrLimits();
	LpsWeighSetZeroAcceptedStatus(FALSE);
	
	LpsWrk.InitErr = LPS_INIT_SUCCESS;
	return LpsWrk.InitErr;
}


/******************************************************************************
FUNCTION NAME:LpsWeighRangeWeighUpdate
DESCRIPTION: Weigh Range weigh Position Determination is done here.The Current Bucket Position is determined with 
regards to the App Defined Weigh Ranges and the current weigh range status is set. 
RETURN VALUE: None
*******************************************************************************/
LpsUpdtErrorTypes_t LpsWeighRangeWeighUpdate(void)
{
    LpsWeighWrwWkTbl_t* pWrwWkTbl  				= &LpsWrk.WrwTbl.WkTbl;
    LpsMachSpecificCfg_t* pWrwMachTbl 			= &LpsWrk.InitTbl.MachSpecificCfg;
    LpsWeighWrwOpTbl_t* pWrwOpTbl				= &LpsWrk.WrwTbl.OpTbl;
    LpsWeighWrwReweighStatus_t* pWrwReweighTbl 	= &LpsWrk.WrwTbl.ReweighWarn;
    LpsUpdtTbl_t* pUpdtTbl 						= LpsWrk.UpdtTbl;
	
	LpsWrk.UpdtErr = LPS_UPDT_UNKNOWN_ERROR;
	
    /*When we are below the start of Weigh Range, indicate that we are so and that we have been below the weigh 
      range*/
    if(pUpdtTbl->LiftCylExt.Val < pWrwMachTbl->StartOfWeigh)
    {
        pWrwOpTbl->Indicator = LPS_BELOW_WEIGH_RANGE;
        pWrwWkTbl->BeenBelowRange = TRUE;
    }

    if(pUpdtTbl->LiftCylExt.Val > pWrwMachTbl->EndOfWeigh)
    {
        pWrwOpTbl->Indicator = LPS_ABOVE_WEIGH_RANGE;
    }

    /*We are checking here if we have entered the weigh range from below the weigh range*/
    if(!(pWrwWkTbl->Weighing))
    {
        if((pUpdtTbl->LiftCylExt.Val >= pWrwMachTbl->StartOfWeigh) && 
           (pUpdtTbl->LiftCylExt.Val < pWrwMachTbl->EndOfWeigh) && 
           (pUpdtTbl->LiftCylVel.Val > MIN_LIFT_VELOCITY) && 
           (pWrwWkTbl->BeenBelowRange))
        {
            /*We have entered the weigh range with proper bucket velocity. So,set the Weighing flag to TRUE*/
            pWrwOpTbl->Indicator = LPS_IN_WEIGH_RANGE_WEIGHING;
            pWrwWkTbl->Weighing = TRUE;
            pWrwWkTbl->BeenBelowRange = FALSE;

            /*We are going to start WRW computations once we exit the weigh range by moving up. Hence as a 
              precursor, clear out all the warning status and computation parameters from the previous weigh*/
            LpsClearReweighWarningStatus();
            LpsClearWeighRangeData();
        }
        else if((pUpdtTbl->LiftCylExt.Val >= pWrwMachTbl->StartOfWeigh) && 
                (pUpdtTbl->LiftCylExt.Val < pWrwMachTbl->EndOfWeigh) && 
                (!pWrwWkTbl->BeenBelowRange))
        {
            /*We have moved in here from above the weigh range. Hence We are in the weigh range but not 
              weighing*/
            pWrwOpTbl->Indicator = LPS_IN_WEIGH_RANGE_NOT_WEIGHING;
        }
    }

    if(pWrwWkTbl->Weighing)
    {
        /*We have eentered into the weigh range and are checking if we have moved above the weigh range*/
        if(pUpdtTbl->LiftCylExt.Val > pWrwMachTbl->EndOfWeigh)
        {
            /*We have moved above the weigh range and are going to record the final weight */
            LpsWeighRangeCalcWt();
            pWrwWkTbl->Weighing = FALSE;
        }
        else if(pUpdtTbl->LiftCylExt.Val < pWrwMachTbl->StartOfWeigh)
        {
            /*We haved moved from within the weigh range to below the weigh range. So we are not weighing now*/
            pWrwOpTbl->Indicator = LPS_BELOW_WEIGH_RANGE;
            pWrwWkTbl->Weighing = FALSE;
        }
        else if(LPS_WEIGH_SYSTEM_UNCALIBRATED == lpsCalibStatus())
        {
            pWrwWkTbl->Weighing = FALSE;
        }
        else if(LPS_WEIGHT_BKT_FULLY_DUMPED != GetDumpStateStatus())
        {
			LpsWeighSetZeroAcceptedStatus(FALSE);
			
            /*We compute the WRW weight only if the bucket is not under full dump and if all the inputs are good*/
            if(STATUS_GOOD == LpsChkInputStat() && (TRUE == LpsWrk.UpdtTbl->UseFilterDataFlag))
            {
                /*If the bucket velocity in weigh range at any point becomes less than 1.0, then we raise Stopped 
                  Warning*/
                if(pUpdtTbl->LiftCylVel.Val < MIN_LIFT_VELOCITY)
                {
                    pWrwReweighTbl->Stopped = TRUE;
                }

                /*If the bucket movement within the weigh range is having greater than 32766 position samples, 
                  then it approximately indicates more than 10 minutes within the weigh range at 20ms task rate*/
                if(TOO_SLOW_NUMBER_OF_SAMPLES < pWrwWkTbl->Count)
                {
                    pWrwReweighTbl->TooSlow = TRUE;
                }

                /*We should be fully racked back within the weigh range for sure, otherwise the weight calculations 
                  might not be accurate enough. So we raise a reweigh warning for the same*/
                if(!LpsWeighFullRackDetect())
                {
                    pWrwReweighTbl->NotRacked = TRUE;
                }

                pWrwWkTbl->Count++;
                pWrwWkTbl->WtSum 	 += LpsWrk.InstWtFilt;
                pWrwWkTbl->WtWtSum 	 += LpsWrk.InstWtFilt * LpsWrk.InstWtFilt;
                pWrwWkTbl->WtWtWtSum += LpsWrk.InstWtFilt * LpsWrk.InstWtFilt * LpsWrk.InstWtFilt;
                pWrwWkTbl->VelSum 	 += pUpdtTbl->LiftCylVel.Val;
                pWrwWkTbl->VelVelSum += pUpdtTbl->LiftCylVel.Val * pUpdtTbl->LiftCylVel.Val;

                if(pWrwWkTbl->Count == 1)
                {
                    pWrwWkTbl->WtLow = LpsWrk.InstWtFilt;
                    pWrwWkTbl->WtHigh = LpsWrk.InstWtFilt;
                }
                else
                {              
                    /*We are trying to set the lowest and highest weight values within the weigh range 
                      so we can calculate the absolute weight difference within the weigh range*/
                    if(pWrwWkTbl->WtLow > LpsWrk.InstWtFilt)
                    {
                        pWrwWkTbl->WtLow = LpsWrk.InstWtFilt;
                    }

                    if(pWrwWkTbl->WtHigh < LpsWrk.InstWtFilt)
                    {
                        pWrwWkTbl->WtHigh = LpsWrk.InstWtFilt;
                    }
                }
            }
        }
        else
        {
            pWrwWkTbl->Weighing = FALSE;
        }
    }
	LpsWrk.UpdtErr = LPS_UPDT_SUCCESS;
	return LpsWrk.UpdtErr;
}

LpsWeighRangeIndicator_t LpsWeighGetWeighRangeIndicator(void)
{
	return LpsWrk.WrwTbl.OpTbl.Indicator;
}

