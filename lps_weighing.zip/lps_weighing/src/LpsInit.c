/*******************************************************************************
** COPYRIGHT (C) 2016 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsInit.c
DESCRIPTION:This file provides the initialization routines for the application software
            for LPS library.
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/

#ifndef __LPS_COMMON_TYPE_DEF_H__
/* Contains type definitions of standard datatypes */
#include <LpsCommonTypeDef.h>
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
/* Contains structures which are common between all LPS system libraries */
#include <LpsCommonStructures.h> 
#endif

#ifndef __LPS_PUBLIC_H__
/*******************************************************/ 
/* Has prototypes of interfaces and functions which are*/
/* exported to the application using the library       */
/*******************************************************/
#include <LpsPublic.h>
#endif

/*******************************************************/ 
/* Has prototypes of interfaces and functions which are*/
/* used within the payload computation library         */
/*******************************************************/
#include "LpsPrivate.h"

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
LpsWrkTbl_t LpsWrk = {0};
 
/******************************************************************************
FUNCTION NAME: LpsInit
DESCRIPTION: This function is an API interface for the application software to initialize
             the LPS library.The function accepts machine configuration                       
PARAMETER DESCRIPTION: LpsAppInitTbl ->This interface holds the application configurations
                       for the LPS library.It consists of various machine specific 
                       parameters like cylinder bore area,rod radius,Oil temperature
                       coefficients etc.LPS library configures the internal algorithm
                       based this interface.LPS library makes a local copy of this interface
                       in the work table for further refernec during payload computation.
                       Any change to this interface by application software will not be recognized
                       by the library until a re-init request or ECM key cycle.
                       
RETURN VALUE: LpsInitErrorTypes_t-> This enum interface reports various error types reported by
              LpsInit function to the application software.
*******************************************************************************/
LpsInitErrorTypes_t LpsInit(LpsInitTbl_t  *LpsAppInitTbl)
{	
	LpsResetWrkTbl();
	
	LpsWrk.InitErr = LPS_INIT_UNKNOWN_ERROR;
	
	if(NULL == LpsAppInitTbl)
	{
		LpsWrk.InitErr =  LPS_INIT_CONFIG_ERROR;
		return (LpsWrk.InitErr);
	}
	
	if(FALSE == LpsAppInitTbl->InstallStat)
	{
		LpsWrk.InitErr =  LPS_INIT_DISABLED;
		return (LpsWrk.InitErr);
	}
	
	if( (0   == LpsAppInitTbl->MachSpecificCfg.NoOfLiftCyls) ||
		(0.0 == LpsAppInitTbl->ExecRate) ||
		(0   == LpsAppInitTbl->MachSpecificCfg.LiftCylBoreDia) ||
		(0   == LpsAppInitTbl->MachSpecificCfg.LiftCylRodDia)
	  )
	{
		LpsWrk.InitErr =  LPS_INIT_CONFIG_ERROR;
		return (LpsWrk.InitErr);
	}
	
	LpsCopyAppInitTbl(LpsAppInitTbl); /* As LPS application configurations are
	                               * validated,the configurations are copied into the
	                               * LPS library work table for processing.The LPS library is
	                               * designed to work on local copy of application configurations
	                               * rather than using the actual configuration interface of the application. 
	                               */
	
	LpsCalcCylFlowConst(); /* Calculating hydraulic oil flow constands for lift cyclinder
	                        * based on machine specific values passed by application software
	                        */
	

	LpsLiveWeighInit(); /* Initializing Live Weight parameters */
	
	LpsLlwInit(); /* Initializing the band stop and low pass filter configurations used
			 in the low lift weigh calculation */

	LpsWeighRangeWeighInit();
	
	LpsWeighZeroInit();
	
	LpsWrk.InitErr = PayloadDigDetectInit(LpsAppInitTbl->DumpWtBuffer);
	if(LPS_INIT_SUCCESS != LpsWrk.InitErr)
	{
		return LpsWrk.InitErr;
	}
	
	LpsWrk.InitErr = PayloadDumpStateInit();
	if(LPS_INIT_SUCCESS != LpsWrk.InitErr)
	{
		return LpsWrk.InitErr;
	}
	
	LpsWeighResetBestAvailableBktWt();
	
	LpsWrk.InitErr = LPS_INIT_SUCCESS;
	
	return (LpsWrk.InitErr);
}
