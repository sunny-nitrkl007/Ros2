/*******************************************************************************
** COPYRIGHT (C) 2016 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME:LpsWeighLiveWeigh
DESCRIPTION: Calculates the live weight
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef __LPS_COMMON_TYPE_DEF_H__
#include <LpsCommonTypeDef.h> /* Contains type definitions of standard datatypes */
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h> /* Contains structures which are common between all LPS
                                  * system libraries
                  */
#endif

#ifndef  __LPS_COMMON_LOOKUP_TBL_UTILITY_H__
#include <LpsCommonLookUpTblUtility.h>
#endif

#ifndef __LPS_PUBLIC_H__
#include <LpsPublic.h> /*******************************************************/ 
                       /* Containes prototypes of interfaces and functions    */
                       /* which are exported to the application using the     */
                       /* library                                             */
                       /*******************************************************/
#endif

#include "LpsPrivate.h"

#ifndef __CPM_FILTER_H__
#include <cpm_filter.h> /* Contains the functions from CPM Filter library of MAAL */
#endif

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/

/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/******************************************************************************
FUNCTION NAME:LpsLiveWeighInit
DESCRIPTION: Initializes the filter parameters used for Live Weigh calculation
PARAMETER DESCRIPTION: None
RETURN VALUE: None
*******************************************************************************/
void LpsLiveWeighInit()
{
	LpsInitTbl_t			*pInitTbl		=	&LpsWrk.InitTbl;
	LpsWeighLiveWtCfg_t 	*pLiveWtCfg		=   &LpsWrk.InitTbl.MachSpecificCfg.LiveWeighConfig;
	LpsWeighLiveWeigh_t		*pLiveWtTbl	    = 	&LpsWrk.LiveWeighTbl;
							
	cpm_filter_low_pass_filter_reset(&pLiveWtTbl->SlowFilter, 0.0); 
	cpm_filter_low_pass_filter_reset(&pLiveWtTbl->FastFilter, 0.0);

	pLiveWtTbl->FastFilter.cf = pLiveWtCfg->FastFiltWtCf;
	pLiveWtTbl->FastFilter.ts = pInitTbl->ExecRate;
	pLiveWtTbl->FastFilter.init = FALSE;
	pLiveWtTbl->SlowFilter.cf = pLiveWtCfg->SlowFiltWtCf;
	pLiveWtTbl->SlowFilter.ts = pInitTbl->ExecRate;
	pLiveWtTbl->SlowFilter.init = FALSE;	
	pLiveWtTbl->PrevFastFilt = FALSE;
	
	LpsWeighResetLiveWt();
}


/******************************************************************************
FUNCTION NAME:LpsLiveWeighCalc
DESCRIPTION: Band stop filtered weights are taken as input to this function. Then 
             it is passed through fast/slow low pass filters and then cal adjusted
             after doing the zero weight adjustment.
PARAMETER DESCRIPTION:None
RETURN VALUE: None
*******************************************************************************/
void LpsLiveWeighCalc(void)
{
    float_32 			estWt, zeroWt;
    LpsUpdtTbl_t 		*pUpdateTbl	=	LpsWrk.UpdtTbl;
	LpsWeighLiveWeigh_t	*pLiveWtTbl	=	&LpsWrk.LiveWeighTbl;
	LpsMachSpecificCfg_t* pMachSpecConf = &LpsWrk.InitTbl.MachSpecificCfg;
	LpsCalib_t* pCalTbl = &pMachSpecConf->CalibTbl;
	
	zeroWt = pCalTbl->ZeroWeight;
    
    /* Bandstop filtering is done in LLW calculation to filter the pressure to 
       remove resonant frequencies caused by machine and tire mass resonance */
    cpm_filter_low_pass_filter(&pLiveWtTbl->FastFilter, LpsWrk.InstWtLlwFilt);

    if(FALSE == pUpdateTbl->UseFastFilter && TRUE == pLiveWtTbl->PrevFastFilt)
    {
        /* If transition from fast filter to slow filter happens, reset the slow filter first */
        cpm_filter_low_pass_filter_reset(&pLiveWtTbl->SlowFilter, 0.0);  
    }
          
    cpm_filter_low_pass_filter(&pLiveWtTbl->SlowFilter, LpsWrk.InstWtLlwFilt);

    /* Copying the filter derivative as per the selected filter */
    if(TRUE == pUpdateTbl->UseFastFilter)
    {
        estWt = pLiveWtTbl->FastFilter.ystate;
    }        
    else
    {
        estWt = pLiveWtTbl->SlowFilter.ystate;
    }

    /* Adjust the current weight against any weight previosuly present in the bucket and doing cal adjust */
	
	//Negative weights are allowed according to value team.
	//Based on the that adjust else and one above zeroing wt.		
    pLiveWtTbl->Wt = LpsCalAdjustWeight(estWt - zeroWt);

    pLiveWtTbl->PrevFastFilt = pUpdateTbl->UseFastFilter;
    pLiveWtTbl->Stat = LPS_WEIGH_LIVE_WEIGH_STATUS_VALID;
}

/******************************************************************************
FUNCTION NAME:LpsWeighResetLiveWt
DESCRIPTION: Reset the live weigh data to unlatch the current weight
PARAMETER DESCRIPTION: None
RETURN VALUE: None
*******************************************************************************/
void LpsWeighResetLiveWt(void)
{
    LpsWrk.LiveWeighTbl.Wt = 0.0;
    LpsWrk.LiveWeighTbl.Stat = LPS_WEIGH_LIVE_WEIGH_STATUS_INVALID;
}
