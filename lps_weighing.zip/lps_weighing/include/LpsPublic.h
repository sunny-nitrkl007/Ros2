/*******************************************************************************
** COPYRIGHT (C) 2016 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsPublic.h
DESCRIPTION:
*******************************************************************************/
#ifndef __LPS_PUBLIC_H__
#define __LPS_PUBLIC_H__
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <LpsCommonTypeDef.h>
#include <LpsCommonStructures.h>
#include <LpsCommonLookUpTblUtility.h>
/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
//Only for weighing lib internal usage set by the wrapper / app.
#define STATUS_GOOD   (boolean) 0   
#define STATUS_BAD    (boolean) 1

typedef enum
{		
	LPS_WEIGH_SYSTEM_CALIBRATED = 0,
	LPS_WEIGH_SYSTEM_UNCALIBRATED
}LpsWeighCalStatus_t;

//PCM - PAYLOAD CALC METHOD
#define LPS_WEIGH_PCM_PRIMARY_FILTER_TYPE_DYNAMIC_AVG 0x1
#define LPS_WEIGH_PCM_PRIMARY_FILTER_TYPE_BUTTERWORTH_LP 0x2
#define GET_ACCURACY(PayloadCalcMethod) ((PayloadCalcMethod & 0x0F00) >> 8)

//Hydraulic Pressure Sensors, both Head End and Rod End
#define LPS_WEIGH_PCM_SENSOR_TYPE_HPS_HE_RE 0x1

typedef enum {
  LPS_OIL_TYPE_SAE_10W = 0,
  LPS_OIL_TYPE_SAE_0W20
}LpsHydOilType_t;

typedef enum{
  LPS_INIT_SUCCESS = 0,
  LPS_INIT_FAIL,
  LPS_INIT_CONFIG_ERROR,
  LPS_INIT_DISABLED,
  LPS_INIT_UNKNOWN_ERROR
}LpsInitErrorTypes_t;

typedef enum{
  LPS_UPDT_SUCCESS = 0,
  LPS_UPDT_FAIL,
  LPS_UPDT_INPUT_ERROR,
  LPS_UPDT_DISABLED,
  LPS_UPDT_NOT_INIT,
  LPS_UPDT_UNKNOWN_ERROR
}LpsUpdtErrorTypes_t;

typedef enum{
  LPS_INST_RAW_WT_STATUS_OK = 0,
  LPS_INST_RAW_WT_STATUS_BAD
}LpsInstWtRawStat_t;

typedef enum{
    LPS_WEIGH_WARNING_ACTIVE = 0,
    LPS_WEIGH_NO_WARNING_ACTIVE
}LpsWeighRangeWarning_t;

typedef enum{
    LPS_WEIGH_WRW_STATUS_VALID = 0,
    LPS_WEIGH_WRW_STATUS_INVALID
}LpsWeighRangeLatched_t;

typedef enum {
  LPS_WEIGH_LLW_STATUS_VALID = 0,
  LPS_WEIGH_LLW_STATUS_INVALID
}LpsLlwStat_t;

typedef enum{
    LPS_BELOW_WEIGH_RANGE = 0x0323,
    LPS_IN_WEIGH_RANGE_WEIGHING = 0x0325,
    LPS_ABOVE_WEIGH_RANGE = 0x0326,
    LPS_IN_WEIGH_RANGE_NOT_WEIGHING = 0x06CD
}LpsWeighRangeIndicator_t;

typedef struct
{
    float_32 TiltCompGainScalar;
    float_32 TiltCompEmptyBktWtGain;
    float_32 TiltCompMaxGain;
}LpsTiltCompTbl_t;

typedef struct
{
    unsigned_32     NumColumns;
    unsigned_32     NumRows;
    float_32 const *ColumnAxis;
    float_32 const *RowAxis;
    float_32 const *Data;
}LpsTiltMap_t;

typedef enum{
	LPS_ZERO_UPDATE_SUCCESS = 0,
	LPS_ZERO_UPDATE_NOT_CALIBRATED,
	LPS_ZERO_UPDATE_BUCKET_WT_NOT_ACCURATE,
	LPS_ZERO_UPDATE_HYD_OIL_ERROR,
	LPS_ZERO_UPDATE_TOO_HEAVY_TO_ZERO,
	LPS_ZERO_UPDATE_UNKNOWN_ERROR
}LpsZeroErrorTypes_t;

typedef enum{
	LPS_ZERO_UPDATE_ZERO_NOT_REQUIRED = 0,
	LPS_ZERO_UPDATE_TIMER_EXPIRED_ZERO_REQUIRED,
	LPS_ZERO_UPDATE_TEMPERATURE_CHANGE_ZERO_REQUIRED
}LpsZeroNeededStatus_t;

typedef enum    /* PDI D0 0E9B */   /* Bit Field masks */
{   LPS_WEIGHT_WRW_REWEIGH_WARN_STATUS_NONE = 0x0000,
    LPS_WEIGHT_WRW_REWEIGH_WARN_STATUS_SLOW = 0x8000,
    LPS_WEIGHT_WRW_REWEIGH_WARN_STATUS_STOPPED = 0x4000,
    LPS_WEIGHT_WRW_REWEIGH_WARN_STATUS_NOT_RACKED = 0x2000,
    LPS_WEIGHT_WRW_REWEIGH_WARN_STATUS_JERKY = 0x1000,
    LPS_WEIGHT_WRW_REWEIGH_WARN_STATUS_INCST = 0x0800,
    LPS_WEIGHT_WRW_REWEIGH_WARN_STATUS_CHG2HI = 0x0400,
    LPS_WEIGHT_WRW_REWEIGH_WARN_STATUS_REWEIGH_BUCKET =0x0200,
    LPS_WEIGHT_WRW_REWEIGH_WARN_STATUS_LIFT_TOO_HIGH =0x0100,
    LPS_WEIGHT_WRW_REWEIGH_WARN_STATUS_LIFT_TOO_LOW =0x0080
} LpsWeighWrwReweighWarningStatus_t;

typedef enum   /* Bit Field masks */
{   LPS_WEIGHT_WRW_INFO_POPUP_WARN_STATUS_NONE = 0x00000000,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_UPPER_STALL = 0x00000008,
	LPS_WEIGHT_WRW_INFO_POPUP_WARN_LOWER_STALL = 0x00000004,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_BUCKET_NOT_RACKED = 0x00000002,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_STOPPED_IN_WRG = 0x00000001,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_PRESS_CHG2HI = 0x00000080,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_SPEED_CHG2HI = 0x00000040,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_ZERO_ACCEPTED = 0x00000020,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_SIMPLE_CAL_ACCEPTED = 0x00000010,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_INCONSISTENT = 0x00000800,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_LIFT_TOO_SLOW = 0x00000400,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_ZERO_UPDATE_NOT_CALIBRATED = 0x00000200,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_ZERO_UPDATE_BUCKET_WT_NOT_ACCURATE = 0x00000100,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_ZERO_UPDATE_HYD_OIL_ERROR = 0x00008000,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_ZERO_UPDATE_TOO_HEAVY_TO_ZERO = 0x00004000,
    LPS_WEIGHT_WRW_INFO_POPUP_WARN_ZERO_UPDATE_UNKNOWN_ERROR = 0x00002000
} LpsInfoPopUpWarningStatus_t;


typedef struct {
  unsigned_16 LowerStall:1;
  unsigned_16  UpperStall:1;
}LpsGetStallStat_t;


typedef struct {
    LpsPresSensorInfo_t   	LiftCylHePres;
    LpsPresSensorInfo_t   	LiftCylRePres;
    LpsLiftCylExt_t       	LiftCylExt;
    LpsLiftCylVel_t       	LiftCylVel;
    LpsHydOilTemp_t       	HydOilTemp;
    unsigned_32	        	ClockKeyonSec;
    unsigned_32	        	PassCount;
    boolean                	ZeroButtonPress;
    LpsTiltCylExt_t         TiltCylExt;
	LpsTiltCylVel_t			TiltCylVel;
	LpsBktAngle_t			BktAngle;
	LpsRequestedGear_t		RequestedGear;
	boolean 				UseFastFilter;
	float_32 				LoaderBktPayldTrgtWt;
	boolean                	CaptCylExtnRef;
	boolean					UseFilterDataFlag;
	float_32 				TiltAngleABCPercent;
	char				    StandbyActiveState;
	float_32        		LiftCylPos;
	boolean					AutoManulDumpStateActiveFlag;
	LpsGetStallStat_t       LpsGetStallStat;
}LpsUpdtTbl_t;

typedef struct {
  LpsWeighCalStatus_t    	CalStat;
  float_32      			SlowRaiseEmptyBktLiftHt[11];
  float_32      			SlowRaiseEmptyBktLiftPres[11];
  float_32      			SlowRaiseFullBktLiftHt[11];
  float_32      			SlowRaiseFullBktLiftPres[11];
  float_32      			SlowLowerEmptyBktLiftHt[11];
  float_32      			SlowLowerEmptyBktLiftPres[11];
  float_32      			SlowLowerFullBktLiftHt[11];
  float_32      			SlowLowerFullBktLiftPres[11];
  float_32      			FastRaiseEmptyBktDeltaPres;
  float_32      			FastRaiseFullBktDeltaPres;
  float_32      			EmptyBktSlowRaiseSpd;
  float_32      			EmptyBktFastRaiseSpd;
  float_32      			FullBktSlowRaiseSpd;
  float_32      			FullBktFastRaiseSpd;
  float_32      			Calwt;
  unsigned_16   			TopOfLift;
  unsigned_16   			BottomOfLift;
  float_32 					EmptyTemp;
  float_32 					FullTemp;
  float_32      			CalAdjust;
  float_32      			ZeroWeight;
  float_32      			EmptyBktWtEst;
}LpsCalib_t;

typedef struct {
   float_32 LiftCylHeLineLoss2ndOrdrCoeff;
   float_32 LiftCylHeLineLoss1stOrdrCoeff;
   float_32 LiftCylReLineLoss2ndOrdrCoeff;
   float_32 LiftCylReLineLoss1stOrdrCoeff;
 }LpsHydPressLossCoeff_t;

 typedef struct {
    unsigned_16 TooSlow:1;
    unsigned_16 Stopped:1;
    unsigned_16 NotRacked:1;
    unsigned_16 Jerky:1;
    unsigned_16 Inconsistent:1;
    unsigned_16 RateOfChangeHi:1;
    unsigned_16 ReweighBucket:1;
    unsigned_16 Unused:9;
}LpsWeighWrwReweighStatus_t;

typedef  struct {
   float_32 FilterFactorMean;
   float_32 FilterFactorVariance;
   float_32 ErrorBand;
   float_32 MinimumConfidenceTime;
   float_32 AutoWeighRangeConfThr;
   float_32 AutoWeighMinLiftHt;
   float_32 WtCf;
   float_32 StageOneCf;
   float_32 StageTwoCf;
   float_32 StageThreeCf;   
   float_32 DampingRate;
} LpsLlwConf_t;

/******* Dig State ************/
typedef struct{
	float_32 DigTargetWt;
	float_32 DigDurationMaxLimit;
	float_32 DigDurationMinLimit;
	float_32 DigStartLimit;
	float_32 DigEndLimit;
	float_32 LiftLowerVelocityLimit;
}LpsWeighDigCfg_t;

/******* Dump State ************/
typedef struct{
	float_32					TiltCylExtThreshold;
	float_32					FullDumpBktAngleThreshold;
	float_32					PartDumpBktAngleThreshold;
	float_32					FullRackBktAngleThreshold;
	float_32					TiltAngleABCThreshold;
}LpsWeighDumpCfg_t;

/******* Live Weight ************/
typedef  struct {
   float_32 FastFiltWtCf;
   float_32 SlowFiltWtCf;   
} LpsWeighLiveWtCfg_t;

typedef  struct {
   unsigned_8               NoOfLiftCyls;
   float_32                 LiftCylBoreDia; 
   float_32                 LiftCylRodDia;   
   LpsHydOilType_t          HydOilType;
   LpsCalib_t               CalibTbl;
   LpsHydPressLossCoeff_t   HydPressLossCoeff;
   float_32                 StartOfWeigh;
   float_32                 EndOfWeigh;
   LpsLlwConf_t             LlwTbl;
   LpsWeighBktWtAccuracy_t  ZeroBktWtAccuracyLimit;
   float_32		      		ZeroRangeLimit;
   unsigned_32	            ZeroAdjInitTimeInterval;
   unsigned_32	            ZeroAdjAutoTimeInterval;
   float_32                 ZeroAdjOilTempWarnThreshold;  
   LpsTiltCompTbl_t         TiltComp;
   LpsTiltMap_t             TiltMap;
   LpsWeighDigCfg_t			DigConfig;
   LpsWeighDumpCfg_t		DumpConfig;
   LpsWeighLiveWtCfg_t      LiveWeighConfig;
} LpsMachSpecificCfg_t;


typedef struct
{
  float_32 Val;
  LpsInstWtRawStat_t Stat;
}LpsInstWtRaw_t;

typedef struct
{
	float		*PtrDumpWtBuffer;
	unsigned_8  bufferSize;
}LpsWeighDumpWtBuffer_t;

typedef struct 
{
    boolean                  InstallStat;
    float_32                 ExecRate;
    LpsMachSpecificCfg_t     MachSpecificCfg;	
	LpsWeighDumpWtBuffer_t   DumpWtBuffer;
}LpsInitTbl_t;

typedef struct 
{
	float_32 Wt;	
	unsigned_16  PayloadCalcMeth;
	boolean WeighDecFlag;		/* indicates if we have a latched bucket weight */
	boolean LatchConditionsOK;	/* indicates if latch conditions are ok */
}LpsWeighBestBktWt_t;

/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/

extern LpsInitErrorTypes_t LpsInit(LpsInitTbl_t *LpsAppInitTbl);
extern LpsUpdtErrorTypes_t LpsUpdt(LpsUpdtTbl_t *LpsAppUpdtTbl);
extern boolean LpsChkInputStat(void);

extern LpsInstWtRaw_t LpsGetRawInstWt(void);
extern float_32 LpsGetLiftCylPres(void);

/******* Weigh Range weight ************/
extern unsigned_16 LpsGetWeighRangeIndicator(void);
extern LpsWeighWrwReweighStatus_t LpsGetWrwReweighWarning(void);
extern float_32 LpsGetWeighRangeWeight(void);
extern LpsWeighRangeIndicator_t LpsWeighGetWeighRangeIndicator(void);

/******* Zero function ************/
extern LpsZeroNeededStatus_t LpsWeighGetAutoZeroUpdateStatus(void);
extern LpsZeroErrorTypes_t LpsWeighGetZeroAdjStatus(void);
extern boolean LpsWeighGetZeroAcceptedStatus(void);
extern void LpsWeighAutoZeroSnooze(void);
extern float_32 LpsWeighGetZeroWeight(void);
extern boolean LpsWeighGetTooHeavyToZero(void);
extern void LpsWeighSetTooHeavyToZero(boolean status);
extern void LpsWeighSetZeroAcceptedStatus(boolean);

/******* Best bucket weight ************/
extern LpsWeighBestBktWt_t LpsWeighGetBestAvailableBktWt(void);
extern void LpsWeighResetBestAvailableBktWt(void);
boolean LpsWeighOverloadWarningActive(void);
boolean GetBucketStateWaitForLatch(void);
void SetBucketStateWaitForLatch(boolean val);

/******* Dump State ************/
extern LpsWeighBktDumpStat_t GetDumpStateStatus(void);
extern boolean GetReferenceCaptured(void);
extern void SetReferenceCaptured(boolean val);

/******* Dig State ************/
extern LpsWeighBktDigStat_t LpsWeighGetDigState(void);

/******* stall detect ************/
extern  LpsGetStallStat_t LpsWeighGetStallStat(void);

/* *** BucketLoadFactor**********/
extern float LpsWeighGetBucketLoadFactor();

/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
#endif /* #ifndef __LPS_PUBLIC_H__ */
