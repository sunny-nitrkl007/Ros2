/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Parameter Publisher class for publishing random parameter data via Middleware

#pragma once

#include <SharkConfiguration.pb.h>
#include <Utilities/nice_ptr.h>
#include <memory>
#include <string>
#include <vector>

namespace middleware
{
namespace parameter
{
class IService;
class IConfigBuilder;
class IPublish;
}
}

namespace cat::middleware::parameter { class Data; }

namespace JawsSubscriber
{
struct PublishRequest;

class ParameterPublisher final
{
public:
	ParameterPublisher(cat::shark::Config const& config);
	~ParameterPublisher();

	void Initialize();
	void PublishOnce(PublishRequest const& publishRequest);
private:
	std::unique_ptr<middleware::parameter::IConfigBuilder> CreateConfiguration();
	void PopulatePublisherNames();

	cat::shark::Config const& m_config;
	std::unique_ptr<middleware::parameter::IService> m_parameterService;
	std::vector<std::string> m_publisherNames;
	std::unordered_map<std::string, Utilities::nice_ptr<middleware::parameter::IPublish>> m_publishers;
};
}
