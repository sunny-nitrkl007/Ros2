/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See ParameterReader.h

#include "ParameterReader.h"
#include "WebSocketTypes.h"
#include <IConfigBuilder.h>
#include <ParameterServiceFactory.h>
#include <Utilities/ArrayToHexString.h>
#include <Utilities/narrow_cast.h>
#include <cassert>
#include <chrono>
#include <iostream>

namespace JawsSubscriber
{
namespace
{
constexpr char const* n_pReaderIdentity = "JawsReader";
}

ParameterReader::ParameterReader(cat::shark::Config const& config)
	: m_config{config}
{
}
ParameterReader::~ParameterReader() = default;
void ParameterReader::Initialize()
{
	PopulateReadNames();

	std::cout << "Possible Reads:" << std::endl;
	for (auto const& readName : m_readParameterNames)
	{
		std::cout << "  - " << readName << std::endl;
	}

	auto spConfigBuilder = CreateConfiguration();

	try
	{
		m_spParameterService = middleware::parameter::Factory::CreateParameterService(std::move(spConfigBuilder));

		for (auto const& readName : m_readParameterNames)
		{
			auto& reader = m_spParameterService->RetrieveReadInstance(readName);
			m_readers[readName] = &reader;
		}
	}
	catch (std::exception const& ex)
	{
		// If this fails, you need to add something like this to the DataLinkEngine section of /opt/appdata/Middleware/PARAMETER_SERVICE_TEST_MODE.xml:
		//         <parameter name="pgn_00_feb0" value_type="binary" />
        //         <parameter name="pgn_69_feb0" value_type="binary" />
		std::cerr <<
			"ParameterReader: FAILED TO CREATE MIDDLEWARE PARAMETER SERVICE.\n"
			"The read parameters are probably not in /opt/appdata/Middleware/PARAMETER_SERVICE_TEST_MODE.xml.\n"
			<< ex.what() << std::endl;
		return;
	}

	std::cout << "ParameterReader: Middleware service created successfully" << std::endl;
}
void ParameterReader::ReadOnce(std::string const& readRequest)
{
	auto const& readName = readRequest;

	std::cout << "Reading parameter: " << readName << std::endl;

	auto itFind = m_readers.find(readName);

	if (itFind == m_readers.end())
	{
		std::cout << "Failed to find reader for parameter: " << readName << std::endl;
	}
	else
	{
		auto callback = [this, readName](
			middleware::parameter::IRead::ReadStatus const& readStatus,
			cat::middleware::parameter::Parameter const& parameter)
		{
			OnReadResult(readName, readStatus, parameter);
		};

		auto reader = itFind->second;
		reader->Read(std::move(callback));
	}
}
void ParameterReader::OnReadResult(
	std::string const& readName,
	middleware::parameter::IRead::ReadStatus readStatus,
	cat::middleware::parameter::Parameter const& parameter)
{
	std::cout << "Read result:" << std::endl;
	std::cout << "  Name: " << readName << std::endl;
	std::cout << "  Status: " << readStatus.status << std::endl;
	std::cout << "  Parameter: " << parameter.DebugString() << std::endl;
}
std::unique_ptr<middleware::parameter::IConfigBuilder> ParameterReader::CreateConfiguration()
{
	auto spConfigBuilder = middleware::parameter::IConfigBuilder::Create(n_pReaderIdentity);

	for (auto const& readName : m_readParameterNames)
	{
		std::cout << "ParameterReader: Adding parameter to configuration: " << readName << std::endl;
		spConfigBuilder->AddClientRead(readName.c_str(), {});
	}

	return spConfigBuilder;
}
void ParameterReader::PopulateReadNames()
{
	for (auto const& link : m_config.j1939_data_links())
	{
		for (auto const& peerNode : link.peer_nodes())
		{
			for (auto const& pgnParameter : peerNode.pgn().receive_on_request_pgns())
			{
				for (auto const& spnParameter : pgnParameter.spns())
				{
					m_readParameterNames.push_back(spnParameter.middleware_id());
				}
				m_readParameterNames.push_back(pgnParameter.middleware_id());
			}

			if (peerNode.has_bdt())
			{
				for (auto const& bdtType : peerNode.bdt().bdt_types())
				{
					if (bdtType.access_mode() == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_READ_ONLY ||
					    bdtType.access_mode() == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_READ_WRITE)
					{
						m_readParameterNames.push_back(bdtType.middleware_id());
					}
				}
			}
		}
	}
}
}