# JawsSubscriber

JawsSubscriber is a simple C++ application that subscribes to the set of configured subscribable Middleware parameters and prints updates received from publishers.
It also supplies a WebSocket interface to initiate reads, publishes and writes.

## Features
- Subscribes to configured parameters that will be published to Middleware
    - If diagnostics are configured, internal diagnostic ids are subscribed to
    - If machine security system is configured, machine security system ids are subscribe to
    - Prints parameter updates and quality information to the console
- Allows publishing of configured publish parameters for boolean and binary data types
- Allows reading of configured read parameters
- Allows writing of configured write parameters
    - If machine security system is configured, machine security system ids are subscribed to

## Usage
Run the application after building. It will automatically subscribe to the configured parameters and display updates as they are received.

## Controlling JawsSubscriber
JawsSubscriber is controlled via a web socket interface that uses json. You can use the interface in many different ways--here is one method that works.

1. Forward the port: `ssh -L 8043:localhost:8043 <onboard vm>`
2. In Chrome, navigate to "http://localhost:8043"
   - Note: there is not a web page here... we do this get Chrome to allow us to initialize a web socket to this site
3. Use Chrome dev tools (F12) while at this "site" to run JavaScript and access the JawsSubscriber API

### Example commands

```javascript
var ws = new WebSocket("ws://localhost:8043/JawsSubscriber");
ws.send('{ "writes": { "ids": [ { "id": "machine_security_system.log_in", "value": "1111" } ] } }')
ws.send('{ "publishes": { "ids": [ { "id": "pgn_feed_00", "type": "binary", "value": "0102030405060708" } ] } }')
ws.send('{ "publishes": { "ids": [ { "id": "InternalDiagnostic300", "type": "boolean", "value": "true" } ] } }')
ws.send('{ "reads": { "ids": [ "pgn_00_feb0" ] } }')
```
As of now, only write commands that are pre-configured are supported.  The following is the list of supported writes.
* machine_security_system.log_in
* machine_security_system.log_out
* machine_security_system.lock
* machine_security_system.unlock
* machine_security_system.request_current_operator