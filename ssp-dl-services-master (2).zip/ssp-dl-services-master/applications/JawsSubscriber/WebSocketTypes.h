/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Request structs that are derived from web socket commands

#pragma once

#include <string>
#include <vector>

namespace JawsSubscriber
{
enum DataType
{
	Boolean,
	Binary
};
struct WriteRequest
{
	std::string id;
	std::string type;
	std::string value;
};
using WriteRequests = std::vector<WriteRequest>;

struct PublishRequest
{
	std::string id;
	DataType type;
	std::string value;
};
using PublishRequests = std::vector<PublishRequest>;

using ReadRequests = std::vector<std::string>;
}
