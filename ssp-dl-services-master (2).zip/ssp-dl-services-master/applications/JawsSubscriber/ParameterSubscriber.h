/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Parameter Subscriber class for subscribing to parameters via Middleware

#pragma once

#include <SharkConfiguration.pb.h>
#include <memory>
#include <string>

namespace middleware
{
namespace parameter
{
class IService;
class IConfigBuilder;
}
}

namespace cat::middleware::parameter { class Data; }

namespace JawsSubscriber
{
class ParameterSubscriber final
{
public:
	ParameterSubscriber(cat::shark::Config const& config);
	~ParameterSubscriber();

	void Initialize();
private:
	std::unique_ptr<middleware::parameter::IConfigBuilder> CreateConfiguration();
	void PopulateSubscriberNames();
	void OnParameterUpdate(const std::string& parameterName,
							const cat::middleware::parameter::Data& data);
	void OnPublisherDisconnect(const std::string& parameterName);

	cat::shark::Config const& m_config;
	std::unique_ptr<middleware::parameter::IService> m_parameterService;
	std::vector<std::string> m_subscriberNames{};
};
}
