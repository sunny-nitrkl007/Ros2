/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See ParameterWriter.h

#include "ParameterWriter.h"
#include "WebSocketTypes.h"
#include <IConfigBuilder.h>
#include <middleware_parameter.pb.h>
#include <Utilities/HexStringConverter.h>
#include <ParameterServiceFactory.h>
#include <cassert>
#include <chrono>
#include <iostream>

namespace JawsSubscriber
{
namespace
{
constexpr char const* n_pWriterIdentity = "JawsWriter";
constexpr auto n_writePeriod = std::chrono::milliseconds(10000);
constexpr char const* n_writeParameterNames[] = {
	"machine_security_system.request_current_operator",
	"machine_security_system.log_in",
	"machine_security_system.log_out",
	"machine_security_system.lock",
	"machine_security_system.unlock",
	"calibration_service_test.command",
};
}

ParameterWriter::ParameterWriter(cat::shark::Config const& config)
	: m_config(config)
{
}
ParameterWriter::~ParameterWriter() = default;
void ParameterWriter::Initialize()
{
	PopulateWriterNames();
	std::cout << "Writing possibilities:" << std::endl;
	for (auto const& writerName : m_writerNames)
	{
		std::cout << "  - " << writerName << std::endl;
	}

	auto spConfigBuilder = CreateConfiguration();

	try
	{
		m_spParameterService = middleware::parameter::Factory::CreateParameterService(std::move(spConfigBuilder));

		for (auto const& writerName : m_writerNames)
		{
			auto& writer = m_spParameterService->RetrieveWriteInstance(writerName);
			m_writers[writerName] = &writer;
		}
	}
	catch (std::exception const& ex)
	{
		// If this fails, you need to add something like this to the DataLinkEngine section of /opt/appdata/Middleware/PARAMETER_SERVICE_TEST_MODE.xml:
		//         <parameter name="machine_security_system.request_current_operator" value_type="string" />
		//         <parameter name="machine_security_system.log_in" value_type="string" />
		//         <parameter name="machine_security_system.log_out" value_type="string" />
		//         <parameter name="machine_security_system.lock" value_type="string" />
		//         <parameter name="machine_security_system.unlock" value_type="string" />

		std::cerr <<
			"ParameterWriter: FAILED TO CREATE MIDDLEWARE PARAMETER SERVICE.\n"
			"The write parameters are probably not in /opt/appdata/Middleware/PARAMETER_SERVICE_TEST_MODE.xml.\n"
			<< ex.what() << std::endl;
		return;
	}

	std::cout << "ParameterWriter: Middleware service created successfully" << std::endl;
}
void ParameterWriter::WriteOnce(WriteRequest const& writeRequest)
{
	auto const& writeName = writeRequest.id;
	auto const& writeType = writeRequest.type;
	auto const& writeValue = writeRequest.value;

	std::cout << "Writing parameter: " << writeName << " with value: " << writeValue << std::endl;

	auto itFind = m_writers.find(writeName);

	if (itFind == m_writers.end())
	{
		std::cout << "Failed to find writer for parameter: " << writeName << std::endl;
	}
	else
	{
		cat::middleware::parameter::Data writeData{};
		writeData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);

		if (writeType == "string")
		{
			writeData.mutable_value()->set_string_value(writeValue);
		}
		else if (writeType == "uint")
		{
			auto uintValue = std::stoull(writeValue);
			writeData.mutable_value()->set_uinteger64_value(uintValue);
		}
		else if (writeType == "binary")
		{
			auto dataSize = writeValue.size() / 2;
			std::vector<uint8_t> valueBytes(dataSize);
			Utilities::HexStringConverter{}.ToBinary(writeValue, valueBytes.data(), static_cast<unsigned>(valueBytes.size()));
			writeData.mutable_value()->set_binary_value(valueBytes.data(), valueBytes.size());
		}
		else
		{
			assert(writeType == "double");
			auto doubleValue = std::stod(writeValue);
			writeData.mutable_value()->set_double_value(doubleValue);
		}

		auto writer = (*itFind).second;
		writer->Write(writeData,
			[this, writeName](middleware::parameter::IWrite::WriteStatus const& writeStatus, cat::middleware::parameter::Parameter const& parameter)
			{
				OnWriteResult(writeName, writeStatus, parameter);
			});
	}
}
void ParameterWriter::OnWriteResult(
	std::string const& parameterName,
	middleware::parameter::IWrite::WriteStatus writeStatus,
	cat::middleware::parameter::Parameter const& parameter)
{
	std::cout << "Write result:" << std::endl;
	std::cout << "  Name: " << parameterName << std::endl;
	std::cout << "  Status: " << writeStatus.status << std::endl;
	std::cout << "  Parameter: " << parameter.DebugString() << std::endl;
}
std::unique_ptr<middleware::parameter::IConfigBuilder> ParameterWriter::CreateConfiguration()
{
	auto spConfigBuilder = middleware::parameter::IConfigBuilder::Create(n_pWriterIdentity);

	for (auto const& writeName : m_writerNames)
	{
		spConfigBuilder->AddClientWrite(writeName.c_str(), {});
	}

	return spConfigBuilder;
}
void ParameterWriter::PopulateWriterNames()
{
	for (auto const& link : m_config.j1939_data_links())
	{
		for (auto const& peerNode : link.peer_nodes())
		{
			for (auto const& basicReadWriteParameter : peerNode.basic_read_write().basic_read_write_pids())
			{
				m_writerNames.push_back(basicReadWriteParameter.middleware_id());
			}

			if (peerNode.has_bdt())
			{
				for (auto const& bdtType : peerNode.bdt().bdt_types())
				{
					if (bdtType.access_mode() == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_WRITE_ONLY ||
					    bdtType.access_mode() == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_READ_WRITE)
					{
						m_writerNames.push_back(bdtType.middleware_id());
					}
				}
			}
		}
	}

	for (auto const* pParameterName : n_writeParameterNames)
	{
		m_writerNames.push_back(pParameterName);
	}
}
}