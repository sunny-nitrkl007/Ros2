/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See ParameterPublisher.h

#include "ParameterPublisher.h"
#include "WebSocketTypes.h"
#include <IConfigBuilder.h>
#include <ParameterServiceFactory.h>
#include <IPublishParameter.h>
#include <middleware_parameter.pb.h>
#include <Utilities/HexStringConverter.h>
#include <Utilities/narrow_cast.h>
#include <iostream>
#include <chrono>

namespace JawsSubscriber
{
namespace
{
constexpr char const* n_pPublisherIdentity = "JawsPublisher";
constexpr auto n_publishPeriod = std::chrono::milliseconds(10000); // Publish every 10 seconds
}

ParameterPublisher::ParameterPublisher(cat::shark::Config const& config)
	: m_config{config}
{
}

ParameterPublisher::~ParameterPublisher() = default;

void ParameterPublisher::Initialize()
{
	PopulatePublisherNames();

	std::cout << "Possible publishers:" << std::endl;
	for (auto const& publisherName : m_publisherNames)
	{
		std::cout << "  - " << publisherName << std::endl;
	}

	auto spConfigBuilder = CreateConfiguration();

	m_parameterService = middleware::parameter::Factory::CreateParameterService(std::move(spConfigBuilder));

	assert(m_parameterService);
	std::cout << "ParameterPublisher: Middleware service created successfully" << std::endl;

	// Retrieve publisher instances for each parameter
	for (auto const& publisherName : m_publisherNames)
	{
		auto& publisher = m_parameterService->RetrievePublisherInstance(publisherName);
		m_publishers[publisherName] = &publisher;
	}
}
void ParameterPublisher::PublishOnce(PublishRequest const& publishRequest)
{
	auto const& publishName = publishRequest.id;
	auto const& publishType = publishRequest.type;
	auto const& publishStringValue = publishRequest.value;

	std::cout << "Publishing parameter: " << publishName << " with value: " << publishStringValue << std::endl;

	auto itFind = m_publishers.find(publishName);

	if (itFind == m_publishers.end())
	{
		std::cout << "Failed to find publisher for parameter: " << publishName << std::endl;
	}
	else
	{
		auto dataIsValid = true;
		cat::middleware::parameter::Data publishData{};
		if (publishType == DataType::Boolean)
		{
			bool boolValue = (publishStringValue == "true");
			publishData.mutable_value()->set_boolean_value(boolValue);
		}
		else if (publishType == DataType::Binary)
		{
			auto dataSize = publishStringValue.size() / 2;
			std::vector<uint8_t> valueBytes(dataSize);
			Utilities::HexStringConverter{}.ToBinary(publishStringValue, valueBytes.data(), static_cast<unsigned>(valueBytes.size()));
			publishData.mutable_value()->set_binary_value(valueBytes.data(), valueBytes.size());
		}
		else
		{
			std::cout << "Unsupported data type for parameter: " << publishName << std::endl;
			dataIsValid = false;
		}

		if (dataIsValid)
		{
			publishData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);

			auto publisher = (*itFind).second;
			publisher->Publish(publishData);
		}
	}
}
std::unique_ptr<middleware::parameter::IConfigBuilder> ParameterPublisher::CreateConfiguration()
{
	auto spConfigBuilder = middleware::parameter::IConfigBuilder::Create(n_pPublisherIdentity);

	for (auto const& publisherName : m_publisherNames)
	{
		spConfigBuilder->AddPublish(publisherName.c_str(), {}, {});
	}

	return spConfigBuilder;
}
void ParameterPublisher::PopulatePublisherNames()
{
	for (auto const& link : m_config.j1939_data_links())
	{
		for (auto const& transmitPgnEntry : link.transmit_broadcast_pgns())
		{
			m_publisherNames.push_back(transmitPgnEntry.middleware_id());
		}
	}
	if (m_config.has_diagnostics())
	{
		if (m_config.diagnostics().has_internal_code_list())
		{
			for (auto const& internalCode : m_config.diagnostics().internal_code_list().internal_codes())
			{
				m_publisherNames.push_back(internalCode.middleware_id());
			}
		}
	}
}
}
