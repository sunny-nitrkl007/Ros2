/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Code Subscriber class for subscribing to codes via Middleware

#pragma once
#include <memory>

namespace middleware
{
namespace diagnostics
{
class IService;
class ICodeClient;
}
}

namespace cat::middleware::diagnostics { class Codes; }

namespace JawsSubscriber
{
class CodeSubscriber final
{
public:
	CodeSubscriber();
	~CodeSubscriber();

	void Initialize();
private:
	void OnCodesUpdate(cat::middleware::diagnostics::Codes const& codes);
	void OnDisconnect();

	std::unique_ptr<middleware::diagnostics::IService> m_spCodeService{};
	std::unique_ptr<middleware::diagnostics::ICodeClient> m_spCodeClient{};
};
}
