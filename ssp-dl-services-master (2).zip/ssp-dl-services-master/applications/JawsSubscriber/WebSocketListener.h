/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// The JawsSubscriber WebSocketListener

#pragma once

#include "WebSockets/JsonWebSocket.h"
#include "WebSocketTypes.h"
#include <mutex>
#include <string>
#include <vector>

namespace JawsSubscriber
{
class WebSocketListener
{
public:
	WebSocketListener();

	WriteRequests TakeWriteRequests();
	PublishRequests TakePublishRequests();
	ReadRequests TakeReadRequests();
private:
	void HandleWrites(nlohmann::json const& writeJson);
	void HandlePublishes(nlohmann::json const& publishJson);
	void HandleReads(nlohmann::json const& readJson);

	std::shared_ptr<WebSockets::JsonWebSocket> m_spJsonWebSocket{};

	std::mutex m_mutex{};
	std::vector<WebSockets::JsonWebSocket::Deregisterer> m_deregisterers{};
	WriteRequests m_writeRequests{};
	PublishRequests m_publishRequests{};
	ReadRequests m_readRequests{};
};
}
