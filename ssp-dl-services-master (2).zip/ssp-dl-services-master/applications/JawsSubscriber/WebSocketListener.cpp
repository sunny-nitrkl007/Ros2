/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See WebSocketListener.h

#include "WebSocketListener.h"
#include <Utilities/ArrayToHexString.h>
#include <Utilities/HexStringConverter.h>
#include <simple-websocket-server/server_ws.hpp>

namespace JawsSubscriber
{
WebSocketListener::WebSocketListener()
	: m_spJsonWebSocket{std::make_shared<WebSockets::JsonWebSocket>("/JawsSubscriber", 8043)}
{
	// JavaScript for using this socket in web browser dev tools:
	//   var ws = new WebSocket("ws://localhost:8043/JawsSubscriber");
	//   ws.send('{ "writes": { "ids": [ { "id": "write_string", "type": "string","value": "1111" } ] } }')
	//   ws.send('{ "writes": { "ids": [ { "id": "write_double", "type": "doubule", "value": "3.6" } ] } }')
	//   ws.send('{ "writes": { "ids": [ { "id": "write_uint", "type": "uint", "value": "42" } ] } }')
	//   ws.send('{ "writes": { "ids": [ { "id": "write_binary", "type": "binary", "value": "010203" } ] } }')
	//       writes are always assumed to be string for now
	//   ws.send('{ "publishes": { "ids": [ { "id": "pgn_feed_00", "type": "binary", "value": "0102030405060708" } ] } }')
	//   ws.send('{ "publishes": { "ids": [ { "id": "InternalDiagnostic300", "type": "boolean", "value": "true" } ] } }')
	//       publishes can be binary or boolean
	//   ws.send('{ "reads": { "ids": [ "pgn_00_feb0" ] } }')
	m_deregisterers.emplace_back(
		m_spJsonWebSocket->Register("writes",   []() noexcept {}, [this](auto&& json){ this->HandleWrites(json); }));
	m_deregisterers.emplace_back(
		m_spJsonWebSocket->Register("publishes",   []() noexcept {}, [this](auto&& json){ this->HandlePublishes(json); }));
	m_deregisterers.emplace_back(
		m_spJsonWebSocket->Register("reads",   []() noexcept {}, [this](auto&& json){ this->HandleReads(json); }));
}
WriteRequests WebSocketListener::TakeWriteRequests()
{
	std::lock_guard<std::mutex> lock{m_mutex};

	auto writes = std::move(m_writeRequests);
	m_writeRequests.clear();
	return writes;
}
PublishRequests WebSocketListener::TakePublishRequests()
{
	std::lock_guard<std::mutex> lock{m_mutex};

	auto publishes = std::move(m_publishRequests);
	m_publishRequests.clear();
	return publishes;
}
ReadRequests WebSocketListener::TakeReadRequests()
{
	std::lock_guard<std::mutex> lock{m_mutex};

	auto reads = std::move(m_readRequests);
	m_readRequests.clear();
	return reads;
}
void WebSocketListener::HandleWrites(nlohmann::json const& writeJson)
{
	std::lock_guard<std::mutex> lock{m_mutex};

	auto const& writeJsonList = writeJson["ids"];
	for (auto&& writeJsonItem : writeJsonList)
	{
		auto id = writeJsonItem["id"].get<std::string>();
		auto type = writeJsonItem["type"].get<std::string>();
		auto value = writeJsonItem["value"].get<std::string>();

		std::cout << id << ": Writing " << value << " (" << value.size() << " characters)" << std::endl;
		m_writeRequests.emplace_back(std::move(id), std::move(type), std::move(value));
	}
}
void WebSocketListener::HandlePublishes(nlohmann::json const& publishJson)
{
	std::lock_guard<std::mutex> lock{m_mutex};

	auto const& publishJsonList = publishJson["ids"];
	for (auto&& publishJsonItem : publishJsonList)
	{
		auto id = publishJsonItem["id"].get<std::string>();
		auto type = publishJsonItem["type"].get<std::string>();
		auto value = publishJsonItem["value"].get<std::string>();

		auto dataType = type == "boolean" ? DataType::Boolean : DataType::Binary;

		std::cout << id << ": Publishing " << value << " (" << value.size() << " characters)" << std::endl;
		m_publishRequests.emplace_back(PublishRequest{std::move(id), dataType, std::move(value)});
	}
}
void WebSocketListener::HandleReads(nlohmann::json const& readJson)
{
	std::lock_guard<std::mutex> lock{m_mutex};

	auto const& readJsonList = readJson["ids"];
	for (auto&& readJsonItem : readJsonList)
	{
		auto id = readJsonItem.get<std::string>();

		std::cout << id << ": Reading" << std::endl;
		m_readRequests.emplace_back(std::move(id));
	}
}
}