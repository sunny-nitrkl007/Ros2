/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Parameter Reader class for requesting parameter reads via Middleware

#pragma once

#include <IReadParameter.h>
#include <ParameterServiceDefines.h>
#include <SharkConfiguration.pb.h>
#include <Utilities/nice_ptr.h>
#include <middleware_parameter.pb.h>
#include <memory>
#include <string>
#include <vector>

namespace middleware
{
namespace parameter
{
class IService;
class IConfigBuilder;
}
}

namespace JawsSubscriber
{
class ParameterReader final
{
public:
	ParameterReader(cat::shark::Config const& config);
	~ParameterReader();

	void Initialize();
	void ReadOnce(std::string const& readRequest);
private:
	std::unique_ptr<middleware::parameter::IConfigBuilder> CreateConfiguration();
	void PopulateReadNames();
	void OnReadResult(
		std::string const& parameterName,
		middleware::parameter::IRead::ReadStatus readStatus,
		cat::middleware::parameter::Parameter const& parameter);

	cat::shark::Config const& m_config;
	std::unique_ptr<middleware::parameter::IService> m_spParameterService{};
	std::vector<std::string> m_readParameterNames;
	std::unordered_map<std::string, Utilities::nice_ptr<middleware::parameter::IRead>> m_readers{};
};
}
