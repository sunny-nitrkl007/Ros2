/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See CodeSubscriber.h

#include "CodeSubscriber.h"
#include <CodesFactory.h>
#include <ICodeClient.h>
#include <middleware_diagnostics.pb.h>
#include <middleware_diagnostics_additionalinformation.pb.h>
#include <cassert>
#include <iostream>

namespace JawsSubscriber
{
namespace
{
cat::middleware::diagnostics::CodeStatus GetCodeStatus(cat::middleware::diagnostics::Code const& code)
{
	auto &information = code.information();
	cat::middleware::diagnostics::CodeStatus status{};
	if (information.has_diagnostic())
	{
		status = information.diagnostic().status();
	}
	else if (information.has_event())
	{
		status = information.event().status();
	}
	else
	{
		assert(information.has_public_dtc());
		status = information.public_dtc().status();
	}
	return status;
}
}
CodeSubscriber::CodeSubscriber() = default;
CodeSubscriber::~CodeSubscriber() = default;

void CodeSubscriber::Initialize()
{
	m_spCodeService = middleware::diagnostics::Factory::CreateDiagnosticService();
	assert(m_spCodeService);
	std::cout << "CodeSubscriber: Middleware service created successfully" << std::endl;
	middleware::diagnostics::CodeConsumer codeConsumer
	{
		[this](cat::middleware::diagnostics::Codes const& codes) { OnCodesUpdate(codes); },
		[this]() { OnDisconnect(); }
	};
	m_spCodeClient = m_spCodeService->CreateCodeClient(std::move(codeConsumer));
	assert(m_spCodeClient);
	std::cout << "CodeSubscriber: CodeClient created successfully" << std::endl;
}
void CodeSubscriber::OnCodesUpdate(cat::middleware::diagnostics::Codes const& codes)
{
	std::cout << "Received Codes Update:" << std::endl;
	if (codes.codes().empty())
	{
		std::cout << "  - No codes\n" <<  std::endl;
	}
	for (auto const& code : codes.codes())
	{
		std::cout << "  - " << code.ShortDebugString() << std::endl;
		auto codeStatus = GetCodeStatus(code);
		if (codeStatus == cat::middleware::diagnostics::CodeStatus::CODE_STATUS_ACTIVE_AND_LOGGED ||
			codeStatus == cat::middleware::diagnostics::CodeStatus::CODE_STATUS_LOGGED_ONLY)
		{
			std::cout << "  - Requesting Additional Information for : " << code.code_key() << std::endl;
			m_spCodeClient->RequestAdditionalInformation(
				code.code_key(),
				{::middleware::diagnostics::AdditionalInformationGroup::Group2},
				[](cat::middleware::diagnostics::AdditionalInformation const& additionalInfo)
				{
					std::cout << "  -  - Received Additional Information: " << additionalInfo.ShortDebugString() << "\n" << std::endl;
				});
		}
	}
}
void CodeSubscriber::OnDisconnect()
{
	std::cout << "Code client disconnected!" << std::endl;
}
}
