/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See ParameterSubscriber.h

#include "ParameterSubscriber.h"
#include <IConfigBuilder.h>
#include <ParameterServiceFactory.h>
#include <middleware_parameter.pb.h>
#include <Utilities/ArrayToHexString.h>
#include <Utilities/narrow_cast.h>
#include <iostream>

namespace JawsSubscriber
{
namespace
{
constexpr char const* n_dataLinkEngineConfig = "data_link_engine.configuration";
constexpr char const* n_pSubscriberIdentity = "JawsSubscriber";
constexpr char const* n_diagnosticNames[]
{
	// Codes
	"data_link_engine.highest_active_annunciation_requirement",
};
constexpr char const* n_mssNames[]
{
	// Machine Security System
	"machine_security_system.operator_name",
	"machine_security_system.is_guest",
	"machine_security_system.is_master",
	"machine_security_system.log_in_method",
};
constexpr char const* n_calibrationNames[]
{
	"calibration_service_test.status",
};
}

ParameterSubscriber::ParameterSubscriber(cat::shark::Config const& config)
	: m_config{config}
{
}
ParameterSubscriber::~ParameterSubscriber() = default;

void ParameterSubscriber::Initialize()
{
	// Set middleware logging level
	middleware::parameter::Factory::SetLogLevel(std::cout, 3); // ERROR|WARNINGS|INFO

	PopulateSubscriberNames();
	std::cout << "Subscribing to:" << std::endl;
	for (auto const& subscriberName : m_subscriberNames)
	{
		std::cout << "  - " << subscriberName << std::endl;
	}

	// Create configuration with subscriptions for all parameters
	auto spConfigBuilder = CreateConfiguration();

	// Create the parameter service
	m_parameterService = middleware::parameter::Factory::CreateParameterService(std::move(spConfigBuilder));

	assert(m_parameterService);
	std::cout << "ParameterSubscriber: Middleware service created successfully" << std::endl;
}

void ParameterSubscriber::OnParameterUpdate(const std::string& parameterName,
											const cat::middleware::parameter::Data& data)
{
	using namespace cat::middleware::parameter;

	std::string type = "Unknown";
	std::string valueString = "Unknown data type";

	if (data.has_value()) {
		auto const& value = data.value();
		switch (value.selection_case())
		{
			case Value::SelectionCase::kDoubleValue:
				type = "Double";
				valueString = std::to_string(value.double_value());
				break;
			case Value::SelectionCase::kStringValue:
				type = "String";
				valueString = value.string_value();
				break;
			case Value::SelectionCase::kBinaryValue:
			{
				type = "Binary";

				auto const binaryInString = value.binary_value();
				std::vector<uint8_t> const binaryInVector(binaryInString.begin(), binaryInString.end());
				valueString = Utilities::ArrayToHexString(
					binaryInVector.data(),
					Utilities::narrow_cast<unsigned>(binaryInVector.size()));
				break;
			}
			case Value::SelectionCase::kBooleanValue:
				type = "Boolean";
				valueString = (value.boolean_value() ? "true" : "false");
				break;
			case Value::SelectionCase::kUinteger64Value:
				type = "UInt64";
				valueString = std::to_string(value.uinteger64_value());
				break;
			default:
				break;
		}
	}

	std::cout << "Parameter Update:" << std::endl;
	std::cout << "  Name: " << parameterName << std::endl;
	std::cout << "  Type: " << type << std::endl;
	std::cout << "  Value: " << valueString << std::endl;
	std::cout << "  Quality: " << Quality_Name(data.quality()) << std::endl;
	std::cout << std::endl;
}

void ParameterSubscriber::OnPublisherDisconnect(std::string const& parameterName)
{
	std::cout << "Publisher disconnected for parameter: " << parameterName << std::endl;
}

std::unique_ptr<middleware::parameter::IConfigBuilder> ParameterSubscriber::CreateConfiguration()
{
	auto spConfigBuilder = middleware::parameter::IConfigBuilder::Create(n_pSubscriberIdentity);

	// Add subscriptions for all hard-coded parameters
	for (auto const& parameterName : m_subscriberNames)
	{
		// Create callbacks for this parameter
		auto onPublish = [this, parameterName](std::string const&, middleware::parameter::Data const& data)
		{
			this->OnParameterUpdate(parameterName, data);
		};

		auto onDisconnect = [this, parameterName]()
		{
			this->OnPublisherDisconnect(parameterName);
		};

		// Add subscription to configuration (empty Unit{} creates default unit)
		spConfigBuilder->AddSubscribe(std::string(parameterName), {}, std::move(onPublish), std::move(onDisconnect));
	}

	std::string serializedConfig;
	m_config.SerializeToString(&serializedConfig);
	cat::middleware::parameter::Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	data.mutable_value()->set_binary_value(serializedConfig.data(), serializedConfig.size());
	spConfigBuilder->AddPublish(n_dataLinkEngineConfig, {}, std::move(data));

	return spConfigBuilder;
}
void ParameterSubscriber::PopulateSubscriberNames()
{
	bool hasCalibrationServices = false;
	for (auto const& link : m_config.j1939_data_links())
	{
		for (auto const& peerNode : link.peer_nodes())
		{
			for (auto const& adtParameter : peerNode.adt().adt_pids())
			{
				m_subscriberNames.push_back(adtParameter.middleware_id());
			}
			for (auto const& pgbParameter : peerNode.pgb().pgb_pids())
			{
				m_subscriberNames.push_back(pgbParameter.middleware_id());
			}
			for (auto const& pgnParameter : peerNode.pgn().receive_broadcast_pgns())
			{
				for (auto const& spnParameter : pgnParameter.spns())
				{
					m_subscriberNames.push_back(spnParameter.middleware_id());
				}
				m_subscriberNames.push_back(pgnParameter.middleware_id());
			}
			if (peerNode.has_calibration_services())
			{
				hasCalibrationServices = true;
			}
		}
	}
	if (m_config.has_diagnostics())
	{
		for (auto const* diagnosticNames : n_diagnosticNames)
		{
			m_subscriberNames.push_back(diagnosticNames);
		}
	}
	if (m_config.has_machine_security_system())
	{
		for (auto const* mssName : n_mssNames)
		{
			m_subscriberNames.push_back(mssName);
		}
	}
	if (hasCalibrationServices)
	{
		for (auto const* pCalibrationName : n_calibrationNames)
		{
			m_subscriberNames.push_back(pCalibrationName);
		}
	}
}
}
