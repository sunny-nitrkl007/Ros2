/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// JawsSubscriber : Middleware parameter subscriber application

#include "CodeSubscriber.h"
#include "JawsConfigDescriber.h"
#include "ParameterPublisher.h"
#include "ParameterReader.h"
#include "ParameterSubscriber.h"
#include "ParameterWriter.h"
#include "WebSocketListener.h"
#include <Config/ConfigFactory.h>
#include <atomic>
#include <chrono>
#include <initializer_list>
#include <thread>
#include <signal.h>

namespace
{
using namespace std::chrono_literals;

constexpr auto n_loopDelay = 1000ms;

std::atomic<bool> n_quit{false};
void Quit(int)
{
	n_quit = true;
}

void QuitInit()
{
	for (auto signal : { SIGTERM, SIGINT } )
	{
		struct sigaction action;
		sigaction(signal, nullptr, &action);
		action.sa_handler = &Quit;
		sigaction(signal, &action, nullptr);
	}
}

void Run()
{
	QuitInit();

	JawsSubscriber::JawsConfigDescriber configDescriber{};
	auto const& config = Config::ConfigFactory::CreateConfig(configDescriber);

	JawsSubscriber::ParameterSubscriber parameterSubscriber{config};
	parameterSubscriber.Initialize();

	JawsSubscriber::ParameterPublisher parameterPublisher{config};
	parameterPublisher.Initialize();

	JawsSubscriber::ParameterReader parameterReader{config};
	parameterReader.Initialize();

	JawsSubscriber::ParameterWriter parameterWriter{config};
	parameterWriter.Initialize();

	JawsSubscriber::CodeSubscriber codeSubscriber{};
	codeSubscriber.Initialize();

	JawsSubscriber::WebSocketListener webSocketListener{};

	while (!n_quit)
	{
		auto writeRequests = webSocketListener.TakeWriteRequests();
		for (auto&& writeRequest : writeRequests)
		{
			parameterWriter.WriteOnce(writeRequest);
		}

		auto publishRequests = webSocketListener.TakePublishRequests();
		for (auto&& publishRequest : publishRequests)
		{
			parameterPublisher.PublishOnce(publishRequest);
		}

		auto readRequests = webSocketListener.TakeReadRequests();
		for (auto&& readRequest : readRequests)
		{
			parameterReader.ReadOnce(readRequest);
		}

		std::this_thread::sleep_for(n_loopDelay);
	}
}
}

int main()
{
	Run();
	return 0;
}
