/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Jaws Config Describer

#pragma once

#include <Config/IConfigDescriber.h>

namespace JawsSubscriber
{
template <class T> using nice_ptr = Utilities::nice_ptr<T>;

class JawsConfigDescriber final : public Config::IConfigDescriber
{
public:
// Config::IConfigDescriber
	nice_ptr<Config::SharkConfig const> GetSharkConfig() const override;
	nice_ptr<Config::PidIdentifierConfig const> GetPidConfig() const override;
	nice_ptr<Config::PgnIdentifierConfig const> GetPgnConfig() const override;
	nice_ptr<Config::SpnIdentifierConfig const> GetSpnConfig() const override;
	nice_ptr<Config::MultiBytePidIdentifierConfig const> GetMultiBytePidConfig() const override;
};
}
