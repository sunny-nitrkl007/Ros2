#!/usr/bin/env python3
# Copyright (C) Caterpillar Inc. All Rights Reserved.

"""JawsSubscriber websocket client."""


import argparse
import json
from typing import Iterable

import websocket


DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8043
PATH = "/JawsSubscriber"
SOCKET_TIMEOUT_SECONDS = 5.0


def _build_parser() -> argparse.ArgumentParser:
	parser = argparse.ArgumentParser(
		description="Send websocket commands to a JawsSubscriber instance.")
	parser.add_argument("--host", default=DEFAULT_HOST, help="Websocket host.")
	parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="Websocket port.")

	subparsers = parser.add_subparsers(dest="command", required=True)

	write_parser = subparsers.add_parser(
		"write", help="Send a write request.")
	write_parser.add_argument(
		"entries",
		nargs="+",
		metavar="ID:TYPE:VALUE",
		help="One or more write entries as ID:TYPE:VALUE (e.g. write_string:string:hello).")

	publish_parser = subparsers.add_parser(
		"publish", help="Send a publish request.")
	publish_parser.add_argument(
		"entries",
		nargs="+",
		metavar="ID:TYPE:VALUE",
		help="One or more publish entries as ID:TYPE:VALUE where TYPE is 'binary' or 'boolean' "
		     "(e.g. pgn_feed_00:binary:0102030405060708).")

	read_parser = subparsers.add_parser(
		"read", help="Send a read request.")
	read_parser.add_argument(
		"ids",
		nargs="+",
		help="One or more SharkByte IDs to read.")

	return parser


def _build_url(host: str, port: int, path: str) -> str:
	normalized_path = path if path.startswith("/") else f"/{path}"
	return f"ws://{host}:{port}{normalized_path}"


def _send_json_message(host: str, port: int, payload: dict[str, object]) -> None:
	message = json.dumps(payload, separators=(",", ":")).encode("utf-8")
	sock = websocket.create_connection(
		_build_url(host, port, path=PATH),
		timeout=SOCKET_TIMEOUT_SECONDS)
	try:
		sock.send(message, opcode=websocket.ABNF.OPCODE_TEXT)
	finally:
		sock.close()


def _parse_entry(entry: str) -> tuple[str, str, str]:
	parts = entry.split(":", maxsplit=2)
	if len(parts) != 3:
		raise argparse.ArgumentTypeError(
			f"Expected ID:TYPE:VALUE, got {entry!r}")
	return parts[0], parts[1], parts[2]


def _build_write_payload(entries: Iterable[str]) -> dict[str, object]:
	return {
		"writes": {
			"ids": [
				{"id": id_, "type": type_, "value": value}
				for id_, type_, value in (_parse_entry(e) for e in entries)
			],
		}
	}


def _build_publish_payload(entries: Iterable[str]) -> dict[str, object]:
	return {
		"publishes": {
			"ids": [
				{"id": id_, "type": type_, "value": value}
				for id_, type_, value in (_parse_entry(e) for e in entries)
			],
		}
	}


def _build_read_payload(ids: Iterable[str]) -> dict[str, object]:
	return {
		"reads": {
			"ids": list(ids),
		}
	}


def main() -> int:
	args = _build_parser().parse_args()

	if args.command == "write":
		payload = _build_write_payload(args.entries)
		_send_json_message(args.host, args.port, payload)
		print(f"Sent write request for {len(args.entries)} ID(s)")
		return 0

	if args.command == "publish":
		payload = _build_publish_payload(args.entries)
		_send_json_message(args.host, args.port, payload)
		print(f"Sent publish request for {len(args.entries)} ID(s)")
		return 0

	if args.command == "read":
		payload = _build_read_payload(args.ids)
		_send_json_message(args.host, args.port, payload)
		print(f"Sent read request for {len(args.ids)} ID(s)")
		return 0

	raise AssertionError(f"Unsupported command: {args.command}")


if __name__ == "__main__":
	raise SystemExit(main())
