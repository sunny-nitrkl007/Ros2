/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Parameter Writer class for requesting parameter writes via Middleware

#pragma once

#include <SharkConfiguration.pb.h>
#include <IWriteParameter.h>
#include <Utilities/nice_ptr.h>
#include <memory>
#include <string>

namespace middleware
{
namespace parameter
{
class IService;
class IConfigBuilder;
}
}

namespace JawsSubscriber
{
struct WriteRequest;

class ParameterWriter final
{
public:
	ParameterWriter(cat::shark::Config const& config);
	~ParameterWriter();

	void Initialize();
	void WriteOnce(WriteRequest const& writeRequest);
private:
	std::unique_ptr<middleware::parameter::IConfigBuilder> CreateConfiguration();
	void PopulateWriterNames();
	void OnWriteResult(
		std::string const& parameterName,
		middleware::parameter::IWrite::WriteStatus writeStatus,
		cat::middleware::parameter::Parameter const& parameter);

	cat::shark::Config const& m_config;
	std::unique_ptr<middleware::parameter::IService> m_spParameterService{};
	std::unordered_map<std::string, Utilities::nice_ptr<middleware::parameter::IWrite>> m_writers{};
	std::vector<std::string> m_writerNames{};
};
}
