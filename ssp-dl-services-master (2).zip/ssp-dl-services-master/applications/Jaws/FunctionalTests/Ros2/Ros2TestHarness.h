/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Common test harness for the Jaws ROS2 functional tests. Builds the JawsNode
/// dependency graph from a supplied Shark configuration and exposes the
/// retriever mocks that derived harnesses need to wire up.

#pragma once

#include "Ros2/JawsNode.h"
#include <memory>

namespace cat::shark { class Config; }
namespace Shark::Mocks
{
class MockISharkByteRetriever;
class MockIWriteSharkByteRetriever;
}

namespace Jaws::Ros2
{
class JawsNode;

class Ros2TestHarness
{
public:
	explicit Ros2TestHarness(cat::shark::Config config);
	virtual ~Ros2TestHarness();

	std::shared_ptr<JawsNode> CreateNode();
protected:
	Shark::Mocks::MockISharkByteRetriever& SharkByteRetriever();
	Shark::Mocks::MockIWriteSharkByteRetriever& WriteSharkByteRetriever();
private:
	// Follow the pimpl pattern to reduce header dependencies for the tests
	struct Impl;
	std::unique_ptr<Impl> const m_spImpl;
};
}
