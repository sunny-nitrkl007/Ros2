/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Ros2 PID Parameter Write Service functional tests

#include "Ros2TestHarness.h"
#include "SimpleSharkConfigBuilder.h"
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <rtest/service_mock.hpp>

using namespace ::testing;
using WriteParameter = data_link_engine_interfaces::srv::WriteParameter;
using Parameter = data_link_engine_interfaces::msg::Parameter;
using ParameterValue = data_link_engine_interfaces::msg::ParameterValue;
using ParameterServiceResult = data_link_engine_interfaces::msg::ParameterServiceResult;

namespace Jaws
{
namespace Ros2
{
namespace
{
template <typename T>
struct TestData
{
	char const* pSharkByteId;
	T requestValue;
	std::array<uint8_t, 4> expectedEncodedBytes;
	Config::PidIdentifierEntry entry;

	constexpr std::span<uint8_t const> ExpectedEncodedBytes() const
	{
		return {expectedEncodedBytes.data(), entry.byteCount};
	}
	std::shared_ptr<WriteParameter::Request> MakeRequest() const
	{
		auto spRequest = std::make_shared<WriteParameter::Request>();
		if constexpr (std::is_same_v<T, double>)
		{
			spRequest->value.type = ParameterValue::TYPE_DOUBLE;
			spRequest->value.double_value = requestValue;
		}
		else if constexpr (std::is_same_v<T, uint64_t>)
		{
			spRequest->value.type = ParameterValue::TYPE_UINT64;
			spRequest->value.uint64_value = requestValue;
		}
		else if constexpr (std::is_same_v<T, std::vector<uint8_t>>)
		{
			spRequest->value.type = ParameterValue::TYPE_BINARY;
			spRequest->value.binary_value = requestValue;
		}
		return spRequest;
	}
};
constexpr TestData<double> n_doubleTestData
{
	"double",
	8.0,
	{0x10, 0x00},
	{
		0x0040,
		2,
		Config::Unsigned,
		Config::LsbFirst,
		Config::None,
		0.5,
		cat::shark::UNIT_RPM,
		cat::shark::DATA_PRESENTATION_TYPE_DOUBLE,
	}
};
constexpr TestData<uint64_t> n_uintTestData
{
	"unsigned",
	32,
	{0x00, 0x00, 0x00, 0x10},
	{
		0x0054,
		4,
		Config::Unsigned,
		Config::MsbFirst,
		Config::None,
		2.0,
		cat::shark::UNIT_KPA,
		cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED,
	}
};

const TestData<std::vector<uint8_t>> n_binaryTestData
{
	"binary",
	{0xAA, 0xBB, 0xCC},
	{0xAA, 0xBB, 0xCC},
	{
		0x0060,
		3,
		Config::Unsigned,
		Config::LsbFirst,
		Config::None,
		1.0,
		cat::shark::UNIT_NONE,
		cat::shark::DATA_PRESENTATION_TYPE_BINARY,
	}
};
cat::shark::Config BuildConfig()
{
	// PIDs must be sorted ascending by pid value.
	Config::BasicReadWritePidEntry const basicReadWritePids[]
	{
		{n_doubleTestData.entry.pid, n_doubleTestData.pSharkByteId},
		{n_uintTestData.entry.pid,   n_uintTestData.pSharkByteId},
		{n_binaryTestData.entry.pid, n_binaryTestData.pSharkByteId},
	};
	Config::PidIdentifierEntry const pidIdentifierEntries[]
	{
		n_doubleTestData.entry,
		n_uintTestData.entry,
		n_binaryTestData.entry,
	};
	Config::PidIdentifierConfig const pidConfig{{pidIdentifierEntries, std::size(pidIdentifierEntries)}};

	Shark::SimpleSharkConfigBuilder builder{};
	builder.UsingJ1939DataLink(Config::Can0)
		.UsingPeerNode(0x26)
		.WithBasicReadWriteConfig({basicReadWritePids, std::size(basicReadWritePids)});
	return builder.WithPidConfig(pidConfig).Build();
}
}

class Ros2PidParameterWriteServiceHarness : public Ros2TestHarness
{
public:
	Ros2PidParameterWriteServiceHarness()
		: Ros2TestHarness{BuildConfig()}
	{
		ON_CALL(WriteSharkByteRetriever(), Retrieve(n_doubleTestData.pSharkByteId))
			.WillByDefault(ReturnRef(m_mockDoubleWriteSharkByte));
		ON_CALL(WriteSharkByteRetriever(), Retrieve(n_uintTestData.pSharkByteId))
			.WillByDefault(ReturnRef(m_mockUintWriteSharkByte));
		ON_CALL(WriteSharkByteRetriever(), Retrieve(n_binaryTestData.pSharkByteId))
			.WillByDefault(ReturnRef(m_mockBinaryWriteSharkByte));

		// Each test exercises a single PID, so all three mocks write to the same capture
		// members — whichever fires is the one the test cares about.
		for (auto& mockWriteSharkByte : {&m_mockDoubleWriteSharkByte, &m_mockUintWriteSharkByte, &m_mockBinaryWriteSharkByte})
		{
			ON_CALL(*mockWriteSharkByte, Write(_, _))
				.WillByDefault(DoAll(SaveArg<0>(&m_actualWrittenBytes), SaveArg<1>(&m_actualWriteCompleteCallback)));
		}

		m_spNode = CreateNode();
	}
	template <typename T>
	void InitiateWriteRequest(TestData<T> const& testData)
	{
		auto spService = FindWriteService(testData.pSharkByteId);
		CallHandleRequest(spService, testData.MakeRequest());
	}
	std::shared_ptr<rtest::ServiceMock<WriteParameter>> FindWriteService(std::string const& serviceName)
	{
		auto const spMockService = rtest::findService<WriteParameter>(m_spNode, serviceName);
		if (!spMockService)
		{
			throw std::runtime_error("Failed to find write service: " + serviceName);
		}

		// We use EXPECT_CALL here to avoid the "uninteresting mock function call" warnings that
		// would occur in tests that don't set send_response expectations. There is no way to tell
		// rtest to utilize NiceMock for its mocks, unfortunately.
		EXPECT_CALL(*spMockService, send_response(_, _))
			.Times(AnyNumber())
			.WillRepeatedly(SaveArg<1>(&m_actualResponse));

		m_mockServices.emplace_back(spMockService);
		return m_mockServices.back();
	}
	void CallHandleRequest(
		std::shared_ptr<rtest::ServiceMock<WriteParameter>> const& spService,
		std::shared_ptr<WriteParameter::Request> const& spRequest)
	{
		spService->handle_request(
			std::make_shared<rmw_request_id_t>(),
			spRequest);
	}
	// Simulates the data link reporting completion by echoing back the bytes that
	// were written, which the service decodes into the response.
	void CallWriteCompleteCallback()
	{
		ASSERT_THAT(m_actualWriteCompleteCallback, NotNull());
		m_actualWriteCompleteCallback(Shark::SharkByteValue{m_actualWrittenBytes});
	}
	Shark::Mocks::MockIWriteSharkByte& UnsignedWriteSharkByte() { return m_mockUintWriteSharkByte; }
	WriteParameter::Response const& ActualResponse() const { return m_actualResponse; }
	std::vector<uint8_t> const& ActualWrittenBytes() const { return m_actualWrittenBytes; }
private:
	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockDoubleWriteSharkByte{};
	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockUintWriteSharkByte{};
	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockBinaryWriteSharkByte{};

	std::vector<std::shared_ptr<rtest::ServiceMock<WriteParameter>>> m_mockServices{}; // Keep the service mocks alive
	WriteParameter::Response m_actualResponse{};
	std::vector<uint8_t> m_actualWrittenBytes{};
	Shark::IWriteSharkByte::CompletedCallback m_actualWriteCompleteCallback{};
	std::shared_ptr<JawsNode> m_spNode{};
};

class Ros2PidParameterWriteServiceFunctionalTest : public Test
{
protected:
	Ros2PidParameterWriteServiceHarness m_harness{};
};
TEST_F(Ros2PidParameterWriteServiceFunctionalTest, DoubleWrite_EncodesScaledLsbBytesToTheDataLink)
{
	// Given: Jaws is configured with a scaled, LSB-first double PID
	//  When: A double write request is handled
	//  Then: The scaled value is encoded LSB-first to the data link

	m_harness.InitiateWriteRequest(n_doubleTestData);
	EXPECT_THAT(m_harness.ActualWrittenBytes(), ElementsAreArray(n_doubleTestData.ExpectedEncodedBytes()));
}
TEST_F(Ros2PidParameterWriteServiceFunctionalTest, DoubleWrite_OnCompletion_RespondsSuccessWithScaledDoubleValueAndUnit)
{
	// Given: A double write request has been handled
	//  When: The data link reports the write completed
	//  Then: The service responds success with the scaled double value and unit

	m_harness.InitiateWriteRequest(n_doubleTestData);
	m_harness.CallWriteCompleteCallback();

	EXPECT_THAT(m_harness.ActualResponse().result.status, Eq(ParameterServiceResult::STATUS_SUCCESS));
	auto const& parameter = m_harness.ActualResponse().result.parameter;
	EXPECT_THAT(parameter.quality, Eq(Parameter::QUALITY_GOOD));
	EXPECT_THAT(parameter.value.type, Eq(ParameterValue::TYPE_DOUBLE));
	EXPECT_THAT(parameter.value.double_value, DoubleEq(n_doubleTestData.requestValue));
	EXPECT_THAT(parameter.unit, Eq(std::to_underlying(n_doubleTestData.entry.unit)));
}
TEST_F(Ros2PidParameterWriteServiceFunctionalTest, UintWrite_EncodesScaledMsbBytesToTheDataLink)
{
	// Given: Jaws is configured with a scaled, MSB-first unsigned PID
	//  When: An unsigned write request is handled
	//  Then: The scaled value is encoded MSB-first to the data link

	m_harness.InitiateWriteRequest(n_uintTestData);
	EXPECT_THAT(m_harness.ActualWrittenBytes(), ElementsAreArray(n_uintTestData.ExpectedEncodedBytes()));
}
TEST_F(Ros2PidParameterWriteServiceFunctionalTest, UintWrite_OnCompletion_RespondsSuccessWithScaledUintValueAndUnit)
{
	// Given: An unsigned write request has been handled
	//  When: The data link reports the write completed
	//  Then: The service responds success with the scaled unsigned value and unit

	m_harness.InitiateWriteRequest(n_uintTestData);
	m_harness.CallWriteCompleteCallback();

	EXPECT_THAT(m_harness.ActualResponse().result.status, Eq(ParameterServiceResult::STATUS_SUCCESS));
	auto const& parameter = m_harness.ActualResponse().result.parameter;
	EXPECT_THAT(parameter.quality, Eq(Parameter::QUALITY_GOOD));
	EXPECT_THAT(parameter.value.type, Eq(ParameterValue::TYPE_UINT64));
	EXPECT_THAT(parameter.value.uint64_value, Eq(n_uintTestData.requestValue));
	EXPECT_THAT(parameter.unit, Eq(std::to_underlying(n_uintTestData.entry.unit)));
}
TEST_F(Ros2PidParameterWriteServiceFunctionalTest, BinaryWrite_PassesRawBytesToTheDataLink)
{
	// Given: Jaws is configured with a binary PID
	//  When: A binary write request is handled
	//  Then: The raw bytes are passed unchanged to the data link

	m_harness.InitiateWriteRequest(n_binaryTestData);
	EXPECT_THAT(m_harness.ActualWrittenBytes(), ElementsAreArray(n_binaryTestData.ExpectedEncodedBytes()));
}
TEST_F(Ros2PidParameterWriteServiceFunctionalTest, BinaryWrite_OnCompletion_RespondsSuccessWithBinaryValue)
{
	// Given: A binary write request has been handled
	//  When: The data link reports the write completed
	//  Then: The service responds success with the binary value

	m_harness.InitiateWriteRequest(n_binaryTestData);
	m_harness.CallWriteCompleteCallback();

	EXPECT_THAT(m_harness.ActualResponse().result.status, Eq(ParameterServiceResult::STATUS_SUCCESS));
	auto const& parameter = m_harness.ActualResponse().result.parameter;
	EXPECT_THAT(parameter.quality, Eq(Parameter::QUALITY_GOOD));
	EXPECT_THAT(parameter.value.type, Eq(ParameterValue::TYPE_BINARY));
	EXPECT_THAT(parameter.value.binary_value, ElementsAreArray(n_binaryTestData.requestValue));
}
TEST_F(Ros2PidParameterWriteServiceFunctionalTest, Write_WithTypeNotMatchingPidDefinition_DoesNotWriteToTheDataLink)
{
	// Given: A write service for an unsigned PID
	//  When: A double-typed value is written to the unsigned PID
	//  Then: Nothing is written to the data link

	auto const spService = m_harness.FindWriteService(n_uintTestData.pSharkByteId);
	EXPECT_CALL(m_harness.UnsignedWriteSharkByte(), Write(_, _)).Times(0);

	m_harness.CallHandleRequest(spService, n_doubleTestData.MakeRequest());
}
TEST_F(Ros2PidParameterWriteServiceFunctionalTest, Write_WithTypeNotMatchingPidDefinition_RespondsFailureWithProtocolError)
{
	// Given: A write service for an unsigned PID
	//  When: A double-typed value is written to the unsigned PID
	//  Then: The service responds failure with a protocol error

	auto const spService = m_harness.FindWriteService(n_uintTestData.pSharkByteId);
	m_harness.CallHandleRequest(spService, n_doubleTestData.MakeRequest());

	auto const& actualResult = m_harness.ActualResponse().result;
	EXPECT_THAT(actualResult.status, Eq(ParameterServiceResult::STATUS_FAILURE));
	EXPECT_THAT(actualResult.reason, Eq(ParameterServiceResult::REASON_PROTOCOL_ERROR));
}
TEST_F(Ros2PidParameterWriteServiceFunctionalTest, BinaryWrite_WithIncorrectLength_RespondsFailureWithProtocolError)
{
	// Given: A write service for a binary PID
	//  When: A binary value one byte short of the configured length is written
	//  Then: The service responds failure with a protocol error

	auto const spService = m_harness.FindWriteService(n_binaryTestData.pSharkByteId);

	// One byte short of the configured byte count, so encoding fails.
	auto const spRequest = n_binaryTestData.MakeRequest();
	spRequest->value.binary_value.pop_back();
	m_harness.CallHandleRequest(spService, spRequest);

	auto const& actualResult = m_harness.ActualResponse().result;
	EXPECT_THAT(actualResult.status, Eq(ParameterServiceResult::STATUS_FAILURE));
	EXPECT_THAT(actualResult.reason, Eq(ParameterServiceResult::REASON_PROTOCOL_ERROR));
}
}
}

