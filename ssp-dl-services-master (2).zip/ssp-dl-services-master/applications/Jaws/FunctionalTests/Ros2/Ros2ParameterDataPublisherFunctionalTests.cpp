/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// ROS2 Parameter Data Publisher functional tests

#include "Ros2TestHarness.h"
#include "SimpleSharkConfigBuilder.h"
#include <Shark/Mocks/MockISharkByte.h>
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <rtest/publisher_mock.hpp>

using namespace ::testing;
using Parameter = data_link_engine_interfaces::msg::Parameter;
using ParameterValue = data_link_engine_interfaces::msg::ParameterValue;

namespace Jaws
{
namespace Ros2
{
namespace
{
struct Adt
{
	static constexpr unsigned Pid() { return 0x0040; }
	static constexpr char const* MiddlewareId() { return "Engine.Speed"; }
	static constexpr char const* TopicName() { return "/data_link_engine/Engine_Speed"; }
	static constexpr cat::shark::Unit Unit() { return cat::shark::UNIT_RPM; }
};

struct Pgb
{
	static constexpr unsigned Pid() { return 0x0054; }
	static constexpr char const* MiddlewareId() { return "Engine.Pressure"; }
	static constexpr char const* TopicName() { return "/data_link_engine/Engine_Pressure"; }
	static constexpr cat::shark::Unit Unit() { return cat::shark::UNIT_KPA; }
};

cat::shark::Config BuildConfig()
{
	constexpr Config::AdtPidEntry adtPidEntry{Adt::Pid(), Adt::MiddlewareId()};
	Config::AdtEntry const adtEntry{std::nullopt, {&adtPidEntry, 1}};
	Config::PgbPidEntry const pgbPidEntry{
		Pgb::Pid(),
		cat::shark::J1939DataLink::PeerNode::Pgb::REQUEST_RATE_100,
		true,
		Pgb::MiddlewareId()};
	Config::PidIdentifierEntry const pidIdentifierEntries[]{
		{
			Adt::Pid(),
			2,
			Config::Unsigned,
			Config::LsbFirst,
			Config::None,
			0.5,
			Adt::Unit(),
			cat::shark::DATA_PRESENTATION_TYPE_DOUBLE,
		},
		{
			Pgb::Pid(),
			4,
			Config::Unsigned,
			Config::MsbFirst,
			Config::None,
			2.0,
			Pgb::Unit(),
			cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED,
		},
	};
	Config::PidIdentifierConfig const pidConfig{{pidIdentifierEntries, std::size(pidIdentifierEntries)}};

	Shark::SimpleSharkConfigBuilder builder{};
	builder.UsingJ1939DataLink(Config::Can0)
		.UsingPeerNode(0x26)
		.WithAdtConfig(adtEntry)
		.WithPgbConfig({&pgbPidEntry, 1});
	return builder.WithPidConfig(pidConfig).Build();
}
}

class Ros2ParameterDataPublisherHarness : public Ros2TestHarness
{
public:
	Ros2ParameterDataPublisherHarness()
		: Ros2TestHarness{BuildConfig()}
	{
		ON_CALL(SharkByteRetriever(), Retrieve(Adt::MiddlewareId()))
			.WillByDefault(ReturnRef(m_adtSharkByteWrapper.GetMock()));
		ON_CALL(SharkByteRetriever(), Retrieve(Pgb::MiddlewareId()))
			.WillByDefault(ReturnRef(m_pgbSharkByteWrapper.GetMock()));
	}
	std::shared_ptr<rtest::PublisherMock<Parameter>> FindPublisher(
		std::shared_ptr<JawsNode> const& spNode,
		char const* pTopicName)
	{
		auto const spMockPublisher = rtest::findPublisher<Parameter>(spNode, pTopicName);
		if (!spMockPublisher)
		{
			throw std::runtime_error("Failed to find publisher for topic: " + std::string(pTopicName));
		}

		// We use EXPECT_CALL here to avoid the "uninteresting mock function call" warnings that
		// would occur in tests that don't set publish expectations. There is no way to tell rtest
		// to utilize NiceMock for its mocks, unfortunately.
		EXPECT_CALL(*spMockPublisher, publish(_))
			.Times(AnyNumber())
			.WillRepeatedly(SaveArg<0>(&m_actualMessage));

		m_mockPublishers.emplace_back(spMockPublisher);

		return m_mockPublishers.back();
	}
	Shark::Mocks::MockSharkByteWrapper& AdtSharkByteWrapper() { return m_adtSharkByteWrapper; }
	Shark::Mocks::MockSharkByteWrapper& PgbSharkByteWrapper() { return m_pgbSharkByteWrapper; }
	Parameter const& ActualMessage() const { return m_actualMessage; }
private:
	Shark::Mocks::MockSharkByteWrapper m_adtSharkByteWrapper{};
	Shark::Mocks::MockSharkByteWrapper m_pgbSharkByteWrapper{};
	std::vector<std::shared_ptr<rtest::PublisherMock<Parameter>>> m_mockPublishers{}; // Keep the publisher mocks alive
	Parameter m_actualMessage{};
};

class Ros2ParameterDataPublisherFunctionalTest : public Test
{
protected:
	Ros2ParameterDataPublisherHarness m_harness{};
};
TEST_F(Ros2ParameterDataPublisherFunctionalTest, JawsNodeCreatesPublisherForEachAdtAndPgbPid)
{
	// Given: Jaws is configured with an ADT PID and a PGB PID
	//  When: The JawsNode is created
	//  Then: A publisher exists for each PID's topic

	auto const spNode = m_harness.CreateNode();

	EXPECT_THAT(m_harness.FindPublisher(spNode, Adt::TopicName()), NotNull());
	EXPECT_THAT(m_harness.FindPublisher(spNode, Pgb::TopicName()), NotNull());
}
TEST_F(Ros2ParameterDataPublisherFunctionalTest, JawsNodePublishesAdtPidValue)
{
	// Given: The JawsNode is created and the ADT PID's publisher has been found
	//  When: The ADT SharkByte value changes
	//  Then: The scaled double value and unit are published with good quality

	auto const spNode = m_harness.CreateNode();
	m_harness.FindPublisher(spNode, Adt::TopicName());

	m_harness.AdtSharkByteWrapper().SetValue(Shark::SharkByteValue{{0x10, 0x00}});

	auto const& actualMessage = m_harness.ActualMessage();
	EXPECT_THAT(actualMessage.quality, Eq(Parameter::QUALITY_GOOD));
	EXPECT_THAT(actualMessage.value.type, Eq(ParameterValue::TYPE_DOUBLE));
	EXPECT_THAT(actualMessage.value.double_value, DoubleEq(8.0));
	EXPECT_THAT(actualMessage.unit, Eq(Adt::Unit()));
}
TEST_F(Ros2ParameterDataPublisherFunctionalTest, JawsNodePublishesPgbPidValue)
{
	// Given: The JawsNode is created and the PGB PID's publisher has been found
	//  When: The PGB SharkByte value changes
	//  Then: The scaled unsigned value and unit are published with good quality

	auto const spNode = m_harness.CreateNode();
	m_harness.FindPublisher(spNode, Pgb::TopicName());

	m_harness.PgbSharkByteWrapper().SetValue(Shark::SharkByteValue{{0x00, 0x00, 0x00, 0x10}});

	auto const& actualMessage = m_harness.ActualMessage();
	EXPECT_THAT(actualMessage.quality, Eq(Parameter::QUALITY_GOOD));
	EXPECT_THAT(actualMessage.value.type, Eq(ParameterValue::TYPE_UINT64));
	EXPECT_THAT(actualMessage.value.uint64_value, Eq(32));
	EXPECT_THAT(actualMessage.unit, Eq(Pgb::Unit()));
}
}
}