/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Ros2TestHarness.h

#include "Ros2TestHarness.h"
#include "DependencyContainer.h"
#include "Identifiers/PidDefinitionRetriever.h"
#include "Identifiers/PidValueDecoder.h"
#include "Identifiers/PidValueEncoder.h"
#include "Nvm/MockINvmWrapper.h"
#include "Ros2/JawsNode.h"
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Utilities/Mocks/MockIEnvironment.h>
#include <Utilities/Mocks/MockIFilesystem.h>
#include <SharkConfiguration.pb.h>
#include <utility>

namespace Jaws
{
namespace Ros2
{
struct Ros2TestHarness::Impl
{
	explicit Impl(cat::shark::Config config)
		: m_config{std::move(config)}
		, m_pidDefinitionRetriever{m_config.pid_entries(), m_config.multi_byte_pid_entries()}
		, m_dependencyContainer{
			m_config,
			m_mockEnvironment,
			m_mockFilesystem,
			m_pidDefinitionRetriever,
			m_pidValueDecoder,
			m_pidValueEncoder,
			m_mockSharkByteRetriever,
			m_mockWriteSharkByteRetriever,
			m_mockNvmWrapper}
	{
	}

	cat::shark::Config const m_config;
	Identifiers::PidDefinitionRetriever const m_pidDefinitionRetriever;
	Identifiers::PidValueDecoder const m_pidValueDecoder{};
	Identifiers::PidValueEncoder const m_pidValueEncoder{};
	testing::NiceMock<Utilities::Mocks::MockIEnvironment> m_mockEnvironment{};
	testing::NiceMock<Utilities::Mocks::MockIFilesystem> m_mockFilesystem{};
	testing::NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	testing::NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	testing::NiceMock<Nvm::MockINvmWrapper> m_mockNvmWrapper{};
	DependencyContainer const m_dependencyContainer;
};

Ros2TestHarness::Ros2TestHarness(cat::shark::Config config)
	: m_spImpl{std::make_unique<Impl>(std::move(config))}
{
}
Ros2TestHarness::~Ros2TestHarness() = default;
std::shared_ptr<JawsNode> Ros2TestHarness::CreateNode()
{
	return JawsNode::Create(m_spImpl->m_dependencyContainer);
}
Shark::Mocks::MockISharkByteRetriever& Ros2TestHarness::SharkByteRetriever()
{
	return m_spImpl->m_mockSharkByteRetriever;
}
Shark::Mocks::MockIWriteSharkByteRetriever& Ros2TestHarness::WriteSharkByteRetriever()
{
	return m_spImpl->m_mockWriteSharkByteRetriever;
}
}
}
