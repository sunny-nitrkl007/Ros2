/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PidParameterDataWriter functional tests

#include "FakeConfigBuilder.h"
#include "DependencyContainer.h"
#include "Identifiers/MockIPidDefinitionRetriever.h"
#include "Identifiers/MockIPublicJ1939DefinitionRetriever.h"
#include "Identifiers/PidValueDecoder.h"
#include "Identifiers/PidValueEncoder.h"
#include "InitializationGate.h"
#include "JawsManager.h"
#include "Middleware/InitializationGatingConfigBuilder.h"
#include "Middleware/MockIService.h"
#include "Middleware/ParameterWrapper.h"
#include "Middleware/SharkToMiddlewareDefinitions.h"
#include "Nvm/MockINvmWrapper.h"
#include <Shark/Mocks/MockIShark.h>
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Utilities/Mocks/MockIEnvironment.h>
#include <Utilities/Mocks/MockIFilesystem.h>
#include <optional>

using namespace testing;
using namespace middleware::parameter;

namespace Shark
{
// TODO: A LOT of the code in this file should be moved to other common files as more functional tests are written.

std::unique_ptr<IShark> CreateShark(Utilities::IEnvironment const&, cat::shark::Config const&)
{
	assert(false); // Only JawsManager::Create() creates a real Shark, so this function should not be called in functional tests.
	return nullptr;
}
}

namespace Jaws
{
namespace Middleware
{

class PidParameterDataWriterFunctionalTests : public Test
{
protected:
	struct Default
	{
		static constexpr auto MiddlewareId() { return "test_write_id"; }
		static constexpr unsigned Pid() { return 0x00FC42u; }
		static constexpr unsigned ByteCount() { return 2; }
		static constexpr char ByteValue() { return 0x37; }
		static constexpr uint_least16_t WriteKey() { return 42; }
	};

	PidParameterDataWriterFunctionalTests()
		: m_spDependencyContainer{std::make_unique<DependencyContainer>(
			m_sharkConfig,
			m_mockEnvironment,
			m_mockFilesystem,
			m_mockPidDefinitionRetriever,
			m_mockPublicJ1939DefinitionRetriever,
			m_pidValueDecoder,
			m_pidValueEncoder,
			m_mockSharkByteRetriever,
			m_mockWriteSharkByteRetriever,
			m_mockNvmWrapper,
			m_initializationGate,
			m_sharkToMiddlewareDefinitions)}
	{
		auto* pJ1939DataLink = m_sharkConfig.add_j1939_data_links();
		auto* pPeerNode = pJ1939DataLink->add_peer_nodes();
		auto* pBasicReadWrite = pPeerNode->mutable_basic_read_write();
		auto* pEntry = pBasicReadWrite->add_basic_read_write_pids();
		pEntry->set_pid(Default::Pid());
		pEntry->set_middleware_id(Default::MiddlewareId());

		auto* pPidEntry = m_sharkConfig.add_pid_entries();
		pPidEntry->set_pid(Default::Pid());
		pPidEntry->set_byte_count(Default::ByteCount());
		pPidEntry->set_scaling(1.0);
		pPidEntry->set_unit(cat::shark::UNIT_NONE);
		pPidEntry->set_is_lsb(true);
		pPidEntry->set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_BINARY);

		ON_CALL(m_mockWriteSharkByteRetriever, Retrieve(Default::MiddlewareId()))
			.WillByDefault(ReturnRef(m_mockWriteSharkByte));
		ON_CALL(m_mockPidDefinitionRetriever, RetrievePid(Config::Pid{Default::Pid()}))
			.WillByDefault(Return(Identifiers::PidDefinition{m_sharkConfig.pid_entries(0)}));
	}

	cat::middleware::parameter::Data MakeValidBinaryWriteData()
	{
		cat::middleware::parameter::Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_binary_value(std::string(Default::ByteCount(), Default::ByteValue()));
		return data;
	}

	std::unique_ptr<JawsManager> CreateJawsManager(std::vector<std::function<void()>>&& initializers)
	{
		return std::make_unique<JawsManager>(
			std::make_unique<NiceMock<Shark::Mocks::MockIShark>>(),
			std::make_unique<cat::shark::Config>(),
			std::make_unique<NiceMock<Nvm::MockINvmWrapper>>(),
			std::make_unique<NiceMock<Identifiers::MockIPidDefinitionRetriever>>(),
			nullptr, // The IPidValueDecoder is only passed in for lifetime. Not needed here.
			nullptr, // The IPidValueEncoder is only passed in for lifetime. Not needed here.
			std::make_unique<NiceMock<Identifiers::MockIPublicJ1939DefinitionRetriever>>(),
			nullptr, // The IInitializationGate is only passed in for lifetime. Not needed here.
			m_spDependencyContainer.TakeUniquePtr(),
			std::move(initializers));
	}

	cat::shark::Config m_sharkConfig{};
	NiceMock<Utilities::Mocks::MockIEnvironment> m_mockEnvironment{};
	NiceMock<Utilities::Mocks::MockIFilesystem> m_mockFilesystem{};
	NiceMock<Identifiers::MockIPidDefinitionRetriever> m_mockPidDefinitionRetriever{};
	NiceMock<Identifiers::MockIPublicJ1939DefinitionRetriever> m_mockPublicJ1939DefinitionRetriever{};
	Identifiers::PidValueDecoder m_pidValueDecoder{};
	Identifiers::PidValueEncoder m_pidValueEncoder{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<Nvm::MockINvmWrapper> m_mockNvmWrapper{};
	SharkToMiddlewareDefinitions m_sharkToMiddlewareDefinitions{};
	InitializationGate m_initializationGate{};
	Utilities::TestUniquePtr<DependencyContainer> m_spDependencyContainer;

	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockWriteSharkByte{};
	Utilities::DefaultTestUniquePtr<NiceMock<MockIService>> m_spMockService{};

	FunctionalTests::FakeConfigBuilder& MakeFakeConfigBuilder()
	{
		auto spFakeConfigBuilder = std::make_unique<FunctionalTests::FakeConfigBuilder>();
		auto& fakeConfigBuilder = *spFakeConfigBuilder;
		m_gatingConfigBuilder.emplace(std::move(spFakeConfigBuilder), m_initializationGate);
		return fakeConfigBuilder;
	}

	void InitializeJaws(ServiceFactory serviceFactory)
	{
		auto parameterInitializers = ParameterWrapper::CreateParameterInitializers(
			*m_spDependencyContainer,
			*m_gatingConfigBuilder);

		auto spParameterWrapper = std::make_shared<ParameterWrapper>(
			std::move(serviceFactory),
			std::move(parameterInitializers),
			*m_gatingConfigBuilder);

		std::vector<std::function<void()>> initializers{};
		initializers.push_back([spParameterWrapper]()
			{
				spParameterWrapper->Initialize();
			});

		m_spJawsManager = CreateJawsManager(std::move(initializers));
		m_spJawsManager->Initialize();
	}

	void InitializeJaws()
	{
		InitializeJaws([this]() { return m_spMockService.TakeUniquePtr(); });
	}

private:
	std::optional<InitializationGatingConfigBuilder> m_gatingConfigBuilder{};
	std::unique_ptr<JawsManager> m_spJawsManager{};
};
TEST_F(PidParameterDataWriterFunctionalTests, WritesSendSharkResponseThroughMiddlewareAsAReplyAsynchronously)
{
	// Given: Jaws is configured with a basic read/write PID entry and initialized
	//  When: The PID middleware write callback is invoked
	//  Then: The SharkByte write is called and nullopt is returned (async)
	//  When: The SharkByte write completes
	//  Then: The response is sent as a middleware reply

	auto& fakeConfigBuilder = MakeFakeConfigBuilder();
	InitializeJaws();

	Shark::IWriteSharkByte::CompletedCallback actualWriteSharkByteCallback{};
	std::vector<uint8_t> const expectedSharkByteWriteBytes(Default::ByteCount(), Default::ByteValue());
	EXPECT_CALL(m_mockWriteSharkByte, Write(ContainerEq(expectedSharkByteWriteBytes), _))
		.WillOnce(SaveArg<1>(&actualWriteSharkByteCallback));

	auto const& actualMiddlewareWriteCompletionCallback = fakeConfigBuilder.GetServerWriteCallback(Default::MiddlewareId());
	auto const writeData = MakeValidBinaryWriteData();
	ASSERT_THAT(actualMiddlewareWriteCompletionCallback, NotNull());
	auto const result = actualMiddlewareWriteCompletionCallback(Default::WriteKey(), Default::MiddlewareId(), writeData);
	EXPECT_THAT(result, Eq(std::nullopt));

	std::vector<uint8_t> const responseBytes(Default::ByteCount(), Default::ByteValue() + 1);
	Shark::SharkByteValue const responseValue{responseBytes};

	cat::middleware::parameter::Data expectedReply{};
	expectedReply.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedReply.mutable_value()->set_binary_value(responseBytes.data(), responseBytes.size());

	EXPECT_CALL(*m_spMockService, Reply(Default::WriteKey(), Utilities::ProtobufEquals(expectedReply)));

	ASSERT_THAT(actualWriteSharkByteCallback, NotNull());
	actualWriteSharkByteCallback(responseValue);
}
TEST_F(PidParameterDataWriterFunctionalTests, WriteReceivedDuringCreateParameterServiceIsQueuedAndExecutedAfterReady)
{
	// Given: Jaws is configured with a basic read/write PID entry
	//  When: The PID middleware write callback is invoked during service creation
	//  Then: The write is queued
	//  When: Initialization completes
	//  Then: The SharkByte write is called and nullopt is returned (async)
	//  When: The SharkByte write completes
	//  Then: The response is sent as a middleware reply

	auto& fakeConfigBuilder = MakeFakeConfigBuilder();
	auto const writeData = MakeValidBinaryWriteData();

	// Set up expectation for the write that will be queued during service creation
	// and executed when the gate drains during SetReady.
	Shark::IWriteSharkByte::CompletedCallback actualWriteSharkByteCallback{};
	std::vector<uint8_t> const expectedSharkByteWriteBytes(Default::ByteCount(), Default::ByteValue());
	EXPECT_CALL(m_mockWriteSharkByte, Write(ContainerEq(expectedSharkByteWriteBytes), _))
		.WillOnce(SaveArg<1>(&actualWriteSharkByteCallback));

	// The ServiceFactory simulates CreateParameterService. During real service
	// creation, FastDDS discovers remote writers and could fire callbacks on
	// receiver threads. We simulate this by invoking the write callback here.
	// The gate is not yet ready, so the callback returns nullopt and queues
	// the real work for later.
	InitializeJaws([this, &fakeConfigBuilder, &writeData]()
	{
		auto const& gatedCallback = fakeConfigBuilder.GetServerWriteCallback(Default::MiddlewareId());
		auto const result = gatedCallback(Default::WriteKey(), Default::MiddlewareId(), writeData);
		EXPECT_THAT(result, Eq(std::nullopt));
		return m_spMockService.TakeUniquePtr();
	});

	ASSERT_THAT(actualWriteSharkByteCallback, NotNull());

	// Complete the async SharkByte write and verify the middleware reply.
	std::vector<uint8_t> const responseBytes(Default::ByteCount(), Default::ByteValue() + 1);
	Shark::SharkByteValue const responseValue{responseBytes};

	cat::middleware::parameter::Data expectedReply{};
	expectedReply.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedReply.mutable_value()->set_binary_value(responseBytes.data(), responseBytes.size());

	EXPECT_CALL(*m_spMockService, Reply(Default::WriteKey(), Utilities::ProtobufEquals(expectedReply)));

	actualWriteSharkByteCallback(responseValue);
}
}
}
