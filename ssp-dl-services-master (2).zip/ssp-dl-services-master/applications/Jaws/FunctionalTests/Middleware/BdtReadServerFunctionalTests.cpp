/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// BDT Read Server functional tests

#include "FakeConfigBuilder.h"
#include "DependencyContainer.h"
#include "Identifiers/MockIPidDefinitionRetriever.h"
#include "Identifiers/MockIPidValueDecoder.h"
#include "Identifiers/MockIPidValueEncoder.h"
#include "Identifiers/MockIPublicJ1939DefinitionRetriever.h"
#include "InitializationGate.h"
#include "JawsManager.h"
#include "Middleware/InitializationGatingConfigBuilder.h"
#include "Middleware/MockIService.h"
#include "Middleware/ParameterWrapper.h"
#include "Middleware/SharkToMiddlewareDefinitions.h"
#include "Nvm/MockINvmWrapper.h"
#include <Shark/Mocks/MockIShark.h>
#include <Shark/Mocks/MockISharkByte.h>
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Utilities/Mocks/MockIEnvironment.h>
#include <Utilities/Mocks/MockIFilesystem.h>
#include <optional>

using namespace testing;
using namespace middleware::parameter;

namespace Jaws
{
namespace Middleware
{
// TODO: A LOT of the code in this file should be moved to other common files as more functional tests are written.

class BdtReadServerFunctionalTests : public Test
{
protected:
	struct Default
	{
		static constexpr auto MiddlewareId() { return "bdt_read_id"; }
		static constexpr uint_least16_t Key() { return 42; }
		static constexpr std::vector<uint8_t> ValidData() { return {0x10, 0x20, 0x30, 0x40}; }
	};

	BdtReadServerFunctionalTests()
		: m_mockSharkByte(Default::ValidData())
		, m_spDependencyContainer{std::make_unique<DependencyContainer>(
			m_sharkConfig,
			m_mockEnvironment,
			m_mockFilesystem,
			m_mockPidDefinitionRetriever,
			m_mockPublicJ1939DefinitionRetriever,
			m_mockPidValueDecoder,
			m_mockPidValueEncoder,
			m_mockSharkByteRetriever,
			m_mockWriteSharkByteRetriever,
			m_mockNvmWrapper,
			m_initializationGate,
			m_sharkToMiddlewareDefinitions)}
	{
		auto* pJ1939DataLink = m_sharkConfig.add_j1939_data_links();
		auto* pPeerNode = pJ1939DataLink->add_peer_nodes();
		auto* pBdt = pPeerNode->mutable_bdt();
		auto* pBdtType = pBdt->add_bdt_types();
		pBdtType->set_type(1);
		pBdtType->set_index(0);
		pBdtType->set_access_mode(cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_READ_ONLY);
		pBdtType->set_middleware_id(Default::MiddlewareId());

		ON_CALL(m_mockSharkByteRetriever, Retrieve(Default::MiddlewareId()))
			.WillByDefault(ReturnRef(m_mockSharkByte.GetMock()));
	}

	FunctionalTests::FakeConfigBuilder& MakeFakeConfigBuilder()
	{
		auto spFakeConfigBuilder = std::make_unique<FunctionalTests::FakeConfigBuilder>();
		auto& fakeConfigBuilder = *spFakeConfigBuilder;
		m_gatingConfigBuilder.emplace(std::move(spFakeConfigBuilder), m_initializationGate);
		return fakeConfigBuilder;
	}

	void InitializeJaws(ServiceFactory serviceFactory)
	{
		auto parameterInitializers = ParameterWrapper::CreateParameterInitializers(
			*m_spDependencyContainer,
			*m_gatingConfigBuilder);

		auto spParameterWrapper = std::make_shared<ParameterWrapper>(
			std::move(serviceFactory),
			std::move(parameterInitializers),
			*m_gatingConfigBuilder);

		std::vector<std::function<void()>> initializers{};
		initializers.push_back([spParameterWrapper]()
			{
				spParameterWrapper->Initialize();
			});

		m_spJawsManager = std::make_unique<JawsManager>(
			std::make_unique<NiceMock<Shark::Mocks::MockIShark>>(),
			std::make_unique<cat::shark::Config>(),
			std::make_unique<NiceMock<Nvm::MockINvmWrapper>>(),
			std::make_unique<NiceMock<Identifiers::MockIPidDefinitionRetriever>>(),
			nullptr, // The IPidValueDecoder is only passed in for lifetime. Not needed here.
			nullptr, // The IPidValueEncoder is only passed in for lifetime. Not needed here.
			std::make_unique<NiceMock<Identifiers::MockIPublicJ1939DefinitionRetriever>>(),
			nullptr,
			m_spDependencyContainer.TakeUniquePtr(),
			std::move(initializers));
		m_spJawsManager->Initialize();
	}

	void InitializeJaws()
	{
		InitializeJaws([this]() { return m_spMockService.TakeUniquePtr(); });
	}

	cat::shark::Config m_sharkConfig{};
	NiceMock<Utilities::Mocks::MockIEnvironment> m_mockEnvironment{};
	NiceMock<Utilities::Mocks::MockIFilesystem> m_mockFilesystem{};
	NiceMock<Identifiers::MockIPidDefinitionRetriever> m_mockPidDefinitionRetriever{};
	NiceMock<Identifiers::MockIPublicJ1939DefinitionRetriever> m_mockPublicJ1939DefinitionRetriever{};
	NiceMock<Identifiers::MockIPidValueDecoder> m_mockPidValueDecoder{};
	NiceMock<Identifiers::MockIPidValueEncoder> m_mockPidValueEncoder{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<Nvm::MockINvmWrapper> m_mockNvmWrapper{};
	SharkToMiddlewareDefinitions m_sharkToMiddlewareDefinitions{};
	InitializationGate m_initializationGate{};
	Shark::Mocks::MockSharkByteWrapper m_mockSharkByte;
	Utilities::TestUniquePtr<DependencyContainer> m_spDependencyContainer;
	Utilities::DefaultTestUniquePtr<NiceMock<MockIService>> m_spMockService{};

private:
	std::optional<InitializationGatingConfigBuilder> m_gatingConfigBuilder{};
	std::unique_ptr<JawsManager> m_spJawsManager{};
};
TEST_F(BdtReadServerFunctionalTests, ReadRefreshesSharkByteAndRepliesWithValueAsynchronously)
{
	// Given: Jaws is configured with a read-only BDT entry and initialized
	//  When: The BDT middleware read occurs
	//  Then: SharkByte::Refresh() is called and nullopt is returned (async)
	//   And: When the SharkByte value changes, the service replies with the BDT data

	auto& fakeConfigBuilder = MakeFakeConfigBuilder();
	InitializeJaws();

	auto const& readCallback = fakeConfigBuilder.GetServerReadCallback(Default::MiddlewareId());
	ASSERT_THAT(readCallback, NotNull());

	EXPECT_CALL(m_mockSharkByte.GetMock(), Refresh());
	auto const result = readCallback(Default::Key(), Default::MiddlewareId());
	EXPECT_THAT(result, Eq(std::nullopt));

	auto const sharkByteData = Default::ValidData();
	cat::middleware::parameter::Data expectedReply{};
	expectedReply.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedReply.mutable_value()->set_binary_value(sharkByteData.data(), sharkByteData.size());

	EXPECT_CALL(*m_spMockService, Reply(Default::Key(), Utilities::ProtobufEquals(expectedReply)));
	m_mockSharkByte.SetValue(sharkByteData);
}
}
}
