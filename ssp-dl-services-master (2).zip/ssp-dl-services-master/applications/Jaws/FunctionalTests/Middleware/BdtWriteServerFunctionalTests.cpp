/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// RawDataWriteServer functional tests

#include "FakeConfigBuilder.h"
#include "DependencyContainer.h"
#include "Identifiers/MockIPidDefinitionRetriever.h"
#include "Identifiers/MockIPidValueDecoder.h"
#include "Identifiers/MockIPidValueEncoder.h"
#include "Identifiers/MockIPublicJ1939DefinitionRetriever.h"
#include "InitializationGate.h"
#include "JawsManager.h"
#include "Middleware/InitializationGatingConfigBuilder.h"
#include "Middleware/MockIService.h"
#include "Middleware/ParameterWrapper.h"
#include "Middleware/SharkToMiddlewareDefinitions.h"
#include "Nvm/MockINvmWrapper.h"
#include <Shark/Mocks/MockIShark.h>
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Utilities/Mocks/MockIEnvironment.h>
#include <Utilities/Mocks/MockIFilesystem.h>
#include <optional>

using namespace testing;
using namespace middleware::parameter;

namespace Jaws
{
namespace Middleware
{

class RawDataWriteServerFunctionalTests : public Test
{
protected:
	struct Default
	{
		static constexpr auto MiddlewareId() { return "bdt_write_id"; }
		static constexpr uint_least16_t WriteKey() { return 42; }
		static constexpr std::vector<uint8_t> ValidData() { return {0x10, 0x20, 0x30, 0x40}; }
	};

	RawDataWriteServerFunctionalTests()
		: m_spDependencyContainer{std::make_unique<DependencyContainer>(
			m_sharkConfig,
			m_mockEnvironment,
			m_mockFilesystem,
			m_mockPidDefinitionRetriever,
			m_mockPublicJ1939DefinitionRetriever,
			m_mockPidValueDecoder,
			m_mockPidValueEncoder,
			m_mockSharkByteRetriever,
			m_mockWriteSharkByteRetriever,
			m_mockNvmWrapper,
			m_initializationGate,
			m_sharkToMiddlewareDefinitions)}
	{
		auto* pJ1939DataLink = m_sharkConfig.add_j1939_data_links();
		auto* pPeerNode = pJ1939DataLink->add_peer_nodes();
		auto* pBdt = pPeerNode->mutable_bdt();
		auto* pBdtType = pBdt->add_bdt_types();
		pBdtType->set_type(1);
		pBdtType->set_index(0);
		pBdtType->set_access_mode(cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_WRITE_ONLY);
		pBdtType->set_middleware_id(Default::MiddlewareId());

		ON_CALL(m_mockWriteSharkByteRetriever, Retrieve(Default::MiddlewareId()))
			.WillByDefault(ReturnRef(m_mockWriteSharkByte));
	}
	cat::middleware::parameter::Data MakeValidBinaryWriteData()
	{
		cat::middleware::parameter::Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		auto const bytes = Default::ValidData();
		data.mutable_value()->set_binary_value(bytes.data(), bytes.size());
		return data;
	}
	cat::middleware::parameter::Data MakeDoubleWriteData()
	{
		cat::middleware::parameter::Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_double_value(1.0);
		return data;
	}
	FunctionalTests::FakeConfigBuilder& MakeFakeConfigBuilder()
	{
		auto spFakeConfigBuilder = std::make_unique<FunctionalTests::FakeConfigBuilder>();
		auto& fakeConfigBuilder = *spFakeConfigBuilder;
		m_gatingConfigBuilder.emplace(std::move(spFakeConfigBuilder), m_initializationGate);
		return fakeConfigBuilder;
	}
	void InitializeJaws(ServiceFactory serviceFactory)
	{
		auto parameterInitializers = ParameterWrapper::CreateParameterInitializers(
			*m_spDependencyContainer,
			*m_gatingConfigBuilder);

		auto spParameterWrapper = std::make_shared<ParameterWrapper>(
			std::move(serviceFactory),
			std::move(parameterInitializers),
			*m_gatingConfigBuilder);

		std::vector<std::function<void()>> initializers{};
		initializers.push_back([spParameterWrapper]()
			{
				spParameterWrapper->Initialize();
			});

		m_spJawsManager = std::make_unique<JawsManager>(
			std::make_unique<NiceMock<Shark::Mocks::MockIShark>>(),
			std::make_unique<cat::shark::Config>(),
			std::make_unique<NiceMock<Nvm::MockINvmWrapper>>(),
			std::make_unique<NiceMock<Identifiers::MockIPidDefinitionRetriever>>(),
			nullptr, // The IPidValueDecoder is only passed in for lifetime. Not needed here.
			nullptr, // The IPidValueEncoder is only passed in for lifetime. Not needed here.
			std::make_unique<NiceMock<Identifiers::MockIPublicJ1939DefinitionRetriever>>(),
			nullptr,
			m_spDependencyContainer.TakeUniquePtr(),
			std::move(initializers));
		m_spJawsManager->Initialize();
	}
	void InitializeJaws()
	{
		InitializeJaws([this]() { return m_spMockService.TakeUniquePtr(); });
	}

	cat::shark::Config m_sharkConfig{};
	NiceMock<Utilities::Mocks::MockIEnvironment> m_mockEnvironment{};
	NiceMock<Utilities::Mocks::MockIFilesystem> m_mockFilesystem{};
	NiceMock<Identifiers::MockIPidDefinitionRetriever> m_mockPidDefinitionRetriever{};
	NiceMock<Identifiers::MockIPublicJ1939DefinitionRetriever> m_mockPublicJ1939DefinitionRetriever{};
	NiceMock<Identifiers::MockIPidValueDecoder> m_mockPidValueDecoder{};
	NiceMock<Identifiers::MockIPidValueEncoder> m_mockPidValueEncoder{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<Nvm::MockINvmWrapper> m_mockNvmWrapper{};
	SharkToMiddlewareDefinitions m_sharkToMiddlewareDefinitions{};
	InitializationGate m_initializationGate{};
	Utilities::TestUniquePtr<DependencyContainer> m_spDependencyContainer;

	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockWriteSharkByte{};
	Utilities::DefaultTestUniquePtr<NiceMock<MockIService>> m_spMockService{};

private:
	std::optional<InitializationGatingConfigBuilder> m_gatingConfigBuilder{};
	std::unique_ptr<JawsManager> m_spJawsManager{};
};
TEST_F(RawDataWriteServerFunctionalTests, WriteRejectsNonRawDataWithBadQuality)
{
	// Given: Jaws is configured with a write-only BDT entry and initialized
	//  When: The BDT middleware write callback is invoked with non-raw (double) data
	//  Then: A bad quality response is replied asynchronously (no SharkByte write)

	auto& fakeConfigBuilder = MakeFakeConfigBuilder();
	InitializeJaws();

	cat::middleware::parameter::Data expectedReply{};
	expectedReply.set_quality(cat::middleware::parameter::Quality::QUALITY_BAD);

	auto const& actualMiddlewareWriteCallback = fakeConfigBuilder.GetServerWriteCallback(Default::MiddlewareId());
	ASSERT_THAT(actualMiddlewareWriteCallback, NotNull());
	auto const writeData = MakeDoubleWriteData();
	auto const result = actualMiddlewareWriteCallback(Default::WriteKey(), Default::MiddlewareId(), writeData);
	EXPECT_THAT(result, Optional(Utilities::ProtobufEquals(expectedReply)));
}

namespace
{
struct WriteCompletionParams
{
	Shark::SharkByteValue completionValue;
	bool expectedBoolReply;
};
}

class RawDataWriteServerFunctional_WriteCompletionTest
	: public RawDataWriteServerFunctionalTests
	, public WithParamInterface<WriteCompletionParams>
{
};
INSTANTIATE_TEST_SUITE_P(
	ReplyValues,
	RawDataWriteServerFunctional_WriteCompletionTest,
	Values(
		WriteCompletionParams{Shark::TrueSharkByteValue(), true},
		WriteCompletionParams{Shark::FalseSharkByteValue(), false}),
	[](testing::TestParamInfo<WriteCompletionParams> const& paramInfo)
	{
		return paramInfo.param.expectedBoolReply ? "Success" : "Failure";
	});
TEST_P(RawDataWriteServerFunctional_WriteCompletionTest, WriteSendsRawDataToSharkByteAndRepliesWithBooleanResult)
{
	// Given: Jaws is configured with a write-only BDT entry and initialized
	//  When: The BDT middleware write callback is invoked with raw binary data
	//  Then: The SharkByte write is called with the raw bytes and nullopt is returned (async)
	//  When: The SharkByte write completes
	//  Then: A quality good boolean reply is sent as a middleware reply

	auto& fakeConfigBuilder = MakeFakeConfigBuilder();
	InitializeJaws();

	Shark::IWriteSharkByte::CompletedCallback actualWriteSharkByteCallback{};
	auto const expectedBytes = Default::ValidData();
	EXPECT_CALL(m_mockWriteSharkByte, Write(ContainerEq(expectedBytes), _))
		.WillOnce(SaveArg<1>(&actualWriteSharkByteCallback));

	auto const& actualMiddlewareWriteCallback = fakeConfigBuilder.GetServerWriteCallback(Default::MiddlewareId());
	ASSERT_THAT(actualMiddlewareWriteCallback, NotNull());
	auto const writeData = MakeValidBinaryWriteData();

	auto const result = actualMiddlewareWriteCallback(Default::WriteKey(), Default::MiddlewareId(), writeData);
	EXPECT_THAT(result, Eq(std::nullopt));

	cat::middleware::parameter::Data expectedReply{};
	expectedReply.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedReply.mutable_value()->set_boolean_value(GetParam().expectedBoolReply);

	EXPECT_CALL(*m_spMockService, Reply(Default::WriteKey(), Utilities::ProtobufEquals(expectedReply)));

	ASSERT_THAT(actualWriteSharkByteCallback, NotNull());
	actualWriteSharkByteCallback(GetParam().completionValue);
}
}
}
