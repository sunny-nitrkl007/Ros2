/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Calibration and Service Test middleware functional tests

#include "FakeConfigBuilder.h"
#include "CalibrationCommandTestUtilities.h"
#include "DependencyContainer.h"
#include "Identifiers/MockIPidDefinitionRetriever.h"
#include "Identifiers/MockIPidValueDecoder.h"
#include "Identifiers/MockIPidValueEncoder.h"
#include "Identifiers/MockIPublicJ1939DefinitionRetriever.h"
#include "InitializationGate.h"
#include "JawsManager.h"
#include "Middleware/CalibrationWrapper.h"
#include "Middleware/InitializationGatingConfigBuilder.h"
#include "Middleware/InternalMiddlewareIds.h"
#include "Middleware/MockIPublish.h"
#include "Middleware/MockIService.h"
#include "Middleware/ParameterWrapper.h"
#include "Middleware/SharkToMiddlewareDefinitions.h"
#include "Nvm/MockINvmWrapper.h"
#include "SimpleSharkConfigBuilder.h"
#include <Shark/Mocks/MockIShark.h>
#include <Shark/Mocks/MockISharkByte.h>
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Shark/SharkByteDetails.h>
#include <Utilities/Mocks/MockIEnvironment.h>
#include <Utilities/Mocks/MockIFilesystem.h>
#include <Utilities/TestUtilities.h>
#include <nlohmann/json.hpp>
#include <optional>
#include <string>
#include <vector>

using namespace testing;
using namespace middleware::parameter;

namespace Jaws
{
namespace Middleware
{
namespace
{
using Shark::TestUtilities::Calibrations::MakeCommand;
using namespace Shark::SharkByteDetails::Calibrations;

struct Default
{
	static constexpr Config::CanPort CanPort() { return Config::CanPort::Can0; }
	static constexpr uint8_t Address() { return 0x21; }
	static constexpr uint_least16_t WriteKey() { return 42; }
	static constexpr unsigned CalibrationIndex() { return 0x0010; }
	static constexpr char const* CalibrationName() { return "Calibration_0010"; }
	static constexpr unsigned ServiceTestIndex() { return 0x1020; }
	static constexpr char const* ServiceTestName() { return "ServiceTest_1020"; }
	static constexpr uint_least16_t StepNumber() { return 42; }
};

constexpr Config::CalibrationServiceDataEntry n_calibrationEntries[]
{
	{ Default::CalibrationIndex(), Default::CalibrationName() },
};
constexpr Config::CalibrationServiceDataEntry n_serviceTestEntries[]
{
	{ Default::ServiceTestIndex(), Default::ServiceTestName() },
};
constexpr Config::CalibrationServicesEntry n_calibrationServicesEntry
{
	n_calibrationEntries,
	n_serviceTestEntries,
};

std::string ToString(std::vector<uint8_t> const& bytes)
{
	return { bytes.begin(), bytes.end() };
}

Data MakeStringWriteData(std::vector<uint8_t> const& bytes)
{
	Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	data.mutable_value()->set_string_value(ToString(bytes));
	return data;
}

std::vector<uint8_t> MakeStatusBytes()
{
	nlohmann::json document{};
	document[Status::FieldName()] = Default::CalibrationName();
	document[Status::FieldType()] = Status::TypeCalibration();
	document[Status::FieldStep()] = Default::StepNumber();
	document[Status::FieldStatus()] = Status::StatusExecuting();
	document[Status::FieldErrors()] = std::vector<uint_least16_t>{0x1234, 0x5678};

	auto const statusString = document.dump();
	return { statusString.begin(), statusString.end() };
}

Data MakeGoodStringData(std::vector<uint8_t> const& bytes)
{
	Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	data.mutable_value()->set_string_value(ToString(bytes));
	return data;
}

Data MakeGoodBooleanData(bool value)
{
	Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	data.mutable_value()->set_boolean_value(value);
	return data;
}
}

class CalibrationFunctionalTests : public Test
{
protected:
	CalibrationFunctionalTests()
		: m_spDependencyContainer{std::make_unique<DependencyContainer>(
			m_sharkConfig,
			m_mockEnvironment,
			m_mockFilesystem,
			m_mockPidDefinitionRetriever,
			m_mockPublicJ1939DefinitionRetriever,
			m_mockPidValueDecoder,
			m_mockPidValueEncoder,
			m_mockSharkByteRetriever,
			m_mockWriteSharkByteRetriever,
			m_mockNvmWrapper,
			m_initializationGate,
			m_sharkToMiddlewareDefinitions)}
	{
		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder
			.UsingJ1939DataLink(Default::CanPort())
				.UsingPeerNode(Default::Address())
					.WithCalibrationServices(n_calibrationServicesEntry);
		m_sharkConfig = configBuilder.Build();

		ON_CALL(m_mockSharkByteRetriever, Retrieve(Status::SharkByteId()))
			.WillByDefault(ReturnRef(m_mockStatusSharkByte.GetMock()));
		ON_CALL(m_mockWriteSharkByteRetriever, Retrieve(Command::SharkByteId()))
			.WillByDefault(ReturnRef(m_mockCommandSharkByte));
		ON_CALL(*m_spMockService, RetrievePublisherInstance(Calibration::CalibrationStatus()))
			.WillByDefault(ReturnRef(m_mockStatusPublish));
	}

	FunctionalTests::FakeConfigBuilder& MakeFakeConfigBuilder()
	{
		auto spFakeConfigBuilder = std::make_unique<FunctionalTests::FakeConfigBuilder>();
		auto& fakeConfigBuilder = *spFakeConfigBuilder;
		m_gatingConfigBuilder.emplace(std::move(spFakeConfigBuilder), m_initializationGate);
		return fakeConfigBuilder;
	}

	std::unique_ptr<JawsManager> CreateJawsManager(std::vector<std::function<void()>>&& initializers)
	{
		return std::make_unique<JawsManager>(
			std::make_unique<NiceMock<Shark::Mocks::MockIShark>>(),
			std::make_unique<cat::shark::Config>(),
			std::make_unique<NiceMock<Nvm::MockINvmWrapper>>(),
			std::make_unique<NiceMock<Identifiers::MockIPidDefinitionRetriever>>(),
			nullptr, // The IPidValueDecoder is only passed in for lifetime. Not needed here.
			nullptr, // The IPidValueEncoder is only passed in for lifetime. Not needed here.
			std::make_unique<NiceMock<Identifiers::MockIPublicJ1939DefinitionRetriever>>(),
			nullptr, // The IInitializationGate is only passed in for lifetime. Not needed here.
			m_spDependencyContainer.TakeUniquePtr(),
			std::move(initializers));
	}

	void InitializeJaws(ServiceFactory serviceFactory)
	{
		auto calibrationInitializer = CalibrationWrapper::CreateInitializer(*m_spDependencyContainer);
		auto parameterInitializers = ParameterWrapper::CreateParameterInitializers(
			*m_spDependencyContainer,
			*m_gatingConfigBuilder);

		auto spParameterWrapper = std::make_shared<ParameterWrapper>(
			std::move(serviceFactory),
			std::move(parameterInitializers),
			*m_gatingConfigBuilder);

		std::vector<std::function<void()>> initializers{};
		initializers.push_back(std::move(calibrationInitializer));
		initializers.push_back([spParameterWrapper]()
			{
				spParameterWrapper->Initialize();
			});

		m_spJawsManager = CreateJawsManager(std::move(initializers));
		m_spJawsManager->Initialize();
	}

	void InitializeJaws()
	{
		InitializeJaws([this]() { return m_spMockService.TakeUniquePtr(); });
	}

	OnWriteAction& InitializeAndGetCommandWriteCallback(FunctionalTests::FakeConfigBuilder& fakeConfigBuilder)
	{
		InitializeJaws();
		auto& callback = fakeConfigBuilder.GetServerWriteCallback(Calibration::CalibrationCommand());
		return callback;
	}

	Shark::IWriteSharkByte::CompletedCallback ExpectCommandWrite(std::vector<uint8_t> const& expectedBytes)
	{
		Shark::IWriteSharkByte::CompletedCallback actualWriteSharkByteCallback{};
		EXPECT_CALL(m_mockCommandSharkByte, Write(ContainerEq(expectedBytes), _))
			.WillOnce(SaveArg<1>(&actualWriteSharkByteCallback));
		return actualWriteSharkByteCallback;
	}

	void SendCommandAndComplete(
		OnWriteAction const& writeCallback,
		std::vector<uint8_t> const& command,
		Shark::SharkByteValue const& completionValue,
		bool expectedReply)
	{
		Shark::IWriteSharkByte::CompletedCallback actualWriteSharkByteCallback{};
		EXPECT_CALL(m_mockCommandSharkByte, Write(ContainerEq(command), _))
			.WillOnce(SaveArg<1>(&actualWriteSharkByteCallback));

		auto const result = writeCallback(Default::WriteKey(), Calibration::CalibrationCommand(), MakeStringWriteData(command));
		EXPECT_THAT(result, Eq(std::nullopt));

		EXPECT_CALL(*m_spMockService, Reply(Default::WriteKey(), Utilities::ProtobufEquals(MakeGoodBooleanData(expectedReply))));
		ASSERT_THAT(actualWriteSharkByteCallback, NotNull());
		actualWriteSharkByteCallback(completionValue);
	}

	cat::shark::Config m_sharkConfig{};
	NiceMock<Utilities::Mocks::MockIEnvironment> m_mockEnvironment{};
	NiceMock<Utilities::Mocks::MockIFilesystem> m_mockFilesystem{};
	NiceMock<Identifiers::MockIPidDefinitionRetriever> m_mockPidDefinitionRetriever{};
	NiceMock<Identifiers::MockIPublicJ1939DefinitionRetriever> m_mockPublicJ1939DefinitionRetriever{};
	NiceMock<Identifiers::MockIPidValueDecoder> m_mockPidValueDecoder{};
	NiceMock<Identifiers::MockIPidValueEncoder> m_mockPidValueEncoder{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<Nvm::MockINvmWrapper> m_mockNvmWrapper{};
	SharkToMiddlewareDefinitions m_sharkToMiddlewareDefinitions{};
	InitializationGate m_initializationGate{};
	Utilities::TestUniquePtr<DependencyContainer> m_spDependencyContainer;

	NiceMock<middleware::parameter::MockIPublish> m_mockStatusPublish{};
	Shark::Mocks::MockSharkByteWrapper m_mockStatusSharkByte{};
	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockCommandSharkByte{};
	Utilities::DefaultTestUniquePtr<NiceMock<MockIService>> m_spMockService{};

private:
	std::optional<InitializationGatingConfigBuilder> m_gatingConfigBuilder{};
	std::unique_ptr<JawsManager> m_spJawsManager{};
};
TEST_F(CalibrationFunctionalTests, InitializesCalibrationMiddlewareWhenCalibrationsAreConfigured)
{
	// Given: Jaws is configured with calibrations and service tests on a J1939 data link
	//  When: Jaws is initialized
	//  Then: The calibration status publisher and command writer are registered
	//   And: Jaws retrieves the calibration status and command SharkBytes

	auto& fakeConfigBuilder = MakeFakeConfigBuilder();
	EXPECT_CALL(m_mockSharkByteRetriever, Retrieve(Status::SharkByteId()));
	EXPECT_CALL(m_mockWriteSharkByteRetriever, Retrieve(Command::SharkByteId()));
	EXPECT_CALL(*m_spMockService, RetrievePublisherInstance(Calibration::CalibrationStatus()));

	InitializeJaws();

	EXPECT_THAT(fakeConfigBuilder.HasPublisher(Calibration::CalibrationStatus()), IsTrue());
	EXPECT_NO_THROW(fakeConfigBuilder.GetServerWriteCallback(Calibration::CalibrationCommand()));
}
TEST_F(CalibrationFunctionalTests, StatusSharkBytePublishesCalibrationStatusJsonToMiddleware)
{
	// Given: Jaws is configured with calibrations and initialized
	//  When: The calibration status SharkByte reports JSON status data
	//  Then: Jaws publishes the JSON string to the calibration status middleware parameter

	MakeFakeConfigBuilder();
	InitializeJaws();

	auto const statusBytes = MakeStatusBytes();
	EXPECT_CALL(m_mockStatusPublish, Publish(Utilities::ProtobufEquals(MakeGoodStringData(statusBytes))));
	m_mockStatusSharkByte.SetValue(statusBytes);
}

namespace
{
struct SharkCommandMapping
{
	char const* command;
	std::optional<unsigned> context;
};
constexpr SharkCommandMapping n_sharkCommandMappings[]
{
	{ Command::YesAffirmation(),        std::nullopt },
	{ Command::NoAffirmation(),         std::nullopt },
	{ Command::SmallIncrement(),        std::nullopt },
	{ Command::SmallDecrement(),        std::nullopt },
	{ Command::LargeIncrement(),        std::nullopt },
	{ Command::LargeDecrement(),        std::nullopt },
	{ Command::RevertToDefaultValues(), std::nullopt },
	{ Command::GoToStep(),              0x0201 },
	{ Command::CommandButton(),         0x03 },
};

std::vector<std::vector<uint8_t>> MakeCommandsMatchingSharkFunctionalTestCases()
{
	std::vector<std::vector<uint8_t>> commands
	{
		MakeCommand(Command::Engage(), Default::CalibrationName()),
		MakeCommand(Command::Engage(), Default::ServiceTestName()),
		MakeCommand(Command::Engage(), "UnknownCalibration"),
		MakeCommand(Command::Proceed()),
		MakeCommand(Command::Abort()),
		MakeCommand(Command::Disengage()),
		MakeCommand(Command::FinishedServiceTest()),
	};
	for (auto const& mapping : n_sharkCommandMappings)
	{
		if (mapping.context)
		{
			commands.push_back(MakeCommand(mapping.command, *mapping.context));
		}
		else
		{
			commands.push_back(MakeCommand(mapping.command));
		}
	}
	return commands;
}
}

TEST_F(CalibrationFunctionalTests, CalibrationCommandWritesForwardSharkFunctionalCommandPayloadsToSharkByte)
{
	// Given: Jaws is configured with calibrations and initialized
	//  When: Middleware writes each calibration command covered by the Shark functional tests
	//  Then: Jaws forwards the command JSON payload to the calibration command SharkByte
	//   And: The write completes asynchronously with a boolean success reply

	auto& fakeConfigBuilder = MakeFakeConfigBuilder();
	auto& writeCallback = InitializeAndGetCommandWriteCallback(fakeConfigBuilder);

	for (auto const& command : MakeCommandsMatchingSharkFunctionalTestCases())
	{
		SendCommandAndComplete(writeCallback, command, Shark::TrueSharkByteValue(), true);
	}
}
TEST_F(CalibrationFunctionalTests, CalibrationCommandWriteRepliesFalseWhenSharkRejectsCommand)
{
	// Given: Jaws is configured with calibrations and initialized
	//  When: Middleware writes a calibration command
	//   And: Shark rejects the command
	//  Then: Jaws replies with a good quality false boolean value

	auto& fakeConfigBuilder = MakeFakeConfigBuilder();
	auto& writeCallback = InitializeAndGetCommandWriteCallback(fakeConfigBuilder);

	SendCommandAndComplete(writeCallback, MakeCommand(Command::Engage(), "UnknownCalibration"), Shark::FalseSharkByteValue(), false);
}
TEST_F(CalibrationFunctionalTests, CalibrationCommandWriteReturnsBadQualityWhilePreviousCommandIsInProcess)
{
	// Given: Jaws is configured with calibrations and initialized
	//   And: A calibration command write is in process
	//  When: Another calibration command is written before Shark completes the first write
	//  Then: Jaws rejects the second write with bad quality

	auto& fakeConfigBuilder = MakeFakeConfigBuilder();
	auto const& writeCallback = InitializeAndGetCommandWriteCallback(fakeConfigBuilder);

	auto const firstCommand = MakeCommand(Command::Engage(), Default::CalibrationName());
	auto actualWriteSharkByteCallback = ExpectCommandWrite(firstCommand);
	auto const firstResult = writeCallback(Default::WriteKey(), Calibration::CalibrationCommand(), MakeStringWriteData(firstCommand));
	EXPECT_THAT(firstResult, Eq(std::nullopt));

	Data expectedReply{};
	expectedReply.set_quality(cat::middleware::parameter::Quality::QUALITY_BAD);
	auto const secondResult = writeCallback(
		Default::WriteKey() + 1,
		Calibration::CalibrationCommand(),
		MakeStringWriteData(MakeCommand(Command::Proceed())));
	EXPECT_THAT(secondResult, Optional(Utilities::ProtobufEquals(expectedReply)));
}
}
}
