/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Fake IConfigBuilder that captures parameters for testing

#pragma once

#include <IConfigBuilder.h>
#include <middleware_parameter.pb.h>
#include <functional>
#include <map>
#include <set>
#include <string>

namespace Jaws
{
namespace FunctionalTests
{
/// Add more and more functionality as needed for functional tests.
class FakeConfigBuilder : public middleware::parameter::IConfigBuilder
{
public:
	using OnWriteAction = middleware::parameter::OnWriteAction;
	using OnReadAction = middleware::parameter::OnReadAction;

	OnWriteAction& GetServerWriteCallback(std::string const& parameterId)
	{
		auto it = m_serverWriteCallbacks.find(parameterId);
		if (it == m_serverWriteCallbacks.end())
		{
			throw std::out_of_range("No ServerWrite callback registered for: " + parameterId);
		}
		return it->second;
	}

	OnReadAction& GetServerReadCallback(std::string const& parameterId)
	{
		auto it = m_serverReadCallbacks.find(parameterId);
		if (it == m_serverReadCallbacks.end())
		{
			throw std::out_of_range("No ServerRead callback registered for: " + parameterId);
		}
		return it->second;
	}
	bool HasPublisher(std::string const& parameterId) const
	{
		return m_publishers.contains(parameterId);
	}

// middleware::parameter::IConfigBuilder
	IConfigBuilder& AddPublish(middleware::parameter::Identity&& parameter_id, middleware::parameter::Unit /*unit*/, middleware::parameter::Data&& /*initial_value*/) override
	{
		m_publishers.emplace(std::string{parameter_id});
		return *this;
	}
	IConfigBuilder& AddSubscribe(middleware::parameter::Identity&& /*parameter_id*/, middleware::parameter::Unit /*unit*/, middleware::parameter::OnSubscription&& /*callback*/, middleware::parameter::OnDisconnect&& /*disconnect*/) override
	{
		return *this;
	}
	IConfigBuilder& AddSubscribe(middleware::parameter::Identity&& /*parameter_id*/, middleware::parameter::OnSubscriptionWithMetadata&& /*callback*/, middleware::parameter::OnDisconnect&& /*disconnect*/) override
	{
		return *this;
	}
	IConfigBuilder& AddClientRead(middleware::parameter::Identity&& /*parameter_id*/, middleware::parameter::Unit /*unit*/) override
	{
		return *this;
	}
	IConfigBuilder& AddClientWrite(middleware::parameter::Identity&& /*parameter_id*/, middleware::parameter::Unit /*unit*/) override
	{
		return *this;
	}
	IConfigBuilder& AddServerWrite(middleware::parameter::Identity&& parameter_id, OnWriteAction&& callback) override
	{
		m_serverWriteCallbacks.emplace(std::string{parameter_id}, std::move(callback));
		return *this;
	}
	IConfigBuilder& AddServerRead(middleware::parameter::Identity&& parameter_id, middleware::parameter::OnReadAction&& callback) override
	{
		m_serverReadCallbacks.emplace(std::string{parameter_id}, std::move(callback));
		return *this;
	}
	middleware::parameter::ParameterService&& Take() override
	{
		assert(false); // This should not be called in functional tests
		throw std::logic_error("Take() should not be called in functional tests");
	}
private:
	std::map<std::string, OnWriteAction> m_serverWriteCallbacks{};
	std::map<std::string, OnReadAction> m_serverReadCallbacks{};
	std::set<std::string> m_publishers{};
};
}
}
