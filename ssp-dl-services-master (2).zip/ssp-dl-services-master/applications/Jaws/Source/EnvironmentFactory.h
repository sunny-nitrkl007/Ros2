/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Jaws Environment Factory

#pragma once

#include <Utilities/IEnvironment.h>
#include <functional>
#include <memory>

namespace Utilities { class IFilesystem; }

namespace Jaws
{
class EnvironmentFactory
{
public:
	static std::unique_ptr<Utilities::IEnvironment> CreateEnvironment(Utilities::IFilesystem const& filesystem);
};
}
