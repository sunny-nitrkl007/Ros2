/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See ConfigLoader.h

#include "ConfigLoader.h"

#include "ConfigFormatter.h"
#include "Log.h"
#include "Nvm/NvmParameters.h"
#include <google/protobuf/util/json_util.h>

namespace Jaws
{
namespace
{
ConfigFormatter const n_configFormatter(
{
	"pgn",
	"pid",
	"address",
	"module_id",
	"application_id",
	"fid",
	"valid_addresses"
});

/// Parses a protobuf-JSON configuration string into a cat::shark::Config. Returns an
/// empty Config when the string is empty, or nullptr when the string is non-empty but
/// could not be parsed.
Utilities::optional_unique_ptr<cat::shark::Config> ParseConfiguration(
	std::string const& configurationJson)
{
	auto spSharkConfig = std::make_unique<cat::shark::Config>();
	if (configurationJson.size() != 0)
	{
		auto status = google::protobuf::util::JsonStringToMessage(
			configurationJson,
			spSharkConfig.get());
		if (!status.ok())
		{
			LOG_INFO_HIGH("Current Jaws configuration is blank or invalid!");
			return nullptr;
		}
		LOG_INFO_HIGH("Current Jaws configuration:\n" << n_configFormatter.Format(*spSharkConfig));
	}
	return spSharkConfig;
}
}

Utilities::optional_unique_ptr<cat::shark::Config> ConfigLoader::LoadFromNvm(
	Nvm::INvmWrapper& nvmWrapper) const
{
	auto const configurationJson = nvmWrapper.Read(Jaws::Nvm::JawsConfigurationNvmId(), "");
	return ParseConfiguration(configurationJson);
}
}
