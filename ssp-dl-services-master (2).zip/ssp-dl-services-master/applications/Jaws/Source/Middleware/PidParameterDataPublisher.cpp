/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PidParameterDataPublisher.h

#include "PidParameterDataPublisher.h"
#include "DependencyContainer.h"
#include "Identifiers/IPidDefinitionRetriever.h"
#include "Identifiers/IPidValueDecoder.h"
#include "Utilities/OverloadLambdas.h"
#include <IConfigBuilder.h>
#include <IParameterService.h>
#include <IPublishParameter.h>
#include <middleware_parameter.pb.h>
#include <Shark/ISharkByteRetriever.h>

using Data = cat::middleware::parameter::Data;

namespace Jaws
{
namespace Middleware
{
namespace
{
Data CreateDefaultData()
{
	Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	return data;
}
}

std::move_only_function<void(middleware::parameter::IService&)> PidParameterDataPublisher::Create(
	unsigned pid,
	std::string const& publishId,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& pidDefinition = dependencyContainer.GetIPidDefinitionRetriever().RetrievePid(pid);
	configBuilder.AddPublish(
		publishId.c_str(),
		static_cast<middleware::parameter::Unit>(pidDefinition.Units()),
		CreateDefaultData());
	auto spPublisher = std::make_unique<PidParameterDataPublisher>(
		publishId,
		pidDefinition,
		dependencyContainer.GetIPidValueDecoder());

	auto& sharkByteRetriever = dependencyContainer.GetISharkByteRetriever();
	return [spPublisher = std::move(spPublisher), &sharkByteRetriever](middleware::parameter::IService& parameterService) noexcept
	{
		spPublisher->Initialize(sharkByteRetriever, parameterService);
	};
}

PidParameterDataPublisher::PidParameterDataPublisher(
	std::string const& publishId,
	Identifiers::PidDefinition const& pidDefinition,
	Identifiers::IPidValueDecoder const& pidValueDecoder)
	: m_publishId(publishId)
	, m_pidDefinition(pidDefinition)
	, m_pidValueDecoder(pidValueDecoder)
{
}
void PidParameterDataPublisher::Initialize(
	Shark::ISharkByteRetriever const& sharkByteRetriever,
	middleware::parameter::IService& parameterService)
{
	assert(!m_subscription.IsConnected());
	auto& publisher = parameterService.RetrievePublisherInstance(m_publishId);
	auto& sharkByte = sharkByteRetriever.Retrieve(m_publishId);
	m_subscription = sharkByte.SubscribeToValues(
		[this, &publisher](Shark::SharkByteValue const& value)
		{
			Publish(publisher, value);
		});
}
void PidParameterDataPublisher::Publish(
	middleware::parameter::IPublish& publisher,
	Shark::SharkByteValue const& value)
{
	auto const decoded = m_pidValueDecoder.Decode(m_pidDefinition, value);
	Data data{};
	switch (decoded.quality)
	{
		case Identifiers::DecodedPidQuality::NotReceived:
			data.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
			break;
		case Identifiers::DecodedPidQuality::Bad:
			data.set_quality(cat::middleware::parameter::Quality::QUALITY_BAD);
			break;
		case Identifiers::DecodedPidQuality::Good:
			data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
			std::visit(
				Utilities::OverloadLambdas{
					[](std::monostate const&) {},
					[&data](double doubleValue) { data.mutable_value()->set_double_value(doubleValue); },
					[&data](uint64_t uintValue) { data.mutable_value()->set_uinteger64_value(uintValue); },
					[&data](std::vector<uint8_t> const& binaryValue) {
						data.mutable_value()->set_binary_value(binaryValue.data(), binaryValue.size());
					}
				},
				decoded.value);
			break;
		default:
			data.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
			break;
	}
	publisher.Publish(data);
}
}
}
