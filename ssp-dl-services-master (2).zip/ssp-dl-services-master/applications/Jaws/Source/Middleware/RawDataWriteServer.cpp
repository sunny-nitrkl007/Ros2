/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See RawDataWriteServer.h

#include "RawDataWriteServer.h"
#include "DependencyContainer.h"
#include "IConfigBuilder.h"
#include "IParameterService.h"
#include "Log.h"
#include <Shark/IWriteSharkByteRetriever.h>

using Data = cat::middleware::parameter::Data;

namespace
{
Data MakeBadData()
{
	Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_BAD);
	return data;
}
}

namespace Jaws
{
namespace Middleware
{
std::move_only_function<void(middleware::parameter::IService&)> RawDataWriteServer::Create(
	cat::shark::J1939DataLink::PeerNode::Bdt::BdtType const& bdtType,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& middlewareId = bdtType.middleware_id();
	LOG_DEBUG_TAG(Log::Write, middlewareId << ": Creating RawDataWriteServer");

	auto spRawDataWriteServer = std::make_shared<RawDataWriteServer>(middlewareId);

	configBuilder.AddServerWrite(
		middlewareId.c_str(),
		[spRawDataWriteServer](uint_least16_t key, middleware::parameter::Identity const& identity, Data const& data)
			{
				return spRawDataWriteServer->OnWrite(key, identity, data);
			});

	auto& writeSharkByteRetriever = dependencyContainer.GetIWriteSharkByteRetriever();
	return [spRawDataWriteServer = std::move(spRawDataWriteServer), &writeSharkByteRetriever](middleware::parameter::IService& parameterService) noexcept
		{
			spRawDataWriteServer->Initialize(writeSharkByteRetriever, parameterService);
		};
}

RawDataWriteServer::RawDataWriteServer(std::string const& id)
	: m_id{id}
{
}
void RawDataWriteServer::Initialize(
	Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever,
	middleware::parameter::IService& parameterService)
{
	assert(!m_spParameterService);
	assert(!m_spWriteSharkByte);
	m_spWriteSharkByte = &writeSharkByteRetriever.Retrieve(m_id);
	m_spParameterService = &parameterService;
}
std::optional<Data> RawDataWriteServer::OnWrite(
	uint_least16_t key,
	[[maybe_unused]] middleware::parameter::Identity const& id,
	Data const& data)
{
	LOG_INFO_LOW_TAG(Log::Write, id << ": OnWrite(key=" << key << ")");
	assert(m_id == id);
	assert(m_spWriteSharkByte);

	if (!data.has_value() || !data.value().has_binary_value())
	{
		LOG_WARNING_TAG(Log::Write, id << ": Write data must be raw binary. Rejecting write.");
		return MakeBadData();
	}

	auto const& binaryValue = data.value().binary_value();
	std::vector<uint8_t> bytes(binaryValue.begin(), binaryValue.end());

	std::optional<Data> returnData{MakeBadData()};
	{
		std::lock_guard<std::mutex> lock{m_mutex};
		if (m_activeKey)
		{
			LOG_WARNING_TAG(Log::Write, id << ": Received write while another write is active. Rejecting write.");
		}
		else
		{
			m_activeKey = key;
			m_spWriteSharkByte->Write(bytes,
				[this](Shark::SharkByteValue const& value)
				{
					OnWriteCompleted(value);
				});
			returnData = std::nullopt;
		}
	}

	return returnData;
}
void RawDataWriteServer::OnWriteCompleted(Shark::SharkByteValue const& value)
{
	assert(value); // Value must always be valid
	bool const succeeded = (*value != Shark::FalseSharkByteValue());
	LOG_INFO_HIGH_TAG(Log::Write, m_id << ": OnWriteCompleted(" << (succeeded ? "succeeded" : "failed") << ")");
	assert(m_spParameterService);

	Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	data.mutable_value()->set_boolean_value(succeeded);

	std::optional<uint_least16_t> keyToReplyTo{};
	{
		std::lock_guard<std::mutex> lock{m_mutex};
		keyToReplyTo.swap(m_activeKey);
	}

	if (keyToReplyTo)
	{
		LOG_DEBUG_TAG(Log::Write, m_id << ": Replying to key " << *keyToReplyTo << " with value " << data.DebugString());
		m_spParameterService->Reply(*keyToReplyTo, data);
	}
	else
	{
		LOG_WARNING_TAG(Log::Write, m_id << ": No active write key to reply to in OnWriteCompleted");
	}
}
}
}
