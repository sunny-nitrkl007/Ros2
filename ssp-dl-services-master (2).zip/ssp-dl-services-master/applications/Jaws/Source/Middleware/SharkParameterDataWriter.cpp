/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SharkParameterDataWriter.h

#include "SharkParameterDataWriter.h"
#include "DependencyContainer.h"
#include <IConfigBuilder.h>
#include <IParameterService.h>
#include <Utilities/nice_ptr.h>

namespace Jaws
{
namespace Middleware
{
namespace
{
cat::middleware::parameter::Data MakeBadData()
{
	cat::middleware::parameter::Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_BAD);
	return data;
}
}

std::move_only_function<void(middleware::parameter::IService&)> SharkParameterDataWriter::Create(
	SharkToMiddlewareWriter const& sharkToMiddlewareWriter,
	[[maybe_unused]] DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto spSharkParameterDataWriter = std::make_unique<SharkParameterDataWriter>(sharkToMiddlewareWriter);
	auto& sharkParameterDataWriter = *spSharkParameterDataWriter;
	configBuilder.AddServerWrite(
		sharkToMiddlewareWriter.pWriteId,
		[&sharkParameterDataWriter](uint_least16_t key, [[maybe_unused]] middleware::parameter::Identity const& identity, cat::middleware::parameter::Data const& data)
		{
			return sharkParameterDataWriter.OnWrite(key, data);
		});

	return [spSharkParameterDataWriter = std::move(spSharkParameterDataWriter)](middleware::parameter::IService& parameterService) noexcept
		{
			spSharkParameterDataWriter->Initialize(parameterService);
		};
}
SharkParameterDataWriter::SharkParameterDataWriter(
	SharkToMiddlewareWriter const& sharkToMiddlewareWriter)
	: m_sharkToMiddlewareWriter(sharkToMiddlewareWriter)
{
}
void SharkParameterDataWriter::Initialize(middleware::parameter::IService& parameterService)
{
	assert(!m_spParameterService);
	m_spParameterService = &parameterService;
}
std::optional<cat::middleware::parameter::Data> SharkParameterDataWriter::OnWrite(
	uint_least16_t key,
	cat::middleware::parameter::Data const& data)
{
	std::optional<cat::middleware::parameter::Data> returnData = MakeBadData();
	std::lock_guard<std::mutex> lock{m_mutex};
	if (!m_inProcessKey.has_value())
	{
		returnData = m_sharkToMiddlewareWriter.onWrite(data, *this);
		if (!returnData.has_value())
		{
			m_inProcessKey.emplace(key);
		}
	}
	return returnData;
}
void SharkParameterDataWriter::Reply(cat::middleware::parameter::Data const& data)
{
	assert(m_spParameterService);
	std::lock_guard<std::mutex> lock{m_mutex};
	m_spParameterService->Reply(*m_inProcessKey, data);
	m_inProcessKey.reset();
}
}
}