/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See ConfigurationReceiver.h

#include "ConfigurationReceiver.h"
#include "ConfigValidator.h"
#include "DependencyContainer.h"
#include "InternalMiddlewareIds.h"
#include "Log.h"
#include "Nvm/NvmParameters.h"
#include <IConfigBuilder.h>
#include <middleware_parameter.pb.h>
#include <SharkConfiguration.pb.h>
#include <google/protobuf/util/json_util.h>

namespace Jaws
{
namespace Middleware
{
namespace
{
Utilities::nice_ptr<ConfigurationReceiver> n_spConfigurationReceiver{};
}
std::shared_ptr<ConfigurationReceiver> ConfigurationReceiver::Create(
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	configBuilder.AddSubscribe(
		Configuration(),
		&OnConfigurationUpdate,
		[]{});

	auto& nvmWrapper = dependencyContainer.GetINvmWrapper();
	return std::make_shared<ConfigurationReceiver>(nvmWrapper, std::make_unique<ConfigValidator>());
}
void ConfigurationReceiver::OnConfigurationUpdate(
	std::string const& id,
	middleware::parameter::Data const& data,
	middleware::parameter::Metadata const&)
{
	if (id == Configuration())
	{
		n_spConfigurationReceiver->ConfigurationUpdate(data);
	}
}
ConfigurationReceiver::ConfigurationReceiver(
	Nvm::INvmWrapper& nvmWrapper,
	std::unique_ptr<IConfigValidator>&& spConfigValidator) noexcept
	: m_nvmWrapper{nvmWrapper}
	, m_spConfigValidator{std::move(spConfigValidator)}
{
	assert(!n_spConfigurationReceiver);
	n_spConfigurationReceiver = this;
}
ConfigurationReceiver::~ConfigurationReceiver()
{
	assert(n_spConfigurationReceiver);
	n_spConfigurationReceiver.reset();
}
void ConfigurationReceiver::ConfigurationUpdate(middleware::parameter::Data const& data)
{
	assert(data.has_value());
	assert(data.value().has_binary_value());
	auto const& value = data.value().binary_value();
	std::vector<uint8_t> configValue(value.begin(), value.end());
	std::string jsonConfig{};
	if (m_spConfigValidator->ValidateAndConvertToJson(configValue, jsonConfig))
	{
		LOG_INFO_HIGH("New configuration received, validation passed and saving to NVM");
		m_nvmWrapper.Write(Nvm::JawsConfigurationNvmId(), jsonConfig);
	}
	else
	{
		LOG_ERROR("New configuration received, validation failed");
	}
}
}
}