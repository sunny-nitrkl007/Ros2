/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Parameter Wrapper class

#pragma once

#include <functional>
#include <memory>

namespace middleware::parameter
{
class IConfigBuilder;
class IService;
}
namespace Shark {class ISharkByteRetriever;}
namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
class IParameterDataPublisher;
class IServiceWaiter;

using ParameterInitializers = std::vector<std::move_only_function<void(middleware::parameter::IService&)>>;
using ServiceFactory = std::move_only_function<std::unique_ptr<middleware::parameter::IService>()>;

class ParameterWrapper
{
public:
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);

	static ParameterInitializers CreateParameterInitializers(
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);

	ParameterWrapper(
		ServiceFactory&& serviceFactory,
		ParameterInitializers&& parameterInitializers,
		IServiceWaiter& serviceWaiter) noexcept;

	void Initialize();
private:
	ServiceFactory m_serviceFactory;
	ParameterInitializers m_parameterInitializers;
	IServiceWaiter& m_serviceWaiter;
	std::unique_ptr<middleware::parameter::IService> m_spParameterService{}; // Populated by the ServiceFactory
};
}
}
