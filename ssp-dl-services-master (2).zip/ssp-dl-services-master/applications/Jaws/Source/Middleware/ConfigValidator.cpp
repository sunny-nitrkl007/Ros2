/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// see ConfigValidator.h

#include "ConfigValidator.h"
#include "Log.h"
#include <SharkConfiguration.pb.h>
#include <google/protobuf/message.h>
#include <google/protobuf/util/json_util.h>

namespace Jaws
{
namespace Middleware
{
bool ConfigValidator::ValidateAndConvertToJson(
	std::vector<uint8_t> const& data,
	std::string& output)
{
	cat::shark::Config message{};
	bool validationPassed = false;
	if (message.ParseFromArray(data.data(), static_cast<int>(data.size())))
	{
		validationPassed = google::protobuf::util::MessageToJsonString(message, &output).ok();
	}
	else
	{
		LOG_ERROR("Invalid configuration data received, unable to parse");
	}
	return validationPassed;
}
}
}