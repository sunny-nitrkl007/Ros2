/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pid parameter data writer

#pragma once

#include "Identifiers/PidDefinition.h"
#include <IParameterService.h>
#include <Shark/IWriteSharkByte.h>
#include <SharkConfiguration.pb.h>
#include <Utilities/nice_ptr.h>
#include <middleware_parameter.pb.h>
#include <mutex>
#include <optional>
#include <vector>

namespace middleware::parameter
{
class IConfigBuilder;
class IService;
}
namespace Shark
{
class IWriteSharkByteRetriever;
}

namespace Jaws
{
class DependencyContainer;

namespace Identifiers
{
class IPidValueEncoder;
}

namespace Middleware
{

class PidParameterDataWriter
{
public:
	static std::move_only_function<void(middleware::parameter::IService&)> Create(
		cat::shark::J1939DataLink::PeerNode::BasicReadWrite::BasicReadWritePid const& basicReadWritePidEntry,
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);

	PidParameterDataWriter(
		std::string const& id,
		Identifiers::PidDefinition const& pidDefinition,
		Identifiers::IPidValueEncoder const& pidValueEncoder);
	void Initialize(
		Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever,
		middleware::parameter::IService& parameterService);
	std::optional<cat::middleware::parameter::Data> OnWrite(
		uint_least16_t key,
		middleware::parameter::Identity const& id,
		cat::middleware::parameter::Data const& data);
private:
	std::optional<std::vector<uint8_t>> GetDataToWrite(cat::middleware::parameter::Data const& data) const;
	void OnWriteCompleted(Shark::SharkByteValue const& value);
	cat::middleware::parameter::Data CreateReplyData(Shark::SharkByteValue const& value) const;
	bool IsWithinDsiRange(uint32_t lsbUintData) const;
	uint32_t MakeDataLsbFirst(uint8_t const* pData, unsigned dataLength) const;
	bool IsSignedValueNegative(uint32_t data, unsigned length) const;
	int64_t GetRawIntegerValue(uint32_t lsbUintData) const;
	double GetScaledValue(int64_t rawValue) const;

	std::string const m_id;
	Identifiers::PidDefinition const m_pidDefinition;
	Identifiers::IPidValueEncoder const& m_pidValueEncoder;
	Utilities::nice_ptr<middleware::parameter::IService> m_spParameterService{};
	Utilities::nice_ptr<Shark::IWriteSharkByte> m_spWriteSharkByte{};
	std::optional<uint_least16_t> m_activeKey{};
	std::mutex m_mutex{};
};
}
}