/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Parameter Data Publisher

#pragma once

#include "ISharkToMiddlewareDefinitions.h"
#include <Shark/ISharkByte.h>

namespace middleware::parameter
{
class IConfigBuilder;
class IPublish;
class IService;
}
namespace Shark
{
class ISharkByteRetriever;
}
namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
class SharkParameterDataPublisher
{
public:
	static std::move_only_function<void(middleware::parameter::IService&)> Create(
		SharkToMiddlewarePublisher const& sharkToMiddlewarePublisher,
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);
	SharkParameterDataPublisher(
		SharkToMiddlewarePublisher const& sharkToMiddlewarePublisher);

	void Initialize(
		Shark::ISharkByteRetriever const& sharkByteRetriever,
		middleware::parameter::IService& parameterService);

private:
	void Publish(
		middleware::parameter::IPublish& publisher,
		Shark::SharkByteValue const& value);

	SharkToMiddlewarePublisher const m_sharkToMiddlewarePublisher;
	Shark::SharkByteSubscription m_subscription{};
};
}
}