/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pid parameter data writer

#pragma once

#include "Identifiers/PidDefinition.h"
#include <IParameterService.h>
#include <Shark/IWriteSharkByte.h>
#include <SharkConfiguration.pb.h>
#include <Utilities/nice_ptr.h>
#include <middleware_parameter.pb.h>
#include <mutex>
#include <vector>

namespace middleware::parameter
{
class IConfigBuilder;
class IService;
}
namespace Shark
{
class IWriteSharkByteRetriever;
}

namespace Jaws
{
class DependencyContainer;

namespace Middleware
{

class MultiBytePidParameterDataWriter
{
public:
	static std::move_only_function<void(middleware::parameter::IService&)> Create(
		cat::shark::J1939DataLink::PeerNode::BasicReadWrite::BasicReadWritePid const& basicReadWritePidEntry,
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);

	MultiBytePidParameterDataWriter(
		std::string const& id,
		Identifiers::MultiBytePidDefinition const& pidDefinition);
	void Initialize(
		Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever,
		middleware::parameter::IService& parameterService);
	std::optional<cat::middleware::parameter::Data> OnWrite(
		uint_least16_t key,
		middleware::parameter::Identity const& id,
		cat::middleware::parameter::Data const& data);
private:
	std::optional<std::vector<uint8_t>> GetDataToWrite(cat::middleware::parameter::Data const& data) const;
	void OnWriteCompleted(Shark::SharkByteValue const& value);
	cat::middleware::parameter::Data CreateReplyData(Shark::SharkByteValue const& value) const;
	bool DataIsValidType(cat::middleware::parameter::Data const& data) const;

	std::string const m_id;
	Identifiers::MultiBytePidDefinition const m_pidDefinition;
	Utilities::nice_ptr<middleware::parameter::IService> m_spParameterService{};
	Utilities::nice_ptr<Shark::IWriteSharkByte> m_spWriteSharkByte{};
	std::optional<uint_least16_t> m_activeKey{};
	std::mutex m_mutex{};
};
}
}