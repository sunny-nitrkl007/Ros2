/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See RefreshableSharkByteReadServer.h

#include "RefreshableSharkByteReadServer.h"
#include "DependencyContainer.h"
#include "IConfigBuilder.h"
#include "IParameterService.h"
#include <Shark/ISharkByteRetriever.h>
#include "Log.h"

using Data = cat::middleware::parameter::Data;

namespace Jaws
{
namespace Middleware
{
std::move_only_function<void(middleware::parameter::IService&)> RefreshableSharkByteReadServer::Create(
	std::string const& middlewareId,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	LOG_DEBUG_TAG(Log::Read, middlewareId << ": Creating RefreshableSharkByteReadServer");

	auto spParameterDataPublisher = std::make_shared<RefreshableSharkByteReadServer>(middlewareId);

	configBuilder.AddServerRead(
		middlewareId.c_str(),
		[spParameterDataPublisher](uint_least16_t key, middleware::parameter::Identity const& id)
			{
				return spParameterDataPublisher->OnRead(key, id);
			});

	auto& sharkByteRetriever = dependencyContainer.GetISharkByteRetriever();
	return [spParameterDataPublisher = std::move(spParameterDataPublisher), &sharkByteRetriever](middleware::parameter::IService& parameterService) noexcept
		{
			spParameterDataPublisher->Initialize(sharkByteRetriever, parameterService);
		};
}

RefreshableSharkByteReadServer::RefreshableSharkByteReadServer(std::string const& id)
	: m_id{id}
{
}
void RefreshableSharkByteReadServer::Initialize(
	Shark::ISharkByteRetriever const& sharkByteRetriever,
	middleware::parameter::IService& parameterService)
{
	assert(!m_spParameterService);
	assert(!m_spSharkByte);
	m_spParameterService = &parameterService;
	m_spSharkByte = &sharkByteRetriever.Retrieve(m_id);
	m_subscription = m_spSharkByte->SubscribeToValues(
		[this](Shark::SharkByteValue const& value)
		{
			OnValueChanged(value);
		});
}
std::optional<Data> RefreshableSharkByteReadServer::OnRead(
	uint_least16_t key,
	[[maybe_unused]] middleware::parameter::Identity const& id)
{
	LOG_INFO_LOW_TAG(Log::Read, id << ": OnRead(key=" << key << ")");
	assert(m_id == id);
	assert(m_spSharkByte);

	{
		// Read keys are stored so they can be replied to when the SharkByte value changes.
		// We reply to all active reads with the first value received. Any subsequent value
		// changes will be ignored until a new read request is made.
		std::lock_guard<std::mutex> lock{m_mutex};
		m_keys.push_back(key);
	}

	// We refresh even if there is an active Read in case the last refresh never completed.
	m_spSharkByte->Refresh();

	return {}; // Indicate async mode
}
void RefreshableSharkByteReadServer::OnValueChanged(Shark::SharkByteValue const& value)
{
	LOG_INFO_LOW_TAG(Log::Read, m_id << ": OnValueChanged(" << (value.has_value() ? "valid" : "invalid") << " value)");

	auto data = CreateReplyData(value);
	ReplyToAll(data);
}
Data RefreshableSharkByteReadServer::CreateReplyData(Shark::SharkByteValue const& value) const
{
	Data data{};
	auto quality = cat::middleware::parameter::Quality::QUALITY_BAD;
	if (value)
	{
		quality = cat::middleware::parameter::Quality::QUALITY_GOOD;
		data.mutable_value()->set_binary_value(value->data(), value->size());
	}
	data.set_quality(quality);

	return data;
}
void RefreshableSharkByteReadServer::ReplyToAll(Data const& data)
{
	assert(m_spParameterService);
	// Swap the keys so we can release the lock quickly.
	std::vector<uint_least16_t> keysToReplyTo{};
	{
		std::lock_guard<std::mutex> lock{m_mutex};
		keysToReplyTo.swap(m_keys);
	}

	for (auto const& key : keysToReplyTo)
	{
		LOG_DEBUG_TAG(Log::Read, m_id << ": Replying to key " << key << " with value " << data.DebugString());
		m_spParameterService->Reply(key, data);
	}
}
}
}
