/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pid Parameter Data Publisher

#pragma once

#include "Identifiers/IPidValueDecoder.h"
#include "Identifiers/PidDefinition.h"
#include <Shark/ISharkByte.h>

namespace middleware::parameter
{
class IConfigBuilder;
class IPublish;
class IService;
}
namespace Shark
{
class ISharkByteRetriever;
}
namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
class PidParameterDataPublisher
{
public:
	static std::move_only_function<void(middleware::parameter::IService&)> Create(
		unsigned pid,
		std::string const& publishId,
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);
	PidParameterDataPublisher(
		std::string const& publishId,
		Identifiers::PidDefinition const& pidDefinition,
		Identifiers::IPidValueDecoder const& pidValueDecoder);

	void Initialize(
		Shark::ISharkByteRetriever const& sharkByteRetriever,
		middleware::parameter::IService& parameterService);

private:
	void Publish(
		middleware::parameter::IPublish& publisher,
		Shark::SharkByteValue const& value);

	std::string const m_publishId;
	Identifiers::PidDefinition const m_pidDefinition;
	Identifiers::IPidValueDecoder const& m_pidValueDecoder;
	Shark::SharkByteSubscription m_subscription{};
};
}
}