/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Refreshable Shark Byte Read Server

#pragma once

#include <IParameterService.h>
#include <Shark/ISharkByte.h>
#include <Utilities/nice_ptr.h>
#include <middleware_parameter.pb.h>
#include <mutex>
#include <vector>

namespace middleware::parameter
{
class IConfigBuilder;
class IService;
}
namespace Shark
{
class ISharkByteRetriever;
}

namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
// IMPORTANT REQUIREMENT: The SharkByte must send every value it receives, even if the value hasn't changed.
//                        Otherwise reads will timeout if, say, the same data is read twice in a row or the
//                        SharkByteValue is continually invalid.
class RefreshableSharkByteReadServer
{
public:
	static std::move_only_function<void(middleware::parameter::IService&)> Create(
		std::string const& middlewareId,
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);

	RefreshableSharkByteReadServer(std::string const& id);
	void Initialize(
		Shark::ISharkByteRetriever const& sharkByteRetriever,
		middleware::parameter::IService& parameterService);
	std::optional<cat::middleware::parameter::Data> OnRead(
		uint_least16_t key,
		middleware::parameter::Identity const& id);
private:
	void OnValueChanged(Shark::SharkByteValue const& value);
	cat::middleware::parameter::Data CreateReplyData(Shark::SharkByteValue const& value) const;
	void ReplyToAll(cat::middleware::parameter::Data const& data);

	std::string const m_id;
	Utilities::nice_ptr<middleware::parameter::IService> m_spParameterService{};
	Utilities::nice_ptr<Shark::ISharkByte> m_spSharkByte{};
	Shark::SharkByteSubscription m_subscription{};
	std::vector<uint_least16_t> m_keys{};
	std::mutex m_mutex{};
};
}
}