/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See MultiBytePidParameterDataWriter.h

#include "MultiBytePidParameterDataWriter.h"
#include "DependencyContainer.h"
#include "IConfigBuilder.h"
#include "Identifiers/IPidDefinitionRetriever.h"
#include "IParameterService.h"
#include "Log.h"
#include <Shark/IWriteSharkByteRetriever.h>

using Data = cat::middleware::parameter::Data;

namespace
{
cat::middleware::parameter::Data MakeBadData()
{
	cat::middleware::parameter::Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_BAD);
	return data;
}
}

namespace Jaws
{
namespace Middleware
{
std::move_only_function<void(middleware::parameter::IService&)> MultiBytePidParameterDataWriter::Create(
	cat::shark::J1939DataLink::PeerNode::BasicReadWrite::BasicReadWritePid const& basicReadWritePidEntry,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& pidDefinition = dependencyContainer.GetIPidDefinitionRetriever().RetrieveMultiBytePid(basicReadWritePidEntry.pid());
	auto const& middlewareId = basicReadWritePidEntry.middleware_id();
	LOG_DEBUG_TAG(Log::Write, middlewareId << ": Creating MultiBytePidParameterDataWriter");

	auto spPidParameterDataWriter = std::make_shared<MultiBytePidParameterDataWriter>(
		middlewareId,
		pidDefinition);

	configBuilder.AddServerWrite(
		middlewareId.c_str(),
		[spPidParameterDataWriter](uint_least16_t key, middleware::parameter::Identity const& identity, cat::middleware::parameter::Data const& data)
			{
				return spPidParameterDataWriter->OnWrite(key, identity, data);
			});

	auto& writeSharkByteRetriever = dependencyContainer.GetIWriteSharkByteRetriever();
	return [spPidParameterDataWriter = std::move(spPidParameterDataWriter), &writeSharkByteRetriever](middleware::parameter::IService& parameterService) noexcept
		{
			spPidParameterDataWriter->Initialize(writeSharkByteRetriever, parameterService);
		};
}

MultiBytePidParameterDataWriter::MultiBytePidParameterDataWriter(
	std::string const& id,
	Identifiers::MultiBytePidDefinition const& pidDefinition)
	: m_id{id}
	, m_pidDefinition{pidDefinition}
{
}
void MultiBytePidParameterDataWriter::Initialize(
	Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever,
	middleware::parameter::IService& parameterService)
{
	assert(!m_spParameterService);
	assert(!m_spWriteSharkByte);
	m_spParameterService = &parameterService;
	m_spWriteSharkByte = &writeSharkByteRetriever.Retrieve(m_id);
}
std::optional<Data> MultiBytePidParameterDataWriter::OnWrite(
	uint_least16_t key,
	[[maybe_unused]] middleware::parameter::Identity const& id,
	cat::middleware::parameter::Data const& data)
{

	LOG_INFO_LOW_TAG(Log::Write, id << ": OnWrite(key=" << key << ")");
	assert(m_id == id);
	assert(m_spWriteSharkByte);

	std::optional<Data> returnData{MakeBadData()};
	auto&& dataToWrite = GetDataToWrite(data);
	if (dataToWrite)
	{
		std::lock_guard<std::mutex> lock{m_mutex};
		if (m_activeKey)
		{
			LOG_INFO_HIGH_TAG(Log::Write, id << ": Received write while another write is active.");
		}
		else
		{
			m_activeKey = key;
			m_spWriteSharkByte->Write(*dataToWrite,
				[this](Shark::SharkByteValue const& value)
				{
					OnWriteCompleted(value);
				});
			returnData = std::nullopt; // return nullopt to indicate async completion
		}
	}

	return returnData;
}
std::optional<std::vector<uint8_t>> MultiBytePidParameterDataWriter::GetDataToWrite(cat::middleware::parameter::Data const& data) const
{
	std::optional<std::vector<uint8_t>> writeData{};
	if (data.has_value() && DataIsValidType(data))
	{
		if (data.value().has_binary_value())
		{
			auto const& binaryValue = data.value().binary_value();
			auto const length = static_cast<unsigned>(binaryValue.size());
			if (std::clamp(length, m_pidDefinition.MinimumParameterDataLength(), m_pidDefinition.MaximumParameterDataLength()) == length)
			{
				writeData.emplace(binaryValue.begin(), binaryValue.end());
			}
			else
			{
				LOG_INFO_HIGH_TAG(Log::Write, "Binary length is not within the limits defined by the multi-byte pid definition");
			}
		}
		else
		{
			assert(data.value().has_string_value());
			auto const& stringValue = data.value().string_value();
			auto const length = static_cast<unsigned>(stringValue.size());
			if (std::clamp(length, m_pidDefinition.MinimumParameterDataLength(), m_pidDefinition.MaximumParameterDataLength()) == length)
			{
				writeData.emplace(stringValue.begin(), stringValue.end());
			}
			else
			{
				LOG_INFO_HIGH_TAG(Log::Write, "String length is not within the limits defined by the multi-byte pid definition");
			}
		}
	}
	else
	{
		LOG_INFO_HIGH_TAG(Log::Write, "Write data is invalid or is not the correct type for the PID definition");
	}
	return writeData;

}

void MultiBytePidParameterDataWriter::OnWriteCompleted(Shark::SharkByteValue const& value)
{
	LOG_INFO_HIGH_TAG(Log::Write, m_id << ": OnWriteCompleted(" << (value.has_value() ? "valid" : "invalid") << " value)");
	assert(m_spParameterService);

	auto data = CreateReplyData(value);
	// Swap the keys so we can release the lock quickly.
	std::optional<uint_least16_t> keyToReplyTo{};
	{
		std::lock_guard<std::mutex> lock{m_mutex};
		keyToReplyTo.swap(m_activeKey);
	}

	if (keyToReplyTo)
	{
		LOG_DEBUG_TAG(Log::Write, m_id << ": Replying to key " << *keyToReplyTo << " with value " << data.DebugString());
		m_spParameterService->Reply(*keyToReplyTo, data);
	}
	else
	{
		LOG_WARNING_TAG(Log::Write, m_id << ": No active write key to reply to in OnWriteCompleted");
	}
}
Data MultiBytePidParameterDataWriter::CreateReplyData(Shark::SharkByteValue const& value) const
{
	Data data{};
	auto quality = cat::middleware::parameter::Quality::QUALITY_BAD;
	if (value)
	{
		quality = cat::middleware::parameter::Quality::QUALITY_GOOD;
		if (m_pidDefinition.IsBinary())
		{
			data.mutable_value()->set_binary_value((*value).data(), (*value).size());
		}
		else
		{
			assert(m_pidDefinition.IsString());
			data.mutable_value()->set_string_value(std::string{(*value).begin(), (*value).end()});
		}
	}
	data.set_quality(quality);

	return data;
}
bool MultiBytePidParameterDataWriter::DataIsValidType(cat::middleware::parameter::Data const& data) const
{
	bool isValidType = false;
	auto const& value = data.value();
	if ((value.has_binary_value() && m_pidDefinition.IsBinary()) ||
		(value.has_string_value() && m_pidDefinition.IsString()))
	{
		isValidType = true;
	}
	else
	{
		LOG_INFO_HIGH_TAG(Log::Write, "Data type does not match multi-byte pid definition type");
	}

	return isValidType;
}
}
}
