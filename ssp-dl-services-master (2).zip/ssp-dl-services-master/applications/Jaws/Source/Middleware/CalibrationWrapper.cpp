/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See CalibrationWrapper.h

#include "CalibrationWrapper.h"
#include "DependencyContainer.h"
#include "InternalMiddlewareIds.h"
#include "Log.h"
#include "Middleware/SharkToMiddlewareDefinitions.h"
#include <CodesFactory.h>
#include <SharkConfiguration.pb.h>
#include <Shark/ISharkByteRetriever.h>
#include <Shark/IWriteSharkByte.h>
#include <Shark/IWriteSharkByteRetriever.h>
#include <Shark/SharkByteDetails.h>
#include <Utilities/ArrayToHexString.h>

using Data = cat::middleware::parameter::Data;
using namespace Shark::SharkByteDetails::Calibrations;

namespace Jaws
{
namespace Middleware
{
namespace
{
Data MakeBooleanData(bool value)
{
	Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	data.mutable_value()->set_boolean_value(value);
	return data;
}

Utilities::nice_ptr<CalibrationWrapper> n_spCalibrationWrapper{};

constexpr SharkToMiddlewarePublisher n_calibrationStatusPublisher
{
	Calibration::CalibrationStatus(),
	Status::SharkByteId(),
	cat::shark::UNIT_NONE,
	Identifiers::String
};
const SharkToMiddlewareWriter n_calibrationCommandWriter
{
	Calibration::CalibrationCommand(),
	[](Data const& data, IWriteReply& writeReply) -> std::optional<cat::middleware::parameter::Data>
	{
		assert(n_spCalibrationWrapper);
		return n_spCalibrationWrapper->SendCalibrationCommand(data, writeReply);
	}
};
bool J1939DataLinkConfigHasCalibrations(cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	auto const& peerNodes = j1939DataLinkConfig.peer_nodes();
	return std::any_of(peerNodes.begin(),peerNodes.end(),
		[](auto const& peerNode)
		{
			return peerNode.has_calibration_services() &&
			       (peerNode.calibration_services().calibrations().size() > 0 ||
			        peerNode.calibration_services().service_tests().size() > 0);
		});
}
}

bool CalibrationWrapper::ShouldBeCreated(DependencyContainer const& dependencyContainer)
{
	auto const& j1939DataLinks = dependencyContainer.GetSharkConfig().j1939_data_links();
	return std::any_of(j1939DataLinks.begin(), j1939DataLinks.end(),
		[](auto const& j1939DataLinkConfig)
		{
			return J1939DataLinkConfigHasCalibrations(j1939DataLinkConfig);
		});
}
std::function<void()> CalibrationWrapper::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	auto const& writeSharkByteRetriever = dependencyContainer.GetIWriteSharkByteRetriever();
	auto&& spCalibrationWrapper = std::make_shared<CalibrationWrapper>();
	auto& sharkToMiddlewareDefinitions = dependencyContainer.GetSharkToMiddlewareDefinitions();
	sharkToMiddlewareDefinitions.AddPublisher(n_calibrationStatusPublisher);
	sharkToMiddlewareDefinitions.AddWriter(n_calibrationCommandWriter);

	return [spCalibrationWrapper, &writeSharkByteRetriever]() noexcept
		{
			spCalibrationWrapper->Initialize(writeSharkByteRetriever);
		};
}
CalibrationWrapper::CalibrationWrapper() noexcept
{
	assert(!n_spCalibrationWrapper);
	n_spCalibrationWrapper = this;
}
CalibrationWrapper::~CalibrationWrapper()
{
	assert(n_spCalibrationWrapper == this);
	n_spCalibrationWrapper = nullptr;
}
void CalibrationWrapper::Initialize(Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever)
{
	assert(!m_spWriteSharkByte);
	m_spWriteSharkByte = &writeSharkByteRetriever.Retrieve(::Command::SharkByteId());
}
std::optional<Data> CalibrationWrapper::SendCalibrationCommand(
	Data const& data,
	IWriteReply& writeReply)
{
	LOG_INFO_HIGH_TAG(Log::Calibrations, "Jaws - CalibrationWrapper::CalibrationCommand called");
	return ProcessWrite(data, writeReply);
}
std::optional<Data> CalibrationWrapper::ProcessWrite(
	Data const& data,
	IWriteReply& writeReply)
{
	auto dataToWrite = std::vector<uint8_t>{data.value().string_value().begin(), data.value().string_value().end()};
	m_spWriteSharkByte->Write(dataToWrite,
		[&writeReply](Shark::SharkByteValue const& statusResponse)
		{
			bool replyValue = false;
			if (statusResponse && (statusResponse == Shark::TrueSharkByteValue()))
			{
				replyValue = true;
			}
			writeReply.Reply(MakeBooleanData(replyValue));
		});
	return std::nullopt;
}
}
}