/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// MachineSecuritySystem Wrapper class

#pragma once

#include <middleware_parameter.pb.h>
#include <Utilities/nice_ptr.h>
#include <functional>

namespace middleware::diagnostics
{
class IService;
}
namespace Shark
{
class ISharkByteRetriever;
class IWriteSharkByteRetriever;
}
namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
class IWriteReply;

class MachineSecuritySystemWrapper
{
public:
	static bool ShouldBeCreated(DependencyContainer const& dependencyContainer);
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);

	MachineSecuritySystemWrapper(
		Shark::ISharkByteRetriever const& sharkByteRetriever,
		Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever) noexcept;
	~MachineSecuritySystemWrapper();

	std::optional<cat::middleware::parameter::Data> RequestCurrentOperator(
		cat::middleware::parameter::Data const& data,
		IWriteReply& writeReply);
	std::optional<cat::middleware::parameter::Data> LogIn(
		cat::middleware::parameter::Data const& data,
		IWriteReply& writeReply);
	std::optional<cat::middleware::parameter::Data> LogOut(
		cat::middleware::parameter::Data const& data,
		IWriteReply& writeReply);
	std::optional<cat::middleware::parameter::Data> Lock(
		cat::middleware::parameter::Data const& data,
		IWriteReply& writeReply);
	std::optional<cat::middleware::parameter::Data> Unlock(
		cat::middleware::parameter::Data const& data,
		IWriteReply& writeReply);

private:
	std::optional<cat::middleware::parameter::Data> ProcessWrite(
		cat::middleware::parameter::Data const& data,
		IWriteReply& writeReply,
		std::string const& writeSharkByteId,
		std::string const& statusSharkByteId);

	Shark::ISharkByteRetriever const& m_sharkByteRetriever;
	Shark::IWriteSharkByteRetriever const& m_writeSharkByteRetriever;
};
}
}
