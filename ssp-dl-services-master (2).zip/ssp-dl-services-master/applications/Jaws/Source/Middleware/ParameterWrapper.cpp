/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See ParameterWrapper.h

#include "ParameterWrapper.h"
#include "ConfigurationReceiver.h"
#include "DependencyContainer.h"
#include "IConfigBuilder.h"
#include "IInitializationGate.h"
#include "InitializationGatingConfigBuilder.h"
#include "InternalCodeSubscriber.h"
#include "Middleware/SharkToMiddlewareDefinitions.h"
#include "MultiBytePidParameterDataWriter.h"
#include "ParameterServiceFactory.h"
#include "PidParameterDataPublisher.h"
#include "PidParameterDataWriter.h"
#include "PgnParameterDataPublisher.h"
#include "RawDataWriteServer.h"
#include "PgnParameterDataSubscriber.h"
#include "RefreshableSharkByteReadServer.h"
#include "SharkParameterDataPublisher.h"
#include "SharkParameterDataWriter.h"

using AdtPids = ::google::protobuf::RepeatedPtrField<::cat::shark::J1939DataLink_PeerNode_Adt_AdtPid>;
using PgbPids = ::google::protobuf::RepeatedPtrField<::cat::shark::J1939DataLink_PeerNode_Pgb_PgbPid>;

namespace Jaws
{
using namespace Identifiers;

namespace Middleware
{
namespace
{
template <typename T>
void CreatePidPublishers(
	ParameterInitializers& initializers,
	DependencyContainer const& dependencyContainer,
	T configArray,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	for (auto& entry : configArray)
	{
		initializers.push_back(PidParameterDataPublisher::Create(
			entry.pid(),
			entry.middleware_id(),
			dependencyContainer,
			configBuilder));
	}
}
void CreatePidPublishers(
	ParameterInitializers& initializers,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& j1939DataLinks = dependencyContainer.GetSharkConfig().j1939_data_links();
	for (auto const& j1939DataLink : j1939DataLinks)
	{
		for (auto const& peerNode : j1939DataLink.peer_nodes())
		{
			if (peerNode.has_adt())
			{
				CreatePidPublishers<AdtPids>(
					initializers,
					dependencyContainer,
					peerNode.adt().adt_pids(),
					configBuilder);
			}

			if (peerNode.has_pgb())
			{
				CreatePidPublishers<PgbPids>(
					initializers,
					dependencyContainer,
					peerNode.pgb().pgb_pids(),
					configBuilder);
			}
		}
	}
}
void CreatePgnSubscribers(
	ParameterInitializers& initializers,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& j1939DataLinks = dependencyContainer.GetSharkConfig().j1939_data_links();
	for (auto const& j1939DataLink : j1939DataLinks)
	{
		for (auto const& transmitBroadcastPgn : j1939DataLink.transmit_broadcast_pgns())
		{
			initializers.push_back(PgnParameterDataSubscriber::Create(
				transmitBroadcastPgn,
				dependencyContainer,
				configBuilder));
		}
	}
}
void CreatePgnPublishersAndReadServers(
	ParameterInitializers& initializers,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& j1939DataLinks = dependencyContainer.GetSharkConfig().j1939_data_links();
	for (auto const& j1939DataLink : j1939DataLinks)
	{
		for (auto const& peerNode : j1939DataLink.peer_nodes())
		{
			if (peerNode.has_pgn())
			{
				for (auto const& pgnBroadcast : peerNode.pgn().receive_broadcast_pgns())
				{
					initializers.push_back(PgnParameterDataPublisher::Create(
						pgnBroadcast,
						dependencyContainer,
						configBuilder));
				}

				for (auto const& pgnOnRequest : peerNode.pgn().receive_on_request_pgns())
				{
					initializers.push_back(RefreshableSharkByteReadServer::Create(
						pgnOnRequest.middleware_id(),
						dependencyContainer,
						configBuilder));
				}
			}
		}
	}
}
void CreateBdtReadServers(
	ParameterInitializers& initializers,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& j1939DataLinks = dependencyContainer.GetSharkConfig().j1939_data_links();
	for (auto const& j1939DataLink : j1939DataLinks)
	{
		for (auto const& peerNode : j1939DataLink.peer_nodes())
		{
			if (peerNode.has_bdt())
			{
				for (auto const& bdtType : peerNode.bdt().bdt_types())
				{
					if (bdtType.access_mode() == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_READ_ONLY ||
					    bdtType.access_mode() == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_READ_WRITE)
					{
						initializers.push_back(RefreshableSharkByteReadServer::Create(
							bdtType.middleware_id(),
							dependencyContainer,
							configBuilder));
					}
				}
			}
		}
	}
}
void CreateBdtWriteServers(
	ParameterInitializers& initializers,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& j1939DataLinks = dependencyContainer.GetSharkConfig().j1939_data_links();
	for (auto const& j1939DataLink : j1939DataLinks)
	{
		for (auto const& peerNode : j1939DataLink.peer_nodes())
		{
			if (peerNode.has_bdt())
			{
				for (auto const& bdtType : peerNode.bdt().bdt_types())
				{
					if (bdtType.access_mode() == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_WRITE_ONLY ||
					    bdtType.access_mode() == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_READ_WRITE)
					{
						initializers.push_back(RawDataWriteServer::Create(
							bdtType,
							dependencyContainer,
							configBuilder));
					}
				}
			}
		}
	}
}
void CreateSharkPublishers(
	ParameterInitializers& initializers,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& sharkToMiddlewarePublishers = dependencyContainer.GetSharkToMiddlewareDefinitions().TakePublishers();
	for (auto const& definition : sharkToMiddlewarePublishers)
	{
		initializers.push_back(SharkParameterDataPublisher::Create(
			definition,
			dependencyContainer,
			configBuilder));
	}
}
void CreateSharkWriters(
	ParameterInitializers& initializers,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& sharkToMiddlewareWriters = dependencyContainer.GetSharkToMiddlewareDefinitions().TakeWriters();
	for (auto const& definition : sharkToMiddlewareWriters)
	{
		initializers.push_back(SharkParameterDataWriter::Create(
			definition,
			dependencyContainer,
			configBuilder));
	}
}
void CreatePidWriters(
	ParameterInitializers& initializers,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& j1939DataLinks = dependencyContainer.GetSharkConfig().j1939_data_links();
	for (auto const& j1939DataLink : j1939DataLinks)
	{
		for (auto const& peerNode : j1939DataLink.peer_nodes())
		{
			if (peerNode.has_basic_read_write())
			{
				for (auto const& basicReadWritePid : peerNode.basic_read_write().basic_read_write_pids())
				{
					Config::Pid pid{basicReadWritePid.pid()};
					if (pid.IsMultiByte())
					{
						initializers.push_back(MultiBytePidParameterDataWriter::Create(
							basicReadWritePid,
							dependencyContainer,
							configBuilder));
					}
					else
					{
						initializers.push_back(PidParameterDataWriter::Create(
							basicReadWritePid,
							dependencyContainer,
							configBuilder));
					}
				}
			}
		}
	}
}
void CreateInternalCodeSubscribers(
	ParameterInitializers& initializers,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& sharkConfig = dependencyContainer.GetSharkConfig();
	if (sharkConfig.has_diagnostics())
	{
		for (auto const& internalCode : sharkConfig.diagnostics().internal_code_list().internal_codes())
		{
			initializers.push_back(InternalCodeSubscriber::Create(
				internalCode,
				dependencyContainer,
				configBuilder));
		}
	}
}

constexpr auto n_identity{"DataLinkEngine"};

// Set this to 4 to output every parameter value.
//constexpr uint8_t n_middlewareLogLevel = 4; // ERROR|WARNINGS|INFO
constexpr uint8_t n_middlewareLogLevel = 3; // ERROR|WARNINGS|INFO
}

ParameterInitializers ParameterWrapper::CreateParameterInitializers(
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	ParameterInitializers initializers{};
	auto sharkConfig = dependencyContainer.GetSharkConfig();
	if (sharkConfig.j1939_data_links_size() > 0)
	{
		auto&& createFunctions =
		{
			CreatePidPublishers,
			CreatePgnPublishersAndReadServers,
			CreatePgnSubscribers,
			CreateBdtReadServers,
			CreateBdtWriteServers,
			CreateSharkPublishers,
			CreateSharkWriters,
			CreatePidWriters,
			CreateInternalCodeSubscribers
		};
		for (auto const& createFunction : createFunctions)
		{
			createFunction(
				initializers,
				dependencyContainer,
				configBuilder);
		}
	}
	return initializers;
}

std::function<void()> ParameterWrapper::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	// This should really be refactored into its own Initializer, maybe MiddlewareLogger. Ideally
	// middleware would be refactored to call a function instead of writing directly to an ostream.
	// Then we could integrate it into the boost logging system and map its log level to one of
	// ours, while also giving it a "middleware" tag.
	middleware::parameter::Factory::SetLogLevel(std::cout, n_middlewareLogLevel);

	auto& initializationGate = dependencyContainer.GetIInitializationGate();
	auto spGatingConfigBuilder = std::make_unique<InitializationGatingConfigBuilder>(
		middleware::parameter::IConfigBuilder::Create(n_identity),
		initializationGate);
	auto& gatingConfigBuilder = *spGatingConfigBuilder;
	ServiceFactory serviceFactory =
		[spConfigBuilder = std::move(spGatingConfigBuilder)]() mutable
		{
			return middleware::parameter::Factory::CreateParameterService(spConfigBuilder->ReleaseInnerBuilder());
		};

	auto initializers = CreateParameterInitializers(dependencyContainer, gatingConfigBuilder);

	auto spConfigurationReceiver = ConfigurationReceiver::Create(dependencyContainer, gatingConfigBuilder);

	auto spParameterWrapper = std::make_shared<ParameterWrapper>(
		std::move(serviceFactory),
		std::move(initializers),
		gatingConfigBuilder);

	return [spParameterWrapper, spConfigurationReceiver]() noexcept
		{
			spParameterWrapper->Initialize();
		};
}

ParameterWrapper::ParameterWrapper(
	ServiceFactory&& serviceFactory,
	ParameterInitializers&& parameterInitializers,
	IServiceWaiter& serviceWaiter) noexcept
	: m_serviceFactory{std::move(serviceFactory)}
	, m_parameterInitializers{std::move(parameterInitializers)}
	, m_serviceWaiter{serviceWaiter}
{
	assert(m_serviceFactory);
}
void ParameterWrapper::Initialize()
{
	assert(!m_spParameterService);

	m_spParameterService = m_serviceFactory();
	for (auto&& initializer : m_parameterInitializers)
	{
		initializer(*m_spParameterService);
	}
	m_serviceWaiter.SetReady(*m_spParameterService);
}
}
}