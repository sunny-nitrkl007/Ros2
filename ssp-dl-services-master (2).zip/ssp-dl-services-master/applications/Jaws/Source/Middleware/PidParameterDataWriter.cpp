/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PidParameterDataWriter.h

#include "PidParameterDataWriter.h"
#include "DependencyContainer.h"
#include "IConfigBuilder.h"
#include "Identifiers/IPidDefinitionRetriever.h"
#include "Identifiers/IPidValueEncoder.h"
#include "IParameterService.h"
#include "Log.h"
#include <Shark/IWriteSharkByteRetriever.h>

using Data = cat::middleware::parameter::Data;

namespace
{
cat::middleware::parameter::Data MakeBadData()
{
	cat::middleware::parameter::Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_BAD);
	return data;
}
}

namespace Jaws
{
namespace Middleware
{
std::move_only_function<void(middleware::parameter::IService&)> PidParameterDataWriter::Create(
	cat::shark::J1939DataLink::PeerNode::BasicReadWrite::BasicReadWritePid const& basicReadWritePidEntry,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& pidDefinition = dependencyContainer.GetIPidDefinitionRetriever().RetrievePid(basicReadWritePidEntry.pid());
	auto const& middlewareId = basicReadWritePidEntry.middleware_id();
	LOG_DEBUG_TAG(Log::Write, middlewareId << ": Creating PidParameterDataWriter");

	auto spPidParameterDataWriter = std::make_shared<PidParameterDataWriter>(
		middlewareId,
		pidDefinition,
		dependencyContainer.GetIPidValueEncoder());

	configBuilder.AddServerWrite(
		middlewareId.c_str(),
		[spPidParameterDataWriter](uint_least16_t key, middleware::parameter::Identity const& identity, cat::middleware::parameter::Data const& data)
			{
				return spPidParameterDataWriter->OnWrite(key, identity, data);
			});

	auto& writeSharkByteRetriever = dependencyContainer.GetIWriteSharkByteRetriever();
	return [spPidParameterDataWriter = std::move(spPidParameterDataWriter), &writeSharkByteRetriever](middleware::parameter::IService& parameterService) noexcept
		{
			spPidParameterDataWriter->Initialize(writeSharkByteRetriever, parameterService);
		};
}

PidParameterDataWriter::PidParameterDataWriter(
	std::string const& id,
	Identifiers::PidDefinition const& pidDefinition,
	Identifiers::IPidValueEncoder const& pidValueEncoder)
	: m_id{id}
	, m_pidDefinition{pidDefinition}
	, m_pidValueEncoder{pidValueEncoder}
{
}
void PidParameterDataWriter::Initialize(
	Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever,
	middleware::parameter::IService& parameterService)
{
	assert(!m_spParameterService);
	assert(!m_spWriteSharkByte);
	m_spParameterService = &parameterService;
	m_spWriteSharkByte = &writeSharkByteRetriever.Retrieve(m_id);
}
std::optional<Data> PidParameterDataWriter::OnWrite(
	uint_least16_t key,
	[[maybe_unused]] middleware::parameter::Identity const& id,
	cat::middleware::parameter::Data const& data)
{
	LOG_INFO_LOW_TAG(Log::Write, id << ": OnWrite(key=" << key << ")");
	assert(m_id == id);
	assert(m_spWriteSharkByte);

	std::optional<Data> returnData{MakeBadData()};
	auto&& dataToWrite = GetDataToWrite(data);
	if (dataToWrite)
	{
		std::lock_guard<std::mutex> lock{m_mutex};
		if (m_activeKey)
		{
			LOG_INFO_HIGH_TAG(Log::Write, id << ": Received write while another write is active.");
		}
		else
		{
			m_activeKey = key;
			m_spWriteSharkByte->Write(*dataToWrite,
				[this](Shark::SharkByteValue const& value)
				{
					OnWriteCompleted(value);
				});
			returnData = std::nullopt; // return nullopt to indicate async completion
		}
	}

	return returnData;
}
std::optional<std::vector<uint8_t>> PidParameterDataWriter::GetDataToWrite(cat::middleware::parameter::Data const& data) const
{
	if (!data.has_value())
	{
		LOG_INFO_HIGH_TAG(Log::Write, "Write data has no value");
		return std::nullopt;
	}

	Identifiers::FixedLengthPidValue value{};
	auto const& dataValue = data.value();
	if (dataValue.has_double_value())
	{
		value = dataValue.double_value();
	}
	else if (dataValue.has_uinteger64_value())
	{
		value = dataValue.uinteger64_value();
	}
	else if (dataValue.has_binary_value())
	{
		auto const& binaryValue = dataValue.binary_value();
		value = std::vector<uint8_t>(binaryValue.begin(), binaryValue.end());
	}
	else
	{
		LOG_INFO_HIGH_TAG(Log::Write, "Write data is not a supported type");
		return std::nullopt;
	}

	auto encoded = m_pidValueEncoder.Encode(m_pidDefinition, value);
	std::optional<std::vector<uint8_t>> result{};
	if (encoded)
	{
		result.emplace(std::move(*encoded));
	}

	return result;
}

void PidParameterDataWriter::OnWriteCompleted(Shark::SharkByteValue const& value)
{
	LOG_INFO_HIGH_TAG(Log::Write, m_id << ": OnWriteCompleted(" << (value.has_value() ? "valid" : "invalid") << " value)");
	assert(m_spParameterService);

	auto data = CreateReplyData(value);
	// Swap the keys so we can release the lock quickly.
	std::optional<uint_least16_t> keyToReplyTo{};
	{
		std::lock_guard<std::mutex> lock{m_mutex};
		keyToReplyTo.swap(m_activeKey);
	}

	if (keyToReplyTo)
	{
		LOG_DEBUG_TAG(Log::Write, m_id << ": Replying to key " << *keyToReplyTo << " with value " << data.DebugString());
		m_spParameterService->Reply(*keyToReplyTo, data);
	}
	else
	{
		LOG_WARNING_TAG(Log::Write, m_id << ": No active write key to reply to in OnWriteCompleted");
	}
}
Data PidParameterDataWriter::CreateReplyData(Shark::SharkByteValue const& value) const
{
	Data data{};
	auto quality = cat::middleware::parameter::Quality::QUALITY_BAD;
	if (value)
	{
		if (m_pidDefinition.IsRaw())
		{
			quality = cat::middleware::parameter::Quality::QUALITY_GOOD;
			data.mutable_value()->set_binary_value((*value).data(), (*value).size());
		}
		else
		{
			auto const lsbUintData = MakeDataLsbFirst((*value).data(), static_cast<unsigned>((*value).size()));
			if (!IsWithinDsiRange(lsbUintData))
			{
				auto const rawValue = GetRawIntegerValue(lsbUintData);
				auto const scaledValue = GetScaledValue(rawValue);
				quality = cat::middleware::parameter::Quality::QUALITY_GOOD;
				if (m_pidDefinition.IsDouble())
				{
					data.mutable_value()->set_double_value(scaledValue);
				}
				else if (m_pidDefinition.IsUint())
				{
					data.mutable_value()->set_uinteger64_value(static_cast<uint64_t>(scaledValue));
				}
			}
		}
	}
	data.set_quality(quality);

	return data;
}
namespace
{
// Code below is duplicated between PidParameterDataWriter and PidParameterDataPublisher. Consider refactoring if more duplication is added in the future.
constexpr uint32_t n_dsiMinimumValues[5][2] // Indexed by byteCount and isSigned
{
	{},
	{       0xE0, 0x80 },
	{     0xFFE0, 0x8000 },
	{},
	{ 0xFFFFFFE0, 0x80000000 },
};
constexpr uint32_t n_dsiMaximumDelta = 0x1F; // maximum = minimum + 31
}
bool PidParameterDataWriter::IsWithinDsiRange(uint32_t lsbUintData) const
{
	auto inDsiRange{false};
	if (m_pidDefinition.IsDsiCapable())
	{
		auto const minimumDsi = n_dsiMinimumValues[m_pidDefinition.ByteCount()][m_pidDefinition.IsSigned()];
		inDsiRange = ((lsbUintData >= minimumDsi) && (lsbUintData <= minimumDsi + n_dsiMaximumDelta));
	}
	return inDsiRange;
}
uint32_t PidParameterDataWriter::MakeDataLsbFirst(uint8_t const* pData, unsigned dataLength) const
{
	uint32_t lsbUintData{};
	assert(dataLength <= sizeof(lsbUintData));
	if (m_pidDefinition.IsLsbFirst())
	{
		memcpy(&lsbUintData, pData, dataLength);
	}
	else
	{
		auto const pDestinationArray = reinterpret_cast<unsigned char*>(&lsbUintData);
		std::reverse_copy(pData, pData + dataLength, pDestinationArray);
	}
	return lsbUintData;
}
bool PidParameterDataWriter::IsSignedValueNegative(uint32_t data, unsigned length) const
{
	auto const pDataArray = reinterpret_cast<unsigned char const*>(&data);
	auto const mostSignicantByte = pDataArray[length - 1];
	return ((mostSignicantByte & 0x80) != 0);
}
int64_t PidParameterDataWriter::GetRawIntegerValue(uint32_t lsbUintData) const
{
	auto value = int64_t{};
	auto const byteCount = m_pidDefinition.ByteCount();
	if ( m_pidDefinition.IsSigned() && IsSignedValueNegative(lsbUintData, byteCount) )
	{
		value = ~0LL;
	}

	memcpy(&value, &lsbUintData, byteCount);

	return value;
}
double PidParameterDataWriter::GetScaledValue(int64_t rawValue) const
{
	assert(rawValue <= std::numeric_limits<uint32_t>::max());
	return static_cast<double>(rawValue) * m_pidDefinition.UnitsPerBit();
}
}
}
