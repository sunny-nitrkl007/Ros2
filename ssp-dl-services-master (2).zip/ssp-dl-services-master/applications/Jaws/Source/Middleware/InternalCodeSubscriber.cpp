/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See InternalCodeSubscriber.h

#include "InternalCodeSubscriber.h"
#include "DependencyContainer.h"
#include "Log.h"
#include <middleware_parameter.pb.h>
#include <Shark/IWriteSharkByte.h>
#include <Shark/IWriteSharkByteRetriever.h>
#include <IConfigBuilder.h>

using namespace middleware::parameter;

namespace Jaws
{
namespace Middleware
{
std::move_only_function<void(middleware::parameter::IService&)> InternalCodeSubscriber::Create(
	InternalCodeConfig const& internalCodeEntry,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& internalCodeSubscribeId = internalCodeEntry.middleware_id();
	auto spSubscriber = std::make_shared<InternalCodeSubscriber>(internalCodeSubscribeId);

	configBuilder.AddSubscribe(
		internalCodeSubscribeId.c_str(),
		[spSubscriber](Identity const& id, Data const& data, Metadata const&)
		{
			spSubscriber->OnSubscriptionDataReceived(id, data);
		},
		[spSubscriber]()
		{
			spSubscriber->OnDisconnect();
		});

	auto& writeSharkByteRetriever = dependencyContainer.GetIWriteSharkByteRetriever();

	return [spSubscriber, &writeSharkByteRetriever]([[maybe_unused]] middleware::parameter::IService& service) noexcept
		{
			spSubscriber->Initialize(writeSharkByteRetriever);
		};
}
InternalCodeSubscriber::InternalCodeSubscriber(std::string const& internalCodeSubscribeId)
	: m_internalCodeSubscribeId(internalCodeSubscribeId)
{
}

void InternalCodeSubscriber::Initialize(Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever)
{
	assert(!m_spWriteSharkByte);
	m_spWriteSharkByte = &writeSharkByteRetriever.Retrieve(m_internalCodeSubscribeId);
}
void InternalCodeSubscriber::OnSubscriptionDataReceived(
	[[maybe_unused]] Identity const& id,
	cat::middleware::parameter::Data const& data)
{
	assert(m_internalCodeSubscribeId == id);
	assert(m_spWriteSharkByte);
	if (data.has_value() && data.value().has_boolean_value())
	{
		auto const& boolValue = data.value().boolean_value();

		m_spWriteSharkByte->Write(boolValue ? Shark::TrueSharkByteValue() : Shark::FalseSharkByteValue());
	}
	else
	{
		LOG_INFO_HIGH_TAG(Log::Parameter, "Internal code update data is not boolean for " << m_internalCodeSubscribeId.c_str());
	}
}
void InternalCodeSubscriber::OnDisconnect()
{
	assert(m_spWriteSharkByte);
	m_spWriteSharkByte->WriteInvalid();
}
}
}