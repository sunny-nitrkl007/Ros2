/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Calibration and Service Test Wrapper class

#pragma once

#include <middleware_parameter.pb.h>
#include <Utilities/nice_ptr.h>
#include <functional>

namespace middleware::diagnostics
{
class IService;
}
namespace Shark
{
class IWriteSharkByteRetriever;
class IWriteSharkByte;
}
namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
class IWriteReply;

class CalibrationWrapper final
{
public:
	static bool ShouldBeCreated(DependencyContainer const& dependencyContainer);
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);

	CalibrationWrapper() noexcept;
	~CalibrationWrapper();

	std::optional<cat::middleware::parameter::Data> SendCalibrationCommand(
		cat::middleware::parameter::Data const& data,
		IWriteReply& writeReply);

	void Initialize(Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever);
private:
	std::optional<cat::middleware::parameter::Data> ProcessWrite(
		cat::middleware::parameter::Data const& data,
		IWriteReply& writeReply);

	Utilities::nice_ptr<Shark::IWriteSharkByte> m_spWriteSharkByte{};
};
}
}
