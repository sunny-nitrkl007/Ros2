/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// IConfigBuilder decorator that gates all callbacks behind an InitializationGate.

#pragma once

#include <IConfigBuilder.h>
#include <IParameterService.h>
#include <Utilities/nice_ptr.h>
#include <memory>

namespace Jaws
{
class IInitializationGate;

namespace Middleware
{
class IServiceWaiter
{
public:
	virtual ~IServiceWaiter() = default;
	virtual void SetReady(middleware::parameter::IService& service) = 0;
};

class InitializationGatingConfigBuilder final : public middleware::parameter::IConfigBuilder, public IServiceWaiter
{
public:
	InitializationGatingConfigBuilder(
		std::unique_ptr<middleware::parameter::IConfigBuilder>&& spInner,
		Jaws::IInitializationGate& gate);
	// Middleware takes ownership of the IConfigBuilder and destroys it after Take() is called. Thus, we cannot
	// pass the InitializationGatingConfigBuilder itself to the service factory because it still must exist for
	// the callbacks.
	std::unique_ptr<middleware::parameter::IConfigBuilder> ReleaseInnerBuilder();
// middleware::parameter::IConfigBuilder
	IConfigBuilder& AddPublish(
		middleware::parameter::Identity&& parameter_id,
		middleware::parameter::Unit unit,
		middleware::parameter::Data&& initial_value) override;

	IConfigBuilder& AddSubscribe(
		middleware::parameter::Identity&& parameter_id,
		middleware::parameter::Unit unit,
		middleware::parameter::OnSubscription&& callback,
		middleware::parameter::OnDisconnect&& disconnect) override;

	IConfigBuilder& AddSubscribe(
		middleware::parameter::Identity&& parameter_id,
		middleware::parameter::OnSubscriptionWithMetadata&& callback,
		middleware::parameter::OnDisconnect&& disconnect) override;

	IConfigBuilder& AddClientRead(
		middleware::parameter::Identity&& parameter_id,
		middleware::parameter::Unit unit) override;

	IConfigBuilder& AddClientWrite(
		middleware::parameter::Identity&& parameter_id,
		middleware::parameter::Unit unit) override;

	IConfigBuilder& AddServerWrite(
		middleware::parameter::Identity&& parameter_id,
		middleware::parameter::OnWriteAction&& callback) override;

	IConfigBuilder& AddServerRead(
		middleware::parameter::Identity&& parameter_id,
		middleware::parameter::OnReadAction&& callback) override;

	middleware::parameter::ParameterService&& Take() override;

// IServiceWaiter
	void SetReady(middleware::parameter::IService& service) override;
private:
	std::unique_ptr<middleware::parameter::IConfigBuilder> m_spInner;
	Jaws::IInitializationGate& m_gate;
	Utilities::nice_ptr<middleware::parameter::IService> m_spService{};
};
}
}
