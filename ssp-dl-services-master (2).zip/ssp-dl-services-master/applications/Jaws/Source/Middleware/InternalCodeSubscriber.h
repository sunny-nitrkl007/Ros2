/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Internal Code Subscriber

#pragma once

#include <IParameterService.h>
#include <SharkConfiguration.pb.h>
#include <Utilities/nice_ptr.h>

namespace middleware::parameter
{
class IConfigBuilder;
}
namespace Shark
{
class IWriteSharkByte;
class IWriteSharkByteRetriever;
}
namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
using InternalCodeConfig = cat::shark::Diagnostics::InternalCodeList::InternalCode;

class InternalCodeSubscriber
{
public:
	static std::move_only_function<void(middleware::parameter::IService&)> Create(
		InternalCodeConfig const& internalCodeEntry,
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);

	InternalCodeSubscriber(std::string const& internalCodeSubscribeId);

	void Initialize(Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever);
	void OnSubscriptionDataReceived(
		middleware::parameter::Identity const& id,
		cat::middleware::parameter::Data const& data);
	void OnDisconnect();

private:
	std::string const m_internalCodeSubscribeId;
	Utilities::nice_ptr<Shark::IWriteSharkByte> m_spWriteSharkByte{};
};
}
}