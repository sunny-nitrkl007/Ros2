/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PgnParameterDataPublisher.h

#include "PgnParameterDataPublisher.h"
#include "DependencyContainer.h"
#include "IConfigBuilder.h"
#include "Identifiers/IPublicJ1939DefinitionRetriever.h"
#include "IParameterService.h"
#include <IPublishParameter.h>
#include <middleware_parameter.pb.h>
#include <Shark/ISharkByteRetriever.h>
#include <Utilities/narrow_cast.h>

using Data = cat::middleware::parameter::Data;

namespace Jaws
{
namespace Middleware
{
namespace
{
Data CreateDefaultData()
{
	Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	return data;
}
uint64_t CreateDataMask(unsigned bitOffset, Identifiers::SpnDefinition const& definition)
{
	uint64_t mask = static_cast<uint64_t>(~0);
	mask >>= sizeof(mask) * CHAR_BIT - definition.BitCount();
	mask <<= bitOffset;

	return mask;
}
}
std::move_only_function<void(middleware::parameter::IService&)> PgnParameterDataPublisher::Create(
	cat::shark::J1939DataLink::PeerNode::Pgn::ReceiveBroadcastPgn const& pgnEntry,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& publicJ1939DefinitionRetriever = dependencyContainer.GetIPublicJ1939DefinitionRetriever();
	auto const& pgnDefinition = publicJ1939DefinitionRetriever.RetrievePgnDefinition(pgnEntry.pgn());
	SpnPublishers spnPublishers{};
	for (auto const& spnEntry : pgnEntry.spns())
	{
		auto const spn = spnEntry.spn();
		auto const& spnPublishId = spnEntry.middleware_id();
		auto const bitOffset = pgnDefinition.FindSpnOffset(spn);
		assert(bitOffset);
		auto const& spnDefinition = publicJ1939DefinitionRetriever.RetrieveSpnDefinition(spn);
		configBuilder.AddPublish(
			spnPublishId.c_str(),
			static_cast<middleware::parameter::Unit>(spnDefinition.Units()),
			CreateDefaultData());
		spnPublishers.push_back({spnPublishId, *bitOffset, CreateDataMask(*bitOffset, spnDefinition), spnDefinition});
	}
	auto const& pgnPublishId = pgnEntry.middleware_id();
	configBuilder.AddPublish(pgnPublishId.c_str(), {}, CreateDefaultData());

	auto&& spParameterDataPublisher = std::make_unique<PgnParameterDataPublisher>(
		pgnPublishId,
		pgnDefinition,
		std::move(spnPublishers));

	auto& sharkByteRetriever = dependencyContainer.GetISharkByteRetriever();

	return [spParameterDataPublisher = std::move(spParameterDataPublisher), &sharkByteRetriever](middleware::parameter::IService& parameterService) noexcept
		{
			spParameterDataPublisher->Initialize(sharkByteRetriever, parameterService);
		};
}
PgnParameterDataPublisher::PgnParameterDataPublisher(
	std::string const& pgnPublishId,
	Identifiers::PgnDefinition const& pgnDefinition,
	SpnPublishers&& spnPublishers)
	: m_pgnPublishId(pgnPublishId)
	, m_pgnDefinition(pgnDefinition)
	, m_spnPublishers(std::move(spnPublishers))
{
}
void PgnParameterDataPublisher::Initialize(
	Shark::ISharkByteRetriever const& sharkByteRetriever,
	middleware::parameter::IService& parameterService)
{
	assert(m_subscriptions.empty());
	for (auto& spnPublisher : m_spnPublishers)
	{
		spnPublisher.spPublisher = &(parameterService.RetrievePublisherInstance(spnPublisher.publishId.c_str()));
	}
	auto& pgnPublisher = parameterService.RetrievePublisherInstance(m_pgnPublishId);
	auto& sharkByte = sharkByteRetriever.Retrieve(m_pgnPublishId);
	auto subscription = sharkByte.SubscribeToValues(
		[this, &pgnPublisher](Shark::SharkByteValue const& value)
		{
			PublishPgn(pgnPublisher, value);
			for (auto& spnPublisher : m_spnPublishers)
			{
				PublishSpn(
					*(spnPublisher.spPublisher),
					value,
					spnPublisher.bitOffset,
					spnPublisher.dataMask,
					spnPublisher.spnDefinition);
			}
		});
	m_subscriptions.push_back(std::move(subscription));
}
void PgnParameterDataPublisher::PublishPgn(
	middleware::parameter::IPublish& publisher,
	Shark::SharkByteValue const& value)
{
	Data data{};
	if (value)
	{
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_binary_value((*value).data(), (*value).size());
	}
	else
	{
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	}
	publisher.Publish(data);
}
void PgnParameterDataPublisher::PublishSpn(
	middleware::parameter::IPublish& publisher,
	Shark::SharkByteValue const& value,
	unsigned bitOffset,
	uint64_t dataMask,
	Identifiers::SpnDefinition const& spnDefinition)
{
	assert(bitOffset + spnDefinition.BitCount() <= 64);
	Data data{};
	if (value)
	{
		assert(value->size() <= 8);
		uint64_t uintData{};
		memcpy(&uintData, value->data(), value->size());

		uint32_t rawValue = (Utilities::narrow_cast<uint32_t>((uintData & dataMask) >> bitOffset));

		auto result = (Utilities::narrow_cast<double>(rawValue) * spnDefinition.UnitsPerBit()) + spnDefinition.ValueOffset();
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		if (spnDefinition.IsDouble())
		{
			data.mutable_value()->set_double_value(result);
		}
		else if (spnDefinition.IsUint())
		{
			data.mutable_value()->set_uinteger64_value(static_cast<uint64_t>(result));
		}
	}
	else
	{
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	}
	publisher.Publish(data);
}
}
}
