/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pgn Parameter Data Subscriber

#pragma once

#include <IParameterService.h>
#include <SharkConfiguration.pb.h>
#include <Utilities/nice_ptr.h>
#include <vector>

namespace middleware::parameter
{
class IConfigBuilder;
}
namespace Shark
{
class IWriteSharkByte;
class IWriteSharkByteRetriever;
}
namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
// This class is responsible for subscribing to a middleware parameter that provides the full
// data payload for a broadcast PGN.  It will write the data from the subscription to the shark
// byte when it receives and update.  In the case of a disconnect from the publisher, the default
// pgn data of all 0xFF will be written to the shark byte.
class PgnParameterDataSubscriber
{
public:
	static std::move_only_function<void(middleware::parameter::IService&)> Create(
		cat::shark::J1939DataLink::TransmitBroadcastPgn const& transmitPgnEntry,
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);

	PgnParameterDataSubscriber(std::string const& pgnSubscribeId);

	void Initialize(Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever);
	void OnSubscriptionDataReceived(
		middleware::parameter::Identity const& id,
		cat::middleware::parameter::Data const& data);
	void OnDisconnect();

private:
	std::string const m_pgnSubscribeId;
	Utilities::nice_ptr<Shark::IWriteSharkByte> m_spWriteSharkByte{};
};
}
}