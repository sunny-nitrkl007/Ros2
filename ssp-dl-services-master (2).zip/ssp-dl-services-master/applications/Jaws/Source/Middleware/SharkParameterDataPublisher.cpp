/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SharkParameterDataPublisher.h

#include "SharkParameterDataPublisher.h"
#include "DependencyContainer.h"
#include <IConfigBuilder.h>
#include <IParameterService.h>
#include <IPublishParameter.h>
#include <middleware_parameter.pb.h>
#include <Shark/ISharkByteRetriever.h>

using Data = cat::middleware::parameter::Data;

namespace Jaws
{
namespace Middleware
{
namespace
{
Data CreateDefaultData()
{
	Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	return data;
}
}
std::move_only_function<void(middleware::parameter::IService&)> SharkParameterDataPublisher::Create(
	SharkToMiddlewarePublisher const& sharkToMiddlewarePublisher,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	configBuilder.AddPublish(
		sharkToMiddlewarePublisher.pPublishId,
		static_cast<middleware::parameter::Unit>(sharkToMiddlewarePublisher.unit),
		CreateDefaultData());
	auto spSharkParameterDataPublisher = std::make_unique<SharkParameterDataPublisher>(sharkToMiddlewarePublisher);
	auto& sharkByteRetriever = dependencyContainer.GetISharkByteRetriever();
	return [spSharkParameterDataPublisher = std::move(spSharkParameterDataPublisher), &sharkByteRetriever](middleware::parameter::IService& parameterService) noexcept
		{
			spSharkParameterDataPublisher->Initialize(sharkByteRetriever, parameterService);
		};
}
SharkParameterDataPublisher::SharkParameterDataPublisher(
	SharkToMiddlewarePublisher const& sharkToMiddlewarePublisher)
	: m_sharkToMiddlewarePublisher{sharkToMiddlewarePublisher}
{
}
void SharkParameterDataPublisher::Initialize(
	Shark::ISharkByteRetriever const& sharkByteRetriever,
	middleware::parameter::IService& parameterService)
{
	assert(!m_subscription.IsConnected());
	auto& publisher = parameterService.RetrievePublisherInstance(m_sharkToMiddlewarePublisher.pPublishId);
	auto& sharkByte = sharkByteRetriever.Retrieve(m_sharkToMiddlewarePublisher.pSharkByteId);
	m_subscription = sharkByte.SubscribeToValues(
		[this, &publisher](Shark::SharkByteValue const& value)
		{
			Publish(publisher, value);
		});
}
void SharkParameterDataPublisher::Publish(
	middleware::parameter::IPublish& publisher,
	Shark::SharkByteValue const& sharkByteValue)
{
	Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	if (sharkByteValue)
	{
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		switch(m_sharkToMiddlewarePublisher.middlewareDataType)
		{
			case Identifiers::Boolean:
				assert(sharkByteValue->size() == 1);
				data.mutable_value()->set_boolean_value((*sharkByteValue)[0] != 0);
				break;
			case Identifiers::Double:
				assert(sharkByteValue->size() == 1);
				data.mutable_value()->set_double_value((*sharkByteValue)[0]);
				break;
			case Identifiers::Uint:
				assert(sharkByteValue->size() == 1);
				data.mutable_value()->set_uinteger64_value(static_cast<uint64_t>((*sharkByteValue)[0]));
				break;
			case Identifiers::String:
				data.mutable_value()->set_string_value(std::string(sharkByteValue->begin(), sharkByteValue->end()));
				break;
			default:
				assert(false);
				break;
		}
	}
	publisher.Publish(data);
}
}
}