/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Parameter Data Writer

#pragma once

#include "IWriteReply.h"
#include "ISharkToMiddlewareDefinitions.h"
#include <IParameterService.h>
#include <middleware_parameter.pb.h>
#include <Shark/ISharkByte.h>

namespace middleware::parameter
{
class IConfigBuilder;
class IService;
}
namespace Shark
{
class IWriteSharkByteRetriever;
}
namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
class SharkParameterDataWriter : public IWriteReply
{
public:
	static std::move_only_function<void(middleware::parameter::IService&)> Create(
		SharkToMiddlewareWriter const& sharkToMiddlewareWriter,
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);

	SharkParameterDataWriter(SharkToMiddlewareWriter const& sharkToMiddlewareWriter);

	void Initialize(middleware::parameter::IService& parameterService);
	std::optional<cat::middleware::parameter::Data> OnWrite(
		uint_least16_t key,
		cat::middleware::parameter::Data const& data);

// IWriteReply
	void Reply(cat::middleware::parameter::Data const& data) override;
private:
	SharkToMiddlewareWriter const m_sharkToMiddlewareWriter;
	Utilities::nice_ptr<middleware::parameter::IService> m_spParameterService{};
	std::mutex m_mutex{};
	std::optional<uint_least16_t> m_inProcessKey{};
};
}
}