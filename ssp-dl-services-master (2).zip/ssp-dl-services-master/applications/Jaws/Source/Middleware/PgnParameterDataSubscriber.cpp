/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PgnParameterDataSubscriber.h

#include "PgnParameterDataSubscriber.h"
#include "DependencyContainer.h"
#include "Log.h"
#include <middleware_parameter.pb.h>
#include <Shark/IWriteSharkByte.h>
#include <Shark/IWriteSharkByteRetriever.h>
#include <IConfigBuilder.h>

using namespace middleware::parameter;

namespace Jaws
{
namespace Middleware
{
namespace
{
const std::vector<uint8_t> n_defaultPgnData{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
}
std::move_only_function<void(middleware::parameter::IService&)> PgnParameterDataSubscriber::Create(
	cat::shark::J1939DataLink::TransmitBroadcastPgn const& transmitPgnEntry,
	DependencyContainer const& dependencyContainer,
	middleware::parameter::IConfigBuilder& configBuilder)
{
	auto const& pgnSubscribeId = transmitPgnEntry.middleware_id();
	auto spSubscriber = std::make_shared<PgnParameterDataSubscriber>(pgnSubscribeId);

	configBuilder.AddSubscribe(
		pgnSubscribeId.c_str(),
		[spSubscriber](Identity const& id, Data const& data, Metadata const&)
		{
			spSubscriber->OnSubscriptionDataReceived(id, data);
		},
		[spSubscriber]()
		{
			spSubscriber->OnDisconnect();
		});

	auto& writeSharkByteRetriever = dependencyContainer.GetIWriteSharkByteRetriever();

	return [spSubscriber, &writeSharkByteRetriever]([[maybe_unused]] middleware::parameter::IService& service) noexcept
		{
			spSubscriber->Initialize(writeSharkByteRetriever);
		};
}
PgnParameterDataSubscriber::PgnParameterDataSubscriber(std::string const& pgnSubscribeId)
	: m_pgnSubscribeId(pgnSubscribeId)
{
}

void PgnParameterDataSubscriber::Initialize(Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever)
{
	assert(!m_spWriteSharkByte);
	m_spWriteSharkByte = &writeSharkByteRetriever.Retrieve(m_pgnSubscribeId);
}
void PgnParameterDataSubscriber::OnSubscriptionDataReceived(
	[[maybe_unused]] Identity const& id,
	cat::middleware::parameter::Data const& data)
{
	assert(m_pgnSubscribeId == id);
	assert(m_spWriteSharkByte);
	if (data.has_value() && data.value().has_binary_value())
	{
		auto const& binaryValue = data.value().binary_value();
		std::vector<uint8_t> binaryVector(binaryValue.begin(), binaryValue.end());

		// Pad to 8 bytes with 0xFF if under 8 bytes
		if (binaryVector.size() < 8)
		{
			binaryVector.resize(8, 0xFF);
		}

		m_spWriteSharkByte->Write(binaryVector);
	}
	else
	{
		LOG_DEBUG_TAG(Log::Parameter, "Pgn parameter update data is not binary for " << m_pgnSubscribeId.c_str());
	}
}
void PgnParameterDataSubscriber::OnDisconnect()
{
	assert(m_spWriteSharkByte);
	m_spWriteSharkByte->Write(n_defaultPgnData);
}
}
}