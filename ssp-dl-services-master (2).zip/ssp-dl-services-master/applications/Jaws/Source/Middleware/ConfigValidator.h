/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// ConfigValidator class

#pragma once

#include "IConfigValidator.h"
#include <google/protobuf/util/json_util.h>

namespace Jaws
{
namespace Middleware
{
class ConfigValidator final : public IConfigValidator {
public:
    bool ValidateAndConvertToJson(
		std::vector<uint8_t> const& data,
		std::string& output) override;
};
}
}