/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Raw data write server for BDT (Basic Data Transfer) parameters

#pragma once

#include <IParameterService.h>
#include <Shark/IWriteSharkByte.h>
#include <SharkConfiguration.pb.h>
#include <Utilities/nice_ptr.h>
#include <middleware_parameter.pb.h>
#include <mutex>

namespace middleware::parameter
{
class IConfigBuilder;
class IService;
}
namespace Shark
{
class IWriteSharkByteRetriever;
}

namespace Jaws
{
class DependencyContainer;

namespace Middleware
{

class RawDataWriteServer
{
public:
	static std::move_only_function<void(middleware::parameter::IService&)> Create(
		cat::shark::J1939DataLink::PeerNode::Bdt::BdtType const& bdtType,
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);

	RawDataWriteServer(std::string const& id);
	void Initialize(
		Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever,
		middleware::parameter::IService& parameterService);
	std::optional<cat::middleware::parameter::Data> OnWrite(
		uint_least16_t key,
		middleware::parameter::Identity const& id,
		cat::middleware::parameter::Data const& data);
private:
	void OnWriteCompleted(Shark::SharkByteValue const& value);

	std::string const m_id;
	Utilities::nice_ptr<middleware::parameter::IService> m_spParameterService{};
	Utilities::nice_ptr<Shark::IWriteSharkByte> m_spWriteSharkByte{};
	std::optional<uint_least16_t> m_activeKey{};
	std::mutex m_mutex{};
};
}
}
