/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See MachineSecuritySystemWrapper.h

#include "MachineSecuritySystemWrapper.h"
#include "DependencyContainer.h"
#include "InternalMiddlewareIds.h"
#include "Log.h"
#include "Middleware/SharkToMiddlewareDefinitions.h"
#include <CodesFactory.h>
#include <SharkConfiguration.pb.h>
#include <Shark/ISharkByteRetriever.h>
#include <Shark/IWriteSharkByte.h>
#include <Shark/IWriteSharkByteRetriever.h>
#include <Shark/SharkByteDetails.h>
#include <Utilities/ArrayToHexString.h>

using Data = cat::middleware::parameter::Data;
using namespace Shark::SharkByteDetails::MachineSecuritySystem;

namespace Jaws
{
namespace Middleware
{
namespace
{
Data MakeBooleanData(bool value)
{
	Data data{};
	data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	data.mutable_value()->set_boolean_value(value);
	return data;
}

Utilities::nice_ptr<MachineSecuritySystemWrapper> n_spMachineSecuritySystemWrapper{};

#define PUBLISHER_DEFINITION(METHOD_NAME, TYPE) \
	{ \
		MachineSecuritySystem::METHOD_NAME(), \
		Shark::SharkByteDetails::MachineSecuritySystem::METHOD_NAME(), \
		cat::shark::UNIT_NONE, \
		Identifiers::TYPE \
	},

constexpr SharkToMiddlewarePublisher n_sharkToMiddlewarePublishers[]
{
	PUBLISHER_DEFINITION(OperatorName, String)
	PUBLISHER_DEFINITION(OperatorIsGuest, Boolean)
	PUBLISHER_DEFINITION(OperatorIsMaster, Boolean)
	PUBLISHER_DEFINITION(OperatorLogInMethod, String)
};

#define WRITER_DEFINITION(METHOD_NAME) \
	{ \
		MachineSecuritySystem::METHOD_NAME(), \
		[](Data const& data, IWriteReply& writeReply) -> std::optional<cat::middleware::parameter::Data> \
		{ \
			assert(n_spMachineSecuritySystemWrapper); \
			return n_spMachineSecuritySystemWrapper->METHOD_NAME(data, writeReply); \
		} \
	},

const SharkToMiddlewareWriter n_sharkToMiddlewareWriters[]
{
	WRITER_DEFINITION(RequestCurrentOperator)
	WRITER_DEFINITION(LogIn)
	WRITER_DEFINITION(LogOut)
	WRITER_DEFINITION(Lock)
	WRITER_DEFINITION(Unlock)
};
}

bool MachineSecuritySystemWrapper::ShouldBeCreated(DependencyContainer const& dependencyContainer)
{
	return dependencyContainer.GetSharkConfig().has_machine_security_system();
}
std::function<void()> MachineSecuritySystemWrapper::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	auto&& spMachineSecuritySystemWrapper = std::make_shared<MachineSecuritySystemWrapper>(
		dependencyContainer.GetISharkByteRetriever(),
		dependencyContainer.GetIWriteSharkByteRetriever());
	auto& sharkToMiddlewareDefinitions = dependencyContainer.GetSharkToMiddlewareDefinitions();
	for (auto const& publisher : n_sharkToMiddlewarePublishers)
	{
		sharkToMiddlewareDefinitions.AddPublisher(publisher);
	}
	for (auto const& writer : n_sharkToMiddlewareWriters)
	{
		sharkToMiddlewareDefinitions.AddWriter(writer);
	}

	return [spMachineSecuritySystemWrapper]() noexcept {};
}
MachineSecuritySystemWrapper::MachineSecuritySystemWrapper(
	Shark::ISharkByteRetriever const& sharkByteRetriever,
	Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever) noexcept
	: m_sharkByteRetriever(sharkByteRetriever)
	, m_writeSharkByteRetriever(writeSharkByteRetriever)
{
	assert(!n_spMachineSecuritySystemWrapper);
	n_spMachineSecuritySystemWrapper = this;
}
MachineSecuritySystemWrapper::~MachineSecuritySystemWrapper()
{
	assert(n_spMachineSecuritySystemWrapper == this);
	n_spMachineSecuritySystemWrapper = nullptr;
}
std::optional<Data> MachineSecuritySystemWrapper::RequestCurrentOperator(
	Data const& data,
	IWriteReply& writeReply)
{
	LOG_INFO_HIGH("JawsSubscriber - MachineSecuritySystemWrapper::RequestCurrentOperator called");
	return ProcessWrite(data, writeReply, ::RequestCurrentOperator(), ::OperatorRequestStatus());
}
std::optional<Data> MachineSecuritySystemWrapper::LogIn(
	Data const& data,
	IWriteReply& writeReply)
{
	assert(data.value().has_string_value());
	LOG_INFO_HIGH("JawsSubscriber - MachineSecuritySystemWrapper::LogIn called");
	return ProcessWrite(data, writeReply, ::LogIn(), ::LogInStatus());
}
std::optional<Data> MachineSecuritySystemWrapper::LogOut(
	Data const& data,
	IWriteReply& writeReply)
{
	LOG_INFO_HIGH("JawsSubscriber - MachineSecuritySystemWrapper::LogOut called");
	return ProcessWrite(data, writeReply, ::LogOut(), ::LogOutStatus());
}
std::optional<Data> MachineSecuritySystemWrapper::Lock(
	Data const& data,
	IWriteReply& writeReply)
{
	LOG_INFO_HIGH("JawsSubscriber - MachineSecuritySystemWrapper::Lock called");
	return ProcessWrite(data, writeReply, ::Lock(), ::LockStatus());
}
std::optional<Data> MachineSecuritySystemWrapper::Unlock(
	Data const& data,
	IWriteReply& writeReply)
{
	assert(data.value().has_string_value());
	LOG_INFO_HIGH("JawsSubscriber - MachineSecuritySystemWrapper::Unlock called");
	return ProcessWrite(data, writeReply, ::Unlock(), ::UnlockStatus());
}
std::optional<Data> MachineSecuritySystemWrapper::ProcessWrite(
	Data const& data,
	IWriteReply& writeReply,
	std::string const& writeSharkByteId,
	std::string const& statusSharkByteId)
{
	auto dataToWrite = std::vector<uint8_t>{data.value().string_value().begin(), data.value().string_value().end()};
	auto& writeSharkByte = m_writeSharkByteRetriever.Retrieve(writeSharkByteId);
	auto& statusSharkByte = m_sharkByteRetriever.Retrieve(statusSharkByteId);
	writeSharkByte.Write(dataToWrite,
		[&writeReply, &statusSharkByte](Shark::SharkByteValue const&)
		{
			auto const& requestStatus = statusSharkByte.Value();
			bool replyValue = false;
			if (requestStatus && (*requestStatus == Shark::TrueSharkByteValue()))
			{
				replyValue = true;
			}
			writeReply.Reply(MakeBooleanData(replyValue));
		});
	return std::nullopt;
}
}
}