/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See DiagnosticWrapper.h

#include "DiagnosticWrapper.h"
#include "DependencyContainer.h"
#include "InternalMiddlewareIds.h"
#include "Log.h"
#include "Middleware/SharkToMiddlewareDefinitions.h"
#include <CodesFactory.h>
#include <SharkConfiguration.pb.h>
#include <Shark/ISharkByteRetriever.h>
#include <Shark/IWriteSharkByte.h>
#include <Shark/IWriteSharkByteRetriever.h>
#include <Shark/SharkByteDetails.h>
#include <Utilities/ArrayToHexString.h>

namespace Jaws
{
namespace Middleware
{
namespace
{
struct [[gnu::packed]] AdditionalInfoGroup2Data
{
	uint8_t occurrenceCount;
	uint8_t securityLevel;
	uint32_t firstOccurrenceTime;
	uint32_t lastOccurrenceTime;
};

constexpr SharkToMiddlewarePublisher n_diagnosticSharkToMiddlewareDefinitions[]
{
	{
		Diagnostics::HighestActiveAnnunciationRequirement(),
		Shark::SharkByteDetails::DiagnosticCodes::HighestActiveAnnunciationRequirementSharkByteId(),
		cat::shark::UNIT_NONE,
		Identifiers::Uint
	},
};

constexpr std::chrono::seconds n_requestTimeout{5}; // Matches shark and middleware's timeout
}

bool DiagnosticWrapper::ShouldBeCreated(DependencyContainer const& dependencyContainer)
{
	return dependencyContainer.GetSharkConfig().has_diagnostics();
}
std::function<void()> DiagnosticWrapper::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	auto spDiagnosticService = middleware::diagnostics::Factory::CreateDiagnosticService();
	auto& diagnosticService = *spDiagnosticService;
	auto&& spDiagnosticWrapper = std::make_shared<DiagnosticWrapper>(std::move(spDiagnosticService));
	auto& sharkToMiddlewareDefinitions = dependencyContainer.GetSharkToMiddlewareDefinitions();
	for (auto const& definition : n_diagnosticSharkToMiddlewareDefinitions)
	{
		sharkToMiddlewareDefinitions.AddPublisher(definition);
	}

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wnonnull"
	auto spCodeServer = diagnosticService.CreateCodeServer(
		cat::middleware::diagnostics::Codes{},
		[spDiagnosticWrapper](
			uint_least16_t middlewareRequestKey,
			::cat::middleware::diagnostics::AdditionalInformation const& additionalInformation)
		{
			spDiagnosticWrapper->RequestAdditionalInformation(middlewareRequestKey, additionalInformation);
			return std::nullopt;
		});
#pragma GCC diagnostic pop

	spDiagnosticWrapper->SetDependency(std::move(spCodeServer));

	return [&dependencyContainer, spDiagnosticWrapper]() noexcept
		{
			spDiagnosticWrapper->Initialize(
				dependencyContainer.GetISharkByteRetriever(),
				dependencyContainer.GetIWriteSharkByteRetriever());
		};
}
DiagnosticWrapper::DiagnosticWrapper(std::unique_ptr<middleware::diagnostics::IService>&& spDiagnosticService) noexcept
	: m_spDiagnosticService{std::move(spDiagnosticService)}
{
	assert(m_spDiagnosticService);
}
void DiagnosticWrapper::SetDependency(std::unique_ptr<middleware::diagnostics::ICodeServer>&& spCodeServer)
{
	assert(spCodeServer);
	assert(!m_spCodeServer);
	m_spCodeServer = std::move(spCodeServer);
}
void DiagnosticWrapper::Initialize(
	Shark::ISharkByteRetriever const& sharkByteRetriever,
	Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever)
{
	assert(!m_additionalInformationWriteRequestSharkByte);
	m_additionalInformationWriteRequestSharkByte = &writeSharkByteRetriever.Retrieve(
		Shark::SharkByteDetails::DiagnosticCodes::AdditionalInformationRequestSharkByteId());

	auto& codesSharkByte = sharkByteRetriever.Retrieve(Shark::SharkByteDetails::DiagnosticCodes::CodesSharkByteId());
	m_codesSubscription = codesSharkByte.SubscribeToValues(
		[this](Shark::SharkByteValue const& value)
		{
			cat::middleware::diagnostics::Codes codes{};
			if (value)
			{
				codes.ParseFromArray(value->data(), static_cast<int>(value->size()));
			}
			m_spCodeServer->Publish(codes);
		});

	auto& additionalInformationResponseSharkByte = sharkByteRetriever.Retrieve(
		Shark::SharkByteDetails::DiagnosticCodes::AdditionalInformationResponseSharkByteId());
	m_additionalInformationResponseSubscription = additionalInformationResponseSharkByte.SubscribeToValues(
		[this](Shark::SharkByteValue const& value)
		{
			if (value)
			{
				ProcessAdditionalInformationResponse(*value);
			}
			else
			{
				LOG_WARNING_TAG(Log::Diagnostics, "Received invalid Additional Information Response Shark Byte value");
			}
		});
}
void DiagnosticWrapper::RequestAdditionalInformation(
	uint_least16_t middlewareRequestKey,
	::cat::middleware::diagnostics::AdditionalInformation const& additionalInformation)
{
	assert(m_additionalInformationWriteRequestSharkByte);
	LOG_INFO_HIGH_TAG(Log::Diagnostics, "Request Additional Information: middleware request key = "
		<< std::hex << std::uppercase << middlewareRequestKey);

	auto const uniqueCodeKey = additionalInformation.code_key();

	size_t pendingMiddlewareRequests = 0;
	{
		std::lock_guard<std::mutex> lock{m_mutex};

		auto& requestInfo = m_activeRequests[uniqueCodeKey];
		auto const now = Utilities::Clock::now();
		if (requestInfo.middlewareRequestKeys.empty())
		{
			requestInfo.requestTime = now;
		}
		else if (now >= requestInfo.requestTime + n_requestTimeout)
		{
			// Timeouts can occur if the additional information response is identical since
			// Shark does not send a notification for unchanged shark byte values.
			LOG_WARNING_TAG(
				Log::Diagnostics,
				"Previous Additional Information request for UniqueCodeKey = " << std::hex << std::uppercase << uniqueCodeKey
				<< " has timed out. Re-sending request.");
			requestInfo.requestTime = now;
			requestInfo.middlewareRequestKeys.clear();
		}

		assert(std::find(
			requestInfo.middlewareRequestKeys.begin(),
			requestInfo.middlewareRequestKeys.end(),
			middlewareRequestKey) == requestInfo.middlewareRequestKeys.end()); // Should get unique request keys
		requestInfo.middlewareRequestKeys.push_back(middlewareRequestKey);
		pendingMiddlewareRequests = requestInfo.middlewareRequestKeys.size();
	}

	if (pendingMiddlewareRequests == 1)
	{
		std::vector<uint8_t> uniqueCodeKeyBytes(sizeof(uint64_t));
		std::memcpy(uniqueCodeKeyBytes.data(), &uniqueCodeKey, sizeof(uint64_t));

		m_additionalInformationWriteRequestSharkByte->Write(uniqueCodeKeyBytes);
	}
	else
	{
		LOG_INFO_HIGH_TAG(
			Log::Diagnostics,
			"Additional Information request for UniqueCodeKey = " << std::hex << std::uppercase << uniqueCodeKey
			<< " is already pending. Not sending duplicate request.");
	}
}
void DiagnosticWrapper::ProcessAdditionalInformationResponse(std::vector<uint8_t> const& value)
{
	auto valueSize = value.size();
	assert(valueSize >= sizeof(uint64_t));
	LOG_INFO_HIGH_TAG(
		Log::Diagnostics, "Received Additional Information: " << Utilities::ArrayToHexString(value.data(), static_cast<unsigned>(value.size())));
	uint64_t uniqueCodeKey;
	std::memcpy(&uniqueCodeKey, value.data(), sizeof(uint64_t));

	cat::middleware::diagnostics::AdditionalInformation additionalInformation;
	additionalInformation.set_code_key(uniqueCodeKey);
	if (valueSize == sizeof(uint64_t) + sizeof(AdditionalInfoGroup2Data))
	{
		AdditionalInfoGroup2Data group2Data{};
		std::memcpy(&group2Data, value.data() + sizeof(uint64_t), sizeof(AdditionalInfoGroup2Data));
		auto& protobufGroup2 = *additionalInformation.mutable_group_2();
		protobufGroup2.set_occurrence_count(group2Data.occurrenceCount);
		protobufGroup2.set_security_level(group2Data.securityLevel);
		protobufGroup2.set_shm_of_first_occurence(group2Data.firstOccurrenceTime);
		protobufGroup2.set_shm_of_last_occurence(group2Data.lastOccurrenceTime);
	}
	// else something like a timeout occurred and no group 2 data is present

	auto const middlewareRequestKeys = TakeMiddlewareRequestKeysForUniqueCodeKey(uniqueCodeKey);
	if (middlewareRequestKeys.empty())
	{
		LOG_WARNING_TAG(
			Log::Diagnostics,
			"No matching Additional Information requests for UniqueCodeKey = " << std::hex << std::uppercase << uniqueCodeKey);
	}

	for (uint_least16_t const middlewareRequestKey : middlewareRequestKeys)
	{
		m_spCodeServer->Reply(middlewareRequestKey, additionalInformation);
	}
}
DiagnosticWrapper::MiddlewareRequestKeys
DiagnosticWrapper::TakeMiddlewareRequestKeysForUniqueCodeKey(uint64_t uniqueCodeKey)
{
	MiddlewareRequestKeys requests{};
	std::lock_guard<std::mutex> lock{m_mutex};

	auto const itFound = m_activeRequests.find(uniqueCodeKey);
	auto const itEnd = m_activeRequests.end();
	if (itFound != itEnd)
	{
		requests = std::move(itFound->second.middlewareRequestKeys);
		m_activeRequests.erase(itFound);
	}

	return requests;
}
}
}