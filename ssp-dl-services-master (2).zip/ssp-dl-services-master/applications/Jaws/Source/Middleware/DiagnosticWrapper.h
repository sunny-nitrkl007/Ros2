/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Wrapper class

#pragma once

#include "Utilities/Clock.h"
#include <IDiagnosticService.h>
#include <Shark/ISharkByte.h>
#include <functional>
#include <map>
#include <memory>
#include <vector>

namespace middleware::diagnostics
{
class ICodeServer;
class IService;
}
namespace Shark
{
class ISharkByteRetriever;
class IWriteSharkByte;
class IWriteSharkByteRetriever;
}
namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
class DiagnosticWrapper
{
public:
	static bool ShouldBeCreated(DependencyContainer const& dependencyContainer);
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);

	DiagnosticWrapper(std::unique_ptr<middleware::diagnostics::IService>&& spDiagnosticService) noexcept;
	void Initialize(
		Shark::ISharkByteRetriever const& sharkByteRetriever,
		Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever);
	void SetDependency(std::unique_ptr<middleware::diagnostics::ICodeServer>&& spCodeServer);
	void RequestAdditionalInformation(
		uint_least16_t middlewareRequestKey,
		::cat::middleware::diagnostics::AdditionalInformation const& additionalInformation);

private:
	// Mapping from UniqueCodeKey to pending Middleware Request Keys. There can be
	// multiple middleware requests for the same UniqueCodeKey that are all pending.
	// All pending requests will be satisfied when the single response is received.
	using MiddlewareRequestKeys = std::vector<uint_least16_t>;
	struct RequestInfo
	{
		Utilities::Clock::time_point requestTime{};
		MiddlewareRequestKeys middlewareRequestKeys{};
	};
	using ActiveRequests = std::unordered_map<uint64_t, RequestInfo>;

	void ProcessAdditionalInformationResponse(std::vector<uint8_t> const& value);
	MiddlewareRequestKeys TakeMiddlewareRequestKeysForUniqueCodeKey(uint64_t uniqueCodeKey);

	std::unique_ptr<middleware::diagnostics::IService> const m_spDiagnosticService;
	std::unique_ptr<middleware::diagnostics::ICodeServer> m_spCodeServer{};
	Utilities::nice_ptr<Shark::IWriteSharkByte> m_additionalInformationWriteRequestSharkByte{};
	Shark::SharkByteSubscription m_codesSubscription{};
	Shark::SharkByteSubscription m_additionalInformationResponseSubscription{};
	std::mutex m_mutex{};
	ActiveRequests m_activeRequests{};
};
}
}
