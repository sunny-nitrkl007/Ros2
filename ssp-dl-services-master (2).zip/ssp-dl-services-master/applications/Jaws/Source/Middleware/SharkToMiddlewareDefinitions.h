/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark to Middleware Definitions

#pragma once

#include "ISharkToMiddlewareDefinitions.h"

namespace Jaws
{
namespace Middleware
{
class SharkToMiddlewareDefinitions final : public ISharkToMiddlewareDefinitions
{
public:
	std::vector<SharkToMiddlewarePublisher>&& TakePublishers()
	{
		m_sharkToMiddlewarePublishersHaveBeenTaken = true;
		return std::move(m_sharkToMiddlewarePublishers);
	}
	std::vector<SharkToMiddlewareWriter>&& TakeWriters()
	{
		m_sharkToMiddlewareWritersHaveBeenTaken = true;
		return std::move(m_sharkToMiddlewareWriters);
	}

// ISharkToMiddlewareDefinitions
	void AddPublisher(SharkToMiddlewarePublisher const& entry) override
	{
		assert(!m_sharkToMiddlewarePublishersHaveBeenTaken && "Cannot add to Publisher Definitions after they have been taken");
		m_sharkToMiddlewarePublishers.emplace_back(entry);
	}
	void AddWriter(SharkToMiddlewareWriter const& entry) override
	{
		assert(!m_sharkToMiddlewareWritersHaveBeenTaken && "Cannot add to Writer Definitions after they have been taken");
		m_sharkToMiddlewareWriters.emplace_back(entry);
	}
private:
	std::vector<SharkToMiddlewarePublisher> m_sharkToMiddlewarePublishers{};
	std::vector<SharkToMiddlewareWriter> m_sharkToMiddlewareWriters{};
	bool m_sharkToMiddlewarePublishersHaveBeenTaken{false};
	bool m_sharkToMiddlewareWritersHaveBeenTaken{false};
};
}
}
