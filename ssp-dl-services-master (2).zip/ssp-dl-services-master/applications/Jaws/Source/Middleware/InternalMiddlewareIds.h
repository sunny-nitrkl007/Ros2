/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Internal Middleware Ids

#pragma once

namespace Jaws
{
namespace Middleware
{
// Subscribe parameter for Jaws/Shark configuration
static constexpr char const* Configuration() { return "data_link_engine.configuration"; }

namespace Calibration
{
static constexpr auto CalibrationCommand() { return "calibration_service_test.command"; }
static constexpr auto CalibrationStatus() { return "calibration_service_test.status"; }
}
namespace Diagnostics
{
// Publish parameter for the highest active annunciation requirement from all configured diagnostic nodes
static constexpr auto HighestActiveAnnunciationRequirement()
	{ return "data_link_engine.highest_active_annunciation_requirement"; }
}

namespace MachineSecuritySystem
{
// Publish parameter for the name of the currently logged in operator, or empty if no operator is logged in
static constexpr auto OperatorName() { return "machine_security_system.operator_name"; }
// Publish parameter indicating whether the currently logged in operator is a guest account
static constexpr auto OperatorIsGuest() { return "machine_security_system.is_guest"; }
// Publish parameter indicating whether the currently logged in operator is a master account
static constexpr auto OperatorIsMaster() { return "machine_security_system.is_master"; }
// Publish parameter for the method used to log in the currently logged in operator (e.g. password, bluetooth, etc.)
static constexpr auto OperatorLogInMethod() { return "machine_security_system.log_in_method"; }

// Write parameter to request current operator properties from the machine security system
static constexpr auto RequestCurrentOperator() { return "machine_security_system.request_current_operator"; }
// Write parameter to attempt to log in to the machine security system with a given operator password
static constexpr auto LogIn() { return "machine_security_system.log_in"; }
// Write parameter to attempt to log out of the machine security system
static constexpr auto LogOut(){ return "machine_security_system.log_out"; }
// Write parameter to attempt to lock the machine security system
static constexpr auto Lock() { return "machine_security_system.lock"; }
// Write parameter to attempt to unlock the machine security system
static constexpr auto Unlock() { return "machine_security_system.unlock"; }
}
}
}