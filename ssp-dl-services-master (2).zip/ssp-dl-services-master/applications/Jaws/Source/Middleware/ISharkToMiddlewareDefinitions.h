/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark to Middleware Definitions Interface

#pragma once

#include "Identifiers/MiddlewareDataType.h"
#include "IWriteReply.h"
#include <IParameterService.h>
#include <middleware_parameter.pb.h>
#include <SharkConfiguration.pb.h>
#include <functional>
#include <optional>

namespace Jaws
{
namespace Middleware
{
// This definition struct can grow as we add more internal shark parameters
// At this time the assumption is all numeric parameters (uint and double)
// must be 1 byte in length and no scaling of any kind
// String parameters can also be configured with length being the size of the shark byte value
struct SharkToMiddlewarePublisher
{
	char const* pPublishId;
	char const* pSharkByteId;
	cat::shark::Unit unit;
	Identifiers::MiddlewareDataType middlewareDataType;
};

using OnWriteFunction = std::optional<cat::middleware::parameter::Data>(
	cat::middleware::parameter::Data const&,
	IWriteReply&);

struct SharkToMiddlewareWriter
{
	char const* pWriteId;
	std::function<OnWriteFunction> onWrite;
};

class ISharkToMiddlewareDefinitions
{
public:
	virtual ~ISharkToMiddlewareDefinitions() = default;

	virtual void AddPublisher(SharkToMiddlewarePublisher const& definition) = 0;
	virtual void AddWriter(SharkToMiddlewareWriter const& definition) = 0;
};
}
}
