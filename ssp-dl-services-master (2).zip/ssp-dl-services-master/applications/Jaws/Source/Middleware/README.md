# Jaws Middleware Layer

Bridges SharkBytes and the middleware parameter service. Publishers translate SharkByte value changes into middleware publishes; subscribers/writers translate incoming middleware data into SharkByte writes.

## Initialization Order

Initialization is split into two phases inside `JawsManager`:

1. **Construction** (`Create()`) — `ParameterWrapper` builds an `InitializationGatingConfigBuilder` (a decorator over `IConfigBuilder`) and registers all parameters with it. No middleware connections are open and no SharkBytes are touched yet.

2. **Initialization** (`Initialize()`) — `ParameterWrapper::Initialize()` runs three steps in strict order:
   1. Start the middleware service.
   2. Subscribe each publisher/writer to its SharkByte (`SubscribeToValues`).
   3. Call `m_initializationGate.SetReady()`.

**Middleware initialization always completes before SharkBytes are used.** This is structurally enforced: the middleware service is started in step 2i, and SharkByte subscriptions are only created afterward in step 2ii.

## Role of `InitializationGatingConfigBuilder`

Once the middleware service starts (step 2i), middleware may begin delivering subscription data on its own thread before step 2ii finishes. `InitializationGatingConfigBuilder` wraps every inbound callback (`AddSubscribe`, `AddServerWrite`, `AddServerRead`) through `IInitializationGate::EnqueueOrExecute()`, which **queues** early callbacks instead of blocking the caller:

- **Void-returning callbacks** (`AddSubscribe`, disconnect handlers) — Arguments are copied into a queued action. The DDS receiver thread returns immediately without blocking.
- **Value-returning callbacks** (`AddServerWrite`, `AddServerRead`) — Return `std::nullopt` immediately, telling middleware the request is asynchronous. The actual callback is queued and an assertion verifies it also returns `std::nullopt` when replayed (i.e., the real handler uses the async `Reply()` pattern).

When `SetReady()` is called at the end of step 2iii, all queued actions are drained in FIFO order. Actions enqueued *during* the drain (re-entrant callbacks) are appended and executed at the end of the same drain pass, preserving ordering. After the drain completes, subsequent `EnqueueOrExecute` calls execute their action immediately.

Outbound operations (`AddPublish`, `AddClientRead`, `AddClientWrite`) are forwarded unwrapped — they never depend on SharkByte state.

## Why Queuing Instead of Blocking

A previous implementation used `WaitUntilReady()` to block the DDS receiver thread until initialization completed. This caused a cross-thread deadlock: the DDS receiver thread held an internal FastDDS `shared_mutex` while blocked on the gate, while the main thread needed an exclusive lock on that same mutex inside `CreateParameterService`. Neither could proceed.

Queuing eliminates this deadlock because DDS receiver threads never block — they enqueue and return immediately.

## SharkByte Callbacks

As long as the SharkByte callback isn't relying on further work in `Initialize`, it will be safe.
