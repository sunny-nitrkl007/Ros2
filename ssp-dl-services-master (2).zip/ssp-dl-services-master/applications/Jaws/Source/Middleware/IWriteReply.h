/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Write Reply Interface

#pragma once

#include <middleware_parameter.pb.h>

namespace Jaws
{
namespace Middleware
{
class IWriteReply
{
public:
	virtual ~IWriteReply() = default;

	virtual void Reply(cat::middleware::parameter::Data const& data) = 0;
};
}
}