/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pgn Parameter Data Publisher

#pragma once

#include "Identifiers/PgnDefinition.h"
#include "Identifiers/SpnDefinition.h"
#include <Shark/ISharkByte.h>
#include <Utilities/nice_ptr.h>
#include <vector>

namespace middleware::parameter
{
class IConfigBuilder;
class IPublish;
class IService;
}
namespace Shark
{
class ISharkByteRetriever;
}
namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
struct SpnPublisher
{
	std::string publishId;
	unsigned bitOffset;
	uint64_t dataMask;
	Identifiers::SpnDefinition spnDefinition;
	Utilities::nice_ptr<middleware::parameter::IPublish> spPublisher;
};
using SpnPublishers = std::vector<SpnPublisher>;

class PgnParameterDataPublisher
{
public:
	static std::move_only_function<void(middleware::parameter::IService&)> Create(
		cat::shark::J1939DataLink::PeerNode::Pgn::ReceiveBroadcastPgn const& pgnEntry,
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);
	PgnParameterDataPublisher(
		std::string const& publishId,
		Identifiers::PgnDefinition const& pgnDefinition,
		SpnPublishers&& spnPublishers);
	void Initialize(
		Shark::ISharkByteRetriever const& sharkByteRetriever,
		middleware::parameter::IService& parameterService);
private:
	void PublishPgn(
		middleware::parameter::IPublish& publisher,
		Shark::SharkByteValue const& value);
	void PublishSpn(
		middleware::parameter::IPublish& publisher,
		Shark::SharkByteValue const& value,
		unsigned bitOffset,
		uint64_t dataMask,
		Identifiers::SpnDefinition const& spnDefinition);

	std::string const m_pgnPublishId;
	Identifiers::PgnDefinition const m_pgnDefinition;
	SpnPublishers m_spnPublishers;
	std::vector<Shark::SharkByteSubscription> m_subscriptions{};
};
}
}