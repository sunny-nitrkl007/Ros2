/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See InitializationGatingConfigBuilder.h

#include "InitializationGatingConfigBuilder.h"
#include "IInitializationGate.h"
#include <IParameterService.h>
#include <cassert>
#include <middleware_parameter.pb.h>

namespace Jaws
{
namespace Middleware
{
namespace
{
template <typename Callback>
auto MakeQueuedCallback(IInitializationGate const& gate, Callback&& callback)
{
	return [&gate, cb = std::forward<Callback>(callback)](auto&&... args) mutable
	{
		gate.EnqueueOrExecute(
			[&cb, argsTuple = std::make_tuple(auto(std::forward<decltype(args)>(args))...)](bool) mutable
			{
				std::apply(cb, std::move(argsTuple));
			});
	};
}
// All queued callbacks return std::nullopt so that Middleware understands it is going to be responded to
// asynchronously. This is a problem when the queued callback actually returns Data synchronously once it
// is executed. We have to jump through a lot of hoops here to complete it asynchronously when this occurs.
template <typename Callback>
auto MakeQueuedServerCallback(
	IInitializationGate const& gate,
	Callback&& callback,
	Utilities::nice_ptr<middleware::parameter::IService>& spService)
{
	assert(!spService); // The pointer value is populated before any callbacks are executed

	return [&gate, cb = std::forward<Callback>(callback), &spService](uint_least16_t key, auto&&... args) mutable
		-> std::optional<cat::middleware::parameter::Data>
	{
		std::optional<cat::middleware::parameter::Data> immediateResult{};
		gate.EnqueueOrExecute(
			[
				&cb,
				&spService,
				key,
				argsTuple = std::make_tuple(auto(std::forward<decltype(args)>(args))...),
				&immediateResult
			](bool immediate) mutable
			{
				auto result = std::apply(
					[&cb, key](auto&&... a) { return cb(key, std::forward<decltype(a)>(a)...); },
					std::move(argsTuple));
				if (result)
				{
					// The callback returned data synchronously. If we are executing immediately, return the data directly.
					// Otherwise, reply with the data asynchronously.
					if (immediate)
					{
						immediateResult = std::move(*result);
					}
					else
					{
						assert(spService); // The service pointer must be set by the time deferred callbacks are executed. // TODO: Move out one level?
						spService->Reply(key, std::move(*result));
					}
				}
			});

		assert(!immediateResult || gate.IsReady());
		return immediateResult;
	};
}
}

InitializationGatingConfigBuilder::InitializationGatingConfigBuilder(
	std::unique_ptr<middleware::parameter::IConfigBuilder>&& spInner,
	IInitializationGate& gate)
	: m_spInner{std::move(spInner)}
	, m_gate{gate}
{
	assert(m_spInner);
}
std::unique_ptr<middleware::parameter::IConfigBuilder> InitializationGatingConfigBuilder::ReleaseInnerBuilder()
{
	assert(m_spInner);
	return std::move(m_spInner);
}
middleware::parameter::IConfigBuilder& InitializationGatingConfigBuilder::AddPublish(
	middleware::parameter::Identity&& parameter_id,
	middleware::parameter::Unit unit,
	middleware::parameter::Data&& initial_value)
{
	assert(m_spInner);
	m_spInner->AddPublish(std::move(parameter_id), unit, std::move(initial_value));
	return *this;
}
middleware::parameter::IConfigBuilder& InitializationGatingConfigBuilder::AddSubscribe(
	middleware::parameter::Identity&& parameter_id,
	middleware::parameter::Unit unit,
	middleware::parameter::OnSubscription&& callback,
	middleware::parameter::OnDisconnect&& disconnect)
{
	assert(m_spInner);
	m_spInner->AddSubscribe(
		std::move(parameter_id),
		unit,
		MakeQueuedCallback(m_gate, std::move(callback)),
		MakeQueuedCallback(m_gate, std::move(disconnect)));
	return *this;
}
middleware::parameter::IConfigBuilder& InitializationGatingConfigBuilder::AddSubscribe(
	middleware::parameter::Identity&& parameter_id,
	middleware::parameter::OnSubscriptionWithMetadata&& callback,
	middleware::parameter::OnDisconnect&& disconnect)
{
	assert(m_spInner);
	m_spInner->AddSubscribe(
		std::move(parameter_id),
		MakeQueuedCallback(m_gate, std::move(callback)),
		MakeQueuedCallback(m_gate, std::move(disconnect)));
	return *this;
}
middleware::parameter::IConfigBuilder& InitializationGatingConfigBuilder::AddClientRead(
	middleware::parameter::Identity&& parameter_id,
	middleware::parameter::Unit unit)
{
	assert(m_spInner);
	m_spInner->AddClientRead(std::move(parameter_id), unit);
	return *this;
}
middleware::parameter::IConfigBuilder& InitializationGatingConfigBuilder::AddClientWrite(
	middleware::parameter::Identity&& parameter_id,
	middleware::parameter::Unit unit)
{
	assert(m_spInner);
	m_spInner->AddClientWrite(std::move(parameter_id), unit);
	return *this;
}
middleware::parameter::IConfigBuilder& InitializationGatingConfigBuilder::AddServerWrite(
	middleware::parameter::Identity&& parameter_id,
	middleware::parameter::OnWriteAction&& callback)
{
	assert(m_spInner);
	m_spInner->AddServerWrite(
		std::move(parameter_id),
		MakeQueuedServerCallback(m_gate, std::move(callback), m_spService));
	return *this;
}
middleware::parameter::IConfigBuilder& InitializationGatingConfigBuilder::AddServerRead(
	middleware::parameter::Identity&& parameter_id,
	middleware::parameter::OnReadAction&& callback)
{
	assert(m_spInner);
	m_spInner->AddServerRead(
		std::move(parameter_id),
		MakeQueuedServerCallback(m_gate, std::move(callback), m_spService));
	return *this;
}
middleware::parameter::ParameterService&& InitializationGatingConfigBuilder::Take()
{
	assert(m_spInner);
	// Note: The real middleware::parameter::IConfigBuilder asserts if Take() is called
	//       more than once. We will not duplicate the assertion here.
	return m_spInner->Take();
}
void InitializationGatingConfigBuilder::SetReady(middleware::parameter::IService& service)
{
	m_spService = &service;
	m_gate.SetReady();
}
}
}
