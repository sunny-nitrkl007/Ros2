/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Configuration Receiver class

#pragma once

#include "Nvm/INvmWrapper.h"
#include "Middleware/IConfigValidator.h"
#include <ParameterServiceDefines.h>
#include <memory>

namespace middleware::parameter
{
class IConfigBuilder;
}

namespace Jaws
{
class DependencyContainer;

namespace Middleware
{
class ConfigurationReceiver
{
public:
	static std::shared_ptr<ConfigurationReceiver> Create(
		DependencyContainer const& dependencyContainer,
		middleware::parameter::IConfigBuilder& configBuilder);
	static void OnConfigurationUpdate(
		std::string const& id,
		middleware::parameter::Data const& data,
		middleware::parameter::Metadata const&);

	ConfigurationReceiver(Nvm::INvmWrapper& nvmWrapper, std::unique_ptr<IConfigValidator>&& spConfigValidator) noexcept;
	virtual ~ConfigurationReceiver();
private:
	void ConfigurationUpdate(middleware::parameter::Data const& data);

	Nvm::INvmWrapper& m_nvmWrapper;
	std::unique_ptr<IConfigValidator> m_spConfigValidator;
};
}
}
