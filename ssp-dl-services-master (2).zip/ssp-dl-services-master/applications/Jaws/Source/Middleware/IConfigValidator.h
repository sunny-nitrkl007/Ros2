/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// IConfigValidator interface

#pragma once

#include <string>
#include <vector>
#include <google/protobuf/message.h>

namespace Jaws
{
namespace Middleware
{
class IConfigValidator {
public:
    virtual ~IConfigValidator() = default;
	// Converting data to JSON because saving byte streams with embedded nulls is
	// not supported through our current implementation.  We could also move this to
	// a base64 encoding or provide alternate saving methods to write this to the
	// xml file
	virtual bool ValidateAndConvertToJson(
		std::vector<uint8_t> const& data,
		std::string& output) = 0;
};
}
}