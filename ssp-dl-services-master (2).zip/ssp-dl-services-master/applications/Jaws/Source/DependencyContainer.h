/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Dependency Container. Note that it does not own any of the objects.

#pragma once

#include "Utilities/nice_ptr.h"
#include "Utilities/OptionalSmartPointers.h"

namespace cat::shark { class Config; }
namespace Shark
{
class ISharkByteRetriever;
class IWriteSharkByteRetriever;
}
namespace Utilities
{
class IEnvironment;
class IFilesystem;
}
namespace Jaws
{
class IInitializationGate;

namespace Identifiers
{
class IIdentifierConfig;
class IPidDefinitionRetriever;
class IPublicJ1939DefinitionRetriever;
class IPidValueDecoder;
class IPidValueEncoder;
}
namespace Middleware
{
class SharkToMiddlewareDefinitions;
}
namespace Nvm
{
class INvmWrapper;
}

class DependencyContainer
{
public:
	DependencyContainer(
		cat::shark::Config const& sharkConfig,
		Utilities::IEnvironment const& environment,
		Utilities::IFilesystem const& filesystem,
		Identifiers::IPidDefinitionRetriever const& pidDefinitionRetriever,
#ifndef USE_ROS2
		Identifiers::IPublicJ1939DefinitionRetriever const& publicJ1939DefinitionRetriever,
#endif
		Identifiers::IPidValueDecoder const& pidValueDecoder,
		Identifiers::IPidValueEncoder const& pidValueEncoder,
		Shark::ISharkByteRetriever const& sharkByteRetriever,
		Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever,
		Nvm::INvmWrapper& nvmWrapper
#ifndef USE_ROS2
		, IInitializationGate& initializationGate
		, Middleware::SharkToMiddlewareDefinitions& sharkToMiddlewareDefinitions
#endif
	)
		: m_sharkConfig{sharkConfig}
		, m_environment{environment}
		, m_filesystem{filesystem}
		, m_pidDefinitionRetriever{pidDefinitionRetriever}
#ifndef USE_ROS2
		, m_publicJ1939DefinitionRetriever{publicJ1939DefinitionRetriever}
#endif
		, m_pidValueDecoder{pidValueDecoder}
		, m_pidValueEncoder{pidValueEncoder}
		, m_sharkByteRetriever{sharkByteRetriever}
		, m_writeSharkByteRetriever{writeSharkByteRetriever}
		, m_nvmWrapper{nvmWrapper}
#ifndef USE_ROS2
		, m_initializationGate{initializationGate}
		, m_sharkToMiddlewareDefinitions{sharkToMiddlewareDefinitions}
#endif
	{
	}

	cat::shark::Config const& GetSharkConfig() const { return m_sharkConfig; }
	Utilities::IEnvironment const& GetIEnvironment() const { return m_environment; }
	Utilities::IFilesystem const& GetIFilesystem() const { return m_filesystem; }
	Identifiers::IPidDefinitionRetriever const& GetIPidDefinitionRetriever() const { return m_pidDefinitionRetriever; }
#ifndef USE_ROS2
	Identifiers::IPublicJ1939DefinitionRetriever const& GetIPublicJ1939DefinitionRetriever() const { return m_publicJ1939DefinitionRetriever; }
#endif
	Identifiers::IPidValueDecoder const& GetIPidValueDecoder() const { return m_pidValueDecoder; }
	Identifiers::IPidValueEncoder const& GetIPidValueEncoder() const { return m_pidValueEncoder; }
	Shark::ISharkByteRetriever const& GetISharkByteRetriever() const { return m_sharkByteRetriever; }
	Shark::IWriteSharkByteRetriever const& GetIWriteSharkByteRetriever() const { return m_writeSharkByteRetriever; }
	Nvm::INvmWrapper& GetINvmWrapper() const { return m_nvmWrapper; }
#ifndef USE_ROS2
	IInitializationGate& GetIInitializationGate() const { return m_initializationGate; }
	Middleware::SharkToMiddlewareDefinitions& GetSharkToMiddlewareDefinitions() const { return m_sharkToMiddlewareDefinitions; }
#endif
private:
	cat::shark::Config const& m_sharkConfig;
	Utilities::IEnvironment const& m_environment;
	Utilities::IFilesystem const& m_filesystem;
	Identifiers::IPidDefinitionRetriever const& m_pidDefinitionRetriever;
#ifndef USE_ROS2
	Identifiers::IPublicJ1939DefinitionRetriever const& m_publicJ1939DefinitionRetriever;
#endif
	Identifiers::IPidValueDecoder const& m_pidValueDecoder;
	Identifiers::IPidValueEncoder const& m_pidValueEncoder;
	Shark::ISharkByteRetriever const& m_sharkByteRetriever;
	Shark::IWriteSharkByteRetriever const& m_writeSharkByteRetriever;
	Nvm::INvmWrapper& m_nvmWrapper;
#ifndef USE_ROS2
	IInitializationGate& m_initializationGate;
	Middleware::SharkToMiddlewareDefinitions& m_sharkToMiddlewareDefinitions;
#endif
};
}