/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Jaws : Shark front end to middleware

#include "JawsManager.h"
#include "Log.h"
#include <atomic>
#include <chrono>
#include <initializer_list>
#include <thread>
#include <signal.h>

namespace
{
using namespace Jaws;
using namespace std::chrono_literals;

constexpr auto n_loopDelay = 5ms;

std::atomic<bool> n_quit{false};
void Quit(int)
{
	n_quit = true;
}

void QuitInit()
{
	for (auto signal : { SIGTERM, SIGINT } )
	{
		struct sigaction action;
		sigaction(signal, nullptr, &action);
		action.sa_handler = &Quit;
		sigaction(signal, &action, nullptr);
	}
}

void Run()
{
	QuitInit();

	auto spJawsManager = JawsManager::Create();
	spJawsManager->Initialize();

	while (!n_quit)
	{
		Log::Flush(); // Ensure the log is flushed. Without this the debugger doesn't display all the output.
		std::this_thread::sleep_for(n_loopDelay);
	}
}
}

int main(int argc, char* argv[])
{
	(void)argc; (void)argv;
	auto result = 1;
	try
	{
		Run();
		result = 0;
	}
	catch (std::exception const& exception)
	{
		std::cerr << "ERROR: " << exception.what() << std::endl;
	}
	catch(...)
	{
	}

	return result;
}
