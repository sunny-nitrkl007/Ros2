/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// The Jaws Manager

#pragma once

#include "DependencyContainer.h"
#include "Identifiers/IPidDefinitionRetriever.h"
#include "Identifiers/IPublicJ1939DefinitionRetriever.h"
#include "Nvm/INvmWrapper.h"
#include <SharkConfiguration.pb.h>
#include <Shark/IShark.h>
#include <memory>

namespace Jaws
{
namespace Identifiers
{
class IPidValueDecoder;
class IPidValueEncoder;
}

class DependencyContainer;
class IInitializationGate;

class JawsManager
{
public:
	static std::unique_ptr<JawsManager> Create();
	JawsManager(
		std::unique_ptr<Shark::IShark>&& spShark,
		std::unique_ptr<cat::shark::Config>&& spSharkConfig,
		std::unique_ptr<Nvm::INvmWrapper>&& spNvmWrapper,
		std::unique_ptr<Identifiers::IPidDefinitionRetriever>&& spPidDefinitionRetriever,
		std::unique_ptr<Identifiers::IPidValueDecoder>&& spPidValueDecoder,
		std::unique_ptr<Identifiers::IPidValueEncoder>&& spPidValueEncoder,
		std::unique_ptr<Identifiers::IPublicJ1939DefinitionRetriever>&& spPublicJ1939DefinitionRetriever,
		std::unique_ptr<IInitializationGate>&& spInitializationGate,
		std::unique_ptr<DependencyContainer>&& spDependencyContainer,
		std::vector<std::function<void()>>&& initializers) noexcept;
	~JawsManager();

	void Initialize();
private:
	std::unique_ptr<Shark::IShark> m_spShark;
	std::unique_ptr<cat::shark::Config> m_spSharkConfig;
	std::unique_ptr<Nvm::INvmWrapper> m_spNvmWrapper;
	std::unique_ptr<Identifiers::IPidDefinitionRetriever> m_spPidDefinitionRetriever;
	std::unique_ptr<Identifiers::IPidValueDecoder> m_spPidValueDecoder;
	std::unique_ptr<Identifiers::IPidValueEncoder> m_spPidValueEncoder;
	std::unique_ptr<Identifiers::IPublicJ1939DefinitionRetriever> m_spPublicJ1939DefinitionRetriever;
	std::unique_ptr<IInitializationGate> m_spInitializationGate;
	std::unique_ptr<DependencyContainer> const m_spDependencyContainer;
	std::vector<std::function<void()>> const m_initializers;
};
}
