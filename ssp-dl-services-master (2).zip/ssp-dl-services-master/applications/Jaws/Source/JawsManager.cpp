/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See JawsManager.h

#include "JawsManager.h"

#include "ConfigLoader.h"
#include "EnvironmentFactory.h"
#include "DependencyContainer.h"
#include "Identifiers/PidDefinitionRetriever.h"
#include "Identifiers/PidValueDecoder.h"
#include "Identifiers/PidValueEncoder.h"
#include "Identifiers/PublicJ1939DefinitionRetriever.h"
#include "InitializationGate.h"
#include "InitializerFactory.h"
#include "Middleware/ParameterWrapper.h"
#include "Middleware/SharkToMiddlewareDefinitions.h"
#include "Nvm/NvmParameters.h"
#include "Nvm/NvmWrapper.h"
#include <Shark/Shark.h>
#include <Utilities/Filesystem.h>

namespace
{
std::string n_backupConfigString{};
std::unique_ptr<cat::shark::Config> RetrieveConfigurationFromNvm(
	Jaws::IConfigLoader const& configLoader,
	Jaws::Nvm::INvmWrapper& nvmWrapper)
{
	// Read and parse the stored configuration before blanking NVM.
	n_backupConfigString = nvmWrapper.Read(Jaws::Nvm::JawsConfigurationNvmId(), "");
	auto spSharkConfig = configLoader.LoadFromNvm(nvmWrapper);
	if (spSharkConfig == nullptr)
	{
		// The stored configuration was not valid, so do not restore it after
		// initialization. Continue with a blank configuration.
		n_backupConfigString.clear();
		spSharkConfig = std::make_unique<cat::shark::Config>();
	}

	// Blank the stored configuration while initializing so that a bad configuration
	// that causes Jaws to crash does not leave a configuration that cannot be loaded.
	// The configuration is restored in JawsManager::Initialize if all goes well.
	nvmWrapper.Write(Jaws::Nvm::JawsConfigurationNvmId(), "");
	return spSharkConfig;
}
}

namespace Jaws
{
std::unique_ptr<JawsManager> JawsManager::Create()
{
	Utilities::Filesystem filesystem{};
	auto spEnvironment = EnvironmentFactory::CreateEnvironment(filesystem);
	auto spNvmWrapper = Nvm::NvmWrapper::Create(*spEnvironment);
	ConfigLoader const configLoader{};
	auto spSharkConfig = RetrieveConfigurationFromNvm(configLoader, *spNvmWrapper);
	auto spShark = Shark::CreateShark(*spEnvironment, *spSharkConfig);
	auto spPidDefinitionRetriever = std::make_unique<Identifiers::PidDefinitionRetriever>(
		spSharkConfig->pid_entries(),
		spSharkConfig->multi_byte_pid_entries());
	auto spPublicJ1939DefinitionRetriever
		= std::make_unique<Identifiers::PublicJ1939DefinitionRetriever>(
			spSharkConfig->pgn_entries(),
			spSharkConfig->spn_entries());
	auto spPidValueDecoder = std::make_unique<Identifiers::PidValueDecoder>();
	auto spPidValueEncoder = std::make_unique<Identifiers::PidValueEncoder>();
	auto spInitializationGate = std::make_unique<InitializationGate>();

	Middleware::SharkToMiddlewareDefinitions sharkToMiddlewareDefinitions{};

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wnonnull"
	// GCC warns about the spShark->GetXxx() calls here.

	// Store the dependencies in a unique_ptr so lifetime is maintained in case the
	// initializers use them during the initialization phase.
	auto spDependencyContainer = std::make_unique<DependencyContainer>(
		*spSharkConfig,
		*spEnvironment,
		filesystem,
		*spPidDefinitionRetriever,
		*spPublicJ1939DefinitionRetriever,
		*spPidValueDecoder,
		*spPidValueEncoder,
		spShark->GetSharkByteRetriever(),
		spShark->GetWriteSharkByteRetriever(),
		*spNvmWrapper,
		*spInitializationGate,
		sharkToMiddlewareDefinitions);

#pragma GCC diagnostic pop

	InitializerFactory initializerFactory{*spDependencyContainer};
	auto initializerFactoryInitializers = initializerFactory.CreateInitializers();
	std::vector<std::function<void()>> initializers{};
	initializers.insert(
		initializers.end(),
		std::make_move_iterator(initializerFactoryInitializers.begin()),
		std::make_move_iterator(initializerFactoryInitializers.end()));

	return std::make_unique<JawsManager>(
		std::move(spShark),
		std::move(spSharkConfig),
		std::move(spNvmWrapper),
		std::move(spPidDefinitionRetriever),
		std::move(spPidValueDecoder),
		std::move(spPidValueEncoder),
		std::move(spPublicJ1939DefinitionRetriever),
		std::move(spInitializationGate),
		std::move(spDependencyContainer),
		std::move(initializers));
}

JawsManager::JawsManager(
	std::unique_ptr<Shark::IShark>&& spShark,
	std::unique_ptr<cat::shark::Config>&& spSharkConfig,
	std::unique_ptr<Nvm::INvmWrapper>&& spNvmWrapper,
	std::unique_ptr<Identifiers::IPidDefinitionRetriever>&& spPidDefinitionRetriever,
	std::unique_ptr<Identifiers::IPidValueDecoder>&& spPidValueDecoder,
	std::unique_ptr<Identifiers::IPidValueEncoder>&& spPidValueEncoder,
	std::unique_ptr<Identifiers::IPublicJ1939DefinitionRetriever>&& spPublicJ1939DefinitionRetriever,
	std::unique_ptr<IInitializationGate>&& spInitializationGate,
	std::unique_ptr<DependencyContainer>&& spDependencyContainer,
	std::vector<std::function<void()>>&& initializers) noexcept
	: m_spShark(std::move(spShark))
	, m_spSharkConfig(std::move(spSharkConfig))
	, m_spNvmWrapper(std::move(spNvmWrapper))
	, m_spPidDefinitionRetriever(std::move(spPidDefinitionRetriever))
	, m_spPidValueDecoder(std::move(spPidValueDecoder))
	, m_spPidValueEncoder(std::move(spPidValueEncoder))
	, m_spPublicJ1939DefinitionRetriever(std::move(spPublicJ1939DefinitionRetriever))
	, m_spInitializationGate(std::move(spInitializationGate))
	, m_spDependencyContainer(std::move(spDependencyContainer))
	, m_initializers(std::move(initializers))
{
	assert(m_spShark);
	assert(m_spSharkConfig);
	assert(m_spPidDefinitionRetriever);
	assert(m_spPublicJ1939DefinitionRetriever);
	assert(m_spDependencyContainer);
}
JawsManager::~JawsManager() = default;
void JawsManager::Initialize()
{
	// Restore the current config in NVM before initializing middleware pieces
	m_spNvmWrapper->Write(Jaws::Nvm::JawsConfigurationNvmId(), n_backupConfigString);

	for (auto&& initializer : m_initializers)
	{
		initializer();
	}
}
}
