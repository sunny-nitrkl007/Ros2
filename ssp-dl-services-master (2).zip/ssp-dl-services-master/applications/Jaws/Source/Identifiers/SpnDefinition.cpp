/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SpnDefinition.h

#include "SpnDefinition.h"
#include <cassert>

namespace Jaws
{
namespace Identifiers
{
Config::Spn SpnDefinition::Spn() const
{
	return m_spnEntry.spn();
}
unsigned SpnDefinition::BitCount() const
{
	return m_spnEntry.bit_count();
}
double SpnDefinition::UnitsPerBit() const
{
	return m_spnEntry.scaling();
}
cat::shark::Unit SpnDefinition::Units() const
{
	return m_spnEntry.unit();
}
double SpnDefinition::ValueOffset() const
{
	return m_spnEntry.offset();
}
bool SpnDefinition::IsDouble() const
{
	return m_spnEntry.data_presentation_type() == cat::shark::DATA_PRESENTATION_TYPE_DOUBLE;
}
bool SpnDefinition::IsUint() const
{
	return m_spnEntry.data_presentation_type() == cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED;
}
bool operator==(SpnDefinition const& definition1, SpnDefinition const& definition2)
{
	return &(definition1.m_spnEntry) == &(definition2.m_spnEntry);
}
}
}