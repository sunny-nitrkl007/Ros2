/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PGN Definition

#pragma once

#include <Config/Pgn.h>
#include <ParameterUnit.pb.h>
#include <SharkConfiguration.pb.h>

namespace Jaws
{
namespace Identifiers
{
using SpnOffsetEntries = ::google::protobuf::RepeatedPtrField<::cat::shark::PgnEntry_OffsetSpn>;

class PgnDefinition final
{
public:
	constexpr PgnDefinition(cat::shark::PgnEntry const& pgnEntry) noexcept
		: m_pgnEntry{pgnEntry}
	{
	}

	friend bool operator==(PgnDefinition const& definition1, PgnDefinition const& definition2);

	Config::Pgn Pgn() const;
	std::optional<unsigned> FindSpnOffset(unsigned spn) const;

private:
	cat::shark::PgnEntry const& m_pgnEntry;
};
bool operator==(PgnDefinition const& definition1, PgnDefinition const& definition2);
}
}