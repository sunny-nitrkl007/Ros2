/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See IPidValueEncoder.h

#pragma once

#include "Identifiers/IPidValueEncoder.h"

namespace Jaws
{
namespace Identifiers
{
class PidValueEncoder final : public IPidValueEncoder
{
public:
	virtual ~PidValueEncoder() override = default;

// IPidValueEncoder
	IPidValueEncoder::ExpectedType Encode(
		PidDefinition const& pidDefinition,
		FixedLengthPidValue const& value) const override;
};
}
}