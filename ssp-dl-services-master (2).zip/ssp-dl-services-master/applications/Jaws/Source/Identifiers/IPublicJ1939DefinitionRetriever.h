/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pgn Definition Retriever Interface

#pragma once

#include "PgnDefinition.h"
#include "SpnDefinition.h"
#include <Utilities/DefineExceptionClass.h>

namespace Jaws
{
namespace Identifiers
{
class IPublicJ1939DefinitionRetriever
{
public:
	virtual ~IPublicJ1939DefinitionRetriever() = default;

	DEFINE_EXCEPTION_CLASS(Error);

	/// \exception IPublicJ1939DefinitionRetriever::Error
	///            Thrown when pgn is not found
	virtual PgnDefinition RetrievePgnDefinition(unsigned pgn) const = 0;
	virtual SpnDefinition RetrieveSpnDefinition(unsigned spn) const = 0;
};
}
}