/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Interface for encoding values into raw fixed-length PID bytes

#pragma once

#include "Identifiers/PidDefinition.h"
#include "Identifiers/FixedLengthPidValue.h"
#include <cstdint>
#include <expected>
#include <vector>

namespace Jaws
{
namespace Identifiers
{
enum class EncodedPidStatus
{
	Good,
	BadType,
	InvalidLength,
};

class IPidValueEncoder
{
public:
	using ExpectedType = std::expected<std::vector<uint8_t>, EncodedPidStatus>;

	virtual ~IPidValueEncoder() = default;

	virtual ExpectedType Encode(
		PidDefinition const& pidDefinition,
		FixedLengthPidValue const& value) const = 0;
};
}
}