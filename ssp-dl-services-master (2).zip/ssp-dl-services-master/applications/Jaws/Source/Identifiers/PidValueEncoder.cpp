/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PidValueEncoder.h

#include "PidValueEncoder.h"
#include "Log.h"
#include "Utilities/OverloadLambdas.h"
#include "Utilities/narrow_cast.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace Jaws
{
namespace Identifiers
{
namespace
{
std::expected<void, EncodedPidStatus> ValidateTypeAgainstDefinition(
	PidDefinition const& pidDefinition,
	FixedLengthPidValue const& value)
{
	if (  std::holds_alternative<std::monostate>(value)                                     ||
	     (std::holds_alternative<double>(value)               && !pidDefinition.IsDouble()) ||
	     (std::holds_alternative<uint64_t>(value)             && !pidDefinition.IsUint())   ||
	     (std::holds_alternative<std::vector<uint8_t>>(value) && !pidDefinition.IsRaw()) )
	{
		LOG_WARNING_TAG(Log::Write, "Write data is not the correct type for the PID definition");
		return std::unexpected{EncodedPidStatus::BadType};
	}

	return {};
}
unsigned GetRawValue(double value, Jaws::Identifiers::PidDefinition const& pidDefinition) noexcept
{
	double const scaledValue = value / pidDefinition.UnitsPerBit();
	auto const rawValue = static_cast<unsigned>(round(scaledValue));
	return rawValue;
}
std::vector<uint8_t> GetOrderedBytes(unsigned rawValue, Jaws::Identifiers::PidDefinition const& pidDefinition) noexcept
{
	std::vector<uint8_t> data{};
	auto const byteCount = pidDefinition.ByteCount();
	data.resize(byteCount);

	if (pidDefinition.IsLsbFirst())
	{
		memcpy(data.data(), &rawValue, byteCount);
	}
	else
	{
		auto const pByteArray = reinterpret_cast<uint8_t const*>(&rawValue);
		std::reverse_copy(pByteArray, pByteArray + byteCount, data.data());
	}

	return data;
}
std::vector<uint8_t> EncodeNumericValue(PidDefinition const& pidDefinition, double value)
{
		auto const rawValue = GetRawValue(value, pidDefinition);
		return GetOrderedBytes(rawValue, pidDefinition);
}
IPidValueEncoder::ExpectedType EncodeValue(PidDefinition const& pidDefinition, FixedLengthPidValue const& value)
{
	using ExpectedType = IPidValueEncoder::ExpectedType;

	return std::visit(
		Utilities::OverloadLambdas{
			[](std::monostate const&) -> ExpectedType { std::unreachable(); }, // Type check prevents this from being called
			[&pidDefinition](double doubleValue) -> ExpectedType { return EncodeNumericValue(pidDefinition, doubleValue); },
			[&pidDefinition](uint64_t uintValue) -> ExpectedType {
				return EncodeNumericValue(pidDefinition, Utilities::narrow_cast<double>(uintValue));
			},
			[&pidDefinition](std::vector<uint8_t> const& binaryValue) -> ExpectedType {
				if (binaryValue.size() != pidDefinition.ByteCount())
				{
					LOG_WARNING_TAG(Log::Write, "Binary data size does not match PID definition byte count");
					return std::unexpected{EncodedPidStatus::InvalidLength};
				}

				return binaryValue;
			}
		},
		value);
}
}

IPidValueEncoder::ExpectedType PidValueEncoder::Encode(
	PidDefinition const& pidDefinition,
	FixedLengthPidValue const& value) const
{
	return ValidateTypeAgainstDefinition(pidDefinition, value)
		.and_then([&pidDefinition, &value] { return EncodeValue(pidDefinition, value); });
}
}
}