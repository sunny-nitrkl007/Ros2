/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// The implementation of IPidDefinitionRetriever

#pragma once

#include "IPidDefinitionRetriever.h"
#include <SharkConfiguration.pb.h>

namespace Jaws
{
namespace Identifiers
{
using PidEntries = ::google::protobuf::RepeatedPtrField<::cat::shark::PidEntry>;
using MultiBytePidEntries = ::google::protobuf::RepeatedPtrField<::cat::shark::MultiBytePidEntry>;

class PidDefinitionRetriever final : public IPidDefinitionRetriever
{
public:
	PidDefinitionRetriever(
		PidEntries const& pidDefinitions,
		MultiBytePidEntries const& multiBytePidDefinitions) noexcept;
// IPidDefinitionRetriever
	PidDefinition RetrievePid(Config::Pid pid) const override;
	MultiBytePidDefinition RetrieveMultiBytePid(Config::Pid pid) const override;
private:
	PidEntries const& m_pidEntries;
	MultiBytePidEntries const& m_multiBytePidEntries;
};
}
}