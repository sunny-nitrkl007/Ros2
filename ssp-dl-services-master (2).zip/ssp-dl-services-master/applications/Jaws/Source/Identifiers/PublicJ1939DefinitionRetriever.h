/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// The implementation of IPublicJ1939DefinitionRetriever

#pragma once

#include "IPublicJ1939DefinitionRetriever.h"
#include <SharkConfiguration.pb.h>

namespace Jaws
{
namespace Identifiers
{
using PgnEntries = ::google::protobuf::RepeatedPtrField<::cat::shark::PgnEntry>;
using SpnEntries = ::google::protobuf::RepeatedPtrField<::cat::shark::SpnEntry>;

class PublicJ1939DefinitionRetriever final : public IPublicJ1939DefinitionRetriever
{
public:
	PublicJ1939DefinitionRetriever(
		PgnEntries const& pgnEntries,
		SpnEntries const& spnEntries) noexcept;
// IPublicJ1939DefinitionRetriever
	PgnDefinition RetrievePgnDefinition(unsigned pgn) const override;
	SpnDefinition RetrieveSpnDefinition(unsigned spn) const override;
private:
	PgnEntries const& m_pgnEntries;
	SpnEntries const& m_spnEntries;
};
}
}
