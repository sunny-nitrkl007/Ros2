/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PidDefinition.h

#include "PidDefinition.h"
#include <cassert>

namespace Jaws
{
namespace Identifiers
{
Config::Pid PidDefinition::Pid() const
{
	assert(Config::Pid{m_pidEntry.pid()}.IsFixedByte());
	return m_pidEntry.pid();
}
unsigned PidDefinition::ByteCount() const
{
	return m_pidEntry.byte_count();
}
double PidDefinition::UnitsPerBit() const
{
	return m_pidEntry.scaling();
}
cat::shark::Unit PidDefinition::Units() const
{
	return m_pidEntry.unit();
}
bool PidDefinition::IsSigned() const
{
	return m_pidEntry.is_signed();
}
bool PidDefinition::IsDsiCapable() const
{
	return m_pidEntry.is_dsi_supported();
}
bool PidDefinition::IsLsbFirst() const
{
	return m_pidEntry.is_lsb();
}
bool PidDefinition::IsDouble() const
{
	return m_pidEntry.data_presentation_type() == cat::shark::DATA_PRESENTATION_TYPE_DOUBLE;
}
bool PidDefinition::IsUint() const
{
	return m_pidEntry.data_presentation_type() == cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED;
}
bool PidDefinition::IsRaw() const
{
	return m_pidEntry.data_presentation_type() == cat::shark::DATA_PRESENTATION_TYPE_BINARY;
}
bool operator==(PidDefinition const& definition1, PidDefinition const& definition2)
{
	return &(definition1.m_pidEntry) == &(definition2.m_pidEntry);
}
Config::Pid MultiBytePidDefinition::Pid() const
{
	return m_multiBytePidEntry.pid();
}
bool MultiBytePidDefinition::IsString() const
{
	return m_multiBytePidEntry.multi_byte_pid_data_type() == cat::shark::MultiBytePidEntry::MULTI_BYTE_PID_DATA_TYPE_STRING;
}
bool MultiBytePidDefinition::IsBinary() const
{
	return m_multiBytePidEntry.multi_byte_pid_data_type() == cat::shark::MultiBytePidEntry::MULTI_BYTE_PID_DATA_TYPE_BINARY;
}
unsigned MultiBytePidDefinition::MinimumParameterDataLength() const
{
	return m_multiBytePidEntry.minimum_length();
}
unsigned MultiBytePidDefinition::MaximumParameterDataLength() const
{
	return m_multiBytePidEntry.maximum_length();
}
bool operator==(MultiBytePidDefinition const& definition1, MultiBytePidDefinition const& definition2)
{
	return &(definition1.m_multiBytePidEntry) == &(definition2.m_multiBytePidEntry);
}
}
}