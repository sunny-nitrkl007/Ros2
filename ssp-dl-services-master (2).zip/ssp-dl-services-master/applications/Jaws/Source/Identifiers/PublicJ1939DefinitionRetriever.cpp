/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PublicJ1939DefinitionRetriever.h

#include "PublicJ1939DefinitionRetriever.h"
#include <Utilities/Conversions.h>

namespace Jaws
{
namespace Identifiers
{
PublicJ1939DefinitionRetriever::PublicJ1939DefinitionRetriever(
	PgnEntries const& pgnEntries,
	SpnEntries const& spnEntries) noexcept
	: m_pgnEntries{pgnEntries}
	, m_spnEntries{spnEntries}
{
}
PgnDefinition PublicJ1939DefinitionRetriever::RetrievePgnDefinition(unsigned pgn) const
{
	auto const itEnd = std::end(m_pgnEntries);
	cat::shark::PgnEntry pgnEntry{};
	pgnEntry.set_pgn(pgn);
	auto const itLowerBound = std::lower_bound(std::begin(m_pgnEntries), itEnd,
		PgnDefinition{pgnEntry},
		[](PgnDefinition const& definition1, PgnDefinition const& definition2)
		{
			return definition1.Pgn() < definition2.Pgn();
		});
	if (itLowerBound == itEnd || itLowerBound->pgn() != pgn)
	{
		throw Error("PGN not found in PublicJ1939DefinitionRetriever: " + To<std::string>(pgn));
	}

	return PgnDefinition{*itLowerBound};
}
SpnDefinition PublicJ1939DefinitionRetriever::RetrieveSpnDefinition(unsigned spn) const
{
	auto const itEnd = std::end(m_spnEntries);
	cat::shark::SpnEntry spnEntry{};
	spnEntry.set_spn(spn);
	auto const itLowerBound = std::lower_bound(std::begin(m_spnEntries), itEnd,
		SpnDefinition{spnEntry},
		[](SpnDefinition const& definition1, SpnDefinition const& definition2)
		{
			return definition1.Spn() < definition2.Spn();
		});
	if (itLowerBound == itEnd || itLowerBound->spn() != spn)
	{
		throw Error("SPN not found in PublicJ1939DefinitionRetriever: " + To<std::string>(spn));
	}

	return SpnDefinition{*itLowerBound};
}
}
}