/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Decodes raw PID SharkByte data into a transport-neutral DecodedPidValue.

#pragma once

#include "Identifiers/IPidValueDecoder.h"

namespace Jaws
{
namespace Identifiers
{
class PidValueDecoder final : public IPidValueDecoder
{
public:
	virtual ~PidValueDecoder() override = default;
// IPidValueDecoder
	DecodedPidValue Decode(
		PidDefinition const& pidDefinition,
		Shark::SharkByteValue const& value) const override;
};
}
}
