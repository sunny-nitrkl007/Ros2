/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pid Definition Retriever Interface

#pragma once

#include "PidDefinition.h"
#include <Config/Pid.h>
#include <Utilities/DefineExceptionClass.h>

namespace Jaws
{
namespace Identifiers
{
class IPidDefinitionRetriever
{
public:
	virtual ~IPidDefinitionRetriever() = default;

	DEFINE_EXCEPTION_CLASS(Error);

	/// \exception IPidDefinitionRetriever::Error
	///            Thrown when pid is not found
	virtual PidDefinition RetrievePid(Config::Pid pid) const = 0;
	virtual MultiBytePidDefinition RetrieveMultiBytePid(Config::Pid pid) const = 0;
};
}
}