/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// MiddlewareDataType declaration

#pragma once

namespace Jaws
{
namespace Identifiers
{
enum MiddlewareDataType
{
	Boolean,
	Double,
	Raw,
	String,
	Uint,

	MiddlewareDataTypeCount
};
}
}