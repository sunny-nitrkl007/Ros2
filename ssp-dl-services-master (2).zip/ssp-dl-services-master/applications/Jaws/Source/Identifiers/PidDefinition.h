/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// The implementation of PidDefinition

#pragma once

#include <Config/Pid.h>
#include <SharkConfiguration.pb.h>
#include <Utilities/Units.h>

namespace Jaws
{
namespace Identifiers
{
class PidDefinition
{
public:
	constexpr PidDefinition(cat::shark::PidEntry const& pidEntry) noexcept
		: m_pidEntry{pidEntry}
	{
	}

	friend bool operator==(PidDefinition const& definition1, PidDefinition const& definition2);

	Config::Pid Pid() const;
	unsigned ByteCount() const;
	double UnitsPerBit() const;
	cat::shark::Unit Units() const;
	bool IsSigned() const;
	bool IsDsiCapable() const;
	bool IsLsbFirst() const;
	bool IsDouble() const;
	bool IsUint() const;
	bool IsRaw() const;
private:
	cat::shark::PidEntry const& m_pidEntry;
};
bool operator==(PidDefinition const& definition1, PidDefinition const& definition2);

class MultiBytePidDefinition
{
public:
	constexpr MultiBytePidDefinition(cat::shark::MultiBytePidEntry const& multiBytePidEntry) noexcept
		: m_multiBytePidEntry(multiBytePidEntry)
	{
	}

	friend bool operator==(MultiBytePidDefinition const& definition1, MultiBytePidDefinition const& definition2);

	Config::Pid Pid() const;
	bool IsString() const;
	bool IsBinary() const;

	unsigned MinimumParameterDataLength() const;
	unsigned MaximumParameterDataLength() const;
private:
	cat::shark::MultiBytePidEntry const& m_multiBytePidEntry;
};
bool operator==(MultiBytePidDefinition const& definition1, MultiBytePidDefinition const& definition2);
}
}