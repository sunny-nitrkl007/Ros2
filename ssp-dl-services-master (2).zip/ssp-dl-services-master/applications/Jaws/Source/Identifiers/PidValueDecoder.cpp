/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PidValueDecoder.h

#include "PidValueDecoder.h"
#include "Utilities/ArrayToHexString.h"
#include "Utilities/OverloadLambdas.h"
#include "Utilities/narrow_cast.h"
#include <algorithm>
#include <cassert>
#include <cstring>
#include <limits>
#include <utility>

namespace Jaws
{
namespace Identifiers
{
std::ostream& operator<<(std::ostream& os, DecodedPidValue const& value)
{
	os << "DecodedPidValue{quality=";
	switch (value.quality)
	{
		case DecodedPidQuality::NotReceived:
			os << "NotReceived";
			break;
		case DecodedPidQuality::Good:
			os << "Good";
			break;
		case DecodedPidQuality::Bad:
			os << "Bad";
			break;
		default:
			std::unreachable();
	}

	os << ", value=";
	std::visit(
		Utilities::OverloadLambdas{
			[&os](std::monostate const&) {
				os << "No value";
			},
			[&os](double doubleValue) {
				os << doubleValue;
			},
			[&os](uint64_t uintValue) {
				os << uintValue;
			},
			[&os](std::vector<uint8_t> const& binaryValue) {
				os << "0x" << Utilities::ArrayToHexString(binaryValue.data(), Utilities::narrow_cast<unsigned>(binaryValue.size()));
			}
		},
		value.value);
	os << "}";

	return os;
}

namespace
{
constexpr uint32_t n_dsiMinimumValues[5][2] // Indexed by byteCount and isSigned
{
	{},
	{       0xE0, 0x80 },
	{     0xFFE0, 0x8000 },
	{},
	{ 0xFFFFFFE0, 0x80000000 },
};
constexpr uint32_t n_dsiMaximumDelta = 0x1F; // maximum = minimum + 31

bool CheckIfWithinDsiRange(PidDefinition const& pidDefinition, uint32_t lsbUintData)
{
	auto inDsiRange{false};
	if (pidDefinition.IsDsiCapable())
	{
		auto const minimumDsi = n_dsiMinimumValues[pidDefinition.ByteCount()][pidDefinition.IsSigned()];
		inDsiRange = ((lsbUintData >= minimumDsi) && (lsbUintData <= minimumDsi + n_dsiMaximumDelta));
	}
	return inDsiRange;
}
uint32_t MakeDataLsbFirst(PidDefinition const& pidDefinition, uint8_t const* pData, unsigned dataLength)
{
	uint32_t lsbUintData{};
	assert(dataLength <= sizeof(lsbUintData));
	if (pidDefinition.IsLsbFirst())
	{
		memcpy(&lsbUintData, pData, dataLength);
	}
	else
	{
		auto const pDestinationArray = reinterpret_cast<unsigned char*>(&lsbUintData);
		std::reverse_copy(pData, pData + dataLength, pDestinationArray);
	}
	return lsbUintData;
}
bool SignedValueIsNegative(uint32_t data, unsigned length)
{
	auto const pDataArray = reinterpret_cast<unsigned char const*>(&data);
	auto const mostSignicantByte = pDataArray[length - 1];
	return ((mostSignicantByte & 0x80) != 0);
}
int64_t GetRawIntegerValue(PidDefinition const& pidDefinition, uint32_t lsbUintData)
{
	auto value = int64_t{};
	auto const byteCount = pidDefinition.ByteCount();
	if ( pidDefinition.IsSigned() && SignedValueIsNegative(lsbUintData, byteCount) )
	{
		value = ~0LL;
	}

	memcpy(&value, &lsbUintData, byteCount);

	return value;
}
double GetScaledValue(PidDefinition const& pidDefinition, int64_t rawValue)
{
	assert(rawValue <= std::numeric_limits<uint32_t>::max());
	return static_cast<double>(rawValue) * pidDefinition.UnitsPerBit();
}
} // unnamed namespace

DecodedPidValue PidValueDecoder::Decode(
	PidDefinition const& pidDefinition,
	Shark::SharkByteValue const& value) const
{
	DecodedPidValue decoded{};
	if (!value)
	{
		decoded.quality = DecodedPidQuality::NotReceived;
		return decoded;
	}

	if (pidDefinition.IsRaw())
	{
		decoded.quality = DecodedPidQuality::Good;
		std::vector<uint8_t> binaryValue;
		binaryValue.assign((*value).begin(), (*value).end());
		decoded.value = std::move(binaryValue);
		return decoded;
	}

	auto const lsbUintData = MakeDataLsbFirst(
		pidDefinition,
		value->data(),
		static_cast<unsigned>(value->size()));
	if (CheckIfWithinDsiRange(pidDefinition, lsbUintData))
	{
		decoded.quality = DecodedPidQuality::Bad;
		return decoded;
	}

	auto const rawValue = GetRawIntegerValue(pidDefinition, lsbUintData);
	auto const scaledValue = GetScaledValue(pidDefinition, rawValue);
	decoded.quality = DecodedPidQuality::Good;
	if (pidDefinition.IsDouble())
	{
		decoded.value = scaledValue;
	}
	else if (pidDefinition.IsUint())
	{
		decoded.value = static_cast<uint64_t>(scaledValue);
	}
	return decoded;
}
}
}
