/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Type containing the fixed-length value of a PID, as decoded from or to be encoded into raw SharkByte bytes.

#pragma once

#include <cstdint>
#include <variant>
#include <vector>

namespace Jaws::Identifiers
{
/// The variant holds:
///   - std::monostate: No value (empty state)
///   - double: Scaled floating-point value
///   - uint64_t: Scaled unsigned integer value
///   - std::vector<uint8_t>: Raw binary bytes
using FixedLengthPidValue = std::variant<std::monostate, double, uint64_t, std::vector<uint8_t>>;
}