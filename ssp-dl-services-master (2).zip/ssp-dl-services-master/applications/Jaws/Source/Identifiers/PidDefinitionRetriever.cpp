/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PidDefinitionRetriever.h

#include "PidDefinitionRetriever.h"
#include <Utilities/Conversions.h>
#include <algorithm>
namespace Jaws
{
namespace Identifiers
{
namespace
{
template <typename Entries>
auto const* TryToFindPid(Entries const& pidEntries, ::Config::Pid pid)
{
	typename Entries::value_type pidEntry{};
	pidEntry.set_pid(pid);
	auto itEnd = std::end(pidEntries);
	auto itLowerBound = std::lower_bound(std::begin(pidEntries), itEnd,
		pidEntry,
		[](auto const& entry1, auto const& entry2)
		{
			return entry1.pid() < entry2.pid();
		});
	decltype(&*itLowerBound) pPidEntry{};
	if (itLowerBound != itEnd && itLowerBound->pid() == pid)
	{
		pPidEntry = &*itLowerBound;
	}
	return pPidEntry;
}
#ifndef NDEBUG
template <typename Entries>
bool IsSorted(Entries const& pidEntries)
{
	return std::is_sorted(
		pidEntries.begin(),
		pidEntries.end(),
		[](auto&& first, auto&& second){ return first.pid() < second.pid(); });
}
#endif
}

PidDefinitionRetriever::PidDefinitionRetriever(
	PidEntries const& pidEntries,
	MultiBytePidEntries const& multiBytePidEntries) noexcept
	: m_pidEntries(pidEntries)
	, m_multiBytePidEntries(multiBytePidEntries)
{
	assert(IsSorted(m_pidEntries));
	assert(IsSorted(m_multiBytePidEntries));
}
PidDefinition PidDefinitionRetriever::RetrievePid(Config::Pid pid) const
{
	auto const pPidEntry = TryToFindPid(m_pidEntries, pid);
	if (!pPidEntry)
	{
		throw Error("PID not found in PidDefinitionRetriever: " + To<std::string>(pid));
	}
	return PidDefinition{*pPidEntry};
}
MultiBytePidDefinition PidDefinitionRetriever::RetrieveMultiBytePid(Config::Pid pid) const
{
	auto const pPidEntry = TryToFindPid(m_multiBytePidEntries, pid);
	if (!pPidEntry)
	{
		throw Error("Multi-byte PID not found in PidDefinitionRetriever: " + To<std::string>(pid));
	}
	return MultiBytePidDefinition{*pPidEntry};
}
}
}