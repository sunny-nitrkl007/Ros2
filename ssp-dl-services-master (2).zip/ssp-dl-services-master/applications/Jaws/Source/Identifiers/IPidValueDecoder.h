/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Interface for decoding raw PID SharkByte bytes

#pragma once

#include "Identifiers/PidDefinition.h"
#include "Identifiers/FixedLengthPidValue.h"
#include <Shark/ISharkByte.h>
#include <ostream>

namespace Jaws
{
namespace Identifiers
{
/// Coarse validity of a decoded PID value.
enum class DecodedPidQuality
{
	NotReceived,
	Good,
	Bad
};

struct DecodedPidValue
{
	DecodedPidQuality quality{DecodedPidQuality::NotReceived};
	FixedLengthPidValue value;
};
std::ostream& operator<<(std::ostream& os, DecodedPidValue const& value);

/// Decodes the raw bytes of a PID SharkByte into a DecodedPidValue, applying byte
/// ordering, DSI range checks, sign extension and scaling as described by the
/// PidDefinition.
class IPidValueDecoder
{
public:
	virtual ~IPidValueDecoder() = default;

	virtual DecodedPidValue Decode(
		PidDefinition const& pidDefinition,
		Shark::SharkByteValue const& value) const = 0;
};
}
}
