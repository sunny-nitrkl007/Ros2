/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PGN Definition

#pragma once

#include <Config/Spn.h>
#include <SharkConfiguration.pb.h>

namespace Jaws
{
namespace Identifiers
{
class SpnDefinition
{
public:
	constexpr SpnDefinition(cat::shark::SpnEntry const& spnEntry) noexcept
		: m_spnEntry{spnEntry}
	{
	}

	friend bool operator==(SpnDefinition const& definition1, SpnDefinition const& definition2);

	Config::Spn Spn() const;
	unsigned BitCount() const;
	double UnitsPerBit() const;
	cat::shark::Unit Units() const;
	double ValueOffset() const;
	bool IsDouble() const;
	bool IsUint() const;

private:
	cat::shark::SpnEntry const& m_spnEntry;
};
bool operator==(SpnDefinition const& definition1, SpnDefinition const& definition2);
}
}