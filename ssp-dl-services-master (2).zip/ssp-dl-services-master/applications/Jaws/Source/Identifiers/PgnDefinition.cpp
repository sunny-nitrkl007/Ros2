/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PgnDefinition.h

#include "PgnDefinition.h"
#include <cassert>

namespace Jaws
{
namespace Identifiers
{
Config::Pgn PgnDefinition::Pgn() const
{
	return m_pgnEntry.pgn();
}
std::optional<unsigned> PgnDefinition::FindSpnOffset(unsigned spn) const
{
	std::optional<unsigned> offset{};
	auto const& offsetSpns = m_pgnEntry.offset_spns();
	auto const iterEnd = offsetSpns.cend();
	auto iterFind = std::find_if(offsetSpns.cbegin(), iterEnd,
		[spn](auto const& offsetSpnEntry)
		{
			return offsetSpnEntry.spn() == spn;
		});
	if (iterFind != iterEnd)
	{
		offset = iterFind->bit_offset();
	}
	return offset;
}
bool operator==(PgnDefinition const& definition1, PgnDefinition const& definition2)
{
	return &(definition1.m_pgnEntry) == &(definition2.m_pgnEntry);
}
}
}