/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Safe NVM file saver interface

#pragma once

#include <string>

namespace Jaws
{
namespace Nvm
{
class ISafeNvmFileSaver
{
public:
	virtual ~ISafeNvmFileSaver() = default;

	virtual void CreateTemporaryNvmFile(
		std::string const& temporaryNvmFilePath,
		std::string const& nvmContents) const = 0;
	virtual void RemoveCrcFile(std::string const& crcFilePath) const = 0;
	virtual void ReplaceNvmFileWithTheTemporaryNvmFile(
		std::string const& newNvmFilePath,
		std::string const& nvmFilePath) const = 0;
	virtual void CreateNewCrcFile(std::string const& crcFilePath, std::string const& crc) const = 0;
};
}
}