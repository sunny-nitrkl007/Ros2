/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Ensures NVM saves are atomic

#pragma once

#include "ISafeNvmFileSaver.h"

namespace Utilities{ class IFilesystem; }
namespace Jaws
{
namespace Nvm
{
class SafeNvmFileSaver final : public ISafeNvmFileSaver
{
public:
	explicit SafeNvmFileSaver(Utilities::IFilesystem& filesystem);
// ISafeNvmFileSaver
	void CreateTemporaryNvmFile(
		std::string const& temporaryNvmFilePath,
		std::string const& nvmContents) const override;
	void RemoveCrcFile(std::string const& crcFilePath) const override;
	void ReplaceNvmFileWithTheTemporaryNvmFile(
		std::string const& newNvmFilePath,
		std::string const& nvmFilePath) const override;
	void CreateNewCrcFile(std::string const& crcFilePath, std::string const& crc) const override;
private:
	Utilities::IFilesystem& m_filesystem;
};
}
}