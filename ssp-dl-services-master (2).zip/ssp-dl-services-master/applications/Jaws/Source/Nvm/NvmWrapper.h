/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Nvm Wrapper Interface

#pragma once

#include "INvmWrapper.h"
#include <memory>
#include <mutex>
#include <pugixml.hpp>

namespace Utilities {class IEnvironment;}
namespace Jaws
{
namespace Nvm
{
class INvmXmlFile;

class NvmWrapper final : public INvmWrapper
{
public:
	static std::unique_ptr<NvmWrapper> Create(Utilities::IEnvironment const& environment);

	NvmWrapper(std::unique_ptr<INvmXmlFile>&& spFile) noexcept;
	~NvmWrapper() override;
	// INvmWrapper
	std::string Read(std::string const& valueName, std::string const& defaultValue) override;
	void Write(std::string const& valueName, std::string const& value) override;

private:
	pugi::xml_node GetValueNode(std::string_view const& valueName);
	void SetValue(std::string_view const& valueName, std::string_view const& value);
	void SaveNvmFile();

	std::unique_ptr<INvmXmlFile> const m_spFile;
	std::mutex m_mutex{};
};
}
}
