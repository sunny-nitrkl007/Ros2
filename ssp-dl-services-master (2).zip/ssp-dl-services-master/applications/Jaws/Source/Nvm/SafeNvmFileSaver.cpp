/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Ensures NVM saves are atomic

#include "SafeNvmFileSaver.h"
#include "Log.h"
#include <Utilities/IFilesystem.h>
#include <exception>

namespace Jaws
{
namespace Nvm
{
SafeNvmFileSaver::SafeNvmFileSaver(Utilities::IFilesystem& filesystem)
	: m_filesystem{filesystem}
{
}
void SafeNvmFileSaver::CreateTemporaryNvmFile(
	std::string const& temporaryNvmFilePath,
	std::string const& nvmContents) const
{
	try
	{
		m_filesystem.WriteToFile(temporaryNvmFilePath, nvmContents);
	}
	catch (std::exception const&)
	{
		LOG_ERROR_TAG(Log::Nvm, "Could not save NVM file: " << temporaryNvmFilePath);
	}
}
void SafeNvmFileSaver::RemoveCrcFile(std::string const& crcFilePath) const
{
	m_filesystem.Remove(crcFilePath);
}
void SafeNvmFileSaver::ReplaceNvmFileWithTheTemporaryNvmFile(
	std::string const& newNvmFilePath,
	std::string const& nvmFilePath) const
{
	/// Use rename so the old file will be replaced with the new file atomically.
	m_filesystem.Rename(newNvmFilePath, nvmFilePath);
}
void SafeNvmFileSaver::CreateNewCrcFile(std::string const& crcFilePath, std::string const& crc) const
{
	m_filesystem.WriteToFile(crcFilePath, crc);
}
}
}