/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Nvm XML File Interface

#pragma once

#include <pugixml.hpp>

namespace Jaws
{
namespace Nvm
{
class INvmXmlFile
{
public:
	virtual ~INvmXmlFile() = default;

	virtual pugi::xml_node NvmNode() const = 0;
	virtual void Save() const = 0;
};
}
}
