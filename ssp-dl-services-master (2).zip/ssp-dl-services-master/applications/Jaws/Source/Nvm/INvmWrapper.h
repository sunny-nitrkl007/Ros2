/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Nvm Wrapper Interface

#pragma once

#include <string>

namespace Jaws
{
namespace Nvm
{
class INvmWrapper
{
public:
	virtual ~INvmWrapper() = default;

	virtual std::string Read(std::string const& valueName, std::string const& defaultValue) = 0;
	virtual void Write(std::string const& valueName, std::string const& value) = 0;
};
}
}
