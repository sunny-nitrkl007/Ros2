/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// NVM Wrapper

#include "NvmWrapper.h"
#include "Log.h"
#include "NvmXmlFile.h"
#include <Utilities/IEnvironment.h>
#include <Utilities/NvmXmlDefinitions.h>
#include <Utilities/nice_ptr.h>
#include <boost/date_time/date_defs.hpp>
#include <cassert>

using namespace std::chrono_literals;

namespace Jaws
{
namespace Nvm
{
std::unique_ptr<NvmWrapper> NvmWrapper::Create(Utilities::IEnvironment const& environment)
{
	auto const persistentStoragePath = std::string{environment.JawsSettingsNvmFilePath()};

	LOG_INFO_HIGH_TAG(Log::Nvm, "Using persistent storage path: " << persistentStoragePath.c_str());

	auto spNvmXmlFile = NvmXmlFile::Create(persistentStoragePath, environment.Application());
	auto spWrapper	  = std::make_unique<NvmWrapper>(std::move(spNvmXmlFile));

	return spWrapper;
}

NvmWrapper::NvmWrapper(std::unique_ptr<INvmXmlFile>&& spFile) noexcept : m_spFile(std::move(spFile))
{
	assert(m_spFile);
}
NvmWrapper::~NvmWrapper() = default;
void NvmWrapper::SaveNvmFile()
{
	m_spFile->Save();
}
std::string NvmWrapper::Read(std::string const& valueName, std::string const& defaultValue)
{
	std::unique_lock<std::mutex> lock{m_mutex};
	std::string value{};
	auto const valueNode = GetValueNode(valueName);
	auto const attribute = valueNode.attribute(Utilities::NvmXmlDefinitions::ValueAttributeName());
	if (attribute)
	{
		value = attribute.value();
	}
	else
	{
		SetValue(valueName, defaultValue);
		value = defaultValue;
	}

	return value;
}
void NvmWrapper::Write(std::string const& valueName, std::string const& value)
{
	std::unique_lock<std::mutex> lock{m_mutex};
	SetValue(valueName, value);

	// TODO: Saving should be done on a separate thread again
	SaveNvmFile();
}
pugi::xml_node NvmWrapper::GetValueNode(std::string_view const& valueName)
{
	auto const nvmNode = m_spFile->NvmNode();
	return nvmNode.child(valueName.data());
}
void NvmWrapper::SetValue(std::string_view const& valueName, std::string_view const& value)
{
	auto valueNode = GetValueNode(valueName);
	if (!valueNode)
	{
		auto nvmNode = m_spFile->NvmNode();
		valueNode	 = nvmNode.append_child(valueName.data());
	}

	auto valueAttribute = valueNode.attribute(Utilities::NvmXmlDefinitions::ValueAttributeName());
	if (!valueAttribute)
	{
		valueAttribute = valueNode.append_attribute(Utilities::NvmXmlDefinitions::ValueAttributeName());
	}

	auto const succeeded = valueAttribute.set_value(value.data());
	assert(succeeded);
	(void)succeeded;
}
}
}
