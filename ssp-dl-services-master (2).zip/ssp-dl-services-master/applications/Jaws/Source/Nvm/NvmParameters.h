/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Nvm Parameter definitions

#pragma once

namespace Jaws
{
namespace Nvm
{
	static constexpr char const* JawsConfigurationNvmId() { return "Configuration"; }
}
}
