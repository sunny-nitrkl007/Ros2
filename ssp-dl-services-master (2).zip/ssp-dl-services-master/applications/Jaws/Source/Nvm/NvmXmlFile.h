/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Nvm XML File Wrapper

#pragma once

#include "INvmXmlFile.h"
#include <memory>
#include <optional>
#include <string>

namespace Utilities { class IFilesystem; }
namespace Jaws
{
namespace Nvm
{
class ISafeNvmFileSaver;

/// Exposes a mutable pugi::xml_node. All uses of the node and calls to Save() must
/// be protected against multi-threaded access.
class NvmXmlFile final : public INvmXmlFile
{
public:
	static std::unique_ptr<NvmXmlFile> Create(
		std::string const& filePath,
		std::string const& application);
	static constexpr auto TemporaryFileExtension() { return ".new"; }

	NvmXmlFile(
		std::string const& filePath,
		std::string const& temporaryFilePath,
		std::unique_ptr<Utilities::IFilesystem>&& spFilesystem,
		std::unique_ptr<ISafeNvmFileSaver>&& spSafeNvmFileSaver,
		std::string const& application);
	~NvmXmlFile() override;
// INvmXmlFile
	pugi::xml_node NvmNode() const override;
	void Save() const override;
private:
	std::optional<std::string> ReadFile();
	bool IsCrcValid(std::string const& xml);
	bool LoadDocumentFromFile();
	bool IsDocumentValid(std::string const& sharkApplication) const;
	void LoadDefaultDocument(std::string const& application);
	char const* GetSchemaVersion() const;
	char const* GetApplication() const;

	std::string const m_filePath;
	std::string const m_temporaryFilePath;
	std::unique_ptr<Utilities::IFilesystem> const m_spFilesystem;
	std::unique_ptr<ISafeNvmFileSaver> const m_spSafeNvmFileSaver;
	pugi::xml_document m_document{};
};
}
}
