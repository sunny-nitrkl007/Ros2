/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Nvm XML File

#include "NvmXmlFile.h"
#include "Log.h"
#include "SafeNvmFileSaver.h"
#include <Utilities/Conversions.h>
#include <Utilities/Filesystem.h>
#include <Utilities/NvmXmlDefinitions.h>
#include <cassert>
#include <crc32c/crc32c.h>
#include <cstring>

using Utilities::NvmXmlDefinitions;

namespace Jaws
{
namespace Nvm
{
namespace
{
std::string CreateTemporaryNvmFilePath(std::string const& filePath)
{
	return filePath + NvmXmlFile::TemporaryFileExtension();
}
}  // namespace

std::unique_ptr<NvmXmlFile> NvmXmlFile::Create(std::string const& filePath, std::string const& application)
{
	auto spFilesystem = std::make_unique<Utilities::Filesystem>();
	auto spSafeNvmFileSaver = std::make_unique<SafeNvmFileSaver>(*spFilesystem);
	return std::make_unique<NvmXmlFile>(
		filePath,
		CreateTemporaryNvmFilePath(filePath),
		std::move(spFilesystem),
		std::move(spSafeNvmFileSaver),
		application);
}

NvmXmlFile::NvmXmlFile(
	std::string const& filePath,
	std::string const& temporaryFilePath,
	std::unique_ptr<Utilities::IFilesystem>&& spFilesystem,
	std::unique_ptr<ISafeNvmFileSaver>&& spSafeNvmFileSaver,
	std::string const& application)
	: m_filePath{filePath}
	, m_temporaryFilePath{temporaryFilePath}
	, m_spFilesystem{std::move(spFilesystem)}
	, m_spSafeNvmFileSaver{std::move(spSafeNvmFileSaver)}
{
	assert(m_spFilesystem);
	assert(m_spSafeNvmFileSaver);

	LOG_DEBUG_TAG(Log::Nvm | Log::Init, "Opening file: " << m_filePath);
	auto isDocumentValid = false;

	if (LoadDocumentFromFile())
	{
		isDocumentValid = IsDocumentValid(application);
	}

	if (!isDocumentValid)
	{
		LoadDefaultDocument(application);
		Save();
	}
}
NvmXmlFile::~NvmXmlFile() = default;
pugi::xml_node NvmXmlFile::NvmNode() const
{
	return m_document.first_child();
}
void NvmXmlFile::Save() const
{
	LOG_INFO_HIGH_TAG(Log::Nvm, "Saving NVM file");

	assert(IsDocumentValid(GetApplication()));
	std::stringstream stream{};
	m_document.save(stream, NvmXmlDefinitions::Indent(), NvmXmlDefinitions::SaveFlags());

	auto const xml = stream.str();
	m_spSafeNvmFileSaver->CreateTemporaryNvmFile(m_temporaryFilePath, xml);

	auto const crcFilePath = NvmXmlDefinitions::MakeCrcFilePath(m_filePath);
	m_spSafeNvmFileSaver->RemoveCrcFile(crcFilePath);  // Ensure that we don't get the new file with the old CRC

	m_spSafeNvmFileSaver->ReplaceNvmFileWithTheTemporaryNvmFile(m_temporaryFilePath, m_filePath);

	auto const crc = To<std::string>(crc32c::Crc32c(std::string_view{xml.data()}));
	m_spSafeNvmFileSaver->CreateNewCrcFile(crcFilePath, crc);
}
std::optional<std::string> NvmXmlFile::ReadFile()
{
	std::optional<std::string> xml{};

	try
	{
		xml = m_spFilesystem->ReadFromFile(m_filePath);
	}
	catch (std::exception const&)
	{
		LOG_INFO_HIGH_TAG(Log::Nvm, "Could not open file: " << m_filePath);
	}

	return xml;
}
bool NvmXmlFile::IsCrcValid(std::string const& xml)
{
	auto isValid = true;

	auto const crcFilePath = NvmXmlDefinitions::MakeCrcFilePath(m_filePath);
	if (!m_spFilesystem->Exists(crcFilePath))
	{
		LOG_INFO_HIGH_TAG(Log::Nvm, "Could not open CRC file: " << crcFilePath);
		// The lack of a CRC file means that the CRC is valid.
	}
	else
	{
		std::string crcFromFile = *m_spFilesystem->ReadFromFile(crcFilePath);

		auto const generatedCrc = To<std::string>(crc32c::Crc32c(std::string_view{xml.data()}));

		if (crcFromFile != generatedCrc)
		{
			LOG_ERROR_TAG(Log::Nvm, "CRC is not correct: " << std::hex << crcFromFile << " != " << generatedCrc);
			isValid = false;
		}
	}

	return isValid;
}
bool NvmXmlFile::LoadDocumentFromFile()
{
	auto isFullyLoaded = false;

	auto const xml = ReadFile();
	if (xml)
	{
		if (IsCrcValid(*xml))
		{
			auto const fileParseResult = m_document.load_string(xml->c_str());
			if (!fileParseResult)
			{
				LOG_ERROR_TAG(Log::Nvm, "Could not parse file: " << m_filePath << ": " << fileParseResult.description());
			}
			else
			{
				isFullyLoaded = true;
			}
		}
	}

	return isFullyLoaded;
}
bool NvmXmlFile::IsDocumentValid(std::string const& sharkApplication) const
{
	auto isValid = false;

	auto const nvmNode = NvmNode();
	auto const pNvmNodeName = nvmNode.name();
	auto const pSchemaVersion = GetSchemaVersion();
	auto const pNvmApplication = GetApplication();
	auto const nextSiblingNode = nvmNode.next_sibling();

	if (strcmp(pNvmNodeName, NvmXmlDefinitions::NvmNodeName()) != 0)
	{
		LOG_ERROR_TAG(Log::Nvm, "File has an incorrect first node: " << pNvmNodeName);
	}
	else if (strcmp(pSchemaVersion, NvmXmlDefinitions::SchemaVersion()) != 0)
	{
		LOG_WARNING_TAG(Log::Nvm, "File was created for a different schema version: " << pSchemaVersion);
	}
	else if (pNvmApplication != sharkApplication)
	{
		LOG_WARNING_TAG(Log::Nvm, "File was created for a different application: " << pNvmApplication);
	}
	else if (nextSiblingNode)
	{
		LOG_ERROR_TAG(Log::Nvm, "File has an unexpected second node: " << nextSiblingNode.name());
	}
	else
	{
		isValid = true;
	}

	return isValid;
}
void NvmXmlFile::LoadDefaultDocument(std::string const& application)
{
	m_document.reset();
	auto nvmNode = m_document.append_child(NvmXmlDefinitions::NvmNodeName());
	nvmNode.append_attribute(NvmXmlDefinitions::SchemaVersionAttributeName())
		.set_value(NvmXmlDefinitions::SchemaVersion());
	nvmNode.append_attribute(NvmXmlDefinitions::ApplicationAttributeName()).set_value(application.c_str());
	assert(IsDocumentValid(application));

	LOG_INFO_HIGH_TAG(Log::Nvm, "Using the default NVM file contents");
}
char const* NvmXmlFile::GetSchemaVersion() const
{
	return NvmNode().attribute(NvmXmlDefinitions::SchemaVersionAttributeName()).value();
}
char const* NvmXmlFile::GetApplication() const
{
	return NvmNode().attribute(NvmXmlDefinitions::ApplicationAttributeName()).value();
}
}
}
