/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Logging framework

#pragma once

#include <cstdint>
#include <iostream>

namespace Log
{
enum class SeverityLevel
{
	Debug,
	InfoLow,
	InfoHigh,
	Warning,
	Error,

	Count
};
enum Tag : uint64_t
{
	None            = 0,
	Init            = 1ul <<  0,
	Parameter       = 1ul <<  1,
	Nvm             = 1ul <<  2,
	Diagnostics     = 1ul <<  3,
	Read            = 1ul <<  4,
	Write           = 1ul <<  5,
	Calibrations    = 1ul <<  6,

	MaxTagPlusOne,
};
std::ostream& operator<<(std::ostream& stream, Tag tag);

// Filtering mechanism
constexpr SeverityLevel MINIMUM_LOGGED_SEVERITY = SeverityLevel::InfoHigh;
constexpr uint64_t ALWAYS_LOGGED_TAGS = None;
}

#define MY_LOGGER g_jawsLogger
#include <Log/LogBase.h>
