/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See InitializerFactory.h

#include "InitializerFactory.h"
#include "DependencyContainer.h"
#include "Middleware/CalibrationWrapper.h"
#include "Middleware/DiagnosticWrapper.h"
#include "Middleware/MachineSecuritySystemWrapper.h"
#include "Middleware/ParameterWrapper.h"
#include "Utilities/CountOf.h"
#include <cassert>

namespace Jaws
{
namespace
{
bool ShouldAlwaysBeCreated(DependencyContainer const&) { return true; }

struct InitializerFactoryEntry
{
	bool (*pShouldCreateInitializer)(DependencyContainer const& container);
	std::function<void()> (*pCreateInitializer)(DependencyContainer const& container);
};

#define INITIALIZER_FACTORY_ENTRY(x) { &x::ShouldBeCreated, &x::CreateInitializer }
#define INITIALIZER_FACTORY_ALWAYS_INITIALIZED_ENTRY(x) { &ShouldAlwaysBeCreated, &x::CreateInitializer }

constexpr InitializerFactoryEntry n_initializerFactoryEntries[] {
	INITIALIZER_FACTORY_ENTRY(Middleware::DiagnosticWrapper),
	INITIALIZER_FACTORY_ENTRY(Middleware::MachineSecuritySystemWrapper),
	INITIALIZER_FACTORY_ENTRY(Middleware::CalibrationWrapper),

	// Should be initialized last to take the list of Shark to Middleware
	// definitions after all other initializers have had a chance to add to it.
	INITIALIZER_FACTORY_ALWAYS_INITIALIZED_ENTRY(Middleware::ParameterWrapper),
};
}

InitializerFactory::InitializerFactory(DependencyContainer const& dependencyContainer)
	: m_dependencyContainer{dependencyContainer}
{
}
std::vector<std::function<void()>> InitializerFactory::CreateInitializers()
{
	std::vector<std::function<void()>> initializers{};
	initializers.reserve(Utilities::CountOf(n_initializerFactoryEntries));
	for (auto&& entry : n_initializerFactoryEntries)
	{
		if (entry.pShouldCreateInitializer(m_dependencyContainer))
		{
			auto initializer = entry.pCreateInitializer(m_dependencyContainer);
			assert(initializer);
			initializers.emplace_back(std::move(initializer));
		}
	}

	return initializers;
}
}
