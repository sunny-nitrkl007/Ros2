/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Interface for loading the Jaws protobuf configuration from NVM.

#pragma once

#include "Nvm/INvmWrapper.h"
#include <SharkConfiguration.pb.h>
#include <Utilities/OptionalSmartPointers.h>

namespace Jaws
{
/// Reads and parses the Jaws configuration that is stored in NVM as a protobuf-JSON
/// string.
class IConfigLoader
{
public:
	virtual ~IConfigLoader() = default;

	/// Reads the configuration string from NVM and parses it into a cat::shark::Config.
	/// Returns nullptr when the stored configuration is not valid.
	virtual Utilities::optional_unique_ptr<cat::shark::Config> LoadFromNvm(
		Nvm::INvmWrapper& nvmWrapper) const = 0;
};
}
