/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See ConfigFormatter.h

#include "ConfigFormatter.h"

#include <google/protobuf/descriptor.h>
#include <format>
#include <optional>
#include <sstream>

namespace Jaws
{
namespace
{
namespace pb = google::protobuf;

void FormatMessage(
	pb::Message const& message,
	std::ostringstream& oss,
	unsigned indent,
	std::unordered_set<std::string> const& hexFields);

void FormatFieldValue(
	pb::Message const& message,
	pb::FieldDescriptor const* field,
	std::optional<int> repeatedIndex,
	std::ostringstream& oss,
	unsigned indent,
	std::unordered_set<std::string> const& hexFields)
{
	auto const* reflection = message.GetReflection();
	bool const hex = hexFields.contains(field->name());
	bool const repeated = repeatedIndex.has_value();

	switch (field->type())
	{
	case pb::FieldDescriptor::TYPE_UINT32:
	case pb::FieldDescriptor::TYPE_FIXED32:
	{
		auto val = repeated
			? reflection->GetRepeatedUInt32(message, field, *repeatedIndex)
			: reflection->GetUInt32(message, field);
		if (hex)
		{
			oss << std::format("0x{:X}", val);
		}
		else
		{
			oss << val;
		}
		break;
	}
	case pb::FieldDescriptor::TYPE_INT32:
	case pb::FieldDescriptor::TYPE_SINT32:
	case pb::FieldDescriptor::TYPE_SFIXED32:
	{
		auto val = repeated
			? reflection->GetRepeatedInt32(message, field, *repeatedIndex)
			: reflection->GetInt32(message, field);
		oss << val;
		break;
	}
	case pb::FieldDescriptor::TYPE_UINT64:
	case pb::FieldDescriptor::TYPE_FIXED64:
	{
		auto val = repeated
			? reflection->GetRepeatedUInt64(message, field, *repeatedIndex)
			: reflection->GetUInt64(message, field);
		if (hex)
		{
			oss << std::format("0x{:X}", val);
		}
		else
		{
			oss << val;
		}
		break;
	}
	case pb::FieldDescriptor::TYPE_INT64:
	case pb::FieldDescriptor::TYPE_SINT64:
	case pb::FieldDescriptor::TYPE_SFIXED64:
	{
		auto val = repeated
			? reflection->GetRepeatedInt64(message, field, *repeatedIndex)
			: reflection->GetInt64(message, field);
		oss << val;
		break;
	}
	case pb::FieldDescriptor::TYPE_DOUBLE:
	{
		auto val = repeated
			? reflection->GetRepeatedDouble(message, field, *repeatedIndex)
			: reflection->GetDouble(message, field);
		oss << val;
		break;
	}
	case pb::FieldDescriptor::TYPE_FLOAT:
	{
		auto val = repeated
			? reflection->GetRepeatedFloat(message, field, *repeatedIndex)
			: reflection->GetFloat(message, field);
		oss << val;
		break;
	}
	case pb::FieldDescriptor::TYPE_BOOL:
	{
		auto val = repeated
			? reflection->GetRepeatedBool(message, field, *repeatedIndex)
			: reflection->GetBool(message, field);
		oss << (val ? "true" : "false");
		break;
	}
	case pb::FieldDescriptor::TYPE_STRING:
	case pb::FieldDescriptor::TYPE_BYTES:
	{
		if (repeated)
		{
			oss << "\"" << reflection->GetRepeatedString(message, field, *repeatedIndex) << "\"";
		}
		else
		{
			oss << "\"" << reflection->GetString(message, field) << "\"";
		}
		break;
	}
	case pb::FieldDescriptor::TYPE_ENUM:
	{
		auto const* val = repeated
			? reflection->GetRepeatedEnum(message, field, *repeatedIndex)
			: reflection->GetEnum(message, field);
		oss << val->name();
		break;
	}
	case pb::FieldDescriptor::TYPE_MESSAGE:
	{
		auto const& subMsg = repeated
			? reflection->GetRepeatedMessage(message, field, *repeatedIndex)
			: reflection->GetMessage(message, field);
		oss << "{\n";
		FormatMessage(subMsg, oss, indent + 1, hexFields);
		oss << std::string(indent * 2, ' ') << "}";
		break;
	}
	default:
		oss << "?";
		break;
	}
}

void FormatMessage(
	pb::Message const& message,
	std::ostringstream& oss,
	unsigned indent,
	std::unordered_set<std::string> const& hexFields)
{
	auto const* descriptor = message.GetDescriptor();
	auto const* reflection = message.GetReflection();
	std::string const pad(indent * 2, ' ');

	for (int i = 0; i < descriptor->field_count(); ++i)
	{
		auto const* field = descriptor->field(i);

		if (field->is_repeated())
		{
			int const count = reflection->FieldSize(message, field);
			for (int j = 0; j < count; ++j)
			{
				oss << pad << field->name() << ": ";
				FormatFieldValue(message, field, j, oss, indent, hexFields);
				oss << "\n";
			}
			continue;
		}

		if (field->has_presence() && !reflection->HasField(message, field))
		{
			continue;
		}

		oss << pad << field->name() << ": ";
		FormatFieldValue(message, field, std::nullopt, oss, indent, hexFields);
		oss << "\n";
	}
}
}

ConfigFormatter::ConfigFormatter(std::unordered_set<std::string> hexFields)
	: m_hexFields(std::move(hexFields))
{
}

std::string ConfigFormatter::Format(google::protobuf::Message const& message) const
{
	std::ostringstream oss;
	FormatMessage(message, oss, 0u, m_hexFields);
	return oss.str();
}
}
