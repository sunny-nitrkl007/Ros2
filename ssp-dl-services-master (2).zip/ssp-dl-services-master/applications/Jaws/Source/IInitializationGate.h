/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Interface for a thread-safe initialization gate.

#pragma once

#include <functional>

namespace Jaws
{
class IInitializationGate
{
public:
	virtual ~IInitializationGate() = default;

	virtual bool IsReady() const = 0;
	virtual void SetReady() = 0;

	/// If the gate is ready, executes the action immediately with `true`.
	/// Otherwise, queues the action to be executed when SetReady() is called with `false`.
	virtual void EnqueueOrExecute(std::move_only_function<void(bool immediate)>&& action) const = 0;
};
}
