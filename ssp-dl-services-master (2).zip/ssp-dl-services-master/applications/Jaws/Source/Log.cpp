/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Log.h

#include "Log.h"
#include <Utilities/narrow_cast.h>
#include <cassert>
#include <cmath>

#include <Log/LogBase.cpp>

namespace Log
{
std::ostream& operator<<(std::ostream& stream, Tag tag)
{
	static auto const s_tagStrings = std::vector<char const*>
	{
		// Do not include "None" since it is never displayed.
		"Jaws Init",
		"Parameters",
		"Nvm",
		"Diagnostics",
		"Read",
		"Write",
		"Calibrations",
	};
	assert( (Utilities::narrow_cast<size_t>(std::log2(static_cast<double>(Log::MaxTagPlusOne) - 1.0)) + 1) == s_tagStrings.size() );

	return Detail::OutputTag(stream, tag, s_tagStrings);
}
}

/// Provide the logger to SHARK or any other libs.
boost::log::sources::severity_logger_mt<Log::SeverityLevel>& GetLogger()
{
	return Log::MY_LOGGER::get();
}
