/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Loads and parses the Jaws protobuf configuration stored in NVM.

#pragma once

#include "IConfigLoader.h"

namespace Jaws
{
class ConfigLoader final : public IConfigLoader
{
public:
	~ConfigLoader() override = default;
// IConfigLoader
	Utilities::optional_unique_ptr<cat::shark::Config> LoadFromNvm(
		Nvm::INvmWrapper& nvmWrapper) const override;
};
}
