/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See JawsNode.h

#include "JawsNode.h"
#include "Identifiers/IPidDefinitionRetriever.h"
#include "Identifiers/IPidValueDecoder.h"
#include "Log.h"
#include <SharkConfiguration.pb.h>

namespace Jaws
{
namespace Ros2
{
namespace
{
/// Appends to publishers
template <typename PidConfigArray>
void CreatePidPublishers(
	rclcpp::Node& node,
	PidConfigArray const& pidConfigArray,
	Shark::ISharkByteRetriever const& sharkByteRetriever,
	Identifiers::IPidDefinitionRetriever const& pidDefinitionRetriever,
	Identifiers::IPidValueDecoder const& pidValueDecoder,
	std::vector<std::unique_ptr<Ros2PidParameterDataPublisher>>& publishers)
{
	for (auto const& entry : pidConfigArray)
	{
		auto const pidDefinition = pidDefinitionRetriever.RetrievePid(entry.pid());
		auto spPublisher = Ros2PidParameterDataPublisher::Create(
			node,
			entry.middleware_id(),
			pidDefinition,
			pidValueDecoder);
		spPublisher->Initialize(sharkByteRetriever);
		publishers.emplace_back(std::move(spPublisher));
	}
}
std::vector<std::unique_ptr<Ros2PidParameterDataPublisher>> CreateAllPidPublishers(
	DependencyContainer const& dependencyContainer,
	rclcpp::Node& node)
{
	std::vector<std::unique_ptr<Ros2PidParameterDataPublisher>> publishers{};

	auto const createPublishers = [&node, &dependencyContainer, &publishers](auto const& pidArray) {
		return CreatePidPublishers(
			node,
			pidArray,
			dependencyContainer.GetISharkByteRetriever(),
			dependencyContainer.GetIPidDefinitionRetriever(),
			dependencyContainer.GetIPidValueDecoder(),
			publishers);
	};

	for (auto const& j1939DataLink : dependencyContainer.GetSharkConfig().j1939_data_links())
	{
		for (auto const& peerNode : j1939DataLink.peer_nodes())
		{
			if (peerNode.has_adt())
			{
				createPublishers(peerNode.adt().adt_pids());
			}

			if (peerNode.has_pgb())
			{
				createPublishers(peerNode.pgb().pgb_pids());
			}
		}
	}

	return publishers;
}
std::vector<std::unique_ptr<Ros2PidParameterWriteService>> CreateAllPidWriteServices(
	DependencyContainer const& dependencyContainer,
	rclcpp::Node& node)
{
	std::vector<std::unique_ptr<Ros2PidParameterWriteService>> writeServices{};

	for (auto const& j1939DataLink : dependencyContainer.GetSharkConfig().j1939_data_links())
	{
		for (auto const& peerNode : j1939DataLink.peer_nodes())
		{
			if (peerNode.has_basic_read_write())
			{
				for (auto const& entry : peerNode.basic_read_write().basic_read_write_pids())
				{
					Config::Pid pid{entry.pid()};
					if (pid.IsMultiByte())
					{
						continue;
					}

					auto const pidDefinition = dependencyContainer.GetIPidDefinitionRetriever().RetrievePid(entry.pid());
					auto spWriteService = Ros2PidParameterWriteService::Create(
						node,
						entry.middleware_id(),
						pidDefinition,
						dependencyContainer.GetIPidValueEncoder(),
						dependencyContainer.GetIPidValueDecoder());
					spWriteService->Initialize(dependencyContainer.GetIWriteSharkByteRetriever());
					writeServices.emplace_back(std::move(spWriteService));
				}
			}
		}
	}

	return writeServices;
}

constexpr char const* n_pNodeName = "jaws";
}

std::shared_ptr<JawsNode> JawsNode::Create(DependencyContainer const& dependencyContainer)
{
	auto spNode = std::make_shared<JawsNode>();

	auto pidPublishers = CreateAllPidPublishers(dependencyContainer, *spNode);
	auto writeServices = CreateAllPidWriteServices(dependencyContainer, *spNode);

	spNode->SetDependencies(std::move(pidPublishers), std::move(writeServices));

	return spNode;
}

JawsNode::JawsNode()
	: rclcpp::Node{n_pNodeName}
{
}
void JawsNode::SetDependencies(
	std::vector<std::unique_ptr<Ros2PidParameterDataPublisher>>&& pidPublishers,
	std::vector<std::unique_ptr<Ros2PidParameterWriteService>>&& writeServices)
{
	m_pidPublishers = std::move(pidPublishers);
	m_writeServices = std::move(writeServices);

	LOG_INFO_HIGH_TAG(Log::Init | Log::Parameter, "Publishing " << m_pidPublishers.size() << " PID parameter(s).");
	LOG_INFO_HIGH_TAG(Log::Init | Log::Parameter, "Providing " << m_writeServices.size() << " PID write service(s).");
}
}
}