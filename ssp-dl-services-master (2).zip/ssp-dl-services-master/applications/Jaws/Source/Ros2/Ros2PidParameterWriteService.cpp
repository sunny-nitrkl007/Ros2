/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Ros2PidParameterWriteService.h

#include "Ros2PidParameterWriteService.h"
#include "Log.h"
#include "ParameterMessageFactory.h"
#include "Shark/IWriteSharkByteRetriever.h"
#include "Utilities/HexStringConverter.h"

using Parameter = data_link_engine_interfaces::msg::Parameter;
using ParameterValue = data_link_engine_interfaces::msg::ParameterValue;
using ParameterServiceResult = data_link_engine_interfaces::msg::ParameterServiceResult;

namespace Jaws::Ros2
{
namespace
{
template <typename T>
class ResponseSender final : public IResponseSender<T>
{
public:
	explicit ResponseSender(std::shared_ptr<rclcpp::Service<T>>&& spService)
		: m_spService{std::move(spService)}
	{
	}
// IResponseSender
	std::string ServiceName() const override
	{
		assert(m_spService);
		return m_spService->get_service_name();
	}
	void SendResponse(
		std::shared_ptr<rmw_request_id_t> const& spRequestHeader,
		std::shared_ptr<typename T::Response> const& spResponse) override
	{
		assert(spRequestHeader);
		assert(spResponse);
		m_spService->send_response(*spRequestHeader, *spResponse);
	}
private:
	std::shared_ptr<rclcpp::Service<T>> const m_spService;
};

std::shared_ptr<Ros2PidParameterWriteService::WriteParameter::Response> MakeFailureResponse(
	uint8_t reason)
{
	auto spResponse = std::make_shared<Ros2PidParameterWriteService::WriteParameter::Response>();
	spResponse->result.status = ParameterServiceResult::STATUS_FAILURE;
	spResponse->result.reason = reason;
	spResponse->result.parameter.quality = Parameter::QUALITY_BAD;
	return spResponse;
}
Identifiers::FixedLengthPidValue ExtractFixedLengthValue(ParameterValue const& value)
{
	Identifiers::FixedLengthPidValue fixedLengthValue{};
	switch (value.type)
	{
		case ParameterValue::TYPE_DOUBLE:
			fixedLengthValue = value.double_value;
			break;
		case ParameterValue::TYPE_UINT64:
			fixedLengthValue = value.uint64_value;
			break;
		case ParameterValue::TYPE_BINARY:
			fixedLengthValue = value.binary_value;
			break;
		default:
			break;
	}

	return fixedLengthValue;
}
}

std::unique_ptr<Ros2PidParameterWriteService> Ros2PidParameterWriteService::Create(
	rclcpp::Node& node,
	std::string const& sharkByteId,
	Identifiers::PidDefinition const& pidDefinition,
	Identifiers::IPidValueEncoder const& pidValueEncoder,
	Identifiers::IPidValueDecoder const& pidValueDecoder)
{
	auto spWriteService = std::make_unique<Ros2PidParameterWriteService>(
		node,
		sharkByteId,
		pidDefinition,
		pidValueEncoder,
		pidValueDecoder);

	auto spRosService = node.create_service<WriteParameter>(
		sharkByteId,
		[pWriteService = spWriteService.get()](
			std::shared_ptr<rmw_request_id_t> spRequestHeader,
			std::shared_ptr<WriteParameter::Request> spRequest)
		{
			pWriteService->Write(spRequestHeader, *spRequest);
		});
	auto spResponseSender = std::make_unique<ResponseSender<WriteParameter>>(std::move(spRosService));
	spWriteService->SetDependency(std::move(spResponseSender));

	return spWriteService;
}

Ros2PidParameterWriteService::Ros2PidParameterWriteService(
	rclcpp::Node& node,
	std::string const& sharkByteId,
	Identifiers::PidDefinition const& pidDefinition,
	Identifiers::IPidValueEncoder const& pidValueEncoder,
	Identifiers::IPidValueDecoder const& pidValueDecoder)
	: m_node{node}
	, m_sharkByteId{sharkByteId}
	, m_pidDefinition{pidDefinition}
	, m_pidValueEncoder{pidValueEncoder}
	, m_pidValueDecoder{pidValueDecoder}
{
}
void Ros2PidParameterWriteService::SetDependency(std::unique_ptr<IResponseSender<WriteParameter>> spResponseSender)
{
	assert(!m_spResponseSender);
	assert(spResponseSender);
	m_spResponseSender = std::move(spResponseSender);
	LOG_INFO_HIGH_TAG(Log::Write,
		"Created write service for " << m_pidDefinition.Pid() << " named '" << m_spResponseSender->ServiceName() << "'.");
}
void Ros2PidParameterWriteService::Initialize(Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever)
{
	assert(!m_spWriteSharkByte);
	m_spWriteSharkByte = &writeSharkByteRetriever.Retrieve(m_sharkByteId);
}
void Ros2PidParameterWriteService::Write(
	std::shared_ptr<rmw_request_id_t> const& spRequestHeader,
	WriteParameter::Request const& request)
{
	assert(spRequestHeader);
	assert(m_spWriteSharkByte);

	if (m_spActiveRequestHeader)
	{
		LOG_WARNING_TAG(Log::Write, m_sharkByteId << ": Write received while another write is active.");
		m_spResponseSender->SendResponse(
			spRequestHeader,
			MakeFailureResponse(ParameterServiceResult::REASON_BUSY));
		return;
	}

	auto const fixedLengthValue = ExtractFixedLengthValue(request.value);
	auto const encoded = m_pidValueEncoder.Encode(m_pidDefinition, fixedLengthValue);
	if (!encoded)
	{
		LOG_WARNING_TAG(Log::Write, m_sharkByteId << ": Failed to encode write request value.");
		m_spResponseSender->SendResponse(
			spRequestHeader,
			MakeFailureResponse(ParameterServiceResult::REASON_PROTOCOL_ERROR));
		return;
	}

	m_spActiveRequestHeader = spRequestHeader;

	LOG_DEBUG_TAG(Log::Write, m_sharkByteId << ": Write(writer="
		<< Utilities::HexStringConverter{}.ToString(m_spActiveRequestHeader->writer_guid, sizeof(m_spActiveRequestHeader->writer_guid))
		<< " sequence=" << m_spActiveRequestHeader->sequence_number << "): "
		<< Utilities::HexStringConverter{}.ToString(encoded->data(), static_cast<unsigned>(encoded->size())));
	m_spWriteSharkByte->Write(*encoded,
		[this](Shark::SharkByteValue const& value)
		{
			OnWriteCompleted(value);
		});
}
void Ros2PidParameterWriteService::OnWriteCompleted(Shark::SharkByteValue const& value)
{
	LOG_DEBUG_TAG(Log::Write, m_sharkByteId << ": OnWriteCompleted(writer="
		<< Utilities::HexStringConverter{}.ToString(m_spActiveRequestHeader->writer_guid, sizeof(m_spActiveRequestHeader->writer_guid))
		<< " sequence=" << m_spActiveRequestHeader->sequence_number << ")");

	auto const decodedValue = m_pidValueDecoder.Decode(m_pidDefinition, value);

	auto spResponse = std::make_shared<WriteParameter::Response>();
	spResponse->result.parameter = MakeParameterMessage(decodedValue, static_cast<uint32_t>(m_pidDefinition.Units()));
	spResponse->result.parameter.header.stamp = m_node.now();
	spResponse->result.status = (decodedValue.quality == Identifiers::DecodedPidQuality::Good)
		? ParameterServiceResult::STATUS_SUCCESS
		: ParameterServiceResult::STATUS_FAILURE;

	auto spRequestHeader = std::exchange(m_spActiveRequestHeader, nullptr);
	m_spResponseSender->SendResponse(spRequestHeader, spResponse);
}
}
