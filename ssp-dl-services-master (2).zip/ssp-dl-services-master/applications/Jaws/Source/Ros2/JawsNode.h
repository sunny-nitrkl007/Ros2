/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// ROS2 node that publishes the configured PGB and ADT PID values, one ROS2 topic
/// per PID.

#pragma once

#include "DependencyContainer.h"
#include "Ros2/Ros2PidParameterDataPublisher.h"
#include "Ros2/Ros2PidParameterWriteService.h"
#include <rclcpp/rclcpp.hpp>
#include <memory>
#include <vector>

namespace Shark { class ISharkByteRetriever; }

namespace Jaws
{
namespace Ros2
{
class JawsNode final : public rclcpp::Node
{
public:
	static std::shared_ptr<JawsNode> Create(DependencyContainer const& dependencyContainer);

	JawsNode();
	void SetDependencies(
		std::vector<std::unique_ptr<Ros2PidParameterDataPublisher>>&& pidPublishers,
		std::vector<std::unique_ptr<Ros2PidParameterWriteService>>&& writeServices);
private:
	std::vector<std::unique_ptr<Ros2PidParameterDataPublisher>> m_pidPublishers{};
	std::vector<std::unique_ptr<Ros2PidParameterWriteService>> m_writeServices{};
};
}
}
