/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Ros2PidParameterDataPublisher.h

#include "Ros2PidParameterDataPublisher.h"
#include "Log.h"
#include "ParameterMessageFactory.h"
#include "Shark/ISharkByteRetriever.h"
#include <cctype>

namespace Jaws
{
namespace Ros2
{
namespace
{
// ROS2 topic names may only contain alphanumerics and underscores between the
// '/' separators, and a token may not begin with a digit. Middleware identifiers
// use '.' as a separator and may begin with a digit, so replace any character
// that is not a valid token character with an underscore and prefix an underscore
// when the result would otherwise begin with a digit.
//
// NOTE: This is only needed temporarily until we have a ROS2 JawsSubscriber that
//       provides ROS2-compatible identifiers.
std::string SanitizeForTopic(std::string const& sharkByteId)
{
	// Don't use std::isalnum here because it is locale-dependent and ROS2 naming rules
	// specifically require ascii characters.
	constexpr auto isLetter = [](char character) {
		return (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z');
	};

	std::string sanitized = sharkByteId;
	for (auto& character : sanitized)
	{
		bool const isValid = isLetter(character)
			|| std::isdigit(character) != 0
			|| character == '_';
		if (!isValid)
		{
			character = '_';
		}
	}

	// Ensure the first character is a letter to avoid hidden topics (_ prefix) and ROS2's
	// requirement that tokens not begin with digits
	if (!sanitized.empty())
	{
		char const firstChar = sanitized.front();
		if (!isLetter(firstChar))
		{
			sanitized.insert(sanitized.begin(), 'p'); // arbitrary letter prefix
		}
	}

	return sanitized;
}
std::string TopicName(std::string const& sharkByteId)
{
	return "/data_link_engine/" + SanitizeForTopic(sharkByteId);
}

constexpr auto n_historyDepth = 1;

/// Create a ROS2 publisher with Quality of Service (QoS) settings. QoS defines how
/// messages are delivered in a distributed system (DDS/ROS2). Key settings:
///
/// HISTORY POLICY (KEEP_LAST with depth=1):
///   Stores only the most recent message in a buffer on the publisher side.
///   This ensures new subscribers connecting after publication has started will only
///   receive the latest message available at that moment. No older messages are buffered.
///   After receiving the single most recent message, the subscriber receives only new
///   messages as they are published. This prevents stale data from reaching late-joining
///   subscribers.
///
/// RELIABILITY (RELIABLE):
///   The publisher guarantees that every message will reach every subscriber, retrying
///   as needed. Without this (BEST_EFFORT mode), messages might be silently dropped if
///   the network is congested. Since these are control parameters, reliable delivery is
///   critical.
///
/// DURABILITY (VOLATILE - default):
///   Messages are only held while the publisher is active. If the publisher crashes,
///   buffered messages are discarded. The alternative (TRANSIENT_LOCAL) would persist
///   messages to disk, but that's overkill for real-time parameter streaming.
///
/// LIVELINESS (AUTOMATIC - default):
///   ROS2 automatically detects when publishers are alive by monitoring heartbeats.
///   Subscribers know a publisher is "dead" if no heartbeat arrives after a timeout.
rclcpp::Publisher<data_link_engine_interfaces::msg::Parameter>::SharedPtr CreatePublisher(
	std::string const& sharkByteId,
	rclcpp::Node& node)
{
	return node.create_publisher<data_link_engine_interfaces::msg::Parameter>(
		TopicName(sharkByteId),
		rclcpp::QoS{n_historyDepth});
}
}

std::unique_ptr<Ros2PidParameterDataPublisher> Ros2PidParameterDataPublisher::Create(
	rclcpp::Node& node,
	std::string const& sharkByteId,
	Identifiers::PidDefinition const& pidDefinition,
	Identifiers::IPidValueDecoder const& pidValueDecoder)
{
	return std::make_unique<Ros2PidParameterDataPublisher>(
		node,
		CreatePublisher(sharkByteId, node),
		sharkByteId,
		pidDefinition,
		pidValueDecoder);
}
Ros2PidParameterDataPublisher::Ros2PidParameterDataPublisher(
	rclcpp::Node& node,
	rclcpp::Publisher<data_link_engine_interfaces::msg::Parameter>::SharedPtr&& spPublisher,
	std::string const& sharkByteId,
	Identifiers::PidDefinition const& pidDefinition,
	Identifiers::IPidValueDecoder const& pidValueDecoder)
	: m_node{node}
	, m_sharkByteId{sharkByteId}
	, m_pidDefinition{pidDefinition}
	, m_pidValueDecoder{pidValueDecoder}
	, m_spPublisher{std::move(spPublisher)}
{
	LOG_INFO_HIGH_TAG(Log::Parameter,
		"Created publisher for " << m_pidDefinition.Pid() << " on topic '" << m_spPublisher->get_topic_name() << "'.");
}
void Ros2PidParameterDataPublisher::Initialize(Shark::ISharkByteRetriever const& sharkByteRetriever)
{
	assert(!m_subscription.IsConnected());
	auto& sharkByte = sharkByteRetriever.Retrieve(m_sharkByteId);
	LOG_DEBUG_TAG(Log::Parameter, "Subscribing to SharkByte '" << m_sharkByteId << "'.");
	m_subscription = sharkByte.SubscribeToValues(
		[this](Shark::SharkByteValue const& value)
		{
			Publish(value);
		});
}
void Ros2PidParameterDataPublisher::Publish(Shark::SharkByteValue const& value)
{
	auto const decodedValue = m_pidValueDecoder.Decode(m_pidDefinition, value);
	LOG_DEBUG_TAG(Log::Parameter, "Publishing value for '" << m_spPublisher->get_topic_name() << "': " << decodedValue);
	auto message = MakeParameterMessage(decodedValue, static_cast<uint32_t>(m_pidDefinition.Units()));
	message.header.stamp = m_node.now();
	m_spPublisher->publish(message);
}
}
}
