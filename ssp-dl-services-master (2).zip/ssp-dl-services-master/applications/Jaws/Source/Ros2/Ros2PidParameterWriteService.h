/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Handles asynchronous ROS2 WriteParameter requests for a single PID-backed SharkByte.

#pragma once

#include "Identifiers/IPidValueDecoder.h"
#include "Identifiers/IPidValueEncoder.h"
#include "Identifiers/PidDefinition.h"
#include "Utilities/nice_ptr.h"
#include "data_link_engine_interfaces/srv/write_parameter.hpp"
#include <Shark/IWriteSharkByte.h>
#include <memory>
#include <rclcpp/rclcpp.hpp>
#include <string>

namespace Shark
{
class IWriteSharkByteRetriever;
}

namespace Jaws::Ros2
{
/// Generic interface for sending typed ROS2 service responses asynchronously. Facilitates unit testing.
template <typename T>
class IResponseSender
{
public:
	virtual ~IResponseSender() = default;

	virtual std::string ServiceName() const = 0;
	virtual void SendResponse(
		std::shared_ptr<rmw_request_id_t> const& spRequestHeader,
		std::shared_ptr<typename T::Response> const& spResponse) = 0;
};

/// Handles asynchronous ROS2 WriteParameter service requests for a single PID-backed SharkByte,
/// encoding/decoding parameter values and managing responses.
class Ros2PidParameterWriteService
{
public:
	using WriteParameter = data_link_engine_interfaces::srv::WriteParameter;

	static std::unique_ptr<Ros2PidParameterWriteService> Create(
		rclcpp::Node& node,
		std::string const& sharkByteId,
		Identifiers::PidDefinition const& pidDefinition,
		Identifiers::IPidValueEncoder const& pidValueEncoder,
		Identifiers::IPidValueDecoder const& pidValueDecoder);

	Ros2PidParameterWriteService(
		rclcpp::Node& node,
		std::string const& sharkByteId,
		Identifiers::PidDefinition const& pidDefinition,
		Identifiers::IPidValueEncoder const& pidValueEncoder,
		Identifiers::IPidValueDecoder const& pidValueDecoder);
	void SetDependency(std::unique_ptr<IResponseSender<WriteParameter>> spResponseSender);
	void Initialize(Shark::IWriteSharkByteRetriever const& writeSharkByteRetriever);

	/// Asynchronously handles a PID basic write request by encoding the value and writing it to the SharkByte.
	void Write(
		std::shared_ptr<rmw_request_id_t> const& spRequestHeader,
		WriteParameter::Request const& request);
private:
	void OnWriteCompleted(Shark::SharkByteValue const& value);

	rclcpp::Node& m_node;
	std::string const m_sharkByteId;
	Identifiers::PidDefinition const m_pidDefinition;
	Identifiers::IPidValueEncoder const& m_pidValueEncoder;
	Identifiers::IPidValueDecoder const& m_pidValueDecoder;
	std::unique_ptr<IResponseSender<WriteParameter>> m_spResponseSender{};
	Utilities::nice_ptr<Shark::IWriteSharkByte> m_spWriteSharkByte{};
	std::shared_ptr<rmw_request_id_t> m_spActiveRequestHeader{};
};
}