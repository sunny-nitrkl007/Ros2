/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Subscribes to a PID SharkByte and republishes its decoded value on a ROS2 topic.

#pragma once

#include "Identifiers/IPidValueDecoder.h"
#include "Identifiers/PidDefinition.h"
#include "data_link_engine_interfaces/msg/parameter.hpp"
#include <Shark/ISharkByte.h>
#include <rclcpp/rclcpp.hpp>
#include <string>

namespace Shark { class ISharkByteRetriever; }

namespace Jaws
{
namespace Ros2
{
class Ros2PidParameterDataPublisher
{
public:
	static std::unique_ptr<Ros2PidParameterDataPublisher> Create(
		rclcpp::Node& node,
		std::string const& sharkByteId,
		Identifiers::PidDefinition const& pidDefinition,
		Identifiers::IPidValueDecoder const& pidValueDecoder);

	Ros2PidParameterDataPublisher(
		rclcpp::Node& node,
		rclcpp::Publisher<data_link_engine_interfaces::msg::Parameter>::SharedPtr&& spPublisher,
		std::string const& sharkByteId,
		Identifiers::PidDefinition const& pidDefinition,
		Identifiers::IPidValueDecoder const& pidValueDecoder);

	void Initialize(Shark::ISharkByteRetriever const& sharkByteRetriever);
private:
	void Publish(Shark::SharkByteValue const& value);

	rclcpp::Node& m_node;
	std::string const m_sharkByteId;
	Identifiers::PidDefinition const m_pidDefinition;
	Identifiers::IPidValueDecoder const& m_pidValueDecoder;
	rclcpp::Publisher<data_link_engine_interfaces::msg::Parameter>::SharedPtr const m_spPublisher;
	Shark::SharkByteSubscription m_subscription{};
};
}
}
