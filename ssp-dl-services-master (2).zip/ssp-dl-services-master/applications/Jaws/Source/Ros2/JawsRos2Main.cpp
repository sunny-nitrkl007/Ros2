/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// ROS2 Jaws entry point. Loads the Shark configuration from NVM, brings up Shark
/// and publishes the configured PGB/ADT PID values on ROS2 topics.

#include "ConfigLoader.h"
#include "DependencyContainer.h"
#include "EnvironmentFactory.h"
#include "Identifiers/PidDefinitionRetriever.h"
#include "Identifiers/PidValueDecoder.h"
#include "Identifiers/PidValueEncoder.h"
#include "Nvm/NvmWrapper.h"
#include "Ros2/JawsNode.h"
#include "Shark/Shark.h"
#include "Utilities/Filesystem.h"
#include <memory>
#include <rclcpp/rclcpp.hpp>

int main(int argc, char* argv[])
{
	rclcpp::init(argc, argv);

	Utilities::Filesystem filesystem{};
	auto const spEnvironment = Jaws::EnvironmentFactory::CreateEnvironment(filesystem);
	auto const spNvmWrapper = Jaws::Nvm::NvmWrapper::Create(*spEnvironment);

	Jaws::ConfigLoader const configLoader{};
	auto spSharkConfig = configLoader.LoadFromNvm(*spNvmWrapper);
	if (spSharkConfig == nullptr)
	{
		// The stored configuration was not valid; continue with a blank configuration.
		spSharkConfig = std::make_unique<cat::shark::Config>();
	}

	auto const spShark = Shark::CreateShark(*spEnvironment, *spSharkConfig);

	Jaws::Identifiers::PidDefinitionRetriever pidDefinitionRetriever{
		spSharkConfig->pid_entries(),
		spSharkConfig->multi_byte_pid_entries()};
	Jaws::Identifiers::PidValueDecoder pidValueDecoder{};
	Jaws::Identifiers::PidValueEncoder pidValueEncoder{};

	auto spDependencyContainer = std::make_unique<Jaws::DependencyContainer>(
		*spSharkConfig,
		*spEnvironment,
		filesystem,
		pidDefinitionRetriever,
		pidValueDecoder,
		pidValueEncoder,
		spShark->GetSharkByteRetriever(),
		spShark->GetWriteSharkByteRetriever(),
		*spNvmWrapper);

	auto const spNode = Jaws::Ros2::JawsNode::Create(*spDependencyContainer);

	rclcpp::spin(spNode);
	rclcpp::shutdown();

	return 0;
}
