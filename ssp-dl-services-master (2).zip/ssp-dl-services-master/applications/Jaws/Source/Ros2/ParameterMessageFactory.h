/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Maps a transport-neutral DecodedPidValue onto a ROS2 Parameter message.

#pragma once

#include "Identifiers/IPidValueDecoder.h"
#include "data_link_engine_interfaces/msg/parameter.hpp"
#include <cstdint>

namespace Jaws
{
namespace Ros2
{
/// Builds a Parameter message from a decoded PID value and its unit. The message
/// timestamp is left unset; the caller is responsible for stamping the message.
data_link_engine_interfaces::msg::Parameter MakeParameterMessage(
	Identifiers::DecodedPidValue const& decodedValue,
	uint32_t unit);
}
}
