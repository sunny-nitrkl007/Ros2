/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See ParameterMessageFactory.h

#include "ParameterMessageFactory.h"
#include "Utilities/OverloadLambdas.h"
#include <utility>

namespace Jaws
{
namespace Ros2
{
namespace
{
using Parameter = data_link_engine_interfaces::msg::Parameter;
using ParameterValue = data_link_engine_interfaces::msg::ParameterValue;

uint8_t MapQuality(Identifiers::DecodedPidQuality quality)
{
	switch (quality)
	{
		case Identifiers::DecodedPidQuality::Good:
			return Parameter::QUALITY_GOOD;
		case Identifiers::DecodedPidQuality::Bad:
			return Parameter::QUALITY_BAD;
		case Identifiers::DecodedPidQuality::NotReceived:
			return Parameter::QUALITY_NOT_RECEIVED;
		default:
			std::unreachable();
	}
};
}

data_link_engine_interfaces::msg::Parameter MakeParameterMessage(
	Identifiers::DecodedPidValue const& decodedValue,
	uint32_t unit)
{
	Parameter message{};

	message.unit = unit;
	message.quality = MapQuality(decodedValue.quality);

	if (decodedValue.quality == Identifiers::DecodedPidQuality::Good)
	{
		std::visit(
			Utilities::OverloadLambdas{
				[&message](std::monostate const&) {
					message.value.type = ParameterValue::TYPE_UNSPECIFIED;
				},
				[&message](double doubleValue) {
					message.value.type = ParameterValue::TYPE_DOUBLE;
					message.value.double_value = doubleValue;
				},
				[&message](uint64_t uintValue) {
					message.value.type = ParameterValue::TYPE_UINT64;
					message.value.uint64_value = uintValue;
				},
				[&message](std::vector<uint8_t> const& binaryValue) {
					message.value.type = ParameterValue::TYPE_BINARY;
					message.value.binary_value = binaryValue;
				}
			},
			decodedValue.value);
	}

	return message;
}
}
}
