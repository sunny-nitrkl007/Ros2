/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Thread-safe gate that queues callbacks until ready.

#pragma once

#include "IInitializationGate.h"
#include <atomic>
#include <functional>
#include <mutex>
#include <vector>

namespace Jaws
{
class InitializationGate final : public IInitializationGate
{
public:
// IInitializationGate
	bool IsReady() const override;
	void SetReady() override;
	void EnqueueOrExecute(std::move_only_function<void(bool)>&& action) const override;
private:
	void PerformPendingActions();

	mutable std::mutex m_mutex{};
	std::atomic<bool> m_ready{};
	mutable std::vector<std::move_only_function<void(bool)>> m_pendingActions{};
};
}
