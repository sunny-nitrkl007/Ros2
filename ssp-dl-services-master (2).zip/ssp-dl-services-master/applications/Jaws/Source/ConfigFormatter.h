/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Formats a protobuf config message as human-readable text.

#pragma once

#include <google/protobuf/message.h>
#include <string>
#include <unordered_set>

namespace Jaws
{

class ConfigFormatter
{
public:
	explicit ConfigFormatter(std::unordered_set<std::string> hexFields);

	std::string Format(google::protobuf::Message const& message) const;

private:
	std::unordered_set<std::string> m_hexFields;
};

}
