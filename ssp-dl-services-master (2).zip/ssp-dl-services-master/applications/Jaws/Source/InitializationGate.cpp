/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See InitializationGate.h

#include "InitializationGate.h"
#include "Log.h"
#include <cassert>

namespace Jaws
{
bool InitializationGate::IsReady() const
{
	return m_ready;
}
void InitializationGate::SetReady()
{
	assert(!IsReady());

	// Drain all pending actions. Ensure that any actions enqueued while draining are also executed before returning.
	while (!IsReady())
	{
		PerformPendingActions();

		{
			std::lock_guard const lock{m_mutex};
			if (m_pendingActions.empty())
			{
				m_ready = true;
			}
		}
	}
}
void InitializationGate::EnqueueOrExecute(std::move_only_function<void(bool)>&& action) const
{
	{
		std::lock_guard const lock{m_mutex};
		if (!IsReady())
		{
			LOG_DEBUG_TAG(Log::Init, "InitializationGate: Not ready. Enqueuing callback.");
			m_pendingActions.push_back(std::move(action));
			return;
		}
	}
	action(true);
}
void InitializationGate::PerformPendingActions()
{
	assert(!IsReady());

	std::vector<std::move_only_function<void(bool)>> pending{};
	{
		std::lock_guard const lock{m_mutex};
		std::swap(pending, m_pendingActions);
	}

	LOG_INFO_HIGH_TAG(Log::Init, "InitializationGate: Ready. Executing " << pending.size() << " queued callback(s).");

	for (auto&& action : pending)
	{
		action(false);
	}
}
}
