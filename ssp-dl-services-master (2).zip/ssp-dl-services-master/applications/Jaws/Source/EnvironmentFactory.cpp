/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See EnvironmentFactory.h

#include "EnvironmentFactory.h"
#include <Utilities/IFilesystem.h>
#include <pugixml.hpp>

namespace Jaws
{
namespace
{
constexpr auto n_pApplication = "Jaws";
#ifdef DESKTOP_BUILD
constexpr auto n_pPersistentStoragePath = "/tmp/";
#else
constexpr auto n_pPersistentStoragePath = "/opt/appdata/Jaws/";
#endif
}
class Environment : public Utilities::IEnvironment
{
public:
    Environment() {}
// Utilities::IEnvironment
	std::string const& Application() const override { return m_application; }
	std::string const& PersistentStoragePath() const override { return m_persistentStoragePath; }
private:
	std::string const m_application{n_pApplication};
	std::string const m_persistentStoragePath{n_pPersistentStoragePath};
};

std::unique_ptr<Utilities::IEnvironment> EnvironmentFactory::CreateEnvironment(Utilities::IFilesystem const& filesystem)
{
	auto spEnvironment = std::make_unique<Environment>();

	// Shark needs the NVM path to exist
	filesystem.CreateDirectories(spEnvironment->DeletedOnApplicationChangePersistentStorageDirectory());

	return spEnvironment;
}
}
