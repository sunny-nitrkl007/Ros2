/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// NvmXmlFile Tests

#include "Nvm/NvmXmlFile.cpp"
#include <Utilities/DefaultSmartPointers.h>
#include <Utilities/Mocks/MockIFilesystem.h>
#include <Utilities/NvmXmlUtilities.h>
#include <Utilities/TemporaryFile.h>
#include <Utilities/TestUtilities.h>
#include <Utilities/narrow_cast.h>
#include <fstream>
#include <gmock/gmock.h>
#include <sstream>

using namespace testing;
using Utilities::NvmXmlBuilder;
using Utilities::NvmXmlDefinitions;
using Utilities::TemporaryDirectory;

namespace Jaws
{
namespace Nvm
{
namespace
{
struct Any
{
	static constexpr char const* OtherApplication()
	{
		return "other app";
	}
	static constexpr char const* RenamedApplication()
	{
		return "renamed app";
	}
	static constexpr char const* OtherSchemaVersion()
	{
		return "bad version";
	}
	static constexpr char const* NodeName()
	{
		return "ANode";
	}
};

class MockISafeNvmFileSaver : public ISafeNvmFileSaver
{
	EnsureMockKindIsSpecified(MockISafeNvmFileSaver);

public:
	MOCK_CONST_METHOD2(
		CreateTemporaryNvmFile,
		void(std::string const& temporaryNvmFilePath, std::string const& nvmContents));
	MOCK_CONST_METHOD1(RemoveCrcFile, void(std::string const& crcFilePath));
	MOCK_CONST_METHOD2(
		ReplaceNvmFileWithTheTemporaryNvmFile,
		void(std::string const& newNvmFilePath, std::string const& nvmFilePath));
	MOCK_CONST_METHOD2(CreateNewCrcFile, void(std::string const& crcFilePath, std::string const& crc));
};
}

class NvmXmlFileTest : public Test
{
protected:
	struct Default
	{
		static constexpr char const* FilePath()
		{
			return "/tmp/file/that/does/not/exist";
		}
		static constexpr char const* TemporaryFilePath()
		{
			return "/tmp/file/that/does/not/exist.new";
		}
		static constexpr char const* Application()
		{
			return NvmXmlBuilder::Default::Application();
		}
		static constexpr unsigned Crc()
		{
			return 0x12345678;
		}
	};

	void Save()
	{
		m_nvmXmlFile.Save();
	}

	std::string const m_nvmCrcFilePath{NvmXmlDefinitions::MakeCrcFilePath(Default::FilePath())}; // cppcheck-suppress unusedStructMember
	Utilities::DefaultTestUniquePtr<NiceMock<Utilities::Mocks::MockIFilesystem>> m_spMockFilesystem{};
	Utilities::DefaultTestUniquePtr<NiceMock<MockISafeNvmFileSaver>> m_spMockSafeNvmFileSaver{};

	NvmXmlFile m_nvmXmlFile{
		Default::FilePath(),
		Default::TemporaryFilePath(),
		m_spMockFilesystem.TakeUniquePtr(),
		m_spMockSafeNvmFileSaver.TakeUniquePtr(),
		Default::Application()};
};
TEST_F(NvmXmlFileTest, Save_CreatesTheTemporaryNvmFileWithTheCurrentXml)
{
	auto const expectedFileContents = NvmXmlBuilder().Xml();
	EXPECT_CALL(*m_spMockSafeNvmFileSaver, CreateTemporaryNvmFile(Default::TemporaryFilePath(), expectedFileContents));
	Save();
}
TEST_F(NvmXmlFileTest, Save_RemovesTheCrcFile)
{
	EXPECT_CALL(*m_spMockSafeNvmFileSaver, RemoveCrcFile(m_nvmCrcFilePath));
	Save();
}
TEST_F(NvmXmlFileTest, Save_ReplacesTheNvmFileWithTheTemporaryNvmFile)
{
	EXPECT_CALL(
		*m_spMockSafeNvmFileSaver,
		ReplaceNvmFileWithTheTemporaryNvmFile(Default::TemporaryFilePath(), Default::FilePath()));
	Save();
}
TEST_F(NvmXmlFileTest, Save_CreatesTheNewCrcFile)
{
	EXPECT_CALL(*m_spMockSafeNvmFileSaver, CreateNewCrcFile(m_nvmCrcFilePath, _));
	Save();
}
TEST_F(NvmXmlFileTest, Save_PerformsTheCallsInTheCorrectOrder)
{
	InSequence inSequence{};
	EXPECT_CALL(*m_spMockSafeNvmFileSaver, CreateTemporaryNvmFile(_, _));
	EXPECT_CALL(*m_spMockSafeNvmFileSaver, RemoveCrcFile(_));
	EXPECT_CALL(*m_spMockSafeNvmFileSaver, ReplaceNvmFileWithTheTemporaryNvmFile(_, _));
	EXPECT_CALL(*m_spMockSafeNvmFileSaver, CreateNewCrcFile(_, _));

	Save();
}

/// Relies on NVM being written to and read from the real filesystem.
/// Since SafeNvmFileSaver is being tested indirectly through this integration test, there
/// are no separate SafeNvmFileSaverTests.
class NvmXmlFile_IntegrationTest : public Test
{
protected:
	struct Default
	{
		static constexpr char const* Application()
		{
			return NvmXmlBuilder::Default::Application();
		}
		static constexpr unsigned Crc()
		{
			return 0x12345678;
		}
	};

	NvmXmlFile_IntegrationTest()
		: m_nvmTemporaryDirectory(TemporaryDirectory::Create("Jaws_Tests"))
		, m_nvmFilePath{m_nvmTemporaryDirectory.Path() + "NvmFile.xml"}
		, m_temporaryNvmFilePath{m_nvmFilePath + NvmXmlFile::TemporaryFileExtension()}
		, m_nvmCrcFilePath{NvmXmlDefinitions::MakeCrcFilePath(m_nvmFilePath)}
	{
	}
	void CreateNvmXmlFile()
	{
		auto& filesystem = *m_spFilesystem;
		m_spNvmXmlFile	 = std::make_unique<NvmXmlFile>(
			  m_nvmFilePath,
			  m_temporaryNvmFilePath,
			  // Takes the real things because these tests expect the real XML to be created
			  std::move(m_spFilesystem),
			  std::make_unique<SafeNvmFileSaver>(filesystem),
			  m_application);
	}
	std::string Read()
	{
		std::ifstream stream(m_nvmFilePath);
		return {std::istreambuf_iterator<char>{stream}, {}};
	}
	void Write(std::string const& xml)
	{
		std::ofstream stream(m_nvmFilePath);
		stream << xml;
	}
	std::string ReadCrc()
	{
		std::string crc{};
		std::ifstream crcFile{m_nvmCrcFilePath, std::ios::binary};

		crcFile >> crc;
		return crc;
	}
	void WriteCrcBytes(unsigned byteCount)
	{
		std::vector<char> const bytes(byteCount, 0);
		std::ofstream crcFile{m_nvmCrcFilePath, std::ios::binary};
		crcFile.write(bytes.data(), Utilities::narrow_cast<int>(bytes.size()));
		assert(crcFile);
	}
	void WriteCrc(unsigned crc)
	{
		std::ofstream crcFile{m_nvmCrcFilePath, std::ios::binary};
		crcFile.write(reinterpret_cast<char const*>(&crc), sizeof(crc));
		assert(crcFile);
	}
	void WriteCrc(std::string const& crc)
	{
		std::ofstream crcFile{m_nvmCrcFilePath, std::ios::binary};
		crcFile << crc;
		assert(crcFile);
	}
	void ExpectThatTheXmlTreeIsTheDefaultXmlTree()
	{
		auto const node = m_spNvmXmlFile->NvmNode();
		EXPECT_THAT(node.name(), StrEq(NvmXmlDefinitions::NvmNodeName()));
		EXPECT_THAT(GetSchemaVersionValue(node), StrEq(NvmXmlDefinitions::SchemaVersion()));
		EXPECT_THAT(GetApplicationAttributeValue(node), StrEq(Default::Application()));
		EXPECT_THAT(node.begin(), Eq(node.end()));
	}
	// Returns the XML that *should have* been written
	std::string SaveNonDefaultXmlTree()
	{
		auto node = m_spNvmXmlFile->NvmNode();
		node.append_child(Any::NodeName());

		pugi::xml_document otherDocument{};
		otherDocument.append_copy(node);

		m_spNvmXmlFile->Save();

		std::stringstream stream{};
		otherDocument.save(stream, NvmXmlDefinitions::Indent(), NvmXmlDefinitions::SaveFlags());
		return stream.str();
	}

	static char const* GetApplicationAttributeValue(pugi::xml_node nvmNode)
	{
		return nvmNode.attribute(NvmXmlDefinitions::ApplicationAttributeName()).value();
	}
	static char const* GetSchemaVersionValue(pugi::xml_node nvmNode)
	{
		return nvmNode.attribute(NvmXmlDefinitions::SchemaVersionAttributeName()).value();
	}

	TemporaryDirectory const m_nvmTemporaryDirectory;
	std::string m_nvmFilePath;
	std::string const m_temporaryNvmFilePath;
	std::string const m_nvmCrcFilePath;
	std::string m_application{Default::Application()};
	Utilities::default_unique_ptr<Utilities::Filesystem> m_spFilesystem{};

	std::unique_ptr<NvmXmlFile> m_spNvmXmlFile{};
};
TEST_F(NvmXmlFile_IntegrationTest, TheTemporaryExtensionIsCorrect)
{
	static_assert(NvmXmlFile::TemporaryFileExtension() == std::string_view{".new"});
}
TEST_F(NvmXmlFile_IntegrationTest, Constructor_SavesTheDefaultXmlTreeIfTheFileIsInvalidOrDoesNotExist)
{
	// We simply validate the non-existence case here... The parameterized tests cover invalid files.
	CreateNvmXmlFile();

	auto const expected = NvmXmlBuilder().Xml();
	EXPECT_THAT(Read(), Eq(expected));
}
TEST_F(NvmXmlFile_IntegrationTest, NvmNode_ReturnsTheDefaultXmlTreeIfTheCrcFileExistsButTheCrcDoesNotMatch)
{
	auto const xml = NvmXmlBuilder().WithNode(Any::NodeName()).Xml();
	Write(xml);
	WriteCrc(Default::Crc() + 1);

	CreateNvmXmlFile();
	ExpectThatTheXmlTreeIsTheDefaultXmlTree();
}
TEST_F(NvmXmlFile_IntegrationTest, NvmNode_ReturnsTheDefaultXmlTreeIfThereIsNoSourceFile)
{
	CreateNvmXmlFile();
	ExpectThatTheXmlTreeIsTheDefaultXmlTree();
}
TEST_F(NvmXmlFile_IntegrationTest, NvmNode_ReturnsTheDefaultXmlTreeIfThereIsAValidSourceFileButTheApplicationHasChanged)
{
	auto const xml = NvmXmlBuilder(Any::OtherApplication()).Xml();
	Write(xml);
	CreateNvmXmlFile();
	ExpectThatTheXmlTreeIsTheDefaultXmlTree();
}
TEST_F(
	NvmXmlFile_IntegrationTest,
	NvmNode_ReturnsTheDefaultXmlTreeIfThereIsAValidSourceFileButTheSchemaVersionIsMissing)
{
	auto const xml = NvmXmlBuilder().WithoutSchemaVersion().Xml();
	Write(xml);
	CreateNvmXmlFile();
	ExpectThatTheXmlTreeIsTheDefaultXmlTree();
}
TEST_F(
	NvmXmlFile_IntegrationTest,
	NvmNode_ReturnsTheDefaultXmlTreeIfThereIsAValidSourceFileButTheSchemaVersionIsIncorrect)
{
	auto const xml = NvmXmlBuilder().WithSchemaVersion(Any::OtherSchemaVersion()).Xml();
	Write(xml);
	CreateNvmXmlFile();
	ExpectThatTheXmlTreeIsTheDefaultXmlTree();
}
TEST_F(
	NvmXmlFile_IntegrationTest,
	NvmNode_ReturnsTheParsedXmlTreeIfThereIsAValidSourceFileWithMatchingApplicationAndThereIsNoCrcFile)
{
	auto const xml = NvmXmlBuilder(Any::OtherApplication()).WithNode(Any::NodeName()).Xml();
	Write(xml);
	m_application = Any::OtherApplication();
	CreateNvmXmlFile();
	auto const node = m_spNvmXmlFile->NvmNode();
	EXPECT_THAT(GetApplicationAttributeValue(node), StrEq(Any::OtherApplication()));
	EXPECT_THAT(node.first_child().name(), StrEq(Any::NodeName()));
}
TEST_F(
	NvmXmlFile_IntegrationTest,
	NvmNode_ReturnsTheParsedXmlTreeIfThereIsAValidSourceFileWithMatchingApplicationAndTheCrcMatches)
{
	auto const xml = NvmXmlBuilder(Any::OtherApplication()).WithNode(Any::NodeName()).Xml();
	Write(xml);

	auto const expectedCrc = To<std::string>(crc32c::Crc32c(std::string_view{xml.data()}));
	WriteCrc(expectedCrc);

	m_application = Any::OtherApplication();
	CreateNvmXmlFile();
	auto const node = m_spNvmXmlFile->NvmNode();
	EXPECT_THAT(GetApplicationAttributeValue(node), StrEq(Any::OtherApplication()));
	EXPECT_THAT(node.first_child().name(), StrEq(Any::NodeName()));
}
TEST_F(NvmXmlFile_IntegrationTest, Save_WritesTheCurrentXmlTreeToTheFile)
{
	CreateNvmXmlFile();
	auto const expected = SaveNonDefaultXmlTree();
	EXPECT_THAT(Read(), Eq(expected));
}
TEST_F(NvmXmlFile_IntegrationTest, Save_WritesTheCrcOfTheCurrentXmlTreeToTheCrcFile)
{
	CreateNvmXmlFile();
	auto const actualXml = SaveNonDefaultXmlTree();

	Utilities::Filesystem filesystem{};
	ASSERT_TRUE(filesystem.Exists(m_nvmCrcFilePath));

	auto const expectedCrc = To<std::string>(crc32c::Crc32c(actualXml));
	auto const actualCrc   = ReadCrc();
	EXPECT_THAT(actualCrc, Eq(expectedCrc));
}

namespace
{
constexpr char const* n_pInvalidXml[]{
	"",
	"<>",
	"</>",
	"<Bar/>",
	R"(<Nvm SchemaVersion="1" Application="app">)",
	R"(<Nvm SchemaVersion="1" Application="app"><UnitSystem Value="0>"</Nvm>)",	 // Missing quote in attribute
	R"(<Nvm SchemaVersion="1" Application="app"/><Bar/>)",						 // Extra node
};
constexpr auto n_pInvalidXmlAppName = "app";
}  // namespace
class NvmXmlFile_InvalidSourceFileContentsTest : public NvmXmlFile_IntegrationTest,
												 public WithParamInterface<char const*>
{
};
INSTANTIATE_TEST_SUITE_P(Param, NvmXmlFile_InvalidSourceFileContentsTest, ValuesIn(n_pInvalidXml));
TEST_P(NvmXmlFile_InvalidSourceFileContentsTest, NvmNode_ReturnsTheDefaultXmlTreeIfTheSourceFileContentsAreInvalid)
{
	char const* const pXml = GetParam();
	Write(pXml);
	m_application = n_pInvalidXmlAppName;
	CreateNvmXmlFile();
	ExpectThatTheXmlTreeIsTheDefaultXmlTree();
}
}
}
