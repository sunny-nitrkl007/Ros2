/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock INvmWrapper

#pragma once

#include "Nvm/INvmWrapper.h"
#include <Utilities/DestructorTester.h>
#include <gmock/gmock.h>

namespace Jaws
{
namespace Nvm
{
class MockINvmWrapper : public INvmWrapper, public Utilities::DestructorTesterManager
{
public:
	MOCK_METHOD(std::string, Read, (std::string const&, std::string const&), (override));
	MOCK_METHOD(void, Write, (std::string const&, std::string const&), (override));
};
}
}
