/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Nvm Wrapper Tests

#include "Nvm/NvmWrapper.cpp"
#include <Utilities/NvmXmlUtilities.h>
#include <Utilities/TestUtilities.h>
#include <gmock/gmock.h>
#include <pugixml.hpp>

using namespace testing;

namespace Jaws
{
namespace Nvm
{
namespace
{
class MockINvmXmlFile : public INvmXmlFile
{
public:
	MOCK_CONST_METHOD0(NvmNode, pugi::xml_node());
	MOCK_CONST_METHOD0(Save, void());
};

struct Any
{
	static constexpr char const* NewValueName()
	{
		return "NotThereYet";
	}
	static constexpr char const* NewValue()
	{
		return "newvalue";
	}
};
}  // namespace

class NvmWrapperTest : public Test
{
protected:
	struct Default
	{
		static constexpr char const* ValueName()
		{
			return "Test";
		}
		static constexpr char const* InitialValue()
		{
			return "initial";
		}
		static constexpr char const* DefaultValue()
		{
			return "default";
		}
	};

	NvmWrapperTest() : m_spWrapper(std::make_unique<NvmWrapper>(m_spMockNvmXmlFile.TakeUniquePtr()))
	{
		m_document.append_child("dummy");
		ON_CALL(*m_spMockNvmXmlFile, NvmNode()).WillByDefault(Invoke([this] { return m_document.first_child(); }));

		auto const xml = Utilities::NvmXmlBuilder{}.WithValue(Default::ValueName(), Default::InitialValue()).Xml();
		m_document.load_string(xml.c_str());
	}
	void WriteAnyNvmValue()
	{
		m_spWrapper->Write("Foo", "Bar");
	}
	std::string GetActualValue(std::string const& attributeName)
	{
		Utilities::NvmXmlParser const parser{m_document};
		return parser.GetValue(attributeName);
	}

	pugi::xml_document m_document{};
	Utilities::DefaultTestUniquePtr<NiceMock<MockINvmXmlFile>> m_spMockNvmXmlFile{};

	std::unique_ptr<NvmWrapper> m_spWrapper;
};
TEST_F(NvmWrapperTest, Read_RetrievesValueWhenItExists)
{
	auto const readValue = m_spWrapper->Read(Default::ValueName(), Default::DefaultValue());
	EXPECT_THAT(readValue, Eq(Default::InitialValue()));
}
TEST_F(NvmWrapperTest, Read_RetrievesDefaultValueWhenTheNodeDoesNotExist)
{
	auto const readValue = m_spWrapper->Read(Any::NewValueName(), Default::DefaultValue());
	EXPECT_THAT(readValue, Eq(Default::DefaultValue()));
}
TEST_F(NvmWrapperTest, Read_RetrievesDefaultValueWhenTheAttributeDoesNotExist)
{
	auto valueNode = m_document.first_child().first_child();
	valueNode.remove_attribute(valueNode.first_attribute());

	auto const readValue = m_spWrapper->Read(Default::ValueName(), Default::DefaultValue());
	EXPECT_THAT(readValue, Eq(Default::DefaultValue()));
}
TEST_F(NvmWrapperTest, Read_CreatesANodeWithCorrectValueWhenItDoesNotExist)
{
	m_spWrapper->Read(Any::NewValueName(), Default::DefaultValue());
	EXPECT_THAT(GetActualValue(Any::NewValueName()), Eq(Default::DefaultValue()));
}
TEST_F(NvmWrapperTest, Write_UpdatesTheNodeValueWhenItExists)
{
	m_spWrapper->Write(Default::ValueName(), Any::NewValue());
	auto const actualValue = GetActualValue(Default::ValueName());
	EXPECT_THAT(actualValue, Eq(Any::NewValue()));
}
TEST_F(NvmWrapperTest, Write_CreatesANodeWithCorrectValueWhenItDoesNotExist)
{
	m_spWrapper->Write(Any::NewValueName(), Any::NewValue());
	EXPECT_THAT(GetActualValue(Any::NewValueName()), Eq(Any::NewValue()));
}
TEST_F(NvmWrapperTest, Write_SavesXmlFile)
{
	EXPECT_CALL(*m_spMockNvmXmlFile, Save());
	m_spWrapper->Write(Any::NewValueName(), Any::NewValue());
}
}
}
