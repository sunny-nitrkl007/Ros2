/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PidValueDecoder tests

#include "Identifiers/PidValueDecoder.cpp"
#include <gmock/gmock.h>

using namespace testing;

namespace Jaws
{
namespace Identifiers
{
namespace
{
struct Any
{
	static constexpr unsigned Pid()       { return 0x112233; }
	static constexpr double UnitScaling() { return 0.25; }
};

enum class Signedness
{
	Signed,
	Unsigned
};

enum class DsiSupport
{
	Supported,
	NotSupported
};

enum class ByteOrder
{
	Lsb,
	Msb
};

enum class DsiStatus
{
	Valid,
	Invalid
};

struct PublishParameter
{
	unsigned byteCount;
	Signedness signedness;
	DsiSupport dsiSupport;
	ByteOrder byteOrder;

	uint8_t inputData[4]; // Ordered according to byteOrder
	double expectedDoubleValue;
	DsiStatus dsiStatus;

	std::vector<uint8_t> GetInputData() const
	{
		return std::vector<uint8_t>{inputData, inputData + byteCount};
	}
};

constexpr PublishParameter n_signedPidPublishers[]
{
	{ 1, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0x7F },                           127.0, DsiStatus::Valid   },
	{ 1, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0x80 },                             0.0, DsiStatus::Invalid },
	{ 1, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0x9F },                             0.0, DsiStatus::Invalid },
	{ 1, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0xA0 },                           -96.0, DsiStatus::Valid   },
	{ 1, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Lsb, { 0x80 },                          -128.0, DsiStatus::Valid   },
	{ 1, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0x42 },                            66.0, DsiStatus::Valid   },
	{ 1, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0xB2 },                           -78.0, DsiStatus::Valid   },

	{ 2, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Msb, { 0x7F, 0xFF },                   32767.0, DsiStatus::Valid   },
	{ 2, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Msb, { 0x80, 0x00 },                       0.0, DsiStatus::Invalid },
	{ 2, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Msb, { 0x80, 0x1F },                       0.0, DsiStatus::Invalid },
	{ 2, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Msb, { 0x80, 0x20 },                  -32736.0, DsiStatus::Valid   },
	{ 2, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Msb, { 0x80, 0x00 },                  -32768.0, DsiStatus::Valid   },
	{ 2, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Msb, { 0x42, 0xB2 },                   17074.0, DsiStatus::Valid   },
	{ 2, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Msb, { 0xB2, 0x42 },                  -19902.0, DsiStatus::Valid   },

	{ 2, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0xFF, 0x7F },                   32767.0, DsiStatus::Valid   },
	{ 2, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0x00, 0x80 },                       0.0, DsiStatus::Invalid },
	{ 2, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0x1F, 0x80 },                       0.0, DsiStatus::Invalid },
	{ 2, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0x20, 0x80 },                  -32736.0, DsiStatus::Valid   },
	{ 2, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Lsb, { 0x00, 0x80 },                  -32768.0, DsiStatus::Valid   },
	{ 2, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Lsb, { 0xB2, 0x42 },                   17074.0, DsiStatus::Valid   },
	{ 2, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Lsb, { 0x42, 0xB2 },                  -19902.0, DsiStatus::Valid   },

	{ 4, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Msb, { 0x7F, 0xFF, 0xFF, 0xFF },  2147483647.0, DsiStatus::Valid   },
	{ 4, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Msb, { 0x80, 0x00, 0x00, 0x00 },           0.0, DsiStatus::Invalid },
	{ 4, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Msb, { 0x80, 0x00, 0x00, 0x1F },           0.0, DsiStatus::Invalid },
	{ 4, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Msb, { 0x80, 0x00, 0x00, 0x20 }, -2147483616.0, DsiStatus::Valid   },
	{ 4, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Msb, { 0x80, 0x00, 0x00, 0x00 }, -2147483648.0, DsiStatus::Valid   },
	{ 4, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Msb, { 0x42, 0x43, 0x44, 0x45 },  1111704645.0, DsiStatus::Valid   },
	{ 4, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Msb, { 0xB2, 0x43, 0x44, 0x45 }, -1304214459.0, DsiStatus::Valid   },

	{ 4, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0xFF, 0xFF, 0xFF, 0x7F },  2147483647.0, DsiStatus::Valid   },
	{ 4, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0x00, 0x00, 0x00, 0x80 },           0.0, DsiStatus::Invalid },
	{ 4, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0x1F, 0x00, 0x00, 0x80 },           0.0, DsiStatus::Invalid },
	{ 4, Signedness::Signed, DsiSupport::Supported,    ByteOrder::Lsb, { 0x20, 0x00, 0x00, 0x80 }, -2147483616.0, DsiStatus::Valid   },
	{ 4, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Lsb, { 0x00, 0x00, 0x00, 0x80 }, -2147483648.0, DsiStatus::Valid   },
	{ 4, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Lsb, { 0x45, 0x44, 0x43, 0x42 },  1111704645.0, DsiStatus::Valid   },
	{ 4, Signedness::Signed, DsiSupport::NotSupported, ByteOrder::Lsb, { 0x45, 0x44, 0x43, 0xB2 }, -1304214459.0, DsiStatus::Valid   },
};
constexpr PublishParameter n_unsignedPidPublishers[]
{
	{ 1, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Lsb, { 0xDF },                           223.0, DsiStatus::Valid   },
	{ 1, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Lsb, { 0xE0 },                             0.0, DsiStatus::Invalid },
	{ 1, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Lsb, { 0xFF },                             0.0, DsiStatus::Invalid },
	{ 1, Signedness::Unsigned, DsiSupport::NotSupported, ByteOrder::Lsb, { 0xE0 },                           224.0, DsiStatus::Valid   },
	{ 1, Signedness::Unsigned, DsiSupport::NotSupported, ByteOrder::Lsb, { 0x42 },                            66.0, DsiStatus::Valid   },

	{ 2, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Msb, { 0xFF, 0xDF },                   65503.0, DsiStatus::Valid   },
	{ 2, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Msb, { 0xFF, 0xE0 },                       0.0, DsiStatus::Invalid },
	{ 2, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Msb, { 0xFF, 0xFF },                       0.0, DsiStatus::Invalid },
	{ 2, Signedness::Unsigned, DsiSupport::NotSupported, ByteOrder::Msb, { 0xFF, 0xE0 },                   65504.0, DsiStatus::Valid   },
	{ 2, Signedness::Unsigned, DsiSupport::NotSupported, ByteOrder::Msb, { 0x42, 0x43 },                   16963.0, DsiStatus::Valid   },

	{ 2, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Lsb, { 0xDF, 0xFF },                   65503.0, DsiStatus::Valid   },
	{ 2, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Lsb, { 0xE0, 0xFF },                       0.0, DsiStatus::Invalid },
	{ 2, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Lsb, { 0xFF, 0xFF },                       0.0, DsiStatus::Invalid },
	{ 2, Signedness::Unsigned, DsiSupport::NotSupported, ByteOrder::Lsb, { 0xE0, 0xFF },                   65504.0, DsiStatus::Valid   },
	{ 2, Signedness::Unsigned, DsiSupport::NotSupported, ByteOrder::Lsb, { 0x43, 0x42 },                   16963.0, DsiStatus::Valid   },

	{ 4, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Msb, { 0xFF, 0xFF, 0xFF, 0xDF },  4294967263.0, DsiStatus::Valid   },
	{ 4, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Msb, { 0xFF, 0xFF, 0xFF, 0xE0 },           0.0, DsiStatus::Invalid },
	{ 4, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Msb, { 0xFF, 0xFF, 0xFF, 0xFF },           0.0, DsiStatus::Invalid },
	{ 4, Signedness::Unsigned, DsiSupport::NotSupported, ByteOrder::Msb, { 0xFF, 0xFF, 0xFF, 0xE0 },  4294967264.0, DsiStatus::Valid   },
	{ 4, Signedness::Unsigned, DsiSupport::NotSupported, ByteOrder::Msb, { 0x42, 0x43, 0x44, 0x45 },  1111704645.0, DsiStatus::Valid   },

	{ 4, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Lsb, { 0xDF, 0xFF, 0xFF, 0xFF },  4294967263.0, DsiStatus::Valid   },
	{ 4, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Lsb, { 0xE0, 0xFF, 0xFF, 0xFF },           0.0, DsiStatus::Invalid },
	{ 4, Signedness::Unsigned, DsiSupport::Supported,    ByteOrder::Lsb, { 0xFF, 0xFF, 0xFF, 0xFF },           0.0, DsiStatus::Invalid },
	{ 4, Signedness::Unsigned, DsiSupport::NotSupported, ByteOrder::Lsb, { 0xE0, 0xFF, 0xFF, 0xFF },  4294967264.0, DsiStatus::Valid   },
	{ 4, Signedness::Unsigned, DsiSupport::NotSupported, ByteOrder::Lsb, { 0x45, 0x44, 0x43, 0x42 },  1111704645.0, DsiStatus::Valid   },
};

cat::shark::PidEntry CreatePidEntry(PublishParameter const& param, cat::shark::DataPresentationType type, double unitsPerBit)
{
	cat::shark::PidEntry pidEntry{};
	pidEntry.set_pid(Any::Pid());
	pidEntry.set_byte_count(param.byteCount);
	pidEntry.set_is_signed(param.signedness == Signedness::Signed);
	pidEntry.set_is_dsi_supported(param.dsiSupport == DsiSupport::Supported);
	pidEntry.set_is_lsb(param.byteOrder == ByteOrder::Lsb);
	pidEntry.set_scaling(unitsPerBit);
	pidEntry.set_data_presentation_type(type);
	return pidEntry;
}
}

class PidValueDecoderTest : public TestWithParam<PublishParameter>
{
protected:
	DecodedPidValue Decode(cat::shark::DataPresentationType type, double unitsPerBit = 1.0)
	{
		auto const& param = GetParam();
		auto const pidEntry = CreatePidEntry(param, type, unitsPerBit);
		return m_decoder.Decode(PidDefinition{pidEntry}, Shark::SharkByteValue{param.GetInputData()});
	}

	PidValueDecoder const m_decoder{};
};
TEST_F(PidValueDecoderTest, Decode_ReportsNotReceivedWhenTheSharkByteHasNoValue)
{
	cat::shark::PidEntry pidEntry{};
	pidEntry.set_byte_count(1);
	pidEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_DOUBLE);

	auto const decoded = m_decoder.Decode(PidDefinition{pidEntry}, Shark::SharkByteValue{});

	EXPECT_THAT(decoded.quality, Eq(DecodedPidQuality::NotReceived));
}

class RawPidValueDecoderTest : public PidValueDecoderTest {};
INSTANTIATE_TEST_SUITE_P(RawSigned, RawPidValueDecoderTest, ValuesIn(n_signedPidPublishers));
INSTANTIATE_TEST_SUITE_P(RawUnsigned, RawPidValueDecoderTest, ValuesIn(n_unsignedPidPublishers));
TEST_P(RawPidValueDecoderTest, Decode_ReturnsTheRawBytesAsABinaryValue)
{
	auto const decoded = Decode(cat::shark::DATA_PRESENTATION_TYPE_BINARY);

	EXPECT_THAT(decoded.quality, Eq(DecodedPidQuality::Good));
	EXPECT_THAT(std::get<std::vector<uint8_t>>(decoded.value), ContainerEq(GetParam().GetInputData()));
}

class DoublePidValueDecoderTest : public PidValueDecoderTest {};
INSTANTIATE_TEST_SUITE_P(DoubleSigned, DoublePidValueDecoderTest, ValuesIn(n_signedPidPublishers));
INSTANTIATE_TEST_SUITE_P(DoubleUnsigned, DoublePidValueDecoderTest, ValuesIn(n_unsignedPidPublishers));
TEST_P(DoublePidValueDecoderTest, Decode_ProducesAScaledDoubleValueWithUnityScaling)
{
	auto const& param = GetParam();
	auto const decoded = Decode(cat::shark::DATA_PRESENTATION_TYPE_DOUBLE);

	if (param.dsiStatus == DsiStatus::Invalid)
	{
		EXPECT_THAT(decoded.quality, Eq(DecodedPidQuality::Bad));
	}
	else
	{
		EXPECT_THAT(decoded.quality, Eq(DecodedPidQuality::Good));
		EXPECT_THAT(std::get<double>(decoded.value), DoubleEq(param.expectedDoubleValue));
	}
}
TEST_P(DoublePidValueDecoderTest, Decode_ProducesAScaledDoubleValueWithAlternateScaling)
{
	auto const& param = GetParam();
	auto const decoded = Decode(cat::shark::DATA_PRESENTATION_TYPE_DOUBLE, Any::UnitScaling());

	if (param.dsiStatus == DsiStatus::Invalid)
	{
		EXPECT_THAT(decoded.quality, Eq(DecodedPidQuality::Bad));
	}
	else
	{
		EXPECT_THAT(decoded.quality, Eq(DecodedPidQuality::Good));
		EXPECT_THAT(std::get<double>(decoded.value), DoubleEq(param.expectedDoubleValue * Any::UnitScaling()));
	}
}

class UintPidValueDecoderTest : public PidValueDecoderTest {};
INSTANTIATE_TEST_SUITE_P(UintUnsigned, UintPidValueDecoderTest, ValuesIn(n_unsignedPidPublishers));
TEST_P(UintPidValueDecoderTest, Decode_ProducesAScaledUintValueWithUnityScaling)
{
	auto const& param = GetParam();
	auto const decoded = Decode(cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED);

	if (param.dsiStatus == DsiStatus::Invalid)
	{
		EXPECT_THAT(decoded.quality, Eq(DecodedPidQuality::Bad));
	}
	else
	{
		EXPECT_THAT(decoded.quality, Eq(DecodedPidQuality::Good));
		EXPECT_THAT(std::get<uint64_t>(decoded.value), Eq(static_cast<uint64_t>(param.expectedDoubleValue)));
	}
}
TEST_P(UintPidValueDecoderTest, Decode_ProducesAScaledUintValueWithAlternateScaling)
{
	auto const& param = GetParam();
	auto const decoded = Decode(cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED, Any::UnitScaling());

	if (param.dsiStatus == DsiStatus::Invalid)
	{
		EXPECT_THAT(decoded.quality, Eq(DecodedPidQuality::Bad));
	}
	else
	{
		EXPECT_THAT(decoded.quality, Eq(DecodedPidQuality::Good));
		EXPECT_THAT(std::get<uint64_t>(decoded.value), Eq(static_cast<uint64_t>(param.expectedDoubleValue * Any::UnitScaling())));
	}
}
}
}
