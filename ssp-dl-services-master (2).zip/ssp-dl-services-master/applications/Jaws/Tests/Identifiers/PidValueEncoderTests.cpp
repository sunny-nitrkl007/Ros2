/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PidValueEncoder tests

#include "Identifiers/PidValueEncoder.cpp"
#include "Utilities/TestExpectedUtilities.h"
#include <gmock/gmock.h>

using namespace testing;

namespace Jaws
{
namespace Identifiers
{
namespace
{
constexpr cat::shark::PidEntry CreatePidEntry(
	unsigned byteCount,
	bool isLsb,
	cat::shark::DataPresentationType type,
	double unitsPerBit = 1.0)
{
	cat::shark::PidEntry pidEntry{};
	pidEntry.set_byte_count(byteCount);
	pidEntry.set_scaling(unitsPerBit);
	pidEntry.set_is_lsb(isLsb);
	pidEntry.set_data_presentation_type(type);
	return pidEntry;
}
}

class PidValueEncoderTest : public Test
{
protected:
	struct Default
	{
		static cat::shark::PidEntry BinaryPidEntry()
		{
			return CreatePidEntry(2, true, cat::shark::DATA_PRESENTATION_TYPE_BINARY);
		}
	};

	std::vector<uint8_t> MakeValidBinaryData() const
	{
		assert(Default::BinaryPidEntry().byte_count() == 2);
		return {0x40, 0x41};
	}

	PidValueEncoder m_encoder{};
};
TEST_F(PidValueEncoderTest, Encode_RejectsWrongTypeForDoublePidDefinitions)
{
	auto const pidEntry = CreatePidEntry(2, true, cat::shark::DATA_PRESENTATION_TYPE_DOUBLE);

	auto encoded = m_encoder.Encode(PidDefinition{pidEntry}, 12u);
	EXPECT_THAT(encoded, HasExpectedError(Eq(EncodedPidStatus::BadType)));

	encoded = m_encoder.Encode(PidDefinition{pidEntry}, MakeValidBinaryData());
	EXPECT_THAT(encoded, HasExpectedError(Eq(EncodedPidStatus::BadType)));
}
TEST_F(PidValueEncoderTest, Encode_RejectsWrongTypeForUnsignedPidDefinitions)
{
	auto const pidEntry = CreatePidEntry(2, true, cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED);

	auto encoded = m_encoder.Encode(PidDefinition{pidEntry}, 12.0);
	EXPECT_THAT(encoded, HasExpectedError(Eq(EncodedPidStatus::BadType)));

	encoded = m_encoder.Encode(PidDefinition{pidEntry}, MakeValidBinaryData());
	EXPECT_THAT(encoded, HasExpectedError(Eq(EncodedPidStatus::BadType)));
}
TEST_F(PidValueEncoderTest, Encode_RejectsWrongTypeForBinaryPidDefinitions)
{
	auto const pidEntry = CreatePidEntry(2, true, cat::shark::DATA_PRESENTATION_TYPE_BINARY);

	auto encoded = m_encoder.Encode(PidDefinition{pidEntry}, 12.0);
	EXPECT_THAT(encoded, HasExpectedError(Eq(EncodedPidStatus::BadType)));

	encoded = m_encoder.Encode(PidDefinition{pidEntry}, 12u);
	EXPECT_THAT(encoded, HasExpectedError(Eq(EncodedPidStatus::BadType)));
}
TEST_F(PidValueEncoderTest, Encode_EncodesBinaryDataWithouthModification)
{
	auto const binaryData = MakeValidBinaryData();
	auto const encoded = m_encoder.Encode({Default::BinaryPidEntry()}, binaryData);

	EXPECT_THAT(encoded, HasExpectedValue(ElementsAreArray(binaryData)));
}
TEST_F(PidValueEncoderTest, Encode_RejectsBinaryDataWhenTheLengthDoesNotMatchTheConfiguredByteCount)
{
	auto const pidEntry = Default::BinaryPidEntry();
	for (auto const length : {pidEntry.byte_count() - 1, pidEntry.byte_count() + 1})
	{
		std::vector<uint8_t> binaryData{};
		binaryData.resize(length);
		auto const encoded = m_encoder.Encode({pidEntry}, binaryData);
		EXPECT_THAT(encoded, HasExpectedError(EncodedPidStatus::InvalidLength));
	}
}
TEST_F(PidValueEncoderTest, Encode_RejectsUntypedValue)
{
	auto const encoded = m_encoder.Encode(PidDefinition{Default::BinaryPidEntry()}, FixedLengthPidValue{});
	EXPECT_THAT(encoded, HasExpectedError(Eq(EncodedPidStatus::BadType)));
}

namespace
{
struct TestDoubleWriteData
{
	double writeValue;
	unsigned byteCount;
	double unitsPerBit;
	uint8_t expectedOutput[4];

	constexpr std::vector<uint8_t> GetLsbData() const noexcept
	{
		return std::vector<uint8_t>(expectedOutput, expectedOutput + byteCount);
	}
	constexpr std::vector<uint8_t> GetMsbData() const noexcept
	{
		auto data = GetLsbData();
		std::reverse(std::begin(data), std::begin(data) + byteCount);
		return data;
	}
};
void PrintTo(TestDoubleWriteData const& d, std::ostream* os)
{
	*os << "writeValue=" << d.writeValue;
}
constexpr TestDoubleWriteData n_testDoubleWriteData[]
{
	{ -1.0, 1, 1, { 0xFF } },
	{  0.0, 1, 1, { 0x00 } },
	{  1.0, 1, 1, { 0x01 } },

	{ -1.0, 2, 1, { 0xFF, 0xFF } },
	{  1.0, 2, 1, { 0x01, 0x00 } },

	{ -1.0, 4, 1, { 0xFF, 0xFF, 0xFF, 0xFF } },
	{  1.0, 4, 1, { 0x01, 0x00, 0x00, 0x00 } },

	{ -2.8, 1, 1, { 0xFD }, },
	{ -2.3, 1, 1, { 0xFE }, },
	{  2.3, 1, 1, { 0x02 }, },
	{  2.8, 1, 1, { 0x03 }, },

	{ -128.4999, 1, 1, { 0x80 } },
	{  255.4999, 1, 1, { 0xFF } },

	{  0.99, 2, 0.5, { 0x02, 0x00 } },
	{ -0.99, 2, 0.5, { 0xFE, 0xFF } },

	{  8000000002, 4, 2, { 0x01, 0x28, 0x6B, 0xEE } },
	{ -4000000002, 4, 2, { 0xFF, 0x6B, 0xCA, 0x88 } },
};
}
class PidValueEncoder_DoubleTest : public TestWithParam<TestDoubleWriteData>
{
protected:
	void RunTest(bool isLsbTest)
	{
		auto const& param = GetParam();

		cat::shark::PidEntry pidEntry = CreatePidEntry(
			param.byteCount,
			isLsbTest,
			cat::shark::DATA_PRESENTATION_TYPE_DOUBLE,
			param.unitsPerBit);

		auto const bytes = m_encoder.Encode({pidEntry}, param.writeValue);
		EXPECT_THAT(bytes, HasExpectedValue(ElementsAreArray(isLsbTest ? param.GetLsbData() : param.GetMsbData())));
	}

	PidValueEncoder const m_encoder{};
};
INSTANTIATE_TEST_SUITE_P(PidValueEncoder, PidValueEncoder_DoubleTest, ValuesIn(n_testDoubleWriteData));
TEST_P(PidValueEncoder_DoubleTest, GetDataToWrite_ConvertsDoubleValueToLsbBytesAccordingToPidDefinition)
{
	RunTest(true);
}
TEST_P(PidValueEncoder_DoubleTest, GetDataToWrite_ConvertsDoubleValueToMsbBytesAccordingToPidDefinition)
{
	RunTest(false);
}

namespace
{
struct TestUintWriteData
{
	uint64_t writeValue;
	unsigned byteCount;
	double unitsPerBit;
	uint8_t expectedOutput[4];

	std::vector<uint8_t> GetLsbData() const noexcept
	{
		return std::vector<uint8_t>(expectedOutput, expectedOutput + byteCount);
	}
	std::vector<uint8_t> GetMsbData() const noexcept
	{
		auto data = GetLsbData();
		std::reverse(std::begin(data), std::begin(data) + byteCount);
		return data;
	}
};
void PrintTo(TestUintWriteData const& d, std::ostream* os)
{
	*os << "writeValue=" << d.writeValue;
}
constexpr TestUintWriteData n_testUintWriteData[]
{
	{ 0,   1, 1, { 0x00 } },
	{ 1,   1, 1, { 0x01 } },
	{ 255, 1, 1, { 0xFF } },

	{     0, 2, 1, { 0x00, 0x00 } },
	{     1, 2, 1, { 0x01, 0x00 } },
	{ 65535, 2, 1, { 0xFF, 0xFF } },

	{          0, 4, 1, { 0x00, 0x00, 0x00, 0x00 } },
	{          1, 4, 1, { 0x01, 0x00, 0x00, 0x00 } },
	{ 4294967295, 4, 1, { 0xFF, 0xFF, 0xFF, 0xFF } },

	{  8000000002, 4, 2, { 0x01, 0x28, 0x6B, 0xEE } },
};
}
class PidValueEncoder_UintTest : public TestWithParam<TestUintWriteData>
{
public:
	void RunTest(bool isLsbTest)
	{
		auto const& param = GetParam();
		cat::shark::PidEntry pidEntry = CreatePidEntry(
			param.byteCount,
			isLsbTest,
			cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED,
			param.unitsPerBit);

		auto const bytes = m_encoder.Encode({pidEntry}, param.writeValue);
		EXPECT_THAT(bytes, HasExpectedValue(ElementsAreArray(isLsbTest ? param.GetLsbData() : param.GetMsbData())));
	}

	PidValueEncoder const m_encoder{};
};
INSTANTIATE_TEST_SUITE_P(PidValueEncoder, PidValueEncoder_UintTest, ValuesIn(n_testUintWriteData));
TEST_P(PidValueEncoder_UintTest, GetDataToWrite_ConvertsUintValueToLsbBytesAccordingToPidDefinition)
{
	RunTest(true);
}
TEST_P(PidValueEncoder_UintTest, GetDataToWrite_ConvertsUintValueToMsbBytesAccordingToPidDefinition)
{
	RunTest(false);
}
}
}