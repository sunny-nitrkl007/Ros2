/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IPidValueEncoder

#pragma once

#include "Identifiers/IPidValueEncoder.h"
#include <Utilities/DataEngineMock.h>

namespace Jaws
{
namespace Identifiers
{
class MockIPidValueEncoder : public IPidValueEncoder
{
	EnsureMockKindIsSpecified(MockIPidValueEncoder);
public:
	MOCK_METHOD(IPidValueEncoder::ExpectedType, Encode, (PidDefinition const& pidDefinition, FixedLengthPidValue const& value), (const override));
};
}
}