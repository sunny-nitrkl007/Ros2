/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PgnDefinition tests

#include "Identifiers/PgnDefinition.cpp"
#include <gtest/gtest.h>
#include <gmock/gmock.h>

using namespace testing;

namespace Jaws
{
namespace Identifiers
{
namespace
{
struct Any
{
	static constexpr Config::Pgn Pgn() { return 0x00FEEE; }
	static constexpr unsigned BitOffset() { return 8; }
	static constexpr unsigned Spn() { return 1; }
	static constexpr unsigned SpnCount() { return 5; }
};
}

class PgnDefinitionTest : public Test
{
protected:
	PgnDefinition const CreateDefinition()
	{
		m_pgnEntry.set_pgn(Any::Pgn());
		for (auto entryNum = 0u; entryNum < Any::SpnCount(); ++entryNum)
		{
			auto& offsetPgn = *m_pgnEntry.add_offset_spns();
			offsetPgn.set_spn(Any::Spn() + entryNum);
			offsetPgn.set_bit_offset(Any::BitOffset() + entryNum);
		}
		return PgnDefinition{m_pgnEntry};
	}

	cat::shark::PgnEntry m_pgnEntry{};
};
TEST_F(PgnDefinitionTest, Pgn_IsFromPgnSource)
{
	auto const pgnDefinition = CreateDefinition();
	EXPECT_THAT(pgnDefinition.Pgn(), Eq(Any::Pgn()));
}
TEST_F(PgnDefinitionTest, SpnEntries_Find_RetrievesTheCorrectSpnOffsetEntry)
{
	auto const pgnDefinition = CreateDefinition();
	constexpr auto const spnIndexToTest = 3;
	auto const thirdSpnOffset = pgnDefinition.FindSpnOffset(spnIndexToTest);
	ASSERT_TRUE(thirdSpnOffset);
	EXPECT_THAT(*thirdSpnOffset, Eq(Any::BitOffset() + spnIndexToTest - 1));
}
TEST_F(PgnDefinitionTest, SpnEntries_Find_ReturnsEmptyOptionalForOutOfRangeIndex)
{
	auto const pgnDefinition = CreateDefinition();
	auto const spnIndexToTest = Any::SpnCount() + 1;
	auto const thirdSpnOffsetEntry = pgnDefinition.FindSpnOffset(spnIndexToTest);
	EXPECT_THAT(thirdSpnOffsetEntry, Eq(std::nullopt));
}
TEST_F(PgnDefinitionTest, PgnDefinitionsContainingTheSamePgnEntryAddressesAreEqual)
{
	cat::shark::PgnEntry pgnEntry{};
	PgnDefinition pgnDefinition{pgnEntry};
	EXPECT_TRUE(pgnDefinition == pgnDefinition);
}
TEST_F(PgnDefinitionTest, PgnDefinitionsContainingDifferentPgnEntryAddressesAreNotEqual)
{
	cat::shark::PgnEntry pgnEntry1{};
	cat::shark::PgnEntry pgnEntry2{};
	PgnDefinition pgnDefinition1{pgnEntry1};
	PgnDefinition pgnDefinition2{pgnEntry2};
	EXPECT_FALSE(pgnDefinition1 == pgnDefinition2);
}
}
}