/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IPublicJ1939DefinitionRetriever

#pragma once

#include "Identifiers/IPublicJ1939DefinitionRetriever.h"
#include <Utilities/DestructorTester.h>
#include <gmock/gmock.h>

namespace Jaws
{
namespace Identifiers
{
class MockIPublicJ1939DefinitionRetriever : public IPublicJ1939DefinitionRetriever, public Utilities::DestructorTesterManager
{
	EnsureMockKindIsSpecified(MockIPublicJ1939DefinitionRetriever);
public:
	MOCK_METHOD(PgnDefinition, RetrievePgnDefinition, (unsigned pgn), (const override));
	MOCK_METHOD(SpnDefinition, RetrieveSpnDefinition, (unsigned spn), (const override));
};
}
}
