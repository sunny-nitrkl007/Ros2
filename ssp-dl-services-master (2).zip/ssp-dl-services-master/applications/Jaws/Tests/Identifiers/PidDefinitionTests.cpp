/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PidDefinition tests

#include "Identifiers/PidDefinition.cpp"
#include <gtest/gtest.h>
#include <gmock/gmock.h>

using namespace testing;

namespace Jaws
{
namespace Identifiers
{
namespace
{
struct Any
{
	static constexpr Config::Pid Pid()   { return 0x42; }
	static constexpr Config::Pid MultiBytePid() { return 0xF99C; }
	static constexpr unsigned ByteCount() { return 2; }
	static constexpr double Scaling() { return 4.242; }
	static constexpr cat::shark::Unit Units() { return cat::shark::UNIT_RPM; }
	static constexpr unsigned MinimumLength() { return 2; }
	static constexpr unsigned MaximumLength() { return 10; }
};
}

class PidDefinitionTest : public Test
{
protected:
	PidDefinition const CreateDefinition() const
	{
		return PidDefinition{m_pidEntry};
	}

	cat::shark::PidEntry m_pidEntry{};
};
TEST_F(PidDefinitionTest, Pid_IsFromPidSource)
{
	m_pidEntry.set_pid(Any::Pid());
	EXPECT_THAT(CreateDefinition().Pid(), Eq(Any::Pid()));
}
TEST_F(PidDefinitionTest, ByteCount_IsFromPidSource)
{
	m_pidEntry.set_byte_count(Any::ByteCount());
	EXPECT_THAT(CreateDefinition().ByteCount(), Eq(Any::ByteCount()));
}
TEST_F(PidDefinitionTest, Resolution_IsFromPidSource)
{
	m_pidEntry.set_scaling(Any::Scaling());
	EXPECT_THAT(CreateDefinition().UnitsPerBit(), Eq(Any::Scaling()));
}
TEST_F(PidDefinitionTest, Units_IsFromPidSource)
{
	m_pidEntry.set_unit(Any::Units());
	EXPECT_THAT(CreateDefinition().Units(), Eq(Any::Units()));
}
TEST_F(PidDefinitionTest, IsSigned_IsFromPidSource)
{
	for (auto const isSigned : Bool())
	{
		m_pidEntry.set_is_signed(isSigned);
		EXPECT_THAT(CreateDefinition().IsSigned(), Eq(isSigned));
	}
}
TEST_F(PidDefinitionTest, IsDsiCapable_IsFromPidSource)
{
	for (auto const isDsi : Bool())
	{
		m_pidEntry.set_is_dsi_supported(isDsi);
		EXPECT_THAT(CreateDefinition().IsDsiCapable(), Eq(isDsi));
	}
}
TEST_F(PidDefinitionTest, IsLsb_IsFromPidSource)
{
	for (auto const isLsb : Bool())
	{
		m_pidEntry.set_is_lsb(isLsb);
		EXPECT_THAT(CreateDefinition().IsLsbFirst(), Eq(isLsb));
	}
}
TEST_F(PidDefinitionTest, IsDouble_IsTrueWhenDouble)
{
	m_pidEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_DOUBLE);
	EXPECT_TRUE(CreateDefinition().IsDouble());
}
TEST_F(PidDefinitionTest, IsDouble_IsFalseWhenNotDouble)
{
	m_pidEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED);
	EXPECT_FALSE(CreateDefinition().IsDouble());
}
TEST_F(PidDefinitionTest, IsUint_IsTrueWhenUint)
{
	m_pidEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED);
	EXPECT_TRUE(CreateDefinition().IsUint());
}
TEST_F(PidDefinitionTest, IsUint_IsFalseWhenNotUint)
{
	m_pidEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_DOUBLE);
	EXPECT_FALSE(CreateDefinition().IsUint());
}
TEST_F(PidDefinitionTest, IsRaw_IsTrueWhenBinary)
{
	m_pidEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_BINARY);
	EXPECT_TRUE(CreateDefinition().IsRaw());
}
TEST_F(PidDefinitionTest, IsGear_IsFalseWhenNotRaw)
{
	m_pidEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED);
	EXPECT_FALSE(CreateDefinition().IsRaw());
}

class MultiBytePidDefinitionTest : public Test
{
protected:
	MultiBytePidDefinition CreateDefinition() const
	{
		return MultiBytePidDefinition{m_pidEntry};
	}

	cat::shark::MultiBytePidEntry m_pidEntry{};
};
TEST_F(MultiBytePidDefinitionTest, Pid_IsFromPidSource)
{
	m_pidEntry.set_pid(Any::MultiBytePid());
	EXPECT_THAT(CreateDefinition().Pid(), Eq(Any::MultiBytePid()));
}
TEST_F(MultiBytePidDefinitionTest, WhenDataTypeIsString_IsStringReturnsTrueAndIsBinaryReturnsFalse)
{
	m_pidEntry.set_multi_byte_pid_data_type(cat::shark::MultiBytePidEntry::MULTI_BYTE_PID_DATA_TYPE_STRING);
	auto const& definition = CreateDefinition();
	EXPECT_TRUE(definition.IsString());
	EXPECT_FALSE(definition.IsBinary());
}
TEST_F(MultiBytePidDefinitionTest, WhenDataTypeIsBinary_IsBinaryReturnsTrueAndIsStringReturnsFalse)
{
	m_pidEntry.set_multi_byte_pid_data_type(cat::shark::MultiBytePidEntry::MULTI_BYTE_PID_DATA_TYPE_BINARY);
	auto const& definition = CreateDefinition();
	EXPECT_TRUE(definition.IsBinary());
	EXPECT_FALSE(definition.IsString());
}
TEST_F(MultiBytePidDefinitionTest, MinimumParameterDataLength_IsFromPidSource)
{
	m_pidEntry.set_minimum_length(Any::MinimumLength());
	EXPECT_THAT(CreateDefinition().MinimumParameterDataLength(), Eq(Any::MinimumLength()));
}
TEST_F(MultiBytePidDefinitionTest, MaximumParameterDataLength_IsFromPidSource)
{
	m_pidEntry.set_maximum_length(Any::MaximumLength());
	EXPECT_THAT(CreateDefinition().MaximumParameterDataLength(), Eq(Any::MaximumLength()));
}
}
}