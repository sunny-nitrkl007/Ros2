/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IPidDefinitionRetriever

#pragma once

#include "Identifiers/IPidDefinitionRetriever.h"
#include <Utilities/DestructorTester.h>
#include <Utilities/DataEngineMock.h>
#include <deque>

namespace Jaws
{
namespace Identifiers
{
class MockIPidDefinitionRetriever : public IPidDefinitionRetriever, public Utilities::DestructorTesterManager
{
	EnsureMockKindIsSpecified(MockIPidDefinitionRetriever);
public:
	struct Default
	{
		static constexpr auto ByteCount() { return 1u; }
	};

	MockIPidDefinitionRetriever()
	{
		using namespace ::testing;
		ON_CALL(*this, RetrievePid(_))
			.WillByDefault(Invoke(this, &MockIPidDefinitionRetriever::DefaultRetrieveImplementation));
	}

	MOCK_METHOD(PidDefinition, RetrievePid, (Config::Pid pid), (const override));
	MOCK_METHOD(MultiBytePidDefinition, RetrieveMultiBytePid, (Config::Pid pid), (const override));
private:
	PidDefinition DefaultRetrieveImplementation(Config::Pid pid)
	{
		cat::shark::PidEntry pidEntry{};
		pidEntry.set_pid(pid);
		pidEntry.set_byte_count(Default::ByteCount());
		m_pidEntries.push_back(pidEntry);
		return {m_pidEntries.back()};
	}

	std::deque<cat::shark::PidEntry> m_pidEntries{}; // Must be a deque so entries aren't moved around
};
}
}