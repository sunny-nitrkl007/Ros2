/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IPidValueDecoder

#pragma once

#include "Identifiers/IPidValueDecoder.h"
#include <Utilities/DataEngineMock.h>

namespace Jaws
{
namespace Identifiers
{
class MockIPidValueDecoder : public IPidValueDecoder
{
	EnsureMockKindIsSpecified(MockIPidValueDecoder);
public:
	MOCK_METHOD(DecodedPidValue, Decode, (PidDefinition const& pidDefinition, Shark::SharkByteValue const& value), (const override));
};
}
}
