/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PidDefinitionRetriever tests

#include "Identifiers/PidDefinitionRetriever.cpp"
#include <gmock/gmock.h>
#include <memory>

using namespace testing;

namespace Jaws
{
namespace Identifiers
{
namespace
{
struct Any
{
	static constexpr unsigned DefinedPid()    { return 0xD10101; }
	static constexpr unsigned DefinedMultiBytePid() { return 0xF99C; }
	static constexpr unsigned NotDefinedPid() { return 0x45; }
};
PidEntries CreateAnyPidEntries()
{
	cat::shark::Config config{};
	auto& pidEntry = *config.add_pid_entries();
	pidEntry.set_pid(Any::DefinedPid());
	return config.pid_entries();
}
MultiBytePidEntries CreateAnyMultiBytePidEntries()
{
	cat::shark::Config config{};
	auto& multiBytePidEntry = *config.add_multi_byte_pid_entries();
	multiBytePidEntry.set_pid(Any::DefinedMultiBytePid());
	return config.multi_byte_pid_entries();
}
}

class PidDefinitionRetrieverTest : public Test
{
protected:
	PidDefinitionRetrieverTest()
	{
		CreateRetriever();
	}
	void CreateRetriever()
	{
		m_spRetriever = std::make_unique<PidDefinitionRetriever>(m_pidEntries, m_multiBytePidEntries);
	}
	PidEntries const m_pidEntries{CreateAnyPidEntries()};
	MultiBytePidEntries const m_multiBytePidEntries{CreateAnyMultiBytePidEntries()};
	std::unique_ptr<PidDefinitionRetriever> m_spRetriever{};
};
TEST_F(PidDefinitionRetrieverTest, RetrievePid_ThrowsErrorForMissingPid)
{
	EXPECT_THROW(m_spRetriever->RetrievePid(Any::NotDefinedPid()), IPidDefinitionRetriever::Error);
}
TEST_F(PidDefinitionRetrieverTest, RetrievePid_ReturnsDefinitionForExistingPid)
{
	auto const searchPid = Any::DefinedPid();
	auto const definition = m_spRetriever->RetrievePid(searchPid);
	EXPECT_THAT(definition.Pid(), Eq(searchPid));
}
TEST_F(PidDefinitionRetrieverTest, RetrieveMultiBytePid_ThrowsNotFoundForMissingPid)
{
	EXPECT_THROW(m_spRetriever->RetrieveMultiBytePid(Any::NotDefinedPid()), IPidDefinitionRetriever::Error);
}
TEST_F(PidDefinitionRetrieverTest, RetrieveMultiBytePid_ReturnsDefinitionForExistingPid)
{
	auto const searchPid = Any::DefinedMultiBytePid();
	auto const definition = m_spRetriever->RetrieveMultiBytePid(searchPid);
	EXPECT_THAT(definition.Pid(), Eq(searchPid));
}
}
}