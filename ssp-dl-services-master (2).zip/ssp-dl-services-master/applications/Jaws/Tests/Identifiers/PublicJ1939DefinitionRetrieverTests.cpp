/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PgnDefinitionRetriever tests

#include "Identifiers/PublicJ1939DefinitionRetriever.cpp"
#include <gmock/gmock.h>

using namespace testing;

namespace Jaws
{
namespace Identifiers
{
namespace
{
struct Any
{
	static constexpr unsigned ValidPgn() { return 0xF004; }
	static constexpr unsigned OtherPgn() { return 0xFEEE; }
	static constexpr unsigned ValidSpn() { return 190; }
	static constexpr unsigned OtherSpn() { return 3442; }
	static constexpr unsigned BitOffset() { return 42; }
};

using namespace cat::shark;
PgnEntries const CreatePgnEntries()
{
	PgnEntries pgnEntries{};
	auto& pgnEntry = *pgnEntries.Add();
	pgnEntry.set_pgn(Any::ValidPgn());
	auto& spnEntry = *pgnEntry.add_offset_spns();
	spnEntry.set_spn(Any::ValidSpn());
	spnEntry.set_bit_offset(Any::BitOffset());
	return pgnEntries;
}
SpnEntries const CreateSpnEntries()
{
	SpnEntries spnEntries{};
	auto& spnEntry = *spnEntries.Add();
	spnEntry.set_spn(Any::ValidSpn());
	return spnEntries;
}
}

class PublicJ1939DefinitionRetrieverTest : public Test
{
protected:
	PgnEntries const m_pgnEntries{CreatePgnEntries()};
	SpnEntries const m_spnEntries{CreateSpnEntries()};
	PublicJ1939DefinitionRetriever const m_retriever{m_pgnEntries, m_spnEntries};
};
TEST_F(PublicJ1939DefinitionRetrieverTest, RetrievePgnDefinition_ThrowsErrorForMissingPgn)
{
	EXPECT_THROW(m_retriever.RetrievePgnDefinition(Any::OtherPgn()), IPublicJ1939DefinitionRetriever::Error);
}
TEST_F(PublicJ1939DefinitionRetrieverTest, RetrievePgnDefinition_ReturnsDefinitionForExistingPgn)
{
	auto const searchPgn = Any::ValidPgn();
	auto const definition = m_retriever.RetrievePgnDefinition(searchPgn);
	EXPECT_THAT(definition.Pgn(), Eq(searchPgn));
}
TEST_F(PublicJ1939DefinitionRetrieverTest, RetrieveSpnDefinition_ThrowsErrorForMissingSpn)
{
	EXPECT_THROW(m_retriever.RetrieveSpnDefinition(Any::OtherSpn()), IPublicJ1939DefinitionRetriever::Error);
}
TEST_F(PublicJ1939DefinitionRetrieverTest, RetrieveSpnDefinition_ReturnsDefinitionForExistingSpn)
{
	auto const searchSpn = Any::ValidSpn();
	auto const definition = m_retriever.RetrieveSpnDefinition(searchSpn);
	EXPECT_THAT(definition.Spn(), Eq(searchSpn));
}

class PublicJ1939DefinitionRetrieverEmptyListTest : public Test
{
protected:
	PgnEntries const m_pgnEntries{};
	SpnEntries const m_spnEntries{};
	PublicJ1939DefinitionRetriever const m_retriever{m_pgnEntries, m_spnEntries};
};
TEST_F(PublicJ1939DefinitionRetrieverEmptyListTest, RetrievePgnDefinition_ThrowsErrorWhenPgnEntryListIsEmpty)
{
	EXPECT_THROW(m_retriever.RetrievePgnDefinition(Any::OtherPgn()), IPublicJ1939DefinitionRetriever::Error);
}
TEST_F(PublicJ1939DefinitionRetrieverEmptyListTest, RetrieveSpnDefinition_ThrowsErrorWhenSpnEntryListIsEmpty)
{
	EXPECT_THROW(m_retriever.RetrieveSpnDefinition(Any::OtherSpn()), IPublicJ1939DefinitionRetriever::Error);
}
}
}