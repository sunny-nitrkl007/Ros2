/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SpnDefinition tests

#include "Identifiers/SpnDefinition.cpp"
#include <gtest/gtest.h>
#include <gmock/gmock.h>

using namespace testing;

namespace Jaws
{
namespace Identifiers
{
namespace
{
struct Any
{
	static constexpr Config::Spn Spn() { return 4242; }
	static constexpr unsigned BitCount() { return 42; }
	static constexpr double UnitsPerBit() { return 3.5; }
	static constexpr double ValueOffset() { return 5.5; }
	static constexpr cat::shark::Unit Units() { return cat::shark::UNIT_RPM; }
};
}

class SpnDefinitionTest : public Test
{
protected:
	SpnDefinition const CreateDefinition() const
	{
		return SpnDefinition{m_spnEntry};
	}

	cat::shark::SpnEntry m_spnEntry{};
};
TEST_F(SpnDefinitionTest, Spn_IsFromSpnSource)
{
	m_spnEntry.set_spn(Any::Spn());
	auto const spnDefinition = CreateDefinition();
	EXPECT_THAT(spnDefinition.Spn(), Eq(Any::Spn()));
}
TEST_F(SpnDefinitionTest, BitCount_IsFromSpnSource)
{
	m_spnEntry.set_bit_count(Any::BitCount());
	auto const spnDefinition = CreateDefinition();
	EXPECT_THAT(spnDefinition.BitCount(), Eq(Any::BitCount()));
}
TEST_F(SpnDefinitionTest, UnitsPerBit_IsFromSpnSource)
{
	m_spnEntry.set_scaling(Any::UnitsPerBit());
	auto const spnDefinition = CreateDefinition();
	EXPECT_THAT(spnDefinition.UnitsPerBit(), Eq(Any::UnitsPerBit()));
}
TEST_F(SpnDefinitionTest, ValueOffset_IsFromSpnSource)
{
	m_spnEntry.set_offset(Any::ValueOffset());
	auto const spnDefinition = CreateDefinition();
	EXPECT_THAT(spnDefinition.ValueOffset(), Eq(Any::ValueOffset()));
}
TEST_F(SpnDefinitionTest, Units_AreFromSpnSource)
{
	m_spnEntry.set_unit(Any::Units());
	auto const spnDefinition = CreateDefinition();
	EXPECT_THAT(spnDefinition.Units(), Eq(Any::Units()));
}
TEST_F(SpnDefinitionTest, IsDouble_IsTrueWhenDouble)
{
	m_spnEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_DOUBLE);
	auto const spnDefinition = CreateDefinition();
	EXPECT_TRUE(spnDefinition.IsDouble());
}
TEST_F(SpnDefinitionTest, IsDouble_IsFalseWhenNotDouble)
{
	m_spnEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED);
	auto const spnDefinition = CreateDefinition();
	EXPECT_FALSE(spnDefinition.IsDouble());
}
TEST_F(SpnDefinitionTest, IsUint_IsTrueWhenUint)
{
	m_spnEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED);
	auto const spnDefinition = CreateDefinition();
	EXPECT_TRUE(spnDefinition.IsUint());
}
TEST_F(SpnDefinitionTest, IsUint_IsFalseWhenNotUint)
{
	m_spnEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_DOUBLE);
	auto const spnDefinition = CreateDefinition();
	EXPECT_FALSE(spnDefinition.IsUint());
}
TEST_F(SpnDefinitionTest, SpnDefinitionsContainingTheSameSpnEntryAddressesAreEqual)
{
	cat::shark::SpnEntry spnEntry{};
	SpnDefinition spnDefinition{spnEntry};
	EXPECT_TRUE(spnDefinition == spnDefinition);
}
TEST_F(SpnDefinitionTest, SpnDefinitionsContainingDifferentSpnEntryAddressesAreNotEqual)
{
	cat::shark::SpnEntry spnEntry1{};
	cat::shark::SpnEntry spnEntry2{};
	SpnDefinition spnDefinition1{spnEntry1};
	SpnDefinition spnDefinition2{spnEntry2};
	EXPECT_FALSE(spnDefinition1 == spnDefinition2);
}
}
}