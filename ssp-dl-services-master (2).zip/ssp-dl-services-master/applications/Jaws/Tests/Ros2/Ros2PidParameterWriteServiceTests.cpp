/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Unit tests for Ros2PidParameterWriteService

#include "Ros2/Ros2PidParameterWriteService.cpp"

#include "Identifiers/MockIPidValueDecoder.h"
#include "Identifiers/MockIPidValueEncoder.h"
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Utilities/DataEngineMock.h>
#include <Utilities/TestUtilities.h>
#include "Utilities/DefaultSmartPointers.h"
#include <rtest/test_clock.hpp>

using namespace testing;
using WriteParameter = data_link_engine_interfaces::srv::WriteParameter;
using ParameterValue = data_link_engine_interfaces::msg::ParameterValue;
using ParameterServiceResult = data_link_engine_interfaces::msg::ParameterServiceResult;

namespace Jaws
{
namespace Ros2
{
namespace
{
class MockIResponseSender : public IResponseSender<WriteParameter>
{
	EnsureMockKindIsSpecified(MockIResponseSender);
public:
	MOCK_METHOD(std::string, ServiceName, (), (const override));
	MOCK_METHOD(void, SendResponse,
		(std::shared_ptr<rmw_request_id_t> const& spRequestHeader,
		 std::shared_ptr<WriteParameter::Response> const& spResponse),
		(override));
};

struct Any
{
	static constexpr char const* SharkByteId() { return "Vehicle.Speed"; }
	static constexpr double DoubleValue()      { return 42.5; }
	static constexpr uint64_t Uint64Value()    { return 100u; }
	static std::vector<uint8_t> BinaryValue()  { return {0xAA, 0xBB}; }
	static Shark::SharkByteValue ValidSharkByteValue() { return {{0x10, 0x20}}; }

	static Identifiers::DecodedPidValue GoodDecodedValue(double v = DoubleValue())
	{
		Identifiers::DecodedPidValue decoded{};
		decoded.quality = Identifiers::DecodedPidQuality::Good;
		decoded.value = v;
		return decoded;
	}
	static Identifiers::DecodedPidValue BadDecodedValue()
	{
		Identifiers::DecodedPidValue decoded{};
		decoded.quality = Identifiers::DecodedPidQuality::Bad;
		return decoded;
	}
};

WriteParameter::Request MakeDoubleRequest(double value)
{
	WriteParameter::Request request{};
	request.value.type = ParameterValue::TYPE_DOUBLE;
	request.value.double_value = value;
	return request;
}
WriteParameter::Request MakeUint64Request(uint64_t value)
{
	WriteParameter::Request request{};
	request.value.type = ParameterValue::TYPE_UINT64;
	request.value.uint64_value = value;
	return request;
}
WriteParameter::Request MakeBinaryRequest(std::vector<uint8_t> const& value)
{
	WriteParameter::Request request{};
	request.value.type = ParameterValue::TYPE_BINARY;
	request.value.binary_value = value;
	return request;
}
WriteParameter::Request MakeAnyRequest()
{
	return MakeUint64Request(Any::Uint64Value());
}

auto ResponseWithStatus(uint8_t status)
{
	return Pointee(
		Field(&WriteParameter::Response::result,
			Field(&ParameterServiceResult::status, Eq(status))));
}
auto ResponseWithStatusAndReason(uint8_t status, uint8_t reason)
{
	return Pointee(
		Field(&WriteParameter::Response::result,
			AllOf(
				Field(&ParameterServiceResult::status, Eq(status)),
				Field(&ParameterServiceResult::reason, Eq(reason)))));
}

// Node creation is expensive (~12 ms) so only create it once.
// use_sim_time=true is required by rtest::TestClock for timestamp tests.
std::shared_ptr<rclcpp::Node> n_spNode{};
}

class Ros2PidParameterWriteServiceTest : public Test
{
protected:
	struct Default
	{
		static constexpr char const* SharkByteId() { return Any::SharkByteId(); }
		static constexpr std::vector<uint8_t> EncodedBytes() { return {0x01, 0x02}; }
		static constexpr Identifiers::DecodedPidValue GoodDecodedValue() { return Any::GoodDecodedValue(); }
	};

	static void SetUpTestSuite()
	{
		assert(!n_spNode);

		// use_sim_time=true is required by rtest::TestClock for timestamp tests.
		rclcpp::NodeOptions options{};
		options.parameter_overrides({rclcpp::Parameter("use_sim_time", true)});
		n_spNode = std::make_shared<rclcpp::Node>("test_node", options);
	}
	static void TearDownTestSuite()
	{
		assert(n_spNode);
		n_spNode.reset();
	}

	Ros2PidParameterWriteServiceTest()
		: m_writeService{
			*n_spNode,
			Default::SharkByteId(),
			m_pidDefinition,
			m_mockEncoder,
			m_mockDecoder}
	{
		ON_CALL(m_mockRetriever, Retrieve(Default::SharkByteId()))
			.WillByDefault(ReturnRef(m_mockWriteSharkByte));

		m_writeService.SetDependency(m_spMockResponseSender.TakeUniquePtr());
	}

	void Initialize()
	{
		m_writeService.Initialize(m_mockRetriever);
	}

	cat::shark::PidEntry m_pidEntry{};
	Identifiers::PidDefinition m_pidDefinition{m_pidEntry};
	NiceMock<Identifiers::MockIPidValueEncoder> m_mockEncoder{};
	NiceMock<Identifiers::MockIPidValueDecoder> m_mockDecoder{};
	Utilities::DefaultTestUniquePtr<NiceMock<MockIResponseSender>> m_spMockResponseSender{};
	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockWriteSharkByte{};

	Ros2PidParameterWriteService m_writeService;
};
TEST_F(Ros2PidParameterWriteServiceTest, Initialize_RetrievesWriteSharkByte)
{
	EXPECT_CALL(m_mockRetriever, Retrieve(Default::SharkByteId()));
	Initialize();
}

class Ros2PidParameterWriteService_InitializedTest : public Ros2PidParameterWriteServiceTest
{
protected:
	Ros2PidParameterWriteService_InitializedTest()
	{
		Initialize();

		ON_CALL(m_mockEncoder, Encode(_, _))
			.WillByDefault(Return(Default::EncodedBytes()));
		ON_CALL(m_mockDecoder, Decode(_, _))
			.WillByDefault(Return(Default::GoodDecodedValue()));
		ON_CALL(m_mockWriteSharkByte, Write(_, _))
			.WillByDefault(SaveArg<1>(&m_actualCallback));
		ON_CALL(*m_spMockResponseSender, SendResponse(_, _))
			.WillByDefault(SaveArg<1>(&m_spActualResponse));
	}
	void CallWrite(WriteParameter::Request const& request = MakeAnyRequest())
	{
		m_writeService.Write(m_spRequestHeader, request);
	}
	void SimulateWriteCompletion()
	{
		ASSERT_THAT(m_actualCallback, NotNull());
		m_actualCallback(m_sharkByteValue);
	}

	std::shared_ptr<rmw_request_id_t> m_spRequestHeader{std::make_shared<rmw_request_id_t>()};
	Shark::IWriteSharkByte::CompletedCallback m_actualCallback{};
	std::shared_ptr<WriteParameter::Response> m_spActualResponse{};
	Shark::SharkByteValue m_sharkByteValue{};
};
TEST_F(Ros2PidParameterWriteService_InitializedTest, Write_WithDoubleValue_EncodesDoubleIntoSharkByte)
{
	auto const expectedValue = Any::DoubleValue();
	EXPECT_CALL(m_mockEncoder,
		Encode(m_pidDefinition, VariantWith<double>(DoubleEq(expectedValue))));
	CallWrite(MakeDoubleRequest(expectedValue));
}
TEST_F(Ros2PidParameterWriteService_InitializedTest, Write_WithUint64Value_EncodesUint64IntoSharkByte)
{
	auto const expectedValue = Any::Uint64Value();
	EXPECT_CALL(m_mockEncoder,
		Encode(m_pidDefinition, VariantWith<uint64_t>(Eq(expectedValue))));
	CallWrite(MakeUint64Request(expectedValue));
}
TEST_F(Ros2PidParameterWriteService_InitializedTest, Write_WithBinaryValue_EncodesBinaryIntoSharkByte)
{
	auto const expectedValue = Any::BinaryValue();
	EXPECT_CALL(m_mockEncoder,
		Encode(m_pidDefinition, VariantWith<std::vector<uint8_t>>(ElementsAreArray(expectedValue))));
	CallWrite(MakeBinaryRequest(expectedValue));
}
TEST_F(Ros2PidParameterWriteService_InitializedTest, Write_CallsWriteOnSharkByteWithEncodedBytes)
{
	EXPECT_CALL(m_mockWriteSharkByte, Write(ElementsAreArray(Default::EncodedBytes()), _));
	CallWrite();
}
TEST_F(Ros2PidParameterWriteService_InitializedTest, Write_WhenEncodingFails_SendsFailureResponseWithProtocolErrorReason)
{
	ON_CALL(m_mockEncoder, Encode(_, _))
		.WillByDefault(Return(std::unexpected{Identifiers::EncodedPidStatus::BadType}));
	EXPECT_CALL(*m_spMockResponseSender, SendResponse(_,
		ResponseWithStatusAndReason(ParameterServiceResult::STATUS_FAILURE, ParameterServiceResult::REASON_PROTOCOL_ERROR)));
	CallWrite();
}
TEST_F(Ros2PidParameterWriteService_InitializedTest, Write_WhenAlreadyActive_SendsFailureResponseWithBusyReason)
{
	CallWrite(); // First write — becomes active
	EXPECT_CALL(*m_spMockResponseSender, SendResponse(_,
		ResponseWithStatusAndReason(ParameterServiceResult::STATUS_FAILURE, ParameterServiceResult::REASON_BUSY)));
	CallWrite(); // Second write while first is still active
}
TEST_F(Ros2PidParameterWriteService_InitializedTest, Write_WhenAlreadyActive_DoesNotCallWriteOnSharkByteAgain)
{
	CallWrite();
	EXPECT_CALL(m_mockWriteSharkByte, Write(_, _)).Times(0);
	CallWrite();
}

class Ros2PidParameterWriteService_InitializedAndWritingTest : public Ros2PidParameterWriteService_InitializedTest
{
protected:
	Ros2PidParameterWriteService_InitializedAndWritingTest()
	{
		CallWrite();
	}
};
TEST_F(Ros2PidParameterWriteService_InitializedAndWritingTest, OnWriteCompleted_SendsResponseWithOriginalRequestHeader)
{
	// First write already started
	auto const spExpectedHeader = m_spRequestHeader;
	m_spRequestHeader = std::make_shared<rmw_request_id_t>(); // New request header for second write
	CallWrite(); // Second write should be rejected
	EXPECT_CALL(*m_spMockResponseSender, SendResponse(spExpectedHeader, _));
	SimulateWriteCompletion();
}
TEST_F(Ros2PidParameterWriteService_InitializedAndWritingTest, OnWriteCompleted_DecodesTheWriteCompletionValue)
{
	EXPECT_CALL(m_mockDecoder, Decode(m_pidDefinition, m_sharkByteValue));
	SimulateWriteCompletion();
}
TEST_F(Ros2PidParameterWriteService_InitializedAndWritingTest, OnWriteCompleted_SendsResponseWithSuccessForGoodValue)
{
	EXPECT_CALL(*m_spMockResponseSender, SendResponse(_, ResponseWithStatus(ParameterServiceResult::STATUS_SUCCESS)));
	SimulateWriteCompletion();
}
TEST_F(Ros2PidParameterWriteService_InitializedAndWritingTest, OnWriteCompleted_SendsResponseWithFailureForBadValue)
{
	ON_CALL(m_mockDecoder, Decode(_, _))
		.WillByDefault(Return(Any::BadDecodedValue()));
	EXPECT_CALL(*m_spMockResponseSender, SendResponse(_, ResponseWithStatus(ParameterServiceResult::STATUS_FAILURE)));
	SimulateWriteCompletion();
}
TEST_F(Ros2PidParameterWriteService_InitializedAndWritingTest, OnWriteCompleted_ResponseParameterContainsDecodedValue)
{
	constexpr auto anyDouble = 77.7;
	ON_CALL(m_mockDecoder, Decode(_, _))
		.WillByDefault(Return(Any::GoodDecodedValue(anyDouble)));

	SimulateWriteCompletion();

	ASSERT_THAT(m_spActualResponse, NotNull());
	auto const& value = m_spActualResponse->result.parameter.value;
	EXPECT_THAT(value.type, Eq(ParameterValue::TYPE_DOUBLE));
	EXPECT_THAT(value.double_value, DoubleEq(anyDouble));
}
TEST_F(Ros2PidParameterWriteService_InitializedAndWritingTest, OnWriteCompleted_ResponseParameterTimestampIsNodeNow)
{
	constexpr auto anyTimeMs = 123;
	rtest::TestClock clock{n_spNode};
	clock.advanceMs(anyTimeMs);

	SimulateWriteCompletion();

	ASSERT_THAT(m_spActualResponse, NotNull());
	auto const& stamp = m_spActualResponse->result.parameter.header.stamp;
	EXPECT_THAT(rclcpp::Time{stamp}.nanoseconds(), Eq(RCUTILS_MS_TO_NS(anyTimeMs)));
}
TEST_F(Ros2PidParameterWriteService_InitializedAndWritingTest, OnWriteCompleted_ClearsActiveRequest_AllowingNewWrite)
{
	SimulateWriteCompletion();
	// After completion, a new write should be accepted (not rejected as busy)
	EXPECT_CALL(m_mockWriteSharkByte, Write(_, _));
	CallWrite();
}
}
}