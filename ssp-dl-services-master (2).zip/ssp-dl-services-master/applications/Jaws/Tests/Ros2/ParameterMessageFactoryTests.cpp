/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Unit tests for ParameterMessageFactory

#include "Ros2/ParameterMessageFactory.cpp"
#include <gmock/gmock.h>

using namespace testing;

namespace Jaws
{
namespace Ros2
{
namespace
{
using Parameter = data_link_engine_interfaces::msg::Parameter;
using ParameterValue = data_link_engine_interfaces::msg::ParameterValue;

struct Any
{
	static constexpr double DoubleValue()     { return 3.14; }
	static constexpr uint64_t UintValue()     { return 12345u; }
	static std::vector<uint8_t> BinaryValue() { return {0x01, 0x02, 0x03}; }
};
}

class MakeParameterMessageTest : public ::testing::Test
{
protected:
	struct Default
	{
		static constexpr uint32_t Unit() { return 42u; }
	};

	Identifiers::DecodedPidValue MakeDecodedWithQuality(
		Identifiers::DecodedPidQuality quality)
	{
		Identifiers::DecodedPidValue decoded{};
		decoded.quality = quality;
		decoded.value = Any::DoubleValue();
		return decoded;
	}

	template <typename T>
	Identifiers::DecodedPidValue MakeDecodedWithValue(T const& value)
	{
		Identifiers::DecodedPidValue decoded{};
		decoded.quality = Identifiers::DecodedPidQuality::Good;
		decoded.value = value;
		return decoded;
	}
	Parameter CallMakeParameterMessage(Identifiers::DecodedPidValue const& decoded)
	{
		return MakeParameterMessage(decoded, Default::Unit());
	}
};
TEST_F(MakeParameterMessageTest, UnitIsSetOnMessage)
{
	auto const message = CallMakeParameterMessage(MakeDecodedWithQuality(Identifiers::DecodedPidQuality::Good));
	EXPECT_THAT(message.unit, Eq(Default::Unit()));
}

TEST_F(MakeParameterMessageTest, WhenQualityIsGood_QualityIsSetToGood)
{
	auto const message = CallMakeParameterMessage(MakeDecodedWithQuality(Identifiers::DecodedPidQuality::Good));
	EXPECT_THAT(message.quality, Eq(Parameter::QUALITY_GOOD));
}
TEST_F(MakeParameterMessageTest, WhenQualityIsBad_QualityIsSetToBad)
{
	auto const message = CallMakeParameterMessage(MakeDecodedWithQuality(Identifiers::DecodedPidQuality::Bad));
	EXPECT_THAT(message.quality, Eq(Parameter::QUALITY_BAD));
}
TEST_F(MakeParameterMessageTest, WhenQualityIsNotReceived_QualityIsSetToNotReceived)
{
	auto const message = CallMakeParameterMessage(MakeDecodedWithQuality(Identifiers::DecodedPidQuality::NotReceived));
	EXPECT_THAT(message.quality, Eq(Parameter::QUALITY_NOT_RECEIVED));
}
TEST_F(MakeParameterMessageTest, WhenQualityIsGoodAndValueIsDouble_ValueTypeIsDoubleAndValueIsSet)
{
	auto const message = CallMakeParameterMessage(MakeDecodedWithValue(Any::DoubleValue()));
	EXPECT_THAT(message.value.type, Eq(ParameterValue::TYPE_DOUBLE));
	EXPECT_THAT(message.value.double_value, DoubleEq(Any::DoubleValue()));
}
TEST_F(MakeParameterMessageTest, WhenQualityIsGoodAndValueIsUint64_ValueTypeIsUint64AndValueIsSet)
{
	auto const message = CallMakeParameterMessage(MakeDecodedWithValue(Any::UintValue()));
	EXPECT_THAT(message.value.type, Eq(ParameterValue::TYPE_UINT64));
	EXPECT_THAT(message.value.uint64_value, Eq(Any::UintValue()));
}
TEST_F(MakeParameterMessageTest, WhenQualityIsGoodAndValueIsBinary_ValueTypeIsBinaryAndValueIsSet)
{
	auto const message = CallMakeParameterMessage(MakeDecodedWithValue(Any::BinaryValue()));
	EXPECT_THAT(message.value.type, Eq(ParameterValue::TYPE_BINARY));
	EXPECT_THAT(message.value.binary_value, ElementsAreArray(Any::BinaryValue()));
}
TEST_F(MakeParameterMessageTest, WhenQualityIsGoodAndValueIsMonostate_ValueTypeIsUnspecified)
{
	auto const message = CallMakeParameterMessage(MakeDecodedWithValue(std::monostate{}));
	EXPECT_THAT(message.value.type, Eq(ParameterValue::TYPE_UNSPECIFIED));
}
TEST_F(MakeParameterMessageTest, WhenQualityIsNotGood_ValueIsNotPopulated)
{
	for (auto badQuality : {Identifiers::DecodedPidQuality::Bad, Identifiers::DecodedPidQuality::NotReceived})
	{
		auto const message = CallMakeParameterMessage(MakeDecodedWithQuality(badQuality));
		EXPECT_THAT(message.value.type, Eq(ParameterValue::TYPE_UNSPECIFIED));
	}
}
}
}
