/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Unit tests for Ros2PidParameterDataPublisher

#include "Ros2/Ros2PidParameterDataPublisher.cpp"
#include "Identifiers/MockIPidValueDecoder.h"
#include <Shark/Mocks/MockISharkByte.h>
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <rtest/publisher_mock.hpp>
#include <gmock/gmock.h>

using namespace testing;
using Parameter = data_link_engine_interfaces::msg::Parameter;
using ParameterValue = data_link_engine_interfaces::msg::ParameterValue;

namespace Jaws
{
namespace Ros2
{
namespace
{
struct Any
{
	static constexpr char const* NodeName()    { return "test_node"; }
	static constexpr char const* SharkByteId() { return "Vehicle.Speed"; }
	static constexpr double DecodedDouble()    { return 42.5; }
	static constexpr cat::shark::Unit Unit()   { return cat::shark::UNIT_RPM; }

	static constexpr Shark::SharkByteValue ValidSharkByteValue() { return {{0x10, 0x20}}; }
};

Identifiers::DecodedPidValue MakeGoodDoubleDecoded(double value = Any::DecodedDouble())
{
	Identifiers::DecodedPidValue decoded{};
	decoded.quality = Identifiers::DecodedPidQuality::Good;
	decoded.value = value;
	return decoded;
}
}

using Ros2PidParameterDataPublisher_SanitizeForTopicTest = Test;
TEST_F(Ros2PidParameterDataPublisher_SanitizeForTopicTest, InvalidTopicChars_AreReplacedWithUnderscores)
{
	EXPECT_THAT(SanitizeForTopic("a.b-c"), StrEq("a_b_c"));
}
TEST_F(Ros2PidParameterDataPublisher_SanitizeForTopicTest, LeadingDigit_IsPrefixedWithP)
{
	EXPECT_THAT(SanitizeForTopic("1Speed"), StrEq("p1Speed"));
}
TEST_F(Ros2PidParameterDataPublisher_SanitizeForTopicTest, LeadingUnderscore_IsPrefixedWithP)
{
	for (auto const pTopicName : {"_Speed", ".Speed"})
	{
		std::string topic{pTopicName};
		EXPECT_THAT(SanitizeForTopic(topic), StrEq("p_Speed"));
	}
}
TEST_F(Ros2PidParameterDataPublisher_SanitizeForTopicTest, IdentifiersWithNoInvalidChars_AreUnchanged)
{
	for (auto const pTopicName : {"VehicleSpeed", ""})
	{
		std::string topic{pTopicName};
		EXPECT_THAT(SanitizeForTopic(topic), StrEq(topic));
	}
}

using Ros2PidParameterDataPublisher_TopicNameTest = Test;
TEST_F(Ros2PidParameterDataPublisher_TopicNameTest, SanitizesAndPrependsDataLinkEngineNamespace)
{
	EXPECT_THAT(TopicName("any.topic"), StrEq("/data_link_engine/any_topic"));
}

using Ros2PidParameterDataPublisher_CreatePublisherTest = Test;
TEST_F(Ros2PidParameterDataPublisher_CreatePublisherTest, CreatesPublisherWithSanitizedTopicName)
{
	rclcpp::Node node(Any::NodeName());
	auto publisher = CreatePublisher(Any::SharkByteId(), node);
	EXPECT_THAT(publisher->get_topic_name(), StrEq(TopicName(Any::SharkByteId())));
}
TEST_F(Ros2PidParameterDataPublisher_CreatePublisherTest, CreatesPublisherWithHistoryDepthOf1)
{
	rclcpp::Node node(Any::NodeName());
	auto publisher = CreatePublisher(Any::SharkByteId(), node);
	EXPECT_THAT(publisher->get_actual_qos().depth(), Eq(1));
}

class Ros2PidParameterDataPublisherTest : public Test
{
protected:
	struct Default
	{
		static constexpr char const* SharkByteId() { return Any::SharkByteId(); }
		static constexpr char const* TopicName()   { return "any_valid_topic"; }
		static constexpr rclcpp::QoS QoS()         { return rclcpp::QoS{10}; }
	};

	Ros2PidParameterDataPublisherTest()
		: m_spNode{std::make_shared<rclcpp::Node>(Any::NodeName())}
		, m_pidDefinition{m_pidEntry}
		, m_dataPublisher{
			*m_spNode,
			m_spNode->create_publisher<Parameter>(Default::TopicName(), Default::QoS()),
			Default::SharkByteId(),
			m_pidDefinition,
			m_mockDecoder}
	{

		m_pidEntry.set_unit(Any::Unit());
		ON_CALL(m_mockDecoder, Decode(_, _))
			.WillByDefault(Return(MakeGoodDoubleDecoded()));
		ON_CALL(m_mockRetriever, Retrieve(Default::SharkByteId()))
			.WillByDefault(ReturnRef(m_sharkByteWrapper.GetMock()));

		// We use EXPECT_CALL here to avoid the "uninteresting mock function call" warnings that
		// would occur in tests that don't set publish expectations. There is no way to tell rtest
		// to utilize NiceMock for its mocks, unfortunately.
		m_spMockPublisher = FindPublisherMock();
		EXPECT_CALL(*m_spMockPublisher, publish(_))
			.Times(AnyNumber())
			.WillRepeatedly(SaveArg<0>(&m_actualMessage));
	}
	std::shared_ptr<rtest::PublisherMock<Parameter>> FindPublisherMock() const
	{
		return rtest::findPublisher<Parameter>(m_spNode, Default::TopicName());
	}

	rclcpp::Node::SharedPtr m_spNode;
	cat::shark::PidEntry m_pidEntry{};
	Identifiers::PidDefinition m_pidDefinition;
	NiceMock<Identifiers::MockIPidValueDecoder> m_mockDecoder;
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockRetriever;
	Shark::Mocks::MockSharkByteWrapper m_sharkByteWrapper{};
	std::shared_ptr<rtest::PublisherMock<Parameter>> m_spMockPublisher{};
	Parameter m_actualMessage{};

	Ros2PidParameterDataPublisher m_dataPublisher;
};
TEST_F(Ros2PidParameterDataPublisherTest, Initialize_RetrievesSharkByte)
{
	EXPECT_CALL(m_mockRetriever, Retrieve(Default::SharkByteId()))
		.WillOnce(ReturnRef(m_sharkByteWrapper.GetMock()));
	m_dataPublisher.Initialize(m_mockRetriever);
}
TEST_F(Ros2PidParameterDataPublisherTest, Initialize_PublishesInitialValueOnTopic)
{
	EXPECT_CALL(*m_spMockPublisher, publish(_));
	m_dataPublisher.Initialize(m_mockRetriever);
}
TEST_F(Ros2PidParameterDataPublisherTest, Initialize_DecoderIsCalledWithPidDefinitionAndSharkByteValue)
{
	auto const expectedValue = Any::ValidSharkByteValue();
	m_sharkByteWrapper.SetValue(expectedValue);
	EXPECT_CALL(m_mockDecoder, Decode(m_pidDefinition, expectedValue));
	m_dataPublisher.Initialize(m_mockRetriever);
}
TEST_F(Ros2PidParameterDataPublisherTest, Initialize_MessageContainsTheDecodedValue)
{
	constexpr double anyDouble = 123.45; // Arbitrary choice of double type
	ON_CALL(m_mockDecoder, Decode(_, _))
		.WillByDefault(Return(MakeGoodDoubleDecoded(anyDouble)));

	m_dataPublisher.Initialize(m_mockRetriever);

	EXPECT_THAT(m_actualMessage.value.type, Eq(ParameterValue::TYPE_DOUBLE));
	EXPECT_THAT(m_actualMessage.value.double_value, DoubleEq(anyDouble));
}
TEST_F(Ros2PidParameterDataPublisherTest, Initialize_MessageUnitIsFromPidDefinition)
{
	m_dataPublisher.Initialize(m_mockRetriever);
	EXPECT_THAT(m_actualMessage.unit, Eq(m_pidEntry.unit()));
}

class Ros2PidParameterDataPublisher_InitializedTest : public Ros2PidParameterDataPublisherTest
{
protected:
	Ros2PidParameterDataPublisher_InitializedTest()
	{
		m_dataPublisher.Initialize(m_mockRetriever);
		m_actualMessage = Parameter{}; // Reset the message to ensure we're checking the updated value
	}
};
TEST_F(Ros2PidParameterDataPublisher_InitializedTest, WhenSharkByteValueChanges_DecoderIsCalledWithPidDefinitionAndSharkByteValue)
{
	auto const expectedValue = Any::ValidSharkByteValue();
	EXPECT_CALL(m_mockDecoder, Decode(m_pidDefinition, expectedValue));
	m_sharkByteWrapper.SetValue(expectedValue);
}
TEST_F(Ros2PidParameterDataPublisher_InitializedTest, WhenSharkByteValueChanges_MessageContainsTheDecodedValue)
{
	constexpr double anyDouble = 123.45; // Arbitrary choice of double type
	ON_CALL(m_mockDecoder, Decode(_, _))
		.WillByDefault(Return(MakeGoodDoubleDecoded(anyDouble)));
	m_sharkByteWrapper.SetValue(Any::ValidSharkByteValue());

	EXPECT_THAT(m_actualMessage.value.type, Eq(ParameterValue::TYPE_DOUBLE));
	EXPECT_THAT(m_actualMessage.value.double_value, DoubleEq(anyDouble));
}
TEST_F(Ros2PidParameterDataPublisher_InitializedTest, WhenSharkByteValueChanges_MessageUnitIsFromPidDefinition)
{
	m_sharkByteWrapper.SetValue(Any::ValidSharkByteValue());

	EXPECT_THAT(m_actualMessage.unit, Eq(m_pidEntry.unit()));
}
}
}
