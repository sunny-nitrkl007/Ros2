/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// JawsManager tests

#include "JawsManager.cpp"
#include "FakeDependencyContainer.h"
#include "Identifiers/MockIPidDefinitionRetriever.h"
#include "Identifiers/MockIPublicJ1939DefinitionRetriever.h"
#include "Nvm/MockINvmWrapper.h"
#include <Shark/Mocks/MockISharkByte.h>
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Utilities/TestUtilities.h>

using namespace testing;

namespace Shark
{
class MockIShark : public Shark::IShark
{
	EnsureMockKindIsSpecified(MockIShark);
public:
	MOCK_METHOD(char const*, Name, (), (override, const, noexcept));
	MOCK_METHOD(Shark::ISharkByteRetriever const&, GetSharkByteRetriever, (), (override, const));
	MOCK_METHOD(Shark::IWriteSharkByteRetriever const&, GetWriteSharkByteRetriever, (), (override, const));
};

std::unique_ptr<IShark> CreateShark(Utilities::IEnvironment const&, cat::shark::Config const&)
{
	return nullptr;
}
}

namespace Jaws
{
namespace
{
struct Any
{
	static constexpr char const* SharkByteId() { return "id"; }
	static constexpr char const* ConfigString() { return "config string"; }
};
}

class JawsManagerTest : public Test
{
protected:
	Utilities::DefaultTestUniquePtr<NiceMock<Shark::MockIShark>> m_spMockShark{};
	Utilities::DefaultTestUniquePtr<cat::shark::Config> m_spSharkConfig{};
	Utilities::DefaultTestUniquePtr<NiceMock<Nvm::MockINvmWrapper>> m_spMockNvmWrapper{};
	Utilities::DefaultTestUniquePtr<NiceMock<Identifiers::MockIPidDefinitionRetriever>> m_spMockPidDefinitionRetriever{};
	Utilities::DefaultTestUniquePtr<NiceMock<Identifiers::MockIPublicJ1939DefinitionRetriever>> m_spMockPublicJ1939DefinitionRetriever{};
	FakeDependencyContainer m_fakeDependencyContainer{};
	NiceMock<MockFunction<void()>> m_mockInitializer1{};
	NiceMock<MockFunction<void()>> m_mockInitializer2{};

	JawsManager m_jawsManager{
		m_spMockShark.TakeUniquePtr(),
		m_spSharkConfig.TakeUniquePtr(),
		m_spMockNvmWrapper.TakeUniquePtr(),
		m_spMockPidDefinitionRetriever.TakeUniquePtr(),
		nullptr, // The IPidValueDecoder is only passed in for lifetime. Not needed here.
		nullptr, // The IPidValueEncoder is only passed in for lifetime. Not needed here.
		m_spMockPublicJ1939DefinitionRetriever.TakeUniquePtr(),
		nullptr, // The IInitializationGate is only passed in for lifetime. Not needed here.
		m_fakeDependencyContainer.m_spDependencyContainer.TakeUniquePtr(),
		std::vector<std::function<void()>>{m_mockInitializer1.AsStdFunction(), m_mockInitializer2.AsStdFunction()}};
};

TEST_F(JawsManagerTest, Initialize_CallsAllConstructedInitializers)
{
	EXPECT_CALL(m_mockInitializer1, Call());
	EXPECT_CALL(m_mockInitializer2, Call());

	m_jawsManager.Initialize();
}
TEST_F(JawsManagerTest, Initialize_RestoresConfigInNvm)
{
	n_backupConfigString = Any::ConfigString();
	EXPECT_CALL(*m_spMockNvmWrapper, Write(Jaws::Nvm::JawsConfigurationNvmId(), Any::ConfigString()));

	m_jawsManager.Initialize();
}
}