/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Fake DependencyContainer

#pragma once

#include "DependencyContainer.h"
#include "Identifiers/MockIPidValueDecoder.h"
#include "Identifiers/MockIPidValueEncoder.h"
#include "Middleware/SharkToMiddlewareDefinitions.h"
#include "Nvm/MockINvmWrapper.h"
#include "Shark/Mocks/MockISharkByteRetriever.h"
#include "Shark/Mocks/MockIWriteSharkByteRetriever.h"
#include <Utilities/Mocks/MockIEnvironment.h>
#include <Utilities/Mocks/MockIFilesystem.h>
#include <Utilities/TestUtilities.h>

namespace Jaws
{
class FakeDependencyContainer
{
	template<typename T> using NiceMock = testing::NiceMock<T>;
public:
	FakeDependencyContainer();
	~FakeDependencyContainer();

	NiceMock<Nvm::MockINvmWrapper> m_mockNvmWrapper{};
	NiceMock<Utilities::Mocks::MockIEnvironment> m_mockEnvironment{};
	NiceMock<Utilities::Mocks::MockIFilesystem> m_mockFilesystem{};
	NiceMock<Identifiers::MockIPidValueDecoder> m_mockPidValueDecoder{};
	NiceMock<Identifiers::MockIPidValueEncoder> m_mockPidValueEncoder{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	Middleware::SharkToMiddlewareDefinitions m_sharkToMiddlewareDefinitions{};

	Utilities::TestUniquePtr<DependencyContainer> m_spDependencyContainer;
	DependencyContainer const& m_dependencyContainer;
};
}
