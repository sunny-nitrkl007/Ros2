/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// MachineSecuritySystemWrapper tests

#include "Middleware/MachineSecuritySystemWrapper.cpp"
#include "MockIWriteReply.h"
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockISharkByte.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Utilities/TestUtilities.h>

using namespace testing;

namespace Jaws
{
namespace Middleware
{
namespace
{
struct Any
{
static constexpr auto StringValue() { return "test"; }
static constexpr auto StringValueAsBytes() { return std::vector<uint8_t>(StringValue(), StringValue() + strlen(StringValue())); }
};

enum class MachineSecuritySystemCommand
{
	RequestCurrentOperator,
	LogIn,
	LogOut,
	Lock,
	Unlock
};
struct MachineSecuritySystemCommandData
{
	MachineSecuritySystemCommand command;
	char const* writeSharkByteId;
	char const* statusSharkByteId;
};
constexpr MachineSecuritySystemCommandData n_commandData[]
{
	{ MachineSecuritySystemCommand::RequestCurrentOperator, ::RequestCurrentOperator(), ::OperatorRequestStatus() },
	{ MachineSecuritySystemCommand::LogIn,                  ::LogIn(),                  ::LogInStatus() },
	{ MachineSecuritySystemCommand::LogOut,                 ::LogOut(),                 ::LogOutStatus() },
	{ MachineSecuritySystemCommand::Lock,                   ::Lock(),                   ::LockStatus() },
	{ MachineSecuritySystemCommand::Unlock,                 ::Unlock(),                 ::UnlockStatus() },
};
}

class MachineSecuritySystemWrapperTest : public TestWithParam<MachineSecuritySystemCommandData>
{
protected:
	MachineSecuritySystemWrapperTest()
	{
		auto&& param = GetParam();
		m_commandType = param.command;
		m_writeSharkByteName = param.writeSharkByteId;
		m_statusSharkByteName = param.statusSharkByteId;

		m_data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		m_data.mutable_value()->set_string_value(Any::StringValue());

		ON_CALL(m_mockSharkByteRetriever, Retrieve(_))
			.WillByDefault(ReturnRef(m_mockStatusSharkByte));
		ON_CALL(m_mockWriteSharkByteRetriever, Retrieve(_))
			.WillByDefault(ReturnRef(m_mockWriteSharkByte));
		ON_CALL(m_mockWriteSharkByte, Write(_, NotNull()))
			.WillByDefault(SaveArg<1>(&m_writeCallback));
	}
	std::optional<Data> CallCommand()
	{
		std::function<std::optional<Data>(Data const&, IWriteReply&)> commandFunction;
		switch (m_commandType)
		{
			case MachineSecuritySystemCommand::RequestCurrentOperator:
				commandFunction = [this](Data const& data, IWriteReply& writeReply) {
					return m_machineSecuritySystemWrapper.RequestCurrentOperator(data, writeReply);};
				break;
			case MachineSecuritySystemCommand::LogIn:
				commandFunction = [this](Data const& data, IWriteReply& writeReply) {
					return m_machineSecuritySystemWrapper.LogIn(data, writeReply);};
				break;
			case MachineSecuritySystemCommand::LogOut:
				commandFunction = [this](Data const& data, IWriteReply& writeReply) {
					return m_machineSecuritySystemWrapper.LogOut(data, writeReply);};
				break;
			case MachineSecuritySystemCommand::Lock:
				commandFunction = [this](Data const& data, IWriteReply& writeReply) {
					return m_machineSecuritySystemWrapper.Lock(data, writeReply);};
				break;
			case MachineSecuritySystemCommand::Unlock:
				commandFunction = [this](Data const& data, IWriteReply& writeReply) {
					return m_machineSecuritySystemWrapper.Unlock(data, writeReply);};
				break;
			default:
				assert(true);
		}
		return commandFunction(m_data, m_mockWriteReply);
	}

	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockISharkByte> m_mockStatusSharkByte{};
	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockWriteSharkByte{};
	NiceMock<MockIWriteReply> m_mockWriteReply{};
	std::function<void(Shark::SharkByteValue const&)> m_writeCallback;
	cat::middleware::parameter::Data m_data{};
	MachineSecuritySystemCommand m_commandType{};
	std::string m_writeSharkByteName{};
	std::string m_statusSharkByteName{};

	MachineSecuritySystemWrapper m_machineSecuritySystemWrapper{
		m_mockSharkByteRetriever,
		m_mockWriteSharkByteRetriever};
};
INSTANTIATE_TEST_SUITE_P(MssCommandTests, MachineSecuritySystemWrapperTest, ValuesIn(n_commandData));
TEST_P(MachineSecuritySystemWrapperTest, Command_RetrievesWriteAndStatusSharkBytes)
{
	EXPECT_CALL(m_mockWriteSharkByteRetriever, Retrieve(m_writeSharkByteName));
	EXPECT_CALL(m_mockSharkByteRetriever, Retrieve(m_statusSharkByteName));

	CallCommand();
}
TEST_P(MachineSecuritySystemWrapperTest, Command_ReturnsEmptyOptional)
{
	EXPECT_THAT(CallCommand(), Eq(std::nullopt));
}
TEST_P(MachineSecuritySystemWrapperTest, Command_CallsWriteWithDataAndNonNullCallback)
{
	EXPECT_CALL(m_mockWriteSharkByte, Write(Any::StringValueAsBytes(), NotNull()));

	CallCommand();
}
TEST_P(MachineSecuritySystemWrapperTest, CommandWriteCallback_RetrievesStatusSharkByteValue)
{
	CallCommand();

	ASSERT_TRUE(m_writeCallback);
	EXPECT_CALL(m_mockStatusSharkByte, Value());

	m_writeCallback(std::nullopt);
}
TEST_P(MachineSecuritySystemWrapperTest, CommandWriteCallback_CallsReplyWithDataBasedOnStatusSharkByteValue)
{
	for (auto status : { true, false })
	{
		CallCommand();

		ASSERT_TRUE(m_writeCallback);
		ON_CALL(m_mockStatusSharkByte, Value())
			.WillByDefault(Return(status ? Shark::TrueSharkByteValue() : Shark::FalseSharkByteValue()));

		EXPECT_CALL(m_mockWriteReply, Reply(Utilities::ProtobufEquals(MakeBooleanData(status))));

		m_writeCallback(std::nullopt);
	}
}
TEST_P(MachineSecuritySystemWrapperTest, CommandWriteCallback_CallsReplyWithFalseDataWhenStatusSharkByteValueIsInvalid)
{
	CallCommand();

	ASSERT_TRUE(m_writeCallback);
	ON_CALL(m_mockStatusSharkByte, Value())
		.WillByDefault(Return(std::nullopt));

	EXPECT_CALL(m_mockWriteReply, Reply(Utilities::ProtobufEquals(MakeBooleanData(false))));

	m_writeCallback(std::nullopt);
}
}
}