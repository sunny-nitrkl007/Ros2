/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SharkParameterDataWriter tests

#include "Middleware/SharkParameterDataWriter.cpp"
#include "MockIService.h"
#include "MockIWriteReply.h"
#include <Utilities/TestUtilities.h>

using namespace testing;
using namespace middleware::parameter;

namespace Jaws
{
using namespace Identifiers;

namespace Middleware
{
namespace
{
struct Any
{
	static constexpr auto WriterId() { return "middleware_id"; }
	static constexpr uint_least16_t Key() { return 42; }
	static constexpr double Value() { return 66.0; }
};
}

class SharkParameterDataWriterTest : public Test
{
protected:
	SharkParameterDataWriterTest()
	{
		m_data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		m_data.mutable_value()->set_double_value(Any::Value());

		m_sharkParameterDataWriter.Initialize(m_mockParameterService);
	}
	std::optional<cat::middleware::parameter::Data> CallStaticOnWrite()
	{
		return m_sharkParameterDataWriter.OnWrite(Any::Key(), m_data);
	}

	NiceMock<MockFunction<OnWriteFunction>> m_mockFunction{};
	NiceMock<MockIService> m_mockParameterService{};
	NiceMock<MockIWriteReply> m_mockWriteReply{};
	SharkToMiddlewareWriter m_sharkToMiddlewareWriter
	{
		Any::WriterId(),
		m_mockFunction.AsStdFunction()
	};
	cat::middleware::parameter::Data m_data{};
	SharkParameterDataWriter m_sharkParameterDataWriter{m_sharkToMiddlewareWriter};
};
TEST_F(SharkParameterDataWriterTest, MakeBadData_CreatesDataWithBadQuality)
{
	auto badData = MakeBadData();
	EXPECT_EQ(badData.quality(), cat::middleware::parameter::Quality::QUALITY_BAD);
}
TEST_F(SharkParameterDataWriterTest, StaticOnWrite_CallsSharkToMiddlewareWriteFunction)
{
	EXPECT_CALL(m_mockFunction, Call(Utilities::ProtobufEquals(m_data), Ref(m_sharkParameterDataWriter)));
	CallStaticOnWrite();
}
TEST_F(SharkParameterDataWriterTest, StaticOnWrite_ReturnsValueFromSharkToMiddlewareWriteFunction)
{
	ON_CALL(m_mockFunction, Call(_, _))
		.WillByDefault(Return(m_data));

	auto actualReturnValue = CallStaticOnWrite();
	ASSERT_TRUE(actualReturnValue);
	EXPECT_THAT(*actualReturnValue, Utilities::ProtobufEquals(m_data));
}
TEST_F(SharkParameterDataWriterTest, StaticOnWrite_ReturnsBadDataIfAnotherWriteIsActive)
{
	CallStaticOnWrite();
	EXPECT_CALL(m_mockFunction, Call(_, _)).Times(0);
	auto actualReturnValue = CallStaticOnWrite();
	ASSERT_TRUE(actualReturnValue.has_value());
	EXPECT_THAT(*actualReturnValue, Utilities::ProtobufEquals(MakeBadData()));
}
TEST_F(SharkParameterDataWriterTest, Reply_CallsParameterServiceReplyWithKeyAndData)
{
	CallStaticOnWrite();
	EXPECT_CALL(m_mockParameterService, Reply(Any::Key(), Utilities::ProtobufEquals(m_data)));
	m_sharkParameterDataWriter.Reply(m_data);
}
TEST_F(SharkParameterDataWriterTest, Reply_AllowsAnotherWriteToExecute)
{
	CallStaticOnWrite();
	m_sharkParameterDataWriter.Reply(m_data);
	EXPECT_CALL(m_mockFunction, Call(_, _));
	CallStaticOnWrite();
}
}
}