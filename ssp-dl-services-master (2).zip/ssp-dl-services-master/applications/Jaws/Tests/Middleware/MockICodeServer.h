/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock ICodeServer

#pragma once

#include <ICodeServer.h>
#include <Utilities/DataEngineMock.h>

namespace middleware
{
namespace diagnostics
{
class MockICodeServer : public ICodeServer
{
	EnsureMockKindIsSpecified(MockICodeServer);

public:
	MOCK_METHOD(void, Reply, (uint_least16_t key, ::cat::middleware::diagnostics::AdditionalInformation const& data), (override));
	MOCK_METHOD(void, Publish, (::cat::middleware::diagnostics::Codes const& codes), (override));
};
}  // namespace diagnostics
}  // namespace middleware