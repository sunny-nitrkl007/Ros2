/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// MultiBytePidParameterDataWriter tests

#include "Middleware/MultiBytePidParameterDataWriter.cpp"
#include "MockIService.h"
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Utilities/TestUtilities.h>

using namespace testing;
using namespace middleware::parameter;

namespace Jaws
{
using namespace Identifiers;

namespace Middleware
{
namespace
{
struct Any
{
	static constexpr uint_least16_t AnotherKey() { return 99; }
	static constexpr std::vector<uint8_t> ValidData() { return {0x40, 0x41}; }
	static constexpr std::string ValidStringData() { return "@A"; }
};
}

class MultiBytePidParameterDataWriterTest : public Test
{
protected:
	struct Default
	{
		static constexpr char const* WriteId() { return "write id"; }
		static constexpr uint_least16_t Key() { return 42; }
		static constexpr unsigned MinimumLength() { return 2; }
		static constexpr unsigned MaximumLength() { return 4; }
		static constexpr cat::shark::MultiBytePidEntry::MultiBytePidDataType DataType() { return cat::shark::MultiBytePidEntry::MULTI_BYTE_PID_DATA_TYPE_BINARY; }
	};

	MultiBytePidParameterDataWriterTest()
	{
		ON_CALL(m_mockWriteSharkByteRetriever, Retrieve(Default::WriteId()))
			.WillByDefault(ReturnRef(m_mockWriteSharkByte));
		ON_CALL(m_mockWriteSharkByte, Write(_, _))
			.WillByDefault(Invoke([this](std::vector<uint8_t> const& writeData, std::function<void(Shark::SharkByteValue const&)> callback)
				{
					m_writeData.emplace(writeData);
					m_writeCallback = std::move(callback);
				}));
	}

	void CreateAndInitialize()
	{
		PopulatePidEntry();
		m_spPidParameterDataWriter = std::make_unique<MultiBytePidParameterDataWriter>(Default::WriteId(), Identifiers::MultiBytePidDefinition{m_pidEntry});
		m_spPidParameterDataWriter->Initialize(m_mockWriteSharkByteRetriever, m_mockService);
	}
	void PopulatePidEntry()
	{
		m_pidEntry.set_pid(0xF99C);
		m_pidEntry.set_minimum_length(Default::MinimumLength());
		m_pidEntry.set_maximum_length(Default::MaximumLength());
		m_pidEntry.set_multi_byte_pid_data_type(m_dataType);
	}
	Data MakeBinaryData(std::vector<uint8_t> const& value) const
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_binary_value(value.data(), value.size());
		return data;
	}
	Data MakeStringData(std::string const& value) const
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_string_value(value);
		return data;
	}
	std::optional<Data> CallBinaryWrite(std::vector<uint8_t> const& value = Any::ValidData())
	{
		return m_spPidParameterDataWriter->OnWrite(Default::Key(), Default::WriteId(), MakeBinaryData(value));
	}
	std::optional<Data> CallStringWrite(std::string const& value = Any::ValidStringData())
	{
		return m_spPidParameterDataWriter->OnWrite(Default::Key(), Default::WriteId(), MakeStringData(value));
	}
	std::optional<Data> CallWriteWithInvalidData()
	{
		return m_spPidParameterDataWriter->OnWrite(Default::Key(), Default::WriteId(), Data{});
	}

	NiceMock<MockIService> m_mockService{};
	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockWriteSharkByte{};
	std::function<void(Shark::SharkByteValue const&)> m_writeCallback;
	std::optional<std::vector<uint8_t>> m_writeData{};

	cat::shark::MultiBytePidEntry::MultiBytePidDataType m_dataType{Default::DataType()};
	cat::shark::MultiBytePidEntry m_pidEntry{};
	std::unique_ptr<MultiBytePidParameterDataWriter> m_spPidParameterDataWriter{};
};
TEST_F(MultiBytePidParameterDataWriterTest, Initialize_RetrievesWriteSharkByteFromRetrieverWithTheCorrectId)
{
	EXPECT_CALL(m_mockWriteSharkByteRetriever, Retrieve(Default::WriteId()));
	CreateAndInitialize();
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWrite_CallsWriteOnTheWriteSharkByte)
{
	CreateAndInitialize();
	EXPECT_CALL(m_mockWriteSharkByte, Write(_, _));
	CallBinaryWrite();
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWrite_ReturnsNulloptToInitiateAsyncMode)
{
	CreateAndInitialize();
	auto const result = CallBinaryWrite();
	EXPECT_THAT(result, Eq(std::nullopt));
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWrite_ReturnsDataWithBadQualityIfDataIsInvalid)
{
	CreateAndInitialize();
	auto const result = CallWriteWithInvalidData();
	ASSERT_TRUE(result);
	EXPECT_THAT(result->quality(), Eq(cat::middleware::parameter::Quality::QUALITY_BAD));
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWrite_ReturnsDataWithBadQualityIfThereIsAlreadyAnActiveWrite)
{
	CreateAndInitialize();
	CallBinaryWrite();
	auto const result = CallBinaryWrite();
	ASSERT_TRUE(result);
	EXPECT_THAT(result->quality(), Eq(cat::middleware::parameter::Quality::QUALITY_BAD));
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWrite_ReturnsDataWithBadQualityIfStringDataIsLongerThanMaximumLength)
{
	m_dataType = cat::shark::MultiBytePidEntry::MULTI_BYTE_PID_DATA_TYPE_STRING;
	CreateAndInitialize();
	auto const result = CallStringWrite("TooLong");
	ASSERT_TRUE(result);
	EXPECT_THAT(result->quality(), Eq(cat::middleware::parameter::Quality::QUALITY_BAD));
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWrite_ReturnsDataWithBadQualityIfStringDataIsShorterThanMinimumLength)
{
	m_dataType = cat::shark::MultiBytePidEntry::MULTI_BYTE_PID_DATA_TYPE_STRING;
	CreateAndInitialize();
	auto const result = CallStringWrite("T");
	ASSERT_TRUE(result);
	EXPECT_THAT(result->quality(), Eq(cat::middleware::parameter::Quality::QUALITY_BAD));
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWrite_ReturnsDataWithBadQualityIfBinaryDataIsLongerThanMaximumLength)
{
	m_dataType = cat::shark::MultiBytePidEntry::MULTI_BYTE_PID_DATA_TYPE_BINARY;
	CreateAndInitialize();
	auto const result = CallBinaryWrite(std::vector<uint8_t>{0x00, 0x01, 0x02, 0x03, 0x04});
	ASSERT_TRUE(result);
	EXPECT_THAT(result->quality(), Eq(cat::middleware::parameter::Quality::QUALITY_BAD));
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWrite_ReturnsDataWithBadQualityIfBinaryDataIsShorterThanMinimumLength)
{
	m_dataType = cat::shark::MultiBytePidEntry::MULTI_BYTE_PID_DATA_TYPE_BINARY;
	CreateAndInitialize();
	auto const result = CallBinaryWrite(std::vector<uint8_t>{0x00});
	ASSERT_TRUE(result);
	EXPECT_THAT(result->quality(), Eq(cat::middleware::parameter::Quality::QUALITY_BAD));
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWriteCompleted_RepliesWithTheWriteKey)
{
	CreateAndInitialize();
	CallBinaryWrite();
	EXPECT_CALL(m_mockService, Reply(Default::Key(), _));
	m_writeCallback(Any::ValidData());
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWriteCompleted_RepliesWithBinaryValueWhenDataTypeIsBinary)
{
	auto const sharkByteData = Any::ValidData();
	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedData.mutable_value()->set_binary_value(sharkByteData.data(), sharkByteData.size());

	CreateAndInitialize();
	CallBinaryWrite();
	EXPECT_CALL(m_mockService, Reply(_, Utilities::ProtobufEquals(expectedData)));

	m_writeCallback(sharkByteData);
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWriteCompleted_RepliesWithStringValueWhenDatatypeIsString)
{
	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedData.mutable_value()->set_string_value(Any::ValidStringData());

	m_dataType = cat::shark::MultiBytePidEntry::MULTI_BYTE_PID_DATA_TYPE_STRING;
	CreateAndInitialize();
	CallStringWrite(Any::ValidStringData());
	EXPECT_CALL(m_mockService, Reply(_, Utilities::ProtobufEquals(expectedData)));

	m_writeCallback(Any::ValidData());
}
TEST_F(MultiBytePidParameterDataWriterTest, OnWriteCompleted_Invalid_RepliesWithBadQuality)
{
	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_BAD);

	CreateAndInitialize();
	CallBinaryWrite();
	EXPECT_CALL(m_mockService, Reply(_, Utilities::ProtobufEquals(expectedData)));

	m_writeCallback(std::nullopt);
}
}
}