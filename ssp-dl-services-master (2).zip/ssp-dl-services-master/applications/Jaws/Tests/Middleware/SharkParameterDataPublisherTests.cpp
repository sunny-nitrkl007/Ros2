/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SharkParameterDataPublisher tests

#include "Middleware/SharkParameterDataPublisher.cpp"
#include "MockIPublish.h"
#include "MockIService.h"
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockISharkByte.h>
#include <Utilities/TestUtilities.h>

using namespace testing;
using namespace middleware::parameter;

namespace Jaws
{
using namespace Identifiers;

namespace Middleware
{
namespace
{
struct Any
{
	static constexpr char const* PublishId()                              { return "middleware_id"; }
	static constexpr char const* SharkByteId()                            { return "shark_byte_id"; }
	static constexpr cat::shark::Unit Unit()                              { return cat::shark::UNIT_CYCLE; }
	static constexpr Identifiers::MiddlewareDataType MiddlewareDataType() { return Identifiers::Double; }
	static std::vector<uint8_t> ValidData()                               { return {0x42}; }
	static constexpr double DoubleValue()                                 { return 66.0; }
};
constexpr SharkToMiddlewarePublisher n_sharkToMiddlewarePublishers =
{
	Any::PublishId(),
	Any::SharkByteId(),
	Any::Unit(),
	Any::MiddlewareDataType()
};
}

class SharkParameterDataPublisherTest : public Test
{
protected:
	SharkParameterDataPublisherTest()
	{
		ON_CALL(m_mockService, RetrievePublisherInstance(_))
			.WillByDefault(ReturnRef(m_mockPublish));
		ON_CALL(m_mockSharkByteRetriever, Retrieve(_))
			.WillByDefault(ReturnRef(m_mockSharkByte.GetMock()));
		ON_CALL(m_mockPublish, Publish(_))
			.WillByDefault(SaveArg<0>(&m_publishedData));
	}

	void CallInitialize()
	{
		m_sharkParameterDataPublisher.Initialize(m_mockSharkByteRetriever, m_mockService);
	}

	NiceMock<MockIPublish> m_mockPublish{};
	NiceMock<MockIService> m_mockService{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	Shark::Mocks::MockSharkByteWrapper m_mockSharkByte{};

	SharkParameterDataPublisher m_sharkParameterDataPublisher{n_sharkToMiddlewarePublishers};
	Data m_publishedData{};
};
TEST_F(SharkParameterDataPublisherTest, Initialize_RetrievesThePublisherInstanceForTheAssignedPublishId)
{
	EXPECT_CALL(m_mockService, RetrievePublisherInstance(Any::PublishId()));
	CallInitialize();
}
TEST_F(SharkParameterDataPublisherTest, Initialize_RetrievesTheSharkByteForTheAssignedSharkByteId)
{
	EXPECT_CALL(m_mockSharkByteRetriever, Retrieve(Any::SharkByteId()));
	CallInitialize();
}
TEST_F(SharkParameterDataPublisherTest, Initialize_SubscribesToRetrievedSharkByte)
{
	m_mockSharkByte.ExpectThatSubscribeOccurs([this]{ CallInitialize(); });
}
TEST_F(SharkParameterDataPublisherTest,
	SharkByteCallback_PublishesEmptyDataWithQualityNotReceivedToMiddlewareAfterInitialize)
{
	CallInitialize();

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	EXPECT_THAT(m_publishedData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(SharkParameterDataPublisherTest,
	SharkByteCallback_PublishesPopulatedDataWithQualityGoodToMiddlewareAfterSetOfValidValue)
{
	CallInitialize();
	m_mockSharkByte.SetValue(Any::ValidData());

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedData.mutable_value()->set_double_value(Any::DoubleValue());
	EXPECT_THAT(m_publishedData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(SharkParameterDataPublisherTest,
	SharkByteCallback_PublishesEmptyDataWithQualityNotReceivedToMiddlewareAfterSetOfInvalidValue)
{
	CallInitialize();
	m_mockSharkByte.SetValue(Any::ValidData());
	m_mockSharkByte.SetInvalid();

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	EXPECT_THAT(m_publishedData, Utilities::ProtobufEquals(expectedData));
}

namespace
{
struct SingleBytePublishParameter
{
	uint8_t inputData[1];
	double expectedDoubleValue;
	bool expectedBooleanValue;

	std::vector<uint8_t> GetInputData() const
	{
		return std::vector<uint8_t>{inputData, inputData + sizeof(inputData)};
	}
};
constexpr SingleBytePublishParameter n_singleByteSharkPublishers[]
{
	{ { 0x00 },   0.0, false },
	{ { 0x01 },   1.0, true },
	{ { 0x80 }, 128.0, true },
	{ { 0xFE }, 254.0, true },
	{ { 0xFF }, 255.0, true },
};
}
class SingleByteSharkParameterDataPublisherTest : public TestWithParam<SingleBytePublishParameter>
{
public:
	SingleByteSharkParameterDataPublisherTest()
	{
		ON_CALL(m_mockService, RetrievePublisherInstance(_))
			.WillByDefault(ReturnRef(m_mockPublish));
		ON_CALL(m_mockSharkByteRetriever, Retrieve(_))
			.WillByDefault(ReturnRef(m_mockSharkByte.GetMock()));
	}

	void SetDoubleExpectations(Data const& data, double expectedValue)
	{
		Data expectedData{};
		expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		expectedData.mutable_value()->set_double_value(expectedValue);
		EXPECT_THAT(data, Utilities::ProtobufEquals(expectedData));
	}
	void SetUnsignedExpectations(Data const& data, double expectedValue)
	{
		Data expectedData{};
		expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		expectedData.mutable_value()->set_uinteger64_value(static_cast<uint64_t>(expectedValue));
		EXPECT_THAT(data, Utilities::ProtobufEquals(expectedData));
	}
	void SetBooleanExpectations(Data const& data, bool expectedValue)
	{
		Data expectedData{};
		expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		expectedData.mutable_value()->set_boolean_value(expectedValue);
		EXPECT_THAT(data, Utilities::ProtobufEquals(expectedData));
	}
	void RunTest(MiddlewareDataType type)
	{
		SharkToMiddlewarePublisher sharkToMiddlewarePublisher{};

		auto&& param = GetParam();

		sharkToMiddlewarePublisher.pPublishId = Any::PublishId();
		sharkToMiddlewarePublisher.pSharkByteId = Any::SharkByteId();
		sharkToMiddlewarePublisher.middlewareDataType = type;
		sharkToMiddlewarePublisher.unit = Any::Unit();

		std::unique_ptr<SharkParameterDataPublisher> spSharkParameterDataPublisher =
			std::make_unique<SharkParameterDataPublisher>(sharkToMiddlewarePublisher);
		spSharkParameterDataPublisher->Initialize(m_mockSharkByteRetriever, m_mockService);

		Data data{};
		ON_CALL(m_mockPublish, Publish(_))
			.WillByDefault(SaveArg<0>(&data));

		std::vector<uint8_t> parameterData = param.GetInputData();
		m_mockSharkByte.SetValue(parameterData);

		switch (type)
		{
			case Double:
				SetDoubleExpectations(data, param.expectedDoubleValue);
				break;
			case Uint:
				SetUnsignedExpectations(data, param.expectedDoubleValue);
				break;
			case Boolean:
				SetBooleanExpectations(data, param.expectedBooleanValue);
				break;
			default:
				assert(false);
				break;
		}
	}

	NiceMock<MockIPublish> m_mockPublish{};
	NiceMock<MockIService> m_mockService{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	Shark::Mocks::MockSharkByteWrapper m_mockSharkByte{};
};

class DoubleSharkParameterDataPublisherDataTest : public SingleByteSharkParameterDataPublisherTest {};
INSTANTIATE_TEST_SUITE_P(DoubleSigned, DoubleSharkParameterDataPublisherDataTest, ValuesIn(n_singleByteSharkPublishers));
TEST_P(DoubleSharkParameterDataPublisherDataTest, Publisher_CreatesCorrectProtobufDataWithUnityScaling)
{
	RunTest(Double);
}

class UintSharkParameterDataPublisherDataTest : public SingleByteSharkParameterDataPublisherTest {};
INSTANTIATE_TEST_SUITE_P(UintUnsigned, UintSharkParameterDataPublisherDataTest, ValuesIn(n_singleByteSharkPublishers));
TEST_P(UintSharkParameterDataPublisherDataTest, Publisher_CreatesCorrectProtobufDataWithUnityScaling)
{
	RunTest(Uint);
}

class BooleanSharkParameterDataPublisherDataTest : public SingleByteSharkParameterDataPublisherTest {};
INSTANTIATE_TEST_SUITE_P(Boolean, BooleanSharkParameterDataPublisherDataTest, ValuesIn(n_singleByteSharkPublishers));
TEST_P(BooleanSharkParameterDataPublisherDataTest, Publisher_CreatesCorrectProtobufData)
{
	RunTest(Boolean);
}

namespace
{
constexpr auto n_maxInputSize = 7u;
struct StringPublishParameter
{
	uint8_t inputData[n_maxInputSize];
	unsigned filledSize;
	char const* pExpectedStringValue;

	std::vector<uint8_t> GetInputData() const
	{
		return std::vector<uint8_t>{inputData, inputData + filledSize};
	}
};
constexpr StringPublishParameter n_stringSharkPublishers[]
{
	{ { 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37 }, n_maxInputSize, "1234567" },
	{ { },                                                       0, "" },
	{ { 0x51, 0x52, 0x53, 0x20, 0x54, 0x55, 0x56 }, n_maxInputSize, "QRS TUV" },
};
}

class StringSharkParameterDataPublisherTest : public TestWithParam<StringPublishParameter>
{
public:
	StringSharkParameterDataPublisherTest()
	{
		ON_CALL(m_mockService, RetrievePublisherInstance(_))
			.WillByDefault(ReturnRef(m_mockPublish));
		ON_CALL(m_mockSharkByteRetriever, Retrieve(_))
			.WillByDefault(ReturnRef(m_mockSharkByte.GetMock()));
	}

	void SetStringExpectations(Data const& data, std::string const& expectedValue)
	{
		Data expectedData{};
		expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		expectedData.mutable_value()->set_string_value(expectedValue);
		EXPECT_THAT(data, Utilities::ProtobufEquals(expectedData));
	}
	void RunTest()
	{
		SharkToMiddlewarePublisher sharkToMiddlewarePublisher{};

		auto&& param = GetParam();

		sharkToMiddlewarePublisher.pPublishId = Any::PublishId();
		sharkToMiddlewarePublisher.pSharkByteId = Any::SharkByteId();
		sharkToMiddlewarePublisher.middlewareDataType = String;
		sharkToMiddlewarePublisher.unit = Any::Unit();

		auto spSharkParameterDataPublisher = std::make_unique<SharkParameterDataPublisher>(sharkToMiddlewarePublisher);
		spSharkParameterDataPublisher->Initialize(m_mockSharkByteRetriever, m_mockService);

		Data data{};
		ON_CALL(m_mockPublish, Publish(_))
			.WillByDefault(SaveArg<0>(&data));

		std::vector<uint8_t> parameterData = param.GetInputData();
		m_mockSharkByte.SetValue(parameterData);

		SetStringExpectations(data, param.pExpectedStringValue);
	}

	NiceMock<MockIPublish> m_mockPublish{};
	NiceMock<MockIService> m_mockService{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	Shark::Mocks::MockSharkByteWrapper m_mockSharkByte{};
};

INSTANTIATE_TEST_SUITE_P(StringPublishers, StringSharkParameterDataPublisherTest, ValuesIn(n_stringSharkPublishers));
TEST_P(StringSharkParameterDataPublisherTest, Publisher_CreatesCorrectProtobufData)
{
	RunTest();
}
}
}