/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IService

#pragma once

#include <IParameterService.h>
#include <Utilities/DataEngineMock.h>
#include <middleware_parameter.pb.h>

namespace middleware
{
namespace parameter
{
class MockIService : public IService
{
	EnsureMockKindIsSpecified(MockIService);

public:
	MOCK_METHOD(IPublish&, RetrievePublisherInstance, (Identity const& identity), (override));
	MOCK_METHOD(IRead&, RetrieveReadInstance, (Identity const& identity), (override));
	MOCK_METHOD(IWrite&, RetrieveWriteInstance, (Identity const& identity), (override));
	MOCK_METHOD(void, Reply, (uint_least16_t key, Data const& data), (override));
};
}  // namespace parameter
}  // namespace middleware