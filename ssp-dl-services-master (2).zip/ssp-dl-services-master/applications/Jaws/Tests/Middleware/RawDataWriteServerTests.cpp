/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// RawDataWriteServer tests

#include "Middleware/RawDataWriteServer.cpp"
#include "MockIService.h"
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Utilities/TestUtilities.h>

using namespace testing;
using namespace middleware::parameter;

namespace Jaws
{
namespace Middleware
{
namespace
{
struct Any
{
	static constexpr std::vector<uint8_t> ValidData() { return {0x10, 0x20, 0x30, 0x40}; }
};
}

class RawDataWriteServerTest : public Test
{
protected:
	struct Default
	{
		static constexpr char const* WriteId() { return "bdt_write_id"; }
		static constexpr uint_least16_t Key() { return 42; }
	};

	RawDataWriteServerTest()
	{
		ON_CALL(m_mockWriteSharkByteRetriever, Retrieve(Default::WriteId()))
			.WillByDefault(ReturnRef(m_mockWriteSharkByte));
		ON_CALL(m_mockWriteSharkByte, Write(_, _))
			.WillByDefault(Invoke([this](std::vector<uint8_t> const& writeData, std::function<void(Shark::SharkByteValue const&)> callback)
				{
					m_writeData.emplace(writeData);
					m_writeCallback = std::move(callback);
				}));
	}

	void CreateAndInitialize()
	{
		m_spRawDataWriteServer = std::make_unique<RawDataWriteServer>(Default::WriteId());
		m_spRawDataWriteServer->Initialize(m_mockWriteSharkByteRetriever, m_mockService);
	}
	Data MakeValidBinaryData(std::vector<uint8_t> const& bytes) const
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_binary_value(bytes.data(), bytes.size());
		return data;
	}
	Data MakeBoolReply(bool value) const
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_boolean_value(value);
		return data;
	}
	Data MakeDoubleData() const
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_double_value(1.0);
		return data;
	}
	Data MakeUintData() const
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_uinteger64_value(42);
		return data;
	}
	Data MakeStringData() const
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_string_value("hello");
		return data;
	}
	std::optional<Data> CallWrite()
	{
		return m_spRawDataWriteServer->OnWrite(Default::Key(), Default::WriteId(), MakeValidBinaryData(Any::ValidData()));
	}
	std::optional<Data> CallWriteWithData(Data const& data)
	{
		return m_spRawDataWriteServer->OnWrite(Default::Key(), Default::WriteId(), data);
	}
	void CallWriteCallback(Shark::SharkByteValue const& data)
	{
		ASSERT_THAT(m_writeCallback, NotNull());
		m_writeCallback(data);
	}

	NiceMock<MockIService> m_mockService{};
	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockWriteSharkByte{};
	std::function<void(Shark::SharkByteValue const&)> m_writeCallback{};
	std::optional<std::vector<uint8_t>> m_writeData{};
	std::unique_ptr<RawDataWriteServer> m_spRawDataWriteServer{};
};
TEST_F(RawDataWriteServerTest, Initialize_RetrievesWriteSharkByteFromRetrieverWithTheCorrectId)
{
	EXPECT_CALL(m_mockWriteSharkByteRetriever, Retrieve(Default::WriteId()));
	CreateAndInitialize();
}
TEST_F(RawDataWriteServerTest, OnWrite_CallsWriteOnTheWriteSharkByteWithRawData)
{
	CreateAndInitialize();
	EXPECT_CALL(m_mockWriteSharkByte, Write(ContainerEq(Any::ValidData()), _));
	CallWrite();
}
TEST_F(RawDataWriteServerTest, OnWrite_ReturnsNulloptToInitiateAsyncMode)
{
	CreateAndInitialize();
	auto const result = CallWrite();
	EXPECT_THAT(result, Eq(std::nullopt));
}
TEST_F(RawDataWriteServerTest, OnWrite_ReturnsBadQualityWhenDataIsNotRaw)
{
	CreateAndInitialize();

	for (auto const& data : {MakeDoubleData(), MakeUintData(), MakeStringData(), Data{}})
	{
		auto const result = CallWriteWithData(data);
		ASSERT_TRUE(result);
		EXPECT_THAT(result->quality(), Eq(cat::middleware::parameter::Quality::QUALITY_BAD));
	}
}
TEST_F(RawDataWriteServerTest, OnWrite_DoesNotCallWriteOnSharkByteWhenDataIsNotRaw)
{
	CreateAndInitialize();
	EXPECT_CALL(m_mockWriteSharkByte, Write(_, _)).Times(0);
	for (auto const& data : {MakeDoubleData(), MakeUintData(), MakeStringData(), Data{}})
	{
		CallWriteWithData(data);
	}
}
TEST_F(RawDataWriteServerTest, OnWrite_ReturnsBadQualityIfThereIsAlreadyAnActiveWrite)
{
	CreateAndInitialize();
	CallWrite();
	auto const result = CallWrite();
	ASSERT_TRUE(result);
	EXPECT_THAT(result->quality(), Eq(cat::middleware::parameter::Quality::QUALITY_BAD));
}
TEST_F(RawDataWriteServerTest, OnWrite_DoesNotCallWriteOnSharkByteIfThereIsAlreadyAnActiveWrite)
{
	CreateAndInitialize();
	CallWrite();
	EXPECT_CALL(m_mockWriteSharkByte, Write(_, _)).Times(0);
	CallWrite();
}
TEST_F(RawDataWriteServerTest, OnWriteCompleted_RepliesWithTheMiddlewareWriteKey)
{
	CreateAndInitialize();
	CallWrite();
	EXPECT_CALL(m_mockService, Reply(Default::Key(), _));
	CallWriteCallback(Any::ValidData());
}
TEST_F(RawDataWriteServerTest, OnWriteCompleted_RepliesWithTrue_WhenValueIsNotFalseSharkByteValue)
{
	CreateAndInitialize();
	CallWrite();
	EXPECT_CALL(m_mockService, Reply(_, Utilities::ProtobufEquals(MakeBoolReply(true))));

	CallWriteCallback(Shark::TrueSharkByteValue());
}
TEST_F(RawDataWriteServerTest, OnWriteCompleted_RepliesWithFalse_WhenValueIsFalseSharkByteValue)
{
	CreateAndInitialize();
	CallWrite();
	EXPECT_CALL(m_mockService, Reply(_, Utilities::ProtobufEquals(MakeBoolReply(false))));

	CallWriteCallback(Shark::FalseSharkByteValue());
}
TEST_F(RawDataWriteServerTest, OnWriteCompleted_AllowsNextWriteAfterCompletion)
{
	CreateAndInitialize();
	CallWrite();
	CallWriteCallback(Any::ValidData());

	auto const result = CallWrite();
	EXPECT_THAT(result, Eq(std::nullopt));
}
}
}
