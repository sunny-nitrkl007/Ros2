/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// InitializationGatingConfigBuilder tests

#include "Middleware/InitializationGatingConfigBuilder.cpp"
#include "MockIService.h"
#include <Utilities/GetFunctionPrototype.h>
#include <Utilities/TestUtilities.h>
#include <middleware_parameter.pb.h>

using namespace testing;

namespace Jaws
{
namespace Middleware
{
namespace
{
class MockIInitializationGate : public IInitializationGate
{
	EnsureMockKindIsSpecified(MockIInitializationGate);
public:
	MOCK_METHOD(bool, IsReady, (), (const, override));
	MOCK_METHOD(void, SetReady, (), (override));
	MOCK_METHOD(void, EnqueueOrExecute, (std::move_only_function<void(bool)>&&), (const, override));
};

class MockIConfigBuilder : public middleware::parameter::IConfigBuilder
{
	EnsureMockKindIsSpecified(MockIConfigBuilder);
public:
	MOCK_METHOD(middleware::parameter::IConfigBuilder&, AddPublish,
		(middleware::parameter::Identity&&, middleware::parameter::Unit, middleware::parameter::Data&&), (override));
	MOCK_METHOD(middleware::parameter::IConfigBuilder&, AddSubscribe,
		(middleware::parameter::Identity&&, middleware::parameter::Unit, middleware::parameter::OnSubscription&&, middleware::parameter::OnDisconnect&&), (override));
	MOCK_METHOD(middleware::parameter::IConfigBuilder&, AddSubscribe,
		(middleware::parameter::Identity&&, middleware::parameter::OnSubscriptionWithMetadata&&, middleware::parameter::OnDisconnect&&), (override));
	MOCK_METHOD(middleware::parameter::IConfigBuilder&, AddClientRead,
		(middleware::parameter::Identity&&, middleware::parameter::Unit), (override));
	MOCK_METHOD(middleware::parameter::IConfigBuilder&, AddClientWrite,
		(middleware::parameter::Identity&&, middleware::parameter::Unit), (override));
	MOCK_METHOD(middleware::parameter::IConfigBuilder&, AddServerWrite,
		(middleware::parameter::Identity&&, middleware::parameter::OnWriteAction&&), (override));
	MOCK_METHOD(middleware::parameter::IConfigBuilder&, AddServerRead,
		(middleware::parameter::Identity&&, middleware::parameter::OnReadAction&&), (override));
	MOCK_METHOD(middleware::parameter::ParameterService&&, Take, (), (override));
};

class InitializationGatingConfigBuilderTest : public Test
{
protected:
	struct Default
	{
		static middleware::parameter::Identity ParameterId() { return "param"; }
		static constexpr uint_least16_t Key() { return 42; }
		static constexpr middleware::parameter::Unit Unit() { return middleware::parameter::Unit::rpm; }
		static cat::middleware::parameter::Data RequestData()
		{
			cat::middleware::parameter::Data data{};
			data.mutable_value()->set_string_value("request");
			return data;
		}
		static cat::middleware::parameter::Data ResponseData()
		{
			cat::middleware::parameter::Data data{};
			data.mutable_value()->set_string_value("response");
			return data;
		}
	};

	InitializationGatingConfigBuilderTest()
	{
		ON_CALL(m_mockInitializationGate, EnqueueOrExecute(_))
			.WillByDefault(Invoke([this](auto&& action) { m_enqueuedCallback = std::move(action); }));
	}
	void InvokeEnqueuedCallback(bool immediate = false)
	{
		ASSERT_THAT(m_enqueuedCallback, NotNull());
		m_enqueuedCallback(immediate);
	}

	NiceMock<MockIInitializationGate> m_mockInitializationGate{};
	Utilities::DefaultTestUniquePtr<NiceMock<MockIConfigBuilder>> m_spMockDecoratedBuilder{};
	std::move_only_function<void(bool)> m_enqueuedCallback{};

	InitializationGatingConfigBuilder m_gatingBuilder{m_spMockDecoratedBuilder.TakeUniquePtr(), m_mockInitializationGate};
};
TEST_F(InitializationGatingConfigBuilderTest, AddPublish_IsAPassThrough)
{
	EXPECT_CALL(*m_spMockDecoratedBuilder, AddPublish(
		Default::ParameterId(), Default::Unit(), Utilities::ProtobufEquals(Default::RequestData())))
		.WillOnce(ReturnRef(*m_spMockDecoratedBuilder));

	m_gatingBuilder.AddPublish(Default::ParameterId(), Default::Unit(), Default::RequestData());
}
TEST_F(InitializationGatingConfigBuilderTest, AddSubscribe_EnqueuesCallbackThroughGate)
{
	MockFunction<Utilities::GetFunctionPrototype<middleware::parameter::OnSubscription>::type> mockCallback{};

	middleware::parameter::OnSubscription actualCallback{};
	EXPECT_CALL(*m_spMockDecoratedBuilder, AddSubscribe(Default::ParameterId(), Default::Unit(), _, _))
		.WillOnce([&](auto&&, auto&&, middleware::parameter::OnSubscription&& cb, middleware::parameter::OnDisconnect&&) -> middleware::parameter::IConfigBuilder& {
			actualCallback = std::move(cb);
			return *m_spMockDecoratedBuilder;
		});

	m_gatingBuilder.AddSubscribe(Default::ParameterId(), Default::Unit(), mockCallback.AsStdFunction(), []{});

	EXPECT_CALL(m_mockInitializationGate, EnqueueOrExecute(_));
	actualCallback(Default::ParameterId(), Default::RequestData());

	EXPECT_CALL(mockCallback, Call(Default::ParameterId(), Utilities::ProtobufEquals(Default::RequestData())));
	InvokeEnqueuedCallback();
}
TEST_F(InitializationGatingConfigBuilderTest, AddSubscribe_EnqueuesDisconnectThroughGate)
{
	MockFunction<Utilities::GetFunctionPrototype<middleware::parameter::OnDisconnect>::type> mockDisconnect{};

	middleware::parameter::OnDisconnect actualDisconnect{};
	EXPECT_CALL(*m_spMockDecoratedBuilder, AddSubscribe(Default::ParameterId(), Default::Unit(), _, _))
		.WillOnce([&](auto&&, auto&&, middleware::parameter::OnSubscription&&, middleware::parameter::OnDisconnect&& dc) -> middleware::parameter::IConfigBuilder& {
			actualDisconnect = std::move(dc);
			return *m_spMockDecoratedBuilder;
		});

	m_gatingBuilder.AddSubscribe(Default::ParameterId(), Default::Unit(),
		[](auto&&...){},
		mockDisconnect.AsStdFunction());

	EXPECT_CALL(m_mockInitializationGate, EnqueueOrExecute(_));
	actualDisconnect();

	EXPECT_CALL(mockDisconnect, Call());
	InvokeEnqueuedCallback();
}
TEST_F(InitializationGatingConfigBuilderTest, AddSubscribeWithMetadata_EnqueuesCallbackThroughGate)
{
	MockFunction<Utilities::GetFunctionPrototype<middleware::parameter::OnSubscriptionWithMetadata>::type> mockCallback{};

	middleware::parameter::OnSubscriptionWithMetadata actualCallback;
	EXPECT_CALL(*m_spMockDecoratedBuilder, AddSubscribe(Default::ParameterId(), _, _))
		.WillOnce([&](auto&&, auto&& cb, middleware::parameter::OnDisconnect&&) -> middleware::parameter::IConfigBuilder& {
			actualCallback = std::move(cb);
			return *m_spMockDecoratedBuilder;
		});

	m_gatingBuilder.AddSubscribe(Default::ParameterId(), mockCallback.AsStdFunction(), []{});

	EXPECT_CALL(m_mockInitializationGate, EnqueueOrExecute(_));
	middleware::parameter::Metadata metadata{};
	actualCallback(Default::ParameterId(), Default::RequestData(), metadata);

	EXPECT_CALL(mockCallback, Call(Default::ParameterId(), Utilities::ProtobufEquals(Default::RequestData()), _));
	InvokeEnqueuedCallback();
}
TEST_F(InitializationGatingConfigBuilderTest, AddSubscribeWithMetadata_EnqueuesDisconnectThroughGate)
{
	MockFunction<Utilities::GetFunctionPrototype<middleware::parameter::OnDisconnect>::type> mockDisconnect{};

	middleware::parameter::OnDisconnect actualDisconnect;
	EXPECT_CALL(*m_spMockDecoratedBuilder, AddSubscribe(Default::ParameterId(), _, _))
		.WillOnce([&](auto&&, auto&&, middleware::parameter::OnDisconnect&& dc) -> middleware::parameter::IConfigBuilder& {
			actualDisconnect = std::move(dc);
			return *m_spMockDecoratedBuilder;
		});

	m_gatingBuilder.AddSubscribe(Default::ParameterId(),
		[](middleware::parameter::Identity const&, middleware::parameter::Data const&, middleware::parameter::Metadata const&){},
		mockDisconnect.AsStdFunction());

	EXPECT_CALL(m_mockInitializationGate, EnqueueOrExecute(_));
	actualDisconnect();

	EXPECT_CALL(mockDisconnect, Call());
	InvokeEnqueuedCallback();
}
TEST_F(InitializationGatingConfigBuilderTest, AddClientRead_IsAPassThrough)
{
	EXPECT_CALL(*m_spMockDecoratedBuilder, AddClientRead(Default::ParameterId(), Default::Unit()))
		.WillOnce(ReturnRef(*m_spMockDecoratedBuilder));

	m_gatingBuilder.AddClientRead(Default::ParameterId(), Default::Unit());
}
TEST_F(InitializationGatingConfigBuilderTest, AddClientWrite_IsAPassThrough)
{
	EXPECT_CALL(*m_spMockDecoratedBuilder, AddClientWrite(Default::ParameterId(), Default::Unit()))
		.WillOnce(ReturnRef(*m_spMockDecoratedBuilder));

	m_gatingBuilder.AddClientWrite(Default::ParameterId(), Default::Unit());
}
TEST_F(InitializationGatingConfigBuilderTest, AddServerWrite_WhenQueued_ReturnsNulloptAndRepliesThroughService)
{
	MockFunction<Utilities::GetFunctionPrototype<middleware::parameter::OnWriteAction>::type> mockCallback{};

	middleware::parameter::OnWriteAction actualCallback{};
	EXPECT_CALL(*m_spMockDecoratedBuilder, AddServerWrite(Default::ParameterId(), _))
		.WillOnce([&](auto&&, middleware::parameter::OnWriteAction&& cb) -> middleware::parameter::IConfigBuilder& {
			actualCallback = std::move(cb);
			return *m_spMockDecoratedBuilder;
		});

	m_gatingBuilder.AddServerWrite(Default::ParameterId(), mockCallback.AsStdFunction());

	EXPECT_CALL(m_mockInitializationGate, EnqueueOrExecute(_));
	auto const response = actualCallback(Default::Key(), Default::ParameterId(), Default::RequestData());
	EXPECT_THAT(response, Eq(std::nullopt));

	NiceMock<middleware::parameter::MockIService> mockService{};
	m_gatingBuilder.SetReady(mockService);

	EXPECT_CALL(mockCallback, Call(Default::Key(), Default::ParameterId(), Utilities::ProtobufEquals(Default::RequestData())))
		.WillOnce(Return(Default::ResponseData()));
	EXPECT_CALL(mockService, Reply(Default::Key(), Utilities::ProtobufEquals(Default::ResponseData())));
	InvokeEnqueuedCallback(false);
}
TEST_F(InitializationGatingConfigBuilderTest, AddServerWrite_WhenImmediate_ReturnsResultDirectly)
{
	ON_CALL(m_mockInitializationGate, IsReady())
		.WillByDefault(Return(true));
	ON_CALL(m_mockInitializationGate, EnqueueOrExecute(_))
		.WillByDefault(Invoke([](auto&& action) { action(true); }));

	MockFunction<Utilities::GetFunctionPrototype<middleware::parameter::OnWriteAction>::type> mockCallback{};

	middleware::parameter::OnWriteAction actualCallback{};
	EXPECT_CALL(*m_spMockDecoratedBuilder, AddServerWrite(Default::ParameterId(), _))
		.WillOnce([&](auto&&, middleware::parameter::OnWriteAction&& cb) -> middleware::parameter::IConfigBuilder& {
			actualCallback = std::move(cb);
			return *m_spMockDecoratedBuilder;
		});

	m_gatingBuilder.AddServerWrite(Default::ParameterId(), mockCallback.AsStdFunction());

	EXPECT_CALL(mockCallback, Call(Default::Key(), Default::ParameterId(), Utilities::ProtobufEquals(Default::RequestData())))
		.WillOnce(Return(Default::ResponseData()));
	auto const response = actualCallback(Default::Key(), Default::ParameterId(), Default::RequestData());
	EXPECT_THAT(response, Optional(Utilities::ProtobufEquals(Default::ResponseData())));
}
TEST_F(InitializationGatingConfigBuilderTest, AddServerRead_WhenQueued_ReturnsNulloptAndRepliesThroughService)
{
	MockFunction<Utilities::GetFunctionPrototype<middleware::parameter::OnReadAction>::type> mockCallback{};

	middleware::parameter::OnReadAction actualCallback{};
	EXPECT_CALL(*m_spMockDecoratedBuilder, AddServerRead(Default::ParameterId(), _))
		.WillOnce([&](auto&&, middleware::parameter::OnReadAction&& cb) -> middleware::parameter::IConfigBuilder& {
			actualCallback = std::move(cb);
			return *m_spMockDecoratedBuilder;
		});

	m_gatingBuilder.AddServerRead(Default::ParameterId(), mockCallback.AsStdFunction());

	EXPECT_CALL(m_mockInitializationGate, EnqueueOrExecute(_));
	auto const response = actualCallback(Default::Key(), Default::ParameterId());
	EXPECT_THAT(response, Eq(std::nullopt));

	NiceMock<middleware::parameter::MockIService> mockService{};
	m_gatingBuilder.SetReady(mockService);

	EXPECT_CALL(mockCallback, Call(Default::Key(), Default::ParameterId()))
		.WillOnce(Return(Default::ResponseData()));
	EXPECT_CALL(mockService, Reply(Default::Key(), Utilities::ProtobufEquals(Default::ResponseData())));
	InvokeEnqueuedCallback(false);
}
TEST_F(InitializationGatingConfigBuilderTest, AddServerRead_WhenImmediate_ReturnsResultDirectly)
{
	ON_CALL(m_mockInitializationGate, IsReady())
		.WillByDefault(Return(true));
	ON_CALL(m_mockInitializationGate, EnqueueOrExecute(_))
		.WillByDefault(Invoke([](auto&& action) { action(true); }));

	MockFunction<Utilities::GetFunctionPrototype<middleware::parameter::OnReadAction>::type> mockCallback{};

	middleware::parameter::OnReadAction actualCallback{};
	EXPECT_CALL(*m_spMockDecoratedBuilder, AddServerRead(Default::ParameterId(), _))
		.WillOnce([&](auto&&, middleware::parameter::OnReadAction&& cb) -> middleware::parameter::IConfigBuilder& {
			actualCallback = std::move(cb);
			return *m_spMockDecoratedBuilder;
		});

	m_gatingBuilder.AddServerRead(Default::ParameterId(), mockCallback.AsStdFunction());

	EXPECT_CALL(mockCallback, Call(Default::Key(), Default::ParameterId()))
		.WillOnce(Return(Default::ResponseData()));
	auto const response = actualCallback(Default::Key(), Default::ParameterId());
	EXPECT_THAT(response, Optional(Utilities::ProtobufEquals(Default::ResponseData())));
}
TEST_F(InitializationGatingConfigBuilderTest, ReleaseInnerBuilder_ReturnsTheInnerBuilder)
{
	EXPECT_THAT(*m_gatingBuilder.ReleaseInnerBuilder(), Ref(*m_spMockDecoratedBuilder));
}
}
}
}
