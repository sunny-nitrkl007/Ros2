/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// DiagnosticWrapper tests

#include "Middleware/DiagnosticWrapper.cpp"
#include "MockICodeServer.h"
#include "MockIDiagnosticService.h"
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockISharkByte.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Utilities/TestUtilities.h>
#include <Utilities/Kraken/FakeClock.h>

using namespace testing;
using namespace cat::middleware::diagnostics;
using namespace std::chrono_literals;

namespace middleware
{
namespace diagnostics
{
std::unique_ptr<IService> Factory::CreateDiagnosticService()
{
	return nullptr;
}
}
}

namespace Jaws
{
namespace Middleware
{
namespace
{
struct Any
{
	static constexpr unsigned Cid() { return 4242; }
	static constexpr uint_least16_t MiddlewareRequestKey() { return 0x4242; }
	static constexpr uint_least16_t OtherMiddlewareRequestKey() { return 0x8484; }
	static constexpr uint64_t UniqueCodeKey() { return 0x4200000000000024; }
	static constexpr uint64_t NonMatchingUniqueCodeKey() { return 0xBAD000000000F00D; }
	static constexpr uint8_t OccurrenceCount() { return 5; }
	static constexpr uint8_t SecurityLevel() { return 3; }
	static constexpr uint32_t FirstOccurrenceTime() { return 2136; }
	static constexpr uint32_t LastOccurrenceTime() { return 8842; }
};
constexpr AdditionalInfoGroup2Data n_anyAdditionalInfoGroup2Data
{
	Any::OccurrenceCount(),
	Any::SecurityLevel(),
	Any::FirstOccurrenceTime(),
	Any::LastOccurrenceTime()
};

using namespace Shark::SharkByteDetails::DiagnosticCodes;

class DiagnosticWrapperTest : public Test
{
protected:
	DiagnosticWrapperTest()
	{
		ON_CALL(m_mockSharkByteRetriever, Retrieve(CodesSharkByteId()))
			.WillByDefault(ReturnRef(m_mockCodesSharkByte.GetMock()));
		ON_CALL(m_mockSharkByteRetriever, Retrieve(AdditionalInformationResponseSharkByteId()))
			.WillByDefault(ReturnRef(m_mockAdditionalInformationResponseSharkByte.GetMock()));
		ON_CALL(m_mockWriteSharkByteRetriever, Retrieve(AdditionalInformationRequestSharkByteId()))
			.WillByDefault(ReturnRef(m_mockAdditionalInformationRequestSharkByte));
		ON_CALL(*m_spMockCodeServer, Publish(_))
			.WillByDefault(SaveArg<0>(&m_currentCodeList));

		m_spDiagnosticWrapper = std::make_unique<DiagnosticWrapper>(m_spMockDiagnosticService.TakeUniquePtr());
		m_spDiagnosticWrapper->SetDependency(m_spMockCodeServer.TakeUniquePtr());
	}
	void CallInitialize()
	{
		m_spDiagnosticWrapper->Initialize(m_mockSharkByteRetriever, m_mockWriteSharkByteRetriever);
	}
	void CallRequestAdditionalInformation()
	{
		AdditionalInformation additionalInformation{};
		additionalInformation.set_code_key(Any::UniqueCodeKey());
		m_spDiagnosticWrapper->RequestAdditionalInformation(m_middlewareRequestKey, additionalInformation);
	}
	Codes CreateAnyCodes()
	{
		Codes codes{};
		auto& code = *codes.add_codes();
		code.mutable_information()->mutable_diagnostic()->set_component_identifier(Any::Cid());
		return codes;
	}
	std::vector<uint8_t> SerializeCodes(Codes const& codes)
	{
		auto size = codes.ByteSizeLong();
		std::vector<uint8_t> serializedCodes(size);
		codes.SerializeToArray(serializedCodes.data(), static_cast<int>(size));
		return serializedCodes;
	}
	std::vector<uint8_t> SerializeAdditionalInformation()
	{
		std::vector<uint8_t> responseBytes(sizeof(uint64_t) + sizeof(AdditionalInfoGroup2Data));
		auto uniqueCodeKey = Any::UniqueCodeKey();
		std::memcpy(responseBytes.data(), &uniqueCodeKey, sizeof(uint64_t));
		std::memcpy(responseBytes.data() + sizeof(uint64_t), &n_anyAdditionalInfoGroup2Data, sizeof(AdditionalInfoGroup2Data));

		return responseBytes;
	}

	Utilities::DefaultTestUniquePtr<NiceMock<middleware::diagnostics::MockIService>> m_spMockDiagnosticService{};
	Utilities::DefaultTestUniquePtr<NiceMock<middleware::diagnostics::MockICodeServer>> m_spMockCodeServer{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockAdditionalInformationRequestSharkByte{};
	Shark::Mocks::MockSharkByteWrapper m_mockCodesSharkByte{};
	Shark::Mocks::MockSharkByteWrapper m_mockAdditionalInformationResponseSharkByte{};

	uint_least16_t m_middlewareRequestKey = Any::MiddlewareRequestKey();

	std::unique_ptr<DiagnosticWrapper> m_spDiagnosticWrapper{};
	Codes m_currentCodeList{};
};
TEST_F(DiagnosticWrapperTest, AdditionalInformationRequestTimeoutIsSetToFiveSeconds)
{
	static_assert(n_requestTimeout == 5s, "");
}
TEST_F(DiagnosticWrapperTest, Initialize_RetrievesTheAdditionalInformationRequestSharkByte)
{
	EXPECT_CALL(
		m_mockWriteSharkByteRetriever,
		Retrieve(AdditionalInformationRequestSharkByteId()));
	CallInitialize();
}
TEST_F(DiagnosticWrapperTest, Initialize_RetrievesTheCodesAndAdditionalInformationResponseSharkBytes)
{
	EXPECT_CALL(
		m_mockSharkByteRetriever,
		Retrieve(CodesSharkByteId()));
	EXPECT_CALL(
		m_mockSharkByteRetriever,
		Retrieve(AdditionalInformationResponseSharkByteId()));
	CallInitialize();
}
TEST_F(DiagnosticWrapperTest, Initialize_SubscribesToCodesSharkByte)
{
	m_mockCodesSharkByte.ExpectThatSubscribeOccurs([this]{ CallInitialize(); });
}
TEST_F(DiagnosticWrapperTest, Initialize_SubscribesToAdditionalInformationResponseSharkByte)
{
	m_mockAdditionalInformationResponseSharkByte.ExpectThatSubscribeOccurs([this]{ CallInitialize(); });
}
TEST_F(DiagnosticWrapperTest, CodesSubscribeCallback_PublishesParsedCodesFromByteArrayIfSharkByteIsValid)
{
	CallInitialize();
	auto codes = CreateAnyCodes();
	m_mockCodesSharkByte.SetValue(SerializeCodes(codes));
	EXPECT_THAT(m_currentCodeList, Utilities::ProtobufEquals(codes));
}
TEST_F(DiagnosticWrapperTest, CodesSubscribeCallback_PublishesEmptyListIfSharkByteValueIsInvalid)
{
	CallInitialize();
	auto codes = CreateAnyCodes();
	m_mockCodesSharkByte.SetValue(SerializeCodes(codes));
	ASSERT_THAT(m_currentCodeList, Utilities::ProtobufEquals(codes));

	m_mockCodesSharkByte.SetInvalid();

	Codes expectedCodes{};
	EXPECT_THAT(m_currentCodeList, Utilities::ProtobufEquals(expectedCodes));
}
TEST_F(DiagnosticWrapperTest, RequestAdditionalInformation_WritesUniqueCodeKeyBytesToRequestSharkByte)
{
	CallInitialize();

	std::vector<uint8_t> expectedBytes(sizeof(uint64_t));
	auto uniqueCodeKey = Any::UniqueCodeKey();
	std::memcpy(expectedBytes.data(), &uniqueCodeKey, sizeof(uint64_t));
	EXPECT_CALL(
		m_mockAdditionalInformationRequestSharkByte,
		Write(ElementsAreArray(expectedBytes), _));

	CallRequestAdditionalInformation();
}
TEST_F(DiagnosticWrapperTest, RequestAdditionalInformation_DoesNotWriteTheUniqueCodeKeyBytesToRequestSharkByteIfAMatchingRequestIsAlreadyPending)
{
	CallInitialize();
	CallRequestAdditionalInformation();

	EXPECT_CALL(m_mockAdditionalInformationRequestSharkByte, Write(_, _)).Times(0);
	m_middlewareRequestKey = Any::OtherMiddlewareRequestKey();
	CallRequestAdditionalInformation();
}
TEST_F(DiagnosticWrapperTest, RequestAdditionalInformation_WritesUniqueCodeKeyBytesToRequestSharkByteIfMatchingPendingRequestHasTimedOut)
{
	CallInitialize();
	CallRequestAdditionalInformation();

	// This request should not write since it is still pending
	EXPECT_CALL(m_mockAdditionalInformationRequestSharkByte, Write(_, _)).Times(0);
	m_middlewareRequestKey = Any::OtherMiddlewareRequestKey();
	Utilities::Kraken::FakeClock::AdvanceBy(n_requestTimeout - 1ms);
	CallRequestAdditionalInformation();

	// This request should write since the timeout has elapsed
	EXPECT_CALL(m_mockAdditionalInformationRequestSharkByte, Write(_, _));
	Utilities::Kraken::FakeClock::AdvanceBy(1ms);
	CallRequestAdditionalInformation();
}
TEST_F(DiagnosticWrapperTest,
	AdditionalInformationResponseCallback_CallsCodeServerReplyWithKeyThatMatchesTheRequestWhenUniqueCodeKeyMatches)
{
	CallInitialize();
	CallRequestAdditionalInformation();

	EXPECT_CALL(*m_spMockCodeServer, Reply(m_middlewareRequestKey, _));

	std::vector<uint8_t> responseBytes(sizeof(uint64_t));
	auto uniqueCodeKey = Any::UniqueCodeKey();
	std::memcpy(responseBytes.data(), &uniqueCodeKey, sizeof(uint64_t));
	m_mockAdditionalInformationResponseSharkByte.SetValue(responseBytes);
}
TEST_F(DiagnosticWrapperTest,
	AdditionalInformationResponseCallback_CallsCodeServerReplyWithUniqueCodeKeyInAdditionalInformationWhenItMatchesRequest)
{
	CallInitialize();
	CallRequestAdditionalInformation();

	EXPECT_CALL(*m_spMockCodeServer, Reply(_, _))
		.WillOnce(WithArg<1>([](AdditionalInformation const& additionalInformation)
		{
			EXPECT_EQ(additionalInformation.code_key(), Any::UniqueCodeKey());
		}));

	std::vector<uint8_t> responseBytes(sizeof(uint64_t));
	auto uniqueCodeKey = Any::UniqueCodeKey();
	std::memcpy(responseBytes.data(), &uniqueCodeKey, sizeof(uint64_t));
	m_mockAdditionalInformationResponseSharkByte.SetValue(responseBytes);
}
TEST_F(DiagnosticWrapperTest,
	AdditionalInformationResponseCallback_CallsCodeServerReplyWithAdditionalInformationGroup2DataWhenItMatchesRequest)
{
	CallInitialize();
	CallRequestAdditionalInformation();

	EXPECT_CALL(*m_spMockCodeServer, Reply(_, _))
		.WillOnce(WithArg<1>([](AdditionalInformation const& additionalInformation)
		{
			EXPECT_TRUE(additionalInformation.has_group_2());
			auto const& group2 = additionalInformation.group_2();
			EXPECT_THAT(group2.occurrence_count(), Eq(Any::OccurrenceCount()));
			EXPECT_THAT(group2.security_level(), Eq(Any::SecurityLevel()));
			EXPECT_THAT(group2.shm_of_first_occurence(), Eq(Any::FirstOccurrenceTime()));
			EXPECT_THAT(group2.shm_of_last_occurence(), Eq(Any::LastOccurrenceTime()));
		}));

	m_mockAdditionalInformationResponseSharkByte.SetValue(SerializeAdditionalInformation());
}
TEST_F(DiagnosticWrapperTest,
	AdditionalInformationResponseCallback_CallsCodeServerReplyForAllMatchingPendingRequests)
{
	CallInitialize();
	CallRequestAdditionalInformation();
	m_middlewareRequestKey = Any::OtherMiddlewareRequestKey();
	CallRequestAdditionalInformation();

	EXPECT_CALL(*m_spMockCodeServer, Reply(Any::MiddlewareRequestKey(), _));
	EXPECT_CALL(*m_spMockCodeServer, Reply(Any::OtherMiddlewareRequestKey(), _));

	m_mockAdditionalInformationResponseSharkByte.SetValue(SerializeAdditionalInformation());
}
TEST_F(DiagnosticWrapperTest,
	AdditionalInformationResponseCallback_DoesNotCallCodeServerReplyWhenThereHasNotBeenAMatchingRequest)
{
	CallInitialize();
	CallRequestAdditionalInformation();

	EXPECT_CALL(*m_spMockCodeServer, Reply(_, _)).Times(0);

	std::vector<uint8_t> responseBytes(sizeof(uint64_t));
	auto uniqueCodeKey = Any::NonMatchingUniqueCodeKey();
	std::memcpy(responseBytes.data(), &uniqueCodeKey, sizeof(uint64_t));
	m_mockAdditionalInformationResponseSharkByte.SetValue(responseBytes);
}
}
}
}