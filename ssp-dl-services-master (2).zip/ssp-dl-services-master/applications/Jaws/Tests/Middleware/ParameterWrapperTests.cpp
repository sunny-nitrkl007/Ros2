/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// ParameterWrapper tests

#include "Middleware/ParameterWrapper.cpp"
#include "MockIService.h"
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Utilities/TestUtilities.h>

using namespace testing;

namespace middleware
{
namespace parameter
{
std::unique_ptr<IService> Factory::CreateParameterService(std::unique_ptr<IConfigTaker>&&)
{
	return nullptr;
}
void Factory::SetLogLevel(std::ostream&, uint8_t)
{
}
std::unique_ptr<IConfigBuilder> IConfigBuilder::Create(Identity&&)
{
	return nullptr;
}
}
}

namespace Jaws
{
namespace Middleware
{
namespace
{
class MockIServiceWaiter : public IServiceWaiter
{
	EnsureMockKindIsSpecified(MockIServiceWaiter);
public:
	MOCK_METHOD(void, SetReady, (middleware::parameter::IService&), (override));
};

struct Any
{
	static constexpr char const* PublishId() { return "middleware_id"; }
};
}

class ParameterWrapperTest : public Test
{
protected:
	ParameterWrapperTest()
	{
		ParameterInitializers parameterInitializers{};
		parameterInitializers.push_back(m_mockInitializer.AsStdFunction());

		ServiceFactory serviceFactory = [this]()
			{
				return m_spMockParameterService.TakeUniquePtr();
			};

		m_spParameterWrapper = std::make_unique<ParameterWrapper>(
			std::move(serviceFactory),
			std::move(parameterInitializers),
			m_mockServiceWaiter);
	}

	NiceMock<MockIServiceWaiter> m_mockServiceWaiter{};
	NiceMock<MockFunction<void(middleware::parameter::IService&)>> m_mockInitializer{};
	Utilities::DefaultTestUniquePtr<NiceMock<middleware::parameter::MockIService>> m_spMockParameterService{};

	std::unique_ptr<ParameterWrapper> m_spParameterWrapper{};
};
TEST_F(ParameterWrapperTest, Initialize_CallsParameterInitializerWithTheParameterService)
{
	EXPECT_CALL(m_mockInitializer, Call(Ref(*m_spMockParameterService)));
	m_spParameterWrapper->Initialize();
}
TEST_F(ParameterWrapperTest, Initialize_CallsSetReadyWithTheParameterService)
{
	EXPECT_CALL(m_mockServiceWaiter, SetReady(Ref(*m_spMockParameterService)));
	m_spParameterWrapper->Initialize();
}
TEST_F(ParameterWrapperTest, Initialize_CallsSetReadyAfterParameterInitializers)
{
	InSequence seq{};
	EXPECT_CALL(m_mockInitializer, Call(_));
	EXPECT_CALL(m_mockServiceWaiter, SetReady(_));
	m_spParameterWrapper->Initialize();
}
}
}