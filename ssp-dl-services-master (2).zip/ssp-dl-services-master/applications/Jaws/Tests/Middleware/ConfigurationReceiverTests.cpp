/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// ConfigurationReceiver tests

#include "Middleware/ConfigurationReceiver.cpp"
#include "Nvm/MockINvmWrapper.h"
#include <Utilities/TestUtilities.h>
#include "Middleware/IConfigValidator.h"
#include <gmock/gmock.h>

using namespace testing;

namespace Jaws
{
namespace Middleware
{
namespace
{
struct Any
{
	static constexpr char const* Data() { return "TestData";}
	static constexpr char const* NonConfigurationId() { return "NotConfigurationId"; }
	static constexpr char const* JsonString() { return "ValidJsonString"; }
};
}

class MockConfigValidator : public IConfigValidator
{
	EnsureMockKindIsSpecified(MockConfigValidator);
public:
	MOCK_METHOD(
		bool,
		ValidateAndConvertToJson,
		(std::vector<uint8_t> const& data, std::string& output),
		(override));
};

class ConfigurationReceiverTest : public Test {
protected:
	void CallOnConfigurationUpdate(std::string const& id)
	{
		ConfigurationReceiver::OnConfigurationUpdate(id, m_data, middleware::parameter::Metadata{});
	}

	NiceMock<Nvm::MockINvmWrapper> m_mockNvmWrapper{};
	Utilities::DefaultTestUniquePtr<NiceMock<MockConfigValidator>> m_spMockConfigValidator{};
	middleware::parameter::Data m_data{};
	ConfigurationReceiver m_configurationReceiver{m_mockNvmWrapper, m_spMockConfigValidator.TakeUniquePtr()};
};
TEST_F(ConfigurationReceiverTest, OnConfigurationUpdate_IgnoresOtherIds)
{
	m_data.mutable_value()->set_binary_value(Any::Data());
	EXPECT_CALL(m_mockNvmWrapper, Write(Nvm::JawsConfigurationNvmId(), _)).Times(0);
	CallOnConfigurationUpdate(Any::NonConfigurationId());
}
TEST_F(ConfigurationReceiverTest, OnConfigurationUpdate_WritesToNvmWhenValidationSucceeds)
{
	ON_CALL(*m_spMockConfigValidator, ValidateAndConvertToJson(_, _))
		.WillByDefault(Return(true));
	m_data.mutable_value()->set_binary_value(Any::Data());

	EXPECT_CALL(m_mockNvmWrapper, Write(Nvm::JawsConfigurationNvmId(), _));

	CallOnConfigurationUpdate(Configuration());
}
TEST_F(ConfigurationReceiverTest, OnConfigurationUpdate_WritesJsonStringToNvmWhenValidationSucceeds)
{
	ON_CALL(*m_spMockConfigValidator, ValidateAndConvertToJson(_, _))
		.WillByDefault(
			Invoke([](std::vector<uint8_t> const&, std::string& output)
			{
				output = Any::JsonString();
				return true;
			}));
	m_data.mutable_value()->set_binary_value(Any::Data());

	EXPECT_CALL(m_mockNvmWrapper, Write(Nvm::JawsConfigurationNvmId(), Any::JsonString()));

	CallOnConfigurationUpdate(Configuration());
}
TEST_F(ConfigurationReceiverTest, OnConfigurationUpdate_DoesNotWriteToNvmWhenValidationFails)
{
	ON_CALL(*m_spMockConfigValidator, ValidateAndConvertToJson(_, _))
		.WillByDefault(Return(false));
	m_data.mutable_value()->set_binary_value(Any::Data());

	EXPECT_CALL(m_mockNvmWrapper, Write(Nvm::JawsConfigurationNvmId(), _)).Times(0);

	CallOnConfigurationUpdate(Configuration());
}
}
}