/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// CalibrationWrapper tests

#include "Middleware/CalibrationWrapper.cpp"
#include "MockIWriteReply.h"
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockISharkByte.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Utilities/TestUtilities.h>

using namespace testing;

namespace Jaws
{
namespace Middleware
{
namespace
{
struct Any
{
static constexpr auto StringValue() { return "test"; }
static constexpr auto StringValueAsBytes() { return std::vector<uint8_t>(StringValue(), StringValue() + strlen(StringValue())); }
};
}

class CalibrationWrapperTest : public Test
{
protected:
	CalibrationWrapperTest()
	{
		m_data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		m_data.mutable_value()->set_string_value(Any::StringValue());

		ON_CALL(m_mockWriteSharkByteRetriever, Retrieve(_))
			.WillByDefault(ReturnRef(m_mockWriteSharkByte));
		ON_CALL(m_mockWriteSharkByte, Write(_, _))
			.WillByDefault(SaveArg<1>(&m_actualWriteCallback));
	}
	void CallInitialize()
	{
		m_calibrationWrapper.Initialize(m_mockWriteSharkByteRetriever);
	}
	std::optional<Data> CallCommand()
	{
		return m_calibrationWrapper.SendCalibrationCommand(m_data, m_mockWriteReply);
	}

	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockWriteSharkByte{};
	NiceMock<MockIWriteReply> m_mockWriteReply{};
	std::function<void(Shark::SharkByteValue const&)> m_actualWriteCallback;
	cat::middleware::parameter::Data m_data{};

	CalibrationWrapper m_calibrationWrapper{};
};
TEST_F(CalibrationWrapperTest, Initialize_RetrievesTheCalibrationCommandSharkByte)
{
	EXPECT_CALL(m_mockWriteSharkByteRetriever, Retrieve(::Command::SharkByteId()));
	CallInitialize();
}
TEST_F(CalibrationWrapperTest, CalibrationCommand_ReturnsEmptyOptional)
{
	CallInitialize();
	EXPECT_THAT(CallCommand(), Eq(std::nullopt));
}
TEST_F(CalibrationWrapperTest, CalibrationCommand_CallsWriteWithDataAndNonNullCallback)
{
	CallInitialize();
	EXPECT_CALL(m_mockWriteSharkByte, Write(Any::StringValueAsBytes(), NotNull()));
	CallCommand();
}
TEST_F(CalibrationWrapperTest, CalibrationCommandWriteCallback_RepliesToWriteWithFalseIfReturnedSharkByteValueIsInvalid)
{
	CallInitialize();
	CallCommand();
	ASSERT_TRUE(m_actualWriteCallback);
	EXPECT_CALL(m_mockWriteReply, Reply(Utilities::ProtobufEquals(MakeBooleanData(false))));
	m_actualWriteCallback(std::nullopt);
}
TEST_F(CalibrationWrapperTest, CalibrationCommandWriteCallback_CallsReplyWithDataBasedOnStatusSharkByteValue)
{
	CallInitialize();
	for (auto status : { true, false })
	{
		CallCommand();
		ASSERT_TRUE(m_actualWriteCallback);
		EXPECT_CALL(m_mockWriteReply, Reply(Utilities::ProtobufEquals(MakeBooleanData(status))));
		m_actualWriteCallback(status ? Shark::TrueSharkByteValue() : Shark::FalseSharkByteValue());
	}
}
}
}