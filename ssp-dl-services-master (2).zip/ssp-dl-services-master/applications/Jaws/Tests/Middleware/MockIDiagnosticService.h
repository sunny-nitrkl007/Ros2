/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IService

#pragma once

#include <IDiagnosticService.h>
#include <Utilities/DataEngineMock.h>

namespace middleware
{
namespace diagnostics
{
class MockIService : public IService
{
	EnsureMockKindIsSpecified(MockIService);

public:
	MOCK_METHOD(
		std::unique_ptr<::middleware::diagnostics::ICodeClient>,
		CreateCodeClient,
		(CodeConsumer&& client),
		(override));
	MOCK_METHOD(
		std::unique_ptr<::middleware::diagnostics::ICodeServer>,
		CreateCodeServer,
		(
			::cat::middleware::diagnostics::Codes const& current,
			std::function<std::optional<::cat::middleware::diagnostics::AdditionalInformation>
					(uint_least16_t key, ::cat::middleware::diagnostics::AdditionalInformation const& request)>&& requestAdditionalInformation),
		(override));
};
}  // namespace diagnostics
}  // namespace middleware