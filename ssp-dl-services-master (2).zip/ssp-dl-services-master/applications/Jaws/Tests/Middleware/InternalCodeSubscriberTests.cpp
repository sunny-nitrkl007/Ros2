/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// InternalCodeSubscriber tests

#include "Middleware/InternalCodeSubscriber.cpp"
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Utilities/TestUtilities.h>

using namespace testing;
using namespace Shark::Mocks;

namespace Jaws
{
namespace Middleware
{
namespace
{
struct Any
{
	static constexpr char const* SubscribeId() { return "subscribe_id"; }
};

class InternalCodeSubscriberTest : public Test
{
protected:
	InternalCodeSubscriberTest()
	{
		ON_CALL(m_mockWriteSharkByteRetriever, Retrieve(Any::SubscribeId()))
			.WillByDefault(ReturnRef(m_mockWriteSharkByte));
	}

	void CallInitialize()
	{
		m_dataSubscriber.Initialize(m_mockWriteSharkByteRetriever);
	}
	Data CreateData(bool boolValue)
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_boolean_value(boolValue);
		return data;
	}
	void CallOnSubscriptionDataReceived(Data const& data)
	{
		m_dataSubscriber.OnSubscriptionDataReceived(Any::SubscribeId(), data);
	}
	void CallOnDisconnect()
	{
		m_dataSubscriber.OnDisconnect();
	}

	NiceMock<MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<MockIWriteSharkByte> m_mockWriteSharkByte{};

	InternalCodeSubscriber m_dataSubscriber{Any::SubscribeId()};
};
TEST_F(InternalCodeSubscriberTest, InitializeRetrievesWriteSharkByteThatMatchesSubscribeId)
{
	EXPECT_CALL(m_mockWriteSharkByteRetriever, Retrieve(Any::SubscribeId()));
	CallInitialize();
}
TEST_F(InternalCodeSubscriberTest, OnSubscription_WritesSubscribedDataUpdateToSharkByte)
{
	CallInitialize();
	for (auto value : {true, false})
	{
		EXPECT_CALL(m_mockWriteSharkByte, Write(value ? Shark::TrueSharkByteValue() : Shark::FalseSharkByteValue(), _));
		CallOnSubscriptionDataReceived(CreateData(value));
	}
}
TEST_F(InternalCodeSubscriberTest, OnSubscription_DoesNotWriteToSharkByteIfDataIsNotBoolean)
{
	CallInitialize();
	Data emptyData{};

	EXPECT_CALL(m_mockWriteSharkByte, Write(_, _)).Times(0);
	CallOnSubscriptionDataReceived(emptyData);
}
TEST_F(InternalCodeSubscriberTest, OnDisconnect_WritesInvalidDataToSharkByte)
{
	CallInitialize();
	EXPECT_CALL(m_mockWriteSharkByte, WriteInvalid(NotNull()));
	CallOnDisconnect();
}
}
}
}