/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PidParameterDataPublisher tests

#include "Middleware/PidParameterDataPublisher.cpp"
#include "Identifiers/MockIPidValueDecoder.h"
#include "Middleware/MockIPublish.h"
#include "Middleware/MockIService.h"
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockISharkByte.h>
#include <Utilities/TestUtilities.h>

using namespace testing;
using namespace middleware::parameter;

namespace Jaws
{
using namespace Identifiers;

namespace Middleware
{
namespace
{
cat::shark::PidEntry const CreateDefaultPidEntry()
{
	cat::shark::PidEntry pidEntry{};
	pidEntry.set_pid(0xD10101);
	pidEntry.set_byte_count(2);
	pidEntry.set_is_signed(false);
	pidEntry.set_is_dsi_supported(true);
	pidEntry.set_scaling(1.0);
	pidEntry.set_unit(cat::shark::UNIT_NONE);
	pidEntry.set_is_lsb(true);
	pidEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_DOUBLE);
	return pidEntry;
}
struct Any
{
	static constexpr char const* PublishId()  { return "middleware_id"; }
	static std::vector<uint8_t> Data()        { return {0x21, 0x42}; }
	static constexpr double DoubleValue()     { return 16962.5; }
	static constexpr uint64_t UintValue()     { return 85; }
	static std::vector<uint8_t> BinaryValue() { return {0x01, 0x02, 0x03}; }
};
}

class PidParameterDataPublisherTest : public Test
{
protected:
	PidParameterDataPublisherTest()
	{
		ON_CALL(m_mockService, RetrievePublisherInstance(_))
			.WillByDefault(ReturnRef(m_mockPublish));
		ON_CALL(m_mockSharkByteRetriever, Retrieve(_))
			.WillByDefault(ReturnRef(m_mockSharkByte.GetMock()));
		ON_CALL(m_mockPublish, Publish(_))
			.WillByDefault(SaveArg<0>(&m_publishedData));
		ON_CALL(m_mockPidValueDecoder, Decode(_, _))
			.WillByDefault(ReturnPointee(&m_decodedValue));
	}

	void CallInitialize()
	{
		m_pidParameterDataPublisher.Initialize(m_mockSharkByteRetriever, m_mockService);
	}

	void GivenTheDecoderReturns(DecodedPidValue&& decodedValue)
	{
		m_decodedValue = std::move(decodedValue);
	}

	NiceMock<MockIPublish> m_mockPublish{};
	NiceMock<MockIService> m_mockService{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	Shark::Mocks::MockSharkByteWrapper m_mockSharkByte{};
	NiceMock<MockIPidValueDecoder> m_mockPidValueDecoder{};

	cat::shark::PidEntry const m_pidEntry{CreateDefaultPidEntry()};
	PidParameterDataPublisher m_pidParameterDataPublisher{Any::PublishId(), {m_pidEntry}, m_mockPidValueDecoder};
	Data m_publishedData{};
	DecodedPidValue m_decodedValue{};
};
TEST_F(PidParameterDataPublisherTest, Initialize_RetrievesThePublisherInstanceForTheAssignedPublishId)
{
	EXPECT_CALL(m_mockService, RetrievePublisherInstance(Any::PublishId()));
	CallInitialize();
}
TEST_F(PidParameterDataPublisherTest, Initialize_RetrievesTheSharkByteForTheAssignedPublishId)
{
	EXPECT_CALL(m_mockSharkByteRetriever, Retrieve(Any::PublishId()));
	CallInitialize();
}
TEST_F(PidParameterDataPublisherTest, Initialize_SubscribesToRetrievedSharkByte)
{
	m_mockSharkByte.ExpectThatSubscribeOccurs([this]{ CallInitialize(); });
}
TEST_F(PidParameterDataPublisherTest,
	SharkByteCallback_DecodesTheReceivedValueUsingThePublishersPidDefinition)
{
	CallInitialize();

	EXPECT_CALL(m_mockPidValueDecoder, Decode(PidDefinition{m_pidEntry}, _));
	m_mockSharkByte.SetValue(Any::Data());
}
TEST_F(PidParameterDataPublisherTest,
	SharkByteCallback_PublishesQualityNotReceivedWhenTheDecodedQualityIsNotReceived)
{
	GivenTheDecoderReturns({.quality = DecodedPidQuality::NotReceived});
	CallInitialize();
	m_mockSharkByte.SetValue(Any::Data());

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	EXPECT_THAT(m_publishedData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(PidParameterDataPublisherTest,
	SharkByteCallback_PublishesQualityBadWhenTheDecodedQualityIsBad)
{
	GivenTheDecoderReturns({.quality = DecodedPidQuality::Bad});
	CallInitialize();
	m_mockSharkByte.SetValue(Any::Data());

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_BAD);
	EXPECT_THAT(m_publishedData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(PidParameterDataPublisherTest,
	SharkByteCallback_PublishesADoubleValueWhenTheDecodedTypeIsDouble)
{
	GivenTheDecoderReturns({
		.quality = DecodedPidQuality::Good,
		.value = Any::DoubleValue()});
	CallInitialize();
	m_mockSharkByte.SetValue(Any::Data());

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedData.mutable_value()->set_double_value(Any::DoubleValue());
	EXPECT_THAT(m_publishedData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(PidParameterDataPublisherTest,
	SharkByteCallback_PublishesAUintValueWhenTheDecodedTypeIsUint)
{
	GivenTheDecoderReturns({
		.quality = DecodedPidQuality::Good,
		.value = Any::UintValue()});
	CallInitialize();
	m_mockSharkByte.SetValue(Any::Data());

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedData.mutable_value()->set_uinteger64_value(Any::UintValue());
	EXPECT_THAT(m_publishedData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(PidParameterDataPublisherTest,
	SharkByteCallback_PublishesABinaryValueWhenTheDecodedTypeIsBinary)
{
	GivenTheDecoderReturns({
		.quality = DecodedPidQuality::Good,
		.value = Any::BinaryValue()});
	CallInitialize();
	m_mockSharkByte.SetValue(Any::Data());

	auto const binaryValue = Any::BinaryValue();
	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedData.mutable_value()->set_binary_value(binaryValue.data(), binaryValue.size());
	EXPECT_THAT(m_publishedData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(PidParameterDataPublisherTest,
	SharkByteCallback_PublishesQualityGoodWithNoValueWhenTheDecodedTypeIsNone)
{
	GivenTheDecoderReturns({.quality = DecodedPidQuality::Good});
	CallInitialize();
	m_mockSharkByte.SetValue(Any::Data());

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	EXPECT_THAT(m_publishedData, Utilities::ProtobufEquals(expectedData));
}
}
}
