/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// RefreshableSharkByteReadServer tests

#include "Middleware/RefreshableSharkByteReadServer.cpp"
#include "MockIPublish.h"
#include "MockIService.h"
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockISharkByte.h>
#include <Utilities/TestUtilities.h>

using namespace testing;
using namespace middleware::parameter;

namespace Jaws
{
using namespace Identifiers;

namespace Middleware
{
namespace
{
struct Any
{
	static constexpr uint_least16_t AnotherKey() { return 99; }
	static constexpr std::vector<uint8_t> ValidData() { return {0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47}; }
};
}
class RefreshableSharkByteReadServerTest : public Test
{
protected:
	struct Default
	{
		static constexpr char const* ReadId() { return "read id"; }
		static constexpr uint_least16_t Key() { return 42; }
	};

	RefreshableSharkByteReadServerTest()
		: m_mockSharkByte(Any::ValidData())
		, m_publisher(Default::ReadId())
	{
		ON_CALL(m_mockSharkByteRetriever, Retrieve(Default::ReadId()))
			.WillByDefault(ReturnRef(m_mockSharkByte.GetMock()));
	}

	void CallInitialize()
	{
		m_publisher.Initialize(m_mockSharkByteRetriever, m_mockService);
	}

	NiceMock<MockIService> m_mockService{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	Shark::Mocks::MockSharkByteWrapper m_mockSharkByte{};
	RefreshableSharkByteReadServer m_publisher;
};
TEST_F(RefreshableSharkByteReadServerTest, Initialize_SubscribesToTheSharkByte)
{
	m_mockSharkByte.ExpectThatSubscribeOccurs([this]{ CallInitialize(); });
}
TEST_F(RefreshableSharkByteReadServerTest, OnValueChanged_DoesNotReplyWhenNoReadRequestsHaveBeenMade)
{
	CallInitialize();
	EXPECT_CALL(m_mockService, Reply(_, _)).Times(0);
	m_mockSharkByte.SetValue(Any::ValidData());
}
TEST_F(RefreshableSharkByteReadServerTest, OnRead_CallsRefreshOnTheSharkByte)
{
	CallInitialize();
	EXPECT_CALL(m_mockSharkByte.GetMock(), Refresh());
	 m_publisher.OnRead(Default::Key(), Default::ReadId());
}
TEST_F(RefreshableSharkByteReadServerTest, OnRead_ReturnsNulloptToInitiateAsyncMode)
{
	CallInitialize();
	 auto const result = m_publisher.OnRead(Default::Key(), Default::ReadId());
	EXPECT_THAT(result, Eq(std::nullopt));
}
TEST_F(RefreshableSharkByteReadServerTest, OnValueChanged_RepliesUsingTheReadKey)
{
	CallInitialize();
	m_publisher.OnRead(Default::Key(), Default::ReadId());

	EXPECT_CALL(m_mockService, Reply(Default::Key(), _));
	m_mockSharkByte.SetValue(Any::ValidData());
}
TEST_F(RefreshableSharkByteReadServerTest, OnValueChanged_Valid_RepliesWithBinaryValue)
{
	auto const sharkByteData = Any::ValidData();
	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedData.mutable_value()->set_binary_value(sharkByteData.data(), sharkByteData.size());

	CallInitialize();
	m_publisher.OnRead(Default::Key(), Default::ReadId());
	EXPECT_CALL(m_mockService, Reply(_, Utilities::ProtobufEquals(expectedData)));

	m_mockSharkByte.SetValue(sharkByteData);
}
TEST_F(RefreshableSharkByteReadServerTest, OnValueChanged_Invalid_RepliesWithBadQuality)
{
	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_BAD);

	CallInitialize();
	m_publisher.OnRead(Default::Key(), Default::ReadId());
	EXPECT_CALL(m_mockService, Reply(_, Utilities::ProtobufEquals(expectedData)));

	m_mockSharkByte.SetInvalid();
}
TEST_F(RefreshableSharkByteReadServerTest, OnValueChanged_RepliesToAllActiveReadsInTheOrderReceived)
{
	CallInitialize();
	m_publisher.OnRead(Default::Key(), Default::ReadId());
	m_publisher.OnRead(Any::AnotherKey(), Default::ReadId());

	auto& expectation = EXPECT_CALL(m_mockService, Reply(Default::Key(), _));
	EXPECT_CALL(m_mockService, Reply(Any::AnotherKey(), _)).After(expectation);
	m_mockSharkByte.SetValue(Any::ValidData());
}
TEST_F(RefreshableSharkByteReadServerTest, OnValueChanged_OnlyRepliesForEachKeyOnce)
{
	CallInitialize();
	m_publisher.OnRead(Default::Key(), Default::ReadId());

	m_mockSharkByte.SetValue(Any::ValidData());

	EXPECT_CALL(m_mockService, Reply(_, _)).Times(0);
	m_mockSharkByte.SetValue(Any::ValidData());
}
}
}