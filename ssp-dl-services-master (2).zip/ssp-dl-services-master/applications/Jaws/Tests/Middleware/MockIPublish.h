/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IPublish

#pragma once

#include <IPublishParameter.h>
#include <Utilities/DataEngineMock.h>

namespace middleware
{
namespace parameter
{
class MockIPublish : public IPublish
{
	EnsureMockKindIsSpecified(MockIPublish);
public:
    MOCK_METHOD(void,                        Publish,  (Data const &data), (override));
    MOCK_METHOD(std::string,                 Identity, (),                 (override));
    MOCK_METHOD(middleware::parameter::Unit, Unit,     (),                 (override));
};
}
}