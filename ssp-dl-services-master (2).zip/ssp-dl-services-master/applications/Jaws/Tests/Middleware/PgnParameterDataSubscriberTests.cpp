/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PgnParameterDataSubscriber tests

#include "Middleware/PgnParameterDataSubscriber.cpp"
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Utilities/TestUtilities.h>

using namespace testing;
using namespace middleware::parameter;
using namespace Shark::Mocks;

namespace Jaws
{
namespace Middleware
{
namespace
{
struct Any
{
	static constexpr char const* PgnSubscribeId() { return "pgn_publish_id"; }
	static std::vector<uint8_t> Data() { return {{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}}; }
	static std::vector<uint8_t> ShortData() { return {{0x01, 0x02, 0x03, 0x04}}; }
};

class PgnParameterDataSubscriberTest : public Test
{
protected:
	PgnParameterDataSubscriberTest()
	{
		ON_CALL(m_mockWriteSharkByteRetriever, Retrieve(Any::PgnSubscribeId()))
			.WillByDefault(ReturnRef(m_mockWriteSharkByte));
	}

	void CallInitialize()
	{
		m_dataSubscriber.Initialize(m_mockWriteSharkByteRetriever);
	}
	Data CreateData(std::vector<uint8_t> const& inputData)
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_binary_value(inputData.data(), inputData.size());
		return data;
	}
	void CallOnSubscriptionDataReceived(Data const& data)
	{
		m_dataSubscriber.OnSubscriptionDataReceived(Any::PgnSubscribeId(), data);
	}
	void CallOnDisconnect()
	{
		m_dataSubscriber.OnDisconnect();
	}

	NiceMock<MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<MockIWriteSharkByte> m_mockWriteSharkByte{};

	PgnParameterDataSubscriber m_dataSubscriber{Any::PgnSubscribeId()};
};
TEST_F(PgnParameterDataSubscriberTest, DefaultPgnDataIsEightBytesOf0xFF)
{
	EXPECT_THAT(n_defaultPgnData, ElementsAreArray({0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
}
TEST_F(PgnParameterDataSubscriberTest, InitializeRetrievesWriteSharkByteThatMatchesPgnSubscribeId)
{
	EXPECT_CALL(m_mockWriteSharkByteRetriever, Retrieve(Any::PgnSubscribeId()));
	CallInitialize();
}
TEST_F(PgnParameterDataSubscriberTest, OnSubscription_WritesPgnDataToSharkByte)
{
	CallInitialize();
	EXPECT_CALL(m_mockWriteSharkByte, Write(Any::Data(), NotNull()));
	CallOnSubscriptionDataReceived(CreateData(Any::Data()));
}
TEST_F(PgnParameterDataSubscriberTest, OnSubscription_DoesNotWriteToSharkByteIfDataIsNotBinary)
{
	CallInitialize();
	Data emptyData{};

	EXPECT_CALL(m_mockWriteSharkByte, Write(_, _)).Times(0);
	CallOnSubscriptionDataReceived(emptyData);
}
TEST_F(PgnParameterDataSubscriberTest, OnSubscription_WritesPaddedDataToSharkByteIfDataIsShorterThanEightBytes)
{
	CallInitialize();
	auto expectedPaddedData = Any::ShortData();
	expectedPaddedData.reserve(8);
	expectedPaddedData.resize(8, 0xFF);
	EXPECT_CALL(m_mockWriteSharkByte, Write(expectedPaddedData, _));
	CallOnSubscriptionDataReceived(CreateData(Any::ShortData()));
}
TEST_F(PgnParameterDataSubscriberTest, OnDisconnect_WritesDefaultPgnDataToSharkByte)
{
	CallInitialize();
	EXPECT_CALL(m_mockWriteSharkByte, Write(n_defaultPgnData, NotNull()));
	CallOnDisconnect();
}
}
}
}