/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PgnParameterDataPublisher tests

#include "Middleware/PgnParameterDataPublisher.cpp"
#include "MockIPublish.h"
#include "MockIService.h"
#include <Shark/Mocks/MockISharkByteRetriever.h>
#include <Shark/Mocks/MockISharkByte.h>
#include <Utilities/TestUtilities.h>

using namespace testing;
using namespace middleware::parameter;

namespace Jaws
{
using namespace Identifiers;

namespace Middleware
{
namespace
{
struct Any
{
	static constexpr char const* PgnPublishId() { return "pgn_publish_id"; }
	static constexpr char const* SpnPublishId() { return "spn_publish_id"; }
	static constexpr unsigned Pgn()             { return 0xFEEE; }
	static constexpr unsigned Spn()             { return 110; }
	static constexpr unsigned BitOffset()       { return 16; }
	static constexpr unsigned BitCount()        { return 8; }
	static std::vector<uint8_t> ValidData()     { return {{0x40}, {0x41}, {0x42}, {0x43}, {0x44}, {0x45}, {0x46}, {0x47}}; }
	static constexpr double DoubleValue()       { return 26.0; }
};
cat::shark::PgnEntry CreatePgnEntry()
{
	cat::shark::PgnEntry pgnEntry{};
	pgnEntry.set_pgn(Any::Pgn());
	auto& spnEntry = *pgnEntry.add_offset_spns();
	spnEntry.set_spn(Any::Spn());
	spnEntry.set_bit_offset(Any::BitOffset());
	return pgnEntry;
}
cat::shark::PgnEntry const n_pgnEntry{ CreatePgnEntry() };
constexpr PgnDefinition const n_pgnDefinition{ n_pgnEntry };
cat::shark::SpnEntry CreateSpnEntry()
{
	cat::shark::SpnEntry spnEntry{};
	spnEntry.set_spn(Any::Spn());
	spnEntry.set_bit_count(Any::BitCount());
	spnEntry.set_scaling(1.0);
	spnEntry.set_offset(-40);
	spnEntry.set_data_presentation_type(cat::shark::DATA_PRESENTATION_TYPE_DOUBLE);
	return spnEntry;
}
cat::shark::SpnEntry const n_spnEntry{ CreateSpnEntry() };
constexpr SpnDefinition const n_spnDefinition{ n_spnEntry };
}
class PgnParameterDataPublisherTest : public Test
{
protected:
	PgnParameterDataPublisherTest()
	{
		ON_CALL(m_mockService, RetrievePublisherInstance(Any::PgnPublishId()))
			.WillByDefault(ReturnRef(m_mockPgnPublish));
		ON_CALL(m_mockService, RetrievePublisherInstance(Any::SpnPublishId()))
			.WillByDefault(ReturnRef(m_mockSpnPublish));
		ON_CALL(m_mockSharkByteRetriever, Retrieve(Any::PgnPublishId()))
			.WillByDefault(ReturnRef(m_mockSharkByte.GetMock()));
		ON_CALL(m_mockPgnPublish, Publish(_))
			.WillByDefault(SaveArg<0>(&m_publishedPgnData));
		ON_CALL(m_mockSpnPublish, Publish(_))
			.WillByDefault(SaveArg<0>(&m_publishedSpnData));

		CreatePgnParameterDataPublisher();
	}

	void CreatePgnParameterDataPublisher()
	{
		SpnPublishers spnPublishers{};
		auto const bitOffset = Any::BitOffset();
		spnPublishers.push_back({
				Any::SpnPublishId(),
				bitOffset,
				CreateDataMask(bitOffset, n_spnDefinition),
				n_spnDefinition});
		m_spPgnParameterDataPublisher = std::make_unique<PgnParameterDataPublisher>(
			Any::PgnPublishId(),
			n_pgnDefinition,
			std::move(spnPublishers));
	}
	void CallInitialize()
	{
		m_spPgnParameterDataPublisher->Initialize(m_mockSharkByteRetriever, m_mockService);
	}

	NiceMock<MockIPublish> m_mockPgnPublish{};
	NiceMock<MockIPublish> m_mockSpnPublish{};
	NiceMock<MockIService> m_mockService{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	Shark::Mocks::MockSharkByteWrapper m_mockSharkByte{};

	std::unique_ptr<PgnParameterDataPublisher> m_spPgnParameterDataPublisher{};
	Data m_publishedPgnData{};
	Data m_publishedSpnData{};
};
TEST_F(PgnParameterDataPublisherTest, Initialize_RetrievesMiddlewarePublisherForTheConfiguredPgnAndSpns)
{
	EXPECT_CALL(m_mockService, RetrievePublisherInstance(Any::PgnPublishId()));
	EXPECT_CALL(m_mockService, RetrievePublisherInstance(Any::SpnPublishId()));
	CallInitialize();
}
TEST_F(PgnParameterDataPublisherTest, Initialize_RetrievesSharkByteForEachConfiguredPgn)
{
	EXPECT_CALL(m_mockSharkByteRetriever, Retrieve(Any::PgnPublishId()));
	CallInitialize();
}
TEST_F(PgnParameterDataPublisherTest, Initialize_SubscribesToEachSharkByteForEachConfiguredPgnPublishId)
{
	m_mockSharkByte.ExpectThatSubscribeOccurs([this]{ CallInitialize(); });
}
TEST_F(PgnParameterDataPublisherTest, SharkByteCallback_PublishesEmptyPgnDataWithQualityNotReceivedToMiddlewareAfterInitialize)
{
	CallInitialize();

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	EXPECT_THAT(m_publishedPgnData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(PgnParameterDataPublisherTest, SharkByteCallback_PublishesEmptySpnDataWithQualityNotReceivedToMiddlewareAfterInitialize)
{
	CallInitialize();

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	EXPECT_THAT(m_publishedSpnData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(PgnParameterDataPublisherTest, SharkByteCallback_PublishesPopulatedPgnDataWithQualityGoodToMiddlewareAfterSetOfValidValue)
{
	CallInitialize();
	m_mockSharkByte.SetValue(Any::ValidData());

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedData.mutable_value()->set_binary_value(Any::ValidData().data(), Any::ValidData().size());
	EXPECT_THAT(m_publishedPgnData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(PgnParameterDataPublisherTest, SharkByteCallback_PublishesPopulatedSpnDataWithQualityGoodToMiddlewareAfterSetOfValidValue)
{
	CallInitialize();
	m_mockSharkByte.SetValue(Any::ValidData());

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedData.mutable_value()->set_double_value(Any::DoubleValue());
	EXPECT_THAT(m_publishedSpnData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(PgnParameterDataPublisherTest, SharkByteCallback_PublishesEmptyPgnDataWithQualityNotReceivedToMiddlewareAfterSetOfInvalidValue)
{
	CallInitialize();
	m_mockSharkByte.SetValue(Any::ValidData());
	m_mockSharkByte.SetInvalid();

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	EXPECT_THAT(m_publishedPgnData, Utilities::ProtobufEquals(expectedData));
}
TEST_F(PgnParameterDataPublisherTest, SharkByteCallback_PublishesEmptySpnDataWithQualityNotReceivedToMiddlewareAfterSetOfInvalidValue)
{
	CallInitialize();
	m_mockSharkByte.SetValue(Any::ValidData());
	m_mockSharkByte.SetInvalid();

	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_NOT_RECEIVED);
	EXPECT_THAT(m_publishedSpnData, Utilities::ProtobufEquals(expectedData));
}

namespace
{
struct SpnPublishParameter
{
	unsigned bitOffset;
	unsigned bitCount;
	double unitsPerBit;
	double valueOffset;

	uint64_t receivedPgnData;
	double expectedDoubleValue;

	std::vector<uint8_t> GetPgnData() const
	{
		std::vector<uint8_t> pgnData(sizeof(uint64_t));
		std::memcpy(pgnData.data(), &receivedPgnData, sizeof(uint64_t));
		return pgnData;
	}
};
constexpr SpnPublishParameter n_spnPublishParametersWithVaryingBitOffsets[]
{
	{  0,  8, 1.0, 0.0, 0x4746454443424140, 64.0 },
	{  8,  8, 1.0, 0.0, 0x4746454443424140, 65.0 },
	{ 16,  8, 1.0, 0.0, 0x4746454443424140, 66.0 },
	{ 24,  8, 1.0, 0.0, 0x4746454443424140, 67.0 },
	{ 32,  8, 1.0, 0.0, 0x4746454443424140, 68.0 },
	{ 40,  8, 1.0, 0.0, 0x4746454443424140, 69.0 },
	{ 48,  8, 1.0, 0.0, 0x4746454443424140, 70.0 },
	{ 56,  8, 1.0, 0.0, 0x4746454443424140, 71.0 },
};
constexpr SpnPublishParameter n_spnPublishParametersWithVaryingBitCounts[]
{
	{  0,  1, 1.0, 0.0, 0x8877665544332211,          1.0 },
	{  0,  2, 1.0, 0.0, 0x8877665544332211,          1.0 },
	{  0,  4, 1.0, 0.0, 0x8877665544332211,          1.0 },
	{  0,  8, 1.0, 0.0, 0x8877665544332211,         17.0 },
	{  0, 16, 1.0, 0.0, 0x8877665544332211,       8721.0 },
	{  0, 24, 1.0, 0.0, 0x8877665544332211,    3351057.0 },
	{  0, 32, 1.0, 0.0, 0x8877665544332211, 1144201745.0 },
	{ 32,  1, 1.0, 0.0, 0x8877665544332211,          1.0 },
	{ 32,  2, 1.0, 0.0, 0x8877665544332211,          1.0 },
	{ 32,  4, 1.0, 0.0, 0x8877665544332211,          5.0 },
	{ 32,  8, 1.0, 0.0, 0x8877665544332211,         85.0 },
	{ 32, 16, 1.0, 0.0, 0x8877665544332211,      26197.0 },
	{ 32, 24, 1.0, 0.0, 0x8877665544332211,    7824981.0 },
	{ 32, 32, 1.0, 0.0, 0x8877665544332211, 2289526357.0 },
};
constexpr SpnPublishParameter n_spnPublishParametersWithVaryingScaleFactors[]
{
	{  0,  8, 0.5, 0.0, 0x8877665544332211,          8.5 },
	{  0,  8, 2.0, 0.0, 0x8877665544332211,         34.0 },
	{  0, 16, 0.5, 0.0, 0x8877665544332211,       4360.5 },
	{  0, 16, 2.0, 0.0, 0x8877665544332211,      17442.0 },
	{  0, 24, 0.5, 0.0, 0x8877665544332211,    1675528.5 },
	{  0, 24, 2.0, 0.0, 0x8877665544332211,    6702114.0 },
	{  0, 32, 0.5, 0.0, 0x8877665544332211,  572100872.5 },
	{  0, 32, 2.0, 0.0, 0x8877665544332211, 2288403490.0 },
	{ 32,  8, 0.5, 0.0, 0x8877665544332211,         42.5 },
	{ 32,  8, 2.0, 0.0, 0x8877665544332211,        170.0 },
	{ 32, 16, 0.5, 0.0, 0x8877665544332211,      13098.5 },
	{ 32, 16, 2.0, 0.0, 0x8877665544332211,      52394.0 },
	{ 32, 24, 0.5, 0.0, 0x8877665544332211,    3912490.5 },
	{ 32, 24, 2.0, 0.0, 0x8877665544332211,   15649962.0 },
	{ 32, 32, 0.5, 0.0, 0x8877665544332211, 1144763178.5 },
	{ 32, 32, 2.0, 0.0, 0x8877665544332211, 4579052714.0 },
};
constexpr SpnPublishParameter n_spnPublishParametersWithVaryingNegativeScaleOffsets[]
{
	{  0,  1, 1.0, -42.0, 0x8877665544332211,        -41.0 },
	{  0,  2, 1.0, -42.0, 0x8877665544332211,        -41.0 },
	{  0,  4, 1.0, -42.0, 0x8877665544332211,        -41.0 },
	{  0,  8, 1.0, -42.0, 0x8877665544332211,        -25.0 },
	{  0, 16, 1.0, -42.0, 0x8877665544332211,       8679.0 },
	{  0, 24, 1.0, -42.0, 0x8877665544332211,    3351015.0 },
	{  0, 32, 1.0, -42.0, 0x8877665544332211, 1144201703.0 },
	{ 32,  1, 1.0, -42.0, 0x8877665544332211,        -41.0 },
	{ 32,  2, 1.0, -42.0, 0x8877665544332211,        -41.0 },
	{ 32,  4, 1.0, -42.0, 0x8877665544332211,        -37.0 },
	{ 32,  8, 1.0, -42.0, 0x8877665544332211,         43.0 },
	{ 32, 16, 1.0, -42.0, 0x8877665544332211,      26155.0 },
	{ 32, 24, 1.0, -42.0, 0x8877665544332211,    7824939.0 },
	{ 32, 32, 1.0, -42.0, 0x8877665544332211, 2289526315.0 },
};
constexpr SpnPublishParameter n_spnPublishParametersWithVaryingPositiveScaleOffsets[]
{
	{  0,  1, 1.0, 42.0, 0x8877665544332211,         43.0 },
	{  0,  2, 1.0, 42.0, 0x8877665544332211,         43.0 },
	{  0,  4, 1.0, 42.0, 0x8877665544332211,         43.0 },
	{  0,  8, 1.0, 42.0, 0x8877665544332211,         59.0 },
	{  0, 16, 1.0, 42.0, 0x8877665544332211,       8763.0 },
	{  0, 24, 1.0, 42.0, 0x8877665544332211,    3351099.0 },
	{  0, 32, 1.0, 42.0, 0x8877665544332211, 1144201787.0 },
	{ 32,  1, 1.0, 42.0, 0x8877665544332211,         43.0 },
	{ 32,  2, 1.0, 42.0, 0x8877665544332211,         43.0 },
	{ 32,  4, 1.0, 42.0, 0x8877665544332211,         47.0 },
	{ 32,  8, 1.0, 42.0, 0x8877665544332211,        127.0 },
	{ 32, 16, 1.0, 42.0, 0x8877665544332211,      26239.0 },
	{ 32, 24, 1.0, 42.0, 0x8877665544332211,    7825023.0 },
	{ 32, 32, 1.0, 42.0, 0x8877665544332211, 2289526399.0 },
};
}
class PgnParameterDataPublisherDataTest : public TestWithParam<SpnPublishParameter>
{
public:
	struct Default
	{
		static constexpr unsigned Pgn() { return 0xFEEE; }
		static constexpr unsigned Spn() { return 110; }
	};

	PgnParameterDataPublisherDataTest()
	{
		ON_CALL(m_mockService, RetrievePublisherInstance(_))
			.WillByDefault(ReturnRef(m_mockPublish));
		ON_CALL(m_mockSharkByteRetriever, Retrieve(_))
			.WillByDefault(ReturnRef(m_mockSharkByte.GetMock()));
	}

	void SetDoubleExpectations(Data const& data, double expectedValue)
	{
		Data expectedData{};
		expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		expectedData.mutable_value()->set_double_value(expectedValue);
		EXPECT_THAT(data, Utilities::ProtobufEquals(expectedData));
	}
	void SetUnsignedExpectations(Data const& data, double expectedValue)
	{
		Data expectedData{};
		expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		expectedData.mutable_value()->set_uinteger64_value(static_cast<uint64_t>(expectedValue));
		EXPECT_THAT(data, Utilities::ProtobufEquals(expectedData));
	}
	void RunTest(cat::shark::DataPresentationType type)
	{
		auto&& param = GetParam();

		auto bitOffset = param.bitOffset;
		m_pgnEntry.set_pgn(Default::Pgn());
		auto& offsetSpn = *m_pgnEntry.add_offset_spns();
		offsetSpn.set_spn(Default::Spn());
		offsetSpn.set_bit_offset(bitOffset);
		m_spnEntry.set_spn(Default::Spn());
		m_spnEntry.set_unit(cat::shark::UNIT_NONE);
		m_spnEntry.set_bit_count(param.bitCount);
		m_spnEntry.set_data_presentation_type(type);
		m_spnEntry.set_scaling(param.unitsPerBit);
		m_spnEntry.set_offset(param.valueOffset);

		SpnPublishers spnPublishers{};
		spnPublishers.push_back({
				Any::SpnPublishId(),
				bitOffset,
				CreateDataMask(bitOffset, m_spnDefinition),
				m_spnDefinition});
		m_spPgnParameterDataPublisher = std::make_unique<PgnParameterDataPublisher>(
			Any::PgnPublishId(),
			m_pgnDefinition,
			std::move(spnPublishers));

		m_spPgnParameterDataPublisher->Initialize(m_mockSharkByteRetriever, m_mockService);

		Data data{};
		ON_CALL(m_mockPublish, Publish(_))
			.WillByDefault(SaveArg<0>(&data));

		m_pgnData = param.GetPgnData();
		m_mockSharkByte.SetValue(m_pgnData);

		switch (type)
		{
			case cat::shark::DATA_PRESENTATION_TYPE_DOUBLE:
				SetDoubleExpectations(data, param.expectedDoubleValue);
				break;
			case cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED:
				SetUnsignedExpectations(data, param.expectedDoubleValue);
				break;
			default:
				assert(true);
				break;
		}
	}

	NiceMock<MockIPublish> m_mockPublish{};
	NiceMock<MockIService> m_mockService{};
	NiceMock<Shark::Mocks::MockISharkByteRetriever> m_mockSharkByteRetriever{};
	Shark::Mocks::MockSharkByteWrapper m_mockSharkByte{};

	cat::shark::PgnEntry m_pgnEntry{};
	PgnDefinition m_pgnDefinition{m_pgnEntry};
	cat::shark::SpnEntry m_spnEntry{};
	SpnDefinition m_spnDefinition{m_spnEntry};
	std::vector<uint8_t> m_pgnData{};

	std::unique_ptr<PgnParameterDataPublisher> m_spPgnParameterDataPublisher{};
};

class DoublePgnParameterDataPublisherDataTest : public PgnParameterDataPublisherDataTest {};
INSTANTIATE_TEST_SUITE_P(VaryingBitOffsets, DoublePgnParameterDataPublisherDataTest, ValuesIn(n_spnPublishParametersWithVaryingBitOffsets));
INSTANTIATE_TEST_SUITE_P(VaryingBitCounts, DoublePgnParameterDataPublisherDataTest, ValuesIn(n_spnPublishParametersWithVaryingBitCounts));
INSTANTIATE_TEST_SUITE_P(VaryingScaleFactors, DoublePgnParameterDataPublisherDataTest, ValuesIn(n_spnPublishParametersWithVaryingScaleFactors));
INSTANTIATE_TEST_SUITE_P(VaryingScaleNegativeOffsets, DoublePgnParameterDataPublisherDataTest, ValuesIn(n_spnPublishParametersWithVaryingNegativeScaleOffsets));
TEST_P(DoublePgnParameterDataPublisherDataTest, Publisher_CreatesCorrectProtobufData)
{
	RunTest(cat::shark::DATA_PRESENTATION_TYPE_DOUBLE);
}

class UintPgnParameterDataPublisherDataTest : public PgnParameterDataPublisherDataTest {};
INSTANTIATE_TEST_SUITE_P(VaryingBitOffsets, UintPgnParameterDataPublisherDataTest, ValuesIn(n_spnPublishParametersWithVaryingBitOffsets));
INSTANTIATE_TEST_SUITE_P(VaryingBitCounts, UintPgnParameterDataPublisherDataTest, ValuesIn(n_spnPublishParametersWithVaryingBitCounts));
INSTANTIATE_TEST_SUITE_P(VaryingScaleFactors, UintPgnParameterDataPublisherDataTest, ValuesIn(n_spnPublishParametersWithVaryingScaleFactors));
INSTANTIATE_TEST_SUITE_P(VaryingScalePositiveOffsets, UintPgnParameterDataPublisherDataTest, ValuesIn(n_spnPublishParametersWithVaryingPositiveScaleOffsets));
TEST_P(UintPgnParameterDataPublisherDataTest, Publisher_CreatesCorrectProtobufData)
{
	RunTest(cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED);
}
}
}