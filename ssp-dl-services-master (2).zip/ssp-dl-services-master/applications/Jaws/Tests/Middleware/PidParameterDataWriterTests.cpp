/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PidParameterDataWriter tests

#include "Middleware/PidParameterDataWriter.cpp"

#include "Identifiers/MockIPidValueEncoder.h"
#include "MockIService.h"
#include <Shark/Mocks/MockIWriteSharkByteRetriever.h>
#include <Shark/Mocks/MockIWriteSharkByte.h>
#include <Utilities/TestUtilities.h>

using namespace testing;
using namespace middleware::parameter;

namespace Jaws
{
using namespace Identifiers;

namespace Middleware
{
namespace
{
struct Any
{
	static constexpr uint_least16_t AnotherKey() { return 99; }
	static constexpr std::vector<uint8_t> ValidData() { return {0x40, 0x41}; }
};
}

class PidParameterDataWriterTest : public Test
{
protected:
	struct Default
	{
		static constexpr char const* WriteId() { return "write id"; }
		static constexpr uint_least16_t Key() { return 42; }
		static constexpr std::vector<uint8_t> EncodedData() { return {0x97, 0x96}; }
	};

	PidParameterDataWriterTest()
	{
		ON_CALL(m_mockWriteSharkByteRetriever, Retrieve(Default::WriteId()))
			.WillByDefault(ReturnRef(m_mockWriteSharkByte));
		ON_CALL(m_mockWriteSharkByte, Write(_, _))
			.WillByDefault(Invoke([this](std::vector<uint8_t> const& writeData, std::function<void(Shark::SharkByteValue const&)> callback)
				{
					m_writeData.emplace(writeData);
					m_writeCallback = std::move(callback);
				}));
		ON_CALL(m_mockPidValueEncoder, Encode(_, _))
			.WillByDefault(Return(IPidValueEncoder::ExpectedType{Default::EncodedData()}));
	}

	void CreateAndInitialize()
	{
		PopulatePidEntry();
		m_spPidParameterDataWriter = std::make_unique<PidParameterDataWriter>(
			Default::WriteId(),
			Identifiers::PidDefinition{m_pidEntry},
			m_mockPidValueEncoder);
		m_spPidParameterDataWriter->Initialize(m_mockWriteSharkByteRetriever, m_mockService);
	}
	void PopulatePidEntry()
	{
		m_pidEntry.set_pid(0xD10101);
		m_pidEntry.set_byte_count(m_byteCount);
		m_pidEntry.set_is_signed(m_isSigned);
		m_pidEntry.set_is_dsi_supported(true);
		m_pidEntry.set_scaling(m_scaling);
		m_pidEntry.set_unit(cat::shark::UNIT_NONE);
		m_pidEntry.set_is_lsb(m_isLsb);
		m_pidEntry.set_data_presentation_type(m_dataType);
	}
	Data MakeMiddlewareData(std::vector<uint8_t> const& binaryValue) const
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_binary_value(binaryValue.data(), binaryValue.size());
		return data;
	}
	std::optional<Data> CallWrite()
	{
		return m_spPidParameterDataWriter->OnWrite(Default::Key(), Default::WriteId(), MakeMiddlewareData(Any::ValidData()));
	}
	std::optional<Data> CallWriteWithInvalidData()
	{
		return m_spPidParameterDataWriter->OnWrite(Default::Key(), Default::WriteId(), Data{});
	}

	NiceMock<MockIService> m_mockService{};
	NiceMock<MockIPidValueEncoder> m_mockPidValueEncoder{};
	NiceMock<Shark::Mocks::MockIWriteSharkByteRetriever> m_mockWriteSharkByteRetriever{};
	NiceMock<Shark::Mocks::MockIWriteSharkByte> m_mockWriteSharkByte{};
	std::function<void(Shark::SharkByteValue const&)> m_writeCallback;
	std::optional<std::vector<uint8_t>> m_writeData{};

	cat::shark::PidEntry m_pidEntry{};
	unsigned m_byteCount{2};
	bool m_isSigned{false};
	double m_scaling{1.0};
	bool m_isLsb{true};
	cat::shark::DataPresentationType m_dataType{cat::shark::DATA_PRESENTATION_TYPE_BINARY};
	std::unique_ptr<PidParameterDataWriter> m_spPidParameterDataWriter{};
};
TEST_F(PidParameterDataWriterTest, Initialize_RetrievesWriteSharkByteFromRetrieverWithTheCorrectId)
{
	EXPECT_CALL(m_mockWriteSharkByteRetriever, Retrieve(Default::WriteId()));
	CreateAndInitialize();
}
TEST_F(PidParameterDataWriterTest, OnWrite_EncodesTheData)
{
	CreateAndInitialize();
	EXPECT_CALL(m_mockPidValueEncoder,
		Encode(
			Identifiers::PidDefinition{m_pidEntry},
			VariantWith<std::vector<uint8_t>>(ElementsAreArray(Any::ValidData()))));
	CallWrite();
}
TEST_F(PidParameterDataWriterTest, OnWrite_CallsWriteOnTheWriteSharkByteWithTheEncodedData)
{
	CreateAndInitialize();
	EXPECT_CALL(m_mockWriteSharkByte, Write(ElementsAreArray(Default::EncodedData()), _));
	CallWrite();
}
TEST_F(PidParameterDataWriterTest, OnWrite_ReturnsNulloptToInitiateAsyncMode)
{
	CreateAndInitialize();
	auto const result = CallWrite();
	EXPECT_THAT(result, Eq(std::nullopt));
}
TEST_F(PidParameterDataWriterTest, OnWrite_ReturnsDataWithBadQualityIfDataIsInvalid)
{
	CreateAndInitialize();
	auto const result = CallWriteWithInvalidData();
	ASSERT_TRUE(result);
	EXPECT_THAT(result->quality(), Eq(cat::middleware::parameter::Quality::QUALITY_BAD));
}
TEST_F(PidParameterDataWriterTest, OnWrite_ReturnsDataWithBadQualityIfThereIsAlreadyAnActiveWrite)
{
	CreateAndInitialize();
	CallWrite();
	auto const result = CallWrite();
	ASSERT_TRUE(result);
	EXPECT_THAT(result->quality(), Eq(cat::middleware::parameter::Quality::QUALITY_BAD));
}
TEST_F(PidParameterDataWriterTest, OnWriteCompleted_RepliesWithTheWriteKey)
{
	CreateAndInitialize();
	CallWrite();
	EXPECT_CALL(m_mockService, Reply(Default::Key(), _));
	m_writeCallback(Any::ValidData());
}
TEST_F(PidParameterDataWriterTest, OnWriteCompleted_RepliesWithBinaryValue)
{
	auto const sharkByteData = Any::ValidData();
	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
	expectedData.mutable_value()->set_binary_value(sharkByteData.data(), sharkByteData.size());

	CreateAndInitialize();
	CallWrite();
	EXPECT_CALL(m_mockService, Reply(_, Utilities::ProtobufEquals(expectedData)));

	m_writeCallback(sharkByteData);
}
TEST_F(PidParameterDataWriterTest, OnWriteCompleted_Invalid_RepliesWithBadQuality)
{
	Data expectedData{};
	expectedData.set_quality(cat::middleware::parameter::Quality::QUALITY_BAD);

	CreateAndInitialize();
	CallWrite();
	EXPECT_CALL(m_mockService, Reply(_, Utilities::ProtobufEquals(expectedData)));

	m_writeCallback(std::nullopt);
}

namespace
{
struct TestWriteResponseData
{
	unsigned byteCount;
	double scaling;
	uint8_t dataLinkBytes[4];
	Data expectedData;

	std::vector<uint8_t> GetLsbData() const noexcept
	{
		return std::vector<uint8_t>(dataLinkBytes, dataLinkBytes + byteCount);
	}
	std::vector<uint8_t> GetMsbData() const noexcept
	{
		auto data = GetLsbData();
		std::reverse(std::begin(data), std::begin(data) + byteCount);
		return data;
	}
	static Data MakeBinaryData(std::vector<uint8_t> const& bytes)
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_binary_value(bytes.data(), bytes.size());
		return data;
	}
	static Data MakeDoubleData(double value)
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_double_value(value);
		return data;
	}
	static Data MakeUintData(uint64_t value)
	{
		Data data{};
		data.set_quality(cat::middleware::parameter::Quality::QUALITY_GOOD);
		data.mutable_value()->set_uinteger64_value(value);
		return data;
	}
};

TestWriteResponseData const n_testWriteResponseData[]
{
	{ 1, 1.0, {0x42},                   TestWriteResponseData::MakeBinaryData({0x42}) },
	{ 2, 1.0, {0x40, 0x41},             TestWriteResponseData::MakeBinaryData({0x40, 0x41}) },
	{ 4, 1.0, {0x40, 0x41, 0x42, 0x43}, TestWriteResponseData::MakeBinaryData({0x40, 0x41, 0x42, 0x43}) },

	{ 1, 1.0, {0x01},                   TestWriteResponseData::MakeDoubleData(1.0) },
	{ 1, 0.5, {0x04},                   TestWriteResponseData::MakeDoubleData(2.0) },
	{ 2, 1.0, {0x01, 0x00},             TestWriteResponseData::MakeDoubleData(1.0) },
	{ 2, 0.5, {0x04, 0x00},             TestWriteResponseData::MakeDoubleData(2.0) },
	{ 4, 1.0, {0x01, 0x00, 0x00, 0x00}, TestWriteResponseData::MakeDoubleData(1.0) },
	{ 4, 0.5, {0x04, 0x00, 0x00, 0x00}, TestWriteResponseData::MakeDoubleData(2.0) },

	{ 1, 1.0, {0x2A},                   TestWriteResponseData::MakeUintData(42) },
	{ 1, 0.5, {0x04},                   TestWriteResponseData::MakeUintData(2) },
	{ 2, 1.0, {0x2A, 0x00},             TestWriteResponseData::MakeUintData(42) },
	{ 2, 0.5, {0x04, 0x00},             TestWriteResponseData::MakeUintData(2) },
	{ 4, 1.0, {0x2A, 0x00, 0x00, 0x00}, TestWriteResponseData::MakeUintData(42) },
	{ 4, 0.5, {0x04, 0x00, 0x00, 0x00}, TestWriteResponseData::MakeUintData(2) },
};
}

class PidParameterDataWriterResponseTest : public PidParameterDataWriterTest, public WithParamInterface<TestWriteResponseData>
{
protected:
	cat::shark::DataPresentationType GetDataType() const
	{
		cat::shark::DataPresentationType type{cat::shark::DATA_PRESENTATION_TYPE_BINARY};
		auto const typeOfDataToWrite = GetParam().expectedData.value().selection_case();
		if (typeOfDataToWrite == cat::middleware::parameter::Value::kDoubleValue)
		{
			type = cat::shark::DATA_PRESENTATION_TYPE_DOUBLE;
		}
		else if (typeOfDataToWrite == cat::middleware::parameter::Value::kUinteger64Value)
		{
			type = cat::shark::DATA_PRESENTATION_TYPE_UNSIGNED;
		}
		else
		{
			assert(typeOfDataToWrite == cat::middleware::parameter::Value::kBinaryValue);
		}
		return type;
	}
	void WriteData()
	{
		m_spPidParameterDataWriter->OnWrite(Default::Key(), Default::WriteId(), m_param.expectedData);
	}
	std::vector<uint8_t> GetDataLinkBytes(bool isLsb) const
	{
		if (GetDataType() == cat::shark::DATA_PRESENTATION_TYPE_BINARY)
		{
			return GetParam().GetLsbData();
		}
		else
		{
			return isLsb ? GetParam().GetLsbData() : GetParam().GetMsbData();
		}
	}
	void RunTest(bool isLsb)
	{
		m_byteCount = m_param.byteCount;
		m_isSigned = false;
		m_scaling = m_param.scaling;
		m_isLsb = isLsb;
		m_dataType = GetDataType();

		auto const& expectedDataLinkBytes = GetDataLinkBytes(isLsb);
		ON_CALL(m_mockPidValueEncoder, Encode(_, _))
			.WillByDefault(Return(IPidValueEncoder::ExpectedType{expectedDataLinkBytes}));

		CreateAndInitialize();
		WriteData();

		EXPECT_THAT(m_writeData, Optional(expectedDataLinkBytes));
		EXPECT_CALL(m_mockService, Reply(Default::Key(), Utilities::ProtobufEquals(m_param.expectedData)));
		m_writeCallback(expectedDataLinkBytes);
	}

	TestWriteResponseData const& m_param = GetParam();
};
INSTANTIATE_TEST_SUITE_P(WriteResponseTests, PidParameterDataWriterResponseTest, ValuesIn(n_testWriteResponseData));
TEST_P(PidParameterDataWriterResponseTest, OnWriteCompleted_RepliesWithExpectedResponseLsbData)
{
	RunTest(true);
}
TEST_P(PidParameterDataWriterResponseTest, OnWriteCompleted_RepliesWithExpectedResponseMsbData)
{
	RunTest(false);
}
}
}