/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IWriteReply

#pragma once

#include "Middleware/IWriteReply.h"
#include <Utilities/DataEngineMock.h>

namespace Jaws
{
namespace Middleware
{
class MockIWriteReply : public IWriteReply
{
	EnsureMockKindIsSpecified(MockIWriteReply);
public:
    MOCK_METHOD(void, Reply, (cat::middleware::parameter::Data const& data), (override));
};
}
}