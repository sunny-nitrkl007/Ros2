/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// ConfigLoader tests

#include "ConfigLoader.cpp"

#include "Nvm/MockINvmWrapper.h"
#include <Utilities/TestUtilities.h>

using namespace testing;

namespace Jaws
{
class ConfigLoaderTest : public Test
{
protected:
	struct Default
	{
		static constexpr std::string ValidConfigurationJson() { return R"({"pidEntries":[{"pid":123,"byteCount":2}]})"; }
	};

	ConfigLoaderTest()
	{
		ON_CALL(m_mockNvmWrapper, Read(std::string{Nvm::JawsConfigurationNvmId()}, _))
			.WillByDefault(ReturnPointee(&m_configJson));
	}

	NiceMock<Nvm::MockINvmWrapper> m_mockNvmWrapper{};
	std::string m_configJson{Default::ValidConfigurationJson()};

	ConfigLoader m_configLoader{};
};
TEST_F(ConfigLoaderTest, JawsConfigurationNvmId_IsDefinedProperly)
{
	static_assert(std::string_view{Nvm::JawsConfigurationNvmId()} == "Configuration");
}
TEST_F(ConfigLoaderTest, LoadFromNvm_ReadsTheConfigurationFromTheJawsConfigurationNvmId)
{
	EXPECT_CALL(m_mockNvmWrapper, Read(std::string{Nvm::JawsConfigurationNvmId()}, StrEq("")));
	m_configLoader.LoadFromNvm(m_mockNvmWrapper);
}
TEST_F(ConfigLoaderTest, LoadFromNvm_ParsesAValidConfiguration)
{
	auto const spSharkConfig = m_configLoader.LoadFromNvm(m_mockNvmWrapper);

	ASSERT_THAT(spSharkConfig, NotNull());
	EXPECT_THAT(spSharkConfig->pid_entries_size(), Eq(1));
	EXPECT_THAT(spSharkConfig->pid_entries(0).pid(), Eq(123));
}
TEST_F(ConfigLoaderTest, LoadFromNvm_ReturnsAnEmptyConfigurationWhenNvmIsBlank)
{
	ON_CALL(m_mockNvmWrapper, Read(_, _)).WillByDefault(Return(std::string{}));

	auto const spSharkConfig = m_configLoader.LoadFromNvm(m_mockNvmWrapper);

	ASSERT_THAT(spSharkConfig, NotNull());
	EXPECT_THAT(spSharkConfig->pid_entries_size(), Eq(0));
}
TEST_F(ConfigLoaderTest, LoadFromNvm_ReturnsNullptrWhenTheConfigurationIsNotValid)
{
	ON_CALL(m_mockNvmWrapper, Read(_, _)).WillByDefault(Return(std::string{"not valid json"}));

	auto const spSharkConfig = m_configLoader.LoadFromNvm(m_mockNvmWrapper);

	EXPECT_THAT(spSharkConfig, IsNull());
}
}
