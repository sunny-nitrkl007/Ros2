/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See FakeDependencyContainer.h

#include "FakeDependencyContainer.h"

namespace Jaws
{
namespace
{
template <typename T>
T& CreateBadReference()
{
	return *reinterpret_cast<T*>(0xBadF00d);
}
}

FakeDependencyContainer::FakeDependencyContainer()
	: m_spDependencyContainer(std::make_unique<DependencyContainer>(
		CreateBadReference<cat::shark::Config>(),
		m_mockEnvironment,
		m_mockFilesystem,
		CreateBadReference<Identifiers::IPidDefinitionRetriever>(),
		CreateBadReference<Identifiers::IPublicJ1939DefinitionRetriever>(),
		m_mockPidValueDecoder,
		m_mockPidValueEncoder,
		m_mockSharkByteRetriever,
		m_mockWriteSharkByteRetriever,
		m_mockNvmWrapper,
		CreateBadReference<IInitializationGate>(),
		m_sharkToMiddlewareDefinitions))
	, m_dependencyContainer(*m_spDependencyContainer)
{
}
FakeDependencyContainer::~FakeDependencyContainer() = default;
}
