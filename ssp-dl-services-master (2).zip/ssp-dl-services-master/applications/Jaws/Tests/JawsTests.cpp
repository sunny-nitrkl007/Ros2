/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See JawsTests.h

#include "Utilities/TemporaryFileRemoverEnvironment.h"
#include <boost/log/core.hpp>
#include <gmock/gmock.h>

#ifdef USE_ROS2
#include <rclcpp/rclcpp.hpp>
#endif

namespace
{
constexpr char const* n_temporaryFilePrefix = "Jaws_Tests";
}

int main(int argc, char* argv[])
{
	boost::log::core::get()->set_logging_enabled(false);

//#define DEBUGGING_TEST_EXCEPTIONS // Do not commit with this uncommented!
#ifdef DEBUGGING_TEST_EXCEPTIONS
	::testing::FLAGS_gtest_catch_exceptions = 0;
#endif

	testing::InitGoogleMock(&argc, argv);

#ifdef USE_ROS2
	rclcpp::init(argc, argv);
#endif

	Utilities::TemporaryFileRemoverEnvironment::CreateAndEnableRemover(n_temporaryFilePrefix);
	int const result = RUN_ALL_TESTS();

#ifdef USE_ROS2
	rclcpp::shutdown();
#endif

	return result;
}
