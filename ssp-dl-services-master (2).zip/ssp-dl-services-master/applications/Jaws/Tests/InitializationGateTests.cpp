/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// InitializationGate tests

#include "InitializationGate.cpp"
#include <future>

using namespace testing;

namespace Jaws
{
namespace
{
class InitializationGateTest : public Test
{
protected:
	InitializationGate m_gate{};
};
TEST_F(InitializationGateTest, IsNotReadyByDefault)
{
	EXPECT_FALSE(m_gate.IsReady());
}
TEST_F(InitializationGateTest, IsReadyAfterSetReady)
{
	m_gate.SetReady();
	EXPECT_TRUE(m_gate.IsReady());
}
TEST_F(InitializationGateTest, EnqueueOrExecute_ExecutesImmediatelyWithTrueWhenReady)
{
	m_gate.SetReady();

	NiceMock<MockFunction<void(bool)>> mockAction{};
	EXPECT_CALL(mockAction, Call(true));
	m_gate.EnqueueOrExecute(mockAction.AsStdFunction());
}
TEST_F(InitializationGateTest, EnqueueOrExecute_QueuesWhenNotReady)
{
	NiceMock<MockFunction<void(bool)>> mockAction{};
	EXPECT_CALL(mockAction, Call(_)).Times(0);
	m_gate.EnqueueOrExecute(mockAction.AsStdFunction());
}
TEST_F(InitializationGateTest, SetReady_ExecutesAllQueuedActionsWithFalse)
{
	auto const enqueueCount = 3;
	NiceMock<MockFunction<void(bool)>> mockAction{};
	EXPECT_CALL(mockAction, Call(false)).Times(enqueueCount);
	for (int i = 0; i < enqueueCount; ++i)
	{
		m_gate.EnqueueOrExecute(mockAction.AsStdFunction());
	}
	m_gate.SetReady();
}
TEST_F(InitializationGateTest, SetReady_ExecutesQueuedActionsInOrder)
{
	constexpr int n_actions{3};
	std::vector<NiceMock<MockFunction<void(bool)>>> mockActions(n_actions);
	{
		InSequence seq{};
		for (auto& mockAction : mockActions)
		{
			EXPECT_CALL(mockAction, Call(_));
		}
	}
	for (auto& mockAction : mockActions)
	{
		m_gate.EnqueueOrExecute(mockAction.AsStdFunction());
	}
	m_gate.SetReady();
}
TEST_F(InitializationGateTest, SetReady_ConcurrentEnqueueAndSetReady)
{
	std::atomic<int> count{0};
	constexpr int n_actionsPerThread{100};
	constexpr int n_threads{4};

	std::vector<std::future<void>> futures{};
	for (int i = 0; i < n_threads; ++i)
	{
		futures.push_back(std::async(std::launch::async, [&]
		{
			for (int j = 0; j < n_actionsPerThread; ++j)
			{
				m_gate.EnqueueOrExecute([&](bool) { ++count; });
			}
		}));
	}

	m_gate.SetReady();

	for (auto& future : futures)
	{
		future.get();
	}
	EXPECT_THAT(count.load(), Eq(n_threads * n_actionsPerThread));
}
TEST_F(InitializationGateTest, SetReady_ExecutesActionsEnqueuedDuringSetReady)
{
	std::vector<int> order{};
	m_gate.EnqueueOrExecute(
		[this, &order](bool)
		{
			order.push_back(1);
			m_gate.EnqueueOrExecute(
				[this, &order](bool)
				{
					order.push_back(3);
					m_gate.EnqueueOrExecute([&order](bool) { order.push_back(4); });
				});
		});
	m_gate.EnqueueOrExecute([&order](bool) { order.push_back(2); });

	m_gate.SetReady();
	EXPECT_THAT(order, ElementsAre(1, 2, 3, 4));
}
}
}
