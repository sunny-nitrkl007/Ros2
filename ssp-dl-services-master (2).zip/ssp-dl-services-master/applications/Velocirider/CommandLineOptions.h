/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// command-line options

#pragma once

#include <optional>
#include <string>

namespace Velocirider
{
class CommandLineOptions final
{
public:
	CommandLineOptions(bool useCan1);

	bool UseCan1() const { return m_useCan1; }
private:
	bool const m_useCan1;
};
}
