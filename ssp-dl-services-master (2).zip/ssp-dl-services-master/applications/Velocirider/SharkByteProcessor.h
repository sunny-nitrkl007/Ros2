/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Byte Processor

#pragma once

#include "Actions.h"
#include <Shark/ISharkByte.h>
#include <memory>
#include <string>
#include <vector>

namespace Velocirider
{
class CommandLineOptions;

struct SharkByteSubscriptionConfig
{
	char const* pId;
	SubscriptionAction subscriptionAction;
};
std::vector<SharkByteSubscriptionConfig> GetDefaultSharkBytes();

void HandleSpecialSharkByteValue(std::string const& sharkByteId, Shark::SharkByteValue const& value);
}