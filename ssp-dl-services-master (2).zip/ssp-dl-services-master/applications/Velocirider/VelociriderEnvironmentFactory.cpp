/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See VelociriderEnvironmentFactory.h

#include "VelociriderEnvironmentFactory.h"
#include "CommandLineOptions.h"
#include <Utilities/IFilesystem.h>
#include <Utilities/XmlUtilities.h>
#include <pugixml.hpp>

namespace Velocirider
{
namespace
{
constexpr auto n_pApplicationName = "Velocirider";
#ifdef DESKTOP_BUILD
constexpr auto n_pPersistentStoragePath = "/tmp/";
#else
constexpr auto n_pPersistentStoragePath = "/opt/appdata/Velocirider/";
#endif
}
class VelociriderEnvironment : public Utilities::IEnvironment
{
public:
// Utilities::IEnvironment
	std::string const& Application() const override { return m_applicationName; }
	std::string const& PersistentStoragePath() const override { return m_persistentStoragePath; }
private:
	std::string const m_applicationName{n_pApplicationName};
	std::string const m_persistentStoragePath{n_pPersistentStoragePath};
};

std::unique_ptr<Utilities::IEnvironment> VelociriderEnvironmentFactory::CreateEnvironment(Utilities::IFilesystem const& filesystem)
{
	auto spVelociriderEnvironment = std::make_unique<VelociriderEnvironment>();

	// Shark needs the NVM path to exist
	filesystem.CreateDirectories(
		spVelociriderEnvironment->DeletedOnApplicationChangePersistentStorageDirectory());

	return spVelociriderEnvironment;
}
}
