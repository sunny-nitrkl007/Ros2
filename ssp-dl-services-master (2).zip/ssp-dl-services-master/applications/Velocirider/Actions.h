/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Type of Shark Byte subscription

#pragma once

namespace Velocirider
{
enum class SubscriptionAction
{
	Describe,
	Special,

	Count
};
}
