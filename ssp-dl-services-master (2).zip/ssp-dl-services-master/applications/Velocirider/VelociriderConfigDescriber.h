/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Velocirider Application Config

#pragma once

#include <Config/IConfigDescriber.h>

namespace Velocirider
{
template <class T> using nice_ptr = Utilities::nice_ptr<T>;

class VelociriderConfigDescriber final : public Config::IConfigDescriber
{
public:
	VelociriderConfigDescriber(bool useCan1)
		: m_useCan1{useCan1}
	{
	}
// Config::IConfigDescriber
	nice_ptr<Config::SharkConfig const> GetSharkConfig() const override;
private:
	bool m_useCan1;
};
}
