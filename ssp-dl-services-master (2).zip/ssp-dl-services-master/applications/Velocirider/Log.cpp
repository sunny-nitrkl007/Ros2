/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Log.h

#include "Log.h"
#include <boost/log/sources/severity_logger.hpp>
#include <iostream>

namespace Log
{
enum class SeverityLevel;
void Flush()
{
	std::cout << std::flush;
}
}

boost::log::sources::severity_logger_mt<Log::SeverityLevel>& GetLogger()
{
	static boost::log::sources::severity_logger_mt<Log::SeverityLevel> s_logger;
	return s_logger;
}
