/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Velocirider: A simple Shark client

#include "CommandLineOptions.h"
#include "Log.h"
#include "SharkByteProcessor.h"
#include "VelociriderConfigDescriber.h"
#include "VelociriderEnvironmentFactory.h"
#include "VelociriderManager.h"
#include "WebSocketListener.h"
#include <Utilities/Filesystem.h>
#include <atomic>
#include <chrono>
#include <iostream>
#include <thread>
#include <signal.h>

namespace
{
using namespace Velocirider;
using namespace std::chrono_literals;

constexpr auto n_loopDelay = 5ms;

std::atomic<bool> n_quit{false};
void Quit(int)
{
	n_quit = true;
}

void QuitInit()
{
	for (auto signal : { SIGTERM, SIGINT } )
	{
		struct sigaction action;
		sigaction(signal, nullptr, &action);
		action.sa_handler = &Quit;
		sigaction(signal, &action, nullptr);
	}
}

void Run(CommandLineOptions const& commandLineOptions)
{
	QuitInit();

	Utilities::Filesystem filesystem{};
	auto spEnvironment = VelociriderEnvironmentFactory::CreateEnvironment(filesystem);
	auto spConfigDescriber = std::make_unique<VelociriderConfigDescriber>(commandLineOptions.UseCan1());
	auto spVelociriderManager = std::make_shared<VelociriderManager>(std::move(spEnvironment), std::move(spConfigDescriber));
	WebSocketListener WebSocketListener{spVelociriderManager};

	for (auto&& defaultSharkByte : GetDefaultSharkBytes())
	{
		spVelociriderManager->AddSharkByte(defaultSharkByte.pId, defaultSharkByte.subscriptionAction);
	}

	while (!n_quit)
	{
		auto subscriptionRequests = WebSocketListener.TakeSubscribeRequests();
		for (auto&& subscriptionRequest : subscriptionRequests)
		{
			spVelociriderManager->AddSharkByte(subscriptionRequest.first, subscriptionRequest.second);
		}

		auto writeRequests = WebSocketListener.TakeWriteRequests();
		for (auto&& writeRequest : writeRequests)
		{
			spVelociriderManager->WriteToSharkByte(writeRequest.first, writeRequest.second);
		}

		auto refreshRequests = WebSocketListener.TakeRefreshRequests();
		for (auto&& refreshRequest : refreshRequests)
		{
			spVelociriderManager->Refresh(refreshRequest);
		}

		Log::Flush(); // Ensure the log is flushed. Without this the debugger doesn't display all the output.
		std::this_thread::sleep_for(n_loopDelay);
	}
}
}

int main(int argc, char* argv[])
{
	auto result = 1;
	try
	{
		auto const getCommandLineOptions = ProcessCommandLine(argc, argv);
		Run(getCommandLineOptions());
		result = 0;
	}
	catch (std::exception const& exception)
	{
		std::cerr << "ERROR: " << exception.what() << std::endl;
	}
	catch(...)
	{
	}

	return result;
}
