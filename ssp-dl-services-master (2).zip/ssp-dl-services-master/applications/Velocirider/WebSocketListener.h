/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// The Velocirider WebSocketListener

#pragma once

#include "WebSockets/JsonWebSocket.h"
#include "Actions.h"
#include "VelociriderManager.h"
#include <Shark/ISharkByte.h>
#include <mutex>
#include <string>
#include <vector>

namespace Velocirider
{
class WebSocketListener
{
public:
	using SubscribeRequests = std::vector<std::pair<Shark::SharkByteId, SubscriptionAction>>;
	using WriteRequests = std::vector<std::pair<Shark::SharkByteId, std::vector<uint8_t>>>;
	using RefreshRequests = std::vector<Shark::SharkByteId>;

	WebSocketListener(std::shared_ptr<VelociriderManager> &velociriderManager);
	WriteRequests TakeWriteRequests();
	SubscribeRequests TakeSubscribeRequests();
	RefreshRequests TakeRefreshRequests();
private:
	void HandleDisplaySharkBytes(nlohmann::json const& displaySharkBytesJson);
	void HandleWriteSharkBytes(nlohmann::json const& writeSharkBytesJson);
	void HandleRefreshSharkBytes(nlohmann::json const& refreshSharkBytesJson);

	std::shared_ptr<VelociriderManager> m_velociriderManager{};
	std::shared_ptr<WebSockets::JsonWebSocket> m_spJsonWebSocket{};

	std::mutex m_mutex{};
	std::vector<WebSockets::JsonWebSocket::Deregisterer> m_deregisterers{};
	WriteRequests m_writeRequests{};
	SubscribeRequests m_subscribeRequests{};
	RefreshRequests m_refreshRequests{};
};
}
