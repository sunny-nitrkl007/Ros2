/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See WebSocketListener.h

#include "WebSocketListener.h"
#include <Utilities/ArrayToHexString.h>
#include <Utilities/HexStringConverter.h>
#include <simple-websocket-server/server_ws.hpp>

namespace Velocirider
{
WebSocketListener::WebSocketListener(std::shared_ptr<VelociriderManager> &velociriderManager)
	: m_velociriderManager(velociriderManager)
	, m_spJsonWebSocket{std::make_shared<WebSockets::JsonWebSocket>("/Velocirider", 8043)}
{
	// JavaScript for using this socket in web browser dev tools:
	//   var ws = new WebSocket("ws://localhost:8043/Velocirider");
	//   ws.send('{ "displaySharkBytes": { "sharkBytes": [ { "id": "PGN_00_00F004_190" } ] } }')
	//   ws.send('{ "writeSharkBytes": { "sharkBytes": [ { "id": "MSS_LogIn", "value": "31313131" } ] } }')
	//   ws.send('{ "refreshSharkBytes": { "sharkBytes": [ { "id": "PID_00_000054" } ] } }')

	m_deregisterers.emplace_back(
		m_spJsonWebSocket->Register("displaySharkBytes", []() noexcept {}, [this](auto&& json){ this->HandleDisplaySharkBytes(json); }));
	m_deregisterers.emplace_back(
		m_spJsonWebSocket->Register("writeSharkBytes",   []() noexcept {}, [this](auto&& json){ this->HandleWriteSharkBytes(json);   }));
	m_deregisterers.emplace_back(
		m_spJsonWebSocket->Register("refreshSharkBytes", []() noexcept {}, [this](auto&& json){ this->HandleRefreshSharkBytes(json); }));
}
WebSocketListener::WriteRequests WebSocketListener::TakeWriteRequests()
{
	std::lock_guard<std::mutex> lock(m_mutex);

	auto writes = std::move(m_writeRequests);
	m_writeRequests.clear();
	return writes;
}
WebSocketListener::SubscribeRequests WebSocketListener::TakeSubscribeRequests()
{
	std::lock_guard<std::mutex> lock(m_mutex);

	auto subscriptions = std::move(m_subscribeRequests);
	m_subscribeRequests.clear();
	return subscriptions;
}
WebSocketListener::RefreshRequests WebSocketListener::TakeRefreshRequests()
{
	std::lock_guard<std::mutex> lock(m_mutex);

	auto refreshes = std::move(m_refreshRequests);
	m_refreshRequests.clear();
	return refreshes;
}
void WebSocketListener::HandleDisplaySharkBytes(nlohmann::json const& displaySharkBytesJson)
{
	std::lock_guard<std::mutex> lock(m_mutex);

	auto const& sharkByteListJson = displaySharkBytesJson["sharkBytes"];
	for (auto&& sharkByteJson : sharkByteListJson)
	{
		auto id = sharkByteJson["id"].get<std::string>();
		std::string action{"describe"};
		auto const pActionName = "action";
		if (sharkByteJson.contains(pActionName))
		{
			action = sharkByteJson[pActionName].get<std::string>();
		}

		SubscriptionAction subscriptionAction{};
		if (action == "describe")
		{
			subscriptionAction = SubscriptionAction::Describe;
		}
		else
		{
			assert(action == "special");
			subscriptionAction = SubscriptionAction::Special;
		}

		m_subscribeRequests.emplace_back(std::move(id), subscriptionAction);
	}
}
void WebSocketListener::HandleWriteSharkBytes(nlohmann::json const& writeSharkBytesJson)
{
	std::lock_guard<std::mutex> lock(m_mutex);

	auto const& sharkByteListJson = writeSharkBytesJson["sharkBytes"];
	for (auto&& sharkByteJson : sharkByteListJson)
	{
		auto id = sharkByteJson["id"].get<std::string>();
		std::string value = sharkByteJson["value"].get<std::string>();

		auto dataSize = value.size() / 2;
		std::vector<uint8_t> valueBytes(dataSize);
		Utilities::HexStringConverter{}.ToBinary(value, valueBytes.data(), static_cast<unsigned>(dataSize));

		std::cout << id << ": Writing " << value << " (" << valueBytes.size() << " bytes)" << std::endl;
		m_writeRequests.emplace_back(std::move(id), std::move(valueBytes));
	}
}
void WebSocketListener::HandleRefreshSharkBytes(nlohmann::json const& refreshSharkBytesJson)
{
	std::lock_guard<std::mutex> lock(m_mutex);

	auto const& sharkByteListJson = refreshSharkBytesJson["sharkBytes"];
	std::transform(
		sharkByteListJson.begin(),
		sharkByteListJson.end(),
		std::back_inserter(m_refreshRequests),
		[](auto&& json) { return json["id"].template get<std::string>(); });
}
}
