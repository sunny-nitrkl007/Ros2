#!/usr/bin/env bash
# Copyright (C) Caterpillar Inc. All Rights Reserved.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

python -m pip install -r "${SCRIPT_DIR}/requirements.txt"
