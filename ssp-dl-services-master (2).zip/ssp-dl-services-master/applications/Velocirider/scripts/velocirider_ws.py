#!/usr/bin/env python3
# Copyright (C) Caterpillar Inc. All Rights Reserved.

"""Velocirider websocket client."""


import argparse
import json
from typing import Iterable

import websocket


DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8043
PATH = "/Velocirider"
SOCKET_TIMEOUT_SECONDS = 5.0


def _build_parser() -> argparse.ArgumentParser:
	parser = argparse.ArgumentParser(
		description="Send websocket commands to a Velocirider instance.")
	parser.add_argument("--host", default=DEFAULT_HOST, help="Websocket host.")
	parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="Websocket port.")

	subparsers = parser.add_subparsers(dest="command", required=True)

	display_parser = subparsers.add_parser(
		"display", help="Send a displaySharkBytes request.")
	display_parser.add_argument(
		"ids",
		nargs="+",
		help="One or more SharkByte IDs to include in the displaySharkBytes request.")

	refresh_parser = subparsers.add_parser(
		"refresh", help="Send a refreshSharkBytes request.")
	refresh_parser.add_argument(
		"ids",
		nargs="+",
		help="One or more SharkByte IDs to refresh.")

	write_parser = subparsers.add_parser(
		"write", help="Send a writeSharkBytes request.")
	write_parser.add_argument(
		"id",
		help="The SharkByte ID to write to.")
	write_parser.add_argument(
		"value",
		help="Hex string value to write (e.g. '31313131').")

	return parser


def _build_url(host: str, port: int, path: str) -> str:
	normalized_path = path if path.startswith("/") else f"/{path}"
	return f"ws://{host}:{port}{normalized_path}"


def _send_json_message(host: str, port: int, payload: dict[str, object]) -> None:
	message = json.dumps(payload, separators=(",", ":")).encode("utf-8")
	sock = websocket.create_connection(
		_build_url(host, port, path=PATH),
		timeout=SOCKET_TIMEOUT_SECONDS)
	try:
		sock.send(message, opcode=websocket.ABNF.OPCODE_TEXT)
	finally:
		sock.close()


def _build_display_payload(ids: Iterable[str]) -> dict[str, object]:
	return {
		"displaySharkBytes": {
			"sharkBytes": [{"id": shark_byte_id} for shark_byte_id in ids],
		}
	}


def _build_refresh_payload(ids: Iterable[str]) -> dict[str, object]:
	return {
		"refreshSharkBytes": {
			"sharkBytes": [{"id": shark_byte_id} for shark_byte_id in ids],
		}
	}


def _build_write_payload(shark_byte_id: str, value: str) -> dict[str, object]:
	return {
		"writeSharkBytes": {
			"sharkBytes": [{"id": shark_byte_id, "value": value}],
		}
	}


def main() -> int:
	args = _build_parser().parse_args()

	if args.command == "display":
		payload = _build_display_payload(args.ids)
		_send_json_message(args.host, args.port, payload)
		print(f"Sent displaySharkBytes for {len(args.ids)} SharkByte ID(s)")
		return 0

	if args.command == "refresh":
		payload = _build_refresh_payload(args.ids)
		_send_json_message(args.host, args.port, payload)
		print(f"Sent refreshSharkBytes for {len(args.ids)} SharkByte ID(s)")
		return 0

	if args.command == "write":
		payload = _build_write_payload(args.id, args.value)
		_send_json_message(args.host, args.port, payload)
		print(f"Sent writeSharkBytes for '{args.id}' with value '{args.value}'")
		return 0

	raise AssertionError(f"Unsupported command: {args.command}")


if __name__ == "__main__":
	raise SystemExit(main())