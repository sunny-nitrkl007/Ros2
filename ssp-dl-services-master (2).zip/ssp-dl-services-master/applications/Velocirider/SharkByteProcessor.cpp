/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SharkByteProcessor.h

#include "SharkByteProcessor.h"
#include "middleware_diagnostics.pb.h"
#include <Shark/SharkByteDetails.h>
#include <Config/J1939Address.h>
#include <iostream>

namespace Velocirider
{
using namespace Shark::SharkByteDetails;
std::vector<SharkByteSubscriptionConfig> GetDefaultSharkBytes()
{
	static constexpr SharkByteSubscriptionConfig s_defaultSharkBytes[]
	{
		// ADT
		{ "engine.engine_fan_reversing_solenoid_status" },
		{ "engine.exhaust_system_high_temperature_indicator_status" },
		{ "engine.aftertreatment_regeneration_device_inhibited_indicator_status" },
		{ "machine.operator_seat_belt_indicator_status" },
		{ "transmission.operator_present_status" },

		// PGB
		{ "engine.diesel_particulate_filter_indicator_status" },
		{ "engine.malfunction_indicator_lamp_status" },
		{ "engine.glow_plug_start_aid_status" },
		{ "machine.machine_slope" },
		{ "machine.machine_side_slope" },
		{ "machine.ground_power_percentage" },
		{ "machine.implement_lockout_switch_position" },
		{ "machine.blade_float_status" },
		{ "machine.winch_enable_status" },
		{ "machine.winch_low_speed_lock_feature_status" },
		{ "machine.winch_enable_status_lock" },
		{ "machine.autocarry_display_status" },
		{ "machine.automatic_ripper_control_display_status" },
		{ "transmission.requested_powertrain_speed_range" },
		{ "transmission.autoshift_reverse_to_forward_range" },
		{ "transmission.autoshift_forward_to_reverse_range" },
		{ "transmission.limp_home_mode_status" },
		{ "transmission.transmission_auto_shift_mode" },
		{ "transmission.parking_brake_status" },

		// PGN Broadcast
		{ "pgn_fc31" },
		{ "pgn_fd07" },
		{ "pgn_fe56" },
		{ "pgn_feee" },
		{ "pgn_fe68" },
		{ "pgn_fefc" },
		{ "pgn_fd95" },
		{ "pgn_ffe0" },
		{ "pgn_ffe1" },
		{ "pgn_ffe2" },

		// PGN On-Request
		{ "pgn_00_feb0" },
		{ "pgn_00_fee5" },
		{ "pgn_00_fee9" },
		{ "pgn_69_feb0" },
		{ "pgn_69_fee5" },
		{ "pgn_69_fee9" },

		{ "MSS_OperatorDetected" },
		{ "MSS_OperatorIsGuest" },
		{ "MSS_OperatorIsMaster" },
		{ "MSS_OperatorLogInMethod" },
		{ "MSS_OperatorName" },
		{ "MSS_RawOperatorKeyId" },

		{ "MSS_LogInStatus" },
		{ "MSS_LogOutStatus" },
		{ "MSS_LockStatus" },
		{ "MSS_OperatorRequestStatus" },
		{ "MSS_UnlockStatus" },

		// Internal shark bytes
		{ "HighestActiveAnnunciationRequirement" },

		{ DiagnosticCodes::CodesSharkByteId(), SubscriptionAction::Special },
		{ Calibrations::Status::SharkByteId(), SubscriptionAction::Special }
	};

	return std::vector<SharkByteSubscriptionConfig>{std::begin(s_defaultSharkBytes), std::end(s_defaultSharkBytes)};
}
void HandleCodesSharkByteValue(std::string const& sharkByteId, Shark::SharkByteValue const& value)
{
	assert(sharkByteId == DiagnosticCodes::CodesSharkByteId());

	cat::middleware::diagnostics::Codes protobufCodes{};
	if (!value || !protobufCodes.ParseFromArray(value->data(), static_cast<int>(value->size())))
	{
		throw std::runtime_error("Could not parse Code protobuf");
	}
	std::cout << sharkByteId << ":";
	for (auto const& protobufCode : protobufCodes.codes())
	{
		std::cout << "\n  " << protobufCode.ShortDebugString();
	}
	std::cout << std::endl;
}
void HandleCalibrationsStatusSharkByteValue(std::string const& sharkByteId, Shark::SharkByteValue const& value)
{
	assert(sharkByteId == Calibrations::Status::SharkByteId());

	std::cout << sharkByteId << ": ";
	if (value)
	{
		std::cout << std::string(value->begin(), value->end());
	}
	else
	{
		std::cout << "no status, cal not active";
	}
	std::cout << std::endl;
}
void HandleSpecialSharkByteValue(std::string const& sharkByteId, Shark::SharkByteValue const& value)
{
	if (sharkByteId == Shark::SharkByteDetails::DiagnosticCodes::CodesSharkByteId())
	{
		HandleCodesSharkByteValue(sharkByteId, value);
	}
	else if (sharkByteId == Shark::SharkByteDetails::Calibrations::Status::SharkByteId())
	{
		HandleCalibrationsStatusSharkByteValue(sharkByteId, value);
	}
}
}