/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See CommandLineOptions.h

#include "CommandLineOptions.h"
#include <Utilities/CountOf.h>
#include <Utilities/IndexOf.h>
#include <Utilities/StringUtilities.h>
#include <Utilities/ToUnderlying.h>
#include <boost/program_options.hpp>
#include <iostream>

namespace Velocirider
{
namespace
{
CommandLineOptions CreateCommandLineOptions(boost::program_options::variables_map const& variablesMap)
{
	auto const useCan1 = (variablesMap.count("use_can1") > 0);
	return CommandLineOptions{useCan1};
}
}

CommandLineOptions::CommandLineOptions(bool useCan1)
	: m_useCan1{useCan1}
{
}

std::function<CommandLineOptions const&()> ProcessCommandLine(int argc, char* argv[])
{
	using namespace boost::program_options;

	options_description description{};
	description.add_options()
		("help", "Display this help message")
		("use_can1", "Use can1 for all J1939 communications. (can0 used by default)");

	auto const parsedOptions = command_line_parser(argc, argv)
		.options(description)
		.run();

	try
	{
		variables_map variablesMap{};
		store(parsedOptions, variablesMap);
		notify(variablesMap);

		if (variablesMap.count("help"))
		{
			throw std::runtime_error("help");
		}

		auto const commandLineOptions = CreateCommandLineOptions(variablesMap);
		return [commandLineOptions]() noexcept -> CommandLineOptions const& { return commandLineOptions; };
	}
	catch (std::exception const& e)
	{
		std::cout << e.what() << std::endl;
		std::cout << "Usage:\n" << description << std::endl;
		throw;
	}
}
}