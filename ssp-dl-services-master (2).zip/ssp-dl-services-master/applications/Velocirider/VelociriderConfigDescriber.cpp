/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See VelociriderDataEngineConfig.h

#include "VelociriderConfigDescriber.h"
#include <Config/PidIdentifierConfig.h>
#include <Config/PgnIdentifierConfig.h>
#include <Config/SharkConfig.h>
#include <Config/SpnIdentifierConfig.h>

using namespace Config;

namespace Velocirider
{
namespace
{
constexpr AdtPidEntry n_adtPidEntries_00[]
{
	{ 0x00F2B0, "engine.engine_fan_reversing_solenoid_status" },
	{ 0xD10A58, "engine.exhaust_system_high_temperature_indicator_status" },
	{ 0xD10ACB, "engine.aftertreatment_regeneration_device_inhibited_indicator_status" },
};
constexpr AdtPidEntry n_adtPidEntries_21[]
{
 	{ 0xD10D2E, "machine.operator_seat_belt_indicator_status" },
};
constexpr AdtPidEntry n_adtPidEntries_27[]
{
 	{ 0xD1016D, "transmission.operator_present_status" },
};
constexpr PgbPidEntry n_pgbPidEntries_00[]
{
	{ 0xD10A57,  500, true, "engine.diesel_particulate_filter_indicator_status" },
	{ 0xD10D3E,  500, true, "engine.malfunction_indicator_lamp_status" },
	{ 0xD102CA, 1000, true, "engine.glow_plug_start_aid_status" },
};
constexpr PgbPidEntry n_pgbPidEntries_21[]
{
	{ 0x00F533,  100, true, "machine.machine_slope" },
	{ 0xD00409,  250, true, "machine.machine_side_slope" },
	{ 0xD0146A,  250, true, "machine.ground_power_percentage" },
	{ 0x00F0B8, 1000, true, "machine.implement_lockout_switch_position" },
	{ 0xD103DD, 1000, true, "machine.blade_float_status" },
	{ 0xD10401, 1000, true, "machine.winch_enable_status" },
	{ 0xD1044B, 1000, true, "machine.winch_low_speed_lock_feature_status" },
	{ 0xD1065D, 1000, true, "machine.winch_enable_status_lock" },
	{ 0xD11630, 1000, true, "machine.autocarry_display_status" },
	{ 0xD11632, 1000, true, "machine.automatic_ripper_control_display_status" },
};
constexpr PgbPidEntry n_pgbPidEntries_27[]
{
	{ 0xD00D3E,  500, true, "transmission.requested_powertrain_speed_range" },
	{ 0xD013AC,  500, true, "transmission.autoshift_reverse_to_forward_range" },
	{ 0xD013AD,  500, true, "transmission.autoshift_forward_to_reverse_range" },
	{ 0xD10418,  500, true, "transmission.limp_home_mode_status" },
	{ 0x00F1FF, 1000, true, "transmission.transmission_auto_shift_mode" },
	{ 0x00F602, 1000, true, "transmission.parking_brake_status" },
};
constexpr InternalSpnEntry n_internalSpnEntries_00_FC31[]
{
	{ 7502, "engine.aftertreatment_engine_speed_increase_request" },
};
constexpr InternalSpnEntry n_internalSpnEntries_00_FD07[]
{
	{ 5078, "engine.engine_amber_warning_lamp_command" },
};
constexpr InternalSpnEntry n_internalSpnEntries_00_FE56[]
{
	{ 1761, "engine.aftertreatment_1_diesel_exhaust_fluid_tank_volume" },
};
constexpr InternalSpnEntry n_internalSpnEntries_00_FEEE[]
{
	{ 110, "engine.engine_coolant_temperature" },
};
constexpr ReceiveBroadcastPgnEntry n_broadcastPgnEntries_00[]
{
	{ 0x00FC31, 3000, n_internalSpnEntries_00_FC31, "pgn_fc31" },
	{ 0x00FD07, 3000, n_internalSpnEntries_00_FD07, "pgn_fd07" },
	{ 0x00FE56, 3000, n_internalSpnEntries_00_FE56, "pgn_fe56" },
	{ 0x00FEEE, 3000, n_internalSpnEntries_00_FEEE, "pgn_feee" },
};
constexpr ReceiveOnRequestPgnEntry n_onRequestPgnEntries_00[]
{
	{ 0x00FEB0, {}, "pgn_00_feb0" },
	{ 0x00FEE5, {}, "pgn_00_fee5" },
	{ 0x00FEE9, {}, "pgn_00_fee9" },
};
constexpr InternalSpnEntry n_internalSpnEntries_21_FE68[]
{
	{ 1638, "machine.hydraulic_temperature" },
};
constexpr InternalSpnEntry n_internalSpnEntries_21_FEFC[]
{
	{  96, "machine.fuel_level_1" },
};
constexpr ReceiveBroadcastPgnEntry n_broadcastPgnEntries_21[]
{
	{ 0x00FE68, 4000, n_internalSpnEntries_21_FE68, "pgn_fe68" },
	{ 0x00FEFC, 4000, n_internalSpnEntries_21_FEFC, "pgn_fefc" },
};
constexpr InternalSpnEntry n_internalSpnEntries_27_FD95[]
{
	{ 3823, "transmission.transmission_torque_converter_oil_outlet_temperature" },
};
constexpr InternalSpnEntry n_internalSpnEntries_27_FFE0[]
{
	{ 1, "transmission.automatics_status" },
	{ 2, "transmission.2D_efence_front_enable_status" },
	{ 3, "transmission.machine_pitch_roll_angle_enable_status" },
};
constexpr InternalSpnEntry n_internalSpnEntries_27_FFE1[]
{
	{ 4, "transmission.machine_rotation_angle" },
	{ 5, "transmission.machine_pitch_angle" },
	{ 6, "transmission.machine_roll_angle" },
};
constexpr InternalSpnEntry n_internalSpnEntries_27_FFE2[]
{
	{ 7, "transmission.right_light_bar_point_z_status" },
	{ 8, "transmission.left_light_bar_point_j_status" },
};
constexpr ReceiveBroadcastPgnEntry n_broadcastPgnEntries_27[]
{
	{ 0x00FD95, 3000, n_internalSpnEntries_27_FD95, "pgn_fd95"},
	{ 0x00FFE0, 1000, n_internalSpnEntries_27_FFE0, "pgn_ffe0" },
	{ 0x00FFE1, 1000, n_internalSpnEntries_27_FFE1, "pgn_ffe1"},
	{ 0x00FFE2, 1000, n_internalSpnEntries_27_FFE2, "pgn_ffe2"},
};
constexpr BasicReadWritePidEntry n_basicReadWritePidEntries_00[]
{
	{ 0x000014, "write_pid_00_14" },
	{ 0x000055, "write_pid_00_55" },
	{ 0x0000C8, "write_pid_00_c8" },
};
constexpr BdtTypeEntry n_typeEntries_27[]
{
	{ 0xC000, 0x00000000, BdtAccessMode::ReadWrite, "27.bdt_c000_00000000" },
	{ 0xC000, 0x00000001, BdtAccessMode::ReadWrite, "27.bdt_c000_00000001" },
	{ 0xC820, 0x00000000, BdtAccessMode::ReadOnly,  "27.bdt_c820_00000000" },
	{ 0xC830, 0x00000003, BdtAccessMode::WriteOnly, "27.bdt_c830_00000003" },
};
constexpr CalibrationServiceDataEntry n_calibrationEntries_42[]
{
	{ 0x002F, "42.calibration_002F" },
	{ 0x00DE, "42.calibration_00DE" },
};
constexpr CalibrationServiceDataEntry n_serviceTestEntries_42[]
{
	{ 0x0180, "42.service_test_0180" },
	{ 0x01CA, "42.service_test_01CA" },
};
constexpr ExtensionIdReadEntry n_extensionIdReadEntries_00[]
{
	{ 0xF019, "can0_00_F019" },
	{ 0xF01A, "can0_00_F01A" },
};
constexpr ExtensionIdReadEntry n_extensionIdReadEntries_21[]
{
	{ 0xF019, "can0_21_F019" },
	{ 0xF01A, "can0_21_F01A" },
};
constexpr ExtensionIdReadEntry n_extensionIdReadEntries_42[]
{
	{ 0xF019, "can0_42_F019" },
	{ 0xF01A, "can0_42_F01A" },
};

constexpr PeerNodeEntry n_peerNodes_0[]
{
	{
		0x00,
		{ std::nullopt, n_adtPidEntries_00 },
		{ n_pgbPidEntries_00 },
		{ n_broadcastPgnEntries_00, n_onRequestPgnEntries_00 },
		{ n_basicReadWritePidEntries_00 },
		{},
		{},
		{ n_extensionIdReadEntries_00 },
	},
	{
		0x21,
		{ std::nullopt, n_adtPidEntries_21 },
		{ n_pgbPidEntries_21 },
		{ n_broadcastPgnEntries_21 },
		{},
		{},
		{},
		{ n_extensionIdReadEntries_21 },
	},
	{
		0x27,
		{ 10000, n_adtPidEntries_27 },
		{ n_pgbPidEntries_27 },
		{ n_broadcastPgnEntries_27 },
		{},
		{ n_typeEntries_27 },
	},
	{
		0x42,
		{},
		{},
		{},
		{},
		{},
		{ n_calibrationEntries_42, n_serviceTestEntries_42 },
		{ n_extensionIdReadEntries_42 },
	},
	{
		0x91,
		{},
		{},
		{},
	}
};


constexpr ReceiveOnRequestPgnEntry n_onRequestPgnEntries_69[]
{
	{ 0x00FEB0, {}, "pgn_69_feb0" },
	{ 0x00FEE5, {}, "pgn_69_fee5" },
	{ 0x00FEE9, {}, "pgn_69_fee9" },
};
constexpr BasicReadWritePidEntry n_basicReadWritePidEntries_69[]
{
	{ 0x00F815, "write_pid_69_f815" },
};
constexpr BdtTypeEntry n_typeEntries_69[]
{
	{ 0xC820, 0x00000000, BdtAccessMode::ReadOnly,  "69.bdt_c820_00000000" },
	{ 0xC830, 0x00000003, BdtAccessMode::WriteOnly, "69.bdt_c830_00000003" },
};
constexpr CalibrationServiceDataEntry n_calibrationEntries_70[]
{
	{ 0x0306, "70.calibration_0306" },
	{ 0x0335, "70.calibration_0335" },
};
constexpr CalibrationServiceDataEntry n_serviceTestEntries_70[]
{
	{ 0x00C6, "70.service_test_00C6" },
	{ 0x00D4, "70.service_test_00D4" },
};
constexpr ExtensionIdReadEntry n_extensionIdReadEntries_69[]
{
	{ 0xF019, "can1_69_F019" },
	{ 0xF01A, "can1_69_F01A" },
};
constexpr ExtensionIdReadEntry n_extensionIdReadEntries_70[]
{
	{ 0xF019, "can1_70_F019" },
	{ 0xF01A, "can1_70_F01A" },
};

constexpr PeerNodeEntry n_peerNodes_1[]
{
	{
		0x69,
		{  },
		{  },
		{ {}, { n_onRequestPgnEntries_69 } },
		{ n_basicReadWritePidEntries_69 },
		{ n_typeEntries_69 },
		{  },
		{ n_extensionIdReadEntries_69 },

	},
	{
		0x70,
		{  },
		{  },
		{  },
		{  },
		{  },
		{ n_calibrationEntries_70, n_serviceTestEntries_70 },
		{ n_extensionIdReadEntries_70 },
	},
};

// ***** CAN Bus 2 - Subset of 0 *****

constexpr PgbPidEntry n_pgbPidEntries_2_21[]
{
	{ 0x00F533,  100, true, "can2.21.machine.machine_slope" },
};
constexpr PeerNodeEntry n_peerNodes_2[]
{
	{
		0x21,
		{},
		{ n_pgbPidEntries_2_21 },
	},
};

// ***** CAN Bus 3 - Subset of 1 *****

constexpr PgbPidEntry n_pgbPidEntries_3_69[]
{
	{ 0x000040,  50, true, "can3.69.actual_engine_rpm" },
	{ 0xD03179, 250, false, "can3.69.maximum_active_annunciation" },
};
constexpr PeerNodeEntry n_peerNodes_3[]
{
	{
		0x69,
		{},
		{ n_pgbPidEntries_3_69 },
	},
};

// ***** CAN Bus 4 - Subset of 0 *****

constexpr PgbPidEntry n_pgbPidEntries_4_21[]
{
	{ 0x00F533,  100, true, "can4.21.machine.machine_slope" },
};
constexpr PeerNodeEntry n_peerNodes_4[]
{
	{
		0x21,
		{},
		{ n_pgbPidEntries_4_21 },
	},
};

// ***** CAN Bus 5 - Subset of 1 *****

constexpr PgbPidEntry n_pgbPidEntries_5_69[]
{
	{ 0x000040,  50, true, "can5.69.actual_engine_rpm" },
	{ 0xD03179, 250, false, "can5.69.maximum_active_annunciation" },
};
constexpr PeerNodeEntry n_peerNodes_5[]
{
	{
		0x69,
		{},
		{ n_pgbPidEntries_5_69 },
	},
};

constexpr TransmitBroadcastPgnEntry n_transmitPgnEntries_0[]
{
	{ 0x00FEED, 1000, {}, "pgn_feed_0" },
	{ 0x00FEEB, 1000, {}, "pgn_feeb_0" }
};
constexpr TransmitBroadcastPgnEntry n_transmitPgnEntries_1[]
{
	{ 0x00FEED, 1000, {}, "pgn_feed_1" },
	{ 0x00FEEB, 1000, {}, "pgn_feeb_1" }
};
constexpr unsigned n_addressList_link_0[] { 0x50 };
constexpr unsigned n_addressList_link_1[] { 0x51 };
constexpr unsigned n_addressList_link_2[] { 0x52 };
constexpr unsigned n_addressList_link_3[] { 0x53 };
constexpr unsigned n_addressList_link_4[] { 0x54 };
constexpr unsigned n_addressList_link_5[] { 0x55 };
constexpr J1939LinkEntry n_j1939LinkEntries[]
{
	{
		Can0,
		{ n_addressList_link_0, 1, 2, 3, 4, 5, 6, 7 },
		{ n_peerNodes_0, },
		{ n_transmitPgnEntries_0}
	},
	{
		Can1,
		{ n_addressList_link_1, 1, 2, 3, 4, 5, 6, 7 },
		{ n_peerNodes_1 },
		{ n_transmitPgnEntries_1 }
	},
	{
		Can2,
		{ n_addressList_link_2, 1, 2, 3, 4, 5, 6, 7 },
		{
			n_peerNodes_2,
		},
	},
	{
		Can3,
		{ n_addressList_link_3, 1, 2, 3, 4, 5, 6, 7 },
		{
			n_peerNodes_3,
		},
	},
	{
		Can4,
		{ n_addressList_link_4, 1, 2, 3, 4, 5, 6, 7 },
		{
			n_peerNodes_4,
		},
	},
	{
		Can5,
		{ n_addressList_link_5, 1, 2, 3, 4, 5, 6, 7 },
		{
			n_peerNodes_5,
		},
	},
};
constexpr MachineSecuritySystemEntry n_machineSecuritySystemEntry
{
	Can0,
	0x00
};
constexpr DiagnosticPeerEntry n_diagnosticPeerEntry0[]
{
	{ 0x00, Eddt },
	{ 0x21, Eddt },
	{ 0x27, Public },
	{ 0x42, Public },
	{ 0x91, Eddt },
};
constexpr DiagnosticPeerEntry n_diagnosticPeerEntry1[]
{
	{ 0x69, Eddt },
	{ 0x70, Public },
};
constexpr DiagnosticClientCanPort n_diagnosticClientCanPort[]
{
	{
		Can0,
		{ n_diagnosticPeerEntry0 },
	},
	{
		Can1,
		{ n_diagnosticPeerEntry1 },
	},
};
constexpr InternalCodeEntry n_internalCodeEntries[]
{
	{ Diagnostic, ActiveOnly     ,  100, 1, 1, 2, "Diag1" , 0,  1,  1,  1, "InternalDiagnostic100" },
	{ Diagnostic, LoggedAndActive,  200, 2, 2, 2, "Diag2" , 0,  5,  5,  5, "InternalDiagnostic200" },
	{ Diagnostic, ActiveOnly     ,  300, 3, 3, 2, "Diag3" , 0, 10, 10, 10, "InternalDiagnostic300" },
	{ Diagnostic, ActiveOnly     ,  400, 2, 2, 2, "Diag4" , 0,  0,  0,  0, "InternalDiagnostic400" },
	{ Event     , ActiveOnly     , 1000, 0, 1, 2, "Event1", 0,  1,  1,  1, "InternalEvent1000" },
	{ Event     , LoggedAndActive, 2000, 0, 2, 2, "Event2", 0,  5,  5,  5, "InternalEvent2000" },
	{ Event     , ActiveOnly     , 3000, 0, 3, 2, "Event3", 0, 10, 10, 10, "InternalEvent3000" },
	{ Event     , ActiveOnly     , 4000, 0, 2, 2, "Event4", 0,  0,  0,  0, "InternalEvent4000" },
};
constexpr InternalCodeList n_internalCodeList
{
	Can0,
	{ n_internalCodeEntries },
};
constexpr DiagnosticsEntry n_diagnosticsEntry
{
	{ n_diagnosticClientCanPort },
	{ n_internalCodeList }
};
constexpr BdtDefinitionEntry n_bdtDefinitionEntries[]
{
	{ 0xC000, 10000 },
	{ 0xC820, 10000 },
	{ 0xC830, 10000 },
};
constexpr BdtConfig n_bdtConfig{{ n_bdtDefinitionEntries }};

constexpr PgtPidEntry n_pgtPids_00010000[]
{
	{ 0xD00EE5,  100, "00010000_D00EE5" },
	{ 0xD01682,  100, "00010000_D01682" },
	{ 0xD028FC,  100, "00010000_D028FC" },
	{ 0xD10741,  500, "00010000_D10741" },
	{ 0xD10749,  500, "00010000_D10749" },
};
constexpr PgtPidEntry n_pgtPids_00020000[]
{
	{ 0xD00908,  100,  "00020000_D00908" },
	{ 0xD00E9D,  100,  "00020000_D00E9D" },
	{ 0xD0167E,  1000, "00020000_D0167E" },
	{ 0xD1073F,  1000, "00020000_D1073F" },
};
constexpr PgtPidEntry n_pgtPids_00030000[]
{
	{ 0xD00883,  5000, "00030000_D00883" },
};
constexpr EthernetPeerNodeEntry n_enthernetPeerNodeEntries[]
{
	{
		0x00010000,
		"165.26.79.25",
		{ n_pgtPids_00010000 },
	},
	{
		0x00020000,
		"165.26.79.26",
		{ n_pgtPids_00020000 },
	},
	{
		0x00030000,
		"165.26.79.27",
		{ n_pgtPids_00030000 },
	},
};
constexpr EthernetDataLinkEntry n_ethernetDataLinkEntry
{
	0x00080000,
	"165.26.79.42",
	{ n_enthernetPeerNodeEntries },
};

constexpr Config::SharkConfig n_sharkConfig
{
	{ n_j1939LinkEntries },
	{{ 0x0190, 0x0607, 0x0528, 0x0000, std::nullopt }},
	{ n_machineSecuritySystemEntry },
	{ n_diagnosticsEntry },
	{ n_bdtConfig },
	{ n_ethernetDataLinkEntry }
};

}
nice_ptr<Config::SharkConfig const> VelociriderConfigDescriber::GetSharkConfig() const
{
	return &n_sharkConfig;
}
}
