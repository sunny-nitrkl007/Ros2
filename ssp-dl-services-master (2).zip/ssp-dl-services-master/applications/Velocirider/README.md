# Velocirider
Velocirider is a tool used to validate and debug Shark protocol features.

**Name origin**: `Velocirider` instantiates and controls Shark in the same way a velociraptor riding a real shark (aka a `Velocirider`) controls it.

## Running Velocirider onboard
Once you build it, you can run it in the following ways onboard:
- Use CreateVelociriderVerity.sh and copy the verity into your VM's verity location (like `/opt/appdata/BoskoVM`) and reboot, or
- `scp` `artifacts/tgt_gcc_arm64_guest/RelWithDebInfo/tools/Velocirider` to your VM's `/tmp` directory
  - Then run it with `LD_LIBRARY_PATH=/opt/Jaws/lib /tmp/Velocirider`

## Controlling Velocirider
Velocirider is controlled via a web socket interface that uses json. You can use the interface in many different ways--here is one method that works.

1. Forward the port: `ssh -L 8043:localhost:8043 <onboard vm>`
2. In Chrome, navigate to "http://localhost:8043"
   - Note: there is not a web page here... we do this get Chrome to allow us to initialize a web socket to this site
3. Use Chrome dev tools (F12) while at this "site" to run JavaScript and access the Velocridier API

### Example commands

```javascript
var ws = new WebSocket("ws://localhost:8043/Velocirider");
ws.send('{ "displaySharkBytes": { "sharkBytes": [ { "id": "transmission.parking_brake_status" } ] } }')
ws.send('{ "writeSharkBytes": { "sharkBytes": [ { "id": "MSS_LogIn", "value": "31313131" } ] } }')
ws.send('{ "refreshSharkBytes": { "sharkBytes": [ { "id": "pgn_00_feb0" } ] } }')
```

## Python CLI
If you want a simple command-line client instead of using browser dev tools, first install its Python dependencies:

```bash
scripts/install_requirements.sh
```

That installs [scripts/requirements.txt](./scripts/requirements.txt) into your active Python environment. After that, use [applications/Velocirider/scripts/velocirider_ws.py](./scripts/velocirider_ws.py).

Example:

```bash
applications/Velocirider/scripts/velocirider_ws.py display transmission.parking_brake_status pgn_00_feb0
```

Optional connection overrides are also available:

```bash
python applications/Velocirider/scripts/velocirider_ws.py --host localhost --port 8043 display transmission.parking_brake_status
```
