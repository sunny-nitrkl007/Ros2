/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Minimal Logger

namespace Log
{
void Flush();
}
