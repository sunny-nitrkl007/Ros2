/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Velocirider Environment Factory

#pragma once

#include <Utilities/IEnvironment.h>
#include <functional>
#include <memory>

namespace Utilities { class IFilesystem; }

namespace Velocirider
{
// Jump through some hoops so each architecture can return its own type
class CommandLineOptions;
std::function<CommandLineOptions const&()> ProcessCommandLine(int argc, char* argv[]);

class VelociriderEnvironmentFactory
{
public:
	static std::unique_ptr<Utilities::IEnvironment> CreateEnvironment(Utilities::IFilesystem const& filesystem);
};
}
