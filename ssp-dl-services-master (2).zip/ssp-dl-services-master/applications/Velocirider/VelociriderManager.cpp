/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See VelociriderManager.h

#include "VelociriderManager.h"
#include "SharkByteProcessor.h"
#include <Config/ConfigFactory.h>
#include <Shark/Shark.h>
#include <Utilities/ArrayToHexString.h>
#include <Utilities/SharkBytes/SharkByteDescribers.h>
#include <iostream>

namespace Velocirider
{
VelociriderManager::VelociriderManager(
	std::unique_ptr<Utilities::IEnvironment const>&& spEnvironment,
	std::unique_ptr<Config::IConfigDescriber const>&& spConfigDescriber)
	: m_spEnvironment(std::move(spEnvironment))
	, m_spConfigDescriber(std::move(spConfigDescriber))
	, m_sharkConfig(Config::ConfigFactory::CreateConfig(*m_spConfigDescriber))
	, m_spShark(Shark::CreateShark(*m_spEnvironment, m_sharkConfig))
	, m_sharkByteRetriever(m_spShark->GetSharkByteRetriever())
	, m_writeSharkByteRetriever(m_spShark->GetWriteSharkByteRetriever())
{
	assert(m_spEnvironment);
	assert(m_spShark);
}
void VelociriderManager::AddSharkByte(Shark::SharkByteId const& id, SubscriptionAction subscriptionAction)
{
	auto optionalSharkByte = m_sharkByteRetriever.TryRetrieve(id);
	if (optionalSharkByte)
	{
		auto& sharkByte = **optionalSharkByte;
		Shark::SharkByteSubscription subscription{};

		if (subscriptionAction == SubscriptionAction::Describe)
		{
			subscription = sharkByte.SubscribeToValues(
				[&sharkByte](Shark::SharkByteValue const& value)
				{
					std::cout << Utilities::DescribeValue(sharkByte.Id(), value) << std::endl;
				});
		}
		else
		{
			assert(subscriptionAction == SubscriptionAction::Special);
			subscription = sharkByte.SubscribeToValues(
				[id = sharkByte.Id()](Shark::SharkByteValue const& value)
				{
					HandleSpecialSharkByteValue(id, value);
				});
		}
		m_subscriptions.emplace_back(std::move(subscription));
	}
	else
	{
		std::cout << "SharkByte with id " << id << " not found." << std::endl;
	}
}
void VelociriderManager::WriteToSharkByte(Shark::SharkByteId const& id, std::vector<uint8_t> const& value)
{
	auto optionalWriteSharkByte = m_writeSharkByteRetriever.TryRetrieve(id);
	if (optionalWriteSharkByte)
	{
		(**optionalWriteSharkByte).Write(value,
			[](Shark::SharkByteValue const& response)
			{
				if (response)
				{
					std::cout << "Write successful, response value: " <<
						Utilities::ArrayToHexString(response->data(), static_cast<unsigned>(response->size())) << std::endl;
				}
				else
				{
					std::cout << "Write failed or timed out" << std::endl;
				}
			});
	}
	else
	{
		std::cout << "Write SharkByte with id " << id << " not found." << std::endl;
	}
}
void VelociriderManager::Refresh(Shark::SharkByteId const& id)
{
	std::cout << id << ": Refreshing" << std::endl;

	auto optionalSharkByte = m_sharkByteRetriever.TryRetrieve(id);
	if (optionalSharkByte)
	{
		(**optionalSharkByte).Refresh();
	}
	else
	{
		std::cout << "SharkByte with id " << id << " not found." << std::endl;
	}
}
}
