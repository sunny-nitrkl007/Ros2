/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// The Velocirider Manager

#pragma once

#include "Actions.h"
#include <Config/IConfigDescriber.h>
#include <SharkConfiguration.pb.h>
#include <Shark/IShark.h>
#include <Utilities/IEnvironment.h>
#include <atomic>
#include <memory>
#include <thread>
#include <vector>

namespace Velocirider
{
class VelociriderManager
{
public:
	VelociriderManager(
		std::unique_ptr<Utilities::IEnvironment const>&& spEnvironment,
		std::unique_ptr<Config::IConfigDescriber const>&& spConfigDescriber);
	void AddSharkByte(Shark::SharkByteId const& id, SubscriptionAction subscriptionAction);
	void WriteToSharkByte(Shark::SharkByteId const& id, std::vector<uint8_t> const& value);
	void Refresh(Shark::SharkByteId const& id);
private:
	std::unique_ptr<Utilities::IEnvironment const> const m_spEnvironment;
	std::unique_ptr<Config::IConfigDescriber const> const m_spConfigDescriber;
	cat::shark::Config const m_sharkConfig;
	std::unique_ptr<Shark::IShark> m_spShark;
	Shark::ISharkByteRetriever const& m_sharkByteRetriever;
	Shark::IWriteSharkByteRetriever const& m_writeSharkByteRetriever;
	std::vector<Shark::SharkByteSubscription> m_subscriptions{};
};
}
