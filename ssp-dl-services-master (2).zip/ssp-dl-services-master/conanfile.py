# Copyright (C) Caterpillar Inc. All Rights Reserved.

from conan import ConanFile
from conan.errors import ConanInvalidConfiguration
from conan.tools.cmake import cmake_layout, CMakeToolchain, CMake
from os import path


class DataLinkEngineConan(ConanFile):
    name = "datalinkengine"
    version = "development"

    # The middleware option allows us to build with either our middleware-cpp library or with ROS2
    options = {"middleware": ["middleware-cpp", "ros2"]}
    default_options = {"middleware": "middleware-cpp"}

    common_requires = [
        "boost/1.87.0",
        "crc32c/1.1.2",
        "nlohmann_json/3.11.3",
        "pugixml/1.14",
        "simple-websocket-server/2.0.2",
    ]

    settings = "arch", "os", "compiler", "build_type", "cat_tgt"
    generators = "CMakeDeps"

    def requirements(self):
        for req in self.common_requires:
            self.requires(req)

        if self.options.middleware == "middleware-cpp":
            self.requires("cate_middleware/2.1.0")
        else:
            self.requires("ros2/jazzy-test")

            # cate_middleware brings these in for non-ros2 builds
            self.requires("protobuf/5.27.0")
            self.requires("abseil/20250127.0")

    def build_requirements(self):
        self.tool_requires("protobuf/5.27.0")
        self.tool_requires("cpython/3.12.7")

        if self.settings.arch != "armv8":
            self.test_requires("gtest/1.15.0")

            if self.options.middleware == "ros2":
                self.test_requires("cate_rtest/0.2.3-cat.1")

    def validate(self):
        for require, dep in self.dependencies.items():
            # Build-context dependencies (tool_requires) are not linked into
            # this recipe, so their shared/static layout is irrelevant.
            if require.build:
                continue
            if "shared" in dep.options.possible_values:
                if not dep.options.shared:
                    raise ConanInvalidConfiguration(
                        f"The '{self.name}' recipe only works with the '{dep.ref.name}' "
                        "dependency built as a shared library."
                    )

    def _platform_dir(self):
        platform_dir = self.conf.get("user:platform_dir", default=self.settings.cat_tgt.value, check_type=str)
        if self.options.middleware == "ros2":
            platform_dir = platform_dir + "_ros2"
        return platform_dir

    def layout(self):
        platform_dir = self._platform_dir()

        build_path = path.join("build", platform_dir, self.settings.build_type.value)
        generators_path = path.join(
            build_path,
            "generators",
        )
        cmake_layout(self, build_folder=build_path)
        # cmake_layout overwrites self.folders by appending additional settings to file paths, so we re-assign it after
        # but before we call generate, build, or install
        self.folders.build = build_path
        self.folders.generators = generators_path

    def generate(self):
        platform_dir = self._platform_dir()

        tc = CMakeToolchain(self)
        tc.variables["DATAENGINE_PLATFORM_TARGET"] = "A7HX_GUEST" if self.settings.arch == "armv8" else "UBUNTU"
        tc.variables["MIDDLEWARE_BACKEND"] = "ROS2" if self.options.middleware == "ros2" else "MIDDLEWARE_CPP"
        # These are temporary solutions until we can get dependencies through Conan
        tc.variables["ARTIFACTS_BUILD_PATH"] = path.join(platform_dir, self.settings.build_type.value)
        # This one barely works at all. Again, very temporary solution until we repackage ssp-linux into a Conan binary package.
        tc.variables["SSP_BUILD_TARGET"] = "tgt_gcc_arm64_guest" if self.settings.arch == "armv8" else "tgt_gcc_4.4.3_ubuntu"
        # Change the presets so that CMake tools in visual studio code can differentiate between our builds
        tc.presets_prefix = ""
        tc.generate()

    def build(self):
        cmake = CMake(self)
        cmake.configure()
        cmake.build()

        # The ROS2 build generates Python message bindings plus the ament index
        # and package metadata required for `ros2 topic echo` to resolve the
        # typesupport at runtime. These only land in an install prefix, so run
        # the install step to materialize them under
        # artifacts/<platform_dir>_ros2/<build_type>/ros2_python_bindings, which the
        # JawsRos verity (utilities/Deployment/CreateJawsRosVerity.sh) consumes.
        # Only the ros2/ subdirectory declares install rules, so this installs
        # nothing else. Without this step the directory is absent after a clean
        # checkout and the verity build fails.
        if self.options.middleware == "ros2":
            platform_dir = self._platform_dir()
            bindings_prefix = path.join(
                self.source_folder,
                "artifacts",
                platform_dir,
                self.settings.build_type.value,
                "ros2_python_bindings",
            )
            self.run(f'cmake --install "{self.build_folder}" --prefix "{bindings_prefix}"')
