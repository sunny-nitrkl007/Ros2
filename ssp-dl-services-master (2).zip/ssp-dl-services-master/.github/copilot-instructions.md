# Copilot Instructions — Data Link Engine (ssp-dl-services)

## Architecture Overview

This is the **Data Link Engine** — a C++ bridge between physical data links (CAN/J1939, Ethernet) and gen7 middleware. Two primary components:

- **Shark** (`shark/`) — Data link interaction layer. Wraps J1939/Ethernet C libraries via **Kraken** (platform abstraction using `std::weak_ptr` singletons). Core data model is **SharkByte**: an observable value identified by `SharkByteId` (string), subscribed to via `boost::signals2`. Key subdirectories: `SharkBytes/` (slots, data model), `J1939/` (protocol), `Diagnostics/`, `MachineSecuritySystem/`, `Kraken/` (C API wrappers).
- **Jaws** (`applications/Jaws/`) — Middleware adapter. Converts SharkByte data to/from middleware parameter messages. Uses `DependencyContainer` for dependency injection and `InitializerFactory` pattern for ordered initialization. Registration flows through `SharkToMiddlewareDefinitions` (publishers/writers).
- **Velocirider** (`applications/Velocirider/`) — Companion application (ARM target only, not built on desktop).
- **JawsSubscriber** (`applications/JawsSubscriber/`) — WebSocket-based config subscriber.

Data flow: Config (protobuf JSON) → Shark creates SharkBytes → Jaws subscribes to SharkByte value changes → publishes to middleware parameters.

## Build System

**CRITICAL**: Before building, source Conan environment scripts (see `AGENTS.md`):
```bash
source build/<target>/<config>/generators/conanbuild.sh
source build/<target>/<config>/generators/conanrun.sh
```

### Quick Build & Test Commands

**Desktop (GCC, most common):**
```bash
cd build/tgt_gcc_x86_64_ubuntu_workstation/Debug
ninja                    # Build everything
ninja Shark_Tests        # Unit tests only
ninja Shark_Functional_Tests
ninja Jaws_Tests
ninja Jaws_Functional_Tests
```

**High-level scripts** (from repo root, auto-source environment):
```bash
utilities/Build/BuildAll.sh                           # Build all targets/configs
utilities/Build/RunUnitTests.sh -z tgt_gcc_ubuntu -t Debug  # Run unit tests
utilities/Build/RunFunctionalTests.sh -t Debug        # Run functional tests
```

### Build Targets & Configurations

| Target | Use Case | Platforms |
|--------|----------|----------|
| `tgt_gcc_x86_64_ubuntu_workstation` | Desktop development & unit testing | Debug, RelWithDebInfo |
| `tgt_gcc_x86_64_ubuntu_workstation_ros2` | Desktop with ROS2 middleware | Debug, RelWithDebInfo |
| `tgt_gcc_arm64_guest` | ARM64 target (Bosko VM) | Debug, RelWithDebInfo |
| `tgt_gcc_arm64_guest_ros2` | ARM64 with ROS2 | Debug, RelWithDebInfo |
| `tgt_clang_x86_64_ubuntu_workstation` | Clang variant (less common) | Debug, RelWithDebInfo |

**Configuration notes:**
- **Debug**: Address Sanitizer enabled (catches memory errors), slower runtime
- **RelWithDebInfo**: Optimized with debug symbols, recommended for functional testing
- **Middleware**: Default is `middleware-cpp`. Use `ros2` variant only if developing ROS2 integration

Artifacts output to `artifacts/<target>/<config>/` (libraries, tests, binaries).

If Conan generators are missing: `utilities/Build/BuildConanDependencies.sh -z tgt_gcc_ubuntu -t Debug`

## C++ Coding Conventions

- **C++23**, compiled with GCC. ASan enabled in Debug builds.
- **Indentation**: Tabs, not spaces.
- **Brace style**: Allman (opening brace on own line for functions/classes).
- **East const**: `SharkByteValue const&`, `T const*`, never `const T&`.
- **Naming prefixes**: `m_` members, `sp` smart pointers, `p` raw pointers, `n_` anonymous-namespace-scope variables.
- **Interfaces**: `I` prefix (`ISharkByte`, `ISharkByteRetriever`). Pure virtual with `virtual ~IClass() = default`.
- **Namespaces**: Separate `namespace X { namespace Y {` blocks, not `namespace X::Y`.
- **Include guards**: `#pragma once`.
- **Copyright header**: Every file starts with `/// \copyright\n/// Copyright (C) Caterpillar Inc. All Rights Reserved.\n///\n/// \file\n/// <description>`.
- **Exceptions**: Defined inline via `DEFINE_EXCEPTION_CLASS(Name)` macro (in `Utilities/DefineExceptionClass.h`).
- **Logging**: Boost.Log with severity macros: `LOG_INFO_HIGH(...)`, `LOG_WARNING(...)`, `LOG_ERROR(...)`, `LOG_DEBUG(...)`. Tag variants: `LOG_INFO_HIGH_TAG(Log::Init, ...)`.

## Key Patterns

### Static `Create()` Factory Methods
Components use `static Create()` that returns a `std::move_only_function<void(IService&)>` — a deferred initializer. The factory registers with middleware config, captures dependencies, and returns a lambda that performs runtime initialization. Do NOT unit test `Create()` methods directly.

### `nice_ptr<T>` (Non-Owning Pointer)
Use `Utilities::nice_ptr<T>` instead of raw pointers for observing externally-managed lifetimes. Defined in `utilities/Include/Utilities/nice_ptr.h`.

### DependencyContainer
`Jaws::DependencyContainer` holds non-owning references to all shared dependencies. Components receive it by `const&` and extract what they need. See `applications/Jaws/Source/DependencyContainer.h`.

### Protobuf Configuration
Config schema in `config/protobuf/SharkConfiguration/SharkConfiguration.proto` (proto3, package `cat.shark`). Top-level message: `Config`. Loaded as JSON from NVM, parsed via `google::protobuf::util::JsonStringToMessage`.

## Unit Testing

**Framework**: Google Test + Google Mock.

**Key Points**:
- Test names reflect requirements (not generic `Test1`, `Test2`)
- Use `EXPECT_THAT` with matchers: `EXPECT_THAT(value, Eq(expected))`
- Use test fixtures: `class MyTest : public ::testing::Test { /* setup */ }; TEST_F(MyTest, RequirementName)`
- Include `.cpp` files directly to access static/anonymous-namespace functions
- Every mock includes: `EnsureMockKindIsSpecified(ClassName)` (from `Utilities/DataEngineMock.h`)

See [design/UNIT_TESTING.md](../design/UNIT_TESTING.md) for comprehensive testing policy, mock patterns, organization, and common patterns.

## Libraries

| Library | Type | Location | Purpose |
|---|---|---|---|
| `DataEngineUtilities` | STATIC | `utilities/` | Conversions, filesystem, CSV, XML, time, test helpers |
| `UtilitiesHeaders` | INTERFACE | `utilities/` | Header-only utilities |
| `SharkKraken` | STATIC | `shark/Kraken/` | Platform C API wrappers (CDL2, SCL, HAL, OEL, NVM) |
| `SharkMocks` | STATIC | `shark/SharkMocks/` | GMock mocks for Shark public interfaces |
| `ConfigLibrary` | STATIC | `config/` | Protobuf-generated config, IP address utilities |

## External Dependencies (Conan)

| Dependency | Version | Purpose |
|---|---|---|
| Boost | 1.87+ | Signals2 (observables), logging, algorithms |
| protobuf | 5.27+ | Configuration serialization |
| gtest | 1.15+ | Unit testing framework |
| nlohmann_json | 3.11+ | JSON configuration parsing |
| crc32c | 1.1+ | CRC calculations |
| pugixml | 1.14+ | XML processing |
| simple-websocket-server | 2.0+ | WebSocket (JawsSubscriber only) |
| middleware-cpp | 2.1+ | Middleware integration (default) |
| ros2 | jazzy+ | ROS2 integration (when middleware=ros2) |

All are shared libraries. Conan dependencies configured in [conanfile.py](../../conanfile.py).
