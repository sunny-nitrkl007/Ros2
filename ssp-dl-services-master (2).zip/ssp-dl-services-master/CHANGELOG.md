# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [5.0.0] - 2026-05-15

### Breaking Changes
- Jaws was updated to use cate_middleware version 2.1.0
- SharkConfiguration.proto Diagnostics restructured: peer nodes moved into repeated `DiagnosticClientCanPort` messages (each with their own `can_port`), internal codes moved into an `InternalCodeList` message with its own `service_can_port`, and `CodeType`/`StorageType` enums moved inside `InternalCodeList`

### Added
- [33546 BDT Configuration](https://dev.azure.com/cat-ciss/G7/_workitems/edit/33546)
  Added BDT definition entries to SharkConfiguration proto and ConfigFactory. Updated Velocirider and JawsSubscriber configs with BDT support.
- [33549 Middleware BDT Read/Write Servers](https://dev.azure.com/cat-ciss/G7/_workitems/edit/33549)
  Jaws now creates BDT read and write servers, connecting BDT shark bytes to middleware parameter services.

### Changed
- [33961 Multiple Data Link Diagnostics](https://dev.azure.com/cat-ciss/G7/_workitems/edit/33961)
  Diagnostics now support multiple CAN ports. Each CAN port can have its own set of diagnostic peer nodes.
- [33663 Jaws Initialization Robustness](https://dev.azure.com/cat-ciss/G7/_workitems/edit/33663)
  Replaced blocking initialization with a queued callback approach via InitializationGatingConfigBuilder. Middleware callbacks assert initialization has completed, and ParameterWrapper initializes middleware as late as possible.
- [33966 Debugging Improvements](https://dev.azure.com/cat-ciss/G7/_workitems/edit/33966)
  Debug verities can now be created, libasan removed from RelWithDebInfo verities, and middleware log level is set in a single place.
- [34242 Update to Middleware 2.1.0](https://dev.azure.com/cat-ciss/G7/_workitems/edit/34242)
  Updated to cate_middleware/2.1.0.
- [33964 Increase Max PGB Groups Value](https://dev.azure.com/cat-ciss/G7/_workitems/edit/33964)
  Increased max PGB groups value from 130 to 170.
- [33612 Update ssp-linux for SCL CAL Client](https://dev.azure.com/cat-ciss/G7/_workitems/edit/33612)
  Updated ssp-linux and eliminated most a7hx references.

## [4.0.0] - 2026-04-09

### Breaking Changes
- Jaws was updated to use cate_middleware version 2.0.1
- Removed ecm_identity_number from the Identity message in the SharkConfiguration.  This was never actually used and is actually generated from the hardware part number to make it unique.
- Removed deprecated DeviceId message from the PeerNode message.  This was moved to a higher level previously so that all can ports would reply with this information.

### Added
- [27139 Basic Write from Middleware](https://dev.azure.com/cat-ciss/G7/_workitems/edit/27139)
  Jaws now supports writing PID values from middleware to the data link. Includes conversion of binary, float, and uint values to byte data using PID definitions.
  Multi-byte PID write support for binary and string types
- [32123 Machine Security System Middleware Interface](https://dev.azure.com/cat-ciss/G7/_workitems/edit/32123)
  MachineSecuritySystemWrapper ties all MSS commands (Log In, Log Out, Unlock, Lock) and operator key information to middleware
- [32254 Internal Code Control through Jaws](https://dev.azure.com/cat-ciss/G7/_workitems/edit/32254)
  Internal code subscribers can now be created from configuration, connecting internal diagnostic codes to middleware.
- [30526 Support All Can Ports](https://dev.azure.com/cat-ciss/G7/_workitems/edit/30526)
  All six CAN ports are now supported for all previously supported protocols

### Changed
- [32930 Jaws Startup Robustness](https://dev.azure.com/cat-ciss/G7/_workitems/edit/32930)
  Improved startup robustness: safely handle requests for invalid shark byte ids, catch exceptions for unresolvable reads/writes, NVM stored configuration is cleared if Jaws crashes at startup
- [33228 Update Codes AR Support](https://dev.azure.com/cat-ciss/G7/_workitems/edit/33228)
  Resolved invalid annunciation values so that wci's 1, 2, 3 set annunciation values to 1, 4, 6 respectively and elevated all WCI 3 codes to annunciation value 6.
- [32733 Internal Code List Fix](https://dev.azure.com/cat-ciss/G7/_workitems/edit/32733)
  Fixed own codes not updating by swapping vehicle system and vehicle system instance parameters in name creation.
- [32971 CatEValidation Adoption](https://dev.azure.com/cat-ciss/G7/_workitems/edit/32971)
  Jaws release recipe adopted CatEValidation checks.
- [31629 Updated Verity Scripts](https://dev.azure.com/cat-ciss/G7/_workitems/edit/31629)
  Switched to verity creation tool cate_verity.

## [3.0.0] - 2026-02-19

### Breaking Changes
- SharkConfiguration.proto:
  - The device_id field in J1939DataLink is now deprecated. Instead, use the top-level Config's j1939_device_id field.
  - Diagnostic configuration within each peer node is now deprecated.  Instead, use the top-level Config's diagnostics field.
- The SharkConfig.h used by ConfigFactory changed accordingly
  - DeviceIdEntry was removed from J1939LinkEntry and j1939DeviceIdEntry was added to SharkConfig.
  - DiagnosticsEntry was removed from PeerNodeEntry and was added to SharkConfig

### Added
- [30258 Machine Security System Phase I](https://dev.azure.com/cat-ciss/G7/_workitems/edit/30258)
  Machine security system methods to Log In, Log Out, Unlock, Lock and request the current operator are implemented at the data link layer but require one more story to tie them to the middleware.  There is a new configuration available for machine security system that will be tied to a single data link.
- [31362 Internal Codes](https://dev.azure.com/cat-ciss/G7/_workitems/edit/31362)
  Internal EDDT based codes (diagnostics and events) can now be configured and activated at the data link layer but require an additional story to tie them to middleware.
- [30257 J1939 Pgn Broadcast](https://dev.azure.com/cat-ciss/G7/_workitems/edit/30257)
  Pgn broadcast will now subscribe to a configured middleware id to receive the 8-byte payload of a pgn and broadcast on the configured can port.  Further work could be completed to configure individual spn values instead of the whole pgn.
- [31360 Pgn Read Client](https://dev.azure.com/cat-ciss/G7/_workitems/edit/31360)
  Pgn reads can now be performed by reading the configured middleware id.  The full 8-byte payload is the only data currently returned through middleware, further work could be completed to configure individual spn values instead of the whole pgn.

### Changed
- [27137 Multiple Can Port Support](https://dev.azure.com/cat-ciss/G7/_workitems/edit/27137)
  All features unless otherwise specified can be configured on the first two can ports.  This includes pgb, adt, all pgn varieties and extension id responses to common informational messages.
- Jaws was updated to use the latest 1.0.1 release of middleware

## [2.0.0] - 2025-12-17

### Added

- [27137](https://dev.azure.com/cat-ciss/G7/_workitems/edit/27137)
  We can now configure the first two can ports to be used with pgb and adt.  The rest
  of the protocols and features currently supported are planned to be finished by
  package 5 but will currently only work on the first j1939 link

- [30428](https://dev.azure.com/cat-ciss/G7/_workitems/edit/30428/)
  SharkConfiguration.proto pgn periodic broadcast configuration is now available
  but there is further work required to tie the values being sent to middleware values

### Changed

- [30579](https://dev.azure.com/cat-ciss/G7/_workitems/edit/30869/)
  Jaws was updated to the newest version of the SDK package cate_sdk_arm64_guest/arm64_guest_os_2025.4.0

- [30949](https://dev.azure.com/cat-ciss/G7/_workitems/edit/30848/)
  Jaws was updated to use the latest 1.0.0 release of middleware

- SharkConfiguration.proto Naming
  Instead of specifying types of middleware ids (publish/subscribe/read/write) in the
  protobuf variable names, we decided to use the generic term middleware_id when
  referring to any type of middleware string id

## [1.1.0] - 2025-11-12

### Added

- [30360](https://dev.azure.com/cat-ciss/G7/_workitems/edit/30360)
  Enable diagnostic request and retrieval of group 2 additional information for
  logged EDDT diagnostic and event codes.
- [28465](https://dev.azure.com/cat-ciss/G7/_workitems/edit/28465)
  Update Jaws to be built with the common conan profiles.
- [29930](https://dev.azure.com/cat-ciss/G7/_workitems/edit/29930)
  Update Jaws to use middleware-cpp 2025.4.1
- [30253](https://dev.azure.com/cat-ciss/G7/_workitems/edit/30253)
  Enable Core Dumps for Jaws. As system watches are not currently
supported, clients seeking to report crashes will need to manually collect
them from `/tmp/cores`. The name will probably start with "Jaws".

### Changed

- [29924](https://dev.azure.com/cat-ciss/G7/_workitems/edit/29924)
  Allow J1939 configuration to target CAN1.  Initial revision would only accept
  CAN0 as the configured can port.  This is still a single can port usage,
  multiple can ports simultaneous will be supported in the future.

[1.1.0]: https://gitgis.ecorp.cat.com/es-csf-core-info/dl-services/ssp-dl-services/-/tree/Jaws_1.1.0
[2.0.0]: https://gitgis.ecorp.cat.com/es-csf-core-info/dl-services/ssp-dl-services/-/tree/Jaws_2.0.0
[3.0.0]: https://gitgis.ecorp.cat.com/es-csf-core-info/dl-services/ssp-dl-services/-/tree/Jaws_3.0.0
[4.0.0]: https://gitgis.ecorp.cat.com/es-csf-core-info/dl-services/ssp-dl-services/-/tree/Jaws_4.0.0
[5.0.0]: https://gitgis.ecorp.cat.com/es-csf-core-info/dl-services/ssp-dl-services/-/tree/Jaws_5.0.0