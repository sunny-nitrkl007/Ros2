# Data Link Read/Write Service Schema <!-- omit in toc -->

- [Middleware-cpp Read/Write Schema](#middleware-cpp-readwrite-schema)
  - [Schema Overview](#schema-overview)
  - [Read/Write Interfaces](#readwrite-interfaces)
  - [Embedded into DDS IDL](#embedded-into-dds-idl)
  - [Pros of Current Protobuf + Fast DDS Approach](#pros-of-current-protobuf--fast-dds-approach)
  - [Cons of Current Protobuf + Fast DDS Approach](#cons-of-current-protobuf--fast-dds-approach)
- [Path forward](#path-forward)
  - [Service Model](#service-model)
  - [Message and Service Definitions](#message-and-service-definitions)
  - [PID Basic Write Flow](#pid-basic-write-flow)
  - [C++ Usage Examples](#c-usage-examples)
    - [PID Basic Write Server Example](#pid-basic-write-server-example)
    - [PID Basic Write Client Example](#pid-basic-write-client-example)
    - [Read Client Example](#read-client-example)

As we move from Middleware-cpp to ROS 2, parameter publish/subscribe can move to ROS 2 topics, but parameter read/write operations should move to ROS 2 services. Reads and writes are request/response operations, can take time to complete on the physical data link, and need a clear result for the caller.

This document focuses on the equivalent of Middleware-cpp `IRead` and `IWrite`, using PID Basic Write as the concrete example.

## Middleware-cpp Read/Write Schema

### Schema Overview

The existing read/write APIs reuse the same `middleware_parameter.proto` messages used by parameter publishing:

```protobuf
syntax = "proto3";
package cat.middleware.parameter;

message Value {
    oneof selection {
        double double_value     = 1;
        string string_value     = 2;
        bytes binary_value      = 3;
        bool boolean_value      = 4;
        uint64 uinteger64_value = 5;
    }
}
enum Quality {
    QUALITY_UNSPECIFIED  = 0;
    QUALITY_GOOD         = 1;
    QUALITY_BAD          = 2;
    QUALITY_NOT_RECEIVED = 3;
}
message Data {
    Value value     = 1;
    Quality quality = 2;
}
message Info {
    string identity = 1;
    uint32 unit     = 2;
}
message Parameter {
    Info info = 1;
    Data data = 2;
}
```

The `Data` message is used as the write request payload. The full `Parameter` message is returned to the caller so the result includes identity, unit, value, and quality.

### Read/Write Interfaces

The Middleware-cpp service API separates client and server registration from the protobuf payload itself:

```cpp
enum Status
{
    UNSPECIFIED,
    SUCCESS,
    FAILURE
};

class IRead : public IBasic
{
public:
    struct ReadStatus
    {
        Status status{Status::UNSPECIFIED};
    };
    using OnRequest = std::function<void(ReadStatus const&, Parameter const&)>;

    virtual bool Read(OnRequest&& callback) = 0;
};

class IWrite : public IBasic
{
public:
    struct WriteStatus
    {
        Status status{Status::UNSPECIFIED};
    };
    using OnCompletion = std::function<void(WriteStatus const&, Parameter const&)>;

    virtual bool Write(Data const& data, OnCompletion&& callback) = 0;
};
```

Servers are registered by parameter identity. For example, Jaws registers PID Basic Write with `AddServerWrite(middleware_id, callback)`. The write callback receives a request key, the parameter identity, and the requested `Data`. It can return `Data` immediately or return `std::nullopt` to indicate asynchronous completion. For asynchronous completion, Jaws later calls `IService::Reply(key, data)`.

PID Basic Write uses that asynchronous path:

1. The write request contains a typed protobuf `Data` value.
2. Jaws validates that the active value type matches the PID definition.
3. Jaws converts the requested value to raw PID bytes.
4. Shark writes the bytes to the physical data link.
5. Jaws replies with `QUALITY_GOOD` and the resulting value when the write succeeds, or `QUALITY_BAD` when it fails.

### Embedded into DDS IDL

The protobuf payload and request/reply metadata are transported through the Middleware-cpp DDS layer as opaque bytes. Conceptually, the actual parameter schema is still protobuf, while DDS provides the transport and correlation machinery.

```idl
// message.idl -- the actual DDS topic payload shape
struct Message {
    string additional_information;
    sequence<octet> protobuf;
};
```

This means read/write clients and servers use a service-like API, but the wire schema is not visible to the DDS type system.

### Pros of Current Protobuf + Fast DDS Approach

| Pro | Explanation |
|-----|-------------|
| **Shared parameter payload** | Publish, read, and write all use the same `Value`, `Data`, and `Parameter` messages. |
| **`oneof` for variant types** | The active write value is explicit and type-safe in protobuf generated code. |
| **Schema evolution** | Proto3 allows compatible field additions without rebuilding every client at the same time. |
| **Asynchronous server completion** | Server callbacks can return `std::nullopt` and reply later, which matches physical data-link operations that complete after a bus transaction. |
| **Separate service status and value quality** | `ReadStatus`/`WriteStatus` reports request completion while `Data.quality` reports the validity of the returned parameter value. |

### Cons of Current Protobuf + Fast DDS Approach

| Con | Explanation |
|-----|-------------|
| **Opaque to DDS tooling** | The request and response values are protobuf bytes, so DDS introspection, recording, and filtering cannot inspect the parameter fields. |
| **Double serialization overhead** | Data is serialized by protobuf and then carried through the DDS transport payload. |
| **Read/write shape is hidden in C++ APIs** | `Read()` has no protobuf request message, `Write()` takes `Data`, and both callbacks return status plus `Parameter`. That operation contract is not captured in an IDL-like schema. |
| **Limited result detail** | Middleware status only has `UNSPECIFIED`, `SUCCESS`, and `FAILURE`; parameter quality only says whether the returned value is good, bad, or not received. A client cannot reliably distinguish wrong type, busy, timeout, rejected by ECM, or transport failure. |
| **Parameter identity is duplicated** | Identity is part of service configuration and returned again in `Parameter.info.identity`. This is useful for generic clients, but redundant for single-parameter read/write calls. |
| **Protobuf population is clunky** | Write clients must manually set the correct `oneof` field and usually set `QUALITY_GOOD` even though request quality does not describe a sampled value. |

## Path forward

With the move to ROS 2, parameter read/write should use normal ROS 2 services and ROS 2 interface generation. This makes read/write operations visible to ROS tooling, removes protobuf from this path, and expresses the request/response contract in `.srv` files.

The main tradeoffs are the same ones described for [parameter topics](./data-link-parameters-msg-schema.md):

| Con | Explanation |
|-----|-------------|
| **No union type** | The request value uses the same discriminator-plus-parallel-fields pattern as `ParameterValue.msg`. |
| **No enumerations** | Service status, reason, value type, and quality use `uint8` constants. |
| **No optional fields** | Every response field has a default value. The `status` and `reason` fields tell the client which values are meaningful. |
| **No backwards compatibility** | All service clients and servers must be built against the same `.srv` and `.msg` schema. |

The lack of backwards compatibility is acceptable for this first migration because the service schema should be small and stable: read requests are empty, write requests carry a parameter value, and both responses carry a result and the current parameter value.

### Service Model

Each readable or writable parameter should be exposed as its own ROS 2 service. The service name identifies the parameter, so the request does not need an identity field.

Examples:

| Middleware-cpp concept | ROS 2 service |
|------------------------|---------------|
| `AddServerRead("engine_speed", ...)` | `/data_link_engine/parameters/engine_speed/read` |
| `AddServerWrite("engine_speed", ...)` | `/data_link_engine/parameters/engine_speed/write` |
| PID Basic Write middleware ID | `/data_link_engine/parameters/<middleware_id>/write` |

This keeps each service strongly associated with one configured parameter while still allowing generic clients to discover and call services by name.

Responses should separate service execution status from parameter value quality:

| Field | Meaning |
|-------|---------|
| `status` | Whether the read/write request completed successfully from the service perspective. |
| `reason` | A coarse machine-readable reason when `status != STATUS_SUCCESS`. |
| `parameter.quality` | Whether the returned parameter value is valid. A request can complete successfully and still return a bad or not-received parameter value. |

### Message and Service Definitions

The existing `ParameterValue.msg` and `Parameter.msg` can be reused by services. The response shape should be factored into a small result message so read and write services behave the same way.

**`data_link_engine_interfaces/msg/ParameterServiceResult.msg`**
```
# Request handling status. This is separate from Parameter.quality.
uint8 STATUS_UNSPECIFIED = 0
uint8 STATUS_SUCCESS     = 1
uint8 STATUS_FAILURE     = 2

# Coarse reason for failures and rejected requests.
uint8 REASON_UNSPECIFIED      = 0
uint8 REASON_BUSY             = 1
uint8 REASON_TIMEOUT          = 2
uint8 REASON_PROTOCOL_ERROR   = 3
uint8 REASON_NOT_AVAILABLE    = 4

uint8 status
uint8 reason

# Current value associated with the parameter service.
Parameter parameter
```

**`data_link_engine_interfaces/srv/ReadParameter.srv`**
```
# The service name identifies the parameter.
---
ParameterServiceResult result
```

**`data_link_engine_interfaces/srv/WriteParameter.srv`**
```
# Desired value for the parameter identified by the service name.
ParameterValue value
---
ParameterServiceResult result
```

For PID Basic Write, the request value type must match the PID definition:

| PID definition | Accepted write request value |
|----------------|------------------------------|
| Raw single-byte or packed PID | `TYPE_BINARY` with exactly the configured byte count |
| Scaled floating-point PID | `TYPE_DOUBLE` |
| Scaled unsigned integer PID | `TYPE_UINT64` |
| Multi-byte binary PID | `TYPE_BINARY` within the configured length range |
| Multi-byte string PID | `TYPE_STRING` within the configured length range |

### PID Basic Write Flow

PID Basic Write should map cleanly to `WriteParameter.srv`:

1. A client calls `/data_link_engine/parameters/<middleware_id>/write` with a `ParameterValue`.
2. The server validates that `value.type` matches the configured PID definition.
3. The server converts the requested value to the byte ordering and scaling required by the PID definition.
4. The server starts the Shark write and keeps the ROS 2 service request open until the write completes or times out.
5. On success, the response has `result.status = STATUS_SUCCESS`, `result.reason = REASON_UNSPECIFIED`, and `result.parameter.quality = QUALITY_GOOD`.
6. On a rejected request, timeout, or data-link failure, the response has `result.status = STATUS_FAILURE`, a non-`REASON_UNSPECIFIED` reason, and `result.parameter.quality = QUALITY_BAD` or `QUALITY_NOT_RECEIVED` as appropriate.

Unlike Middleware-cpp, ROS 2 service servers do not need an explicit request key. The `rclcpp` service response object is the correlation point. The server can still complete asynchronously by capturing the request header and sending the response after Shark reports completion.

### C++ Usage Examples

The following snippets show the intended shape of a PID Basic Write service and clients. They are illustrative rather than final production code.

#### PID Basic Write Server Example

```cpp
#include <functional>
#include <memory>
#include <vector>
#include <rmw/types.h>
#include <rclcpp/rclcpp.hpp>

#include <data_link_engine_interfaces/msg/parameter.hpp>
#include <data_link_engine_interfaces/msg/parameter_service_result.hpp>
#include <data_link_engine_interfaces/msg/parameter_value.hpp>
#include <data_link_engine_interfaces/srv/write_parameter.hpp>

class PidBasicWriteService : public rclcpp::Node
{
public:
    PidBasicWriteService()
        : Node("pid_basic_write_service")
    {
        using WriteParameter = data_link_engine_interfaces::srv::WriteParameter;

        m_service = create_service<WriteParameter>(
            "/data_link_engine/parameters/engine_speed/write",
            [this](
                std::shared_ptr<rmw_request_id_t> spRequestHeader,
                WriteParameter::Request::SharedPtr spRequest)
            {
                HandleWrite(std::move(spRequestHeader), *spRequest);
            });
    }

private:
    using WriteParameter = data_link_engine_interfaces::srv::WriteParameter;
    using WriteResponse = WriteParameter::Response;
    using WriteResponsePtr = WriteParameter::Response::SharedPtr;

    void HandleWrite(std::shared_ptr<rmw_request_id_t> spRequestHeader, WriteParameter::Request const& request)
    {
        using data_link_engine_interfaces::msg::Parameter;
        using data_link_engine_interfaces::msg::ParameterServiceResult;
        using data_link_engine_interfaces::msg::ParameterValue;

        auto spResponse = std::make_shared<WriteResponse>();
        spResponse->result.parameter.quality = Parameter::QUALITY_BAD;

        if (request.value.type != ParameterValue::TYPE_DOUBLE)
        {
            spResponse->result.status = ParameterServiceResult::STATUS_FAILURE;
            spResponse->result.reason = ParameterServiceResult::REASON_UNSUPPORTED_TYPE;
            SendWriteResponse(spRequestHeader, spResponse);
            return;
        }

        auto const requestedValue = request.value.double_value;
        auto const rawValue = ConvertEngineSpeedToRawPidBytes(request.value.double_value);
        StartPidWrite(
            rawValue,
            [this, spRequestHeader = std::move(spRequestHeader), requestedValue](bool writeSucceeded)
            {
                OnWriteCompleted(spRequestHeader, requestedValue, writeSucceeded);
            });
    }

    void OnWriteCompleted(
        std::shared_ptr<rmw_request_id_t> const& spRequestHeader,
        double requestedValue,
        bool writeSucceeded)
    {
        using data_link_engine_interfaces::msg::Parameter;
        using data_link_engine_interfaces::msg::ParameterServiceResult;
        using data_link_engine_interfaces::msg::ParameterValue;

        auto spResponse = std::make_shared<WriteResponse>();
        spResponse->result.parameter.quality = Parameter::QUALITY_BAD;

        if (!writeSucceeded)
        {
            spResponse->result.status = ParameterServiceResult::STATUS_FAILURE;
            spResponse->result.reason = ParameterServiceResult::REASON_PROTOCOL_ERROR;
            SendWriteResponse(spRequestHeader, spResponse);
            return;
        }

        spResponse->result.status = ParameterServiceResult::STATUS_SUCCESS;
        spResponse->result.reason = ParameterServiceResult::REASON_UNSPECIFIED;
        spResponse->result.parameter.header.stamp = get_clock()->now();
        spResponse->result.parameter.unit = 0;
        spResponse->result.parameter.value.type = ParameterValue::TYPE_DOUBLE;
        spResponse->result.parameter.value.double_value = requestedValue;
        spResponse->result.parameter.quality = Parameter::QUALITY_GOOD;
        SendWriteResponse(spRequestHeader, spResponse);
    }

    void SendWriteResponse(
        std::shared_ptr<rmw_request_id_t> const& spRequestHeader,
        WriteResponsePtr const& spResponse)
    {
        m_service->send_response(*spRequestHeader, spResponse);
    }

    static std::vector<uint8_t> ConvertEngineSpeedToRawPidBytes(double value);
    static void StartPidWrite(std::vector<uint8_t> const& bytes, std::function<void(bool)>&& onCompletion);

    rclcpp::Service<WriteParameter>::SharedPtr m_service;
};
```

#### PID Basic Write Client Example

```cpp
#include <memory>
#include <rclcpp/rclcpp.hpp>

#include <data_link_engine_interfaces/msg/parameter_service_result.hpp>
#include <data_link_engine_interfaces/msg/parameter_value.hpp>
#include <data_link_engine_interfaces/srv/write_parameter.hpp>

class PidBasicWriteClient : public rclcpp::Node
{
public:
    PidBasicWriteClient()
        : Node("pid_basic_write_client")
    {
        m_client = create_client<data_link_engine_interfaces::srv::WriteParameter>(
            "/data_link_engine/parameters/engine_speed/write");
    }

    void WriteEngineSpeed(double engineSpeed)
    {
        using data_link_engine_interfaces::msg::ParameterServiceResult;
        using data_link_engine_interfaces::msg::ParameterValue;

        auto spRequest = std::make_shared<data_link_engine_interfaces::srv::WriteParameter::Request>();
        spRequest->value.type = ParameterValue::TYPE_DOUBLE;
        spRequest->value.double_value = engineSpeed;

        m_client->async_send_request(
            spRequest,
            [this](rclcpp::Client<data_link_engine_interfaces::srv::WriteParameter>::SharedFuture future)
            {
                auto const& result = future.get()->result;
                if (result.status != ParameterServiceResult::STATUS_SUCCESS)
                {
                    RCLCPP_WARN(
                        get_logger(),
                        "Write failed: reason=%u",
                        result.reason);
                    return;
                }

                RCLCPP_INFO(
                    get_logger(),
                    "Write completed with quality=%u",
                    result.parameter.quality);
            });
    }

private:
    rclcpp::Client<data_link_engine_interfaces::srv::WriteParameter>::SharedPtr m_client;
};
```

#### Read Client Example

```cpp
#include <memory>
#include <rclcpp/rclcpp.hpp>

#include <data_link_engine_interfaces/msg/parameter.hpp>
#include <data_link_engine_interfaces/msg/parameter_service_result.hpp>
#include <data_link_engine_interfaces/srv/read_parameter.hpp>

class ParameterReadClient : public rclcpp::Node
{
public:
    ParameterReadClient()
        : Node("parameter_read_client")
    {
        m_client = create_client<data_link_engine_interfaces::srv::ReadParameter>(
            "/data_link_engine/parameters/engine_speed/read");
    }

    void ReadEngineSpeed()
    {
        using data_link_engine_interfaces::msg::Parameter;
        using data_link_engine_interfaces::msg::ParameterServiceResult;

        auto spRequest = std::make_shared<data_link_engine_interfaces::srv::ReadParameter::Request>();
        m_client->async_send_request(
            spRequest,
            [this](rclcpp::Client<data_link_engine_interfaces::srv::ReadParameter>::SharedFuture future)
            {
                auto const& result = future.get()->result;
                if (result.status != ParameterServiceResult::STATUS_SUCCESS)
                {
                    RCLCPP_WARN(get_logger(), "Read failed: reason=%u", result.reason);
                    return;
                }

                if (result.parameter.quality != Parameter::QUALITY_GOOD)
                {
                    RCLCPP_WARN(get_logger(), "Read returned quality=%u", result.parameter.quality);
                    return;
                }

                RCLCPP_INFO(
                    get_logger(),
                    "Engine speed = %.2f",
                    result.parameter.value.double_value);
            });
    }

private:
    rclcpp::Client<data_link_engine_interfaces::srv::ReadParameter>::SharedPtr m_client;
};
```