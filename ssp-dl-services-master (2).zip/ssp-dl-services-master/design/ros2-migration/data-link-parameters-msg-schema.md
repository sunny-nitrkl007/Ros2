# Data Link Parameters MSG Schema <!-- omit in toc -->

- [Middleware-cpp Protobuf Schema](#middleware-cpp-protobuf-schema)
  - [Schema Overview](#schema-overview)
  - [Embedded into DDS IDL](#embedded-into-dds-idl)
  - [Pros of Current Protobuf + Fast DDS Approach](#pros-of-current-protobuf--fast-dds-approach)
  - [Cons of Current Protobuf + Fast DDS Approach](#cons-of-current-protobuf--fast-dds-approach)
- [Path forward](#path-forward)
  - [Message Definitions](#message-definitions)
  - [C++ Usage Examples](#c-usage-examples)
    - [Publisher Example](#publisher-example)
    - [Subscriber Example](#subscriber-example)

As we move from Middleware-cpp to ROS 2, we need to determine how to transfer parameter values -- do we continue to use Protobuf or do we use the build in ROS 2 / DDS serialization?

## Middleware-cpp Protobuf Schema

### Schema Overview

The current `middleware_parameter.proto` defines the parameter service message schema:

```protobuf
syntax = "proto3";
package cat.middleware.parameter;

message Value {
    oneof selection {
        double double_value     = 1;
        string string_value     = 2;
        bytes binary_value      = 3;
        bool boolean_value      = 4;
        uint64 uinteger64_value = 5;
    }
}
enum Quality {
    QUALITY_UNSPECIFIED  = 0;
    QUALITY_GOOD         = 1;
    QUALITY_BAD          = 2;
    QUALITY_NOT_RECEIVED = 3;
}
message Data {
    Value value     = 1;
    Quality quality = 2;
}
message Info {
    string identity = 1;
    uint32 unit     = 2;
}
message Parameter {
    Info info = 1;
    Data data = 2;
}
```

### Embedded into DDS IDL

The serialized protobuf bytes are then serialized again inside DDS topics:

```idl
// message.idl — the actual DDS topic
struct Message {
    string additional_information;
    sequence<octet> protobuf;
};
```

This means DDS is used as an **opaque byte transport**. The actual schema lives in protobuf, not in the DDS type system.

### Pros of Current Protobuf + Fast DDS Approach

| Pro | Explanation |
|-----|-------------|
| **Schema evolution** | Proto3 has excellent forward/backward compatibility. Adding fields won't break existing subscribers. Field numbers are stable wire identifiers. |
| **`oneof` for variant types** | The `Value.selection` oneof is a clean way to express "one of N types" with type-safe accessors. Receivers can `switch` on the active case. |
| **Compact wire format** | Protobuf uses varint encoding, field tags, and omits default values — typically 2-10x smaller than CDR for sparse data. |
| **Decoupled from DDS type system** | Changing the parameter schema doesn't require regenerating DDS IDL types, re-running `fastddsgen`, or touching the DDS layer at all. |
| **Binary payload support** | `bytes binary_value` allows arbitrary payloads (firmware blobs, calibration files) within the same schema. |

### Cons of Current Protobuf + Fast DDS Approach

| Con | Explanation |
|-----|-------------|
| **No way to provide detailed error information** | When quality is QUALITY_BAD, consumers have no way to know why. The libraries and protocols can give us extra information, like "retry later". |
| **PID DSI information cannot be provided** | There is no way to provide specific DSI codes to consumers who want it. |
| **Double serialization overhead** | Data is serialized twice: once by protobuf, then the resulting bytes are serialized again by CDR into DDS. This adds CPU cost and latency. |
| **Opaque to DDS middleware** | DDS content-filtered topics, DDS recording/replay tools, and DDS introspection cannot inspect the protobuf payload. The data is just a blob of bytes to the DDS layer. |
| **No DDS-level filtering** | Cannot use DDS content filters like "only deliver parameters where quality == GOOD" because the DDS layer doesn't understand the payload structure. |
| **Additional dependency** | Requires the protobuf compiler (`protoc`) and runtime library in addition to Fast DDS — increases build complexity and binary size. |
| **Protobuf population is clunky** | Protobuf has deliberately chosen not to utilize modern C++ which leads to a clunky interface for reading and writing values. |

## Path forward

With the move to ROS 2, we should utilize the built-in serialization. This solves various cons listed above, but does come with some drawbacks.

| Con | Explanation |
|-----|-------------|
| **No union type** | Use a discriminator field along with parallel value fields. |
| **No enumerations** | Use uint8 constants. |
| **No optional fields** | All fields are initialized to default values. The default value for any field may be overridden in the MSG file. |
| **No backwards compatibility** | All clients must be built using the same MSG schema. |

The biggest issue is probably the lack of backwards compatibility as new fields are added. I believe this is an acceptable limitation because the schema will stabilize over time. The changes being discussed for the schema going forward are major and would functionally be breaking changes for clients in the Protobuf world.

### Message Definitions

The MSG schema should preserve the useful value semantics while fitting normal ROS 2 topic usage. Since the topic itself identifies the parameter, the payload can stay focused on the sampled value, its unit, its quality, and the sample timestamp.

The schema will be flattened quite a bit, too.

Addressing other problems with the Protobuf schema is out of scope for this initial schema.


**`data_link_engine_interfaces/msg/ParameterValue.msg`**
```
# Discriminator for the active value type
uint8 TYPE_UNSPECIFIED = 0
uint8 TYPE_DOUBLE   = 1
uint8 TYPE_STRING   = 2
uint8 TYPE_BINARY   = 3
uint8 TYPE_BOOLEAN  = 4
uint8 TYPE_UINT64   = 5

uint8 type

# Value fields — only the one matching 'type' is meaningful
float64 double_value
string string_value
uint8[] binary_value
bool boolean_value
uint64 uint64_value
```

**`data_link_engine_interfaces/msg/Parameter.msg`**
```
# Coarse validity of the current value
uint8 QUALITY_UNSPECIFIED  = 0
uint8 QUALITY_GOOD         = 1
uint8 QUALITY_BAD          = 2
uint8 QUALITY_NOT_RECEIVED = 3

# Source timestamp for this value sample. Useful for latency calculations.
builtin_interfaces/Time stamp

# Unit associated with the current value.
uint32 unit

# Current parameter value
data_link_engine_interfaces/ParameterValue value

# Coarse validity of the current value
uint8 quality
```

### C++ Usage Examples

The following snippets show how the proposed messages would be used from a typical publisher and subscriber.

#### Publisher Example

```cpp
#include <chrono>
#include <memory>
#include <rclcpp/rclcpp.hpp>

#include <data_link_engine_interfaces/msg/parameter.hpp>

class ParameterPublisher : public rclcpp::Node
{
public:
    ParameterPublisher()
        : Node("parameter_publisher")
    {
        m_publisher = create_publisher<data_link_engine_interfaces::msg::Parameter>(
            "/data_link_engine/parameters/engine_speed",
            10);

        m_timer = create_wall_timer(
            std::chrono::seconds(1),
            [this]() { PublishEngineSpeed(); });
    }

private:
    void PublishEngineSpeed()
    {
        auto message = data_link_engine_interfaces::msg::Parameter{};

        message.stamp = get_clock()->now();
        message.unit = 0;

        message.quality = data_link_engine_interfaces::msg::Parameter::QUALITY_GOOD;
        message.value.type = data_link_engine_interfaces::msg::ParameterValue::TYPE_DOUBLE;
        message.value.double_value = 1850.0;

        m_publisher->publish(message);
    }

    rclcpp::Publisher<data_link_engine_interfaces::msg::Parameter>::SharedPtr m_publisher;
    rclcpp::TimerBase::SharedPtr m_timer;
};
```

#### Subscriber Example

```cpp
#include <memory>
#include <rclcpp/rclcpp.hpp>

#include <data_link_engine_interfaces/msg/parameter.hpp>

class ParameterSubscriber : public rclcpp::Node
{
public:
    ParameterSubscriber()
        : Node("parameter_subscriber")
    {
        m_subscription = create_subscription<data_link_engine_interfaces::msg::Parameter>(
            "/data_link_engine/parameters/engine_speed",
            10,
            [this](data_link_engine_interfaces::msg::Parameter::SharedPtr spMessage)
            {
                HandleParameter(*spMessage);
            });
    }

private:
    void HandleParameter(data_link_engine_interfaces::msg::Parameter const& message) const
    {
        if (message.quality != data_link_engine_interfaces::msg::Parameter::QUALITY_GOOD)
        {
            RCLCPP_WARN(
                get_logger(),
                "Topic '/data_link_engine/parameters/engine_speed' quality=%u",
                message.quality);
            return;
        }

        switch (message.value.type)
        {
            case data_link_engine_interfaces::msg::ParameterValue::TYPE_DOUBLE:
                RCLCPP_INFO(
                    get_logger(),
                    "Engine speed = %.2f",
                    message.value.double_value);
                break;

            case data_link_engine_interfaces::msg::ParameterValue::TYPE_BOOLEAN:
                RCLCPP_INFO(
                    get_logger(),
                    "Boolean value = %s",
                    message.value.boolean_value ? "true" : "false");
                break;

            case data_link_engine_interfaces::msg::ParameterValue::TYPE_STRING:
                RCLCPP_INFO(
                    get_logger(),
                    "String value = %s",
                    message.value.string_value.c_str());
                break;

            default:
                RCLCPP_WARN(
                    get_logger(),
                    "Topic '/data_link_engine/parameters/engine_speed' has unsupported type=%u",
                    message.value.type);
                break;
        }
    }

    rclcpp::Subscription<data_link_engine_interfaces::msg::Parameter>::SharedPtr m_subscription;
};
```

