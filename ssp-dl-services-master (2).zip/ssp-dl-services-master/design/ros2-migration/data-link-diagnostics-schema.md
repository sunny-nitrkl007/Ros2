# Data Link Diagnostics Schema <!-- omit in toc -->

- [Middleware-cpp Diagnostics Schema](#middleware-cpp-diagnostics-schema)
  - [Schema Overview](#schema-overview)
  - [Diagnostics Interfaces](#diagnostics-interfaces)
  - [Embedded into DDS IDL](#embedded-into-dds-idl)
  - [Pros of Current Protobuf + Fast DDS Approach](#pros-of-current-protobuf--fast-dds-approach)
  - [Cons of Current Protobuf + Fast DDS Approach](#cons-of-current-protobuf--fast-dds-approach)
- [Path forward](#path-forward)
  - [Topic and Service Model](#topic-and-service-model)
  - [Message and Service Definitions](#message-and-service-definitions)
  - [Additional Information Flow](#additional-information-flow)
  - [C++ Usage Examples](#c-usage-examples)
    - [Diagnostics Publisher Example](#diagnostics-publisher-example)
    - [Additional Information Service Example](#additional-information-service-example)
    - [Additional Information Client Example](#additional-information-client-example)

As we move from Middleware-cpp to ROS 2, diagnostics need two related interfaces:

1. A current list of diagnostics.
2. A request/reply interface for additional information about a specific diagnostic code.

The diagnostics list naturally maps to a ROS 2 topic. Additional information is requested on demand for a `code_key`, can take time to complete on the physical data link, and should map to a ROS 2 service.

## Middleware-cpp Diagnostics Schema

### Schema Overview

The current diagnostics list is defined by `middleware_diagnostics.proto`:

```protobuf
syntax = "proto3";
package cat.middleware.diagnostics;

message NetworkAddress
{
  message J1939Address
  {
    enum CanPort
    {
      CAN_PORT_UNSPECIFIED = 0;
      CAN_PORT_1 = 1;
      CAN_PORT_2 = 2;
      CAN_PORT_3 = 3;
      CAN_PORT_4 = 4;
      CAN_PORT_5 = 5;
      CAN_PORT_6 = 6;
    }

    uint32  address  = 1;
    CanPort can_port = 2;
  }

  message Self
  {
    J1939Address j1939 = 1;
  }

  oneof network_address
  {
    Self          self          = 1;
    J1939Address j1939_address = 2;
  }
}

message LampStatuses
{
  enum LampStatus
  {
    LAMP_STATUS_OFF           = 0;
    LAMP_STATUS_ON            = 1;
    LAMP_STATUS_RESERVED      = 2;
    LAMP_STATUS_NOT_AVAILABLE = 3;
  }
  enum MilLampStatus
  {
    MIL_LAMP_STATUS_OFF           = 0;
    MIL_LAMP_STATUS_ON            = 1;
    MIL_LAMP_STATUS_SHORT_MIL     = 2;
    MIL_LAMP_STATUS_NOT_AVAILABLE = 3;
  }
  enum LampFlashStatus
  {
    LAMP_FLASH_STATUS_SLOW         = 0;
    LAMP_FLASH_STATUS_FAST         = 1;
    LAMP_FLASH_STATUS_RESERVED     = 2;
    LAMP_FLASH_STATUS_DO_NOT_FLASH = 3;
  }
  enum MilLampFlashStatus
  {
    MIL_LAMP_FLASH_STATUS_SLOW         = 0;
    MIL_LAMP_FLASH_STATUS_FAST         = 1;
    MIL_LAMP_FLASH_STATUS_CLASS_C_DTC  = 2;
    MIL_LAMP_FLASH_STATUS_DO_NOT_FLASH = 3;
  }

  LampStatus         protect_lamp           = 1;
  LampStatus         amber_lamp             = 2;
  LampStatus         red_lamp               = 3;
  MilLampStatus      malfunction_lamp       = 4;
  LampFlashStatus    protect_lamp_flash     = 5;
  LampFlashStatus    amber_lamp_flash       = 6;
  LampFlashStatus    red_lamp_flash         = 7;
  MilLampFlashStatus malfunction_lamp_flash = 8;
}

enum CodeStatus
{
  CODE_STATUS_NONE              = 0;
  CODE_STATUS_ACTIVE_ONLY       = 1;
  CODE_STATUS_ACTIVE_AND_LOGGED = 2;
  CODE_STATUS_LOGGED_ONLY       = 3;
  CODE_STATUS_PREVIOUSLY_ACTIVE = 4;
}

message Information
{
  message DiagnosticInformation
  {
    uint32     component_identifier       = 1;
    uint32     warning_category_indicator = 2;
    uint32     failure_mode_identifier    = 3;
    uint32     annunciation_requirement   = 4;
    CodeStatus status                     = 5;
  }

  message EventInformation
  {
    uint32     event_identifier           = 1;
    uint32     warning_category_indicator = 2;
    uint32     annunciation_requirement   = 3;
    CodeStatus status                     = 4;
  }

  message PublicInformation
  {
    uint32       suspect_parameter_number   = 1;
    uint32       warning_category_indicator = 2;
    uint32       failure_mode_identifier    = 3;
    uint32       annunciation_requirement   = 4;
    uint32       occurrence_count           = 5;
    LampStatuses lamp_statuses              = 6;
    CodeStatus   status                     = 7;
  }

  oneof information
  {
    DiagnosticInformation diagnostic = 1;
    EventInformation      event      = 2;
    PublicInformation     public_dtc = 3;
  }
}

message Code
{
  UpdateReason   update_reason   = 1 [deprecated = true];
  NetworkAddress network_address = 2;
  Information    information     = 3;
  uint64         code_key        = 4;
}

message Codes
{
  repeated Code codes = 1;
}
```

Additional information is defined by `middleware_diagnostics_additionalinformation.proto`:

```protobuf
syntax = "proto3";
package cat.middleware.diagnostics;

message Group2
{
  uint32 occurrence_count       = 1;
  uint32 security_level         = 2;
  uint32 shm_of_first_occurence = 3;
  uint32 shm_of_last_occurence  = 4;
}

message AdditionalInformation
{
  uint64 code_key = 1;
  oneof group
  {
    Group2 group_2 = 2;
  }
}
```

The `code_key` is the stable correlation value between the diagnostics list and additional-information requests.

### Diagnostics Interfaces

Middleware-cpp exposes diagnostics through a code client and a code server:

```cpp
enum AdditionalInformationGroup
{
    Group2,
};

struct CodeConsumer
{
    std::function<void(cat::middleware::diagnostics::Codes const& codes)> callback;
    std::function<void()> disconnect;
};

class ICodeClient
{
public:
    virtual void RequestAdditionalInformation(
        uint64_t codeKey,
        std::vector<AdditionalInformationGroup> const& groups,
        std::function<void(cat::middleware::diagnostics::AdditionalInformation& additionalInformation)>&& callback) = 0;
};

class ICodeServer
{
public:
    virtual void Reply(uint_least16_t key, cat::middleware::diagnostics::AdditionalInformation data) = 0;
    virtual void Publish(cat::middleware::diagnostics::Codes const& codes) = 0;
};

class IService
{
public:
    virtual std::unique_ptr<ICodeClient> CreateCodeClient(CodeConsumer&& client) = 0;
    virtual std::unique_ptr<ICodeServer> CreateCodeServer(
        cat::middleware::diagnostics::Codes const& current,
        std::function<std::optional<cat::middleware::diagnostics::AdditionalInformation>(
            uint_least16_t key,
            cat::middleware::diagnostics::AdditionalInformation& request)>&& requestAdditionalInformation) = 0;
};
```

Data Link Engine currently acts as the code server. Jaws subscribes to the `Codes` SharkByte, parses the protobuf bytes, and calls `ICodeServer::Publish(codes)`. When middleware requests additional information, Jaws writes the requested `code_key` bytes to the `AdditionalInformationRequest` SharkByte and replies when the `AdditionalInformationResponse` SharkByte updates.

Additional-information requests for the same `code_key` are coalesced while a data-link request is active. If the response does not arrive within five seconds, Jaws allows a later request to re-send the data-link request. A response that contains only `code_key` means the request completed without group data, such as when the peer does not support Group 2 or a timeout occurred below Jaws.

### Embedded into DDS IDL

Like the parameter interfaces, diagnostics use protobuf as the actual schema while DDS provides transport and request correlation. The diagnostics list and additional-information response are opaque protobuf bytes to DDS tooling.

```idl
// message.idl -- conceptual DDS payload shape
struct Message {
    string additional_information;
    sequence<octet> protobuf;
};
```

### Pros of Current Protobuf + Fast DDS Approach

| Pro | Explanation |
|-----|-------------|
| **Rich existing schema** | The current protobuf captures EDDT diagnostics, EDDT events, public DTCs, lamp statuses, network addresses, and additional-information group data. |
| **`oneof` for variants** | `NetworkAddress`, `Information`, and `AdditionalInformation` use protobuf `oneof` fields for mutually exclusive payloads. |
| **Schema evolution** | Proto3 can add new groups or fields while preserving wire compatibility for older clients. |
| **Asynchronous additional-information completion** | The server callback can return `std::nullopt` and later reply by request key, matching data-link request timing. |
| **Coalesced duplicate requests** | Jaws can satisfy multiple middleware request keys from one data-link additional-information response for the same `code_key`. |

### Cons of Current Protobuf + Fast DDS Approach

| Con | Explanation |
|-----|-------------|
| **Opaque to DDS and ROS tooling** | Diagnostic codes and additional information are protobuf bytes, so generic DDS/ROS tools cannot inspect fields without protobuf-specific decoding. |
| **Two schemas describe one API** | Protobuf describes the code data, but publish/subscribe, request/reply, request keys, and group selection are described by C++ interfaces. |
| **Double serialization overhead** | Diagnostics are serialized by protobuf and then carried through the DDS transport payload. |
| **Limited additional-information status** | A response with only `code_key` can mean unsupported group, timeout, or a lower-layer request failure. Clients do not get a structured reason. |
| **Typo is part of the schema** | `shm_of_first_occurence` and `shm_of_last_occurence` are misspelled in the protobuf field names and generated API. |

## Path forward

With ROS 2, the diagnostics list should be a typed topic and additional information should be a typed service. This removes protobuf from the public ROS 2 interface, makes the list visible to ROS 2 tooling, and expresses the request/reply contract in `.srv` files.

The main tradeoffs are the same ones described for [parameter topics](./data-link-parameters-msg-schema.md):

| Con | Explanation |
|-----|-------------|
| **No union type** | Use discriminator fields with parallel value fields for diagnostic, event, and public DTC variants. |
| **No enumerations** | Use `uint8` constants for code type, status, can port, lamp states, and service result values. |
| **No optional fields** | Use explicit `has_*` fields for values such as additional-information Group 2. |
| **No backwards compatibility** | All ROS 2 clients and servers must be built against the same `.msg` and `.srv` schemas. |

### Topic and Service Model

The current diagnostics list should be published as a complete current list, not as per-code deltas. The protobuf `update_reason` field is already deprecated, and the current Jaws path publishes the `Codes` value from the `Codes` SharkByte.

| Middleware-cpp concept | ROS 2 interface |
|------------------------|-----------------|
| `ICodeServer::Publish(Codes)` | Topic `/data_link_engine/diagnostics/codes` |
| `ICodeClient::RequestAdditionalInformation(codeKey, groups, callback)` | Service `/data_link_engine/diagnostics/additional_information` |

The `code_key` remains the correlation value. A client subscribes to the codes topic, chooses a code, and sends that code's `code_key` to the additional-information service.

### Message and Service Definitions

The schemas below intentionally flatten the current protobuf `oneof` messages. Fields that only apply to one code type are meaningful only when `code_type` matches.

**`data_link_engine_interfaces/msg/DiagnosticNetworkAddress.msg`**
```
uint8 CAN_PORT_UNSPECIFIED = 0
uint8 CAN_PORT_1           = 1
uint8 CAN_PORT_2           = 2
uint8 CAN_PORT_3           = 3
uint8 CAN_PORT_4           = 4
uint8 CAN_PORT_5           = 5
uint8 CAN_PORT_6           = 6

uint8 can_port
uint8 address
bool is_self
```

This will need to be updated to support other data links if necessary.

**`data_link_engine_interfaces/msg/DiagnosticLampStatuses.msg`**
```
uint8 LAMP_STATUS_OFF           = 0
uint8 LAMP_STATUS_ON            = 1
uint8 LAMP_STATUS_RESERVED      = 2  # Could be short mil
uint8 LAMP_STATUS_NOT_AVAILABLE = 3

uint8 LAMP_FLASH_STATUS_SLOW         = 0
uint8 LAMP_FLASH_STATUS_FAST         = 1
uint8 LAMP_FLASH_STATUS_RESERVED     = 2  # Could be class c dtc
uint8 LAMP_FLASH_STATUS_DO_NOT_FLASH = 3

uint8 protect
uint8 amber
uint8 red
uint8 malfunction

uint8 protect_flash
uint8 amber_flash
uint8 red_flash
uint8 malfunction_flash
```

**`data_link_engine_interfaces/msg/DiagnosticCode.msg`**
```
uint8 CODE_TYPE_UNSPECIFIED      = 0
uint8 CODE_TYPE_EDDT_DIAGNOSTIC  = 1
uint8 CODE_TYPE_EDDT_EVENT       = 2
uint8 CODE_TYPE_PUBLIC_DTC       = 3

uint8 CODE_STATUS_NONE              = 0
uint8 CODE_STATUS_ACTIVE_ONLY       = 1
uint8 CODE_STATUS_ACTIVE_AND_LOGGED = 2
uint8 CODE_STATUS_LOGGED_ONLY       = 3
uint8 CODE_STATUS_PREVIOUSLY_ACTIVE = 4

uint64 code_key
DiagnosticNetworkAddress network_address
uint8 code_type
uint8 status
uint32 identifier  # component / event / suspect parameter number
uint32 warning_category_indicator
uint32 annunciation_requirement

# EDDT diagnostic fields
uint32 failure_mode_identifier

# Public DTC fields
uint32 occurrence_count
DiagnosticLampStatuses lamp_statuses
```

**`data_link_engine_interfaces/msg/DiagnosticCodeList.msg`**
```
std_msgs/Header header
DiagnosticCode[] codes
```

**`data_link_engine_interfaces/msg/DiagnosticAdditionalInformationGroup2.msg`**
```
uint8 status

uint32 occurrence_count
uint32 security_level
uint32 shm_of_first_occurrence
uint32 shm_of_last_occurrence
```

**`data_link_engine_interfaces/msg/DiagnosticAdditionalInformation.msg`**
```
uint8 GROUP_2 = 2

# Status is specified in each group message
uint8 STATUS_UNSPECIFIED            = 0
uint8 STATUS_SUCCESS                = 1
uint8 STATUS_FAILURE_TIMEOUT        = 2
uint8 STATUS_FAILURE_NOT_SUPPORTED  = 3
uint8 STATUS_FAILURE_REASON_UNKNOWN = 4

uint64 code_key

# The caller must only examine the messages for groups it requested
DiagnosticAdditionalInformationGroup2 group_2
```

**`data_link_engine_interfaces/srv/GetDiagnosticAdditionalInformation.srv`**
```
# DiagnosticCode.code_key from /data_link_engine/diagnostics/codes
uint64 code_key

uint8[] requested_groups
---
DiagnosticAdditionalInformation additional_information
```

The status constants live in `DiagnosticAdditionalInformation` even though each group carries its own `status` field. That is a reasonable shape as long as every additional-information group uses the same status vocabulary. It keeps the constants defined once, avoids duplicating identical constants in every group message, and lets future groups add only their data fields plus `uint8 status`.

### Additional Information Flow

Additional information should map closely to the current Jaws behavior:

1. A client subscribes to `/data_link_engine/diagnostics/codes`.
2. The client selects a `DiagnosticCode` and calls `/data_link_engine/diagnostics/additional_information` with that code's `code_key` and requested groups.
3. The server validates the request and starts the Shark additional-information request.
4. The server keeps the ROS 2 service request open until the response arrives or times out.
5. The response always includes `additional_information.code_key` set to the requested key.
6. If Group 2 data is returned, the response `additional_information.group_2.status = STATUS_SUCCESS`.
7. If Group 2 data is not returned, the response sets `additional_information.group_2.status` to `STATUS_FAILURE_TIMEOUT`, `STATUS_FAILURE_NOT_SUPPORTED`, or `STATUS_FAILURE_REASON_UNKNOWN` when the server can tell.

Unlike Middleware-cpp, ROS 2 service servers do not need an explicit middleware request key. The `rclcpp` service response object is the correlation point. The server can still coalesce duplicate requests for the same `code_key` internally and send a response to each waiting ROS 2 request when the Shark response arrives.

### C++ Usage Examples

The following snippets show the intended shape of the diagnostics topic and additional-information service. They are illustrative rather than final production code.

#### Diagnostics Publisher Example

```cpp
#include <memory>
#include <rclcpp/rclcpp.hpp>

#include <data_link_engine_interfaces/msg/diagnostic_code_list.hpp>

class DiagnosticsPublisher : public rclcpp::Node
{
public:
    DiagnosticsPublisher()
        : Node("diagnostics_publisher")
    {
        m_publisher = create_publisher<data_link_engine_interfaces::msg::DiagnosticCodeList>(
            "/data_link_engine/diagnostics/codes",
            10);
    }

private:
    void PublishCodes(data_link_engine_interfaces::msg::DiagnosticCodeList message)
    {
        message.header.stamp = get_clock()->now();
        m_publisher->publish(message);
    }

    rclcpp::Publisher<data_link_engine_interfaces::msg::DiagnosticCodeList>::SharedPtr m_publisher;
};
```

#### Additional Information Service Example

```cpp
#include <functional>
#include <memory>
#include <vector>
#include <rmw/types.h>
#include <rclcpp/rclcpp.hpp>

#include <data_link_engine_interfaces/msg/diagnostic_additional_information.hpp>
#include <data_link_engine_interfaces/srv/get_diagnostic_additional_information.hpp>

class DiagnosticAdditionalInformationService : public rclcpp::Node
{
public:
    DiagnosticAdditionalInformationService()
        : Node("diagnostic_additional_information_service")
    {
        using GetAdditionalInformation = data_link_engine_interfaces::srv::GetDiagnosticAdditionalInformation;

        m_service = create_service<GetAdditionalInformation>(
            "/data_link_engine/diagnostics/additional_information",
            [this](
                std::shared_ptr<rmw_request_id_t> spRequestHeader,
                GetAdditionalInformation::Request::SharedPtr spRequest)
            {
                HandleRequest(std::move(spRequestHeader), *spRequest);
            });
    }

private:
    using GetAdditionalInformation = data_link_engine_interfaces::srv::GetDiagnosticAdditionalInformation;
    using Response = GetAdditionalInformation::Response;
    using ResponsePtr = GetAdditionalInformation::Response::SharedPtr;

    void HandleRequest(std::shared_ptr<rmw_request_id_t> spRequestHeader, GetAdditionalInformation::Request const& request)
    {
          using data_link_engine_interfaces::msg::DiagnosticAdditionalInformation;

          if (!ContainsGroup2(request.requested_groups))
        {
            auto spResponse = std::make_shared<Response>();
            spResponse->additional_information.code_key = request.code_key;
            spResponse->additional_information.group_2.status = DiagnosticAdditionalInformation::STATUS_FAILURE_NOT_SUPPORTED;
            SendResponse(spRequestHeader, spResponse);
            return;
        }

        StartAdditionalInformationRequest(
            request.code_key,
            [this, spRequestHeader = std::move(spRequestHeader)](auto const& additionalInformation)
            {
                auto spResponse = std::make_shared<Response>();
                spResponse->additional_information = additionalInformation;
                SendResponse(spRequestHeader, spResponse);
            });
    }

    void SendResponse(std::shared_ptr<rmw_request_id_t> const& spRequestHeader, ResponsePtr const& spResponse)
    {
        m_service->send_response(*spRequestHeader, spResponse);
    }

    static bool ContainsGroup2(std::vector<uint8_t> const& groups);
    static void StartAdditionalInformationRequest(
        uint64_t codeKey,
        std::function<void(
          data_link_engine_interfaces::msg::DiagnosticAdditionalInformation const& additionalInformation)>&& onCompletion);

    rclcpp::Service<GetAdditionalInformation>::SharedPtr m_service;
};
```

#### Additional Information Client Example

```cpp
#include <memory>
#include <vector>
#include <rclcpp/rclcpp.hpp>

#include <data_link_engine_interfaces/msg/diagnostic_additional_information.hpp>
#include <data_link_engine_interfaces/srv/get_diagnostic_additional_information.hpp>

class DiagnosticAdditionalInformationClient : public rclcpp::Node
{
public:
    DiagnosticAdditionalInformationClient()
        : Node("diagnostic_additional_information_client")
    {
        m_client = create_client<data_link_engine_interfaces::srv::GetDiagnosticAdditionalInformation>(
            "/data_link_engine/diagnostics/additional_information");
    }

    void RequestGroup2(uint64_t codeKey)
    {
        using data_link_engine_interfaces::msg::DiagnosticAdditionalInformation;
        using data_link_engine_interfaces::srv::GetDiagnosticAdditionalInformation;

        auto spRequest = std::make_shared<GetDiagnosticAdditionalInformation::Request>();
        spRequest->code_key = codeKey;
        spRequest->requested_groups.push_back(DiagnosticAdditionalInformation::GROUP_2);

        m_client->async_send_request(
            spRequest,
            [this, spRequest](rclcpp::Client<GetDiagnosticAdditionalInformation>::SharedFuture future)
            {
                auto const& response = *future.get();
                if (response.additional_information.group_2.status != DiagnosticAdditionalInformation::STATUS_SUCCESS)
                {
                    RCLCPP_WARN(
                        get_logger(),
                        "Group 2 additional information failed: status=%u",
                        response.additional_information.group_2.status);
                    return;
                }

                if (!ContainsGroup2(spRequest->requested_groups))
                {
                    RCLCPP_INFO(get_logger(), "No Group 2 data returned for code_key=%lu", response.additional_information.code_key);
                    return;
                }

                RCLCPP_INFO(
                    get_logger(),
                    "Group 2 occurrence_count=%u security_level=%u",
                    response.additional_information.group_2.occurrence_count,
                    response.additional_information.group_2.security_level);
            });
    }

private:
    static bool ContainsGroup2(std::vector<uint8_t> const& groups);

    rclcpp::Client<data_link_engine_interfaces::srv::GetDiagnosticAdditionalInformation>::SharedPtr m_client;
};
```