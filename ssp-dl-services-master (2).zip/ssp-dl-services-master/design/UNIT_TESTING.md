# Unit Testing

## Continuous Documentation Policy

Whenever there is back and forth about unit testing (new learnings, patterns, decisions, or best practices), update this UNIT_TESTING.md file to capture them. This ensures all agents and contributors have access to the latest guidance.

---

## Framework & Tools

- **Framework**: Google Test (gtest) 1.15+
- **Mocking**: Google Mock (gmock)
- **Headers** (precompiled): `<Utilities/DataEngineMock.h>`, `<Utilities/TestUtilities.h>`, `<gmock/gmock.h>`
- **Test locations**: `*/Tests/` (unit), `*/FunctionalTests/` (integration)

---

## Test Naming & Requirement Clarity

**Core Rule**: Test names must clearly reflect the requirement being tested, not the implementation.

**Bad**: `Test1`, `TestFunction`, `ValidateOutput`
**Good**: `CreatesSharkByteWithCorrectId`, `PublishesValueChangeToMiddleware`, `RejectsInvalidConfiguration`

Pattern: `<ComponentUnderTest><Action><ExpectedResult>`

Example:
```cpp
TEST_F(SharkByteSubscriberTest, PublishesNewValueWhenSharkByteChanges)
TEST_F(PgnPublisherTest, FormatsMessageWithCorrectDlcForFrameType)
TEST_F(ConfigValidatorTest, RejectsConfigMissingRequiredField)
```

---

## Test Fixtures (Required for DRY Code)

All test suites must use Google Test fixtures (`::testing::Test`) to eliminate duplication and provide reusable setup/teardown.

**Pattern**:
```cpp
class MyComponentTest : public ::testing::Test
{
protected:
    // Constructor: called before each test
    MyComponentTest() : m_sut(std::make_unique<MyComponent>())
    {
        // Additional setup as needed
    }
    ~MyComponentTest()
    {
        // Additional tear down as needed
    }

    // Helper methods for common operations
    void ExpectValuePublished(const std::string& byteId, int expectedValue)
    {
        EXPECT_THAT(m_mockPublisher->GetLastPublished(byteId), Eq(expectedValue));
    }

    MyComponent m_myComponent;  // System Under Test
};
TEST_F(MyComponentTest, RequirementName)
{
    // Arrange
    // Act
    // Assert
}
```

**Benefits**:
- Reduces test code duplication
- Clear setup/teardown lifecycle
- Shared helper methods and assertions
- Better readability

---

## Assertions: EXPECT_THAT with Matchers

**Rule**: Use `EXPECT_THAT` with GMock matchers instead of `EXPECT_EQ`, `EXPECT_DOUBLE_EQ`, etc.

**Why**: Better error messages, composable matchers, consistent style across the codebase.

**Examples**:
```cpp
// Basic matchers
EXPECT_THAT(value, Eq(expected));
EXPECT_THAT(value, DoubleEq(3.14));
EXPECT_THAT(str, StrEq("hello"));

// Container matchers
EXPECT_THAT(vec, ElementsAre(1, 2, 3));
EXPECT_THAT(vec, Contains(42));
EXPECT_THAT(map, Contains(Pair("key", 99)));

// Pointer matchers
EXPECT_THAT(ptr, NotNull());
EXPECT_THAT(ptr, Pointee(Eq(expected)));

// Custom matchers
EXPECT_THAT(actualMsg, Utilities::ProtobufEquals(expectedMsg));
```

**Common Protobuf Pattern**:
```cpp
cat::shark::Config expectedConfig = CreateTestConfig();
cat::shark::Config actualConfig = loader.LoadConfig();
EXPECT_THAT(actualConfig, Utilities::ProtobufEquals(expectedConfig));
```

---

## Mock Injection Pattern

**Rule**: Use `Utilities::DefaultTestUniquePtr<NiceMock<MockXxx>>` to create mocks and transfer ownership while retaining a reference for assertions.

**Pattern**:
```cpp
// In test fixture
Utilities::DefaultTestUniquePtr<NiceMock<MockSharkByteSubscriber>> mock;

// In test
auto spMock = mock.Get();              // Non-owning reference for assertions
auto upMock = mock.TakeUniquePtr();    // Transfer ownership to SUT

// Now pass upMock to the component under test
MyComponent sut(std::move(upMock), /*...*/);

// Later, make assertions on spMock
EXPECT_THAT(spMock->GetCallCount(), Eq(1));
EXPECT_THAT(spMock->GetLastValueReceived(), Eq(42));
```

**Mock Declaration Rule**: Every mock must include `EnsureMockKindIsSpecified(ClassName)` macro.

```cpp
class MockSharkByteSubscriber : public ISharkByteSubscriber {
public:
    EnsureMockKindIsSpecified(MockSharkByteSubscriber);

    MOCK_METHOD(void, OnValueChanged, (const SharkByteValue&), (override));
    // ... other mocks
};
```

---

## Accessing Static & Anonymous-Namespace Functions

**Rule**: Include the `.cpp` file directly to access static methods and functions in the unnamed namespace.

**Pattern**:
```cpp
// In your test file
#include "Middleware/PgnParameterDataPublisher.cpp"  // Gives access to static/unnamed functions

TEST_F(MyTest, StaticConverterHandlesEdgeCase)
{
    // Now you can call static functions that are not in the public header
    auto result = ConvertPgnToMiddleware(/*...*/);
    EXPECT_THAT(result, /*...*/);
}
```

**When to Use**:
- Testing static helper functions
- Testing helper functions in unnamed namespace
- Testing private static data

**Note**: Only include `.cpp` files that are directly needed. Do not create excessive transitive includes.

---

## Test Organization

### Unit Tests vs Functional Tests

| Aspect | Unit Tests | Functional Tests |
|--------|-----------|-----------------|
| **Location** | `*/Tests/` | `*/FunctionalTests/` |
| **Scope** | Single component in isolation | Component integration |
| **Mocks** | Heavy; mock all dependencies | Minimal; use real collaborators where safe |
| **Speed** | Fast (milliseconds) | Slower (seconds) |
| **Build Time** | Included in main build | May be optional |

**Unit test focus**: Single responsibility, contracts, edge cases
**Functional test focus**: End-to-end workflows, realistic data, integration points

### Mock Locations

- **Shark-level mocks**: `shark/SharkMocks/` (public interfaces) and `shark/Interface/Shark/Mocks/` (per-component)
- **Kraken mocks**: Alongside interfaces in `shark/Interface/Shark/Kraken/`
- **Jaws mocks**: `applications/Jaws/Tests/` (component-specific)

---

## Common Patterns

### Protobuf Message Comparison
```cpp
EXPECT_THAT(actualMsg, Utilities::ProtobufEquals(expectedMsg));
```

### Build-Specific Tests
```cpp
DEBUG_ONLY_TEST_F(MyTest, DebugOnlyBehavior) {
    // Only runs in Debug configuration
}

RELEASE_ONLY_TEST_F(MyTest, ReleaseBehavior) {
    // Only runs in RelWithDebInfo / Release
}
```

### Verifying Constants
If using constants from production code in tests, verify them with `static_assert` in dedicated test functions:
```cpp
TEST(Constants, SharkyteIdMaxLengthIsCorrect) {
    // If the constant changes, the test must change explicitly
    static_assert(SharkByteId::MAX_LENGTH == 256);
}
```

### Testing Private/Static Members
Use the `.cpp` include pattern above to access private static data or helper functions.

### Matcher Composition
```cpp
EXPECT_THAT(config, AllOf(
    Property(&Config::GetVersion, Eq("1.0")),
    Property(&Config::GetName, StrEq("TestConfig")),
    Property(&Config::IsValid, true)
));
```

---

## Common Pitfalls & How to Avoid Them

### 1. **Testing Implementation, Not Requirements**
**Problem**: Test name is `TestFunction` or `VerifyOutput`. Test is brittle to refactoring.
**Solution**: Name tests after the requirement: `ComputesChecksum`, `IgnoresInvalidInput`.

### 2. **Testing `Create()` Factory Methods**
**Problem**: Trying to unit test `static Create()` methods.
**Solution**: Don't. The factory registers with middleware config and does initialization. Test the component itself after it's created.

### 3. **Not Using Test Fixtures**
**Problem**: Duplicated setup code, hard to modify common setup.
**Solution**: Use `::testing::Test` fixtures with protected members and helper methods.

### 4. **Mixing Unit & Integration in Same Test**
**Problem**: Test calls real components + mocks + external services. Hard to debug failures.
**Solution**: Separate concerns. Unit tests mock everything. Functional tests use real collaborators.

### 5. **Forgetting `EnsureMockKindIsSpecified()`**
**Problem**: Mock doesn't compile or behaves unexpectedly.
**Solution**: Every mock class must include this macro from `Utilities/DataEngineMock.h`.

### 6. **Using `EXPECT_EQ` Instead of Matchers**
**Problem**: Error messages are unclear. Hard to debug complex assertions.
**Solution**: Always use `EXPECT_THAT(value, Matcher())` for clarity.

### 7. **Overly Complex Test Fixtures**
**Problem**: Fixture does too much. Tests are hard to understand.
**Solution**: Keep fixtures focused. Use helper methods for complex operations. Each test should clearly show what it's arranging.

---

## Test Execution

**Build & run unit tests**:
```bash
cd build/tgt_gcc_x86_64_ubuntu_workstation/Debug
ninja Shark_Tests
ninja Jaws_Tests
```

**Build & run functional tests**:
```bash
cd build/tgt_gcc_x86_64_ubuntu_workstation/Debug
ninja Shark_Functional_Tests
ninja Jaws_Functional_Tests
```

**High-level scripts** (auto-source Conan environment):
```bash
utilities/Build/RunUnitTests.sh -z tgt_gcc_ubuntu -t Debug
utilities/Build/RunFunctionalTests.sh -t Debug
```

---

## Continuous Improvement

This document should evolve as the team discovers new patterns and best practices. When you encounter:
- A confusing testing situation
- A pattern that worked well
- A common mistake

Update this document to capture the learning for the next developer or AI agent working on the codebase.
