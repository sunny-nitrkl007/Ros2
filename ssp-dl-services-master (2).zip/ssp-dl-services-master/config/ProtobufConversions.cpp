/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See ProtobufConversions.h

#include "Interface/Config/ProtobufConversions.h"
#include <cassert>

namespace Config
{
static_assert(static_cast<unsigned>(Config::CanPort::Can0) ==
	static_cast<unsigned>(cat::shark::J1939DataLink_CanPort_CanPort_MIN));
static_assert(static_cast<unsigned>(Config::CanPort::CanPortCount) ==
	static_cast<unsigned>(cat::shark::J1939DataLink_CanPort_CanPort_MAX),
	"If this fails, the protobuf CanPort range no longer matches Config::CanPort.");
static_assert(static_cast<unsigned>(Config::CanPort::Can0) ==
	static_cast<unsigned>(cat::middleware::diagnostics::NetworkAddress_J1939Address_CanPort_CanPort_MIN));
static_assert(static_cast<unsigned>(Config::CanPort::CanPortCount) ==
	static_cast<unsigned>(cat::middleware::diagnostics::NetworkAddress_J1939Address_CanPort_CanPort_MAX),
	"If this fails, the diagnostics protobuf CanPort range no longer matches Config::CanPort.");

Config::CanPort ToConfigCanPort(cat::shark::J1939DataLink::CanPort protobufCanPort)
{
	if (protobufCanPort <= cat::shark::J1939DataLink_CanPort_CanPort_MIN ||
		protobufCanPort > cat::shark::J1939DataLink_CanPort_CanPort_MAX)
	{
		throw std::runtime_error("Invalid protobuf CanPort enum value: " + std::to_string(protobufCanPort));
	}

	return static_cast<Config::CanPort>(protobufCanPort - 1);
}
Config::CanPort ToConfigCanPort(cat::middleware::diagnostics::NetworkAddress_J1939Address_CanPort protobufCanPort)
{
	if (protobufCanPort <= cat::middleware::diagnostics::NetworkAddress_J1939Address_CanPort_CanPort_MIN ||
		protobufCanPort > cat::middleware::diagnostics::NetworkAddress_J1939Address_CanPort_CanPort_MAX)
	{
		throw std::runtime_error("Invalid diagnostics protobuf CanPort enum value: " + std::to_string(protobufCanPort));
	}

	return static_cast<Config::CanPort>(protobufCanPort - 1);
}
cat::shark::J1939DataLink::CanPort ToProtobufCanPort(Config::CanPort configCanPort)
{
	if (configCanPort >= Config::CanPort::CanPortCount)
	{
		throw std::runtime_error("Invalid Config CanPort enum value: " + std::to_string(configCanPort));
	}

	return static_cast<cat::shark::J1939DataLink::CanPort>(configCanPort + 1);
}
cat::middleware::diagnostics::NetworkAddress_J1939Address_CanPort ToCodesProtobufCanPort(Config::CanPort configCanPort)
{
	if (configCanPort >= Config::CanPort::CanPortCount)
	{
		throw std::runtime_error("Invalid Config CanPort enum value: " + std::to_string(configCanPort));
	}

	return static_cast<cat::middleware::diagnostics::NetworkAddress_J1939Address_CanPort>(configCanPort + 1);
}
}
