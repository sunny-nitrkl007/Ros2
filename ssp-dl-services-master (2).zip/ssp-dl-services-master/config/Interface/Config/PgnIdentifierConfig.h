/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pgn Identifier Configuration

#pragma once

#include "Utilities/ArrayView.h"

namespace Config
{
struct OffsetSpnEntry
{
	unsigned spn;
	unsigned bitOffset;
};
using OffsetSpnEntries = Utilities::ArrayView<OffsetSpnEntry>;

struct PgnIdentifierEntry
{
	unsigned pgn;
	OffsetSpnEntries spns;
};
using PgnIdentifierEntries = Utilities::ArrayView<PgnIdentifierEntry>;

struct PgnIdentifierConfig
{
	PgnIdentifierEntries entries;
};
}
