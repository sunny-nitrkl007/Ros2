/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Type for Fid to help with outputting is value, validation, etc.

#pragma once

#include <boost/io/ios_state.hpp>
#include <cassert>
#include <ostream>

namespace Config
{
class Fid final
{
public:
	constexpr Fid() = default;
	constexpr Fid(unsigned fid)
		: m_fid{fid}
	{
	}
	operator unsigned() const
	{
		unsigned const applicationFunction = m_fid >> 16;
		unsigned const functionInstance = (m_fid >> 8) & 0xFF;
		unsigned const ecuInstance = m_fid & 0xFF;
		assert(applicationFunction != 0x0000 && applicationFunction != 0xFFFF); (void)applicationFunction;
		assert(functionInstance != 0xFF); (void)functionInstance;
		assert(ecuInstance != 0xFF); (void)ecuInstance;
		return m_fid;
	}
private:
	unsigned m_fid{0x10000};
};
inline std::ostream& operator<<(std::ostream& stream, Fid fid)
{
	boost::io::ios_flags_saver flagsRestorer{stream};
	return stream << "FID: 0x" << std::uppercase << std::hex << static_cast<unsigned>(fid);
}
}
