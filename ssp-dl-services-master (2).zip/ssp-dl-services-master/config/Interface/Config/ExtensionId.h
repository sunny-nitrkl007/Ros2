/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Type for Extension ID to help with outputting is value, validation, etc.

#pragma once

#include <boost/io/ios_state.hpp>
#include <cassert>
#include <ostream>

namespace Config
{
class ExtensionId
{
public:
	constexpr ExtensionId() = default;
	constexpr ExtensionId(unsigned extensionId)
		: m_extensionId{extensionId}
	{
	}
	operator unsigned() const noexcept
	{
		assert(IsValid());
		return m_extensionId;
	}
	constexpr bool IsValid() const
	{
		return m_extensionId <= 0xFFFF;
	}
private:
	unsigned m_extensionId{0};
};
inline std::ostream& operator<<(std::ostream& stream, ExtensionId extensionId)
{
	assert(extensionId.IsValid());
	boost::io::ios_flags_saver flagsRestorer{stream};
	return stream << "ExtId: 0x" << std::uppercase << std::hex << static_cast<unsigned>(extensionId);
}
}
