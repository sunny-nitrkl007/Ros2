/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Type for IP Address to help with outputting is value, validation, etc.

#pragma once

#include <cstdint>
#include <ostream>
#include <string>

namespace Config
{
class IpAddress final
{
public:
	constexpr IpAddress() = default;

	/// \throws std::runtime_error if the IP Address is not valid
	IpAddress(char const* pIpAddress);
	/// \throws std::runtime_error if the IP Address is not valid
	IpAddress(std::string const& ipAddress);

	/// The ipAddress must be in network byte order (big endian)
	constexpr IpAddress(uint32_t ipAddress) : m_address{ipAddress} {}

	/// \returns The IP Address in dotted-decimal format
	std::string AsString() const;

	/// \returns The IP Address in network byte order (big endian)
	constexpr uint32_t NetworkAddress() const { return m_address; }

	constexpr operator uint32_t() const { return NetworkAddress(); }
private:
	uint32_t m_address{};
};
std::ostream& operator<<(std::ostream& stream, IpAddress const& ipAddress);
bool operator==(IpAddress const& left, IpAddress const& right) noexcept;
bool operator!=(IpAddress const& left, IpAddress const& right) noexcept;
}
