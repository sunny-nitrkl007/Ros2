/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Configuration

#pragma once

#include "CanPort.h"
#include "Utilities/ArrayView.h"
#include <optional>

namespace Config
{
struct IdentityEntry
{
	Utilities::ArrayView<unsigned> validAddresses;
	unsigned ecuInstance;
	unsigned functionInstance;
	unsigned industryGroup;
	unsigned vehicleSystem;
	unsigned vehicleSystemInstance;
	unsigned function;
	unsigned manufacturerCode;
};
struct DeviceIdEntry
{
	unsigned moduleId;
	unsigned serviceToolSupportLevel;
	unsigned applicationId;
	unsigned minimumServiceToolSupportLevel;
	std::optional<unsigned> fid;
};

struct AdtPidEntry
{
	unsigned pid;
	char const* pMiddlewareId;
};
using AdtPidEntries = Utilities::ArrayView<AdtPidEntry>;
struct AdtEntry
{
	std::optional<unsigned> timeout;
	AdtPidEntries adtPidEntries;
};

struct PgbPidEntry
{
	unsigned pid;
	unsigned requestRate;
	bool isHighPriority;
	char const* pMiddlewareId;
};
using PgbPidEntries = Utilities::ArrayView<PgbPidEntry>;
struct PgbEntry
{
	PgbPidEntries pgbPidEntries;
};

struct InternalSpnEntry
{
	unsigned spn;
	char const* pMiddlewareId;
};
using InternalSpnEntries = Utilities::ArrayView<InternalSpnEntry>;
struct ReceiveBroadcastPgnEntry
{
	unsigned pgn;
	unsigned timeout;
	InternalSpnEntries internalSpnEntries;
	char const* pMiddlewareId;
};
using ReceiveBroadcastPgnEntries = Utilities::ArrayView<ReceiveBroadcastPgnEntry>;
struct ReceiveOnRequestPgnEntry
{
	unsigned pgn;
	InternalSpnEntries internalSpnEntries;
	char const* pMiddlewareId;
};
using ReceiveOnRequestPgnEntries = Utilities::ArrayView<ReceiveOnRequestPgnEntry>;
struct PgnEntry
{
	ReceiveBroadcastPgnEntries receiveBroadcastPgnEntries;
	ReceiveOnRequestPgnEntries receiveOnRequestPgnEntries;
};
struct BasicReadWritePidEntry
{
	unsigned pid;
	char const* pMiddlewareId;
};
using BasicReadWritePidEntries = Utilities::ArrayView<BasicReadWritePidEntry>;
struct BasicReadWriteEntry
{
	BasicReadWritePidEntries basicReadWritePidEntries;
};

enum class BdtAccessMode
{
	BdtAccessModeUnused,
	ReadOnly,
	WriteOnly,
	ReadWrite
};
struct BdtTypeEntry
{
	unsigned type;
	unsigned index;
	BdtAccessMode accessMode;
	char const* pMiddlewareId;
};
using BdtTypeEntries = Utilities::ArrayView<BdtTypeEntry>;
struct BdtEntry
{
	BdtTypeEntries bdtTypeEntries;
};

struct CalibrationServiceDataEntry
{
	unsigned index;
	char const* pMiddlewareId;
};
using CalibrationServiceDataEntries = Utilities::ArrayView<CalibrationServiceDataEntry>;
struct CalibrationServicesEntry
{
	CalibrationServiceDataEntries calibrations;
	CalibrationServiceDataEntries serviceTests;
};

struct ExtensionIdReadEntry
{
	unsigned extensionId;
	char const* pMiddlewareId;
};
using ExtensionIdReadEntries = Utilities::ArrayView<ExtensionIdReadEntry>;
struct ExtensionIdEntry
{
	ExtensionIdReadEntries extensionIdReads;
};

struct PeerNodeEntry
{
	unsigned address;
	AdtEntry adtEntry;
	PgbEntry pgbEntry;
	PgnEntry pgnEntry;
	BasicReadWriteEntry basicReadWriteEntry;
	BdtEntry bdtEntry;
	CalibrationServicesEntry calibrationServicesEntry;
	ExtensionIdEntry extensionIdEntry;
};
using PeerNodeEntries = Utilities::ArrayView<PeerNodeEntry>;

struct TransmitBroadcastPgnEntry
{
	unsigned pgn;
	unsigned broadcastRate;
	InternalSpnEntries internalSpnEntries;
	char const* pMiddlewareId;
};
using TransmitBroadcastPgnEntries = Utilities::ArrayView<TransmitBroadcastPgnEntry>;

struct J1939LinkEntry
{
	CanPort canPort;
	IdentityEntry identityEntry;
	PeerNodeEntries peerNodeEntries;
	TransmitBroadcastPgnEntries transmitBroadcastPgnEntries;
};
using J1939LinkEntries = Utilities::ArrayView<J1939LinkEntry>;

struct MachineSecuritySystemEntry
{
	CanPort canPort;
	unsigned address;
};

enum DiagnosticType
{
	DiagnosticTypeUnused,
	Eddt,
	Public
};
struct DiagnosticPeerEntry
{
	unsigned address;
	DiagnosticType diagnosticType;
};
using DiagnosticPeerEntries = Utilities::ArrayView<DiagnosticPeerEntry>;
struct DiagnosticClientCanPort
{
	CanPort canPort;
	DiagnosticPeerEntries diagnosticPeerEntries;
};
using DiagnosticClientCanPorts = Utilities::ArrayView<DiagnosticClientCanPort>;

enum CodeType
{
	CodeTypeUnused,
	Diagnostic,
	Event
};
enum StorageType
{
	StorageTypeUnused,
	ActiveOnly,
	LoggedAndActive
};
struct InternalCodeEntry
{
	CodeType codeType;
	StorageType storageType;
	unsigned code;
	unsigned failureModeIdentifier;
	unsigned warningCategoryIndicator;
	unsigned annunciationRequirement;
	char const* pDescription;
	unsigned securityLevel;
	unsigned startUpDelay;
	unsigned activationDelay;
	unsigned deactivationDelay;
	char const* pMiddlewareId;
};
using InternalCodeEntries = Utilities::ArrayView<InternalCodeEntry>;
struct InternalCodeList
{
	CanPort canPort;
	InternalCodeEntries internalCodeEntries;
};

struct DiagnosticsEntry
{
	DiagnosticClientCanPorts diagnosticClientCanPorts;
	InternalCodeList internalCodeList;
};

struct BdtDefinitionEntry
{
	unsigned type;
	unsigned maximumByteCount;
};
using BdtDefinitionEntries = Utilities::ArrayView<BdtDefinitionEntry>;

struct BdtConfig
{
	BdtDefinitionEntries bdtDefinitionEntries;
};

struct PgtPidEntry
{
	unsigned pid;
	unsigned requestRate;
	char const* pMiddlewareId;
};
using PgtPidEntries = Utilities::ArrayView<PgtPidEntry>;
struct PgtEntry
{
	PgtPidEntries pgtPidEntries;
};
struct EthernetPeerNodeEntry
{
	unsigned fid;
	char const* pIpAddress;
	PgtEntry pgtEntry;
};
using EthernetPeerNodeEntries = Utilities::ArrayView<EthernetPeerNodeEntry>;
struct EthernetDataLinkEntry
{
	unsigned fid;
	char const* pIpAddress;
	EthernetPeerNodeEntries ethernetPeerNodeEntries;
};

struct SharkConfig
{
	J1939LinkEntries j1939LinkEntries;
	std::optional<DeviceIdEntry> j1939DeviceIdEntry;
	std::optional<MachineSecuritySystemEntry> machineSecuritySystemEntry;
	std::optional<DiagnosticsEntry> diagnosticsEntry;
	std::optional<BdtConfig> bdtConfig;
	std::optional<EthernetDataLinkEntry> ethernetDataLinkEntry;
};
}
