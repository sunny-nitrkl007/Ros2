/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pid Identifier Configuration

#pragma once

#include "Utilities/ArrayView.h"
#include <SharkConfiguration.pb.h>

namespace Config
{
enum DataType
{
	Signed,
	Unsigned,
	Binary,

	DataTypeCount
};
enum FaultCapability
{
	None,
	DSI,

	FaultCapabilityCount
};
enum ByteOrder
{
	LsbFirst,
	MsbFirst,
	NA,

	ByteOrderCount
};
struct PidIdentifierEntry
{
	unsigned pid;
	unsigned byteCount;
	DataType dataType;
	ByteOrder byteOrder;
	FaultCapability faultCapability;
	double scaling;
	cat::shark::Unit unit;
	cat::shark::DataPresentationType presentationType;
};
using PidIdentifierEntries = Utilities::ArrayView<PidIdentifierEntry>;

struct PidIdentifierConfig
{
	PidIdentifierEntries entries;
};

struct MultiBytePidIdentifierEntry
{
	unsigned pid;
	unsigned minimumLength;
	unsigned maximumLength;
	cat::shark::MultiBytePidEntry::MultiBytePidDataType dataType;
};
using MultiBytePidIdentifierEntries = Utilities::ArrayView<MultiBytePidIdentifierEntry>;

struct MultiBytePidIdentifierConfig
{
	MultiBytePidIdentifierEntries entries;
};
}
