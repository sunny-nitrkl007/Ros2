/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Spn Identifier Configuration

#pragma once

#include "Utilities/ArrayView.h"
#include <SharkConfiguration.pb.h>

namespace Config
{
struct SpnIdentifierEntry
{
	unsigned spn;
	unsigned bitCount;
	double scaling;
	double offset;
	cat::shark::Unit unit;
	cat::shark::DataPresentationType presentationType;
};
using SpnIdentifierEntries = Utilities::ArrayView<SpnIdentifierEntry>;

struct SpnIdentifierConfig
{
	SpnIdentifierEntries entries;
};
}
