/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Data Link Engine Configuration Factory

#pragma once

#include "IConfigDescriber.h"
#include <SharkConfiguration.pb.h>

namespace Config
{
class ConfigFactory
{
public:
	static cat::shark::Config const CreateConfig(IConfigDescriber const& configDescriber);
};
}
