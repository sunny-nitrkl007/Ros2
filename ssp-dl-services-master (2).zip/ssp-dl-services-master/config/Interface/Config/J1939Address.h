/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Type for J1939 Addresses to help with outputting is value, validation, etc.

#pragma once

#include <boost/io/ios_state.hpp>
#include <cassert>
#include <iomanip>
#include <ostream>

namespace Config
{
class J1939Address
{
public:
	constexpr J1939Address() noexcept = default;
	constexpr J1939Address(unsigned address) noexcept
		: m_address{address}
	{
	}
	constexpr operator unsigned() const noexcept
	{
		return m_address;
	}
	constexpr bool IsValid() const
	{
		return m_address < 0xFC; // [FC, FF] are invalid
	}
private:
	static constexpr unsigned s_defaultInvalidAddress = 0xFC; // FC stands out a little more than FF

	unsigned m_address{s_defaultInvalidAddress};
};
inline std::ostream& operator<<(std::ostream& stream, J1939Address address)
{
	assert(address.IsValid());
	boost::io::ios_flags_saver flagsRestorer{stream};
	return stream << "0x" << std::uppercase << std::hex << std::setw(2) << std::setfill('0') << static_cast<unsigned>(address);
}
}
