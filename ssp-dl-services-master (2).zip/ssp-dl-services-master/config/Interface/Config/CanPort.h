/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Config entry point

#pragma once

#include <ostream>

namespace Config
{
enum CanPort : unsigned
{
	Can0 = 0,
	Can1,
	Can2,
	Can3,
	Can4,
	Can5,

	CanPortCount
};

inline std::ostream& operator<<(std::ostream& stream, CanPort canPort)
{
	return stream << "can" << static_cast<unsigned>(canPort);
}
}