/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// PGN class wrapper

#pragma once

#include <cstdint>
#include <iomanip>
#include <iostream>

namespace Config
{
class Pgn final
{
public:
	constexpr Pgn() noexcept = default;
	constexpr Pgn(unsigned pgn) noexcept
		: m_pgn{pgn}
	{
	}
	constexpr operator unsigned() const { return Value(); }

	constexpr unsigned Value() const { return m_pgn; }
	constexpr unsigned NumberWithoutDestinationAddress() const { return IsPdu1() ? Value() & 0x01FF00 : Value(); }
	constexpr uint8_t DestinationAddress() const { return IsPdu1() ? Value() & 0xFF : 0xFF; }
private:
	constexpr uint8_t Pf() const { return static_cast<uint8_t>((Value() & 0x00FF00) >> 8); }
	constexpr bool IsPdu1() const { return Pf() < 240; }

	unsigned m_pgn{0};
};
inline std::ostream& operator<<(std::ostream& ostream, Pgn pgn)
{
	return ostream << "PGN 0x" << std::uppercase << std::hex << std::setw(6) << std::setfill('0') << pgn.Value();
}
}
