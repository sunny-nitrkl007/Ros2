/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Type for PID to help with outputting is value, validation, etc.

#pragma once

#include <boost/io/ios_state.hpp>
#include <cassert>
#include <ostream>

namespace Config
{
class Pid final
{
public:
	constexpr Pid() noexcept = default;
	constexpr Pid(unsigned pid) noexcept
		: m_pid{pid}
	{
	}
	operator unsigned() const
	{
		assert(IsValid());
		return Value();
	}
	constexpr unsigned Value() const { return m_pid; }
	constexpr bool IsValid() const
	{
		return Value() <= 0xFFFFFF;
	}
	constexpr bool IsMultiByte() const
	{
		return (0x80   <= m_pid && m_pid <= 0xC7  ) ||
		       (0xF800 <= m_pid && m_pid <= 0xFBFF);
	}
	constexpr bool IsFixedByte() const
	{
		return (0x01     <= m_pid && m_pid <= 0x7F     ) ||
		       (0xC8     <= m_pid && m_pid <= 0xCE     ) ||
		       (0xF001   <= m_pid && m_pid <= 0xF3FF   ) ||
		       (0xF401   <= m_pid && m_pid <= 0xF7FF   ) ||
		       (0xFC01   <= m_pid && m_pid <= 0xFFFF   ) ||
		       (0xD00001 <= m_pid && m_pid <= 0xD0FFFF ) ||
		       (0xD10001 <= m_pid && m_pid <= 0xD1FFFF );
	}
private:
	unsigned m_pid{0};
};
inline std::ostream& operator<<(std::ostream& stream, Pid pid)
{
	assert(pid.IsValid());
	boost::io::ios_flags_saver flagsRestorer{stream};
	return stream << "PID: 0x" << std::uppercase << std::hex << pid.Value();
}
}
