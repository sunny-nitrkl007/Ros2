/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Config top-level interface

#pragma once

#include "SharkConfig.h"
#include "PidIdentifierConfig.h"
#include "PgnIdentifierConfig.h"
#include "SpnIdentifierConfig.h"
#include "Utilities/nice_ptr.h"

namespace Config
{
class IConfigDescriber
{
public:
	virtual ~IConfigDescriber() = default;

	template <class T> using nice_ptr = Utilities::nice_ptr<T>; // Alias so declaraion length may be shorter

	virtual nice_ptr<SharkConfig const> GetSharkConfig() const { return nullptr; }
	virtual nice_ptr<PidIdentifierConfig const> GetPidConfig() const     { return nullptr; }
	virtual nice_ptr<PgnIdentifierConfig const> GetPgnConfig() const     { return nullptr; }
	virtual nice_ptr<SpnIdentifierConfig const> GetSpnConfig() const     { return nullptr; }
	virtual nice_ptr<MultiBytePidIdentifierConfig const> GetMultiBytePidConfig() const { return nullptr; }
};
}
