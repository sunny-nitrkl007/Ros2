/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Protobuf to Config conversion functions

#pragma once

#include "CanPort.h"
#include <SharkConfiguration.pb.h>
#include <middleware_diagnostics.pb.h>

namespace Config
{
// \throws std::runtime_error on invalid enum value
Config::CanPort ToConfigCanPort(cat::shark::J1939DataLink::CanPort protobufCanPort);
Config::CanPort ToConfigCanPort(cat::middleware::diagnostics::NetworkAddress_J1939Address_CanPort protobufCanPort);
cat::shark::J1939DataLink::CanPort ToProtobufCanPort(Config::CanPort configCanPort);
cat::middleware::diagnostics::NetworkAddress_J1939Address_CanPort ToCodesProtobufCanPort(Config::CanPort configCanPort);
}
