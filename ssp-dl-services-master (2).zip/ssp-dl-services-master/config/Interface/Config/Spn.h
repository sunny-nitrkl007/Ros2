/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SPN class wrapper

#pragma once

//#include <cstdint>
#include <iomanip>
#include <iostream>

namespace Config
{
class Spn final
{
public:
	constexpr Spn() noexcept = default;
	constexpr Spn(unsigned spn) noexcept
		: m_spn{spn}
	{
	}
	constexpr operator unsigned() const { return Value(); }

	constexpr unsigned Value() const { return m_spn; }
private:
	unsigned m_spn{0};
};
inline std::ostream& operator<<(std::ostream& ostream, Spn spn)
{
	return ostream << "SPN " << std::dec << spn.Value();
}
}