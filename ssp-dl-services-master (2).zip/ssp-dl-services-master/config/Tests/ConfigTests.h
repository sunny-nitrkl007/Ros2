/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Config unit tests

#pragma once

namespace Config
{
namespace Tests
{
constexpr char const* TemporaryFilePrefix() { return "Config_Tests"; }
}
}
