/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Protobuf Conversions tests

#include "../ProtobufConversions.cpp"
#include <gmock/gmock.h>

using namespace testing;

namespace Config
{
struct CanPortConversions
{
	Config::CanPort configCanPort;
	cat::shark::J1939DataLink::CanPort protobufCanPort;
};

constexpr CanPortConversions n_canPortConversions[] =
{
	{Config::CanPort::Can0, cat::shark::J1939DataLink_CanPort::J1939DataLink_CanPort_CAN_PORT_0},
	{Config::CanPort::Can1, cat::shark::J1939DataLink_CanPort::J1939DataLink_CanPort_CAN_PORT_1},
	{Config::CanPort::Can2, cat::shark::J1939DataLink_CanPort::J1939DataLink_CanPort_CAN_PORT_2},
	{Config::CanPort::Can3, cat::shark::J1939DataLink_CanPort::J1939DataLink_CanPort_CAN_PORT_3},
	{Config::CanPort::Can4, cat::shark::J1939DataLink_CanPort::J1939DataLink_CanPort_CAN_PORT_4},
	{Config::CanPort::Can5, cat::shark::J1939DataLink_CanPort::J1939DataLink_CanPort_CAN_PORT_5},
};
static_assert(static_cast<unsigned>(Config::CanPort::CanPortCount) ==
	static_cast<unsigned>(cat::shark::J1939DataLink_CanPort_CanPort_MAX),
	"If this fails, we need more test entries above.");
static_assert(std::size(n_canPortConversions) == static_cast<size_t>(Config::CanPort::CanPortCount));

class ProtobufConversions_CanPortTests : public TestWithParam<CanPortConversions>
{
};
INSTANTIATE_TEST_CASE_P(Param, ProtobufConversions_CanPortTests, ValuesIn(n_canPortConversions));
TEST_P(ProtobufConversions_CanPortTests, ToConfigCanPort)
{
	auto const& param = GetParam();
	auto const configCanPort = ToConfigCanPort(param.protobufCanPort);
	EXPECT_THAT(param.configCanPort, Eq(configCanPort));
}
TEST_P(ProtobufConversions_CanPortTests, ToProtobufCanPort)
{
	auto const& param = GetParam();
	auto const protobufCanPort = ToProtobufCanPort(param.configCanPort);
	EXPECT_THAT(param.protobufCanPort, Eq(protobufCanPort));
}
}