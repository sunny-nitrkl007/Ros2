/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Config Factory tests

#include "ConfigFactory.cpp"
#include <gmock/gmock.h>

using namespace testing;

namespace Config
{
namespace
{
struct Any
{
	constexpr static CanPort CanPortValue()          { return CanPort::Can3; }
	constexpr static unsigned Address()              { return 0x42; }
	constexpr static unsigned Spn()	                 { return 4267; }
	constexpr static unsigned Pid()	                 { return 0x2424; }
	constexpr static unsigned Pgn()	                 { return 0xF004; }
	constexpr static unsigned ExtensionId()          { return 0xF019; }
	constexpr static unsigned BdtType()              { return 0x4242; }
	constexpr static unsigned HostFid()              { return 0x87654321; }
	constexpr static unsigned PeerFid()              { return 0x12345678; }
	constexpr static unsigned BroadcastRate()        { return 1000; }
	constexpr static char const* IpAddress()         { return "165.26.79.42"; }
	constexpr static char const* OtherIpAddress()    { return "165.26.79.24"; }
	constexpr static char const* MiddlewareId()      { return "middleware_id"; }
	constexpr static char const* OtherMiddlewareId() { return "other_middleware_id"; }
};
}

class ConfigFactoryTest : public Test
{
protected:
	template<typename ResultType, typename EntryType, typename PopulateFunction>
	ResultType CallPopulate(EntryType const& entry, PopulateFunction populateFunction)
	{
		ResultType result;
		populateFunction(result, entry);
		return result;
	}

	cat::shark::J1939DataLink CallPopulateIdentity(IdentityEntry const& identityEntry)
	{
		return CallPopulate<cat::shark::J1939DataLink>(identityEntry, PopulateIdentity);
	}
	cat::shark::Config CallPopulateJ1939DeviceId(DeviceIdEntry const& deviceIdEntry)
	{
		return CallPopulate<cat::shark::Config>(deviceIdEntry, PopulateJ1939DeviceId);
	}
	cat::shark::Config CallPopulateMachineSecuritySystem(MachineSecuritySystemEntry const& machineSecuritySystemEntry)
	{
		return CallPopulate<cat::shark::Config>(machineSecuritySystemEntry, PopulateMachineSecuritySystem);
	}
	cat::shark::J1939DataLink::TransmitBroadcastPgn CallPopulateInternalSpn(InternalSpnEntry const& internalSpnEntry)
	{
		using TransmitBroadcastPgn = cat::shark::J1939DataLink::TransmitBroadcastPgn;
		return CallPopulate<TransmitBroadcastPgn>(internalSpnEntry, PopulateInternalSpn<TransmitBroadcastPgn>);
	}
	cat::shark::J1939DataLink::PeerNode CallPopulatePeerBdt(BdtEntry const& bdtEntry)
	{
		return CallPopulate<cat::shark::J1939DataLink::PeerNode>(bdtEntry, PopulatePeerBdt);
	}
	cat::shark::J1939DataLink::PeerNode CallPopulatePeerCalibrationServices(CalibrationServicesEntry const& calibrationServicesEntry)
	{
		return CallPopulate<cat::shark::J1939DataLink::PeerNode>(calibrationServicesEntry, PopulatePeerCalibrationServices);
	}
	cat::shark::J1939DataLink::PeerNode CallPopulatePeerExtensionId(ExtensionIdEntry const& extensionIdEntry)
	{
		return CallPopulate<cat::shark::J1939DataLink::PeerNode>(extensionIdEntry, PopulatePeerExtensionId);
	}
	cat::shark::J1939DataLink CallPopulateTransmitBroadcastPgn(TransmitBroadcastPgnEntry const& transmitBroadcastPgnEntry)
	{
		return CallPopulate<cat::shark::J1939DataLink>(transmitBroadcastPgnEntry, PopulateTransmitBroadcastPgn);
	}
	cat::shark::Config CallPopulateBdtConfig(BdtConfig const& bdtConfig)
	{
		return CallPopulate<cat::shark::Config>(bdtConfig, PopulateBdtConfig);
	}
	cat::shark::Config CallPopulateEthernetDataLink(EthernetDataLinkEntry const& ethernetDataLinkEntry)
	{
		return CallPopulate<cat::shark::Config>(ethernetDataLinkEntry, PopulateEthernetDataLink);
	}
};
namespace
{
constexpr unsigned n_anyValidAddresses[]{0x24, 0x42};
constexpr unsigned n_ecuInstance = 1;
constexpr unsigned n_functionInstance = 2;
constexpr unsigned n_vehicleSystem = 4;
constexpr unsigned n_industryGroup = 3;
constexpr unsigned n_vehicleSystemInstance = 5;
constexpr unsigned n_function = 6;
constexpr unsigned n_manufacturerCode = 7;
constexpr IdentityEntry n_anyIdentityEntry{
	n_anyValidAddresses,
	n_ecuInstance,
	n_functionInstance,
	n_industryGroup,
	n_vehicleSystem,
	n_vehicleSystemInstance,
	n_function,
	n_manufacturerCode};
}
TEST_F(ConfigFactoryTest, PopulateIdentity_SetsIdentity_ValidAddresses)
{
	auto j1939DataLink = CallPopulateIdentity(n_anyIdentityEntry);
	EXPECT_THAT(j1939DataLink.identity().valid_addresses(), ElementsAreArray(n_anyValidAddresses));
}
TEST_F(ConfigFactoryTest, PopulateIdentity_SetsIdentity_EcuInstance)
{
	auto j1939DataLink = CallPopulateIdentity(n_anyIdentityEntry);
	EXPECT_THAT(j1939DataLink.identity().ecu_instance(), n_ecuInstance);
}
TEST_F(ConfigFactoryTest, PopulateIdentity_SetsIdentity_FunctionInstance)
{
	auto j1939DataLink = CallPopulateIdentity(n_anyIdentityEntry);
	EXPECT_THAT(j1939DataLink.identity().function_instance(), n_functionInstance);
}
TEST_F(ConfigFactoryTest, PopulateIdentity_SetsIdentity_IndustryGroup)
{
	auto j1939DataLink = CallPopulateIdentity(n_anyIdentityEntry);
	EXPECT_THAT(j1939DataLink.identity().industry_group(), n_industryGroup);
}
TEST_F(ConfigFactoryTest, PopulateIdentity_SetsIdentity_VehicleSystem)
{
	auto j1939DataLink = CallPopulateIdentity(n_anyIdentityEntry);
	EXPECT_THAT(j1939DataLink.identity().vehicle_system(), n_vehicleSystem);
}
TEST_F(ConfigFactoryTest, PopulateIdentity_SetsIdentity_VehicleSystemInstance)
{
	auto j1939DataLink = CallPopulateIdentity(n_anyIdentityEntry);
	EXPECT_THAT(j1939DataLink.identity().vehicle_system_instance(), n_vehicleSystemInstance);
}
TEST_F(ConfigFactoryTest, PopulateIdentity_SetsIdentity_Function)
{
	auto j1939DataLink = CallPopulateIdentity(n_anyIdentityEntry);
	EXPECT_THAT(j1939DataLink.identity().function(), n_function);
}
TEST_F(ConfigFactoryTest, PopulateIdentity_SetsIdentity_ManufacturerCode)
{
	auto j1939DataLink = CallPopulateIdentity(n_anyIdentityEntry);
	EXPECT_THAT(j1939DataLink.identity().manufacturer_code(), n_manufacturerCode);
}

namespace
{
constexpr unsigned n_anyModuleId = 0x4242;
constexpr unsigned n_anyServiceToolSupportLevel = 0x3723;
constexpr unsigned n_anyApplicationId = 0x1234;
constexpr unsigned n_anyMinimumServiceToolSupportLevel = 0x5698;
constexpr unsigned n_anyFid = 0x80000000;
constexpr DeviceIdEntry n_anyDeviceIdEntry{
	n_anyModuleId,
	n_anyServiceToolSupportLevel,
	n_anyApplicationId,
	n_anyMinimumServiceToolSupportLevel,
	n_anyFid};
}
TEST_F(ConfigFactoryTest, PopulateDeviceId_SetsDeviceId_ModuleId)
{
	auto config = CallPopulateJ1939DeviceId(n_anyDeviceIdEntry);
	EXPECT_THAT(config.j1939_device_id().module_id(), n_anyModuleId);
}
TEST_F(ConfigFactoryTest, PopulateDeviceId_SetsDeviceId_ServiceToolSupportLevel)
{
	auto config = CallPopulateJ1939DeviceId(n_anyDeviceIdEntry);
	EXPECT_THAT(config.j1939_device_id().service_tool_support_level(), n_anyServiceToolSupportLevel);
}
TEST_F(ConfigFactoryTest, PopulateDeviceId_SetsDeviceId_ApplicationId)
{
	auto config = CallPopulateJ1939DeviceId(n_anyDeviceIdEntry);
	EXPECT_THAT(config.j1939_device_id().application_id(), n_anyApplicationId);
}
TEST_F(ConfigFactoryTest, PopulateDeviceId_SetsDeviceId_MinimumServiceToolSupportLevel)
{
	auto config = CallPopulateJ1939DeviceId(n_anyDeviceIdEntry);
	EXPECT_THAT(config.j1939_device_id().minimum_service_tool_support_level(), n_anyMinimumServiceToolSupportLevel);
}
TEST_F(ConfigFactoryTest, PopulateDeviceId_SetsDeviceId_Fid)
{
	auto config = CallPopulateJ1939DeviceId(n_anyDeviceIdEntry);
	EXPECT_THAT(config.j1939_device_id().fid(), n_anyFid);
}

namespace
{
constexpr MachineSecuritySystemEntry n_anyMachineSecuritySystemEntry{Any::CanPortValue(), Any::Address()};
}
TEST_F(ConfigFactoryTest, PopulateMachineSecuritySystem_SetMachineSecuritySystem_CanPort)
{
	auto config = CallPopulateMachineSecuritySystem(n_anyMachineSecuritySystemEntry);
	EXPECT_THAT(config.machine_security_system().can_port(), ToProtobufCanPort(Any::CanPortValue()));
}
TEST_F(ConfigFactoryTest, PopulateMachineSecuritySystem_SetMachineSecuritySystem_Address)
{
	auto config = CallPopulateMachineSecuritySystem(n_anyMachineSecuritySystemEntry);
	EXPECT_THAT(config.machine_security_system().address(), Any::Address());
}

namespace
{
constexpr InternalSpnEntry n_anyInternalSpnEntry{Any::Spn(), Any::MiddlewareId()};
}
TEST_F(ConfigFactoryTest, PopulateInternalSpn_SetsTransmitBroadcastPgn_SpnValue)
{
	auto transmitBroadcastPgn = CallPopulateInternalSpn(n_anyInternalSpnEntry);
	EXPECT_THAT(transmitBroadcastPgn.spns().Get(0).spn(), Any::Spn());
}
TEST_F(ConfigFactoryTest, PopulateInternalSpn_SetsMiddlewareIdValue)
{
	auto transmitBroadcastPgn = CallPopulateInternalSpn(n_anyInternalSpnEntry);
	EXPECT_THAT(transmitBroadcastPgn.spns().Get(0).middleware_id(), Any::MiddlewareId());
}

namespace
{
constexpr unsigned n_anyBdtIndex = 0xFFFFFF80;
constexpr BdtAccessMode n_anyBdtAccessMode = BdtAccessMode::ReadWrite;
constexpr BdtTypeEntry n_anyTypeEntry[]{{Any::BdtType(), n_anyBdtIndex, n_anyBdtAccessMode, Any::MiddlewareId()}};
constexpr BdtEntry n_anyBdtEntry{n_anyTypeEntry};
}
TEST_F(ConfigFactoryTest, PopulatePeerBdt_SetsBdtDetail_Type)
{
	auto peerNode = CallPopulatePeerBdt(n_anyBdtEntry);
	EXPECT_THAT(peerNode.bdt().bdt_types().Get(0).type(), Any::BdtType());
}
TEST_F(ConfigFactoryTest, PopulatePeerBdt_SetsBdtDetail_Index)
{
	auto peerNode = CallPopulatePeerBdt(n_anyBdtEntry);
	EXPECT_THAT(peerNode.bdt().bdt_types().Get(0).index(), n_anyBdtIndex);
}
TEST_F(ConfigFactoryTest, PopulatePeerBdt_SetsBdtDetail_AccessMode)
{
	auto peerNode = CallPopulatePeerBdt(n_anyBdtEntry);
	EXPECT_THAT(peerNode.bdt().bdt_types().Get(0).access_mode(), static_cast<J1939DataLink::PeerNode::Bdt::AccessMode>(n_anyBdtAccessMode));
}
TEST_F(ConfigFactoryTest, PopulatePeerBdt_SetsBdtDetail_MiddlewareId)
{
	auto peerNode = CallPopulatePeerBdt(n_anyBdtEntry);
	EXPECT_THAT(peerNode.bdt().bdt_types().Get(0).middleware_id(), Any::MiddlewareId());
}

namespace
{
constexpr unsigned n_anyCalibrationIndex = 0x4242;
constexpr unsigned n_anyServiceTestIndex = 0x2424;
constexpr CalibrationServiceDataEntry n_anyCalibrationEntry[]{{n_anyCalibrationIndex, Any::MiddlewareId()}};
constexpr CalibrationServiceDataEntry n_anyServiceTestEntry[]{{n_anyServiceTestIndex, Any::OtherMiddlewareId()}};
constexpr CalibrationServicesEntry n_anyCalibrationServicesEntry{n_anyCalibrationEntry, n_anyServiceTestEntry};
}
TEST_F(ConfigFactoryTest, PopulatePeerCalibrationServices_SetsCalibrationEntry)
{
	auto peerNode = CallPopulatePeerCalibrationServices(n_anyCalibrationServicesEntry);
	auto const& calibrationEntry = peerNode.calibration_services().calibrations().Get(0);
	EXPECT_THAT(calibrationEntry.index(), n_anyCalibrationIndex);
	EXPECT_THAT(calibrationEntry.middleware_id(), Any::MiddlewareId());
}
TEST_F(ConfigFactoryTest, PopulatePeerCalibrationServices_SetsServiceTestEntry)
{
	auto peerNode = CallPopulatePeerCalibrationServices(n_anyCalibrationServicesEntry);
	auto const& serviceTestEntry = peerNode.calibration_services().service_tests().Get(0);
	EXPECT_THAT(serviceTestEntry.index(), n_anyServiceTestIndex);
	EXPECT_THAT(serviceTestEntry.middleware_id(), Any::OtherMiddlewareId());
}

namespace
{
constexpr ExtensionIdReadEntry n_anyExtensionIdReadEntry[]{{Any::ExtensionId(), Any::MiddlewareId()}};
constexpr ExtensionIdEntry n_anyExtensionIdEntry{n_anyExtensionIdReadEntry};
}
TEST_F(ConfigFactoryTest, PopulatePeerExtensionId_SetsExtensionIdReadEntry)
{
	auto peerNode = CallPopulatePeerExtensionId(n_anyExtensionIdEntry);
	auto const& extensionIdReadEntry = peerNode.extension_id().extension_id_reads().Get(0);
	EXPECT_THAT(extensionIdReadEntry.extension_id(), Any::ExtensionId());
	EXPECT_THAT(extensionIdReadEntry.middleware_id(), Any::MiddlewareId());
}

namespace
{
constexpr TransmitBroadcastPgnEntry n_anyTransmitBroadcastPgnEntry{Any::Pgn(), Any::BroadcastRate(), {n_anyInternalSpnEntry}, Any::MiddlewareId()};
}
TEST_F(ConfigFactoryTest, PopulateTransmitBroadcastPgn_SetsPgnValue)
{
	auto j1939DataLink = CallPopulateTransmitBroadcastPgn(n_anyTransmitBroadcastPgnEntry);
	EXPECT_THAT(j1939DataLink.transmit_broadcast_pgns().Get(0).pgn(), Any::Pgn());
}
TEST_F(ConfigFactoryTest, PopulateTransmitBroadcastPgn_SetsBroadcastRateValue)
{
	auto j1939DataLink = CallPopulateTransmitBroadcastPgn(n_anyTransmitBroadcastPgnEntry);
	EXPECT_THAT(j1939DataLink.transmit_broadcast_pgns().Get(0).broadcast_rate(), Any::BroadcastRate());
}
TEST_F(ConfigFactoryTest, PopulateTransmitBroadcastPgn_SetsMiddlewareIdValue)
{
	auto j1939DataLink = CallPopulateTransmitBroadcastPgn(n_anyTransmitBroadcastPgnEntry);
	EXPECT_THAT(j1939DataLink.transmit_broadcast_pgns().Get(0).middleware_id(), Any::MiddlewareId());
}
TEST_F(ConfigFactoryTest, PopulateTransmitBroadcastPgn_SetsInternalSpnValue)
{
	auto j1939DataLink = CallPopulateTransmitBroadcastPgn(n_anyTransmitBroadcastPgnEntry);
	auto const& internalSpn = j1939DataLink.transmit_broadcast_pgns().Get(0).spns().Get(0);
	EXPECT_THAT(internalSpn.spn(), Any::Spn());
	EXPECT_THAT(internalSpn.middleware_id(), Any::MiddlewareId());
}

namespace
{
constexpr unsigned n_anyMaximumByteCount = 100000;
constexpr BdtDefinitionEntry n_anyBdtDefinitionEntry[]{{Any::BdtType(), n_anyMaximumByteCount}};
constexpr BdtConfig n_anyBdtConfig{n_anyBdtDefinitionEntry};
}
TEST_F(ConfigFactoryTest, PopulateBdtConfig_SetsBdtDefinitionEntry_Type)
{
	auto bdtConfig = CallPopulateBdtConfig(n_anyBdtConfig);
	EXPECT_THAT(bdtConfig.bdt_entries().Get(0).type(), Any::BdtType());
}
TEST_F(ConfigFactoryTest, PopulateBdtConfig_SetsBdtDefinitionEntry_MaximumByteCount)
{
	auto bdtConfig = CallPopulateBdtConfig(n_anyBdtConfig);
	EXPECT_THAT(bdtConfig.bdt_entries().Get(0).maximum_byte_count(), n_anyMaximumByteCount);
}

namespace
{
constexpr PgtPidEntry n_anyPgtPidEntry[]{{Any::Pid(), Any::BroadcastRate(), Any::MiddlewareId()}};
constexpr PgtEntry n_anyPgtEntry{n_anyPgtPidEntry};
constexpr EthernetPeerNodeEntry n_anyEthernetPeerNodeEntry[]{{Any::PeerFid(), Any::OtherIpAddress(), n_anyPgtEntry}};
constexpr EthernetDataLinkEntry n_anyEthernetDataLinkEntry{Any::HostFid(), Any::IpAddress(), n_anyEthernetPeerNodeEntry};
}
TEST_F(ConfigFactoryTest, PopulateEthernetDataLink_SetsEthernetDataLink_Fid)
{
	auto config = CallPopulateEthernetDataLink(n_anyEthernetDataLinkEntry);
	EXPECT_THAT(config.ethernet_data_link().fid(), Any::HostFid());
}
TEST_F(ConfigFactoryTest, PopulateEthernetDataLink_SetsEthernetDataLink_IpAddress)
{
	auto config = CallPopulateEthernetDataLink(n_anyEthernetDataLinkEntry);
	EXPECT_THAT(config.ethernet_data_link().ip_address(), Any::IpAddress());
}
TEST_F(ConfigFactoryTest, PopulateEthernetDataLink_SetsPeerNode_Fid)
{
	auto config = CallPopulateEthernetDataLink(n_anyEthernetDataLinkEntry);
	EXPECT_THAT(config.ethernet_data_link().peer_nodes().Get(0).fid(), Any::PeerFid());
}
TEST_F(ConfigFactoryTest, PopulateEthernetDataLink_SetsPeerNode_IpAddress)
{
	auto config = CallPopulateEthernetDataLink(n_anyEthernetDataLinkEntry);
	EXPECT_THAT(config.ethernet_data_link().peer_nodes().Get(0).ip_address(), Any::OtherIpAddress());
}
TEST_F(ConfigFactoryTest, PopulateEthernetDataLink_SetsPgtPid_Pid)
{
	auto config = CallPopulateEthernetDataLink(n_anyEthernetDataLinkEntry);
	EXPECT_THAT(config.ethernet_data_link().peer_nodes().Get(0).pgt().pgt_pids().Get(0).pid(), Any::Pid());
}
TEST_F(ConfigFactoryTest, PopulateEthernetDataLink_SetsPgtPid_RequestRate)
{
	auto config = CallPopulateEthernetDataLink(n_anyEthernetDataLinkEntry);
	EXPECT_THAT(
		config.ethernet_data_link().peer_nodes().Get(0).pgt().pgt_pids().Get(0).request_rate(),
		static_cast<J1939DataLink::PeerNode::Pgb::RequestRate>(Any::BroadcastRate()));
}
TEST_F(ConfigFactoryTest, PopulateEthernetDataLink_SetsPgtPid_MiddlewareId)
{
	auto config = CallPopulateEthernetDataLink(n_anyEthernetDataLinkEntry);
	EXPECT_THAT(config.ethernet_data_link().peer_nodes().Get(0).pgt().pgt_pids().Get(0).middleware_id(), Any::MiddlewareId());
}
}