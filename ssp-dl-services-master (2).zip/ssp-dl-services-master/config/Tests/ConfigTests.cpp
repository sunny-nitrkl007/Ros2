/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Config unit tests

#include "ConfigTests.h"
#include "Utilities/TemporaryFileRemoverEnvironment.h"
#include <gmock/gmock.h>

int main(int argc, char* argv[])
{
//#define DEBUGGING_TEST_EXCEPTIONS // Do not commit with this uncommented!
#ifdef DEBUGGING_TEST_EXCEPTIONS
	::testing::FLAGS_gtest_catch_exceptions = 0;
#endif
	testing::InitGoogleMock(&argc, argv);
	Utilities::TemporaryFileRemoverEnvironment::CreateAndEnableRemover(Config::Tests::TemporaryFilePrefix());
	return RUN_ALL_TESTS();
}
