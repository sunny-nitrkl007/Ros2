/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See IpAddress.h

#include "Config/IpAddress.h"
#include <arpa/inet.h>
#include <cassert>
#include <netinet/in.h>
#include <stdexcept>

namespace Config
{
IpAddress::IpAddress(char const* pIpAddress)
{
	if (!pIpAddress)
	{
		throw std::runtime_error("IP Address cannot be null");
	}

	in_addr address{};
	if (inet_pton(AF_INET, pIpAddress, &address) == 0)
	{
		throw std::runtime_error("Invalid ip address: " + std::string{pIpAddress});
	}

	m_address = address.s_addr;
}
IpAddress::IpAddress(std::string const& ipAddress)
	: IpAddress(ipAddress.c_str())
{
}
std::string IpAddress::AsString() const
{
	char str[INET_ADDRSTRLEN];
	auto const pResult = inet_ntop(AF_INET, &m_address, str, sizeof(str));
	assert(pResult == str); (void) pResult;

	return str;
}
std::ostream& operator<<(std::ostream& stream, IpAddress const& ipAddress)
{
	return stream << "IP Address: " << ipAddress.AsString();
}
bool operator==(IpAddress const& left, IpAddress const& right) noexcept
{
	return left.NetworkAddress() == right.NetworkAddress();
}
bool operator!=(IpAddress const& left, IpAddress const& right) noexcept
{
	return !(left == right);
}
}
