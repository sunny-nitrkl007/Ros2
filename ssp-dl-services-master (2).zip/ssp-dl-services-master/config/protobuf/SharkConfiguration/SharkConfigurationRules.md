<div align="center">

  # Data Link Engine Configuration Rules

  Summary of validation rules for the protobuf configuration file that will be injected into the data link engine
  <br/><br/>

</div>

## Config message

```
message Config
{
	repeated J1939DataLink j1939_data_links = 1;
	repeated PidEntry pid_entries = 2;
	repeated PgnEntry pgn_entries = 3;
	repeated SpnEntry spn_entries = 4;
	optional J1939DataLink.DeviceId j1939_device_id = 5;
	optional MachineSecuritySystem machine_security_system = 6;
	optional Diagnostics diagnostics = 7;
	repeated MultiBytePidEntry multi_byte_pid_entries = 8;
	repeated BdtEntry bdt_entries = 9;
	optional EthernetDataLink ethernet_data_link = 10;
}
```
### Description
Top level message that contains:
1. The low level J1939 data link setup for each can port that contains network configuration, protocol definitions for each peer node and J1939 identification data
1. The list of pid definitions that will be used to convert byte data from the data link into middleware values or vice versa
1. The list of pgn definitions that will be used to define the embedded spns and the bit offset where they are located
1. The list of spn definitions that will be used to convert byte data from the data link into middleware values or vice versa
1. The J1939 device id that will be used on every configured data link if requested
1. The J1939 location of the machine security system
1. The diagnostic configuration including the single data link and peers to request codes from and list of internal codes that can be controlled through middleware channels
1. The list of multi-byte pid definitions that will be used to convert and validate byte data from the data link into middleware values or vice versa
1. The list of bdt type definitions that can be used within the bdt config for a peer node

### Rules
| field | rule |
|---|---|
| pid_entries | must be sorted in ascending order by pid |
| pgn_entries | must be sorted in ascending order by pgn |
| spn_entries | must be sorted in ascending order by spn |
| multi_byte_pid_entries | must be sorted in ascending order by pid |

***

## J1939DataLink message

```
message J1939DataLink
{
	enum CanPort
	{
		CAN_PORT_UNSPECIFIED = 0;
		CAN_PORT_0 = 1;
		CAN_PORT_1 = 2;
		CAN_PORT_2 = 3;
		CAN_PORT_3 = 4;
		CAN_PORT_4 = 5;
		CAN_PORT_5 = 6;
	}
	CanPort can_port = 1;
	Identity identity = 2;
	repeated PeerNode peer_nodes = 4;
	repeated TransmitBroadcastPgn transmit_broadcast_pgns = 5;
}
```
Message representing a connection to a can port on this hardware.  Encapsulates J1939 identity and the peer addresses in its network.

### Rules
| field | rule |
|---|---|
| can_port | can specify any defined CanPort enum value from CAN_PORT_0 through CAN_PORT_5, this will determine the physical port to configure |
| identify | required to provide the set of possible addresses and J1939 name components |
| peer_nodes | must be sorted in ascending order by address field of PeerNode |
| transmit_broadcast_pgns | must be sorted ascending by pgn |
| transmit_broadcast_pgns | must not have any duplicated pgn values |

***

## Identity message

```
message Identity
{
	repeated uint32 valid_addresses = 1;
	uint32 ecu_instance = 2;
	uint32 function_instance = 3;
	uint32 industry_group = 4;
	uint32 vehicle_system = 5;
	uint32 vehicle_system_instance = 6;
	uint32 function = 7;
	uint32 manufacturer_code = 8;
}
```
Message unique to a can port that configures:
1. The list of possible addresses to be claimed in order
1. The J1939 name to be used for this can port

### Rules
| field | rule |
|---|---|
| valid_addresses | must contain the primary address to try and claim on the J1939 network |
| valid_addresses | can contain other addresses that will try to be claimed if the primary claim fails |
| valid_addresses | addresses must be ordered with primary first and then subsequent addresses in order that they should be tried |
| valid_addresses | each address must be in the range 0x00 through 0xFB inclusive |
| valid_addresses | must not contain any duplicate addresses |
| ecu_instance | must be in the range 0x00 through 0x07 inclusive |
| function_instance | must be in the range 0x00 through 0x1F inclusive |
| industry_group | must be in the range 0x00 through 0x07 inclusive |
| vehicle_system | must be in the range 0x00 through 0x7F inclusive |
| vehicle_system_instance | must be in the range 0x00 through 0x0F inclusive |
| function | must be in the range 0x00 through 0xFF inclusive |
| manufacturer_code | must be in the range 0x0000 through 0x07FF inclusive |

***

## DeviceId message

Deprecated field, should used j1939_device_id message in the Config object

***

## TransmitBroadcastPgn message

```
message TransmitBroadcastPgn
{
	enum BroadcastRate // milliseconds
	{
		BROADCAST_RATE_UNSPECIFIED = 0;
		BROADCAST_RATE_20 = 20;
		BROADCAST_RATE_50 = 50;
		BROADCAST_RATE_100 = 100;
		BROADCAST_RATE_200 = 200;
		BROADCAST_RATE_250 = 250;
		BROADCAST_RATE_500 = 500;
		BROADCAST_RATE_1000 = 1000;
		BROADCAST_RATE_5000 = 5000;
		BROADCAST_RATE_10000 = 10000;
		BROADCAST_RATE_30000 = 30000;
	}
	message Spn
	{
		uint32 spn = 1;
		string middleware_id = 2;
	}
	uint32 pgn = 1;
	BroadcastRate broadcast_rate = 2;
	repeated Spn spns = 3;
	string middleware_id = 4;
}
```
Defines list of pgns that are broadcast from this J1939 Data Link

### Spn Rules
| field | rule |
|---|---|
| spn | must be in the range 0 - 524287 inclusive |
| middleware_id | must be unique compared to all other middleware id values passed to data link engine |
| middleware_id | could be a publish or subscribe id depending on whether the Spn is tied to a receive or transmit pgn |

### TranmitBroadcastPgn Rules
| field | rule |
|---|---|
| pgn | must be 0x00F000 through 0x00FFFF or 0x01F000 through 0x01FFFF inclusive |
| broadcast_rate | must not be BROADCAST_RATE_UNSPECIFIED |
| spns | must be sorted ascending by spn |
| spns | must not have any duplicate spn values between entries |
| middleware_id | should be unique compared to all other middleware id values passed to data link engine |
| middleware_id | must be a subscribe id that data link engine will use to subscribe to data from middleware to populate the pgn bytes |

***

## PeerNode message

```
message PeerNode
{
	uint32 address = 1;
	optional Adt adt = 2;
	optional Pgb pgb = 3;
	optional Pgn pgn = 4;
	optional BasicReadWrite basic_read_write = 5;
	optional Bdt bdt = 6;
	optional CalibrationServices calibration_services = 7;
	optional ExtensionId extension_id = 8;
}
```
Defines how data link engine should communicate with each peer on the J1939 network

### Rules
| field | rule |
|---|---|
| address | must not be in the list of valid_addresses for the parent J1939DataLink |
| address | must not be a duplicate of another PeerNode under the same parent J1939DataLink |
| address | must be in the range 0x00 through 0xFB inclusive |

***

## Adt message

```
message Adt
{
	optional uint32 timeout = 1; // milliseconds
	repeated AdtPid adt_pids = 2;
}
```
Defines the list of adt parameters that should be requested from this PeerNode and optionally overide the timeout value for adt for this PeerNode

### Rules
| field | rule |
|---|---|
| timeout | if not set, then the default adt timeout library value will be used |
| timeout | if set, this will override the adt timeout sent to adt library |
| timeout | must be 7000 or greater |
| adt_pids | must be sorted in ascending order by pid within a PeerNode |
| adt_pids | must not have any duplicate pid values within a PeerNode |

***

## AdtPid message

```
message AdtPid
{
	uint32 pid = 1;
	string middleware_id = 2;
}
```
Defines an individual adt parameter

### Rules
| field | rule |
|---|---|
| pid | must be in the basic pid range of 1, 2 or 4-byte pids |
| middleware_id | must be unique compared to all other middleware id values passed to data link engine |
| middleware_id | must be a publish id that data link engine will use to publish data to middleware |

***

## Pgb message

```
message Pgb
{
	repeated PgbPid pgb_pids = 1;
}
```
Defines the list of pgb parameters that should be requested from this PeerNode

### Rules
| field | rule |
|---|---|
| pgb_pids | must be sorted in ascending order by RequestRate and then ascending order by pid within a PeerNode |
| pgb_pids | must not have any duplicate pid values within a PeerNode |

***

## PgbPid message

```
enum RequestRate // milliseconds
{
	REQUEST_RATE_UNSPECIFIED = 0;
	REQUEST_RATE_50 = 50;
	REQUEST_RATE_100 = 100;
	REQUEST_RATE_200 = 200;
	REQUEST_RATE_250 = 250;
	REQUEST_RATE_500 = 500;
	REQUEST_RATE_1000 = 1000;
	REQUEST_RATE_5000 = 5000;
	REQUEST_RATE_10000 = 10000;
	REQUEST_RATE_20000 = 20000;
	REQUEST_RATE_30000 = 30000;
}
enum Priority
{
	PRIORITY_UNSPECIFIED = 0;
	PRIORITY_HIGH = 1;
	PRIORITY_LOW  = 2;
}
message PgbPid
{
	uint32 pid = 1;
	RequestRate request_rate = 2;
	Priority priority = 3;
	string middleware_id = 4;
}
```
Defines an individual pgb parameter

### Rules
| field | rule |
|---|---|
| pid | must be in the basic pid range of 1, 2 or 4-byte pids |
| request_rate | must not be REQUEST_RATE_UNSPECIFIED |
| priority | must not be PRIORITY_UNSPECIFIED |
| middleware_id | must be unique compared to all other middleware id values passed to data link engine |
| middleware_id | must be a publish id that data link engine will use to publish data to middleware |

***

## Pgn message

```
message Pgn
{
	repeated ReceiveBroadcastPgn receive_broadcast_pgns = 1;
	repeated ReceiveOnRequestPgn receive_on_request_pgns = 2;
}
```
Top level message to contain groupings of different request/response types for pgns

### Rules
| field | rule |
|---|---|
| receive_broadcast_pgns | must be sorted ascending by pgn |
| receive_broadcast_pgns | must not have any duplicated pgn values |
| receive_on_request_pgns | must be sorted ascending by pgn |
| receive_on_request_pgns | must not have any duplicated pgn values |

***

## ReceiveBroadcastPgn message

```
message ReceiveBroadcastPgn
{
	message Spn
	{
		uint32 spn = 1;
		string middleware_id = 2;
	}

	uint32 pgn = 1;
	uint32 timeout = 2; // milliseconds
	repeated Spn spns = 3;
	string middleware_id = 4;
}
```
Defines list of pgns that are broadcast by the containing PeerNode

### Spn Rules
| field | rule |
|---|---|
| spn | must be in the range 0 - 524287 inclusive |
| middleware_id | must be unique compared to all other middleware id values passed to data link engine |
| middleware_id | could be a publish or subscribe id depending on whether the Spn is tied to a receive or transmit pgn |

### ReceiveBroadcastPgn Rules
| field | rule |
|---|---|
| pgn | must be 0x00F000 through 0x00FFFF or 0x01F000 through 0x01FFFF inclusive |
| timeout | is usually a multiplier of the broadcast rate, for fast pgn broadcasts this timeout might need to be extended |
| spns | must be sorted ascending by spn |
| spns | must not have any duplicate spn values between entries |
| middleware_id | should be unique compared to all other middleware id values passed to data link engine |
| middleware_id | must be a publish id that data link engine will use to publish pgn byte data to middleware |

***

## ReceiveOnRequestPgn message

```
message ReceiveOnRequestPgn
{
	message Spn
	{
		uint32 spn = 1;
		string middleware_id = 2;
	}

	uint32 pgn = 1;
	repeated Spn spns = 2;
	string middleware_id = 3;
}
```
Defines list of pgns that are received by request from the containing PeerNode

### Spn Rules
| field | rule |
|---|---|
| spn | must be in the range 0 - 524287 inclusive |
| middleware_id | must be unique compared to all other middleware id values passed to data link engine |
| middleware_id | could be a publish or subscribe id depending on whether the Spn is tied to a receive or transmit pgn |

### ReceiveOnRequestPgn Rules
| field | rule |
|---|---|
| pgn | must be 0x00F000 through 0x00FFFF or 0x01F000 through 0x01FFFF inclusive |
| spns | must be sorted ascending by spn |
| spns | must not have any duplicate spn values between entries |
| middleware_id | should be unique compared to all other middleware id values passed to data link engine |
| middleware_id | must be a publish id that data link engine will use to publish pgn byte data to middleware |

***

## BasicReadWrite message

```
message BasicReadWrite
{
	repeated BasicReadWritePid basic_read_write_pids = 1;
}
```
Defines the configuration for J1939 basic read and write

### Rules
| field | rule |
|---|---|
| basic_read_write_pids | must be sorted ascending by pid |
| basic_read_write_pids | must not have duplicate pid values |

***

## BasicReadWritePid message

```
message BasicReadWritePid
{
	uint32 pid = 1;
	string middleware_id = 2;
}
```
Defines a pid that supports J1939 basic read and write

### Rules
| field | rule |
|---|---|
| pid | must be a valid pid |
| middleware_id | should be unique compared to all other middleware id values passed to data link engine |
| middleware_id | must be a read/write id that will trigger J1939 basic read/write of the pid |

***

## Bdt message

```
message Bdt
{
	repeated BdtType bdt_types = 1;
}
```
Contains the list of bdt types that this peer node can read or write

### Rules
| field | rule |
|---|---|
| types | type and index together should be unique within one peer node |

***

## BdtType message

```
enum AccessMode
{
	ACCESS_MODE_UNSPECIFIED = 0;
	ACCESS_MODE_READ_ONLY = 1;
	ACCESS_MODE_WRITE_ONLY = 2;
	ACCESS_MODE_READ_WRITE = 3;
}
message BdtType
{
	uint32 type = 1;
	Index index = 2;
	AccessMode access_mode = 3;
	string middleware_id = 4;
}
```
Contains bdt data type, index, r/w access support and the middleware id used to read or write

### Rules
| field | rule |
|---|---|
| type | must be a valid 2-byte bdt type |
| type | must have a matching BdtEntry that matches the type value |
| index | must be a valid 4-byte index that is valid for the bdt type |
| access_mode | must be set to one of the enum values besides ACCESS_MODE_UNSPECIFIED |
| middleware_id | must be unique compared to all other middleware id values passed to data link engine |
| middleware_id | must be a read/write id that will trigger read/write of the bdt file |

***

## CalibrationServices message

```
message CalibrationServices
{
	repeated CalibrationServiceData calibrations = 1;
	repeated CalibrationServiceData service_tests = 2;
}
```
Contains the lists of calibrations and service tests available from this node

### Rules
| field | rule |
|---|---|
| calibrations | sorted by index in ascending order |
| calibrations | no entries duplicated on the index value |
| service_tests | sorted by index in ascending order |
| calibrations | no entries duplicated on the index value |

***

## CalibrationServiceData message

```
message CalibrationServiceData
{
	uint32 index = 1;
	string middleware_id = 2;
}
```
Contains the calibration or service test id along with the controlling middleware_id

### Rules
| field | rule |
|---|---|
| index | must be a valid 2-byte calibration or service test id |
| middleware_id | must be unique compared to all other middleware id values passed to data link engine |

***

## ExtensionId message

```
message ExtensionId
{
	repeated ExtensionIdRead extension_id_reads = 1;
}
```
Top level message to contain allowed extension id data protocols

### Rules
| field | rule |
|---|---|
| extension_id_reads | sorted by extension_id in ascending order |
| extension_id_reads | at this time, only 0xF019 and 0xF01A are allowed |

***

## ExtensionIdRead message

```
message ExtensionIdRead
{
	uint32 extension_id = 1;
	string middleware_id = 2;
}
```
Contains the details of the extension id read

### Rules
| field | rule |
|---|---|
| extension_id | at this time, only 0xF019 and 0xF01A are allowed |
| extension_id | duplicates are not allowed |
| middleware_id | must be unique compared to all other middleware id values passed to data link engine |

***

## PidEntry message

```
enum DataPresentationType
{
	DATA_PRESENTATION_TYPE_UNSPECIFIED = 0;
	DATA_PRESENTATION_TYPE_DOUBLE = 1;
	DATA_PRESENTATION_TYPE_UNSIGNED = 2;
	DATA_PRESENTATION_TYPE_BINARY = 3;
}
message PidEntry
{
	uint32 pid = 1;
	uint32 byte_count = 2;
	bool is_signed = 3;
	bool is_dsi_supported = 4;
	double scaling = 5;
	Unit unit = 6;
	bool is_lsb = 7;
	DataPresentationType data_presentation_type= 8;
}
```
Defines pid characteristics and how to convert data link byte data into specified unit data of DataPresentationType

### Rules
| field | rule |
|---|---|
| pid | must be in valid pid ranges ranges |
| byte_count | must be the data byte count for the pid |
| unit | must be one of the values in the Unit enum from middleware |
| data_presentation_type | must not be DATA_PRESENTATION_TYPE_UNSPECIFIED |
| data_presentation_type | if DATA_PRESENTATION_TYPE_BINARY, all other fields will be ignored and that value as it appears on the data link will be passed through middleware |

***

## PgnEntry message

```
message PgnEntry
{
	uint32 pgn = 1;
	repeated OffsetSpn offset_spns = 2;
}
```
Defines a pgn and a bit mapping of the location of spns within the pgn data body

### Rules
| field | rule |
|---|---|
| pgn | must be 0x00F000 through 0x00FFFF or 0x01F000 through 0x01FFFF inclusive |
| offset_spns | must be sorted ascending by bit_offset |
| offset_spns | must not contain duplicate spn values |

***

## OffsetSpn message

```
message OffsetSpn
{
	uint32 spn = 1;
	uint32 bit_offset = 2;
}
```
Defines the bit location of an spn within a parent PgnEntry

### Rules
| field | rule |
|---|---|
| spn | must be in the range 0 - 524287 inclusive |
| spn | must match one entry in the base Config spn_entries by spn value |
| bit_offset | must be in the range 0 - 63 inclusive |
| bit_offset | bit_offset + bit_count of matching SpnEntry must be less than or equal to 64 |
| bit_offset | bit_offset + bit_count must not overlap the range of another bit_offset + bit_count |

***

## SpnEntry message

```
enum DataPresentationType
{
	DATA_PRESENTATION_TYPE_UNSPECIFIED = 0;
	DATA_PRESENTATION_TYPE_DOUBLE = 1;
	DATA_PRESENTATION_TYPE_UNSIGNED = 2;
	DATA_PRESENTATION_TYPE_BINARY = 3;
}
message SpnEntry
{
	uint32 spn = 1;
	uint32 bit_count = 2;
	double scaling = 3;
	double offset = 4;
	Unit unit = 5;
	DataPresentationType data_presentation_type = 6;
}
```
Defines spn characteristics and how to convert data link byte data into specified unit data of DataPresentationType
When processing to a value, the scaling multiplier is applied first and then the offset is added

### Rules
| field | rule |
|---|---|
| spn | must be in the range 0 - 524287 inclusive |
| bit_count | must be in the range 1 - 64 inclusive |
| unit | must be one of the values in the Unit enum from middleware |
| data_presentation_type | must not be DATA_PRESENTATION_TYPE_UNSPECIFIED |
| data_presentation_type | must be DATA_PRESENTATION_TYPE_DOUBLE or DATA_PRESENTATION_TYPE_UNSIGNED at this time |

***

## DeviceId message

```
message DeviceId
{
	uint32 module_id = 1;
	uint32 service_tool_support_level = 2;
	uint32 application_id = 3;
	uint32 minimum_service_tool_support_level = 4;
	optional uint32 fid = 5;
}
```
Optional message to define the response for extension id 0xF016

### Rules
| field | rule |
|---|---|
| module_id | must be in the range 0x0000 through 0xFFFF inclusive |
| service_tool_support_level | must be in the range 0x0000 through 0xFFFF inclusive |
| application_id | must be in the range 0x0000 through 0xFFFF inclusive |
| minimum_service_tool_support_level | must be in the range 0x0000 through 0xFFFF inclusive |
| fid | if not set, the response to extension id 0xF016 will not include fid and be set to version 1 of the message |
| fid | if set, the response to extension id 0xF016 will include fid and be set to version 2 of the message |

***

## MachineSecuritySystem message

```
message MachineSecuritySystem
{
	CanPort can_port = 1;
	uint32 address = 2;
}
```
Optional message to define the j1939 location of the security system module

### Rules
| field | rule |
|---|---|
| can_port | can specify any defined CanPort enum value from CAN_PORT_0 through CAN_PORT_5 |
| can_port | specified port must be defined in a J1939DataLink  |
| address | must be in the range 0x00 through 0xFB inclusive |
| address | must match the address of a PeerNode that is under a J1939DataLink with the same can_port |

***

## Diagnostics message

```
message Diagnostics
{
	repeated DiagnosticClientCanPort diagnostic_client_can_ports = 1;
	optional InternalCodeList internal_code_list = 2;
}
```
Optional message to define the diagnostics to request from the system and the diagnostics that will be owned by the data link engine.  Each DiagnosticClientCanPort defines a set of J1939 nodes on a can port to retrieve diagnostics.  InternalCodeList is limited to only one can port that will provide internal codes.

### Rules
| field | rule |
|---|---|
| diagnostic_client_can_ports | can have up to 6 entries, one for each can port possible |
| internal_code_list | limited to one can port |

***

## DiagnosticClientCanPort message

```
message DiagnosticClientCanPort
{
	J1939DataLink.CanPort can_port = 1;
	repeated PeerNode peer_nodes = 2;
}
```
Defines list of nodes that will provide diagnostics on the given can port

### Rules
| field | rule |
|---|---|
| can_port | must be in the set of possible can ports |
| peer_nodes | list of peers and what type of diagnostics to request |

***

## PeerNode message

```
enum DiagnosticType
{
	DIAGNOSTIC_UNSPECIFIED = 0;
	DIAGNOSTIC_TYPE_EDDT = 1;
	DIAGNOSTIC_TYPE_PUBLIC = 2;
}
message PeerNode
{
	uint32 address = 1;
	DiagnosticType diagnostic_type = 2;
}
```
PeerNode message defines a J1939 source address and the type of diagnostics to request from that address

### Rules
| field | rule |
|---|---|
| address | must be in the range 0x00 through 0xFB inclusive |
| address | must match the address of a PeerNode that is under a J1939DataLink with the same can_port |
| diagnostic_type | must be DIAGNOSTIC_TYPE_EDDT or DIAGNOSTIC_TYPE_PUBLIC |

***

### InternalCodeList message

```
J1939DataLink.CanPort service_can_port = 1;
repeated InternalCode internal_codes = 2;
```
Definition of the single can port used to provide internal diagnostics and the list of defined diagnostics

### Rules
| field | rule |
|---|---|
| service_can_port | must be in the set of possible can ports |

***

## InternalCode message

```
enum CodeType
{
	CODE_TYPE_UNSPECIFIED = 0;
	CODE_TYPE_DIAGNOSTIC = 1;
	CODE_TYPE_EVENT = 2;
}
enum StorageType
{
	STORAGE_TYPE_UNSPECIFIED = 0;
	STORAGE_TYPE_ACTIVE_ONLY = 1;
	STORAGE_TYPE_LOGGED_AND_ACTIVE = 2;
}
message InternalCode
{
	CodeType code_type = 1;
	StorageType storage_type = 2;
	uint32 code = 3;
	uint32 failure_mode_identifier = 4;
	uint32 warning_category_indicator = 5;
	uint32 annunciation_requirement = 6;
	string description = 7;
	uint32 security_level = 8;
	uint32 start_up_delay = 9;
	uint32 activation_delay = 10;
	uint32 deactivation_delay = 11;
	string middleware_id = 12;
}
```
InternalCode message defines all the characteristics of a code that is hosted by the data link engine

1. code_type determines if this is a diagnostic or event
1. storage_type determines if we only need to track active status or if this code should be registered with the logging system and logged statistics are collected
1. code is the component identifier for diagnostics or event identifier for events
1. failure_mode_identifier is the failure mode identifier (fmi) for this code (only used for diagnostics)
1. warning_category_indicator is the warning category indicator (wci) for this code
1. annunciation_requirement is the annunciation requirement for this code
1. description is the internal code description, can be retrieved through additional information group 1
1. security_level is the required clear access for this code
1. start_up_delay is the delay in seconds after data link engine is launched to start evaluating the activation condition
1. activation_delay is the delay in seconds after the activation condition goes to true to actually activate the code
1. deactivation_delay is the delay in seconds after the activation condition goes to false to actually deactivate the code
1. middleware_id is the activation condition subscribed to from middleware that provdides the boolean status of the code

### Rules
| field | rule |
|---|---|
| code_type | must be CODE_TYPE_DIAGNOSTIC or CODE_TYPE_EVENT |
| can_port | must be STORAGE_TYPE_ACTIVE_ONLY or STORAGE_TYPE_LOGGED_AND_ACTIVE |
| code | must be in the range 1 through 65535 inclusive |
| failure_mode_identifier | must be in the range 0 through 31 inclusive |
| warning_category_indicator | must be in the range 1 through 3 inclusive |
| annunciation_requirement | must be in the range 0 through 15 inclusive |
| description | must be a printable ascii string with a max of 21 characters |
| security_level | must be in the range 0 through 3 inclusive |
| start_up_delay | must be positive |
| activation_delay | must be positive |
| deactivation_delay | must be positive |
| middleware_id | should be unique compared to all other middleware id values passed to data link engine |

***

## MultiBytePidEntry message

```
message MultiBytePidEntry
{
	enum MultiBytePidDataType
	{
		MULTI_BYTE_PID_DATA_TYPE_UNSPECIFIED = 0;
		MULTI_BYTE_PID_DATA_TYPE_BINARY = 1;
		MULTI_BYTE_PID_DATA_TYPE_STRING = 2;
	}

	uint32 pid = 1;
	uint32 minimum_length = 2; // length does not include the prefix byte that indicates the length of the data
	uint32 maximum_length = 3; // length does not include the prefix byte that indicates the length of the data
	MultiBytePidDataType multi_byte_pid_data_type = 4;
}
```
Defines pid characteristics and how to convert data link byte data into specified unit data of DataPresentationType

### Rules
| field | rule |
|---|---|
| pid | must be in valid multi-byte pid ranges (0x80 through 0xC7) and (0xF800 through 0xFBFF)|
| minimum_length | minimum number of bytes that can be stored by the pid not including a prefix length byte |
| minimum_length | length must be >= minimum_length |
| maximum_length | maximum number of bytes that can be stored by the pid not including a prefix length byte |
| maximum_length | length must be <= maximum_length |
| multi_byte_pid_data_type | must not be MULTI_BYTE_PID_DATA_TYPE_UNSPECIFIED |
| multi_byte_pid_data_type | this will control how the data is represented when interacting with middleware |

***

## BdtEntry message

```
message BdtEntry
{
	uint32 type = 1;
	uint32 maximum_byte_count = 2;
}
```
Defines the bdt types that can be used and the maximum byte count for each

### Rules
| field | rule |
|---|---|
| type | must be a valid 2-byte bdt type |
| maximum_byte_count | set to the maximum expected size of the bdt file in bytes |

***

## EthernetDataLink message

```
message EthernetDataLink
{
	uint32 fid = 1;
	string ip_address = 2;
	repeated PeerNode peer_nodes = 3;
}
```
Defines the fid and ip address that the data link engine will use for identification

### Rules
| field | rule |
|---|---|
| fid | must be in the format 0xAAAABBCC where AAAA can't be FFF0-FFFE, BB and CC can't be FF |
| fid | must be different than all defined ethernet peers |
| ip_address | must be of the format 165.26.79.xxx where xxx is 0-255 |
| ip_address | must be different that all defined ethernet peers |

***

## PeerNode message

```
message PeerNode
{
	uint32 fid = 1;
	string ip_address = 2;
	optional Pgt pgt = 3;
}
```
Defines the fid and ip address of the other ethernet nodes on the network

### Rules
| field | rule |
|---|---|
| fid | must be in the format 0xAAAABBCC where AAAA can't be FFF0-FFFE, BB and CC can't be FF |
| fid | must be different than all defined ethernet peers |
| ip_address | must be of the format 165.26.79.xxx where xxx is 0-255 |
| ip_address | must be different that all defined ethernet peers |

***

## Pgt message

```
message Pgt
{
	repeated PgtPid pgt_pids = 1;
}
```
Defines the pgt parameters that will be requested

### Rules
| field | rule |
|---|---|
| pgt_pids | must be sorted by request_rate ascending and then pid ascending |

***

## PgtPid message

```
message PgtPid
{
	uint32 pid = 1;
	J1939DataLink.PeerNode.Pgb.RequestRate request_rate = 2;
	string middleware_id = 3;
}
```
Defines the pids that will be requested over pgt

### Rules
| field | rule |
|---|---|
| pid | at this time, must be a valid 1, 2 or 4-byte pid |
| pid | must not duplicate pid values for the same node |
| request_rate | must be set to one of the preset enumeration values |
| middleware_id | must be unique across all other middleware ids |

***
