/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See ConfigFactory.h

#include "Interface/Config/ConfigFactory.h"
#include "Interface/Config/IConfigDescriber.h"
#include "Interface/Config/PgnIdentifierConfig.h"
#include "Interface/Config/PidIdentifierConfig.h"
#include "Interface/Config/ProtobufConversions.h"
#include "Interface/Config/SharkConfig.h"
#include "Interface/Config/SpnIdentifierConfig.h"
#include <SharkConfiguration.pb.h>

using namespace cat::shark;

namespace Config
{
namespace
{
void PopulateIdentity(J1939DataLink& j1939DataLink, IdentityEntry const& identityEntry)
{
	auto& identity = *j1939DataLink.mutable_identity();
	identity.mutable_valid_addresses()->Add(identityEntry.validAddresses.begin(), identityEntry.validAddresses.end());
	identity.set_ecu_instance(identityEntry.ecuInstance);
	identity.set_function_instance(identityEntry.functionInstance);
	identity.set_industry_group(identityEntry.industryGroup);
	identity.set_vehicle_system(identityEntry.vehicleSystem);
	identity.set_vehicle_system_instance(identityEntry.vehicleSystemInstance);
	identity.set_function(identityEntry.function);
	identity.set_manufacturer_code(identityEntry.manufacturerCode);
}
void PopulateJ1939DeviceId(cat::shark::Config& config, DeviceIdEntry const& deviceIdEntry)
{
	auto& deviceId = *config.mutable_j1939_device_id();
	deviceId.set_module_id(deviceIdEntry.moduleId);
	deviceId.set_service_tool_support_level(deviceIdEntry.serviceToolSupportLevel);
	deviceId.set_application_id(deviceIdEntry.applicationId);
	deviceId.set_minimum_service_tool_support_level(deviceIdEntry.minimumServiceToolSupportLevel);
	if (deviceIdEntry.fid)
	{
		deviceId.set_fid(deviceIdEntry.fid.value());
	}
}
void PopulateMachineSecuritySystem(cat::shark::Config& config, MachineSecuritySystemEntry const& machineSecuritySystemEntry)
{
	auto& machineSecuritySystem = *config.mutable_machine_security_system();
	machineSecuritySystem.set_can_port(ToProtobufCanPort(machineSecuritySystemEntry.canPort));
	machineSecuritySystem.set_address(machineSecuritySystemEntry.address);
}
void PopulateDiagnostics(cat::shark::Config& config, DiagnosticsEntry const& diagnosticsEntry)
{
	auto& diagnostics = *config.mutable_diagnostics();
	for (auto const& diagnosticClientCanPort : diagnosticsEntry.diagnosticClientCanPorts)
	{
		auto& diagnosticClient = *diagnostics.add_diagnostic_client_can_ports();
		diagnosticClient.set_can_port(ToProtobufCanPort(diagnosticClientCanPort.canPort));
		for (auto const& diagnosticPeerEntry : diagnosticClientCanPort.diagnosticPeerEntries)
		{
			auto& diagnosticPeer = *diagnosticClient.add_peer_nodes();
			diagnosticPeer.set_address(diagnosticPeerEntry.address);
			diagnosticPeer.set_diagnostic_type(static_cast<Diagnostics_DiagnosticType>(diagnosticPeerEntry.diagnosticType));
		}
	}
	auto& internalCodeList = *diagnostics.mutable_internal_code_list();
	internalCodeList.set_service_can_port(ToProtobufCanPort(diagnosticsEntry.internalCodeList.canPort));
	for (auto const& internalCodeEntry : diagnosticsEntry.internalCodeList.internalCodeEntries)
	{
		auto& internalCode = *internalCodeList.add_internal_codes();
		internalCode.set_code_type(static_cast<Diagnostics_InternalCodeList_CodeType>(internalCodeEntry.codeType));
		internalCode.set_storage_type(static_cast<Diagnostics_InternalCodeList_StorageType>(internalCodeEntry.storageType));
		internalCode.set_code(internalCodeEntry.code);
		internalCode.set_failure_mode_identifier(internalCodeEntry.failureModeIdentifier);
		internalCode.set_warning_category_indicator(internalCodeEntry.warningCategoryIndicator);
		internalCode.set_annunciation_requirement(internalCodeEntry.annunciationRequirement);
		internalCode.set_description(internalCodeEntry.pDescription);
		internalCode.set_security_level(internalCodeEntry.securityLevel);
		internalCode.set_start_up_delay(internalCodeEntry.startUpDelay);
		internalCode.set_activation_delay(internalCodeEntry.activationDelay);
		internalCode.set_deactivation_delay(internalCodeEntry.deactivationDelay);
		internalCode.set_middleware_id(internalCodeEntry.pMiddlewareId);
	}
}
void PopulateBdtConfig(cat::shark::Config& config, BdtConfig const& bdtConfig)
{
	auto& bdtEntries = *config.mutable_bdt_entries();
	for (auto const& bdtTypeEntry : bdtConfig.bdtDefinitionEntries)
	{
		auto& bdtTypeDefinition = *bdtEntries.Add();
		bdtTypeDefinition.set_type(bdtTypeEntry.type);
		bdtTypeDefinition.set_maximum_byte_count(bdtTypeEntry.maximumByteCount);
	}
}
void PopulateEthernetDataLink(cat::shark::Config& config, EthernetDataLinkEntry const& ethernetDataLinkEntry)
{
	auto& ethernetDataLinkConfig = *config.mutable_ethernet_data_link();
	ethernetDataLinkConfig.set_fid(ethernetDataLinkEntry.fid);
	ethernetDataLinkConfig.set_ip_address(ethernetDataLinkEntry.pIpAddress);
	for (auto const& ethernetPeerNodeEntry : ethernetDataLinkEntry.ethernetPeerNodeEntries)
	{
		auto& peerNode = *ethernetDataLinkConfig.add_peer_nodes();
		peerNode.set_fid(ethernetPeerNodeEntry.fid);
		peerNode.set_ip_address(ethernetPeerNodeEntry.pIpAddress);

		auto& pgt = *peerNode.mutable_pgt();
		for (auto const& pgtPidEntry : ethernetPeerNodeEntry.pgtEntry.pgtPidEntries)
		{
			auto& pgtPid = *pgt.add_pgt_pids();
			pgtPid.set_pid(pgtPidEntry.pid);
			pgtPid.set_request_rate(static_cast<J1939DataLink::PeerNode::Pgb::RequestRate>(pgtPidEntry.requestRate));
			pgtPid.set_middleware_id(pgtPidEntry.pMiddlewareId);
		}
	}
}
void PopulatePeerAdt(J1939DataLink::PeerNode& peerNode, AdtEntry const& adtEntry)
{
	auto& adt = *peerNode.mutable_adt();
	if (adtEntry.timeout)
	{
		adt.set_timeout(adtEntry.timeout.value());
	}
	for (auto const& adtPidEntry : adtEntry.adtPidEntries)
	{
		auto& adtPid = *adt.add_adt_pids();
		adtPid.set_pid(adtPidEntry.pid);
		adtPid.set_middleware_id(adtPidEntry.pMiddlewareId);
	}
}
void PopulatePeerPgb(J1939DataLink::PeerNode& peerNode, PgbEntry const& pgbEntry)
{
	auto& pgb = *peerNode.mutable_pgb();
	for (auto const& pgbPidEntry : pgbEntry.pgbPidEntries)
	{
		auto& pgbPid = *pgb.add_pgb_pids();
		pgbPid.set_pid(pgbPidEntry.pid);
		pgbPid.set_request_rate(static_cast<J1939DataLink::PeerNode::Pgb::RequestRate>(pgbPidEntry.requestRate));
		auto priority = pgbPidEntry.isHighPriority ?
			J1939DataLink::PeerNode::Pgb::PRIORITY_HIGH :
			J1939DataLink::PeerNode::Pgb::PRIORITY_LOW;
		pgbPid.set_priority(priority);
		pgbPid.set_middleware_id(pgbPidEntry.pMiddlewareId);
	}
}
template<typename BroadcastPgnType>
void PopulateInternalSpn(BroadcastPgnType& broadcastPgn, InternalSpnEntry const& internalSpnEntry)
{
	auto& spn = *broadcastPgn.add_spns();
	spn.set_spn(internalSpnEntry.spn);
	spn.set_middleware_id(internalSpnEntry.pMiddlewareId);
}
void PopulateReceiveBroadcastPgn(J1939DataLink::PeerNode::Pgn& pgn, ReceiveBroadcastPgnEntry const& receiveBroadcastPgnEntry)
{
	auto& receiveBroadcastPgn = *pgn.add_receive_broadcast_pgns();
	receiveBroadcastPgn.set_pgn(receiveBroadcastPgnEntry.pgn);
	receiveBroadcastPgn.set_timeout(receiveBroadcastPgnEntry.timeout);
	receiveBroadcastPgn.set_middleware_id(receiveBroadcastPgnEntry.pMiddlewareId);
	for (auto const& internalSpnEntry : receiveBroadcastPgnEntry.internalSpnEntries)
	{
		PopulateInternalSpn(receiveBroadcastPgn, internalSpnEntry);
	}
}
void PopulateReceiveOnRequestPgn(J1939DataLink::PeerNode::Pgn& pgn, ReceiveOnRequestPgnEntry const& receiveOnRequestPgnEntry)
{
	auto& receiveOnRequestPgn = *pgn.add_receive_on_request_pgns();
	receiveOnRequestPgn.set_pgn(receiveOnRequestPgnEntry.pgn);
	receiveOnRequestPgn.set_middleware_id(receiveOnRequestPgnEntry.pMiddlewareId);
	for (auto const& internalSpnEntry : receiveOnRequestPgnEntry.internalSpnEntries)
	{
		PopulateInternalSpn(receiveOnRequestPgn, internalSpnEntry);
	}
}
void PopulatePeerPgn(J1939DataLink::PeerNode& peerNode, PgnEntry const& pgnEntry)
{
	auto& pgn = *peerNode.mutable_pgn();
	for (auto const& receiveBroadcastPgnEntry : pgnEntry.receiveBroadcastPgnEntries)
	{
		PopulateReceiveBroadcastPgn(pgn, receiveBroadcastPgnEntry);
	}
	for (auto const& receiveOnRequestPgnEntry : pgnEntry.receiveOnRequestPgnEntries)
	{
		PopulateReceiveOnRequestPgn(pgn, receiveOnRequestPgnEntry);
	}
}
void PopulatePeerBasicReadWrite(J1939DataLink::PeerNode& peerNode, BasicReadWriteEntry const& basicReadWriteEntry)
{
	auto& basicReadWrite = *peerNode.mutable_basic_read_write();
	for (auto const& basicReadWritePidEntry : basicReadWriteEntry.basicReadWritePidEntries)
	{
		auto& pid = *basicReadWrite.add_basic_read_write_pids();
		pid.set_pid(basicReadWritePidEntry.pid);
		pid.set_middleware_id(basicReadWritePidEntry.pMiddlewareId);
	}
}
void PopulatePeerBdt(J1939DataLink::PeerNode& peerNode, BdtEntry const& bdtEntry)
{
	auto& bdt = *peerNode.mutable_bdt();
	for (auto const& typeEntry : bdtEntry.bdtTypeEntries)
	{
		auto& bdtType = *bdt.add_bdt_types();
		bdtType.set_type(typeEntry.type);
		bdtType.set_index(typeEntry.index);
		bdtType.set_access_mode(static_cast<J1939DataLink::PeerNode::Bdt::AccessMode>(typeEntry.accessMode));
		bdtType.set_middleware_id(typeEntry.pMiddlewareId);
	}
}
void PopulatePeerCalibrationServices(J1939DataLink::PeerNode& peerNode, CalibrationServicesEntry const& calibrationServicesEntry)
{
	auto& calibrationServices = *peerNode.mutable_calibration_services();
	for (auto const& calibrationEntry : calibrationServicesEntry.calibrations)
	{
		auto& calibration = *calibrationServices.add_calibrations();
		calibration.set_index(calibrationEntry.index);
		calibration.set_middleware_id(calibrationEntry.pMiddlewareId);
	}
	for (auto const& serviceTestEntry : calibrationServicesEntry.serviceTests)
	{
		auto& serviceTest = *calibrationServices.add_service_tests();
		serviceTest.set_index(serviceTestEntry.index);
		serviceTest.set_middleware_id(serviceTestEntry.pMiddlewareId);
	}
}
void PopulatePeerExtensionId(J1939DataLink::PeerNode& peerNode, ExtensionIdEntry const& extensionIdEntry)
{
	auto& extensionId = *peerNode.mutable_extension_id();
	for (auto const& extensionIdReadEntry : extensionIdEntry.extensionIdReads)
	{
		auto& extensionIdRead = *extensionId.add_extension_id_reads();
		extensionIdRead.set_extension_id(extensionIdReadEntry.extensionId);
		extensionIdRead.set_middleware_id(extensionIdReadEntry.pMiddlewareId);
	}
}
void PopulatePeerNode(J1939DataLink& j1939DataLink, PeerNodeEntry const& peerNodeEntry)
{
	auto& peerNode = *j1939DataLink.add_peer_nodes();
	peerNode.set_address(peerNodeEntry.address);

	PopulatePeerAdt(peerNode, peerNodeEntry.adtEntry);
	PopulatePeerPgb(peerNode, peerNodeEntry.pgbEntry);
	PopulatePeerPgn(peerNode, peerNodeEntry.pgnEntry);
	PopulatePeerBasicReadWrite(peerNode, peerNodeEntry.basicReadWriteEntry);
	PopulatePeerBdt(peerNode, peerNodeEntry.bdtEntry);
	PopulatePeerCalibrationServices(peerNode, peerNodeEntry.calibrationServicesEntry);
	PopulatePeerExtensionId(peerNode, peerNodeEntry.extensionIdEntry);
}
void PopulateTransmitBroadcastPgn(J1939DataLink& j1939DataLink, TransmitBroadcastPgnEntry const& transmitBroadcastPgnEntry)
{
	auto& transmitBroadcastPgn = *j1939DataLink.add_transmit_broadcast_pgns();
	transmitBroadcastPgn.set_pgn(transmitBroadcastPgnEntry.pgn);
	transmitBroadcastPgn.set_broadcast_rate(static_cast<J1939DataLink_TransmitBroadcastPgn_BroadcastRate>(transmitBroadcastPgnEntry.broadcastRate));
	transmitBroadcastPgn.set_middleware_id(transmitBroadcastPgnEntry.pMiddlewareId);
	for (auto const& internalSpnEntry : transmitBroadcastPgnEntry.internalSpnEntries)
	{
		PopulateInternalSpn(transmitBroadcastPgn, internalSpnEntry);
	}
}
void PopulateSharkConfig(cat::shark::Config& config, SharkConfig const& sharkConfig)
{
	assert(sharkConfig.j1939LinkEntries.size() > 0);
	for (auto j1939LinkEntry : sharkConfig.j1939LinkEntries)
	{
		auto& j1939DataLink = *config.add_j1939_data_links();
		j1939DataLink.set_can_port(ToProtobufCanPort(j1939LinkEntry.canPort));

		PopulateIdentity(j1939DataLink, j1939LinkEntry.identityEntry);

		for (auto const& peerNodeEntry : j1939LinkEntry.peerNodeEntries)
		{
			PopulatePeerNode(j1939DataLink, peerNodeEntry);
		}

		for (auto const& transmitBroadcastPgnEntry : j1939LinkEntry.transmitBroadcastPgnEntries)
		{
			PopulateTransmitBroadcastPgn(j1939DataLink, transmitBroadcastPgnEntry);
		}
	}

	if (sharkConfig.j1939DeviceIdEntry)
	{
		PopulateJ1939DeviceId(config, sharkConfig.j1939DeviceIdEntry.value());
	}

	if (sharkConfig.machineSecuritySystemEntry)
	{
		PopulateMachineSecuritySystem(config, sharkConfig.machineSecuritySystemEntry.value());
	}

	if (sharkConfig.diagnosticsEntry)
	{
		PopulateDiagnostics(config, sharkConfig.diagnosticsEntry.value());
	}

	if (sharkConfig.bdtConfig)
	{
		PopulateBdtConfig(config, sharkConfig.bdtConfig.value());
	}

	if (sharkConfig.ethernetDataLinkEntry)
	{
		PopulateEthernetDataLink(config, sharkConfig.ethernetDataLinkEntry.value());
	}
}
void PopulatePidConfig(cat::shark::Config& config, PidIdentifierConfig const& pidConfig)
{
	for (auto const& pidEntry : pidConfig.entries)
	{
		auto& pid = *config.add_pid_entries();
		pid.set_pid(pidEntry.pid);
		pid.set_byte_count(pidEntry.byteCount);
		pid.set_is_signed(pidEntry.dataType == Signed);
		pid.set_is_lsb(pidEntry.byteOrder == LsbFirst);
		pid.set_is_dsi_supported(pidEntry.faultCapability == DSI);
		pid.set_scaling(pidEntry.scaling);
		pid.set_unit(pidEntry.unit);
		pid.set_data_presentation_type(pidEntry.presentationType);
	}
}
void PopulatePgnConfig(cat::shark::Config& config, PgnIdentifierConfig const& pgnConfig)
{
	for (auto const& pgnEntry : pgnConfig.entries)
	{
		auto& pgn = *config.add_pgn_entries();
		pgn.set_pgn(pgnEntry.pgn);
		for (auto const& offsetSpnEntry : pgnEntry.spns)
		{
			auto& spn = *pgn.add_offset_spns();
			spn.set_spn(offsetSpnEntry.spn);
			spn.set_bit_offset(offsetSpnEntry.bitOffset);
		}
	}
}
void PopulateSpnConfig(cat::shark::Config& config, SpnIdentifierConfig const& spnConfig)
{
	for (auto const& spnEntry : spnConfig.entries)
	{
		auto& spn = *config.add_spn_entries();
		spn.set_spn(spnEntry.spn);
		spn.set_bit_count(spnEntry.bitCount);
		spn.set_scaling(spnEntry.scaling);
		spn.set_offset(spnEntry.offset);
		spn.set_unit(spnEntry.unit);
		spn.set_data_presentation_type(spnEntry.presentationType);
	}
}
void PopulateMultiBytePidConfig(cat::shark::Config& config, MultiBytePidIdentifierConfig const& pidConfig)
{
	for (auto const& pidEntry : pidConfig.entries)
	{
		auto& pid = *config.add_multi_byte_pid_entries();
		pid.set_pid(pidEntry.pid);
		pid.set_minimum_length(pidEntry.minimumLength);
		pid.set_maximum_length(pidEntry.maximumLength);
		pid.set_multi_byte_pid_data_type(static_cast<cat::shark::MultiBytePidEntry::MultiBytePidDataType>(pidEntry.dataType));
	}
}
}

cat::shark::Config const ConfigFactory::CreateConfig(IConfigDescriber const& configDescriber)
{
	cat::shark::Config config{};
	auto spSharkConfig = configDescriber.GetSharkConfig();
	if (spSharkConfig)
	{
		PopulateSharkConfig(config, *spSharkConfig);
	}
	auto spPidConfig = configDescriber.GetPidConfig();
	if (spPidConfig)
	{
		PopulatePidConfig(config, *spPidConfig);
	}
	auto spPgnConfig = configDescriber.GetPgnConfig();
	if (spPgnConfig)
	{
		PopulatePgnConfig(config, *spPgnConfig);
	}
	auto spSpnConfig = configDescriber.GetSpnConfig();
	if (spSpnConfig)
	{
		PopulateSpnConfig(config, *spSpnConfig);
	}
	auto spMultiBytePidConfig = configDescriber.GetMultiBytePidConfig();
	if (spMultiBytePidConfig)
	{
		PopulateMultiBytePidConfig(config, *spMultiBytePidConfig);
	}
	return config;
}
}
