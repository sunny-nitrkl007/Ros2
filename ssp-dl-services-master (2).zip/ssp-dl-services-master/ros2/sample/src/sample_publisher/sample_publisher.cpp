/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Minimal ROS2 Jaws node — creates a node and periodically publishes a Parameter message.

#include "data_link_engine_interfaces/msg/parameter.hpp"
#include <chrono>
#include <memory>
#include <rclcpp/rclcpp.hpp>

class JawsNode : public rclcpp::Node
{
public:
	JawsNode()
		: Node("jaws")
		, m_spPublisher(create_publisher<data_link_engine_interfaces::msg::Parameter>(
			"data_link/parameter",
			10))
		, m_spTimer(create_wall_timer(
			std::chrono::seconds(1),
			[this]() { Publish(); }))
		, m_counter(0)
	{
		RCLCPP_INFO(get_logger(), "Jaws ROS2 node started, publishing to 'data_link/parameter'");
	}

private:
	void Publish()
	{
		auto message = data_link_engine_interfaces::msg::Parameter{};

		message.stamp = get_clock()->now();
		message.unit = 0;
		message.quality = data_link_engine_interfaces::msg::Parameter::QUALITY_GOOD;
		message.value.type = data_link_engine_interfaces::msg::ParameterValue::TYPE_UINT64;
		message.value.uint64_value = m_counter++;

		m_spPublisher->publish(message);
	}

	rclcpp::Publisher<data_link_engine_interfaces::msg::Parameter>::SharedPtr m_spPublisher;
	rclcpp::TimerBase::SharedPtr m_spTimer;
	uint64_t m_counter;
};

int main(int argc, char* argv[])
{
	rclcpp::init(argc, argv);
	rclcpp::spin(std::make_shared<JawsNode>());
	rclcpp::shutdown();
	return 0;
}
