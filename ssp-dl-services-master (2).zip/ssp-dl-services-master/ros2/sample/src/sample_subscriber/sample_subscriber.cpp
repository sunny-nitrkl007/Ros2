// Copyright (C) Caterpillar Inc. All Rights Reserved.

#include <memory>
#include <rclcpp/rclcpp.hpp>
#include "data_link_engine_interfaces/msg/parameter.hpp"

class SampleSubscriber : public rclcpp::Node
{
public:
	SampleSubscriber()
		: Node("sample_subscriber")
	{
		m_subscription = create_subscription<data_link_engine_interfaces::msg::Parameter>(
			"parameters/sample_counter",
			10,
			[this](data_link_engine_interfaces::msg::Parameter::ConstSharedPtr msg) { OnReceive(msg); });

		RCLCPP_INFO(get_logger(), "Subscribed to 'parameters/sample_counter'");
	}

private:
	void OnReceive(data_link_engine_interfaces::msg::Parameter::ConstSharedPtr const& msg)
	{
		char const* quality_str = "UNSPECIFIED";
		switch (msg->quality)
		{
		case data_link_engine_interfaces::msg::Parameter::QUALITY_GOOD:
			quality_str = "GOOD";
			break;
		case data_link_engine_interfaces::msg::Parameter::QUALITY_BAD:
			quality_str = "BAD";
			break;
		case data_link_engine_interfaces::msg::Parameter::QUALITY_NOT_RECEIVED:
			quality_str = "NOT_RECEIVED";
			break;
		}

		char const* type_str = "UNSPECIFIED";
		switch (msg->value.type)
		{
		case data_link_engine_interfaces::msg::ParameterValue::TYPE_DOUBLE:
			type_str = "DOUBLE";
			break;
		case data_link_engine_interfaces::msg::ParameterValue::TYPE_STRING:
			type_str = "STRING";
			break;
		case data_link_engine_interfaces::msg::ParameterValue::TYPE_BINARY:
			type_str = "BINARY";
			break;
		case data_link_engine_interfaces::msg::ParameterValue::TYPE_BOOLEAN:
			type_str = "BOOLEAN";
			break;
		case data_link_engine_interfaces::msg::ParameterValue::TYPE_UINT64:
			type_str = "UINT64";
			break;
		}

		RCLCPP_INFO(get_logger(),
			"Received: stamp=%d.%09d unit=%u quality=%s type=%s uint64=%lu",
			msg->stamp.sec, msg->stamp.nanosec,
			msg->unit,
			quality_str,
			type_str,
			msg->value.uint64_value);
	}

	rclcpp::Subscription<data_link_engine_interfaces::msg::Parameter>::SharedPtr m_subscription;
};

int main(int argc, char* argv[])
{
	rclcpp::init(argc, argv);
	rclcpp::spin(std::make_shared<SampleSubscriber>());
	rclcpp::shutdown();
	return 0;
}
