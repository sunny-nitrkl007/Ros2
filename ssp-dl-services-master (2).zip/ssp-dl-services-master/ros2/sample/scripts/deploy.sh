#!/bin/bash
# Deploy a self-contained ROS2 runtime for the sample pub/sub executables.
#
# Usage: ./deploy.sh [target_host]
#
# Layout on the target (REMOTE_DIR):
#   bin/sample_publisher, bin/sample_subscriber
#   ros2/         - flattened ROS2 install prefix (lib/, share/, ...)
#   interfaces/   - flattened data_link_engine_interfaces install prefix
#   run.env       - sourced before launching; sets AMENT_PREFIX_PATH,
#                   LD_LIBRARY_PATH, RMW_IMPLEMENTATION

set -euo pipefail

TARGET="${1:-bosko}"
SAMPLE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="${SAMPLE_DIR}/build/tgt_gcc_arm64_guest/Debug/tgt_gcc_arm64_guest-debug"
DEPLOY_DIR="${SAMPLE_DIR}/build/tgt_gcc_arm64_guest/Debug/deploy"
STAGING_DIR="${SAMPLE_DIR}/build/tgt_gcc_arm64_guest/Debug/staging"
REMOTE_DIR="/tmp/ros2_samples"

CONAN_DIR="$(cd "${SAMPLE_DIR}/../../ess-info/development-tools/conan" && pwd)"
# shellcheck disable=SC1091
. "${CONAN_DIR}/ConanVariables.sh"

echo "Materialising Conan dependencies into ${DEPLOY_DIR} ..."
# Conan's full_deploy writes into version-named subdirs and never prunes old
# ones, so a previous run at version X leaves host/<pkg>/X/ behind even after
# the requirement bumps to Y — the wildcards below would then match BOTH and
# concatenate into a single tar argument. Wipe the deploy tree each run; the
# Conan cache still holds the package bodies so re-materialisation is cheap.
rm -rf "${DEPLOY_DIR}"
conan install "${SAMPLE_DIR}" \
    -pr:b "${BUILD_PROFILE}" \
    -pr:h "${A7HX_HOST_PROFILE_DEBUG}" \
    --deployer=full_deploy \
    --deployer-folder="${DEPLOY_DIR}"

# Resolve the per-package roots (wildcard the version / arch).
ROS2_PKG_DIR="$(echo "${DEPLOY_DIR}"/full_deploy/host/ros2/*/Debug/*)"
INTERFACES_PKG_DIR="$(echo "${DEPLOY_DIR}"/full_deploy/host/data_link_engine_interfaces/*/Debug/*)"

# Stage a clean tree locally so the scp transfer is one rsync-friendly tree
# with no Conan layout noise. We exclude include/ and *.cmake — they're
# huge and serve only build-time consumers. share/ stays because ament's
# index lives under share/ament_index/ and the per-package metadata under
# share/<pkg>/ is what makes rclcpp::init() and typesupport discovery work.
echo "Staging self-contained tree at ${STAGING_DIR} ..."
rm -rf "${STAGING_DIR}"
mkdir -p "${STAGING_DIR}/bin" "${STAGING_DIR}/ros2" "${STAGING_DIR}/interfaces"
cp "${BUILD_DIR}/src/sample_publisher/sample_publisher" "${STAGING_DIR}/bin/"
cp "${BUILD_DIR}/src/sample_subscriber/sample_subscriber" "${STAGING_DIR}/bin/"

# Use tar (portable) for the copy-with-excludes step. -C / | tar x avoids
# the temporary tarball on disk.
stage_pkg() {
    local src="$1" dst="$2"
    tar -C "${src}" \
        --exclude='include' \
        --exclude='*.cmake' \
        -cf - . | tar -C "${dst}" -xf -
}
stage_pkg "${ROS2_PKG_DIR}" "${STAGING_DIR}/ros2"
stage_pkg "${INTERFACES_PKG_DIR}" "${STAGING_DIR}/interfaces"

# Single env file consumers source. POSIX-sh compatible (busybox ash on
# the target has no BASH_SOURCE and no arrays), so REMOTE_DIR is baked in
# at deploy time rather than discovered at source time.
cat > "${STAGING_DIR}/run.env" <<EOF
# Source before launching: . ${REMOTE_DIR}/run.env
HERE="${REMOTE_DIR}"
export AMENT_PREFIX_PATH="\${HERE}/ros2:\${HERE}/interfaces"
# Borrow the system Python from /opt/Ros2Dev (the target has no
# /usr/bin/python3); link against our deployed libyaml etc. by listing
# our lib dirs first.
export LD_LIBRARY_PATH="\${HERE}/ros2/lib:\${HERE}/interfaces/lib:/opt/Ros2Dev/lib\${LD_LIBRARY_PATH:+:\${LD_LIBRARY_PATH}}"
# Python entry points for the ros2 CLI (ros2cli + extensions) and the
# generated message bindings live under each prefix's site-packages.
export PYTHONPATH="\${HERE}/ros2/lib/python3.12/site-packages:\${HERE}/interfaces/lib/python3.12/site-packages\${PYTHONPATH:+:\${PYTHONPATH}}"
export PATH="\${HERE}/ros2/bin:/opt/Ros2Dev/bin\${PATH:+:\${PATH}}"
: "\${RMW_IMPLEMENTATION:=rmw_fastrtps_cpp}"
export RMW_IMPLEMENTATION
# Match the platform's stock /tmp/ros2_env.sh so we coexist with jaws_ros2 /
# jaws_subscriber_ros2 and any shell that sourced that file earlier. Without
# this our binaries fall back to domain 0 and silently fail discovery against
# anything launched on domain 42.
: "\${ROS_DOMAIN_ID:=42}"
export ROS_DOMAIN_ID
# Root's home on the ECU is on a read-only rootfs; rcl_logging_spdlog
# aborts if it can't create its log dir. Park ROS state under /tmp.
: "\${ROS_HOME:=/tmp/.ros}"
: "\${ROS_LOG_DIR:=/tmp/.ros/log}"
export ROS_HOME ROS_LOG_DIR
mkdir -p "\${ROS_LOG_DIR}"
# The ros2 CLI is a Python entry-point script whose shebang points at
# /usr/bin/python3, which doesn't exist on this image. Wrap it so
# 'ros2 topic list' Just Works after sourcing.
ros2() { /opt/Ros2Dev/bin/python3 "\${HERE}/ros2/bin/ros2" "\$@"; }
EOF

echo "Deploying to ${TARGET}:${REMOTE_DIR} (this may take a moment) ..."
# Linux refuses to overwrite a running executable's text segment (ETXTBSY),
# so a redeploy while the sample pub/sub are running fails the scp. Kill
# any leftovers up front. Use killall (matches the process basename via
# /proc/<pid>/comm) rather than `pkill -f`, which scans the full cmdline
# and would gleefully match — and kill — its own parent ssh shell whose
# argv contains the string "sample_publisher".
ssh "${TARGET}" "/bin/mkdir -p '${REMOTE_DIR}' && /usr/bin/killall sample_publisher sample_subscriber 2>/dev/null ; sleep 1; exit 0"
# scp -r works on every busybox/openssh target; rsync would be faster on
# repeat deploys but isn't always installed on minimal ECU images.
scp -r "${STAGING_DIR}/." "${TARGET}:${REMOTE_DIR}/"

cat <<EOM
Done. On ${TARGET}:
  . ${REMOTE_DIR}/run.env
  ${REMOTE_DIR}/bin/sample_publisher
  ${REMOTE_DIR}/bin/sample_subscriber
EOM
