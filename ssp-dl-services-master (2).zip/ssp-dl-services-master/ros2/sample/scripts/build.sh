#!/bin/bash
# Copyright (C) Caterpillar Inc. All Rights Reserved.
#
# Build the sample ROS2 application using the shared Conan build helper.
# The helper builds both Debug and RelWithDebInfo for each requested target.

set -euf -o pipefail

readonly SCRIPT_DIR="$(realpath "$(dirname "$0")")"
readonly SAMPLE_DIR="$(realpath "${SCRIPT_DIR}/..")"
readonly BUILD_HELPER="${SAMPLE_DIR}/../../ess-info/development-tools/conan/BuildConanProject.sh"

readonly USAGE="$(basename "$0") [-z tgt_gcc_arm64_guest|tgt_gcc_ubuntu]*"

declare -a HELPER_ARGS=()

while getopts ":z:" opt; do
	case $opt in
		z)
			case "$OPTARG" in
				tgt_gcc_arm64_guest) HELPER_ARGS+=(-z ecu_a7hx) ;;
				tgt_gcc_ubuntu)      HELPER_ARGS+=(-z ubuntu_a7hx) ;;
				*) echo "$USAGE"; exit 1 ;;
			esac
			;;
		\?) echo "$USAGE"; exit 1 ;;
	esac
done

"${BUILD_HELPER}" -d "${SAMPLE_DIR}" "${HELPER_ARGS[@]}"