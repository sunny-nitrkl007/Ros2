# Copyright (C) Caterpillar Inc. All Rights Reserved.

import os
from conan import ConanFile
from conan.tools.cmake import cmake_layout, CMake


class DataLinkEngineInterfacesSampleConan(ConanFile):
    name = "data_link_engine_interfaces_sample"
    version = "0.1.0"
    package_type = "application"
    settings = "arch", "os", "compiler", "build_type", "cat_tgt"
    generators = "CMakeDeps", "CMakeToolchain", "VirtualRunEnv"
    exports_sources = "CMakeLists.txt", "src/*"

    def requirements(self):
        self.requires("data_link_engine_interfaces/0.1.0")
        self.requires("ros2/jazzy-test")

    def layout(self):
        cmake_layout(self, build_folder=os.path.join(
            "build", self.settings.cat_tgt.value, self.settings.build_type.value))

    def build(self):
        cmake = CMake(self)
        cmake.configure()
        cmake.build()
