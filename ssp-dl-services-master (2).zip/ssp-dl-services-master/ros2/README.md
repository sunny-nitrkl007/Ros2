# ROS2 IDL Conan Packages

It's now possible to generate ROS2 IDL packages in Conan using the ros2/jazzy-test package. It is relatively simple to do so, and you can see an example of this working [here](https://stuff.ecorp.cat.com/ui/repos/tree/General/cat-e-conan-dev-local/_/data_link_engine_interfaces/0.1.0).

## IDL Package Provider

### What is currently possible?

The Conan IDL package can generate all of the dependencies required for a C++ application to communicate over ROS2 using the IDL as well as generating fully functional python bindings so that clients can use runtime introspection and the full suite of ROS2 tooling.

### What is not possible?

There isn't currently a clean way to ship multiple IDL packages to the domain controller and have a well integrated view using ROS2 tooling. Our [sample deployment script](https://gitgis.ecorp.cat.com/es-csf-core-info/dl-services/ssp-dl-services/-/blob/master/ros2/sample/scripts/deploy.sh?ref_type=heads) shows a way that you can get one IDL working by deploying the entire set of dependencies from Conan to the target device, then sourcing an environment variable setup file.

Eventually we will need to support shipping our ROS2 tooling in a separate Dev verity and then allow some standard interface for picking up additional IDL packages on the domain controller. Much of this pain is related to providing all of the xml files that the standard colcon build system for ROS2 would help us to generate. Because we don't use colcon, we need to generate all of the compatibility files from our conan packages instead.

You may also notice that there is a lot of python hacks in the [CMakeLists.txt](https://gitgis.ecorp.cat.com/es-csf-core-info/dl-services/ssp-dl-services/-/blob/master/ros2/CMakeLists.txt?ref_type=heads) file. This is all expected to be dropped when we build from source and the python dependencies can be brought in at build time. We currently just repackage .deb files built for Ubuntu.

## IDL Package Consumer

### What is currently possible?

From a C++ perspective, you can do everything you need to do cleanly and easily. You can view the [test package](https://gitgis.ecorp.cat.com/es-csf-core-info/dl-services/ssp-dl-services/-/tree/master/ros2/test_package?ref_type=heads) to see an example client of an IDL package.

### What is not possible?

See all of the python tooling restrictions listed above.

## How to create a package

[Example](https://gitgis.ecorp.cat.com/es-csf-core-info/dl-services/ssp-dl-services/-/tree/master/ros2?ref_type=heads)

1. To create a package, you must first define the IDL and package.xml exactly as prescribed by the ROS2 docs.
2. In the Conanfile for the package, make sure that you have a regular dependency for ros2/jazzy-test and a **tool** dependency for cpython/3.12.7.
3. In the package info, you must disable conan target generation. You want the ament targets, not the conan targets.
4. In the package info, you must also set the 4 environment variables from the sample Conanfile. You can set them exactly as they are shown (in the future, a utility will likely be provided for these)
5. Review the example CMakeLists.txt and copy it as-is, using a find and replace to change to your IDL file and target names. We will eventually provide a package that allows for a nice CMake function for clients to use.

## How to consume a package

1. Add a dependency for the Conan IDL package in your requires list
2. Use it exactly as you would any other Conan package. It should be immediately available and work as described in the ROS2 docs.