// Copyright (C) Caterpillar Inc. All Rights Reserved.
//
// Constructs the generated message types and exercises a couple of fields to
// confirm that headers, typesupport, and runtime libraries from the Conan
// package are all resolvable. No ROS middleware is required.

#include "data_link_engine_interfaces/msg/parameter.hpp"
#include "data_link_engine_interfaces/msg/parameter_value.hpp"

int main()
{
	constexpr auto anyType = data_link_engine_interfaces::msg::ParameterValue::TYPE_UINT64;
	constexpr auto anyValue = 42;

	data_link_engine_interfaces::msg::ParameterValue value{};
	value.type = anyType;
	value.uint64_value = anyValue;

	constexpr auto anyUnit = 7;
	constexpr auto anyQuality = data_link_engine_interfaces::msg::Parameter::QUALITY_GOOD;

	data_link_engine_interfaces::msg::Parameter parameter{};
	parameter.unit = anyUnit;
	parameter.value = value;
	parameter.quality = anyQuality;

	return 0;
}
