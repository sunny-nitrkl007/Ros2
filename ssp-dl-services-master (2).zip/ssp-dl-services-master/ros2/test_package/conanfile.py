# Copyright (C) Caterpillar Inc. All Rights Reserved.

import os
from conan import ConanFile
from conan.tools.cmake import cmake_layout, CMake
from conan.tools.build import can_run


class DataLinkEngineInterfacesTestConan(ConanFile):
    settings = "arch", "os", "compiler", "build_type", "cat_tgt"
    generators = "CMakeDeps", "CMakeToolchain"

    def requirements(self):
        self.requires(self.tested_reference_str)

    def layout(self):
        cmake_layout(self)

    def build(self):
        cmake = CMake(self)
        cmake.configure()
        cmake.build()

    def test(self):
        if can_run(self):
            self.run(os.path.join(self.cpp.build.bindir, "test_package"), env="conanrun")
