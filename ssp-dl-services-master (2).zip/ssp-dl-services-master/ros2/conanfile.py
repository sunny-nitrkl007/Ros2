# Copyright (C) Caterpillar Inc. All Rights Reserved.

import os
from conan import ConanFile
from conan.tools.cmake import cmake_layout, CMake


class DataLinkEngineInterfacesConan(ConanFile):
    name = "data_link_engine_interfaces"
    version = "0.1.0"
    package_type = "shared-library"
    settings = "arch", "os", "compiler", "build_type", "cat_tgt"
    generators = "CMakeDeps", "CMakeToolchain"
    exports_sources = "CMakeLists.txt", "package.xml", "msg/*", "src/*"

    def requirements(self):
        self.requires("ros2/jazzy-test", transitive_headers=True, transitive_libs=True)

    def build_requirements(self):
        # Otherwise we'll use whichever version of python exists on the host
        self.tool_requires("cpython/3.12.7")

    def layout(self):
        cmake_layout(self, build_folder=os.path.join(
            "build", self.settings.cat_tgt.value, self.settings.build_type.value))

    def build(self):
        cmake = CMake(self)
        cmake.configure()
        cmake.build()

    def package(self):
        cmake = CMake(self)
        cmake.install()

    def package_info(self):
        self.cpp_info.includedirs = [os.path.join("include", self.name)]
        self.cpp_info.libdirs = ["lib"]

        # Disable Conan's CMake targets in favor of the ament-generator targets
        self.cpp_info.set_property("cmake_find_mode", "none")

        # ament/rosidl compatibility to replace colcon's built-in functionality
        self.buildenv_info.prepend_path("AMENT_PREFIX_PATH", self.package_folder)
        self.runenv_info.prepend_path("AMENT_PREFIX_PATH", self.package_folder)
        self.buildenv_info.prepend_path("CMAKE_PREFIX_PATH", self.package_folder)
        self.runenv_info.append_path("LD_LIBRARY_PATH", os.path.join(self.package_folder, "lib"))
