# J1939 ExtensionId Read — High-Level Overview

## Purpose

The J1939 ExtensionId Read subsystem enables Shark to request and receive **J1939 Extension ID** data from peer ECMs on a CAN bus. Extension IDs are a Caterpillar-proprietary mechanism layered on top of the SAE J1939 transport protocol, used to exchange product-specific data (device identification, software/hardware information, etc.) between ECMs and the Shark data link engine.

This implementation supports a **refresh-only** read pattern: middleware issues a refresh request for a configured SharkByte, Shark sends an ExtensionId read request to the target ECM, and the raw response bytes are returned through the SharkByte/middleware interface.

## Scope

This subsystem handles **only** the ExtensionId read (refresh) interaction pattern — on-demand request/response exchanges where Shark sends a read request and awaits the ECM's response. It does **not** cover:

- ExtensionId **writes** (not needed for this feature)
- ExtensionId **broadcast** monitoring (periodic/unsolicited data)
- Parsing response data into individual typed fields (that responsibility belongs to a downstream process outside this feature's scope)
- ExtensionId **transmission** (responding to incoming read requests from other devices — already handled by `J1939ExtensionIdTxManager`)

### Supported Extension IDs

Only the following Extension IDs are supported at this time:

| Extension ID | Description |
|---|---|
| `0xF019` | Software part number, description, release date |
| `0xF01A` | Hardware part number, serial number |

Additional Extension IDs can be added in the future by extending the protobuf configuration without code changes.

## Differences from d6c_shark

| Aspect | d6c_shark | ssp-dl-services/shark |
|---|---|---|
| **Data Interpretation** | Parses response into named sub-fields via `ExtensionIdStringSlot` (asterisk-delimited strings) and `ExtensionIdDefinition` (numeric bit fields) | Treats the full response as raw bytes; delivers the payload as a `std::vector<uint8_t>` directly to the SharkByte. No hex conversion, no sub-field parsing. |
| **Slot Architecture** | Multiple specialized slot types (`ExtensionIdStringSlot`, `F03CExtensionIdSlot`, `F059ExtensionIdSlot`, `ExtensionIdSlot`) with per-definition data processors, routed through `SlotManager` | Single `TransientSharkByte` per configured ExtensionId, owned directly by the manager. No SlotManager routing needed. |
| **Write Support** | Full read/write lifecycle with `IJ1939ExtensionIdDataWriter` | Read (refresh) only — no write path needed |
| **Broadcast Support** | `ExtensionIdBroadcastRxConfig` with `ExtensionIdSlotTimeoutDecorator` for auto-invalidation | Not supported — only on-demand refresh |
| **Configuration** | Legacy `ExtensionIdConfig` (D6CX) and newer definition-driven `ExtensionIdBroadcastRxConfig`/`ExtensionIdOnRequestRxConfig` | Protobuf-driven `J1939DataLink.PeerNode.ExtensionId` configuration |
| **Retry on NACK** | Unlimited retries via `RetryLaterIfCurrent()` on NACK `0x0005` | Unlimited retries via `RetryLaterIfCurrent()` on NACK `0x0005` (retry later) |
| **Read Timeout** | Handled by `ExtensionIdResponseTimeoutHandler` with polling cycle | Up to **4 retries** on no-response timeout via the synchronizer; SharkByte is not notified on timeout exhaustion (synchronizer silently drops the request) |
| **Transient Behavior** | N/A | SharkByte is transient — each refresh produces either a 'good' or 'bad' result, even if the value is unchanged |

## Data Flow

```
Middleware Read (Refresh) Request
        │
        ▼
  TransientSharkByte::Refresh()
        │  Invokes RefreshInitiator lambda
        ▼
  J1939ExtensionIdManager::Refresh(address, extensionId)
        │  Queues request via Transport Protocol Synchronizer
        ▼
  ITransportProtocolClientSynchronizer::Add()
        │  Waits for bus availability
        │
        ▼  (bus available)
  J1939ExtensionIdManager::SendReadRequest()
        │  Constructs PropA message: [0x0080][ExtId MSB][ExtId LSB]
        ▼
  IJ1939Wrapper::SendPropAMessage()
        │  Transmits on J1939 CAN bus
        │
        │  ◄── ECM responds with ExtensionId data ──►
        │
  IJ1939Wrapper  (ExtensionId read response handler)
        │
        ▼
  J1939ExtensionIdManager::ReadResponseHandler()
        │  Extracts extension ID and payload from response
        ▼
  TransientSharkByte::Write(data)  [or WriteInvalid() on error]
        │
        ▼
  Middleware receives raw payload bytes
```

### Error Paths

```
  ┌─────── No Response ─────────┐    ┌──── NACK 0x0005 (Retry) ────┐
  │ Retry up to 4 times         │    │ Retry indefinitely          │
  │ If all retries exhausted:   │    │                             │
  │  → No SharkByte notification│    │                             │
  └─────────────────────────────┘    └─────────────────────────────┘

  ┌─── NACK (Other Error) ──────┐
  │ No retry                    │
  │  → Invalidate SharkByte     │
  └─────────────────────────────┘
```

## Key Components

| Component | Responsibility |
|---|---|
| **J1939ExtensionIdManager** | Core orchestrator for ExtensionId operations on a single CAN port. Constructs outbound read requests, registers response/NACK handlers, and writes received data directly to the associated `TransientSharkByte`. Delegates retry logic to the `ITransportProtocolClientSynchronizer`. Follows the Static Factory Pattern (`ShouldBeCreated()` / `CreateInitializer()`). |
| **TransientSharkByte** (existing) | Implements both `ISharkByte` and `IWriteSharkByte`. Created with a `RefreshInitiator` lambda that captures the manager reference and calls `J1939ExtensionIdManager::Refresh()`. On response, the manager calls `Write(data)` or `WriteInvalid()` directly on the SharkByte. `Value()` always returns `std::nullopt` — every subscriber notification is a fresh event. Follows the same pattern as `BdtClientWrapper`. |
| **ITransportProtocolClientSynchronizer** (existing) | Manages bus contention by queuing `TransportProtocolRequest` entries. Ensures only one outstanding request per address at a time. Provides built-in retry (up to 4 times with 250ms intervals) for the front request — this handles the no-response retry requirement. Supports `RetryLaterIfCurrent()` for NACK-driven retries, which re-queues the request with fresh retry parameters for indefinite retry. |
| **IJ1939Wrapper** (existing) | Platform abstraction over J1939 CAN libraries. Provides `SendPropAMessage()` for transmit, `RegisterExtensionIdCommandHandler()` for receiving ECM read responses (where the extension ID acts as the 2-byte SCL command), and `RegisterExtensionIdCommandIdHandler()` for receiving NACKs keyed by command and extension ID. |

## Configuration

ExtensionId Read is configured via the protobuf `SharkConfiguration` schema:

```
J1939DataLink
  └─ PeerNode (one per ECU address)
       ├─ address: uint32  (J1939 source/destination address)
       └─ ExtensionId extension_id (optional, field 8)
            └─ extension_id_reads (repeated ExtensionIdRead)
                 ├─ extension_id: uint32    (e.g. 0xF019, 0xF01A)
                 └─ middleware_id: string   (SharkByte ID exposed to middleware)
```

Each `ExtensionIdRead` entry creates one `TransientSharkByte` whose `RefreshInitiator` lambda captures the manager, peer address, and extension ID, and calls `J1939ExtensionIdManager::Refresh()`.

## Lifecycle

1. **Creation** — `J1939ExtensionIdManager::ShouldBeCreated()` inspects all J1939DataLink configs; if any peer node has an `extension_id` section, the manager should be created.
2. **Factory** — `CreateInitializer()` iterates over all J1939DataLink configs, creates a `J1939ExtensionIdManager` per CAN port that has ExtensionId read config, creates `TransientSharkByte` instances and registers them with the `ISharkByteManager`, and returns a deferred initializer lambda.
3. **Initialization** — The returned lambda calls `Initialize()` on each manager, which registers ExtensionId command handlers with the J1939 wrapper for read responses and NACKs.
4. **Runtime** — Middleware refresh requests flow through `TransientSharkByte::Refresh()` → manager → synchronizer → J1939 bus → response handler → `TransientSharkByte::Write()` / `WriteInvalid()`. The synchronizer handles no-response retries (up to 4 times); NACK `0x0005` retries are managed via `RetryLaterIfCurrent()`.
5. **Destruction** — The manager unregisters itself from the static tracking array.

## Message Format

### Outbound Read Request (PropA, PGN 0xEF00)

| Field | Size | Value |
|---|---|---|
| Command | 1 byte | `0x80` (ExtensionId Read Request) |
| Extension ID | 2 bytes | MSB-first (e.g., `0xF0`, `0x19` for `0xF019`) |

### Inbound Read Response

| Field | Size | Value |
|---|---|---|
| Extension ID | 2 bytes | MSB-first, echoed from request (serves as the 2-byte SCL command) |
| Payload | N bytes | Raw Extension ID data |

### Inbound NACK (PGN 0xF004)

| Field | Size | Value |
|---|---|---|
| Header | 4 bytes | Protocol-defined header fields |
| Error Code | 2 bytes | `0x0005` = retry later; other = permanent failure |

## Error Handling

- **No response (timeout)**: The read request is retried up to **4 times** by the synchronizer. If all retries are exhausted, the synchronizer silently drops the request and the SharkByte receives no notification.
- **NACK with error `0x0005` (retry later)**: The read request is retried **indefinitely** as long as the ECM continues to respond with NACK `0x0005`.
- **NACK with any other error**: No retry; the SharkByte is immediately invalidated.
- **Transient SharkByte behavior**: The SharkByte is configured as transient, meaning each refresh produces a new value notification regardless of whether the data changed. This ensures the consumer always sees the latest 'good' or 'bad' result.

## Multi-CAN Support

`J1939ExtensionIdManager::CreateInitializer()` creates one manager instance per CAN port that has configured ExtensionId read entries. Different CAN ports and different J1939 node addresses are fully supported through the protobuf configuration, following the same pattern as `J1939BasicReadWriteManager`.
