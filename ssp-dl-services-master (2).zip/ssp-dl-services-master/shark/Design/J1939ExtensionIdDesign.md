# J1939 ExtensionId — In-Depth Design Document

## 1. Introduction

This document provides a detailed design specification of the J1939 ExtensionId subsystem within `ssp-dl-services/shark`. It covers the class architecture, configuration model, initialization sequence, runtime read/retry flow, protocol details, and testability considerations. PlantUML class and sequence diagrams are included inline.

For a high-level overview, see [J1939ExtensionIdOverview.md](J1939ExtensionIdOverview.md).

---

## 2. Class Diagram

```plantuml
@startuml J1939ExtensionIdClassDiagram

skinparam classAttributeIconSize 0
skinparam linetype ortho

skinparam class {
    BackgroundColor<<Changed>> LightGreen
    BackgroundColor<<New>> LightBlue
}

skinparam interface {
    BackgroundColor<<Changed>> LightGreen
    BackgroundColor<<New>> LightBlue
}

hide empty members

package "Shark::J1939" {

    class J1939ExtensionIdManager <<New>> {
        - m_j1939DataLink : J1939DataLink const&
        - m_j1939Wrapper : IJ1939Wrapper&
        - m_synchronizer : ITransportProtocolClientSynchronizer&
        - m_sharkByteMappings : vector<SharkByteMapping>
        __
        + {static} ShouldBeCreated(dc : DependencyContainer const&) : bool
        + {static} CreateInitializer(dc : DependencyContainer const&) : function<void()>
        + J1939ExtensionIdManager(j1939DataLink, wrapper, synchronizer)
        + SetSharkByteMappings(mappings) : void
        + ~J1939ExtensionIdManager()
        + Initialize() : void
        + Refresh(address, extensionId) : void
        - SendReadRequest(request) : void
        - RegisterReceiveHandlers(extensionId) : void
        - FindSharkByte(address, extensionId) : nice_ptr<TransientSharkByte>
        - ReadResponseHandler(address, pMessage, messageLength) : void
        - NackHandler(address, extensionId, pMessage, messageLength) : void
    }

    class SharkByteMapping <<New>> {
        + address : unsigned
        + extensionId : unsigned
        + sharkByte : nice_ptr<TransientSharkByte>
    }

    interface IJ1939Wrapper {
        + SendPropAMessage(destAddress, pData, dataLength) : bool
        + RegisterExtensionIdCommandHandler(extensionId, handler) : void
        + RegisterExtensionIdCommandIdHandler(command, extensionId, handler) : void
        + GetCanPort() : CanPort
    }

    interface ITransportProtocolClientSynchronizer {
        + Add(request, sendMethod) : void
        + Remove(request) : void
        + RetryLaterIfCurrent(request) : void
    }

    class TransportProtocolRequest {
        + type : RequestType
        + address : unsigned
        + id : unsigned
    }

    enum RequestType {
        ExtensionId
        BasicRead
    }

    TransportProtocolRequest *-- RequestType
}

package "Utilities" {

    class TransientSharkByte {
        - m_id : SharkByteId
        - m_refreshInitiator : RefreshInitiator
        + TransientSharkByte(id, refreshInitiator)
        + Value() : SharkByteValue
        + Refresh() : void
        + Write(value) : void
        + WriteInvalid() : void
        + SubscribeToValues(callback) : SharkByteSubscription
    }

    interface ISharkByte {
        + Refresh() : void
        + Value() : SharkByteValue
    }

    interface IWriteSharkByte {
        + Write(value, completedCallback) : void
        + WriteInvalid(completedCallback) : void
    }

    ISharkByte <|.. TransientSharkByte
    IWriteSharkByte <|.. TransientSharkByte
}

package "Shark" {

    class DependencyContainer {
        + GetJ1939DataLinkConfigs() : vector<J1939DataLink>
        + GetIJ1939Wrapper(canPort) : IJ1939Wrapper&
        + GetTransportProtocolClientSynchronizer() : ITransportProtocolClientSynchronizer&
        + GetISharkByteManager() : ISharkByteManager&
    }

    interface ISharkByteManager {
        + AddSharkByte(sharkByte) : void
    }
}

package "Protobuf Config" {

    class J1939DataLink <<protobuf>> {
        + can_port() : CanPort
        + peer_nodes() : repeated PeerNode
    }

    class PeerNode <<Changed>> {
        + address() : uint32
        ..New..
        + has_extension_id() : bool
        + extension_id() : ExtensionId
    }

    class ExtensionId <<New>> {
        + extension_id_reads() : repeated ExtensionIdRead
    }

    class ExtensionIdRead <<New>> {
        + extension_id() : uint32
        + middleware_id() : string
    }

    J1939DataLink *-- "0..*" PeerNode
    PeerNode *-- "0..1" ExtensionId
    ExtensionId *-- "0..*" ExtensionIdRead
}

' Relationships
J1939ExtensionIdManager o-- IJ1939Wrapper
J1939ExtensionIdManager o-- ITransportProtocolClientSynchronizer
J1939ExtensionIdManager *-- "0..*" SharkByteMapping
J1939ExtensionIdManager ..> J1939DataLink : reads config
J1939ExtensionIdManager ..> TransportProtocolRequest : creates
J1939ExtensionIdManager o-- "0..*" TransientSharkByte : writes to

DependencyContainer ..> J1939ExtensionIdManager : creates via CreateInitializer()
DependencyContainer ..> TransientSharkByte : creates

@enduml
```

---

## 3. Initialization Sequence Diagram

```plantuml
@startuml J1939ExtensionIdInitSequence

title J1939 ExtensionId - Initialization Sequence

participant "Shark Startup" as Startup
participant "J1939ExtensionIdManager" as Manager
participant "DependencyContainer" as DC
participant "ISharkByteManager" as SBMgr
participant "IJ1939Wrapper" as Wrapper
participant "TransientSharkByte" as SharkByte

== Static Check ==

Startup -> Manager ++ : ShouldBeCreated(dependencyContainer)
Manager -> DC : GetJ1939DataLinkConfigs()
DC --> Manager : vector<J1939DataLink>
Manager -> Manager : any_of(configs, hasExtensionId)
Manager --> Startup -- : true/false

== Factory Phase (CreateInitializer) ==

Startup -> Manager ++ : CreateInitializer(dependencyContainer)

loop for each J1939DataLink config with extension_id
    Manager -> DC : GetIJ1939Wrapper(canPort)
    Manager -> DC : GetTransportProtocolClientSynchronizer()

    Manager -> Manager : <<create>> J1939ExtensionIdManager(\n\tj1939DataLink, wrapper,\n\tsynchronizer)

    loop for each PeerNode with extension_id
        loop for each ExtensionIdRead
            Manager -> SharkByte : <<create>> TransientSharkByte(\n\tmiddleware_id,\n\trefreshInitiator)
            note right of SharkByte
                RefreshInitiator lambda captures:
                - J1939ExtensionIdManager&
                - address
                - extensionId
                Calls manager.Refresh(
                    address, extensionId)
            end note

            Manager -> SBMgr : AddSharkByte(sharkByte)
        end
    end
        Manager -> Manager : SetSharkByteMappings(mappings)

== Runtime Initialization ==

Startup -> Manager ++ : initializer()
loop for each manager instance
    Manager -> Manager : Initialize()
    loop for each configured ExtensionId
        Manager -> Wrapper : RegisterExtensionIdCommandHandler(\n\textensionId, readResponseHandler)
        note right of Wrapper
            Registers handler for ECM read responses.\n            The extensionId acts as the 2-byte SCL command.
        end note
        Manager -> Wrapper : RegisterExtensionIdCommandIdHandler(\n\tAcknowledgeResponse, extensionId, nackHandler)
        note right of Wrapper
            Registers handler for NACK responses
            matching this specific extensionId.
        end note
    end
end
deactivate Manager

@enduml
```

---

## 4. Read Request & Response Sequence Diagram

```plantuml
@startuml J1939ExtensionIdReadSequence

title J1939 ExtensionId — Refresh, Response & Retry Flow

actor "Middleware" as MW
participant "TransientSharkByte" as SharkByte
participant "J1939ExtensionIdManager" as Manager
participant "ITransportProtocol\nClientSynchronizer" as Sync
participant "IJ1939Wrapper" as J1939
participant "Remote ECM" as ECM

== Refresh / Read Request ==

MW -> SharkByte : Refresh()
SharkByte -> Manager : Refresh(address, extensionId)

Manager -> Sync : Add(TransportProtocolRequest{\n\tExtensionId, address, extensionId},\n\tsendLambda)
note right: Request queued;\nwaiting for bus availability

...bus becomes available...

Sync -> Manager : sendLambda(request)
Manager -> Manager : SendReadRequest(request)

note right of Manager
    Message layout:
    [0x80] [ExtId MSB] [ExtId LSB]

    • Command byte: 0x80 (Read Request)
    • Extension ID: 2 bytes, MSB-first
    e.g., 0xF019 → [0x80, 0xF0, 0x19]

    The synchronizer calls SendReadRequest
    up to 4 times at 250ms intervals. If no
    response or NACK is received, the
    synchronizer silently removes the request.
end note

Manager -> J1939 : SendPropAMessage(address, requestData, 3)
note right: Synchronizer will retry this\nsend up to 4 times total

== Successful Response ==

ECM --> J1939 : ExtensionId read response
J1939 --> Manager : ReadResponseHandler(address, pMessage, length)

Manager -> Manager : ExtractExtensionId(pMessage)
Manager -> Sync : Remove(request)
Manager -> Manager : FindSharkByte(address, extensionId)
Manager -> SharkByte : Write(payloadBytes)
SharkByte -> MW : value available

@enduml
```

---

## 5. Retry & Error Handling Sequence Diagram

```plantuml
@startuml J1939ExtensionIdRetrySequence

title J1939 ExtensionId — Retry & Error Handling

participant "J1939ExtensionIdManager" as Manager
participant "ITransportProtocol\nClientSynchronizer" as Sync
participant "IJ1939Wrapper" as J1939
participant "Remote ECM" as ECM
participant "TransientSharkByte" as SharkByte

== NACK with 0x0005 (Retry Later) — Indefinite Retries ==

ECM --> J1939 : NACK (0xF004), error = 0x0005
J1939 --> Manager : NackHandler(address, pMessage, length)

Manager -> Manager : ExtractExtensionId(pMessage)
Manager -> Manager : ExtractErrorCode(pMessage) → 0x0005

Manager -> Sync : RetryLaterIfCurrent(request)
note right
    Re-queues the request to the back
    of the synchronizer queue. When
    it returns to the front, the synchronizer
    resets retry parameters (fresh 4 retries).
end note

...request reaches front of queue...

Sync -> Manager : sendLambda(request)
Manager -> Manager : SendReadRequest(request)
Manager -> J1939 : SendPropAMessage(address, requestData, 3)

== NACK with Other Error Code — No Retry ==

ECM --> J1939 : NACK (0xF004), error ≠ 0x0005
J1939 --> Manager : NackHandler(address, pMessage, length)

Manager -> Manager : ExtractExtensionId(pMessage)
Manager -> Manager : ExtractErrorCode(pMessage) → other
Manager -> Sync : Remove(request)
Manager -> Manager : FindSharkByte(address, extensionId)
Manager -> SharkByte : WriteInvalid()
note right: SharkByte immediately\ninvalidated

== No Response — Synchronizer Exhausts Retries ==

note over Sync
    The synchronizer calls SendReadRequest
    up to 4 times at 250ms intervals.

    If no Remove() or RetryLaterIfCurrent()
    is called, the synchronizer silently
    removes the request after exhausting
    its retry count.
end note

Sync -> Manager : sendLambda(request)  [1st attempt]
Manager -> J1939 : SendPropAMessage(address, requestData, 3)
note right: No response from ECM

...250ms later...

Sync -> Manager : sendLambda(request)  [2nd attempt]
Manager -> J1939 : SendPropAMessage(address, requestData, 3)
note right: No response from ECM

...250ms later (retries continue up to 4 times)...

note over Sync
    After 4 send attempts with no
    Remove() or RetryLaterIfCurrent(),
    the synchronizer removes the request.
    The SharkByte receives no notification.
end note

@enduml
```

---

## 6. Detailed Component Design

### 6.1 J1939ExtensionIdManager

This is the central class for ExtensionId operations. One instance is created per CAN port that has ExtensionId configuration. It is a `final` class.

#### Static Factory Pattern

The class follows the Shark convention of static `ShouldBeCreated()` / `CreateInitializer()` methods, identical in pattern to `J1939BasicReadWriteManager`:

- **`ShouldBeCreated(DependencyContainer const&)`** — Scans all J1939DataLink configs to check if any peer node has an `extension_id` section. Returns `true` if at least one exists.

- **`CreateInitializer(DependencyContainer const&)`** — Performs all construction work eagerly:
  1. Iterates over all J1939DataLink configs.
  2. For each config containing ExtensionId read entries, creates a `J1939ExtensionIdManager` with its three constructor dependencies.
  3. Creates all `TransientSharkByte` instances for that config and registers them with the `ISharkByteManager`. Each SharkByte receives a `RefreshInitiator` lambda that captures the manager by reference, along with the peer address and extension ID, and calls `J1939ExtensionIdManager::Refresh(address, extensionId)`.
  4. Calls `SetSharkByteMappings()` on the manager to inject the pre-built address/extensionId/SharkByte associations.
  5. Returns a lambda that calls `Initialize()` on each manager instance.

The two-phase approach (construction then initialization) ensures all SharkBytes are registered before any J1939 I/O begins. This follows the same pattern used by `BdtClientWrapper`.

#### Constructor

```cpp
J1939ExtensionIdManager(
    cat::shark::J1939DataLink const& j1939DataLink,
    IJ1939Wrapper& j1939Wrapper,
    ITransportProtocolClientSynchronizer& synchronizer) noexcept;
```

All dependencies are injected. SharkByte mappings are supplied separately via `SetSharkByteMappings()` after construction, because the `RefreshInitiator` lambdas must capture the manager by reference and therefore cannot be built until the manager object exists.

#### Initialize()

Called once per manager after all SharkBytes have been registered. Iterates over the configured `ExtensionIdRead` entries and registers J1939 handlers:

- **Unsupported Extension IDs** — `IsExtensionIdSupported()` checks against a hardcoded list (`0xF019`, `0xF01A`). Extension IDs not on this list are skipped with a warning log; no handlers are registered for them.
- **Handler deduplication** — a `std::set<unsigned>` ensures `RegisterReceiveHandlers()` is called only once per unique extension ID, even if multiple peer nodes share the same extension ID.

Two handlers are registered per unique extension ID via `RegisterReceiveHandlers(extensionId)`:
1. `RegisterExtensionIdCommandHandler(extensionId, readResponseHandler)` — handles ECM read responses, where the extension ID doubles as the 2-byte SCL command.
2. `RegisterExtensionIdCommandIdHandler(AcknowledgeResponse, extensionId, nackHandler)` — handles NACK responses.

#### Refresh()

Called when middleware requests a refresh on an ExtensionId SharkByte. Queues a `TransportProtocolRequest` via the synchronizer. The SharkByte is located at response time via `FindSharkByte()` using the pre-built `m_sharkByteMappings` vector.

```cpp
void Refresh(unsigned address, unsigned extensionId)
{
    auto const request = TransportProtocolRequest{
        RequestType::ExtensionId, address, extensionId};

    m_synchronizer.Add(request,
        [this](auto const& req) { SendReadRequest(req); });
}
```

#### SendReadRequest()

Called by the synchronizer on each retry attempt (up to 4 times with 250ms intervals). Constructs and transmits the PropA read request message:

1. Builds a 3-byte message: `[0x80][ExtId MSB][ExtId LSB]`
2. Sends via `IJ1939Wrapper::SendPropAMessage()`

The synchronizer's built-in retry mechanism handles the timing and retry count. If no response or NACK arrives after all retry attempts, the synchronizer silently removes the request.

#### ReadResponseHandler()

Invoked by the J1939 wrapper when a read response arrives:

1. Extracts the extension ID from the 2-byte message header (which doubles as the 2-byte SCL command)
2. Removes the request from the synchronizer
3. Calls `FindSharkByte()` to locate the associated SharkByte by address and extension ID
4. Calls `TransientSharkByte::Write()` with the raw payload bytes

#### NackHandler()

Invoked when a NACK is received:

1. Extracts the extension ID and error code from the NACK message
2. If error code is `0x0005` (retry later):
   - Calls `ITransportProtocolClientSynchronizer::RetryLaterIfCurrent()` to re-queue. The synchronizer moves the request to the back of its queue and resets retry parameters, giving it a fresh set of 4 retries when it returns to the front.
3. Otherwise (non-retryable error):
   - Removes from synchronizer
   - Calls `FindSharkByte()` to locate the associated SharkByte
   - Calls `TransientSharkByte::WriteInvalid()` on the SharkByte

#### Internal State: SharkByte Mappings

A `std::vector<SharkByteMapping>` holds the pre-built address/extensionId/SharkByte associations for all configured ExtensionId reads. Each `SharkByteMapping` is a public struct `{address, extensionId, sharkByte}`. The vector is populated once during `CreateInitializer()` and is read-only at runtime. `FindSharkByte()` performs a linear scan to locate the entry matching the received address and extension ID.

---

### 6.2 TransientSharkByte (Existing)

The existing `TransientSharkByte` in `utilities/Include/Utilities/SharkBytes/TransientSharkByte.h` is reused. It implements both `ISharkByte` and `IWriteSharkByte` and provides the transient value semantics needed for this feature:

- **`Refresh()`** — Invokes the stored `RefreshInitiator` lambda, passing itself (`*this`) by reference. The lambda is bound during creation to call `J1939ExtensionIdManager::Refresh(address, extensionId)`.
- **`Write(value)`** — Fires the `m_onNewValue` signal with the provided data, notifying all subscribers. Called by the manager when a successful response is received.
- **`WriteInvalid()`** — Fires the `m_onNewValue` signal with `std::nullopt`, notifying subscribers of an invalid/failed result. Called by the manager on timeout exhaustion or NACK failure.
- **`Value()`** — Always returns `std::nullopt`. The SharkByte is inherently transient — it does not cache values. Every `Write()` / `WriteInvalid()` call produces a fresh subscriber notification regardless of whether the data changed.

This is the same pattern used by `BdtClientWrapper::InitiateRead()`, where the BDT wrapper receives a `TransientSharkByte&` and calls `Write()` / `WriteInvalid()` on completion.

---

### 6.3 ITransportProtocolClientSynchronizer Integration (Existing)

The existing `ITransportProtocolClientSynchronizer` is reused. It provides two key mechanisms that the ExtensionId manager relies on:

**Built-in retry on no response** — The synchronizer's periodic `Update()` method calls `Send()` on the front request up to 4 times (`n_maxRetries`) at 250ms intervals (`n_timeout`). If no `Remove()` or `RetryLaterIfCurrent()` is called within those retries, the synchronizer silently removes the request. This directly implements the "retry up to 4 times if no response is received" requirement without the manager needing its own retry counter or timeout timer.

**`RetryLaterIfCurrent()` for NACK-driven retries** — When a NACK with error code `0x0005` is received, the manager calls `RetryLaterIfCurrent()`, which moves the current request to the back of the synchronizer's queue and resets the retry parameters. When the request returns to the front, it receives a fresh set of 4 retries. Since each NACK `0x0005` triggers another `RetryLaterIfCurrent()` call, this produces indefinite retries as long as the ECM continues to respond with `0x0005`.

Other characteristics:
- Queues `TransportProtocolRequest` entries with `RequestType::ExtensionId`
- Ensures only one outstanding request per address at a time (prevents bus contention)
- Shares the bus scheduling with `BasicRead` requests, ensuring fair access

---

## 7. Configuration

### 7.1 Protobuf Schema Extension

The following additions to the `SharkConfiguration.proto` are needed:

```protobuf
message PeerNode
{
    // ... existing fields ...

    message ExtensionId
    {
        message ExtensionIdRead
        {
            uint32 extension_id = 1;    // e.g. 0xF019, 0xF01A
            string middleware_id = 2;   // SharkByte ID for middleware
        }

        repeated ExtensionIdRead extension_id_reads = 1;
    }

    optional ExtensionId extension_id = 8;
}
```

### 7.2 Example Configuration

```json
{
  "j1939_data_links": [
    {
      "can_port": "CAN_PORT_0",
      "peer_nodes": [
        {
          "address": 0,
          "extension_id": {
            "extension_id_reads": [
              {
                "extension_id": 61465,
                "middleware_id": "ExtId_00_F019"
              },
              {
                "extension_id": 61466,
                "middleware_id": "ExtId_00_F01A"
              }
            ]
          }
        }
      ]
    }
  ]
}
```

### 7.3 SharkByte Naming Convention

ExtensionId SharkByte identifiers follow the pattern `ExtId_XX_YYYY`:
- `XX` — source address (hex, 2-digit, zero-padded)
- `YYYY` — extension ID (hex, 4-digit, zero-padded)

Examples:
- `ExtId_00_F019` — ExtensionId `0xF019` from source address `0x00`
- `ExtId_0A_F01A` — ExtensionId `0xF01A` from source address `0x0A`

---

## 8. Retry Logic

Retry logic is handled entirely by the `TransportProtocolClientSynchronizer`:

| Parameter | Value | Owner | Description |
|---|---|---|---|
| `n_maxRetries` | 4 | Synchronizer | Maximum times the synchronizer sends the front request before dropping it |
| `n_timeout` | 250ms | Synchronizer | Interval between retry attempts |
| NACK `0x0005` retry | Indefinite | Manager via `RetryLaterIfCurrent()` | Each NACK `0x0005` re-queues the request, giving it a fresh set of 4 retries |

The `J1939ExtensionIdManager` does **not** implement its own retry counting or timeout timers. It relies entirely on the synchronizer's built-in mechanisms.

---

## 9. Thread Safety

| Concern | Mitigation |
|---|---|
| `m_sharkByteMappings` access | The vector is populated once during construction and read-only thereafter; no locking is needed. |
| TransientSharkByte thread safety | `TransientSharkByte::Write()` and `WriteInvalid()` fire the boost signal directly. The manager ensures these are called from a consistent context (J1939 callback thread). |
| Synchronizer interactions | The `ITransportProtocolClientSynchronizer` manages its own internal synchronization. The synchronizer calls `SendReadRequest` from its periodic task thread; response/NACK handlers are called from the J1939 callback thread. |

---

## 10. Testability

The design supports thorough unit testing through interface injection:

| Interface | Test Strategy |
|---|---|
| **IJ1939Wrapper** | Mock to verify message construction, handler registration, and send behavior |
| **ITransportProtocolClientSynchronizer** | Mock to verify Add/Remove/RetryLaterIfCurrent interactions and to simulate the synchronizer's retry behavior by invoking the captured send lambda |
| **ISharkByteManager** | Mock to verify SharkByte registration during creation |
| **TransientSharkByte** | Verify `Write()` and `WriteInvalid()` are called at the correct times with correct data |

### Recommended Unit Test Cases

1. **ShouldBeCreated** — returns `true` when config has `extension_id`, `false` otherwise
2. **CreateInitializer** — creates correct number of managers and TransientSharkBytes
3. **Refresh** — queues request via synchronizer with correct `TransportProtocolRequest`
4. **SendReadRequest** — constructs correct 3-byte PropA message `[0x80, MSB, LSB]`
5. **Successful response** — removes request from synchronizer, calls `sharkByte.Write()` with raw payload bytes
6. **NACK 0x0005 retry** — calls `RetryLaterIfCurrent()` on the synchronizer
7. **NACK other error** — immediately calls `sharkByte.WriteInvalid()`, no retry
8. **No response (synchronizer retries exhausted)** — synchronizer stops calling `SendReadRequest` after 4 attempts; SharkByte receives no notification
9. **TransientSharkByte integration** — `Refresh()` invokes `RefreshInitiator` which calls manager
10. **Two concurrent refreshes** — a second refresh is issued before the first response arrives; the SharkByte receives both response values in the correct order

### Recommended Functional Test Cases

1. Verify end-to-end refresh on CAN_PORT_0, address 0x00, ExtensionId 0xF019
2. Verify refresh on different CAN ports and addresses
3. Verify retry-on-timeout exhaustion produces no SharkByte notification
4. Verify NACK 0x0005 retries indefinitely
5. Verify NACK with non-0x0005 error immediately invalidates SharkByte
6. Verify successful response populates SharkByte with raw payload bytes

---

## 11. File Reference

| File | Description |
|---|---|
| `shark/Source/J1939/J1939ExtensionIdManager.h` | New — Manager class declaration |
| `shark/Source/J1939/J1939ExtensionIdManager.cpp` | New — Manager implementation |
| `utilities/Include/Utilities/SharkBytes/TransientSharkByte.h` | Existing — Transient SharkByte (refresh + write) |
| `utilities/Source/TransientSharkByte.cpp` | Existing — TransientSharkByte implementation |
| `shark/Source/J1939/IJ1939Wrapper.h` | Existing — J1939 wrapper interface |
| `shark/Source/J1939/ITransportProtocolClientSynchronizer.h` | Existing — Synchronizer interface |
| `shark/Tests/J1939/J1939ExtensionIdManagerTests.cpp` | New — Unit tests |
| `shark/FunctionalTests/J1939ExtensionIdFunctionalTests.cpp` | New — Functional tests (Tx, DeviceId) |
| `shark/FunctionalTests/J1939ExtensionIdRxFunctionalTests.cpp` | New — Functional tests (ExtensionId Read / Rx) |

---

## 12. Acceptance Criteria Traceability

| Acceptance Criterion | Design Element |
|---|---|
| Refresh can be performed on a configured SharkByte to send an ExtensionId read | `TransientSharkByte::Refresh()` → `RefreshInitiator` lambda → `J1939ExtensionIdManager::Refresh()` → synchronizer → `SendReadRequest()` |
| Different CAN ports and J1939 nodes supported | One `J1939ExtensionIdManager` per CAN port; protobuf config specifies `can_port` and per-`PeerNode` `address` |
| ExtensionId read retried up to 4 times on no response | `TransportProtocolClientSynchronizer::Update()` calls `SendReadRequest` up to 4 times (`n_maxRetries`) at 250ms intervals (`n_timeout`). No manager-level retry logic needed. |
| NACK 0x0005 retried indefinitely | `NackHandler()` checks error code `0x0005` and calls `RetryLaterIfCurrent()`, which re-queues the request with fresh retry parameters. Each NACK `0x0005` triggers another re-queue. |
| SharkByte invalidated after timeout cases | `NackHandler()` calls `sharkByte.WriteInvalid()` on non-retryable NACK errors. For no-response exhaustion, the synchronizer silently drops the request; the SharkByte receives no notification. |
| Valid response populates SharkByte | `ReadResponseHandler()` calls `FindSharkByte()` to locate the associated SharkByte, then calls `sharkByte.Write(payloadBytes)` with the raw payload bytes |
| Transient SharkByte — refresh shows good or bad even on repeat | `TransientSharkByte::Value()` always returns `std::nullopt`; every `Write()` / `WriteInvalid()` fires a fresh subscriber notification |
