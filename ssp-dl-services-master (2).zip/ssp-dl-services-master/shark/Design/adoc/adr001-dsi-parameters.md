# ADR 001: Retrieving DSI values for middleware parameters for PID's from Data Link Engine

## Date
07-24-2025

## Status
Approved

## Context
Many PID's coming from the data link will include a DSI status as part of the protocol. This typically indicates some kind of error state. The overwhelming majority of the time we care about whether or not the parameter has a value, but in a few rare cases (approximately 109 times over 28 applications in D6) our clients care about which *specific* DSI status a parameter has. This can be used to drive special indicators, for example.

We need some mechanism that a client can use to retrieve the DSI status for each parameter they require it for. On D6 we automatically created a SharkByteName_Status shark byte for each and every PID we retrieve. This results in thousands of extra shark bytes being created that are never referenced. While that sounds unnecessary, it was simple and never really caused us any noticeable problems.

## Decision
Require Specific Configuration to Create a DSI Parameter For All DSI Statuses (one parameter for all DSI statuses)

## Rationale

### Options Considered:
1. **Always Create DSI Status Parameters**:
We can go forward with the D6 solution. This has the advantage that we don't need any specific config, or any changes to Data Link Engine. It has the disadvantage that we created likely hundreds of unused middleware parameters on each system. I am not sure if there is really a cost to that. Could be a good MVP solution.

2. **Require Specific Configuration to Create a DSI Parameter For All DSI Statuses**:
Enabling a DSI parameter through configuration would allow us to target which parameters we actually care about, which is only a small handful even for machines that care (and not all machines care). It makes Data Link Engine more complex and requires more complexity in the configuration, though it means we don't have as many useless parameters being created.
It could also be nice that we are being so explicit from the configuration - users can read the configuration and understand if they change the data source from a PID to an SPN that they'll be losing an important piece of data they need to source from a new location. Perhaps that would already be flagged by a configuration validation tool?

3. **Require Specific Configuration to Create a DSI Parameter For Each DSI Status**:
The maximal configuration and complexity solution. All of the same benefits and costs as 2, except we have the additional explicit declaration of which DSI values we actually care about.

This might be a bridge too far for Data Link Engine, but might make more sense in an eventual "parameter decorator" application that can manipulate and aggregate data values.

4. **Embed DSI directly into middleware parameter**:
Another option would be to embed this directly into our Middleware Parameter service or into the message itself. The biggest advantage this brings is the atomicity of sending the data at the same time as the DSI, so that there's no chance that one message gets dropped or there's a big time desync between the messages being sent/handled.

The disadvantage of this approach is that we either have to build Data Link Engine domain directly into Middleware, or else everybody communicating with Data Link Engine will need to use a custom error case. It also implies that every message could contain a DSI, when in all likelihood the vast majority of parameters will not care about DSI status.

This seems like a potentially useful end state if the potential problems with not sending the messages atomically need to be addressed in the future.

## Conclusion:
Explain in detail why you made that decision

## Pros and Cons

### Pros
    - Only get the DSI parameters you actually need
	- Applications can't rely on parameters that configuration owners don't know about
    - Explicit configuration reduces likelihood of a surprise when changing configuration

### Cons
    - Data Link Engine is more complex
    - Configuration is more complex
    - If we don't have a mapping solution in the middle, it will leak the DSI status details to client applications
    - Clients will need to request additional parameters from configuration owner for DSI level