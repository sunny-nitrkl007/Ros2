# Architecture

Basic idea: Each CAN port gets its own set of managers and wrappers, organized under the UberWrapper.

```
J1939UberWrapper
├── J1939Wrapper[Can0] (scl_j1939_link_t link0)
│   ├── J1939PgbManager[Can0]
│   ├── J1939AdtManager[Can0]
│   ├── PgnHelper[Can0]
│   └── ...[Can0]
├── J1939Wrapper[Can1] (scl_j1939_link_t link1)
│   ├── J1939PgbManager[Can1]
│   ├── J1939AdtManager[Can1]
│   ├── PgnHelper[Can1]
│   └── ...[Can1]
└── Shared: OelWrapper, DependencyContainer, ...
```

There are a lot of singletons used in the Managers for convenience. These will need to be reworked so that the common callback can be used to pick the correct Manager through a singleton container of Managers. This could be done multiple ways:
1. Add the CAN enum value to the context
2. Add the index to the context (different from #1 since, say, CAN2 and CAN4 might be configured)
3. Add the Manager pointer to the context

This will be set up in the Managers' Initializer methods.

## Entities that are unique per CAN port

| Entity | Notes |
|--------|-------|
| J1939Wrapper Task Work Queue |  |
| SlotManager | All methods already take CanPort |
| PgnHelper | There is no context so PgnHelper::ReceiveHandler needs to map the link to a specific PgnHelper |
| J1939AdtManager | |
| J1939Wrapper | |

More to analyze: ...

## Entities that are Shared for all CAN ports

| Entity | Notes |
|--------|-------|
| DependencyContainer::GetIJ1939Wrapper | Needs to take can port |
| DependencyContainer::<expose all valid CAN link configs> | Used by Xxx::ShouldBeCreated() and more... |
| J1939UberWrapper | Calls scl_j1939_periodic_ctrl_task which handles all links |
| J1939AdtManager::ReceiveHandler | Need to add an identifier to the callback context to map to a specific J1939AdtManager::Manager |
| IJ1939PublicDataReceiver | Already takes CAN port |
| IPidDataReceiver | Already takes CAN port |
| IPeriodicTaskManager | This is the common, shared OEL interface |

## Compromises

1. For now, Codes will only work on a single CAN port. This allows us to keep the codes infrastructure almost entirely unchanged.
