/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See MockISharkByte.h

#include "Shark/Mocks/MockISharkByte.h"
#include "Utilities/Conversions.h"

namespace Shark
{
namespace Mocks
{
MockISharkByte::MockISharkByte()
{
	using namespace ::testing;
	ON_CALL(*this, Describe()).WillByDefault(Return("mock"));
}
MockISharkByte::~MockISharkByte() = default;

struct MockSharkByteWrapper::Impl
{
	Impl(Shark::SharkByteValue const& initialValue)
		: value(initialValue)
	{
		using namespace ::testing;

		ON_CALL(mockSharkByte, Id())
			.WillByDefault(ReturnRef(id));
		ON_CALL(mockSharkByte, Value())
			.WillByDefault(ReturnPointee(&value));
		ON_CALL(mockSharkByte, SubscribeToValues(NotNull()))
			.WillByDefault(Invoke(this, &Impl::Subscribe));
	}

	Shark::SharkByteId id;
	Shark::SharkByteValue value;
	::testing::NiceMock<MockISharkByte> mockSharkByte{};
	boost::signals2::signal<void(Shark::SharkByteValue const&)> signal{};
private:
	Shark::SharkByteSubscription Subscribe(boost::function<void(Shark::SharkByteValue const&)> const& callback)
	{
		assert(callback);

		Shark::SharkByteSubscription subscription{signal.connect(callback), mockSharkByte};
		callback(value);
		return subscription;
	}
};

MockSharkByteWrapper::MockSharkByteWrapper()
	: MockSharkByteWrapper(std::nullopt)
{
}
// RDO
// MockSharkByteWrapper::MockSharkByteWrapper(char const* pValue)
// 	: MockSharkByteWrapper(std::string{pValue})
// {
// }
MockSharkByteWrapper::MockSharkByteWrapper(SharkByteValue const& value)
	: m_spImpl(std::make_unique<Impl>(value))
{
}
MockSharkByteWrapper::MockSharkByteWrapper(MockSharkByteWrapper&& wrapper)
	: m_spImpl(std::move(wrapper.m_spImpl))
{
}
MockSharkByteWrapper::~MockSharkByteWrapper() = default;
MockISharkByte& MockSharkByteWrapper::GetMock() { return m_spImpl->mockSharkByte; }
// void MockSharkByteWrapper::SetValue(char const* pNewValue)
// {
// 	assert(pNewValue);
// 	SetValue(std::string{pNewValue});
// }
void MockSharkByteWrapper::SetValue(Shark::SharkByteValue const& newValue)
{
	m_spImpl->value = newValue;
	m_spImpl->signal(m_spImpl->value);
}
// void MockSharkByteWrapper::SetValue(bool value)
// {
// 	SetValue(To<std::vector<uint8_t>>(value));
// }
void MockSharkByteWrapper::SetInvalid()
{
	SetValue(std::nullopt);
}
Shark::SharkByteValue const& MockSharkByteWrapper::Value() const { return m_spImpl->value; }
bool MockSharkByteWrapper::HasSubscribers() const { return !m_spImpl->signal.empty(); }
void MockSharkByteWrapper::ExpectThatSubscribeOccurs(std::function<void(void)> const& codeUnderTest)
{
	using namespace ::testing;
	EXPECT_CALL(GetMock(), SubscribeToValues(_));
	codeUnderTest();
}
void MockSharkByteWrapper::ExpectThatUnsubscribeOccurs(std::function<void(void)> const& codeUnderTest)
{
	EXPECT_CALL(GetMock(), OnUnsubscribed());
	codeUnderTest();
	::testing::Mock::VerifyAndClearExpectations(&GetMock()); // Destructor would clear it after this
}
}
}