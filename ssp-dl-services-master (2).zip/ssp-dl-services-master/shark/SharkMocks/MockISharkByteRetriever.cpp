/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See MockISharkByteRetriever.h

#include "Shark/Mocks/MockISharkByteRetriever.h"

namespace Shark
{
namespace Mocks
{
ImplementConstructorAndDestructor(MockISharkByteRetriever);
}
}