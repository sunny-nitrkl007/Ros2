/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See MockIShark.h

#include "Shark/Mocks/MockIShark.h"

namespace Shark
{
namespace Mocks
{
ImplementConstructorAndDestructor(MockIShark);
}
}