/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See MockIWriteSharkByteRetriever.h

#include "Shark/Mocks/MockIWriteSharkByteRetriever.h"

namespace Shark
{
namespace Mocks
{
ImplementConstructorAndDestructor(MockIWriteSharkByteRetriever);
}
}