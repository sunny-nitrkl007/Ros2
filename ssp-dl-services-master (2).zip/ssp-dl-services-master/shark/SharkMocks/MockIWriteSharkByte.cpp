/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See MockIWriteSharkByte.h

#include "Mocks/MockIWriteSharkByte.h"

namespace Shark
{
namespace Mocks
{
MockIWriteSharkByte::MockIWriteSharkByte()
{
	using namespace ::testing;
	ON_CALL(*this, Id())
		.WillByDefault(ReturnRefOfCopy(std::string{"any id"}));
}
MockIWriteSharkByte::~MockIWriteSharkByte() = default;
}
}