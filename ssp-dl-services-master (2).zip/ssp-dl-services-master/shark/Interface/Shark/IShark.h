/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark top-level interface

#pragma once

#include "ISharkByteRetriever.h"
#include "IWriteSharkByteRetriever.h"

namespace Shark
{
class IShark
{
public:
	virtual ~IShark() = default;

	virtual char const* Name() const noexcept = 0;
	virtual ISharkByteRetriever const& GetSharkByteRetriever() const = 0;
	virtual IWriteSharkByteRetriever const& GetWriteSharkByteRetriever() const = 0;
};
}
