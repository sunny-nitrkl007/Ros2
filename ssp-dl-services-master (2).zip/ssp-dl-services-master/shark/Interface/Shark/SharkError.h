/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Error Exception

#pragma once

#include <stdexcept>

namespace Shark
{
class SharkError final : public std::runtime_error
{
public:
	SharkError(std::string const& actualWhat)
		: std::runtime_error(actualWhat)
	{
	}
};
}
