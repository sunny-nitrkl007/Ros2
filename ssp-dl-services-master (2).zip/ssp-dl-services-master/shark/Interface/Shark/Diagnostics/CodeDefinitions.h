/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Code Definitions

#pragma once

#include "Utilities/CountOf.h"
#include "Utilities/ToUnderlying.h"
#include <cassert>
#include <ostream>

namespace Shark
{
namespace Diagnostics
{
enum class CodeType : unsigned
{
	EddtDiagnostic,
	EddtEvent,
	PublicDtc,

	Count
};
inline std::ostream& operator<<(std::ostream& stream, Shark::Diagnostics::CodeType codeType)
{
	static constexpr char const* s_toString[]
	{
		"Diagnostic",
		"Event",
		"PublicDtc",
	};

	auto const sharkCodeTypeValue = Utilities::ToUnderlying(codeType);
	assert(sharkCodeTypeValue< Utilities::CountOf(s_toString));
	return stream << s_toString[sharkCodeTypeValue];
}
enum class CodeStatus : unsigned
{
	None,
	Active,
	Logged,
	ActiveAndLogged,

	Count,
	Invalid
};

inline bool IsLogged(CodeStatus status)
{
	return (status == CodeStatus::Logged) || (status == CodeStatus::ActiveAndLogged);
}
}
}
