/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Write Shark Byte Retriever Interface

#pragma once

#include "IWriteSharkByte.h"
#include "Utilities/DefineExceptionClass.h"
#include "Utilities/nice_ptr.h"

namespace Shark
{
class IWriteSharkByteRetriever
{
public:
	virtual ~IWriteSharkByteRetriever() = default;

	DEFINE_EXCEPTION_CLASS(NotFound);

	/// \exception IWriteSharkByteRetriever::NotFound
	///            Thrown when id is not found
	virtual IWriteSharkByte& Retrieve(SharkByteId const& id) const = 0;

	/// Implementations may override this with an optimized implementation.
	virtual std::optional<Utilities::nice_ptr<IWriteSharkByte>> TryRetrieve(SharkByteId const& id) const
	{
		std::optional<Utilities::nice_ptr<IWriteSharkByte>> writeSharkByte{};
		try
		{
			writeSharkByte = &Retrieve(id);
		}
		catch (NotFound const&)
		{
		}
		return writeSharkByte;
	}
};
}
