/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken SCL Obd Interfaces

#pragma once

#include <scl_obd_es.h>
#include <scl_obd_handle_gen.h>
#include <memory>

namespace Shark
{
namespace Kraken
{
class ISclObd
{
public:
	virtual ~ISclObd() = default;

	virtual scl_obd_es_t* scl_obd_es_init(
		const scl_obd_es_config_t* config_init,
		bool_t reset_persistent_data,
		scl_obd_es_error_t* error) = 0;
	virtual scl_obd_handle_gen_t* scl_obd_handle_gen_init(void) = 0;
	virtual scl_obd_test_handle_t scl_obd_handle_gen_get(scl_obd_handle_gen_t* this_) = 0;
	virtual scl_obd_es_error_t scl_obd_es_register_test(
		scl_obd_es_t* this_,
		scl_obd_test_handle_t test_handle,
		const scl_obd_es_test_config_t* test_config) = 0;
	virtual scl_obd_es_error_t scl_obd_es_update(scl_obd_es_t* this_) = 0;
	virtual scl_obd_es_error_t scl_obd_es_notify_test_results(
		scl_obd_es_t* this_,
		scl_obd_test_handle_t test_handle,
		scl_obd_es_test_results_t test_results) = 0;
	virtual scl_obd_es_error_t scl_obd_es_get_fault_rep(
		scl_obd_es_t* this_,
		scl_obd_test_handle_t test_handle,
		scl_obd_es_fault_rep_t* fault_report) = 0;
	virtual void scl_obd_es_keyswitch_status(
		scl_obd_es_t *this_,
		bool_least_t keyswitch_on) = 0;
	virtual bool_least_t scl_obd_es_ok_to_shutdown(
		scl_obd_es_t *this_) = 0;
	virtual scl_obd_es_error_t scl_obd_es_remove_unregistered_faults(
		scl_obd_es_t* this_,
		scl_obd_persistent_id_t* buffer,
		uint_least16_t buffer_size,
		uint_least16_t* number_of_entries) = 0;
};
void SetISclObd(std::shared_ptr<ISclObd> const& spSclObd);
}
}
