/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken clock interface

#pragma once

#include <clock_proto.h>
#include <clock_rtc_sec.h>
#include <clock_tm_zone_proto.h>
#include <memory>

namespace Shark
{
namespace Kraken
{
class IClock
{
public:
	virtual ~IClock() = default;

	virtual clock_result_t clock_ginit() = 0;
	virtual clock_result_t clock_go() = 0;
	virtual clock_result_t clock_runservice(clock_runstatus_t go) = 0;
	virtual clock_time_t clock_getservice_sec() = 0;
	virtual clock_result_t clock_setservice_sec(clock_time_t newtime) = 0;
	virtual clock_result_t clock_update() = 0;
	virtual clock_result_t clock_rtc_init() = 0;
	virtual clock_result_t clock_rtc_init_v2() = 0;
	virtual clock_result_t clock_getreal_struct_tm2 ( struct clock_tm *a,bool_least_t *is_secured ) = 0;
	virtual clock_result_t clock_tzone_init(NVM_block_handle_t time_zone_handle) = 0;
	virtual clock_result_t clock_tzone_init_v2(unsigned_32 tzone_block_id) = 0;
	virtual clock_result_t clock_tzone_get(tzone_tx_comm_struct *tzone_comm_ptr,bool_least_t *is_secured) = 0;
	virtual clock_result_t clock_tzone_set(tzone_rcv_comm_struct *tzone_comm_ptr,bool_least_t is_secured) = 0;
	virtual clock_result_t clock_tzone_get_local_tm2(struct clock_tm *curr_local_tm, bool_least_t *is_secured) = 0;
	virtual bool_least_t clock_rtc_sec_fps_config(
		scl_fps_rc_token_ifc_t* hdlr_get_feat_token,
		void* get_feat_token_context,
		clock_fps_feat_token_increment* hdlr_inc_feat_token,
		void* inc_feat_token_context) = 0;
	virtual clock_result_t clock_rtc_sec_init(const clock_rtc_sec_config_t *rtc_sec_config) = 0;
	virtual void clock_rtc_set_sec_enabled(bool_least_t security_status) = 0;
	virtual clock_result_t clock_rtc_configure_time_adj(unsigned_32 slew_rate_ms, unsigned_32 slew_limit_ms) = 0;
	virtual clock_tm* clock_tzone_get_local_tm() = 0;
};
void SetIClock(std::shared_ptr<IClock> const& spClock);
}
}
