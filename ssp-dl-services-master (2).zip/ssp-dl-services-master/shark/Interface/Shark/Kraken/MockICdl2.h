/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock ICdl2 accessors

#pragma once

#include "Cdl2.h"
#include <gmock/gmock.h>

namespace Shark
{
namespace Kraken
{
class MockICdl2 : public ICdl2
{
public:
	MOCK_METHOD(void, cdl2_ginit, (), (override));
	MOCK_METHOD(int_32, cdl2_transmit_ginit, (), (override));
	MOCK_METHOD(void, cdl_rcv_did_set, (boolean_t val, unsigned_8 lo_did, unsigned_8 hi_did), (override));
	MOCK_METHOD(void, cdl_default_mid_set, (unsigned_8 mid), (override));
	MOCK_METHOD(int_32, cdl2_cbs_ginit, (
		unsigned_8 harness_code, 
		cdl2_cbs_system_cfg_t* system_table_ptr,
		cdl2_cbs_ecm_cfg_t* ecm_table_ptr, 
		cdl2_cbs_parm_cfg_t* parm_tbl_ptr, 
		cdl2_cbs_input_tbl_t* input_tbl_ptr,
		cdl2_cbs_get_func_ptr_t get_fnc_ptr,
		cdl2_cbs_get_data_ptr_t get_data_ptr), (override));
	MOCK_METHOD(void, cdl2_receive_main, (), (override));
	MOCK_METHOD(
		int_16, cdl2_add_to_con_rx_pit, (unsigned_32 new_data_ID, cdl2_con_rx_hdlr_t *new_hdlr, void const *new_pie), (override));
	MOCK_METHOD(int_16, cdl2_add_to_tx_pit, (unsigned_32 new_data_ID, cdl2_tx_hdlr_t *new_hdlr, void const *new_pie), (override));
	MOCK_METHOD(int_16, cdl2_add_to_wr_pit, (unsigned_32 new_data_ID, Cdl_wr_hdlr_t *new_hdlr, void const *new_pie), (override));
};
}
}
