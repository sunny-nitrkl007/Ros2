/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IJ1939

#pragma once

#include "SclJ1939.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockIJ1939 : public IJ1939
{
	EnsureMockKindIsSpecifiedWithoutADefaultDefinition(MockIJ1939);
public:
	struct Default
	{
		static constexpr scl_j1939_link_t Link() { return 0; }
	};

	MockIJ1939();

	MOCK_METHOD(boolean_t, scl_j1939_set_num_links, (
		unsigned_8  Pu8_num_links), (override));

	MOCK_METHOD(scl_j1939_link_t, scl_j1939_establish_link, (
		volatile hal_canv3_port_t* Ppst_port,
		const scl_j1939_addr_tbl_t*   Ppast_address_table,
		const unsigned_8 Pu8_num_in_address_table,
		const unsigned_16       Pu16_num_of_mbufs,
		const unsigned_16       Pu16_num_of_extensions,
		const unsigned_16       Pu16_numb_of_tpcbs,
		const unsigned_8        Pu8_max_net_size,
		scl_j1939_ac_status_cb_t*  Ppfn_ac_status_cb,
		const scl_j1939_config_t* Ppst_j1939_config), (override));

	MOCK_METHOD(boolean_t, scl_j1939_set_ppgn_enable_table, (
		const scl_j1939_link_t        Ph_link,
		const int_8             Pi8_ppgn_enable_size,
		const scl_j1939_ppgn_enable_t  Past_ppgn_enable_tbl[]), (override));

	MOCK_METHOD(boolean_t, scl_j1939_set_max_dm13_clients, (
		unsigned_8 max_stop_bcast_clients,
		unsigned_8 max_suspend_clients,
		boolean_t (*is_sbcast_allowed_cb)(void)), (override));

	MOCK_METHOD(boolean_t, scl_j1939_install_dm13, (
		scl_j1939_link_t link,
		unsigned_8 ecm_index), (override));

	MOCK_METHOD(boolean_t, scl_j1939_add_suspend_client, (
		scl_j1939_suspend_cb_t *suspend_cb,
		void *context), (override));

	MOCK_METHOD(void, scl_j1939_init_tasks, (
		const int_16   Pi16_task_period), (override));

	MOCK_METHOD(boolean_t, scl_j1939_cmgr_init, (
		scl_j1939_link_t link,
		unsigned_8 num_connections,
		unsigned_8 num_services_per_connection), (override));

	MOCK_METHOD(void, scl_j1939_periodic_ctrl_task, (), (override));

	MOCK_METHOD(boolean_t, scl_j1939_que_tx_msg_by_address, (
		const scl_j1939_link_t  Ph_link,
		const unsigned_32 Pu32_pgn,
		const unsigned_8  Pu8_priority,
		const unsigned_8  Pu8_da,
		const int_8       Pi8_ecm,
		const unsigned_8  Pau8_data[],
		const unsigned_16 Pu16_data_length), (override));

	MOCK_METHOD(boolean_t, scl_j1939_que_tx_msg_by_name, (
		const scl_j1939_link_t  Ph_link,
		const unsigned_32 Pu32_pgn,
		const unsigned_8  Pu8_priority,
		const unsigned_8  Pau8_dest_name[SCL_J1939_SHORTHAND_NAME_LEN],
		const int_8       Pi8_ecm,
		const unsigned_8  Pau8_data[],
		const unsigned_16 Pu16_data_length ), (override));

	MOCK_METHOD(bool_t, scl_j1939_cat_ppgn_id_install_command, (
		scl_j1939_link_t Ph_link,
		const SCL_J1939_CAT_PPGN_ID_HDLR_t *id_hdlr_blk), (override));

	MOCK_METHOD(bool_t, scl_j1939_cat_ppgn_id_install_command_id, (
		scl_j1939_link_t Ph_link,
		const SCL_J1939_CAT_PPGN_ID_HDLR_t *id_hdlr_blk), (override));

	MOCK_METHOD(unsigned_8, scl_j1939_add_tx_msg_table_entry, (
		const scl_j1939_link_t Ph_link,
		const unsigned_8 Pu8_ecm,
		const scl_j1939_tx_msg_t* Pst_tx_msg_entry,
		void* Ppv_context,
		scl_j1939_tx_msg_context_builder Ppfn_context_builder_cb), (override));

	MOCK_METHOD(scl_j1939_bldr_t*, scl_j1939_bldr_get_pgn, (
		scl_j1939_link_t Ph_link,
		unsigned_8 Pu8_ecm_index,
		unsigned_32 pgn,
		boolean_t address_by_name,
		unsigned_8 dest_address,
		const unsigned_8 *dest_short_name,
		unsigned_8 length,
		boolean_t *new_bldr), (override));

	MOCK_METHOD(boolean_t, scl_j1939_bldr_add_param, (
		scl_j1939_bldr_t *bldr,
		const scl_j1939_param_tx_config_t *config,
		boolean_t override_previous), (override));

	MOCK_METHOD(boolean_t, scl_j1939_set_rx_msg_send_request_bit, (
		const scl_j1939_link_t Ph_link,
		const int_8 Pi8_ecm,
		const unsigned_8 Pu8_tbl_idx), (override));

	MOCK_METHOD(unsigned_8, scl_j1939_add_rx_msg_table_entry, (
		const scl_j1939_link_t Ph_link,
		const unsigned_8 Pu8_ecm,
		const scl_j1939_rx_msg_t* Pst_rx_msg_entry,
		void* Ppv_context,
		scl_j1939_rx_msg_context_parser Ppfn_context_parser_cb), (override));

	MOCK_METHOD(boolean_t, scl_j1939_find_name_by_address, (
		const scl_j1939_link_t Ph_link,
		const unsigned_8 address,
		unsigned_8 Pau8_name[SCL_J1939_NAME_LEN]), (override));

	MOCK_METHOD(boolean_t, scl_j1939_get_first_nar_entry, (
		const scl_j1939_link_t Ph_link,
		scl_j1939_nar_entry_t* nar_entry,
		scl_j1939_nar_handle_t* nar_handle), (override));

	MOCK_METHOD(boolean_t, scl_j1939_get_next_nar_entry, (
		const scl_j1939_link_t Ph_link,
		scl_j1939_nar_entry_t* nar_entry,
		scl_j1939_nar_handle_t* nar_handle), (override));
};
}
}
