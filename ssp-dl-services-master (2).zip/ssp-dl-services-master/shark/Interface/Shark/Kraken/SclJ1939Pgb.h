/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken SCL J1939 PGB interface

#pragma once

#include <scl_pgb_j1939.h>
#include <memory>

namespace Shark
{
namespace Kraken
{

class IJ1939Pgb
{
public:
	virtual ~IJ1939Pgb() = default;

	virtual scl_pgb_j1939_t* scl_pgb_j1939_init(scl_j1939_link_t link) = 0;
	virtual bool_t scl_pgb_j1939_add_ecm(scl_pgb_j1939_t *itself, const scl_pgb_j1939_ecm_config_t *ecm_config) = 0;
	virtual bool_t scl_pgb_j1939_add_rx_grps
		(
			scl_pgb_j1939_t *itself,
			int_least8_t ecm_idx,
			uint_least8_t remote_addr,
			uint_least16_t num_rx_pids,
			const scl_pgb_j1939_rx_pid_cfg_ptr_t *rx_pid_table,
			scl_pgb_j1939_diag_contxt_tbl_t *diag_context_ptrs,
			uint_least16_t requested_periodic_rate,
			uint_least16_t requested_timeout,
			scl_pgb_j1939_event_clbk_t *event_clbk,
			void *event_context
		) = 0;
};
void SetIJ1939Pgb(std::shared_ptr<IJ1939Pgb> const& spJ1939Pgb);

}
}
