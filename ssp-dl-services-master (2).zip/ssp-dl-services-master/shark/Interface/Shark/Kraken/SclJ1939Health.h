/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken SCL J1939 Health interface

#pragma once

#include <scl_health_j39.h>
#include <scl_health_j39_fault_mgr_ifc.h>
#include <memory>

namespace Shark
{
namespace Kraken
{
class IJ1939Health
{
public:
	virtual ~IJ1939Health() = default;

	virtual scl_health_j39_error_t scl_health_j39_init() = 0;

	virtual scl_health_j39_error_t scl_health_j39_link_set_pgb_ptr(
		scl_health_j39_link_t* link_ptr,
		scl_pgb_j1939_t* pgb_ptr) = 0;

	virtual scl_health_j39_error_t scl_health_j39_link_set_adt_handle(
		scl_health_j39_link_t* link_ptr,
		scl_adt_j1939_link_handle_t handle) = 0;

	virtual scl_health_j39_error_t scl_health_j39_link_set_fault_mgr(
		scl_health_j39_link_t* link_ptr,
		const scl_health_j39_fault_mgr_ifc_t* fault_mgr_ifc,
		void* fault_mgr_ptr,
		void* no_comm_fault_ptr,
		void* config_err_fault_ptr) = 0;

	virtual scl_health_j39_link_t* scl_health_j39_add_link(
		scl_j1939_link_t j1939_link,
		const scl_health_j39_link_config_t* link_config,
		bool_t start,
		scl_health_j39_error_t* error_code) = 0;

	virtual scl_health_j39_ecm_t* scl_health_j39_link_add_ecm(
		scl_health_j39_link_t* link_ptr,
		uint_least8_t ecm_idx,
		const scl_health_j39_ecm_config_t* ecm_config,
		bool_t start,
		scl_health_j39_error_t* error_code) = 0;

	virtual scl_health_j39_peer_t* scl_health_j39_ecm_add_peer(
		scl_health_j39_ecm_t* ecm_ptr,
		const scl_health_j39_peer_config_t* peer_config,
		bool_least_t start,
		scl_health_j39_error_t* error_code) = 0;

	virtual scl_health_j39_grp_t* scl_health_j39_peer_add_rx_grps(
		scl_health_j39_peer_t* peer_ptr,
		uint_least16_t num_rx_pids,
		const scl_pgb_j1939_rx_pid_cfg_ptr_t* rx_pid_table,
		uint_least16_t requested_periodic_rate,
		uint_least16_t requested_timeout,
		uint_least16_t pgb_comm_delay,
		bool_t start_mon,
		bool_t begin_comm,
		scl_health_j39_error_t* error_code) = 0;

	virtual scl_health_j39_pgn_t* scl_health_j39_peer_add_rx_pgn(
		scl_health_j39_peer_t* peer_ptr,
		uint_least8_t msg_idx,
		uint_least16_t timeout,
		scl_health_j39_mon_type_t mon_type,
		const scl_health_j39_cum_config_t* cum_config,
		uint_least16_t num_ids,
		const scl_health_j39_id_and_type_t* id_list,
		bool_t start,
		scl_health_j39_error_t* error_code) = 0;

	virtual scl_health_j39_adt_grp_t* scl_health_j39_peer_add_adt_rx_grps(
		scl_health_j39_peer_t* peer_ptr,
		uint_least8_t num_rx_pids,
		const scl_adt_j1939_client_grp_pid_config_ptr_t* client_grp_pid_configs,
		bool_least_t dm13_support,
		uint_least16_t adt_comm_delay,
		bool_t start_mon,
		bool_t begin_comm,
		scl_health_j39_error_t* error_code) = 0;

	virtual scl_health_j39_error_t scl_health_j39_peer_get_qs(
		scl_health_j39_peer_t* peer_ptr,
		scl_health_j39_qs_t* qualified_status) = 0;

	virtual scl_health_j39_error_t scl_health_j39_link_start(scl_health_j39_link_t *link_ptr) = 0;

	virtual scl_health_j39_error_t scl_health_j39_link_pause(scl_health_j39_link_t *link) = 0;

	virtual scl_health_j39_error_t scl_health_j39_peer_start(scl_health_j39_peer_t *peer_ptr) = 0;

	virtual scl_health_j39_error_t scl_health_j39_peer_pause(scl_health_j39_peer_t *peer_ptr) = 0;

	virtual boolean_t scl_health_j39_peer_set_eval_delay(
		scl_health_j39_peer_t *peer_ptr,
		uint_least32_t eval_delay) = 0;
	virtual void scl_health_j39_adt_grp_set_timeout(
		scl_health_j39_adt_grp_t *grp,
		uint_least32_t timeout) = 0;
};
void SetIJ1939Health(std::shared_ptr<IJ1939Health> const& spJ1939Health);
}
}
