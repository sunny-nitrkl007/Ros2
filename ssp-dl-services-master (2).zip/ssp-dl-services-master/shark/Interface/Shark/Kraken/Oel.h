/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken OEL interface

#pragma once

#include <oel_u.h>
#include <oel_rtos_posix.h>
#include <memory>

namespace Shark
{
namespace Kraken
{

class IOel
{
public:
	virtual ~IOel() = default;

	virtual void oel_u_init(
	  oel_rtos_init_object_t const* never_used) = 0;
	virtual void oel_sys_init(
	   void) = 0;
	virtual void oel_rtos_startup_init(
	   void) = 0;
	virtual oel_rtos_status_t oel_rtos_task_get_context(
	   oel_rtos_task_context_t* context) = 0;
	virtual oel_rtos_status_t oel_rtos_event_pend(
		oel_rtos_task_context_t context,
		oel_rtos_event_t pend_events,
		oel_rtos_event_t* received_events) = 0;
	virtual oel_rtos_status_t oel_rtos_event_post(
	   oel_rtos_task_id_t task_id,
	   oel_rtos_event_t events) = 0;
	virtual oel_rtos_resource_t* oel_rtos_resource_pi_vnew() = 0;

	virtual uint_least32_t oel_u_crc_32(
		const uint_least8_t *buffer_ptr,
		size_t length,
		uint_least32_t initial_value) = 0;
};

void SetIOel(std::shared_ptr<IOel> const& spOel);
oel_rtos_posix_config_t const& GetOelConfig();

}
}
