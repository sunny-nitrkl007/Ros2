/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock ISclObd

#pragma once

#include "SclObd.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockISclObd : public ISclObd
{
	EnsureMockKindIsSpecified(MockISclObd);
public:
	MockISclObd()
	{
		using namespace ::testing;

		ON_CALL(*this, scl_obd_es_init(_, _, _))
			.WillByDefault(DoAll(
				SetArgPointee<2>(SCL_OBD_ES_SUCCESS),
				Return(reinterpret_cast<scl_obd_es_t*>(0x42))));
		ON_CALL(*this, scl_obd_handle_gen_init())
			.WillByDefault(Return(reinterpret_cast<scl_obd_handle_gen_t*>(0x42)));
		ON_CALL(*this, scl_obd_handle_gen_get(_))
			.WillByDefault(InvokeWithoutArgs(this, &MockISclObd::GetNextTestHandle));
		ON_CALL(*this, scl_obd_es_register_test(_, _, _))
			.WillByDefault(Return(SCL_OBD_ES_SUCCESS));
		ON_CALL(*this, scl_obd_es_get_fault_rep(_, _, _))
			.WillByDefault(Return(SCL_OBD_ES_SUCCESS));
		ON_CALL(*this, scl_obd_es_ok_to_shutdown(_))
			.WillByDefault(Return(TRUE));
		ON_CALL(*this, scl_obd_es_remove_unregistered_faults(_, _, _, _))
			.WillByDefault(Return(SCL_OBD_ES_SUCCESS));
	}

	MOCK_METHOD(scl_obd_es_t*, scl_obd_es_init, (
		const scl_obd_es_config_t* config_init,
		bool_t reset_persistent_data,
		scl_obd_es_error_t* error), (override));
	MOCK_METHOD(scl_obd_handle_gen_t*, scl_obd_handle_gen_init, (), (override));
	MOCK_METHOD(scl_obd_test_handle_t, scl_obd_handle_gen_get, (scl_obd_handle_gen_t* this_), (override));
	MOCK_METHOD(scl_obd_es_error_t, scl_obd_es_register_test, (
		scl_obd_es_t* this_,
		scl_obd_test_handle_t test_handle,
		const scl_obd_es_test_config_t* test_config), (override));
	MOCK_METHOD(scl_obd_es_error_t, scl_obd_es_update, (scl_obd_es_t* this_), (override));
	MOCK_METHOD(scl_obd_es_error_t, scl_obd_es_notify_test_results, (
		scl_obd_es_t* this_,
		scl_obd_test_handle_t test_handle,
		scl_obd_es_test_results_t test_results), (override));
	MOCK_METHOD(scl_obd_es_error_t, scl_obd_es_get_fault_rep, (
		scl_obd_es_t* this_,
		scl_obd_test_handle_t test_handle,
		scl_obd_es_fault_rep_t* fault_report), (override));
	MOCK_METHOD(void, scl_obd_es_keyswitch_status, (
		scl_obd_es_t* this_,
		bool_least_t keyswitch_on), (override));
	MOCK_METHOD(bool_least_t, scl_obd_es_ok_to_shutdown, (
		scl_obd_es_t* this_), (override));
	MOCK_METHOD(scl_obd_es_error_t, scl_obd_es_remove_unregistered_faults, (
		scl_obd_es_t* this_,
		scl_obd_persistent_id_t* buffer,
		uint_least16_t buffer_size,
		uint_least16_t* number_of_entries), (override));

private:
	scl_obd_test_handle_t GetNextTestHandle() {return ++m_testHandle;}
	scl_obd_test_handle_t m_testHandle{0};
};
}
}
