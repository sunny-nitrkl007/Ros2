/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken SCL J1939 proprietary eddt diagnostic interfaces

#pragma once

#include <scl_diag_pj1939.h>
#include <memory>

namespace Shark
{
namespace Kraken
{
class IDiagPJ1939
{
public:
	virtual ~IDiagPJ1939() = default;

	virtual scl_diag_pj1939_t* scl_diag_pj1939_init(
		const scl_diag_pj1939_config_t* config,
		scl_j1939_link_t link,
		int_least8_t ecm_idx,
		scl_obd_es_t* es,
		scl_obd_crit_t* crit,
		scl_diag_pj1939_error_t* error) = 0;
	virtual scl_diag_pj1939_error_t scl_diag_pj1939_register_fault(
		scl_diag_pj1939_t* itself,
		scl_obd_test_handle_t test_handle,
		const scl_eddt_fault_config_t* fault_config) = 0;
	virtual scl_diag_pj1939_error_t scl_diag_pj1939_update(scl_diag_pj1939_t* itself) = 0;
};
void SetIDiagPJ1939(std::shared_ptr<IDiagPJ1939> const& spDiagPJ1939);
}
}
