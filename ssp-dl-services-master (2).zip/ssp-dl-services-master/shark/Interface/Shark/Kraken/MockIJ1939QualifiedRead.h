/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IJ1939 Rw accessors

#pragma once

#include "SclJ1939QualifiedRead.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockIJ1939QualifiedRead : public IJ1939QualifiedRead
{
	EnsureMockKindIsSpecified(MockIJ1939QualifiedRead);
public:
	MOCK_METHOD(scl_qr_j1939_t*, scl_qr_j1939_init, (
		scl_j1939_link_t link,
		const scl_qr_j1939_config_t *config), (override));
	MOCK_METHOD(scl_qr_j1939_client_t*, scl_qr_j1939_add_client, (
		scl_qr_j1939_t *itself,
		int_least8_t ecm_idx,
		uint_least8_t max_remote_nodes), (override));
	MOCK_METHOD(bool_t, scl_qr_j1939_tx_request, (
		scl_qr_j1939_t *itself,
		int_least8_t ecm_idx,
		uint_least8_t remote_addr,
		uint_least32_t pid,
		scl_qr_j1939_pid_type_t pid_type,
		scl_qr_j1939_qualifier_type_t qualifier_type,
		scl_qr_j1939_datalink_endian_t datalink_endian,
		uint_least8_t data_length,
		scl_qr_j1939_data_sign_t data_sign,
		scl_qr_j1939_rqst_clbk_t *rqst_clbk,
		void *rqst_clbk_context), (override));
};
}
}
