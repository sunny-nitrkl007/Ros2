/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See MockISclCalClient.h

#include "MockISclCalClient.h"

namespace Shark
{
namespace Kraken
{
MockISclCalClient::MockISclCalClient()
{
}

MockISclCalClient::~MockISclCalClient() = default;
}
}
