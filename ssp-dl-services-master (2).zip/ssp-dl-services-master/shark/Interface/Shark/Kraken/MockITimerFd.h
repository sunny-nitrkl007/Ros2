/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock ITimerFd

#pragma once

#include "TimerFd.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockITimerFd : public ITimerFd
{
	EnsureMockKindIsSpecified(MockITimerFd);
public:
	MockITimerFd()
	{
		using namespace testing;
		ON_CALL(*this, timerfd_create(_, _))
			.WillByDefault(Return(-1));
	}

	MOCK_METHOD(int, timerfd_create, (clockid_t clock_id, int flags), (override));
	MOCK_METHOD(int, timerfd_settime, (int fd, int flags, const struct itimerspec* new_value, struct itimerspec* old_value), (override));
};
}
}
