/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken scl_info interface

#pragma once

#include <scl_dcm.h>
#include <memory>

namespace Shark
{
namespace Kraken
{

class ISclInfoDcm
{
public:
	virtual ~ISclInfoDcm() = default;

	virtual scl_dcm_error_state_t scl_dcm_init(
		const scl_dcm_config_t *config_data) = 0;

	virtual scl_dcm_error_state_t scl_dcm_add_j1939_link(
		scl_j1939_link_t link,
		uint_least8_t ecm_index,
		scl_dcm_link_id_t *link_index) = 0;

	virtual scl_dcm_error_state_t scl_dcm_register_peer(
		scl_dcm_link_id_t link_indx,
		const scl_dcm_peer_config_t *peer_cfg,
		scl_dcm_peer_id_t *peer_id) = 0;

	virtual scl_dcm_error_state_t scl_dcm_peer_get_num_codes(
		scl_dcm_peer_id_t peer_index,
		scl_dcm_tbl_code_type_t code_type,
		uint_least16_t *num_codes) = 0;

	virtual scl_dcm_error_state_t scl_dcm_read_diag_codes(
		scl_dcm_peer_id_t peer_id,
		scl_dcm_db_fault_s *buffer,
		uint_least16_t buffer_size,
		uint_least16_t *entries_filled) = 0;

	virtual scl_dcm_error_state_t scl_dcm_read_event_codes(
		scl_dcm_peer_id_t peer_id,
		scl_dcm_db_fault_s *buffer,
		uint_least16_t buffer_size,
		uint_least16_t *entries_filled) = 0;

	virtual scl_dcm_error_state_t scl_dcm_read_spn_codes(
		scl_dcm_peer_id_t peer_id,
		scl_dcm_db_fault_s *buffer,
		uint_least16_t buffer_size,
		uint_least16_t *entries_filled) = 0;

	virtual void scl_dcm_update() = 0;

	virtual scl_dcm_error_state_t scl_dcm_peer_request_ai(
		scl_dcm_peer_id_t peer_index,
		scl_dcm_req_msg_types_t req_type,
		uint_least32_t code,
		uint_least8_t wci,
		uint_least8_t fmi) = 0;

	virtual scl_dcm_error_state_t scl_dcm_register_own_peer(
		scl_dcm_link_id_t link_indx,
		const scl_dcm_peer_config_t* peer_cfg,
		scl_dcm_event_sys_type_t event_sys_type,
		scl_obd_es_t* obd_es_obj,
		void* data_link_obj,
		scl_dcm_peer_id_t* peer_id) = 0;

	virtual scl_dcm_error_state_t scl_dcm_peer_get_support_ai_grps(
		scl_dcm_peer_id_t peer_index,
		uint_least8_t* ai_group_buff,
		uint_least8_t buffer_size,
		uint_least8_t* filled_size) = 0;

	virtual scl_dcm_error_state_t scl_dcm_get_link_index(
		scl_dcm_peer_id_t peer_index,
		scl_dcm_link_id_t* link_index) = 0;

	virtual scl_dcm_error_state_t scl_dcm_get_peer_address(
		scl_dcm_peer_id_t peer_index,
		uint_least8_t* peer_address) = 0;

	virtual scl_dcm_peer_id_t scl_dcm_get_peer_index(
		scl_dcm_link_id_t link_index,
		uint_least8_t peer_address) = 0;

	virtual scl_dcm_error_state_t scl_dcm_peer_request_dm(
		scl_dcm_peer_id_t peer_index,
		scl_dcm_req_msg_types_t req_type) = 0;
};
void SetISclInfoDcm(std::shared_ptr<ISclInfoDcm> const& spSclInfoDcm);

}
}
