/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken timerfd interface

#pragma once

#include <memory>
#include <sys/timerfd.h>

namespace Shark
{
namespace Kraken
{
class ITimerFd
{
public:
	virtual ~ITimerFd() = default;

	virtual int timerfd_create(clockid_t clock_id, int flags) = 0;
	virtual int timerfd_settime(int fd, int flags, const struct itimerspec* new_value, struct itimerspec* old_value) = 0;
};

int timerfd_create(clockid_t clock_id, int flags);
int timerfd_settime(int fd, int flags, const struct itimerspec* new_value, struct itimerspec* old_value);

void SetITimerFd(std::shared_ptr<ITimerFd> const& spTimerFd);
}
}
