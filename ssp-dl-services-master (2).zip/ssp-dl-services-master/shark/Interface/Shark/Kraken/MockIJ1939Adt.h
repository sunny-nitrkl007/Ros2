/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IJ1939Adt

#pragma once

#include "SclJ1939Adt.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockIJ1939Adt : public IJ1939Adt
{
	EnsureMockKindIsSpecified(MockIJ1939Adt);
public:
	MOCK_METHOD(scl_adt_j1939_link_handle_t, scl_adt_j1939_link_init, (scl_j1939_link_t link), (override));
	MOCK_METHOD(bool_t, scl_adt_j1939_link_add_ecm, (scl_adt_j1939_link_handle_t adt_j1939_hndl, uint_least8_t ecm_idx), (override));
	MOCK_METHOD(uint_least8_t, scl_adt_j1939_link_add_group, (
		scl_adt_j1939_link_handle_t adt_j1939_hndl,
		uint_least8_t ecm_idx,
		uint_least8_t remote_addr,
		uint_least8_t num_of_pids,
		bool_least_t dm13_support,
		const scl_adt_j1939_client_grp_pid_config_ptr_t* client_grp_pid_configs,
		scl_adt_j1939_diag_contxt_tbl_t *diag_context_ptrs,
		scl_adt_j1939_event_clbk_t* event_callback,
		void* event_callback_context), (override));
	MOCK_METHOD(bool_t, scl_adt_j1939_client_grp_set_timeout, (
		scl_adt_j1939_link_handle_t adt_j1939_hndl,
		uint_least8_t ecm_idx,
		uint_least8_t remote_addr,
		uint_least8_t group_id,
		uint_least32_t timeout), (override));
};
}
}
