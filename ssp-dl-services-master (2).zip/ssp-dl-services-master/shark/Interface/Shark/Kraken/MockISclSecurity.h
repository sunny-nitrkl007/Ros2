/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock ISclSecurity

#pragma once

#include "Security.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockISclSecurity : public ISclSecurity
{
	EnsureMockKindIsSpecified(MockISclSecurity);
public:
	MockISclSecurity()
	{
		using namespace ::testing;

		ON_CALL(*this, scl_security_install_fps())
			.WillByDefault(Return(SCL_SECURITY_RET_VAL_SUCCESS));
		ON_CALL(*this, scl_security_install_passwd())
			.WillByDefault(Return(SCL_SECURITY_RET_VAL_SUCCESS));
	}
	MOCK_METHOD(scl_security_ret_val_t, scl_security_install_fps, (), (override));
	MOCK_METHOD(scl_security_ret_val_t, scl_security_install_passwd, (), (override));
	MOCK_METHOD(void, passwd_pkg_init, (PASSWD_Pkg_Work_t *work, PASSWD_Pkg_Config_t *config), (override));
	MOCK_METHOD(void, passwd_pkg_main, (PASSWD_Pkg_Work_t *work, PASSWD_Pkg_Config_t *config), (override));
	MOCK_METHOD(unsigned_8, passwd_get_seclvl, (), (override));
};
}
}
