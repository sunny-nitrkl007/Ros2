/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Kraken for scl security and fps interfaces

#pragma once

#include <passwd_proto.h>
#include <scl_fps.h>
#include <scl_fps_j1939.h>
#include <scl_security.h>
#include <memory>

namespace Shark
{
namespace Kraken
{
class ISclFps
{
public:
	virtual ~ISclFps() = default;

	virtual bool_t scl_fps_init(const scl_fps_cfg_t* fps_cfg) = 0;
	virtual scl_fps_key_result_t scl_fps_install_crypto_key(void* key_context) = 0;
	virtual void scl_fps_background() = 0;
};
void SetISclFps(std::shared_ptr<ISclFps> const& spSclFps);

class ISclFpsJ1939
{
public:
	virtual ~ISclFpsJ1939() = default;

	virtual scl_fps_j1939_link_t* scl_fps_j1939_link_init(
		scl_j1939_link_t link,
		scl_fps_j1939_link_config_t* link_config) = 0;
	virtual bool_t scl_fps_j1939_link_add_ecm(
		scl_fps_j1939_link_t *itself,
		int_least8_t ecm_idx,
		const scl_fps_j1939_ecm_config_t *j1939_ecm_config) = 0;
};
void SetISclFpsJ1939(std::shared_ptr<ISclFpsJ1939> const& spSclFpsJ1939);

class ISclSecurity
{
public:
	virtual ~ISclSecurity() = default;

	virtual scl_security_ret_val_t scl_security_install_fps() = 0;
	virtual scl_security_ret_val_t scl_security_install_passwd() = 0;
	virtual void passwd_pkg_init(PASSWD_Pkg_Work_t *work, PASSWD_Pkg_Config_t *config) = 0;
	virtual void passwd_pkg_main(PASSWD_Pkg_Work_t *work, PASSWD_Pkg_Config_t *config) = 0;
	virtual unsigned_8 passwd_get_seclvl() = 0;
};
void SetISclSecurity(std::shared_ptr<ISclSecurity> const& spSclSnmpd);
}
}

