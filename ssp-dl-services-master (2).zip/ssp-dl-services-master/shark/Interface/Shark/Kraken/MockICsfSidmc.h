/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock ICsfSidmc

#pragma once

#include "CsfSidmc.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockICsfSidmc : public ICsfSidmc
{
	EnsureMockKindIsSpecified(MockICsfSidmc);
public:
	MockICsfSidmc()
	{
		using namespace testing;
		ON_CALL(*this, csf_sidmc_init(_, _, _))
			.WillByDefault(Return(CSF_SIDMC_SUCCESS));
		ON_CALL(*this, csf_sidmc_cmd_req(_, _))
			.WillByDefault(Return(CSF_SIDMC_SUCCESS));
	}

	MOCK_METHOD(
		csf_sidmc_ret_type_t,
		csf_sidmc_init,
		(
			scl_j1939_link_t h_link,
			uint_least8_t ecm_indx,
			const csf_sidmc_config_t* p_config
		),
		(override));
	MOCK_METHOD(
		csf_sidmc_ret_type_t,
		csf_sidmc_cmd_req,
		(
			csf_sidmc_cmd_t sidmc_cmd,
			const csf_sidmc_key_info_t* key_info_ptr
		),
		(override));
	MOCK_METHOD(void, csf_sidmc_update, (), (override));
};
}
}
