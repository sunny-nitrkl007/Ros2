/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IBdt accessors

#pragma once

#include "Bdt.h"
#include <gmock/gmock.h>

namespace Shark
{
namespace Kraken
{
class MockIBdt : public IBdt
{
public:
	struct Default
	{
		static constexpr unsigned_8 J1939DatalinkHandle()    { return 1; }
		static constexpr unsigned_8 EthernetDatalinkHandle() { return 2; }
	};

	MockIBdt()
	{
		using namespace ::testing;

		ON_CALL(*this, bdt_set_callback_block_count(_)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_set_datatype_count(_)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_set_callback_block(_, _, _, _, _, _, _, _)).WillByDefault(Return(1));
		ON_CALL(*this, bdt_set_datatype(_, _)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_init(_, _, _, _, _)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_req_connection(_, _, _, _, _, _, _, _, _, _, _)).WillByDefault(Return(BDT_ERROR_NONE));
		ON_CALL(*this, bdt_set_report_error_hdlr(_, _)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_j1939_init(_)).WillByDefault(Return(Default::J1939DatalinkHandle()));
		ON_CALL(*this, bdt_action_init(_)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_eth_init(_, _)).WillByDefault(Return(Default::EthernetDatalinkHandle()));
		ON_CALL(*this, bdt_eth_req_connection(_, _, _, _, _, _, _, _, _)).WillByDefault(Return(BDT_ERROR_NONE));
		ON_CALL(*this, bdt_eth_set_report_error_hdlr(_, _)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_set_conn_status_hdlr_max_count(_)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_set_notify_conn_status_hdlr(_, _)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_eth_set_conn_status_hdlr_max_count(_)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_eth_set_notify_conn_status_hdlr(_, _)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_dl_datatype_accesslist_init(_)).WillByDefault(Return(TRUE));
		ON_CALL(*this, bdt_dl_datatype_accesslist_add(_, _)).WillByDefault(Return(TRUE));
	}

	MOCK_METHOD(boolean_t, bdt_set_callback_block_count, (unsigned_16 count), (override));
	MOCK_METHOD(boolean_t, bdt_set_datatype_count, (unsigned_16 count), (override));
	MOCK_METHOD(unsigned_16, bdt_set_callback_block, (
		bdt_query_index_supported_t bdt_query_index_supported,
		bdt_obtain_data_access_t bdt_obtain_data_access,
		bdt_release_data_access_t bdt_release_data_access,
		bdt_get_data_size_t bdt_get_data_size,
		bdt_open_data_t bdt_open_data,
		bdt_close_data_t bdt_close_data,
		bdt_get_data_t bdt_get_data,
		bdt_set_data_t bdt_set_data), (override));
	MOCK_METHOD(boolean_t, bdt_set_datatype, (unsigned_16 datatype, unsigned_16 handle), (override));
	MOCK_METHOD(void, bdt_set_period, (unsigned_32 period), (override));
	MOCK_METHOD(boolean_t, bdt_init, (unsigned_8 NumRxCon, unsigned_32 RxBufSize, unsigned_8 NumTxCon, unsigned_32 TxBufSize, unsigned_8 NumDatalinkCon), (override));
	MOCK_METHOD(void, bdt_main, (), (override));

	MOCK_METHOD(bdt_error_t, bdt_req_connection, (
		unsigned_8 type,
		unsigned_8 sid,
		unsigned_8 did,
		unsigned_16 datatype,
		unsigned_32 index,
		unsigned_32 size,
		unsigned_8 rate,
		bdt_app_info_t *app_info,
		unsigned_8 datalink_id,
		unsigned_8 encyption,
		unsigned_8 compress), (override));

	MOCK_METHOD(boolean_t, bdt_set_report_error_hdlr, (void *report_error_context, bdt_report_error_hdlr_t bdt_report_error_hdlr), (override));
	MOCK_METHOD(unsigned_8, bdt_j1939_init, (scl_j1939_link_t Ph_link), (override));
	MOCK_METHOD(void, bdt_j1939_set_resource, (const oel_rtos_resource_config_t *resource), (override));
	MOCK_METHOD(bool_t, bdt_action_init, (const bdt_action_config_t *config), (override));
	MOCK_METHOD(uint_least8_t, bdt_eth_init, (void *http_server, uint_least32_t fid), (override));
	MOCK_METHOD(bdt_error_t, bdt_eth_req_connection, (
		unsigned_8 type,
		unsigned_16 data_type,
		unsigned_32 data_idx,
		unsigned_32 ptxt_file_size,
		bdt_app_info_t* app_info,
		unsigned_8 encryption,
		unsigned_8 compression,
		unsigned_8 datalink_id,
		unsigned_32 server_fid), (override));
	MOCK_METHOD(bool_least_t, bdt_eth_set_report_error_hdlr, (bdt_eth_report_error_hdlr_t error_handler, void* report_context), (override));
	MOCK_METHOD(bdt_action_req_status_t, bdt_action_req_command, (
		bdt_action_cmd_id_t cmd_id,
		unsigned_8 sid,
		unsigned_8 did,
		unsigned_16 data_type,
		unsigned_32 data_index,
		bdt_action_resp_notify_t resp_notify,
		void* context,
		unsigned_8 datalink_id), (override));
	MOCK_METHOD(bdt_action_req_status_t, bdt_eth_action_req_command, (
		bdt_action_cmd_id_t cmd_id,
		unsigned_32 local_fid,
		unsigned_32 server_fid,
		unsigned_16 data_type,
		unsigned_32 data_index,
		bdt_eth_action_resp_notify_t resp_notify,
		void* context,
		unsigned_8 datalink_id), (override));
	MOCK_METHOD(boolean_t, bdt_set_conn_status_hdlr_max_count, (const unsigned_8 bdt_conn_status_hdlr_max_cnt), (override));
	MOCK_METHOD(boolean_t, bdt_set_notify_conn_status_hdlr, (void* conn_status_context, bdt_notify_conn_status_hdlr_t notify_conn_status_hdlr), (override));
	MOCK_METHOD(bool_least_t, bdt_eth_set_conn_status_hdlr_max_count, (uint_least8_t num_conn_status_hndlrs), (override));
	MOCK_METHOD(bool_least_t, bdt_eth_set_notify_conn_status_hdlr, (bdt_eth_notify_conn_status_hdlr_t conn_status_handler, void* conn_status_context), (override));
	MOCK_METHOD(bool_least_t, bdt_dl_datatype_accesslist_init, (unsigned_8 datalink_id), (override));
	MOCK_METHOD(bool_least_t, bdt_dl_datatype_accesslist_add, (unsigned_8 datalink_id, unsigned_16 datatype), (override));
};
}
}
