/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Kraken cdl2 interface

#pragma once

#include <cdl2_proto.h>
#include <memory>

namespace Shark
{
namespace Kraken
{

class ICdl2
{
public:
	virtual ~ICdl2() = default;

	virtual void cdl2_ginit() = 0;
	virtual int_32 cdl2_transmit_ginit() = 0;
	virtual void cdl_rcv_did_set(boolean_t val, unsigned_8 lo_did, unsigned_8 hi_did) = 0;
	virtual void cdl_default_mid_set(unsigned_8 mid) = 0;
	virtual int_32 cdl2_cbs_ginit(
		unsigned_8 harness_code, 
		cdl2_cbs_system_cfg_t* system_table_ptr,
		cdl2_cbs_ecm_cfg_t* ecm_table_ptr, 
		cdl2_cbs_parm_cfg_t* parm_tbl_ptr, 
		cdl2_cbs_input_tbl_t* input_tbl_ptr,
		cdl2_cbs_get_func_ptr_t get_fnc_ptr,
		cdl2_cbs_get_data_ptr_t get_data_ptr) = 0;
	virtual void cdl2_receive_main() = 0;

	virtual int_16 cdl2_add_to_con_rx_pit(unsigned_32 new_data_ID, cdl2_con_rx_hdlr_t *new_hdlr, void const *new_pie) = 0;
	virtual int_16 cdl2_add_to_tx_pit(unsigned_32 new_data_ID, cdl2_tx_hdlr_t *new_hdlr, void const *new_pie) = 0;
	virtual int_16 cdl2_add_to_wr_pit(unsigned_32 new_data_ID, Cdl_wr_hdlr_t *new_hdlr, void const *new_pie) = 0;
};

void SetICdl2(std::shared_ptr<ICdl2> const& spCdl2);

}
}

