/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken HAL interface

#pragma once

#include <hal_adci.h>
#include <hal_boot_proto.h>
#include <hal_canv3_port.h>
#include <hal_lcd.h>
#include <hal_power.h>
#include <hal_pulsei.h>
#include <hal_pulseo.h>
#include <hal_rtc.h>
// #include <ksw.h>
#include <memory>

namespace Shark
{
namespace Kraken
{
class IHal
{
public:
	virtual ~IHal() = default;

	virtual void hal_init() = 0;

	virtual void hal_canv3_port_set_resource(
		volatile hal_canv3_port_t *port,
		const oel_rtos_resource_config_t *resource_config) = 0;

	virtual void hal_pulseo_init() = 0;
	virtual hal_diagnostic_t hal_pulseo_get_diagnostics(hal_pulseo_channel_t channel) = 0;
	virtual void hal_pulseo_set_diag_enable(hal_pulseo_channel_t channel, hal_u08_t diagnostic_control) = 0;
	virtual void hal_pulseo_set_discrete(
		hal_pulseo_channel_t channel,
		hal_discrete_t discrete_command) = 0;
	virtual void hal_pulseo_set_rwave_period_pw(
		hal_pulseo_channel_t channel,
		hal_second_u32_l30_t period,
		hal_second_u32_l30_t pulse_width) = 0;

	virtual void hal_power_init() = 0;
	virtual hal_volt_s16_l07_t hal_power_get_voltage(hal_power_supply_t supply) = 0;
	virtual hal_diagnostic_t hal_power_get_diagnostics(hal_power_supply_t supply) = 0;

	virtual void hal_pulsei_init() = 0;
	virtual hal_discrete_t hal_pulsei_get_discrete(hal_pulsei_channel_t channel) = 0;

	virtual hal_cat_partno_t hal_boot_get_ecm_partno() = 0;
	virtual hal_ecm_serialno_t hal_boot_get_ecm_serialno() = 0;
	virtual hal_location_code_t hal_boot_read_location_code() = 0;

	virtual void hal_rtc_init() = 0;
	virtual hal_s32_t hal_rtc_wakeup_alarm_clear() = 0;
	virtual hal_s32_t hal_rtc_read(struct tm * const tp) = 0;

	virtual void hal_adci_init() = 0;
	virtual hal_s16_l05_t hal_adci_get_temperature(hal_adci_channel_t channel) = 0;

	virtual unsigned GetCpuCount() = 0;
};

void SetIHal(std::shared_ptr<IHal> const& spHal);
}
}
