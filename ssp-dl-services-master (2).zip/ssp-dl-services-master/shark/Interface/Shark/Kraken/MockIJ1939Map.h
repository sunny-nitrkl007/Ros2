/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IJ1939Map

#pragma once

#include "SclJ1939Map.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockIJ1939Map : public IJ1939Map
{
	EnsureMockKindIsSpecified(MockIJ1939Map);
public:
	MockIJ1939Map()
	{
		using namespace testing;

		ON_CALL(*this, scl_j1939_set_ma_client_configuration(_, _, _))
			.WillByDefault(Return(TRUE));
		ON_CALL(*this, scl_j1939_set_ma_configuration(_, _, _, _))
			.WillByDefault(Return(TRUE));
	}

	MOCK_METHOD(boolean_t, scl_j1939_set_ma_client_configuration, (
		scl_j1939_link_t                Ph_link,
		scl_j1939_ma_client_status_cb_t Ppfn_status_cb,
		unsigned_8                      Pu8_max_ma_sessions), (override));

	MOCK_METHOD(boolean_t, scl_j1939_set_ma_configuration, (
		scl_j1939_link_t Ph_link,
		int_8 Pi8_ma_param_size,
		const scl_j1939_ma_param_list_t *Past_ma_param_tbl,
		unsigned_8 Pu8_max_ma_sessions), (override));

	MOCK_METHOD(unsigned_8, scl_j1939_ma_client_transaction_by_address, (
		scl_j1939_link_t                 Ph_link,
		int_8                            Pi8_init_ecm,
		unsigned_8                       Pu8_target_ecm,
		unsigned_8                       Pu8_service,
		unsigned_8                       Pu8_param_type,
		unsigned_32                      Pu32_param,
		unsigned_16                      Pu16_length,
		scl_j1939_ma_trans_complete_cb_t Ppfn_trans_complete_cb,
		scl_j1939_ma_client_param_cb_t   Ppfn_parm_cb,
		boolean_t                        Pb_keep_alive), (override));
};
}
}
