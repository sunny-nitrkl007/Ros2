/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken csf_sidmc interface

#pragma once

#include <csf_sidmc.h>
#include <memory>

namespace Shark
{
namespace Kraken
{
class ICsfSidmc
{
public:
	virtual ~ICsfSidmc() = default;

	virtual csf_sidmc_ret_type_t csf_sidmc_init(
		scl_j1939_link_t h_link,
		uint_least8_t ecm_indx,
		const csf_sidmc_config_t* p_config) = 0;

	virtual csf_sidmc_ret_type_t csf_sidmc_cmd_req(
		csf_sidmc_cmd_t sidmc_cmd,
		const csf_sidmc_key_info_t* key_info_ptr) = 0;

	virtual void csf_sidmc_update() = 0;
};
void SetICsfSidmc(std::shared_ptr<ICsfSidmc> const& spCsfSidmc);
}
}
