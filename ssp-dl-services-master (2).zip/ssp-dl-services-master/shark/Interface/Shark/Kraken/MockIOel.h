/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IOel

#pragma once

#include "Oel.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockIOel : public IOel
{
	EnsureMockKindIsSpecified(MockIOel);
public:
	MOCK_METHOD(void, oel_u_init, (oel_rtos_init_object_t const* never_used), (override));
	MOCK_METHOD(void, oel_sys_init, (), (override));
	MOCK_METHOD(void, oel_rtos_startup_init, (), (override));
	MOCK_METHOD(oel_rtos_status_t, oel_rtos_task_get_context, (oel_rtos_task_context_t* context), (override));
	MOCK_METHOD(oel_rtos_status_t, oel_rtos_event_pend, (
		oel_rtos_task_context_t context,
		oel_rtos_event_t pend_events,
		oel_rtos_event_t* received_events), (override));
	MOCK_METHOD(oel_rtos_status_t, oel_rtos_event_post, (
	   oel_rtos_task_id_t task_id,
	   oel_rtos_event_t events), (override));
	MOCK_METHOD(oel_rtos_resource_t*, oel_rtos_resource_pi_vnew, (), (override));
	MOCK_METHOD(uint_least32_t, oel_u_crc_32, (
		const uint_least8_t *buffer_ptr,
		size_t length,
		uint_least32_t initial_value), (override));
};
}
}
