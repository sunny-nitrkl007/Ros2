/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock INvm accessors

#pragma once

#include "Nvm.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockINvm : public INvm
{
	EnsureMockKindIsSpecified(MockINvm);
public:
	MOCK_METHOD(unsigned_8, nvm_file_init, (unsigned_16 const max_blocks), (override));
	MOCK_METHOD(unsigned_8, nvm_file_block_cfg, (nvm_file_block_cfg_t const* block_config), (override));
	MOCK_METHOD(
		unsigned_8,
		nvm_block_init,
		( unsigned_8 block_type, unsigned_8* block_cache_ptr, unsigned_32 data_id, int block_priority, NVM_block_handle_t* block_handle_ptr),
		(override));
	MOCK_METHOD(
		unsigned_8,
		nvm_block_read,
		( NVM_block_handle_t block_handle, unsigned_32 read_size, unsigned_32 read_offset, unsigned_8* destination_ptr, int read_task_priority),
		(override));
	MOCK_METHOD(
		unsigned_8,
		nvm_block_write,
		( NVM_block_handle_t block_handle, unsigned_32 write_size, unsigned_32 write_offset, unsigned_8* source_ptr, int write_task_priority),
		(override));
	MOCK_METHOD(unsigned_8, nvm_file_update, (), (override));
};
}
}
