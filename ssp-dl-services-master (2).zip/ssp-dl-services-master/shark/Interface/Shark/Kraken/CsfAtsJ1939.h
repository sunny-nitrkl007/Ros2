/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken csf_ats_j1939 interface

#pragma once

#include <csf_ats_j1939_client.h>
#include <memory>

namespace Shark
{
namespace Kraken
{
class ICsfAtsJ1939
{
public:
	virtual ~ICsfAtsJ1939() = default;

	virtual csf_ats_j1939_client_ret_type_t csf_ats_j1939_client_init(
		const csf_ats_j1939_client_config_t* p_config,
		scl_j1939_link_t h_link,
		uint_least8_t ecm_indx) = 0;

	virtual void csf_ats_j1939_client_update() = 0;

	virtual csf_ats_j1939_client_ret_type_t csf_ats_j1939_client_cmd_req(csf_ats_j1939_cmd_req_t cmd_req) = 0;

	virtual csf_ats_j1939_client_ret_type_t csf_ats_j1939_client_seed_req(csf_ats_j1939_seed_clbk_t* p_serv_seed_clbk) = 0;
};
void SetICsfAtsJ1939(std::shared_ptr<ICsfAtsJ1939> const& spCsfAtsJ1939);
}
}
