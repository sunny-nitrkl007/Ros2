/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IJ1939 Rw accessors

#pragma once

#include "SclJ1939Rw.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockIJ1939Rw : public IJ1939Rw
{
	EnsureMockKindIsSpecified(MockIJ1939Rw);
public:
	MockIJ1939Rw()
	{
		using namespace ::testing;
		ON_CALL(*this, scl_rw_j1939_client_init(_))
			.WillByDefault(Return(TRUE));
		ON_CALL(*this, scl_rw_j1939_server_init(_))
			.WillByDefault(Return(TRUE));
	}

	MOCK_METHOD(bool_t, scl_rw_j1939_client_init, (scl_j1939_link_t link), (override));
	MOCK_METHOD(bool_t, scl_rw_j1939_server_init, (scl_j1939_link_t link), (override));
};
}
}
