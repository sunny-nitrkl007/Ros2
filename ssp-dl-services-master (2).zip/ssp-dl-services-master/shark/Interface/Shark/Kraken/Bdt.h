/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken BDT interface

#pragma once

#include <bdt_action.h>
#include <bdt_eth_proto.h>
#include <bdt_proto.h>
#include <memory>

namespace Shark
{
namespace Kraken
{
class IBdt
{
public:
	virtual ~IBdt() = default;

	virtual boolean_t bdt_set_callback_block_count (unsigned_16 count) = 0;

	virtual boolean_t bdt_set_datatype_count (unsigned_16 count) = 0;

	virtual unsigned_16 bdt_set_callback_block (
		bdt_query_index_supported_t bdt_query_index_supported,
		bdt_obtain_data_access_t bdt_obtain_data_access,
		bdt_release_data_access_t bdt_release_data_access,
		bdt_get_data_size_t bdt_get_data_size,
		bdt_open_data_t bdt_open_data,
		bdt_close_data_t bdt_close_data,
		bdt_get_data_t bdt_get_data,
		bdt_set_data_t bdt_set_data) = 0;

	virtual boolean_t bdt_set_datatype (unsigned_16 datatype, unsigned_16 handle) = 0;

	virtual void bdt_set_period (unsigned_32 period) = 0;

	virtual boolean_t bdt_init(
		unsigned_8 NumRxCon, unsigned_32 RxBufSize,
		unsigned_8 NumTxCon, unsigned_32 TxBufSize,
		unsigned_8 NumDatalinkCon) = 0;

	virtual void bdt_main() = 0;

	virtual bdt_error_t bdt_req_connection(
		unsigned_8      type,
		unsigned_8      sid,
		unsigned_8      did,
		unsigned_16     datatype,
		unsigned_32     index,
		unsigned_32     size,
		unsigned_8      rate,
		bdt_app_info_t *app_info,
		unsigned_8      datalink_id,
		unsigned_8      encyption,
		unsigned_8      compress) = 0;

	virtual boolean bdt_set_report_error_hdlr(
		void *report_error_context,
		bdt_report_error_hdlr_t bdt_report_error_hdlr) = 0;

	virtual unsigned_8 bdt_j1939_init(scl_j1939_link_t Ph_link) = 0;

	virtual void bdt_j1939_set_resource(const oel_rtos_resource_config_t *resource) = 0;

	virtual bool_t bdt_action_init(const bdt_action_config_t *config) = 0;

	virtual uint_least8_t bdt_eth_init(void *http_server, uint_least32_t fid) = 0;

	virtual bdt_error_t bdt_eth_req_connection(
		unsigned_8 type,
		unsigned_16 data_type,
		unsigned_32 data_idx,
		unsigned_32 ptxt_file_size,
		bdt_app_info_t* app_info,
		unsigned_8 encryption,
		unsigned_8 compression,
		unsigned_8 datalink_id,
		unsigned_32 server_fid) = 0;

	virtual bool_least_t bdt_eth_set_report_error_hdlr(
		bdt_eth_report_error_hdlr_t error_handler,
		void* report_context) = 0;

	virtual bdt_action_req_status_t bdt_action_req_command(
		bdt_action_cmd_id_t cmd_id,
		unsigned_8 sid,
		unsigned_8 did,
		unsigned_16 data_type,
		unsigned_32 data_index,
		bdt_action_resp_notify_t resp_notify,
		void* context,
		unsigned_8 datalink_id) = 0;

	virtual bdt_action_req_status_t bdt_eth_action_req_command(
		bdt_action_cmd_id_t cmd_id,
		unsigned_32 local_fid,
		unsigned_32 server_fid,
		unsigned_16 data_type,
		unsigned_32 data_index,
		bdt_eth_action_resp_notify_t resp_notify,
		void* context,
		unsigned_8 datalink_id) = 0;

	virtual boolean_t bdt_set_conn_status_hdlr_max_count(const unsigned_8 bdt_conn_status_hdlr_max_cnt) = 0;

	virtual boolean bdt_set_notify_conn_status_hdlr(
		void* conn_status_context,
		bdt_notify_conn_status_hdlr_t notify_conn_status_hdlr) = 0;

	virtual bool_least_t bdt_eth_set_conn_status_hdlr_max_count(uint_least8_t num_conn_status_hndlrs) = 0;

	virtual bool_least_t bdt_eth_set_notify_conn_status_hdlr(
		bdt_eth_notify_conn_status_hdlr_t conn_status_handler,
		void* conn_status_context) = 0;

	virtual boolean_t bdt_dl_datatype_accesslist_init(unsigned_8 datalink_id) = 0;

	virtual boolean_t bdt_dl_datatype_accesslist_add(unsigned_8 datalink_id, unsigned_16 datatype) = 0;

};

void SetIBdt(std::shared_ptr<IBdt> const& spBdt);
}
}
