/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken SCL J1939 Adt interface

#pragma once

#include <scl_adt_j1939.h>
#include <memory>

namespace Shark
{
namespace Kraken
{

class IJ1939Adt
{
public:
	virtual ~IJ1939Adt() = default;

	virtual scl_adt_j1939_link_handle_t scl_adt_j1939_link_init(scl_j1939_link_t link) = 0;
	virtual bool_t scl_adt_j1939_link_add_ecm(scl_adt_j1939_link_handle_t adt_j1939_hndl, uint_least8_t ecm_idx) = 0;
	virtual uint_least8_t scl_adt_j1939_link_add_group(
		scl_adt_j1939_link_handle_t adt_j1939_hndl,
		uint_least8_t ecm_idx,
		uint_least8_t remote_addr,
		uint_least8_t num_of_pids,
		bool_least_t dm13_support,
		const scl_adt_j1939_client_grp_pid_config_ptr_t* client_grp_pid_configs,
		scl_adt_j1939_diag_contxt_tbl_t *diag_context_ptrs,
		scl_adt_j1939_event_clbk_t* event_callback,
		void* event_callback_context) = 0;
	virtual bool_t scl_adt_j1939_client_grp_set_timeout(
		scl_adt_j1939_link_handle_t adt_j1939_hndl,
		uint_least8_t ecm_idx,
		uint_least8_t remote_addr,
		uint_least8_t group_id,
		uint_least32_t timeout) = 0;
};
void SetIJ1939Adt(std::shared_ptr<IJ1939Adt> const& spJ1939Adt);

}
}
