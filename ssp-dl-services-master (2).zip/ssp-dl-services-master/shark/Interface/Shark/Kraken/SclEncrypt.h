/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken scl_encrypt interface

#pragma once

#include <scl_encrypt.h>
#include <memory>

namespace Shark
{
namespace Kraken
{
class ISclEncrypt
{
public:
	virtual ~ISclEncrypt() = default;

	virtual scl_encrypt_results_t scl_encrypt_init() = 0;

	virtual scl_encrypt_results_t scl_encrypt_begin_encryption(
		uint_least16_t feat_indx,
		const uint_least8_t* src_buff,
		uint_least8_t* encrypt_buff,
		uint_least32_t buff_size) = 0;

	virtual scl_encrypt_results_t scl_encrypt_register_feature(
		scl_encrypt_key_type_t key_type,
		const scl_encrypt_key_info_t* key_info,
		scl_encrypt_alg_type_t alg_type,
		scl_encrypt_feat_indx_t *feat_indx) = 0;
};
void SetISclEncrypt(std::shared_ptr<ISclEncrypt> const& spSclEncrypt);
}
}
