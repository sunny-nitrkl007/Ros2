/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock ISclEncrypt

#pragma once

#include "SclEncrypt.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockISclEncrypt : public ISclEncrypt
{
	EnsureMockKindIsSpecified(MockISclEncrypt);
public:
	MockISclEncrypt()
	{
		using namespace testing;
		ON_CALL(*this, scl_encrypt_init())
			.WillByDefault(Return(SCL_ENCRYPT_SUCCESS));
	}

	MOCK_METHOD(scl_encrypt_results_t, scl_encrypt_init, (), (override));
	MOCK_METHOD(scl_encrypt_results_t, scl_encrypt_begin_encryption, (
		uint_least16_t feat_indx,
		const uint_least8_t* src_buff,
		uint_least8_t* encrypt_buff,
		uint_least32_t buff_size), (override));
	MOCK_METHOD(scl_encrypt_results_t, scl_encrypt_register_feature, (
		scl_encrypt_key_type_t key_type,
		const scl_encrypt_key_info_t* key_info,
		scl_encrypt_alg_type_t alg_type,
		scl_encrypt_feat_indx_t *feat_indx), (override));
};
}
}