/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See MockIJ1939.h

#include "MockIJ1939.h"

namespace Shark
{
namespace Kraken
{
MockIJ1939::MockIJ1939()
{
	using namespace ::testing;

	ON_CALL(*this, scl_j1939_set_num_links(_))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_establish_link(_, _, _, _, _, _, _, _, _))
		.WillByDefault(Return(Default::Link()));
	ON_CALL(*this, scl_j1939_set_ppgn_enable_table(_, _, _))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_set_max_dm13_clients(_, _, _))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_install_dm13(_, _))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_add_suspend_client(_, _))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_cmgr_init(_, _, _))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_que_tx_msg_by_address(_, _, _, _, _, _, _))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_que_tx_msg_by_name(_, _, _, _, _, _, _))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_cat_ppgn_id_install_command(_, _))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_cat_ppgn_id_install_command_id(_, _))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_add_tx_msg_table_entry(_, _, _, _, _))
		.WillByDefault(Return(0));
	ON_CALL(*this, scl_j1939_bldr_get_pgn(_, _, _, _, _, _, _, _))
		.WillByDefault(DoAll(
			SetArgPointee<7>(TRUE),
			Return(reinterpret_cast<scl_j1939_bldr_t*>(0x42))));
	ON_CALL(*this, scl_j1939_bldr_add_param(_, _, _))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_set_rx_msg_send_request_bit(_, _, _))
		.WillByDefault(Return(TRUE));
	ON_CALL(*this, scl_j1939_add_rx_msg_table_entry(_, _, _, _, _))
		.WillByDefault(Return(0));
	ON_CALL(*this, scl_j1939_find_name_by_address(_, _, _))
		.WillByDefault(Return(TRUE));
}

MockIJ1939::~MockIJ1939() = default;
}
}
