/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken SCL J1939 RW interface

#pragma once

#include <scl_rw_j1939.h>
#include <memory>

namespace Shark
{
namespace Kraken
{

class IJ1939Rw
{
public:
	virtual ~IJ1939Rw() = default;

	virtual bool_t scl_rw_j1939_client_init(scl_j1939_link_t link) = 0;
	virtual bool_t scl_rw_j1939_server_init(scl_j1939_link_t link) = 0;
};
void SetIJ1939Rw(std::shared_ptr<IJ1939Rw> const& spJ1939Rw);

}
}
