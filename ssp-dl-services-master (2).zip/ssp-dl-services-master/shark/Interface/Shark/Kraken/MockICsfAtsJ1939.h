/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock ICsfAtsJ1939

#pragma once

#include "CsfAtsJ1939.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockICsfAtsJ1939 : public ICsfAtsJ1939
{
	EnsureMockKindIsSpecified(MockICsfAtsJ1939);
public:
	MockICsfAtsJ1939()
	{
		using namespace testing;
		ON_CALL(*this, csf_ats_j1939_client_init(_, _, _))
			.WillByDefault(Return(CSF_ATS_J1939_CLIENT_SUCCESS));
		ON_CALL(*this, csf_ats_j1939_client_cmd_req(_))
			.WillByDefault(Return(CSF_ATS_J1939_CLIENT_SUCCESS));
	}

	MOCK_METHOD(
		csf_ats_j1939_client_ret_type_t,
		csf_ats_j1939_client_init,
		(
			const csf_ats_j1939_client_config_t* p_config,
			scl_j1939_link_t h_link,
			uint_least8_t ecm_indx
		),
		(override));
	MOCK_METHOD(void, csf_ats_j1939_client_update, (), (override));
	MOCK_METHOD(
		csf_ats_j1939_client_ret_type_t,
		csf_ats_j1939_client_cmd_req,
		(csf_ats_j1939_cmd_req_t cmd_req),
		(override));
	MOCK_METHOD(
		csf_ats_j1939_client_ret_type_t,
		csf_ats_j1939_client_seed_req,
		(csf_ats_j1939_seed_clbk_t* p_serv_seed_clbk),
		(override));
};
}
}
