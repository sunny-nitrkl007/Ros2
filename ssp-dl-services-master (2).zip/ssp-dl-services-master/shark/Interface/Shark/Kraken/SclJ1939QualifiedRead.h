/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken SCL J1939 Qualified Read interface

#pragma once

#include <scl_qr_j1939.h>
#include <memory>

namespace Shark
{
namespace Kraken
{

class IJ1939QualifiedRead
{
public:
	virtual ~IJ1939QualifiedRead() = default;

	virtual scl_qr_j1939_t* scl_qr_j1939_init(
		scl_j1939_link_t link,
		const scl_qr_j1939_config_t *config) = 0;
	virtual scl_qr_j1939_client_t* scl_qr_j1939_add_client(
		scl_qr_j1939_t *itself,
		int_least8_t ecm_idx,
		uint_least8_t max_remote_nodes) = 0;
	virtual bool_t scl_qr_j1939_tx_request(
		scl_qr_j1939_t *itself,
		int_least8_t ecm_idx,
		uint_least8_t remote_addr,
		uint_least32_t pid,
		scl_qr_j1939_pid_type_t pid_type,
		scl_qr_j1939_qualifier_type_t qualifier_type,
		scl_qr_j1939_datalink_endian_t datalink_endian,
		uint_least8_t data_length,
		scl_qr_j1939_data_sign_t data_sign,
		scl_qr_j1939_rqst_clbk_t *rqst_clbk,
		void *rqst_clbk_context) = 0;
};
void SetIJ1939QualifiedRead(std::shared_ptr<IJ1939QualifiedRead> const& spJ1939QualifiedRead);

}
}
