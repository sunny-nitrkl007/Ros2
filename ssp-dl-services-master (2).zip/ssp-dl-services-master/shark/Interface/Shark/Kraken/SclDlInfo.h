/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Kraken scl dlinfo interface

#pragma once

#include <scl_dlinfo.h>
#include <memory>

namespace Shark
{
namespace Kraken
{
class ISclDlInfo
{
public:
	virtual ~ISclDlInfo() = default;

	virtual scl_dlinfo_error_t scl_dlinfo_init(const scl_dlinfo_config_t* dlinfo_config) = 0;
	virtual scl_dlinfo_error_t scl_dlinfo_add_j39_link(
		scl_health_j39_link_t* health_j39_link,
		const scl_dlinfo_j39_link_config_t* link_config) = 0;
	virtual void scl_dlinfo_keyswitch_status(bool_least_t keyswitch_on) = 0;
	virtual bool_t scl_dlinfo_ok_to_shutdown(void) = 0;
};
void SetISclDlInfo(std::shared_ptr<ISclDlInfo> const& spSclDlInfo);
}
}
