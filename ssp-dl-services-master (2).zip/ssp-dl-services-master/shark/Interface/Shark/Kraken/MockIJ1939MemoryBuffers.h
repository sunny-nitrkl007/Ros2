/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IJ1939 Memory Buffer accessors

#pragma once

#include "SclJ1939.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockIJ1939MemoryBuffers : public IJ1939MemoryBuffers
{
	EnsureMockKindIsSpecified(MockIJ1939MemoryBuffers);
public:
	MOCK_METHOD(unsigned_16, scl_j1939_get_mbuf_len, (
		const scl_j1939_mbuf_hdr_t* Ppst_mbuf), (override));

	MOCK_METHOD(boolean_t, scl_j1939_get_data_from_mbuf, (
		const scl_j1939_mbuf_hdr_t* Ppst_mbuf,
		unsigned_8* Pau8_dest,
		const unsigned_16 Pu16_len,
		const unsigned_16 Pu16_start), (override));

	MOCK_METHOD(unsigned_8, scl_j1939_get_mbuf_sa, (const scl_j1939_mbuf_hdr_t* Ppst_mbuf), (override));

	MOCK_METHOD(boolean_t, scl_j1939_get_cat_ext_from_mbuf, (
		const scl_j1939_mbuf_hdr_t* Ppst_mbuf,
		unsigned_16* Ppu16_value,
		const unsigned_16 Pu16_start), (override));

	MOCK_METHOD(boolean_t, scl_j1939_fill_mbuf_data, (
		scl_j1939_mbuf_hdr_t* Ppst_mbuf,
		const void* Ppu8_data,
		unsigned_16 Pu16_length), (override));
};
}
}
