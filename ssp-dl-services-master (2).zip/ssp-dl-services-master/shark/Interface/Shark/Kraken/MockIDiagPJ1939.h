/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock SCL J1939 proprietary eddt diagnostic interfaces

#pragma once

#include "SclDiagPj1939.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockIDiagPJ1939 : public IDiagPJ1939
{
	EnsureMockKindIsSpecified(MockIDiagPJ1939);
public:
	MockIDiagPJ1939()
	{
		using namespace ::testing;

		ON_CALL(*this, scl_diag_pj1939_init(_, _, _, _, _, _))
			.WillByDefault(DoAll(
				SetArgPointee<5>(SCL_DIAG_PJ1939_SUCCESSFUL),
				Return(reinterpret_cast<scl_diag_pj1939_t*>(0x42))));
		ON_CALL(*this, scl_diag_pj1939_register_fault(_, _, _))
			.WillByDefault(Return(SCL_DIAG_PJ1939_SUCCESSFUL));
	}

	MOCK_METHOD(scl_diag_pj1939_t*, scl_diag_pj1939_init, (
		const scl_diag_pj1939_config_t* config,
		scl_j1939_link_t link,
		int_least8_t ecm_idx,
		scl_obd_es_t* es,
		scl_obd_crit_t* crit,
		scl_diag_pj1939_error_t* error), (override));
	MOCK_METHOD(scl_diag_pj1939_error_t, scl_diag_pj1939_register_fault, (
		scl_diag_pj1939_t* itself,
		scl_obd_test_handle_t test_handle,
		const scl_eddt_fault_config_t* fault_config), (override));
	MOCK_METHOD(scl_diag_pj1939_error_t, scl_diag_pj1939_update, (scl_diag_pj1939_t* itself), (override));
};
}
}
