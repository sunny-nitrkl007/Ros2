/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IHal

#pragma once

#include "Hal.h"
#include <Utilities/DataEngineMock.h>
#include <algorithm>

namespace Shark
{
namespace Kraken
{
class MockIHal : public IHal
{
	EnsureMockKindIsSpecified(MockIHal);
public:
	struct Default
	{
		static constexpr hal_cat_partno_t PartNumber() { return   hal_cat_partno_t{10, "0000000000"}; }
		static constexpr hal_ecm_serialno_t SerialNumber()
		{
			// Uses only 15 '0' so that the null will be in the last byte
			return hal_ecm_serialno_t{16, "000000000000000"};
		}
	};

	MockIHal()
	{
		using namespace testing;

		ON_CALL(*this, hal_boot_get_ecm_partno())
			.WillByDefault(Invoke(Default::PartNumber));
		ON_CALL(*this, hal_boot_get_ecm_serialno())
			.WillByDefault(Invoke(Default::SerialNumber));
	}

	MOCK_METHOD(void, hal_init, (), (override));

	MOCK_METHOD(void, hal_canv3_port_set_resource, (
		 volatile hal_canv3_port_t *port,
		 const oel_rtos_resource_config_t *resource_config), (override));

	MOCK_METHOD(void, hal_pulseo_init, (), (override));
	MOCK_METHOD(hal_diagnostic_t, hal_pulseo_get_diagnostics, (hal_pulseo_channel_t channel), (override));
	MOCK_METHOD(void, hal_pulseo_set_diag_enable, (
		hal_pulseo_channel_t channel,
		hal_u08_t diagnostic_control), (override));
	MOCK_METHOD(void, hal_pulseo_set_discrete, (
		hal_pulseo_channel_t channel,
		hal_discrete_t discrete_command), (override));
	MOCK_METHOD(void, hal_pulseo_set_rwave_period_pw, (
		hal_pulseo_channel_t channel,
		hal_second_u32_l30_t period,
		hal_second_u32_l30_t pulse_width), (override));

	MOCK_METHOD(void, hal_power_init, (), ());
	MOCK_METHOD(hal_volt_s16_l07_t, hal_power_get_voltage, (hal_power_supply_t supply), (override));
	MOCK_METHOD(hal_diagnostic_t, hal_power_get_diagnostics, (hal_power_supply_t supply), (override));

	MOCK_METHOD(void, hal_pulsei_init, (), (override));
	MOCK_METHOD(hal_discrete_t, hal_pulsei_get_discrete, (hal_pulsei_channel_t channel), (override));

	MOCK_METHOD(hal_cat_partno_t, hal_boot_get_ecm_partno, (), (override));
	MOCK_METHOD(hal_ecm_serialno_t, hal_boot_get_ecm_serialno, (), (override));
	MOCK_METHOD(hal_location_code_t, hal_boot_read_location_code, (), (override));

	MOCK_METHOD(void, hal_rtc_init, (), (override));
	MOCK_METHOD(hal_s32_t, hal_rtc_wakeup_alarm_clear, (), (override));
	MOCK_METHOD(hal_s32_t, hal_rtc_read, (struct tm * const tp), (override));

	MOCK_METHOD(void, hal_adci_init, (), (override));
	MOCK_METHOD(hal_s16_l05_t, hal_adci_get_temperature, (hal_adci_channel_t channel), (override));
	MOCK_METHOD(unsigned, GetCpuCount, (), (override));
};
}
}
