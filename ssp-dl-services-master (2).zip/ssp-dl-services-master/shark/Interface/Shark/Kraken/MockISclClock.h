/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock IClock

#pragma once

#include "SclClock.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockIClock : public IClock
{
	EnsureMockKindIsSpecified(MockIClock);
public:
	MockIClock()
	{
		using namespace ::testing;

		ON_CALL(*this, clock_rtc_sec_fps_config(_, _, _, _))
			.WillByDefault(Return(TRUE));
	}

	MOCK_METHOD(clock_result_t, clock_ginit, (), (override));
	MOCK_METHOD(clock_result_t, clock_go, (), (override));
	MOCK_METHOD(clock_result_t, clock_runservice, (clock_runstatus_t go), (override));
	MOCK_METHOD(clock_time_t, clock_getservice_sec, (), (override));
	MOCK_METHOD(clock_result_t, clock_setservice_sec, (clock_time_t newtime), (override));
	MOCK_METHOD(clock_result_t, clock_update, (), (override));

	MOCK_METHOD(clock_result_t, clock_rtc_init, (), (override));
	MOCK_METHOD(clock_result_t, clock_rtc_init_v2, (), (override));
	MOCK_METHOD(clock_result_t, clock_getreal_struct_tm2, (struct clock_tm *a, bool_least_t *is_secured), (override));
	MOCK_METHOD(clock_result_t, clock_tzone_init, (NVM_block_handle_t time_zone_handle), (override));
	MOCK_METHOD(clock_result_t, clock_tzone_init_v2, (unsigned_32 tzone_block_id), (override));
	MOCK_METHOD(clock_result_t, clock_tzone_get, (tzone_tx_comm_struct *tzone_comm_ptr,bool_least_t *is_secured), (override));
	MOCK_METHOD(clock_result_t, clock_tzone_set, (tzone_rcv_comm_struct *tzone_comm_ptr,bool_least_t is_secured), (override));
	MOCK_METHOD(clock_result_t, clock_tzone_get_local_tm2, (struct clock_tm *curr_local_tm, bool_least_t *is_secured), (override));
	MOCK_METHOD(bool_least_t, clock_rtc_sec_fps_config, (
		scl_fps_rc_token_ifc_t* hdlr_get_feat_token,
		void* get_feat_token_context,
		clock_fps_feat_token_increment* hdlr_inc_feat_token,
		void* inc_feat_token_context), (override));
	MOCK_METHOD(clock_result_t, clock_rtc_sec_init, (const clock_rtc_sec_config_t *rtc_sec_config), (override));
	MOCK_METHOD(void, clock_rtc_set_sec_enabled, (bool_least_t security_status), (override));
	MOCK_METHOD(clock_result_t, clock_rtc_configure_time_adj, (unsigned_32 slew_rate_ms, unsigned_32 slew_limit_ms), (override));
	MOCK_METHOD(clock_tm*, clock_tzone_get_local_tm, (), (override));
};
}
}
