/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock ISclCalClient

#pragma once

#include "SclCalClient.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockISclCalClient : public ISclCalClient
{
	EnsureMockKindIsSpecifiedWithoutADefaultDefinition(MockISclCalClient);
public:
	MockISclCalClient();

	MOCK_METHOD(void, scl_cal_client_init, (), (override));
	MOCK_METHOD(uint_least8_t, scl_cal_client_link_add_j1939, (
		scl_j1939_link_t link,
		uint_least8_t ecm_index,
		scl_cal_client_status_t* link_stat), (override));
	MOCK_METHOD(uint_least8_t, scl_cal_client_link_add_peer_by_addr, (
		uint_least8_t link_index,
		uint_least8_t remote_peer_address,
		scl_cal_client_status_t* peer_stat), (override));
	MOCK_METHOD(uint_least8_t, scl_cal_client_peer_add_svc, (
		uint_least8_t peer_index,
		scl_cal_client_svc_types_t svc_type,
		scl_cal_client_notify_app_status_t scl_cal_client_notify_status,
		void* context_ptr,
		scl_cal_client_status_t* svc_stat), (override));
	MOCK_METHOD(scl_cal_client_status_t, scl_cal_client_start_svc, (
		uint_least16_t cal_or_srvtst_id,
		uint_least8_t svc_index), (override));
	MOCK_METHOD(scl_cal_client_status_t, scl_cal_client_user_action, (
		scl_cal_client_ac_t action_cmd,
		uint_least8_t *ac_data,
		uint_least8_t ac_data_len,
		uint_least8_t svc_index), (override));
	MOCK_METHOD(scl_cal_client_status_t, scl_cal_client_last_svc_status, (
		uint_least16_t cal_id,
		uint_least8_t svc_index), (override));
	MOCK_METHOD(scl_cal_client_status_t, scl_cal_client_abort_svc, (uint_least8_t svc_index), (override));
	MOCK_METHOD(scl_cal_client_status_t, scl_cal_client_end_svc, (uint_least8_t svc_index), (override));
	MOCK_METHOD(scl_cal_client_status_t, scl_cal_client_remove_peer, (uint_least8_t peer_index), (override));
	MOCK_METHOD(void, scl_cal_client_update, (), (override));
};
}
}
