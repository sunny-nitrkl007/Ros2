/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Mock ISclDlInfo

#pragma once

#include "SclDlInfo.h"
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Kraken
{
class MockISclDlInfo : public ISclDlInfo
{
	EnsureMockKindIsSpecified(MockISclDlInfo);
public:
	MOCK_METHOD(scl_dlinfo_error_t, scl_dlinfo_init, (const scl_dlinfo_config_t* dlinfo_config), (override));
	MOCK_METHOD(scl_dlinfo_error_t, scl_dlinfo_add_j39_link, (
		scl_health_j39_link_t* health_j39_link,
		const scl_dlinfo_j39_link_config_t* link_config), (override));
	MOCK_METHOD(void, scl_dlinfo_keyswitch_status, (bool_least_t keyswitch_on), (override));
	MOCK_METHOD(bool_t, scl_dlinfo_ok_to_shutdown, (), (override));
};
}
}
