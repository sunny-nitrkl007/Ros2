/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK entry point

#pragma once

#include "IShark.h"
#include <SharkConfiguration.pb.h>
#include <Utilities/IEnvironment.h>
#include <memory>
#include <string>
#include <vector>

namespace Shark
{
std::unique_ptr<IShark> CreateShark(
	Utilities::IEnvironment const& environment,
	cat::shark::Config const& sharkConfig);
}