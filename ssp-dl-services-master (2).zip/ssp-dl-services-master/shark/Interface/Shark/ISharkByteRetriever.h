/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Byte Retriever Interface

#pragma once

#include "ISharkByte.h"
#include "Utilities/DefineExceptionClass.h"

namespace Shark
{
class ISharkByteRetriever
{
public:
	virtual ~ISharkByteRetriever() = default;

	DEFINE_EXCEPTION_CLASS(NotFound);

	/// \exception ISharkByteRetriever::NotFound
	///            Thrown when id is not found
	virtual ISharkByte& Retrieve(SharkByteId const& id) const = 0;

	/// Implementations may override this with an optimized implementation.
	virtual std::optional<Utilities::nice_ptr<ISharkByte>> TryRetrieve(SharkByteId const& id) const
	{
		std::optional<Utilities::nice_ptr<ISharkByte>> sharkByte{};
		try
		{
			sharkByte = &Retrieve(id);
		}
		catch (NotFound const&)
		{
		}
		return sharkByte;
	}
};
}
