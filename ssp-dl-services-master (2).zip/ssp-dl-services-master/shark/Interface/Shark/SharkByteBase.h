/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SharkByte base class

#pragma once

#include "ISharkByte.h"
#include <Utilities/SharkBytes/SharkByteDescribers.h>
#include <boost/signals2.hpp>

namespace Shark
{
/// Subclasses must implement Value()
class SharkByteBase : public virtual ISharkByte
{
public:
	explicit SharkByteBase(SharkByteId&& id)
		: SharkByteBase(std::move(id), std::nullopt)
	{
	}
	SharkByteBase(SharkByteId&& id, SharkByteValue value)
		: SharkByteBase(std::move(id), std::move(value), false)
	{
	}
	// By default, SharkByteBase asserts that ValueChanged is only called when the value actually changes.
	// This can be disabled if needed so that the subscriber will receive notifications even if the value
	// hasn't changed. This is known as "transient" behavior.
	SharkByteBase(
		SharkByteId&& id,
		[[maybe_unused]] SharkByteValue value,
		bool isTransient)
		: m_id{std::move(id)}
		, m_isTransient{isTransient}
#ifndef NDEBUG
		, m_cachedValue{std::move(value)}
#endif
	{
	}
	bool IsTransient() const { return m_isTransient; }
// ISharkByte
	SharkByteId const& Id() const noexcept override
	{
		return m_id;
	}
	std::string Describe() const override
	{
		return Utilities::DescribeValue(*this);
	}
	SharkByteSubscription SubscribeToValues(boost::function<void(SharkByteValue const&)> const& callback) override
	{
		assert(callback);
		SharkByteSubscription subscription{m_onNewValue.connect(callback)};
		callback(Value());
		return subscription;
	}
	virtual void Refresh() override
	{
	}
protected:
	~SharkByteBase() override = default;

	void ValueChanged(SharkByteValue const& value)
	{
#ifndef NDEBUG
		if (!IsTransient())
		{
			assert(m_cachedValue != value);
		}
		m_cachedValue = value;
#endif
		m_onNewValue(value);
	}
private:
	SharkByteId const m_id;
	boost::signals2::signal<void(Shark::SharkByteValue const&)> m_onNewValue{};
	bool const m_isTransient;
#ifndef NDEBUG
	SharkByteValue m_cachedValue; // Used to verify ValueChanged is only called when the value did change
#endif
};
}