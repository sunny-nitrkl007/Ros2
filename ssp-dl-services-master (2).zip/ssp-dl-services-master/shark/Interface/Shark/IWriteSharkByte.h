/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Write Shark Byte Interface

#pragma once

#include "ISharkByte.h"
#include <functional>

namespace Shark
{
class IWriteSharkByte
{
public:
	using CompletedCallback = std::function<void(SharkByteValue const& writeResponse)>;
	static inline CompletedCallback const NoOpCallback = [](SharkByteValue const&){};

	virtual ~IWriteSharkByte() = default;

	virtual SharkByteId const& Id() const = 0;

	/// completedCallback may and probably will be called from a different thread
	virtual void Write(std::vector<uint8_t> const& value, CompletedCallback const& completedCallback = NoOpCallback) = 0;
	virtual void WriteInvalid(CompletedCallback const& completedCallback = NoOpCallback) = 0;
};
}
