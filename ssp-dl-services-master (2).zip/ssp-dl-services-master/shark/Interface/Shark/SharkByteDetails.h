/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Byte names and values

#pragma once

namespace Shark
{
namespace SharkByteDetails
{
namespace Calibrations
{
	namespace Command
	{
		static constexpr char const* SharkByteId()                { return "Calibration_Command"; }
		static constexpr char const* FieldCommand()               { return "command"; }
		static constexpr char const* FieldContext()               { return "context"; }
		static constexpr char const* Engage()                     { return "engage"; }
		static constexpr char const* FinishedServiceTest()        { return "finish_service_test"; }
		static constexpr char const* Abort()                      { return "abort"; }
		static constexpr char const* Proceed()                    { return "proceed"; }
		static constexpr char const* Disengage()                  { return "disengage"; }
		static constexpr char const* YesAffirmation()             { return "yes_affirmation"; }
		static constexpr char const* NoAffirmation()              { return "no_affirmation"; }
		static constexpr char const* SmallIncrement()             { return "increment_slider_1_small_step"; }
		static constexpr char const* SmallDecrement()             { return "decrement_slider_1_small_step"; }
		static constexpr char const* LargeIncrement()             { return "increment_slider_1_large_step"; }
		static constexpr char const* LargeDecrement()             { return "decrement_slider_1_large_step"; }
		static constexpr char const* GoToStep()                   { return "go_to_step"; }
		static constexpr char const* CommandButton()              { return "command_button"; }
		static constexpr char const* RevertToDefaultValues()      { return "revert_to_default_values"; }
	}

	static constexpr char const* StepNumberSharkByteId() { return "Calibration_StepNumber"; }

	namespace Status
	{
		static constexpr char const* SharkByteId() { return "Calibration_Status"; }

		static constexpr char const* FieldName()         {return "name"; }
		static constexpr char const* FieldType()         {return "type"; }
		static constexpr char const* TypeCalibration()   {return "calibration"; }
		static constexpr char const* TypeServiceTest()   {return "service test"; }
		static constexpr char const* FieldStatus()       {return "status"; }
		static constexpr char const* StatusInitialized() {return "initialized"; }
		static constexpr char const* StatusExecuting()   {return "executing"; }
		static constexpr char const* StatusBusy()        {return "busy"; }
		static constexpr char const* StatusSucceeded()   {return "succeeded"; }
		static constexpr char const* StatusFailed()      {return "failed"; }
		static constexpr char const* FieldStep()         {return "step"; }
		static constexpr char const* FieldErrors()       {return "errors"; }
	}

	static constexpr char const* ErrorsSharkByteId() { return "Calibration_Errors"; }
}

namespace DiagnosticCodes
{
	static constexpr char const* CodesSharkByteId()                                { return "Codes"; }
	static constexpr char const* HighestActiveAnnunciationRequirementSharkByteId() { return "HighestActiveAnnunciationRequirement"; }

	// WriteSharkByte that takes the unique code id and places a request on the queue to be requested
	static constexpr char const* AdditionalInformationRequestSharkByteId()         { return "AdditionalInformationRequest"; }
	// SharkByte that streams additional information responses back to client.
	static constexpr char const* AdditionalInformationResponseSharkByteId()        { return "AdditionalInformationResponse"; }
}

namespace MachineSecuritySystem
{
	// Reads - Operator information
	static constexpr char const* OperatorDetected()    { return "MSS_OperatorDetected"; }
	static constexpr char const* OperatorIsGuest()     { return "MSS_OperatorIsGuest"; }
	static constexpr char const* OperatorIsMaster()    { return "MSS_OperatorIsMaster"; }
	static constexpr char const* OperatorLogInMethod() { return "MSS_OperatorLogInMethod"; }
	static constexpr char const* OperatorName()        { return "MSS_OperatorName"; }
	static constexpr char const* RawOperatorKeyId()    { return "MSS_RawOperatorKeyId"; }

	// Reads - Completion status of commands
	static constexpr char const* LogInStatus()           { return "MSS_LogInStatus"; }
	static constexpr char const* LogOutStatus()          { return "MSS_LogOutStatus"; }
	static constexpr char const* LockStatus()            { return "MSS_LockStatus"; }
	static constexpr char const* OperatorRequestStatus() { return "MSS_OperatorRequestStatus"; }
	static constexpr char const* UnlockStatus()          { return "MSS_UnlockStatus"; }

	// Writes
	static constexpr char const* Lock()                   { return "MSS_Lock"; }
	static constexpr char const* LogIn()                  { return "MSS_LogIn"; }
	static constexpr char const* LogOut()                 { return "MSS_LogOut"; }
	static constexpr char const* RequestCurrentOperator() { return "MSS_RequestCurrentOperator"; }
	static constexpr char const* Unlock()                 { return "MSS_Unlock"; }
}

namespace Oel
{
	// Reads
	static constexpr char const* StrobeId() { return "Oel_Strobe"; }
}
}
}
