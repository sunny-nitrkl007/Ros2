/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SHARK Byte Interface

#pragma once

#include "Utilities/Conversions.h"
#include "Utilities/nice_ptr.h"
#include "Utilities/Units.h"
#include <boost/signals2.hpp>
#include <cassert>
#include <optional>
#include <vector>
#include <string>

namespace Shark
{
using SharkByteId = std::string;
using SharkByteValue = std::optional<std::vector<uint8_t>>;

constexpr std::vector<uint8_t> TrueSharkByteValue() {return {0x01};}
constexpr std::vector<uint8_t> FalseSharkByteValue() {return {0x00};}
}

namespace Shark
{
class ISharkByte;

/// Move-only object that unsubscribes upon destruction if not already unsubscribed.
class SharkByteSubscription final
{
public:
	SharkByteSubscription() = default;
	SharkByteSubscription(boost::signals2::connection&& connection) noexcept
		: m_connection(std::move(connection))
	{
		assert(m_connection.connected());
	}
	SharkByteSubscription(boost::signals2::connection&& connection, ISharkByte& sharkByte) noexcept
		: m_connection(std::move(connection))
		, m_spSharkByte(&sharkByte)
	{
		assert(m_connection.connected());
	}
	SharkByteSubscription(SharkByteSubscription&& subscription) noexcept
		: m_connection(std::move(subscription.m_connection))
		, m_spSharkByte(std::move(subscription.m_spSharkByte))
	{
	}
	~SharkByteSubscription()
	{
		Unsubscribe();
	}
	SharkByteSubscription& operator=(SharkByteSubscription&& subscription) noexcept
	{
		assert(this != &subscription);
		m_connection = std::move(subscription.m_connection);
		m_spSharkByte = std::move(subscription.m_spSharkByte);
		return *this;
	}

	SharkByteSubscription(SharkByteSubscription const&) = delete;
	SharkByteSubscription& operator=(SharkByteSubscription const&) = delete;

	bool IsConnected() const
	{
		return m_connection.connected();
	}
	void Unsubscribe()
	{
		if (m_connection.connected())
		{
			m_connection.disconnect();

			// We only notify the Shark Byte if the connection is valid. If it is invalid, then the Shark Byte
			// has been destroyed. At that point, there is is nothing that can be done safely anyway.
			if (m_spSharkByte)
			{
				NotifySharkByteOfDisconnection();
				m_spSharkByte.reset();
			}
		}
	}
private:
	void NotifySharkByteOfDisconnection();

	boost::signals2::scoped_connection m_connection{};
	Utilities::nice_ptr<ISharkByte> m_spSharkByte{};
};

class ISharkByte
{
public:
	virtual ~ISharkByte() = default;

	virtual SharkByteId const& Id() const = 0;
	/// Returns a description of this ISharkByte and its current value
	virtual std::string Describe() const = 0;

	/// Subscribes to value change events.
	virtual SharkByteSubscription SubscribeToValues(boost::function<void(SharkByteValue const&)> const& callback) = 0;
	SharkByteSubscription SubscribeToNotifications(boost::function<void()> const& callback)
	{
		assert(callback);
		return SubscribeToValues([callback](SharkByteValue const&) { callback(); });
	}

	/// Called when a SharkByteSubscription is Unsubscribed or destroyed
	virtual void OnUnsubscribed() {}

	/// Return value is empty when the value is not valid.
	virtual SharkByteValue Value() const = 0;

	/// Manual request to update data
	virtual void Refresh() = 0;
};

inline void SharkByteSubscription::NotifySharkByteOfDisconnection()
{
	m_spSharkByte->OnUnsubscribed();
}
}

namespace boost
{
inline bool operator==(Shark::SharkByteValue const& value, char const* pString)
{
	assert(pString);
	return value && (*value == pString);
}
inline bool operator==(char const* pString, Shark::SharkByteValue const& value)
{
	assert(pString);
	return value && (*value == pString);
}
}
