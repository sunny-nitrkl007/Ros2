/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// IShark Mock

#pragma once

#include <Shark/IShark.h>
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Mocks
{
class MockIShark : public IShark
{
	EnsureMockKindIsSpecifiedWithoutADefaultDefinition(MockIShark);
public:
	MockIShark();

	MOCK_METHOD(char const*, Name, (), (override, const, noexcept));
	MOCK_METHOD(ISharkByteRetriever const&, GetSharkByteRetriever, (), (override, const));
	MOCK_METHOD(IWriteSharkByteRetriever const&, GetWriteSharkByteRetriever, (), (override, const));
};
}
}
