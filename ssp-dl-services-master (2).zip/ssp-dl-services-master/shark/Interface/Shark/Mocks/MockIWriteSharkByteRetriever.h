/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// IWriteSharkByteRetriever Mock

#pragma once

#include "Shark/IWriteSharkByteRetriever.h"
#include <Utilities/DestructorTester.h>
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Mocks
{
class MockIWriteSharkByteRetriever : public IWriteSharkByteRetriever
{
	EnsureMockKindIsSpecifiedWithoutADefaultDefinition(MockIWriteSharkByteRetriever);
public:
	MockIWriteSharkByteRetriever();

	void SetDestructorTester(std::unique_ptr<Utilities::DestructorTester>&& spDestructorTester)
	{
		assert(!m_spDestructorTester);
		m_spDestructorTester = std::move(spDestructorTester);
	}
	Utilities::DestructorTester& GetDestructorTester() { return *m_spDestructorTester; }
// IWriteSharkByteRetriever
	MOCK_CONST_METHOD1(Retrieve, IWriteSharkByte&(std::string const& id));
private:
	std::unique_ptr<Utilities::DestructorTester> m_spDestructorTester{};
};
}
}
