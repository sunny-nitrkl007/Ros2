/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// IWriteSharkByte Mock

#pragma once

#include <Shark/IWriteSharkByte.h>
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Mocks
{
class MockIWriteSharkByte : public IWriteSharkByte
{
	EnsureMockKindIsSpecifiedWithoutADefaultDefinition(MockIWriteSharkByte);
public:
	MockIWriteSharkByte();

	MOCK_METHOD(Shark::SharkByteId const&, Id, (), (const override));
	MOCK_METHOD(void, Write, (std::vector<uint8_t> const& value, IWriteSharkByte::CompletedCallback const& completedCallback), (override));
	MOCK_METHOD(void, WriteInvalid, (IWriteSharkByte::CompletedCallback const& completedCallback), (override));
};
}
}
