/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// ISharkByte Mock

#pragma once

#include <Shark/ISharkByte.h>
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Mocks
{
class MockISharkByte : public ISharkByte
{
	EnsureMockKindIsSpecifiedWithoutADefaultDefinition(MockISharkByte);
public:
	MockISharkByte();

	MOCK_METHOD(SharkByteId const&, Id, (), (const override));
	MOCK_METHOD(std::string, Describe, (), (const override));
	MOCK_METHOD(SharkByteSubscription, SubscribeToValues, (boost::function<void(SharkByteValue const&)> const& callback), (override));
	MOCK_METHOD(void, OnUnsubscribed, (), (override));
	MOCK_METHOD(SharkByteValue, Value, (), (const override));
	MOCK_METHOD(Units::Unit, Units, (), (const override));
	MOCK_METHOD(void, Refresh, (), (override));
};

class MockSharkByteWrapper final
{
public:
	MockSharkByteWrapper();
	explicit MockSharkByteWrapper(char const* pValue);
	explicit MockSharkByteWrapper(SharkByteValue const& value);
	MockSharkByteWrapper(MockSharkByteWrapper&& wrapper);
	~MockSharkByteWrapper();

	MockISharkByte& GetMock();
	// void SetValue(char const* pNewValue);
	void SetValue(Shark::SharkByteValue const& newValue);
	void SetValue(bool value);
	void SetInvalid();
	Shark::SharkByteValue const& Value() const;
	bool HasSubscribers() const;
	void ExpectThatSubscribeOccurs(std::function<void(void)> const& codeUnderTest);
	void ExpectThatUnsubscribeOccurs(std::function<void(void)> const& codeUnderTest);
private:
	// Store all context in a unique_ptr so that moves will not move anything that is being referenced elsewhere.
	struct Impl;
	std::unique_ptr<Impl> m_spImpl;
};
}
}
