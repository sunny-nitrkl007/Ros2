/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// ISharkByteRetriever Mock

#pragma once

#include "Shark/ISharkByteRetriever.h"
#include <Utilities/DestructorTester.h>
#include <Utilities/DataEngineMock.h>

namespace Shark
{
namespace Mocks
{
class MockISharkByteRetriever : public ISharkByteRetriever
{
	EnsureMockKindIsSpecifiedWithoutADefaultDefinition(MockISharkByteRetriever);
public:
	MockISharkByteRetriever();

	void SetDestructorTester(std::unique_ptr<Utilities::DestructorTester>&& spDestructorTester)
	{
		assert(!m_spDestructorTester);
		m_spDestructorTester = std::move(spDestructorTester);
	}
	Utilities::DestructorTester& GetDestructorTester() { return *m_spDestructorTester; }
// ISharkByteRetriever
	MOCK_CONST_METHOD1(Retrieve, ISharkByte&(std::string const& id));
private:
	std::unique_ptr<Utilities::DestructorTester> m_spDestructorTester{};
};
}
}
