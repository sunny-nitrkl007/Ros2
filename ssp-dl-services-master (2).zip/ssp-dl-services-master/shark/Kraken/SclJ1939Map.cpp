/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclJ1939Map.h

#include "SclJ1939Map.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<IJ1939Map> n_wpJ1939Map;
}

namespace Shark
{
namespace Kraken
{
void SetIJ1939Map(std::shared_ptr<IJ1939Map> const& spJ1939Map)
{
	n_wpJ1939Map = spJ1939Map;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

boolean_t scl_j1939_set_ma_client_configuration(
	scl_j1939_link_t                Ph_link,
	scl_j1939_ma_client_status_cb_t Ppfn_status_cb,
	unsigned_8                      Pu8_max_ma_sessions)
{
	return CallKrakenMethod(n_wpJ1939Map, TRUE, &IJ1939Map::scl_j1939_set_ma_client_configuration,
		Ph_link, Ppfn_status_cb, Pu8_max_ma_sessions);
}

boolean_t scl_j1939_set_ma_configuration(
		scl_j1939_link_t Ph_link,
		int_8 Pi8_ma_param_size,
		const scl_j1939_ma_param_list_t *Past_ma_param_tbl,
		unsigned_8 Pu8_max_ma_sessions)
{
	return CallKrakenMethod(n_wpJ1939Map, TRUE, &IJ1939Map::scl_j1939_set_ma_configuration,
	Ph_link, Pi8_ma_param_size, Past_ma_param_tbl, Pu8_max_ma_sessions);
}

unsigned_8 scl_j1939_ma_client_transaction_by_address(
	scl_j1939_link_t                 Ph_link,
	int_8                            Pi8_init_ecm,
	unsigned_8                       Pu8_target_ecm,
	unsigned_8                       Pu8_service,
	unsigned_8                       Pu8_param_type,
	unsigned_32                      Pu32_param,
	unsigned_16                      Pu16_length,
	scl_j1939_ma_trans_complete_cb_t Ppfn_trans_complete_cb,
	scl_j1939_ma_client_param_cb_t   Ppfn_parm_cb,
	boolean_t                        Pb_keep_alive)
{
	return CallKrakenMethod(n_wpJ1939Map, INVALID_MA_SESSION, &IJ1939Map::scl_j1939_ma_client_transaction_by_address,
		Ph_link,
		Pi8_init_ecm,
		Pu8_target_ecm,
		Pu8_service,
		Pu8_param_type,
		Pu32_param,
		Pu16_length,
		Ppfn_trans_complete_cb,
		Ppfn_parm_cb,
		Pb_keep_alive);
}
