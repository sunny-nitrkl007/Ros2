/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclDiagPJ1939.h

#include "SclDiagPj1939.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<IDiagPJ1939> n_wpDiagPJ1939;
}

namespace Shark
{
namespace Kraken
{
void SetIDiagPJ1939(std::shared_ptr<IDiagPJ1939> const& spDiagPJ1939)
{
	n_wpDiagPJ1939 = spDiagPJ1939;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

scl_diag_pj1939_t* scl_diag_pj1939_init(
	const scl_diag_pj1939_config_t* config,
	scl_j1939_link_t link,
	int_least8_t ecm_idx,
	scl_obd_es_t* es,
	scl_obd_crit_t* crit,
	scl_diag_pj1939_error_t* error)
{
	auto const pDefaultResult = reinterpret_cast<scl_diag_pj1939_t*>(42);
	*error = SCL_DIAG_PJ1939_SUCCESSFUL;
	return CallKrakenMethod(
		n_wpDiagPJ1939, pDefaultResult, &IDiagPJ1939::scl_diag_pj1939_init, config, link, ecm_idx, es, crit, error);
}
scl_diag_pj1939_error_t scl_diag_pj1939_register_fault(
	scl_diag_pj1939_t* itself,
	scl_obd_test_handle_t test_handle,
	const scl_eddt_fault_config_t* fault_config)
{
	return CallKrakenMethod(n_wpDiagPJ1939, SCL_DIAG_PJ1939_SUCCESSFUL, &IDiagPJ1939::scl_diag_pj1939_register_fault,
		itself,
		test_handle,
		fault_config);
}
scl_diag_pj1939_error_t scl_diag_pj1939_update(scl_diag_pj1939_t* itself)
{
	return CallKrakenMethod(n_wpDiagPJ1939, SCL_DIAG_PJ1939_SUCCESSFUL, &IDiagPJ1939::scl_diag_pj1939_update, itself);
}
