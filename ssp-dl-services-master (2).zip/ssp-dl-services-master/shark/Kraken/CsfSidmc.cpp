/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See CsfSidmc.h

#include "CsfSidmc.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<ICsfSidmc> n_wpCsfSidmc;
}

namespace Shark
{
namespace Kraken
{
void SetICsfSidmc(std::shared_ptr<ICsfSidmc> const& spCsfSidmc)
{
	n_wpCsfSidmc = spCsfSidmc;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

csf_sidmc_ret_type_t csf_sidmc_init(
	scl_j1939_link_t h_link,
	uint_least8_t ecm_indx,
	const csf_sidmc_config_t* p_config)
{
	return CallKrakenMethod(n_wpCsfSidmc, CSF_SIDMC_SUCCESS, &ICsfSidmc::csf_sidmc_init, h_link, ecm_indx, p_config);
}
csf_sidmc_ret_type_t csf_sidmc_cmd_req(
	csf_sidmc_cmd_t sidmc_cmd,
	const csf_sidmc_key_info_t* key_info_ptr)
{
	return CallKrakenMethod(n_wpCsfSidmc, CSF_SIDMC_SUCCESS, &ICsfSidmc::csf_sidmc_cmd_req, sidmc_cmd, key_info_ptr);
}
void csf_sidmc_update()
{
	CallKrakenMethod(n_wpCsfSidmc, &ICsfSidmc::csf_sidmc_update);
}
