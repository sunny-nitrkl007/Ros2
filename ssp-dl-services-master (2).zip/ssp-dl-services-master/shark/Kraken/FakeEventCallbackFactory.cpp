/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See FakeEventCallbackFactory.h

#include "FakeEventCallbackFactory.h"
#include <Utilities/Kraken/FakeClock.h>
#include "Utilities/nice_ptr.h"
#include "Utilities/Updatables.h"
#include <cassert>
#include <gmock/gmock.h>

namespace Shark
{
namespace SharkUtilities
{
namespace Kraken
{
namespace
{
Utilities::nice_ptr<FakeEventCallbackFactory> n_spFactory{};
}

class FakeTimedCallback final : public ITimedCallback, public Utilities::IUpdatable
{
public:
	FakeTimedCallback(std::chrono::milliseconds milliseconds, std::function<void()>&& callback, bool repeats)
		: m_milliseconds(milliseconds)
		, m_callback(std::move(callback))
		, m_repeats(repeats)
	{
		assert(milliseconds.count() > 0);
		assert(m_callback);

		Reset();
	}
// ITimedCallback
	void Reset() override
	{
		Reset(Utilities::Kraken::FakeClock::now());
	}
// Utilities::IUpdatable
	void Update(Clock::time_point const& now) override
	{
		while ( m_active && (now >= m_nextCallbackTime) )
		{
			m_active = false;
			m_callback();

			if (m_repeats)
			{
				Reset(m_nextCallbackTime);
			}
		}
	}
private:
	void Reset(Clock::time_point const& now)
	{
		m_active = true;
		m_nextCallbackTime = now + m_milliseconds;
	}

	std::chrono::milliseconds const m_milliseconds;
	std::function<void()> const m_callback;
	bool const m_repeats;
	bool m_active{true};
	Utilities::Kraken::FakeClock::time_point m_nextCallbackTime{};
};

class FakeTimedCallbackWrapper final : public ITimedCallback
{
public:
	FakeTimedCallbackWrapper(
		std::shared_ptr<FakeTimedCallback> const& spFakeTimedCallback,
		FakeEventCallbackFactory& factory)
		: m_spFakeTimedCallback{spFakeTimedCallback}
		, m_factory{factory}
	{
	}
	~FakeTimedCallbackWrapper() override
	{
		m_factory.Remove(m_spFakeTimedCallback);
	}
// ITimedCallback
	void Reset() override
	{
		m_spFakeTimedCallback->Reset();
	}
private:
	std::shared_ptr<FakeTimedCallback> const m_spFakeTimedCallback;
	FakeEventCallbackFactory& m_factory;
};

class FakeFilesystemCallbackDetails
{
public:
	FakeFilesystemCallbackDetails(
		std::string const& path,
		uint32_t eventMask,
		IEventCallbackFactory::FilesystemEventCallbackFunction&& callback)
		: m_path{path}
		, m_eventMask{eventMask}
		, m_callback{std::move(callback)}
	{
	}
	std::string const& Path() const { return m_path; }
	void PerformCallback(std::string const& name, uint32_t mask) const
	{
		ASSERT_TRUE(mask & m_eventMask) << "Tried to send filesystem event that had not been registered for";

		std::optional<std::string> optionalName{name};
		if (optionalName->empty())
		{
			optionalName.reset();
		}
		m_callback(optionalName, mask);
	}
private:
	std::string const m_path;
	uint32_t const m_eventMask;
	IEventCallbackFactory::FilesystemEventCallbackFunction const m_callback;
};

class FakeFilesystemEventWrapper : public IEventCallback
{
public:
	FakeFilesystemEventWrapper(std::shared_ptr<FakeFilesystemCallbackDetails> const& spDetails)
		: m_spDetails{spDetails}
	{
	}
private:
	std::shared_ptr<FakeFilesystemCallbackDetails> const m_spDetails;
};

std::unique_ptr<FakeEventCallbackFactory> FakeEventCallbackFactory::CreateFake()
{
	auto spFactory = std::make_unique<FakeEventCallbackFactory>(std::make_unique<Utilities::Updatables>());
	n_spFactory = spFactory.get();
	return spFactory;
}
IFakeEventCallbackManager& FakeEventCallbackFactory::GetInstance()
{
	assert(n_spFactory);
	return *n_spFactory;
}

FakeEventCallbackFactory::FakeEventCallbackFactory(std::unique_ptr<Utilities::IUpdatables>&& spUpdatables)
	: m_spTimedCallbacks(std::move(spUpdatables))
{
}
void FakeEventCallbackFactory::Update()
{
	{
		std::unique_lock<std::mutex> lock{m_mutex};

		for (auto&& modification : m_modificationQueue)
		{
			auto&& timedCallback = *modification.spTimedCallback;
			if (modification.add)
			{
				m_spTimedCallbacks->Add(timedCallback);
			}
			else
			{
				m_spTimedCallbacks->Remove(timedCallback);
			}
		}
		m_modificationQueue.clear();
	}

	m_spTimedCallbacks->UpdateAll(Utilities::Kraken::FakeClock::now());
}
void FakeEventCallbackFactory::PerformFilesystemEventCallback(std::string const& path, std::string const& name, uint32_t event)
{
	auto const allFoundDetails = TryFindFilesystemCallbackDetails(path);
	ASSERT_FALSE(allFoundDetails.empty()) << "Tried to perform a filesystem callback for an unregistered path";
	for (auto&& spDetails : allFoundDetails)
	{
		spDetails->PerformCallback(name, event);
	}
}
void FakeEventCallbackFactory::SetCreatePeriodicTimerCallback(std::function<void()>&& callback)
{
	m_createPeriodicTimerCallback = std::move(callback);
}
std::vector<std::shared_ptr<FakeFilesystemCallbackDetails>> FakeEventCallbackFactory::TryFindFilesystemCallbackDetails(std::string const& path)
{
	std::lock_guard<std::mutex> lock{m_mutex};
	std::vector<std::shared_ptr<FakeFilesystemCallbackDetails>> allFoundDetails{};
	auto const findLambda =
		[&path](auto&& wpDetails)
			{
				auto&& spDetails = wpDetails.lock();
				return spDetails && spDetails->Path() == path;
			};

	for (auto&& wpFilesystemCallbackDetails : m_filesystemCallbackDetails)
	{
		if (findLambda(wpFilesystemCallbackDetails))
		{
			allFoundDetails.emplace_back(wpFilesystemCallbackDetails.lock());
		}
	}

	return allFoundDetails;
}
void FakeEventCallbackFactory::RemoveStaleFilesystemCallbackDetails()
{
	std::lock_guard<std::mutex> lock{m_mutex};

	auto const itEnd = m_filesystemCallbackDetails.end();
	auto const itNewEnd = std::remove_if(m_filesystemCallbackDetails.begin(), itEnd,
		[](auto&& wpDetails){ return wpDetails.expired(); });
	m_filesystemCallbackDetails.erase(itNewEnd, itEnd);
}
void FakeEventCallbackFactory::Remove(std::shared_ptr<FakeTimedCallback> const& spTimedCallback)
{
	std::unique_lock<std::mutex> lock{m_mutex};
	m_modificationQueue.push_back({false, spTimedCallback});
}
std::unique_ptr<ITimedCallback> FakeEventCallbackFactory::CreateTimedCallbackThatFiresIn(
	std::chrono::milliseconds milliseconds,
	std::function<void()>&& callback)
{
	return CreateFakeTimedCallback(milliseconds, std::move(callback), false);
}
std::unique_ptr<ITimedCallback> FakeEventCallbackFactory::CreatePeriodicTimedCallback(
	std::chrono::milliseconds periodMilliseconds,
	std::function<void()>&& callback)
{
	auto spTimeCalledBack = CreateFakeTimedCallback(periodMilliseconds, std::move(callback), true);
 	if (m_createPeriodicTimerCallback)
	{
		m_createPeriodicTimerCallback();
	}
	return spTimeCalledBack;
}
std::unique_ptr<IEventCallback> FakeEventCallbackFactory::CreateFilesystemEventCallback(
	std::string const& path,
	uint32_t eventMask,
	FilesystemEventCallbackFunction&& callback)
{
	RemoveStaleFilesystemCallbackDetails(); // First do a bit of clean up

	auto spDetails = std::make_shared<FakeFilesystemCallbackDetails>(path, eventMask, std::move(callback));
	{
		std::lock_guard<std::mutex> lock{m_mutex};
		m_filesystemCallbackDetails.emplace_back(spDetails);
	}

	return std::make_unique<FakeFilesystemEventWrapper>(spDetails);
}
std::unique_ptr<ITimedCallback> FakeEventCallbackFactory::CreateFakeTimedCallback(
	std::chrono::milliseconds milliseconds,
	std::function<void()>&& callback,
	bool repeats)
{
	assert(milliseconds.count() > 0);
	assert(callback);

	auto spTimedCallback = std::make_shared<FakeTimedCallback>(milliseconds, std::move(callback), repeats);

	{
		std::unique_lock<std::mutex> lock{m_mutex};
		m_modificationQueue.push_back({true, spTimedCallback});
	}

	return std::make_unique<FakeTimedCallbackWrapper>(spTimedCallback, *this);
}
}
}
}
