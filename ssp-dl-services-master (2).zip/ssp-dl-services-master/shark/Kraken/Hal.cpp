/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Hal.h

#include "Hal.h"
#include <Utilities/Kraken/CallKrakenMethod.h>
#include <hal_init.h>

using Shark::Kraken::IHal;
using Utilities::Kraken::CallKrakenMethod;

namespace
{
std::weak_ptr<IHal> n_wpHal;
}

namespace Shark
{
namespace Kraken
{
void SetIHal(std::shared_ptr<IHal> const& spHal)
{
	n_wpHal = spHal;
}
}
}

void hal_init()
{
	CallKrakenMethod(n_wpHal, &IHal::hal_init);
}
void hal_canv3_port_set_resource(
	volatile hal_canv3_port_t *port,
	const oel_rtos_resource_config_t *resource_config)
{
	CallKrakenMethod(n_wpHal, &IHal::hal_canv3_port_set_resource, port, resource_config);
}
void hal_pulseo_init()
{
	CallKrakenMethod(n_wpHal, &IHal::hal_pulseo_init);
}
hal_diagnostic_t hal_pulseo_get_diagnostics(hal_pulseo_channel_t channel)
{
	return CallKrakenMethod(n_wpHal, HAL_DEFINITE_NO_FAULT, &IHal::hal_pulseo_get_diagnostics, channel);
}
void hal_pulseo_set_diag_enable(hal_pulseo_channel_t channel, hal_u08_t diagnostic_control)
{
	return CallKrakenMethod(n_wpHal, &IHal::hal_pulseo_set_diag_enable, channel, diagnostic_control);
}
void hal_pulseo_set_discrete(
	hal_pulseo_channel_t channel,
	hal_discrete_t discrete_command)
{
	CallKrakenMethod(n_wpHal, &IHal::hal_pulseo_set_discrete, channel, discrete_command);
}
void hal_pulseo_set_rwave_period_pw(
	hal_pulseo_channel_t channel,
	hal_second_u32_l30_t period,
	hal_second_u32_l30_t pulse_width)
{
	CallKrakenMethod(n_wpHal, &IHal::hal_pulseo_set_rwave_period_pw, channel, period, pulse_width);
}
void hal_power_init()
{
	CallKrakenMethod(n_wpHal, &IHal::hal_power_init);
}
hal_volt_s16_l07_t hal_power_get_voltage(hal_power_supply_t supply)
{
	return CallKrakenMethod(n_wpHal, 0, &IHal::hal_power_get_voltage, supply);
}
hal_diagnostic_t hal_power_get_diagnostics(hal_power_supply_t supply)
{
	return CallKrakenMethod(n_wpHal, HAL_DEFINITE_NO_FAULT, &IHal::hal_power_get_diagnostics, supply);
}
void hal_pulsei_init()
{
	CallKrakenMethod(n_wpHal, &IHal::hal_pulsei_init);
}
hal_discrete_t hal_pulsei_get_discrete(hal_pulsei_channel_t channel)
{
	return CallKrakenMethod(n_wpHal, HAL_DISCRETE_INACTIVE, &IHal::hal_pulsei_get_discrete, channel);
}
hal_cat_partno_t hal_boot_get_ecm_partno()
{
	return CallKrakenMethod(n_wpHal, hal_cat_partno_t{10, "0000000000"}, &IHal::hal_boot_get_ecm_partno);
}
hal_ecm_serialno_t hal_boot_get_ecm_serialno()
{
	// Uses only 15 '0' so that the null will be in the last byte
	return CallKrakenMethod(n_wpHal, hal_ecm_serialno_t{16, "000000000000000"}, &IHal::hal_boot_get_ecm_serialno);
}
hal_location_code_t hal_boot_read_location_code()
{
	return CallKrakenMethod(n_wpHal, 0, &IHal::hal_boot_read_location_code);
}
void hal_rtc_init()
{
	CallKrakenMethod(n_wpHal, &IHal::hal_rtc_init);
}
hal_s32_t hal_rtc_wakeup_alarm_clear()
{
	return CallKrakenMethod(n_wpHal, HAL_RTC_OK, &IHal::hal_rtc_wakeup_alarm_clear);
}
hal_s32_t hal_rtc_read(struct tm * const tp)
{
	return CallKrakenMethod(n_wpHal, HAL_RTC_OK, &IHal::hal_rtc_read, tp);
}
void hal_adci_init()
{
	CallKrakenMethod(n_wpHal, &IHal::hal_adci_init);
}
hal_s16_l05_t hal_adci_get_temperature(hal_adci_channel_t channel)
{
	return CallKrakenMethod(n_wpHal, 0, &IHal::hal_adci_get_temperature, channel);
}

struct hal_canv3_port_socket_s {};
volatile hal_canv3_port_socket_t hal_canv3_port_socketcan0_arm64_guest{};
volatile hal_canv3_port_socket_t hal_canv3_port_socketcan1_arm64_guest{};
volatile hal_canv3_port_socket_t hal_canv3_port_socketcan2_arm64_guest{};
volatile hal_canv3_port_socket_t hal_canv3_port_socketcan3_arm64_guest{};
volatile hal_canv3_port_socket_t hal_canv3_port_socketcan4_arm64_guest{};
volatile hal_canv3_port_socket_t hal_canv3_port_socketcan5_arm64_guest{};
