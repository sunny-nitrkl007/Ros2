/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclEncrypt.h

#include "SclEncrypt.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<ISclEncrypt> n_wpSclEncrypt;
}

namespace Shark
{
namespace Kraken
{
void SetISclEncrypt(std::shared_ptr<ISclEncrypt> const& spSclEncrypt)
{
	n_wpSclEncrypt = spSclEncrypt;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

scl_encrypt_results_t scl_encrypt_init()
{
	return CallKrakenMethod(n_wpSclEncrypt, SCL_ENCRYPT_SUCCESS, &ISclEncrypt::scl_encrypt_init);
}
scl_encrypt_results_t scl_encrypt_begin_encryption(
	uint_least16_t feat_indx,
	const uint_least8_t* src_buff,
	uint_least8_t* encrypt_buff,
	uint_least32_t buff_size)
{
	return CallKrakenMethod(n_wpSclEncrypt, SCL_ENCRYPT_SUCCESS, &ISclEncrypt::scl_encrypt_begin_encryption,
		feat_indx,
		src_buff,
		encrypt_buff,
		buff_size);
}
scl_encrypt_results_t scl_encrypt_register_feature(
		scl_encrypt_key_type_t key_type,
		const scl_encrypt_key_info_t* key_info,
		scl_encrypt_alg_type_t alg_type,
		scl_encrypt_feat_indx_t *feat_indx)
{
	return CallKrakenMethod(n_wpSclEncrypt, SCL_ENCRYPT_SUCCESS, &ISclEncrypt::scl_encrypt_register_feature,
		key_type,
		key_info,
		alg_type,
		feat_indx);
}

// Required externals
const void* scl_encrypt_key_am1_key2;
