/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Bdt.h

#include "Bdt.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<IBdt> n_wpBdt;
}

namespace Shark
{
namespace Kraken
{
void SetIBdt(std::shared_ptr<IBdt> const& spBdt)
{
	n_wpBdt = spBdt;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

boolean_t bdt_set_callback_block_count (unsigned_16 count)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_set_callback_block_count, count);
}
boolean_t bdt_set_datatype_count (unsigned_16 count)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_set_datatype_count, count);
}
unsigned_16 bdt_set_callback_block (
	bdt_query_index_supported_t bdt_query_index_supported,
	bdt_obtain_data_access_t bdt_obtain_data_access,
	bdt_release_data_access_t bdt_release_data_access,
	bdt_get_data_size_t bdt_get_data_size,
	bdt_open_data_t bdt_open_data,
	bdt_close_data_t bdt_close_data,
	bdt_get_data_t bdt_get_data,
	bdt_set_data_t bdt_set_data)
{
	return CallKrakenMethod(n_wpBdt, 1, &IBdt::bdt_set_callback_block,
		bdt_query_index_supported,
		bdt_obtain_data_access,
		bdt_release_data_access,
		bdt_get_data_size,
		bdt_open_data,
		bdt_close_data,
		bdt_get_data,
		bdt_set_data);
}
boolean_t bdt_set_datatype (unsigned_16 datatype, unsigned_16 handle)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_set_datatype, datatype, handle);
}
void bdt_set_period (unsigned_32 period)
{
	CallKrakenMethod(n_wpBdt, &IBdt::bdt_set_period, period);
}
boolean_t bdt_init(
	unsigned_8 NumRxCon, unsigned_32 RxBufSize,
	unsigned_8 NumTxCon, unsigned_32 TxBufSize,
	unsigned_8 NumDatalinkCon)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_init, NumRxCon, RxBufSize, NumTxCon, TxBufSize, NumDatalinkCon);
}
void bdt_main()
{
	CallKrakenMethod(n_wpBdt, &IBdt::bdt_main);
}
bdt_error_t bdt_req_connection(
	unsigned_8      type,
	unsigned_8      sid,
	unsigned_8      did,
	unsigned_16     datatype,
	unsigned_32     index,
	unsigned_32     size,
	unsigned_8      rate,
	bdt_app_info_t *app_info,
	unsigned_8      datalink_id,
	unsigned_8      encyption,
	unsigned_8      compress)
{
	return CallKrakenMethod(n_wpBdt, BDT_ERROR_NONE, &IBdt::bdt_req_connection,
		type, sid, did, datatype, index, size, rate, app_info, datalink_id, encyption, compress);
}
boolean bdt_set_report_error_hdlr(
	void *report_error_context,
	bdt_report_error_hdlr_t bdt_report_error_hdlr)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_set_report_error_hdlr, report_error_context, bdt_report_error_hdlr);
}
unsigned_8 bdt_j1939_init(scl_j1939_link_t Ph_link)
{
	return CallKrakenMethod(n_wpBdt, 1, &IBdt::bdt_j1939_init, Ph_link);
}
void bdt_j1939_set_resource(const oel_rtos_resource_config_t *resource)
{
	CallKrakenMethod(n_wpBdt, &IBdt::bdt_j1939_set_resource, resource);
}
bool_t bdt_action_init(const bdt_action_config_t *config)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_action_init, config);
}
uint_least8_t bdt_eth_init(void *http_server, uint_least32_t fid)
{
	return CallKrakenMethod(n_wpBdt, 2, &IBdt::bdt_eth_init, http_server, fid);
}
bdt_error_t bdt_eth_req_connection(
	unsigned_8 type,
	unsigned_16 data_type,
	unsigned_32 data_idx,
	unsigned_32 ptxt_file_size,
	bdt_app_info_t* app_info,
	unsigned_8 encryption,
	unsigned_8 compression,
	unsigned_8 datalink_id,
	unsigned_32 server_fid)
{
	return CallKrakenMethod(n_wpBdt, BDT_ERROR_NONE, &IBdt::bdt_eth_req_connection,
		type, data_type, data_idx, ptxt_file_size, app_info, encryption, compression, datalink_id, server_fid);
}
bool_least_t bdt_eth_set_report_error_hdlr(
	bdt_eth_report_error_hdlr_t error_handler,
	void* report_context)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_eth_set_report_error_hdlr, error_handler, report_context);
}
bdt_action_req_status_t bdt_action_req_command(
	bdt_action_cmd_id_t cmd_id,
	unsigned_8 sid,
	unsigned_8 did,
	unsigned_16 data_type,
	unsigned_32 data_index,
	bdt_action_resp_notify_t resp_notify,
	void* context,
	unsigned_8 datalink_id)
{
	return CallKrakenMethod(n_wpBdt, BDT_ACTION_REQ_ACCEPT, &IBdt::bdt_action_req_command,
		cmd_id, sid, did, data_type, data_index, resp_notify, context, datalink_id);
}
bdt_action_req_status_t bdt_eth_action_req_command(
	bdt_action_cmd_id_t cmd_id,
	unsigned_32 local_fid,
	unsigned_32 server_fid,
	unsigned_16 data_type,
	unsigned_32 data_index,
	bdt_eth_action_resp_notify_t resp_notify,
	void* context,
	unsigned_8 datalink_id)
{
	return CallKrakenMethod(n_wpBdt, BDT_ACTION_REQ_ACCEPT, &IBdt::bdt_eth_action_req_command,
		cmd_id, local_fid, server_fid, data_type, data_index, resp_notify, context, datalink_id);
}
boolean_t bdt_set_conn_status_hdlr_max_count(
	const unsigned_8 bdt_conn_status_hdlr_max_cnt)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_set_conn_status_hdlr_max_count, bdt_conn_status_hdlr_max_cnt);
}
boolean bdt_set_notify_conn_status_hdlr(
	void* conn_status_context,
	bdt_notify_conn_status_hdlr_t notify_conn_status_hdlr)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_set_notify_conn_status_hdlr, conn_status_context, notify_conn_status_hdlr);
}
bool_least_t bdt_eth_set_conn_status_hdlr_max_count(uint_least8_t num_conn_status_hndlrs)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_eth_set_conn_status_hdlr_max_count, num_conn_status_hndlrs);
}
bool_least_t bdt_eth_set_notify_conn_status_hdlr(
	bdt_eth_notify_conn_status_hdlr_t conn_status_handler,
	void* conn_status_context)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_eth_set_notify_conn_status_hdlr, conn_status_handler, conn_status_context);
}
boolean_t bdt_dl_datatype_accesslist_init(unsigned_8 datalink_id)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_dl_datatype_accesslist_init, datalink_id);
}
boolean_t bdt_dl_datatype_accesslist_add(unsigned_8 datalink_id, unsigned_16 datatype)
{
	return CallKrakenMethod(n_wpBdt, TRUE, &IBdt::bdt_dl_datatype_accesslist_add, datalink_id, datatype);
}
