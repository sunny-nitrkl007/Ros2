/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclJ1939.h

#include "SclJ1939.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<IJ1939> n_wpJ1939;
std::weak_ptr<IJ1939MemoryBuffers> n_wpJ1939MemoryBuffers;
}

namespace Shark
{
namespace Kraken
{
void SetIJ1939(std::shared_ptr<IJ1939> const& spJ1939)
{
	n_wpJ1939 = spJ1939;
}
void SetIJ1939MemoryBuffers(std::shared_ptr<IJ1939MemoryBuffers> const& spJ1939MemoryBuffers)
{
	n_wpJ1939MemoryBuffers = spJ1939MemoryBuffers;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

boolean_t scl_j1939_set_num_links(
   unsigned_8  Pu8_num_links )
{
	return CallKrakenMethod(n_wpJ1939, TRUE, &IJ1939::scl_j1939_set_num_links, Pu8_num_links);
}
scl_j1939_link_t scl_j1939_establish_link
(
   volatile hal_canv3_port_t* Ppst_port,
   const scl_j1939_addr_tbl_t*   Ppast_address_table,
   const unsigned_8 Pu8_num_in_address_table,
   const unsigned_16       Pu16_num_of_mbufs,
   const unsigned_16       Pu16_num_of_extensions,
   const unsigned_16       Pu16_numb_of_tpcbs,
   const unsigned_8        Pu8_max_net_size,
   scl_j1939_ac_status_cb_t*  Ppfn_ac_status_cb,
   const scl_j1939_config_t* Ppst_j1939_config
)
{
	return CallKrakenMethod(n_wpJ1939, 0, &IJ1939::scl_j1939_establish_link,
		Ppst_port,
		Ppast_address_table,
		Pu8_num_in_address_table,
		Pu16_num_of_mbufs,
		Pu16_num_of_extensions,
		Pu16_numb_of_tpcbs,
		Pu8_max_net_size,
		Ppfn_ac_status_cb,
		Ppst_j1939_config);
}
boolean_t scl_j1939_set_ppgn_enable_table(
   const scl_j1939_link_t        Ph_link,
   const int_8             Pi8_ppgn_enable_size,
   const scl_j1939_ppgn_enable_t  Past_ppgn_enable_tbl[] )
{
	return CallKrakenMethod(
		n_wpJ1939, TRUE, &IJ1939::scl_j1939_set_ppgn_enable_table, Ph_link, Pi8_ppgn_enable_size, Past_ppgn_enable_tbl);
}
boolean_t scl_j1939_set_max_dm13_clients(
   unsigned_8 max_stop_bcast_clients,
   unsigned_8 max_suspend_clients,
   boolean_t (*is_sbcast_allowed_cb)(void))
{
	return CallKrakenMethod(n_wpJ1939, TRUE, &IJ1939::scl_j1939_set_max_dm13_clients,
		max_stop_bcast_clients,
		max_suspend_clients,
		is_sbcast_allowed_cb);
}
boolean_t scl_j1939_install_dm13(
   scl_j1939_link_t link,
   unsigned_8 ecm_index)
{
	return CallKrakenMethod(n_wpJ1939, TRUE, &IJ1939::scl_j1939_install_dm13, link, ecm_index);
}
boolean_t scl_j1939_add_suspend_client(
   scl_j1939_suspend_cb_t *suspend_cb,
   void *context)
{
	return CallKrakenMethod(n_wpJ1939, TRUE, &IJ1939::scl_j1939_add_suspend_client, suspend_cb, context);
}
void scl_j1939_init_tasks(
   const int_16   Pi16_task_period )
{
	CallKrakenMethod(n_wpJ1939, &IJ1939::scl_j1939_init_tasks, Pi16_task_period);
}
boolean_t scl_j1939_cmgr_init(
	scl_j1939_link_t link,
	unsigned_8 num_connections,
	unsigned_8 num_services_per_connection)
{
	return CallKrakenMethod(n_wpJ1939, TRUE, &IJ1939::scl_j1939_cmgr_init, link, num_connections, num_services_per_connection);
}
void scl_j1939_periodic_ctrl_task()
{
	CallKrakenMethod(n_wpJ1939, &IJ1939::scl_j1939_periodic_ctrl_task);
}
boolean_t scl_j1939_que_tx_msg_by_address(
	const scl_j1939_link_t Ph_link,
	const unsigned_32 Pu32_pgn,
	const unsigned_8  Pu8_priority,
	const unsigned_8  Pu8_da,
	const int_8       Pi8_ecm,
	const unsigned_8  Pau8_data[],
	const unsigned_16 Pu16_data_length)
{
	return CallKrakenMethod(n_wpJ1939, TRUE, &IJ1939::scl_j1939_que_tx_msg_by_address,
		Ph_link,
		Pu32_pgn,
		Pu8_priority,
		Pu8_da,
		Pi8_ecm,
		Pau8_data,
		Pu16_data_length);
}
boolean_t scl_j1939_que_tx_msg_by_name(
	const scl_j1939_link_t  Ph_link,
	const unsigned_32 Pu32_pgn,
	const unsigned_8  Pu8_priority,
	const unsigned_8  Pau8_dest_name[SCL_J1939_SHORTHAND_NAME_LEN],
	const int_8       Pi8_ecm,
	const unsigned_8  Pau8_data[],
	const unsigned_16 Pu16_data_length )
{
	return CallKrakenMethod(n_wpJ1939, TRUE, &IJ1939::scl_j1939_que_tx_msg_by_name,
		Ph_link,
		Pu32_pgn,
		Pu8_priority,
		Pau8_dest_name,
		Pi8_ecm,
		Pau8_data,
		Pu16_data_length);
}
bool_t scl_j1939_cat_ppgn_id_install_command(
	scl_j1939_link_t Ph_link,
	const SCL_J1939_CAT_PPGN_ID_HDLR_t *id_hdlr_blk)
{
	return CallKrakenMethod(n_wpJ1939, TRUE, &IJ1939::scl_j1939_cat_ppgn_id_install_command, Ph_link, id_hdlr_blk);
}
bool_t scl_j1939_cat_ppgn_id_install_command_id(
	scl_j1939_link_t Ph_link,
	const SCL_J1939_CAT_PPGN_ID_HDLR_t *id_hdlr_blk)
{
	return CallKrakenMethod(n_wpJ1939, TRUE, &IJ1939::scl_j1939_cat_ppgn_id_install_command_id, Ph_link, id_hdlr_blk);
}
void scl_j1939_cat_ppgn_hdlr(
	const scl_j1939_link_t,
	const scl_j1939_rx_msg_t *,
	const int_8,
	const SCL_J1939_RX_MSG_CB_ENUM_t,
	const scl_j1939_mbuf_hdr_t *)
{
}
unsigned_8 scl_j1939_add_tx_msg_table_entry(
	const scl_j1939_link_t Ph_link,
	const unsigned_8 Pu8_ecm,
	const scl_j1939_tx_msg_t* Pst_tx_msg_entry,
	void* Ppv_context,
	scl_j1939_tx_msg_context_builder Ppfn_context_builder_cb)
{
	return CallKrakenMethod(n_wpJ1939, 0, &IJ1939::scl_j1939_add_tx_msg_table_entry,
		Ph_link,
		Pu8_ecm,
		Pst_tx_msg_entry,
		Ppv_context,
		Ppfn_context_builder_cb);
}
scl_j1939_bldr_t* scl_j1939_bldr_get_pgn(
	scl_j1939_link_t Ph_link,
	unsigned_8 Pu8_ecm_index,
	unsigned_32 pgn,
	boolean_t address_by_name,
	unsigned_8 dest_address,
	const unsigned_8 *dest_short_name,
	unsigned_8 length,
	boolean_t *new_bldr)
{
	auto const pDefaultResult = reinterpret_cast<scl_j1939_bldr_t*>(0x42);
	*new_bldr = TRUE;
	return CallKrakenMethod(n_wpJ1939, pDefaultResult, &IJ1939::scl_j1939_bldr_get_pgn,
		Ph_link,
		Pu8_ecm_index,
		pgn,
		address_by_name,
		dest_address,
		dest_short_name,
		length,
		new_bldr);
}
boolean_t scl_j1939_bldr_param_tx(
	scl_j1939_mbuf_hdr_t *,
	const scl_j1939_tx_msg_t *,
	unsigned_8,
	void *)
{
	return TRUE;
}
boolean_t scl_j1939_bldr_add_param(
	scl_j1939_bldr_t *bldr,
	const scl_j1939_param_tx_config_t *config,
	boolean_t override_previous)
{
	return CallKrakenMethod(n_wpJ1939, TRUE, &IJ1939::scl_j1939_bldr_add_param, bldr, config, override_previous);
}
boolean_t scl_j1939_set_rx_msg_send_request_bit(
	const scl_j1939_link_t Ph_link,
	const int_8 Pi8_ecm,
	const unsigned_8 Pu8_tbl_idx )
{
	return CallKrakenMethod(n_wpJ1939, TRUE, &IJ1939::scl_j1939_set_rx_msg_send_request_bit, Ph_link, Pi8_ecm, Pu8_tbl_idx);
}
unsigned_8 scl_j1939_add_rx_msg_table_entry(
	const scl_j1939_link_t Ph_link,
	const unsigned_8 Pu8_ecm,
	const scl_j1939_rx_msg_t* Pst_rx_msg_entry,
	void* Ppv_context,
	scl_j1939_rx_msg_context_parser Ppfn_context_parser_cb)
{
	return CallKrakenMethod(
		n_wpJ1939,
		0,
		&IJ1939::scl_j1939_add_rx_msg_table_entry,
		Ph_link,
		Pu8_ecm,
		Pst_rx_msg_entry,
		Ppv_context,
		Ppfn_context_parser_cb);
}
boolean_t scl_j1939_find_name_by_address(
	const scl_j1939_link_t Ph_link,
	const unsigned_8 address,
	unsigned_8 Pau8_name[SCL_J1939_NAME_LEN])
{
	return CallKrakenMethod(
		n_wpJ1939,
		TRUE,
		&IJ1939::scl_j1939_find_name_by_address,
		Ph_link,
		address,
		Pau8_name);
}
boolean_t scl_j1939_get_first_nar_entry(
	const scl_j1939_link_t Ph_link,
	scl_j1939_nar_entry_t* nar_entry,
	scl_j1939_nar_handle_t* nar_handle)
{
	return CallKrakenMethod(n_wpJ1939, FALSE, &IJ1939::scl_j1939_get_first_nar_entry, Ph_link, nar_entry, nar_handle);
}
boolean_t scl_j1939_get_next_nar_entry(
	const scl_j1939_link_t Ph_link,
	scl_j1939_nar_entry_t* nar_entry,
	scl_j1939_nar_handle_t* nar_handle)
{
	return CallKrakenMethod(n_wpJ1939, FALSE, &IJ1939::scl_j1939_get_next_nar_entry, Ph_link, nar_entry, nar_handle);
}


unsigned_16 scl_j1939_get_mbuf_len(const scl_j1939_mbuf_hdr_t* Ppst_mbuf)
{
	return CallKrakenMethod(n_wpJ1939MemoryBuffers, 0, &IJ1939MemoryBuffers::scl_j1939_get_mbuf_len, Ppst_mbuf);
}
boolean_t scl_j1939_get_data_from_mbuf
(
	const scl_j1939_mbuf_hdr_t* Ppst_mbuf,
	unsigned_8* Pau8_dest,
	const unsigned_16 Pu16_len,
	const unsigned_16 Pu16_start
)
{
	return CallKrakenMethod(n_wpJ1939MemoryBuffers, TRUE, &IJ1939MemoryBuffers::scl_j1939_get_data_from_mbuf,
		Ppst_mbuf,
		Pau8_dest,
		Pu16_len,
		Pu16_start);
}
unsigned_8 scl_j1939_get_mbuf_sa(const scl_j1939_mbuf_hdr_t* Ppst_mbuf)
{
	return CallKrakenMethod(n_wpJ1939MemoryBuffers, 0xFF, &IJ1939MemoryBuffers::scl_j1939_get_mbuf_sa, Ppst_mbuf);
}
boolean_t scl_j1939_get_cat_ext_from_mbuf(
	const scl_j1939_mbuf_hdr_t* Ppst_mbuf,
	unsigned_16* Ppu16_value,
	const unsigned_16 Pu16_start)
{
	return CallKrakenMethod(n_wpJ1939MemoryBuffers, FALSE, &IJ1939MemoryBuffers::scl_j1939_get_cat_ext_from_mbuf,
		Ppst_mbuf,
		Ppu16_value,
		Pu16_start);
}
boolean_t scl_j1939_fill_mbuf_data(
	scl_j1939_mbuf_hdr_t* Ppst_mbuf,
	const void* Ppu8_data,
	unsigned_16 Pu16_length)
{
	return CallKrakenMethod(n_wpJ1939MemoryBuffers, FALSE, &IJ1939MemoryBuffers::scl_j1939_fill_mbuf_data,
		Ppst_mbuf,
		Ppu8_data,
		Pu16_length);
}