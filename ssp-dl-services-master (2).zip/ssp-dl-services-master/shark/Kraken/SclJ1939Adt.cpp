/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclJ1939Adt.h

#include "SclJ1939Adt.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<IJ1939Adt> n_wpJ1939Adt;
}

namespace Shark
{
namespace Kraken
{
void SetIJ1939Adt(std::shared_ptr<IJ1939Adt> const& spJ1939Adt)
{
	n_wpJ1939Adt = spJ1939Adt;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

scl_adt_j1939_link_handle_t scl_adt_j1939_link_init(scl_j1939_link_t link)
{
	return CallKrakenMethod(n_wpJ1939Adt, 42, &IJ1939Adt::scl_adt_j1939_link_init, link);
}
bool_t scl_adt_j1939_link_add_ecm(scl_adt_j1939_link_handle_t adt_j1939_hndl, uint_least8_t ecm_idx)
{
	return CallKrakenMethod(n_wpJ1939Adt, TRUE, &IJ1939Adt::scl_adt_j1939_link_add_ecm, adt_j1939_hndl, ecm_idx);
}
uint_least8_t scl_adt_j1939_link_add_group(
	scl_adt_j1939_link_handle_t adt_j1939_hndl,
	uint_least8_t ecm_idx,
	uint_least8_t remote_addr,
	uint_least8_t num_of_pids,
	bool_least_t dm13_support,
	const scl_adt_j1939_client_grp_pid_config_ptr_t* client_grp_pid_configs,
	scl_adt_j1939_diag_contxt_tbl_t *diag_context_ptrs,
	scl_adt_j1939_event_clbk_t* event_callback,
	void* event_callback_context)
{
	return CallKrakenMethod(n_wpJ1939Adt, 1, &IJ1939Adt::scl_adt_j1939_link_add_group,
		adt_j1939_hndl,
		ecm_idx,
		remote_addr,
		num_of_pids,
		dm13_support,
		client_grp_pid_configs,
		diag_context_ptrs,
		event_callback,
		event_callback_context);
}
bool_t scl_adt_j1939_client_grp_set_timeout(
	scl_adt_j1939_link_handle_t adt_j1939_hndl,
	uint_least8_t ecm_idx,
	uint_least8_t remote_addr,
	uint_least8_t group_id,
	uint_least32_t timeout)
{
	return CallKrakenMethod(n_wpJ1939Adt, TRUE, &IJ1939Adt::scl_adt_j1939_client_grp_set_timeout,
		adt_j1939_hndl,
		ecm_idx,
		remote_addr,
		group_id,
		timeout);
}