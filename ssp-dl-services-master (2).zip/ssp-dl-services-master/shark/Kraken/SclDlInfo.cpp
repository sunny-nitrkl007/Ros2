/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclDlInfo.h

#include "SclDlInfo.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<ISclDlInfo> n_wpSclDlInfo;
}

namespace Shark
{
namespace Kraken
{
void SetISclDlInfo(std::shared_ptr<ISclDlInfo> const& spSclDlInfo)
{
	n_wpSclDlInfo = spSclDlInfo;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

scl_dlinfo_error_t scl_dlinfo_init(const scl_dlinfo_config_t* dlinfo_config)
{
	return CallKrakenMethod(n_wpSclDlInfo, SCL_DLINFO_SUCCESS, &ISclDlInfo::scl_dlinfo_init, dlinfo_config);
}
scl_dlinfo_error_t scl_dlinfo_add_j39_link(
	scl_health_j39_link_t* health_j39_link,
	const scl_dlinfo_j39_link_config_t* link_config)
{
	return CallKrakenMethod(n_wpSclDlInfo, SCL_DLINFO_SUCCESS, &ISclDlInfo::scl_dlinfo_add_j39_link, health_j39_link, link_config);
}
void scl_dlinfo_keyswitch_status(bool_least_t keyswitch_on)
{
	CallKrakenMethod(n_wpSclDlInfo, &ISclDlInfo::scl_dlinfo_keyswitch_status, keyswitch_on);
}
bool_t scl_dlinfo_ok_to_shutdown(void)
{
	return CallKrakenMethod(n_wpSclDlInfo, TRUE, &ISclDlInfo::scl_dlinfo_ok_to_shutdown);
}
