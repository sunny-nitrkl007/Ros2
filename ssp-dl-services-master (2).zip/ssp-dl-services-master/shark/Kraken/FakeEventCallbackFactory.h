/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Fake Event Callback Factory

#pragma once

#include "SharkUtilities/IEventCallbackFactory.h"
#include "Utilities/IUpdatables.h"
#include <chrono>
#include <memory>
#include <mutex>
#include <vector>

namespace Shark
{
namespace SharkUtilities
{
namespace Kraken
{
class FakeTimedCallback;

class IFakeEventCallbackManager : public IEventCallbackFactory
{
public:
	// Gets the time from FakeClock and performs all necessary callbacks.
	// Note: Will perform every periodic callback whose time has passed.
	virtual void Update() = 0;

	virtual void PerformFilesystemEventCallback(std::string const& path, std::string const& name, uint32_t event) = 0;
	virtual void SetCreatePeriodicTimerCallback(std::function<void()>&& callback) = 0;
protected:
	~IFakeEventCallbackManager() override = default;
};

class FakeFilesystemCallbackDetails;

class FakeEventCallbackFactory final : public IFakeEventCallbackManager
{
public:
	static std::unique_ptr<FakeEventCallbackFactory> CreateFake();
	static IFakeEventCallbackManager& GetInstance();

	FakeEventCallbackFactory(std::unique_ptr<Utilities::IUpdatables>&& spUpdatables);
	void Remove(std::shared_ptr<FakeTimedCallback> const& spTimedCallback);
// IFakeEventCallbackManager
	void Update() override;
	void PerformFilesystemEventCallback(std::string const& path, std::string const& name, uint32_t event) override;
	void SetCreatePeriodicTimerCallback(std::function<void()>&& callback) override;
// IEventCallbackFactory
	std::unique_ptr<ITimedCallback> CreateTimedCallbackThatFiresIn(
		std::chrono::milliseconds milliseconds,
		std::function<void()>&& callback) override;
	std::unique_ptr<ITimedCallback> CreatePeriodicTimedCallback(
		std::chrono::milliseconds periodMilliseconds,
		std::function<void()>&& callback) override;
	std::unique_ptr<IEventCallback> CreateFilesystemEventCallback(
		std::string const& path,
		uint32_t eventMask,
		FilesystemEventCallbackFunction&& callback) override;
	void Shutdown() override {}
private:
	std::unique_ptr<ITimedCallback> CreateFakeTimedCallback(
		std::chrono::milliseconds milliseconds,
		std::function<void()>&& callback,
		bool repeats);
	std::vector<std::shared_ptr<FakeFilesystemCallbackDetails>> TryFindFilesystemCallbackDetails(std::string const& path);
	void RemoveStaleFilesystemCallbackDetails();

	std::unique_ptr<Utilities::IUpdatables> const m_spTimedCallbacks;

	struct Modification
	{
		bool add;
		std::shared_ptr<FakeTimedCallback> spTimedCallback;
	};
	std::vector<Modification> m_modificationQueue{};
	std::mutex m_mutex{};

	std::vector<std::weak_ptr<FakeFilesystemCallbackDetails>> m_filesystemCallbackDetails{};
	std::function<void()> m_createPeriodicTimerCallback{};
};
}
}
}
