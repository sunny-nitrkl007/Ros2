/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See TimerFd.h

#include "TimerFd.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

namespace
{
std::weak_ptr<Shark::Kraken::ITimerFd> n_wpTimerFd;
}

namespace Shark
{
namespace Kraken
{
void SetITimerFd(std::shared_ptr<Shark::Kraken::ITimerFd> const& spTimerFd)
{
	n_wpTimerFd = spTimerFd;
}

using Utilities::Kraken::CallKrakenMethod;

int timerfd_create(clockid_t clock_id, int flags)
{
	return CallKrakenMethod(n_wpTimerFd, -1, &ITimerFd::timerfd_create, clock_id, flags);
}
int timerfd_settime(int fd, int flags, const struct itimerspec* new_value, struct itimerspec* old_value)
{
	return CallKrakenMethod(n_wpTimerFd, -1, &ITimerFd::timerfd_settime, fd, flags, new_value, old_value);
}
}
}

