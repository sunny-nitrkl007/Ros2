/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See CsfAtsJ1939.h

#include "CsfAtsJ1939.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<ICsfAtsJ1939> n_wpCsfAtsJ1939;
}

namespace Shark
{
namespace Kraken
{
void SetICsfAtsJ1939(std::shared_ptr<ICsfAtsJ1939> const& spCsfAtsJ1939)
{
	n_wpCsfAtsJ1939 = spCsfAtsJ1939;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

csf_ats_j1939_client_ret_type_t csf_ats_j1939_client_init(
	const csf_ats_j1939_client_config_t* p_config,
	scl_j1939_link_t h_link,
	uint_least8_t ecm_indx)
{
	return CallKrakenMethod(
		n_wpCsfAtsJ1939, CSF_ATS_J1939_CLIENT_SUCCESS, &ICsfAtsJ1939::csf_ats_j1939_client_init, p_config, h_link, ecm_indx);
}
void csf_ats_j1939_client_update()
{
	CallKrakenMethod(n_wpCsfAtsJ1939, &ICsfAtsJ1939::csf_ats_j1939_client_update);
}
csf_ats_j1939_client_ret_type_t csf_ats_j1939_client_cmd_req(csf_ats_j1939_cmd_req_t cmd_req)
{
	return CallKrakenMethod(n_wpCsfAtsJ1939, CSF_ATS_J1939_CLIENT_SUCCESS, &ICsfAtsJ1939::csf_ats_j1939_client_cmd_req, cmd_req);
}
csf_ats_j1939_client_ret_type_t csf_ats_j1939_client_seed_req(csf_ats_j1939_seed_clbk_t* p_serv_seed_clbk)
{
	return CallKrakenMethod(
		n_wpCsfAtsJ1939, CSF_ATS_J1939_CLIENT_SUCCESS, &ICsfAtsJ1939::csf_ats_j1939_client_seed_req, p_serv_seed_clbk);
}
