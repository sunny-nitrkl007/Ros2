/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Clock.h

#include "SclClock.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<IClock> n_wpClock;
}

namespace Shark
{
namespace Kraken
{
void SetIClock(std::shared_ptr<IClock> const& spClock)
{
	n_wpClock = spClock;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

clock_result_t clock_ginit()
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_ginit);
}
clock_result_t clock_go()
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_go);
}
clock_result_t clock_runservice(clock_runstatus_t go)
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_runservice, go);
}
clock_time_t clock_getservice_sec()
{
	return CallKrakenMethod(n_wpClock, 0, &IClock::clock_getservice_sec);
}
clock_result_t clock_setservice_sec(clock_time_t newtime)
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_setservice_sec, newtime);
}
clock_result_t clock_update()
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_update);
}
clock_result_t clock_rtc_init()
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_rtc_init);
}
clock_result_t clock_rtc_init_v2()
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_rtc_init_v2);
}
clock_result_t clock_getreal_struct_tm2 ( struct clock_tm *a,bool_least_t *is_secured )
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_getreal_struct_tm2, a, is_secured);
}
clock_result_t clock_tzone_init(NVM_block_handle_t time_zone_handle)
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_tzone_init, time_zone_handle);
}
clock_result_t clock_tzone_init_v2(unsigned_32 tzone_block_id)
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_tzone_init_v2, tzone_block_id);
}
clock_result_t clock_tzone_get(tzone_tx_comm_struct *tzone_comm_ptr,bool_least_t *is_secured)
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_tzone_get, tzone_comm_ptr, is_secured);
}
clock_result_t clock_tzone_set(tzone_rcv_comm_struct *tzone_comm_ptr,bool_least_t is_secured)
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_tzone_set, tzone_comm_ptr, is_secured);
}
clock_result_t clock_tzone_get_local_tm2(struct clock_tm *curr_local_tm, bool_least_t *is_secured)
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_tzone_get_local_tm2, curr_local_tm, is_secured);
}
bool_least_t clock_rtc_sec_fps_config(
	scl_fps_rc_token_ifc_t* hdlr_get_feat_token,
	void* get_feat_token_context,
	clock_fps_feat_token_increment* hdlr_inc_feat_token,
	void* inc_feat_token_context)
{
	return CallKrakenMethod(
		n_wpClock, TRUE, &IClock::clock_rtc_sec_fps_config, hdlr_get_feat_token, get_feat_token_context, hdlr_inc_feat_token, inc_feat_token_context);
}
clock_result_t clock_rtc_sec_init(const clock_rtc_sec_config_t *rtc_sec_config)
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_rtc_sec_init, rtc_sec_config);
}
void clock_rtc_set_sec_enabled(bool_least_t security_status)
{
	CallKrakenMethod(n_wpClock, &IClock::clock_rtc_set_sec_enabled, security_status);
}
clock_result_t clock_rtc_configure_time_adj(unsigned_32 slew_rate_ms, unsigned_32 slew_limit_ms)
{
	return CallKrakenMethod(n_wpClock, clock_RESULT_SUCCESS, &IClock::clock_rtc_configure_time_adj, slew_rate_ms, slew_limit_ms);
}
clock_tm n_localTime{0, 0, 0, 12, 23, 6, 123, 5, 189, 0};
clock_tm* clock_tzone_get_local_tm()
{
	return CallKrakenMethod(n_wpClock, &n_localTime, &IClock::clock_tzone_get_local_tm);
}

// Required dependency
#include <oel_rtos_posix.h>
oel_rtos_semaphore_t* oel_rtos_semaphore_pi_vnew(oel_rtos_semaphore_pi_vconfig_t const*)
{
	return nullptr;
}

