/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Fake OEL

#pragma once

#include "Oel.h"
#include <array>
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <vector>

/// The per-thread task structure. It simply holds a pointer to the task configuration.
struct oel_rtos_tcb_base_s
{
	oel_rtos_posix_task_config_t const* pConfig{};
	oel_rtos_event_t pendingEvents{};
	std::atomic<bool> initialized{};
	std::atomic<bool> runNow{};
};

namespace Shark
{
namespace Kraken
{
using CrcMap = std::unordered_map<std::string, uint_least32_t>;

/// Performs necessary functionality for when there is no OEL.
class FakeOel final : public IOel
{
public:

	// A helper that will automatically KillAllTasks upon destruction to avoid leaks.
	class FakeOelDestroyerHelper
	{
	public:
		explicit FakeOelDestroyerHelper(std::shared_ptr<FakeOel> const& spFakeOel);
		~FakeOelDestroyerHelper();

		std::shared_ptr<FakeOel> GetFakeOel() const;
	private:
		std::shared_ptr<FakeOel> const m_spFakeOel;
	};

	FakeOel(oel_rtos_posix_config_t const& rtosConfig);
	~FakeOel() override;

	/// Returns when all tasks have finished.
	void ExecuteAllTasks();
	void ExecuteTask(std::chrono::milliseconds taskRate);
	void StrobeWatchdog();
	void EnableFakeCrc(std::shared_ptr<std::unordered_map<std::string, uint_least32_t>> spCrcs);

	/// Typically the FakeOel will never be destroyed because the OelWrapper task methods
	/// will always be inside a call to oel_rtos_event_pend which is holding a shared_ptr
	/// to the FakeOel. KillAllTasks() may be used to kill the threads and release the
	/// shared_ptr.
	void KillAllTasks();

// Shark::Kraken::IOel
	void oel_u_init(
	  oel_rtos_init_object_t const*) override;
	void oel_sys_init(
	   void) override;
	void oel_rtos_startup_init(
	   void) override;
	oel_rtos_status_t oel_rtos_task_get_context(
	   oel_rtos_task_context_t* context) override;
	oel_rtos_status_t oel_rtos_event_pend(
	   oel_rtos_task_context_t context,
	   oel_rtos_event_t pend_events,
	   oel_rtos_event_t* received_events) override;
	oel_rtos_status_t oel_rtos_event_post(
	   oel_rtos_task_id_t task_id,
	   oel_rtos_event_t events) override;
	oel_rtos_resource_t* oel_rtos_resource_pi_vnew() override;
	uint_least32_t oel_u_crc_32(
		const uint_least8_t *buffer_ptr,
		size_t length,
		uint_least32_t initial_value) override;
private:
	void CancelAllTaskThreads();
	void WaitForAllTaskThreadsToExit();

	oel_rtos_posix_config_t const& m_rtosConfig;
	bool m_rtosInitialized{false};
	std::mutex m_initializationMutex{};
	std::mutex m_mutex{};
	std::vector<std::thread> m_taskThreads{};
	std::atomic<unsigned> m_taskInitializedCount{};
	std::condition_variable m_aTaskHasBeenInitialized{};
	std::condition_variable m_aTaskShouldRun{};
	std::array<oel_rtos_tcb_base_s, 10> m_taskContexts{}; // Must use array since atomics are not movable or copyable.

	// This needs to be persistent between restarts, but reset between tests, because that is the lifetime of our test databases
	std::weak_ptr<CrcMap> m_wpCrcs{};
};
}
}
