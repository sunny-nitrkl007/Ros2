/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclCalClient.h

#include "SclCalClient.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<ISclCalClient> n_wpSclCalClient;
}

namespace Shark
{
namespace Kraken
{
void SetISclCalClient(std::shared_ptr<ISclCalClient> const& spSclCalClient)
{
	n_wpSclCalClient = spSclCalClient;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

void scl_cal_client_init(void)
{
	CallKrakenMethod(n_wpSclCalClient, SCL_CAL_CLIENT_SUCCESS, &ISclCalClient::scl_cal_client_init);
}
uint_least8_t scl_cal_client_link_add_j1939(
	scl_j1939_link_t link,
	uint_least8_t ecm_index,
	scl_cal_client_status_t* link_stat)
{
	if (link_stat)
	{
		*link_stat = SCL_CAL_CLIENT_SUCCESS;
	}

	return CallKrakenMethod(n_wpSclCalClient, 0, &ISclCalClient::scl_cal_client_link_add_j1939, link, ecm_index, link_stat);
}
uint_least8_t scl_cal_client_link_add_peer_by_addr(
	uint_least8_t link_index,
	uint_least8_t remote_peer_address,
	scl_cal_client_status_t* peer_stat)
{
	if (peer_stat)
	{
		*peer_stat = SCL_CAL_CLIENT_SUCCESS;
	}

	return CallKrakenMethod(
		n_wpSclCalClient, 0, &ISclCalClient::scl_cal_client_link_add_peer_by_addr, link_index, remote_peer_address, peer_stat);
}
uint_least8_t scl_cal_client_peer_add_svc(
	uint_least8_t peer_index,
	scl_cal_client_svc_types_t svc_type,
	scl_cal_client_notify_app_status_t scl_cal_client_notify_status,
	void* context_ptr,
	scl_cal_client_status_t* svc_stat)
{
	if (svc_stat)
	{
		*svc_stat = SCL_CAL_CLIENT_SUCCESS;
	}

	return CallKrakenMethod(n_wpSclCalClient, 0, &ISclCalClient::scl_cal_client_peer_add_svc,
		peer_index,
		svc_type,
		scl_cal_client_notify_status,
		context_ptr,
		svc_stat);
}
scl_cal_client_status_t scl_cal_client_start_svc(uint_least16_t cal_or_srvtst_id, uint_least8_t svc_index)
{
	return CallKrakenMethod(
		n_wpSclCalClient, SCL_CAL_CLIENT_SUCCESS, &ISclCalClient::scl_cal_client_start_svc, cal_or_srvtst_id, svc_index);
}
scl_cal_client_status_t scl_cal_client_user_action(
	scl_cal_client_ac_t action_cmd,
	uint_least8_t *ac_data,
	uint_least8_t ac_data_len,
	uint_least8_t svc_index)
{
	return CallKrakenMethod(n_wpSclCalClient, SCL_CAL_CLIENT_SUCCESS, &ISclCalClient::scl_cal_client_user_action,
		action_cmd,
		ac_data,
		ac_data_len,
		svc_index);
}
scl_cal_client_status_t scl_cal_client_last_svc_status(
	uint_least16_t cal_id,
	uint_least8_t svc_index)
{
	return CallKrakenMethod(n_wpSclCalClient, SCL_CAL_CLIENT_SUCCESS, &ISclCalClient::scl_cal_client_last_svc_status,
		cal_id,
		svc_index);
}
scl_cal_client_status_t scl_cal_client_abort_svc(uint_least8_t svc_index)
{
	return CallKrakenMethod(n_wpSclCalClient, SCL_CAL_CLIENT_SUCCESS, &ISclCalClient::scl_cal_client_abort_svc, svc_index);
}
scl_cal_client_status_t scl_cal_client_end_svc(uint_least8_t svc_index)
{
	return CallKrakenMethod(n_wpSclCalClient, SCL_CAL_CLIENT_SUCCESS, &ISclCalClient::scl_cal_client_end_svc, svc_index);
}
scl_cal_client_status_t scl_cal_client_remove_peer(uint_least8_t peer_index)
{
	return CallKrakenMethod(n_wpSclCalClient, SCL_CAL_CLIENT_SUCCESS, &ISclCalClient::scl_cal_client_remove_peer, peer_index);
}
void scl_cal_client_update(void)
{
	CallKrakenMethod(n_wpSclCalClient, SCL_CAL_CLIENT_SUCCESS, &ISclCalClient::scl_cal_client_update);
}
