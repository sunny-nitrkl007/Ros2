/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See FakeOel.h

#include "FakeOel.h"
#include "Utilities/ArrayView.h"
#include "Utilities/narrow_cast.h"
#include <algorithm>
#include <cassert>
#include <chrono>
#include <iostream>

using namespace std::chrono_literals;

namespace Shark
{
namespace Kraken
{
namespace
{
constexpr auto n_dumpCrcInput = false;
}

FakeOel::FakeOelDestroyerHelper::FakeOelDestroyerHelper(std::shared_ptr<FakeOel> const& spFakeOel)
	: m_spFakeOel{spFakeOel}
{
	assert(m_spFakeOel);
}
FakeOel::FakeOelDestroyerHelper::~FakeOelDestroyerHelper()
{
	m_spFakeOel->KillAllTasks();
}
std::shared_ptr<FakeOel> FakeOel::FakeOelDestroyerHelper::GetFakeOel() const
{
	return m_spFakeOel;
}

FakeOel::FakeOel(oel_rtos_posix_config_t const& rtosConfig)
	: m_rtosConfig(rtosConfig)
{
	assert(m_rtosConfig.base.number_of_tasks <= m_taskContexts.size()); // Just increase the array size if this is hit.
}
FakeOel::~FakeOel()
{
	KillAllTasks();
}
void FakeOel::ExecuteAllTasks()
{
	for (auto i = 0; i < m_rtosConfig.base.number_of_tasks; ++i)
	{
		auto const& baseTaskConfig = m_rtosConfig.posix.task_config[i].base;
		if (baseTaskConfig.period != 0)
		{
			// Don't run tasks that are configured to NOT run periodically
			auto const pTaskContext = *baseTaskConfig.task_id;
			oel_rtos_event_post(pTaskContext, OEL_RTOS_TIME_EVENT);
		}
	}
}
void FakeOel::ExecuteTask(std::chrono::milliseconds taskRate)
{
	assert(taskRate != 0ms);
	auto const targetPeriod = OEL_RTOS_SECONDS_DBL_TO_U32_L20(static_cast<double>(taskRate.count()) / 1000.0);
	Utilities::ArrayView<oel_rtos_posix_task_config_t const> const taskConfigs{
		m_rtosConfig.posix.task_config,
		m_rtosConfig.base.number_of_tasks};

	for (auto const& config : taskConfigs)
	{
		if (targetPeriod == config.base.period)
		{
			oel_rtos_event_post(*config.base.task_id, OEL_RTOS_TIME_EVENT);
		}
	}
}
void FakeOel::StrobeWatchdog()
{
	m_rtosConfig.base.watchdog_strobe();
}
void FakeOel::EnableFakeCrc(std::shared_ptr<std::unordered_map<std::string, uint_least32_t>> spCrcs)
{
	assert(!m_wpCrcs.lock());
	assert(spCrcs);

	m_wpCrcs = std::move(spCrcs);
}
void FakeOel::KillAllTasks()
{
	CancelAllTaskThreads();
	WaitForAllTaskThreadsToExit();
	m_taskThreads.clear();
}
void FakeOel::oel_u_init(
	oel_rtos_init_object_t const*)
{
}
void FakeOel::oel_sys_init(
	void)
{
	auto const taskCount = m_rtosConfig.base.number_of_tasks;

	// Start the threads
	for (auto i = 0u; i < taskCount; ++i)
	{
		auto const& taskConfig = m_rtosConfig.posix.task_config[i];
		auto& taskContext = m_taskContexts[i];

		*(taskConfig.base.task_id) = &taskContext;
		taskContext.pConfig = &taskConfig;

		// Lock to ensure the vector is not changing while oel_rtos_task_get_context is using it
		std::lock_guard<std::mutex> lock{m_initializationMutex};
		m_taskThreads.emplace_back([&taskConfig] { taskConfig.posix.entry(); });
	}

	// Wait for them to be fully initialized
	std::unique_lock<std::mutex> lock{m_initializationMutex};
	auto const allTasksHaveBeenInitialized =  m_aTaskHasBeenInitialized.wait_for(
		lock,
		1s,
		[this, taskCount] { return m_taskInitializedCount == taskCount; });
	assert(allTasksHaveBeenInitialized);
	(void) allTasksHaveBeenInitialized;
}
void FakeOel::oel_rtos_startup_init(
	void)
{
	// This method is called from every task thread. It should only call startup_inits once.
	std::unique_lock<std::mutex> lock(m_mutex);

	if (!m_rtosInitialized)
	{
		assert(m_rtosConfig.base.startup_init);
		assert(m_rtosConfig.base.startup_init[0]);
		assert(m_rtosConfig.base.startup_init[0]->init);
		assert(m_rtosConfig.base.startup_init[1] == nullptr);

		// Only supports 1 init callback for now. Add a loop if more are used.
		m_rtosConfig.base.startup_init[0]->init(nullptr);
		m_rtosInitialized = true;
	}
}
oel_rtos_status_t FakeOel::oel_rtos_task_get_context(
	oel_rtos_task_context_t* context)
{
	assert(context);

	std::lock_guard<std::mutex> lock{m_initializationMutex};

	auto const thisThreadId = std::this_thread::get_id();
	auto const itBegin = m_taskThreads.begin();
	auto const itEnd = m_taskThreads.end();
	auto const itFound = std::find_if(itBegin, itEnd,
		[thisThreadId](std::thread& thread)
		{
			return thisThreadId == thread.get_id();
		});

	oel_rtos_status_t result = OEL_RTOS_STATUS_FAILED;
	if (itFound != itEnd)
	{
		auto const index = Utilities::narrow_cast<unsigned>(itFound - itBegin);
		*context = &m_taskContexts[index];
		result = OEL_RTOS_STATUS_OK;
	}

	return result;
}
oel_rtos_status_t FakeOel::oel_rtos_event_pend(
	oel_rtos_task_context_t context,
	oel_rtos_event_t pend_events,
	oel_rtos_event_t* received_events)
{
	{
		std::unique_lock<std::mutex> lock(m_mutex);
		context->runNow = false;

		if (!context->initialized) // This must come after resetting runNow to false
		{
			{
				std::unique_lock<std::mutex> initializationLock{m_initializationMutex};
				++m_taskInitializedCount;
			}

			context->initialized = true;
			m_aTaskHasBeenInitialized.notify_one();
		}

		m_aTaskShouldRun.wait(lock, [context]{ return context->runNow.load(); });
	}

	oel_rtos_event_t const processedEvents = (pend_events & context->pendingEvents);
	context->pendingEvents = Utilities::narrow_cast<oel_rtos_event_t>(context->pendingEvents & ~processedEvents);
	*received_events = processedEvents;

	return OEL_RTOS_STATUS_OK;
}
oel_rtos_status_t FakeOel::oel_rtos_event_post(
	oel_rtos_task_id_t task_id,
	oel_rtos_event_t events)
{
	task_id->pendingEvents |= events;
	auto& runNow = task_id->runNow;

	{
		std::unique_lock<std::mutex> lock(m_mutex);
		assert(!runNow);
		runNow = true;
	}

	m_aTaskShouldRun.notify_all(); // Notify all, but only one will actually run.

	// Wait for this task to finish, before kicking off the next. It *might* be more efficient
	// to use a condition variable (aquiring the mutex would take time), but this is much simpler.
	while (runNow)
	{
		std::this_thread::yield();
	}

	return OEL_RTOS_STATUS_OK;
}
uint_least32_t FakeOel::oel_u_crc_32(
		const uint_least8_t *buffer_ptr,
		size_t length,
		uint_least32_t initial_value)
{
	assert(initial_value == 0); (void)initial_value;
	assert(length > 0); (void)length;

	// I'd rather not return a "0" crc so that it's clear we're assigning an intentional value
	constexpr auto anyOffset = 42;
	uint_least32_t crc{anyOffset};

	auto spCrcs = m_wpCrcs.lock();
	if (spCrcs)
	{
		std::string str{reinterpret_cast<char const*>(buffer_ptr)};

		if (spCrcs->find(str) == spCrcs->end())
		{
			auto const newId = static_cast<unsigned>(spCrcs->size()) + anyOffset;
			(*spCrcs)[str] = newId;
		}

		if (n_dumpCrcInput)
		{
			std::cout << "CRC input: " << str << std::endl;
			std::cout << "CRC output: " << spCrcs->at(str) << std::endl << std::endl;
		}

		crc = spCrcs->at(str);
	}

	return crc;
}
oel_rtos_resource_t* FakeOel::oel_rtos_resource_pi_vnew()
{
	return nullptr;
}
void FakeOel::CancelAllTaskThreads()
{
	std::for_each(m_taskThreads.begin(), m_taskThreads.end(),
		[](auto&& taskThread)
		{
			auto const posixHandle = taskThread.native_handle();
			pthread_cancel(posixHandle); // All threads should be sleeping in a cancellable Posix syscall in oel_rtos_event_pend
		});
}
void FakeOel::WaitForAllTaskThreadsToExit()
{
	std::for_each(m_taskThreads.begin(), m_taskThreads.end(),  [](auto&& taskThread){ taskThread.join(); });
}
}
}
