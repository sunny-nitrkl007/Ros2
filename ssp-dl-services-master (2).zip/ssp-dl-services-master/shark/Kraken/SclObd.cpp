/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclObd.h

#include "SclObd.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<ISclObd> n_wpSclObd;
}

namespace Shark
{
namespace Kraken
{
void SetISclObd(std::shared_ptr<ISclObd> const& spSclObd)
{
	n_wpSclObd = spSclObd;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

scl_obd_es_t* scl_obd_es_init(
	const scl_obd_es_config_t* config_init,
	bool_t reset_persistent_data,
	scl_obd_es_error_t* error)
{
	auto const pDefaultResult = reinterpret_cast<scl_obd_es_t*>(42);
	*error = SCL_OBD_ES_SUCCESS;
	return CallKrakenMethod(n_wpSclObd, pDefaultResult, &ISclObd::scl_obd_es_init, config_init, reset_persistent_data, error);
}
scl_obd_handle_gen_t* scl_obd_handle_gen_init(void)
{
	auto const pDefaultResult = reinterpret_cast<scl_obd_handle_gen_t*>(42);
	return CallKrakenMethod(n_wpSclObd, pDefaultResult, &ISclObd::scl_obd_handle_gen_init);
}
scl_obd_test_handle_t scl_obd_handle_gen_get(scl_obd_handle_gen_t* this_)
{
	return CallKrakenMethod(n_wpSclObd, 42, &ISclObd::scl_obd_handle_gen_get, this_);
}
scl_obd_es_error_t scl_obd_es_register_test(
	scl_obd_es_t* this_,
	scl_obd_test_handle_t test_handle,
	const scl_obd_es_test_config_t* test_config)
{
	return CallKrakenMethod(n_wpSclObd, SCL_OBD_ES_SUCCESS, &ISclObd::scl_obd_es_register_test, this_, test_handle, test_config);
}
scl_obd_es_error_t scl_obd_es_update(scl_obd_es_t* this_)
{
	return CallKrakenMethod(n_wpSclObd, SCL_OBD_ES_SUCCESS, &ISclObd::scl_obd_es_update, this_);
}
scl_obd_es_error_t scl_obd_es_notify_test_results(
	scl_obd_es_t* this_,
	scl_obd_test_handle_t test_handle,
	scl_obd_es_test_results_t test_results)
{
	return CallKrakenMethod(
		n_wpSclObd, SCL_OBD_ES_SUCCESS, &ISclObd::scl_obd_es_notify_test_results, this_, test_handle, test_results);
}
scl_obd_es_error_t scl_obd_es_get_fault_rep(
	scl_obd_es_t* this_,
	scl_obd_test_handle_t test_handle,
	scl_obd_es_fault_rep_t* fault_report)
{
	return CallKrakenMethod(
		n_wpSclObd, SCL_OBD_ES_SUCCESS, &ISclObd::scl_obd_es_get_fault_rep, this_, test_handle, fault_report);
}
void scl_obd_es_keyswitch_status(
	scl_obd_es_t *this_,
	bool_least_t keyswitch_on)
{
	CallKrakenMethod(n_wpSclObd, &ISclObd::scl_obd_es_keyswitch_status, this_, keyswitch_on);
}
bool_least_t scl_obd_es_ok_to_shutdown(
	scl_obd_es_t *this_)
{
	return CallKrakenMethod(
		n_wpSclObd, TRUE, &ISclObd::scl_obd_es_ok_to_shutdown, this_);
}
scl_obd_es_error_t scl_obd_es_remove_unregistered_faults(
    scl_obd_es_t* this_,
    scl_obd_persistent_id_t* buffer,
    uint_least16_t buffer_size,
    uint_least16_t* number_of_entries)
{
	return CallKrakenMethod(
		n_wpSclObd, SCL_OBD_ES_SUCCESS, &ISclObd::scl_obd_es_remove_unregistered_faults, this_, buffer, buffer_size, number_of_entries);
}
