/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclJ1939Pgb.h

#include "SclJ1939Pgb.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<IJ1939Pgb> n_wpJ1939Pgb;
}

namespace Shark
{
namespace Kraken
{
void SetIJ1939Pgb(std::shared_ptr<IJ1939Pgb> const& spJ1939Pgb)
{
	n_wpJ1939Pgb = spJ1939Pgb;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

scl_pgb_j1939_t* scl_pgb_j1939_init(scl_j1939_link_t link)
{
	auto const pDefaultResult = reinterpret_cast<scl_pgb_j1939_t*>(42);
	return CallKrakenMethod(n_wpJ1939Pgb, pDefaultResult, &IJ1939Pgb::scl_pgb_j1939_init, link);
}
bool_t scl_pgb_j1939_add_ecm(scl_pgb_j1939_t *itself, const scl_pgb_j1939_ecm_config_t *ecm_config)
{
	return CallKrakenMethod(n_wpJ1939Pgb, TRUE, &IJ1939Pgb::scl_pgb_j1939_add_ecm, itself, ecm_config);
}
bool_t scl_pgb_j1939_add_rx_grps
(
	scl_pgb_j1939_t *itself,
	int_least8_t ecm_idx,
	uint_least8_t remote_addr,
	uint_least16_t num_rx_pids,
	const scl_pgb_j1939_rx_pid_cfg_ptr_t *rx_pid_table,
	scl_pgb_j1939_diag_contxt_tbl_t *diag_context_ptrs,
	uint_least16_t requested_periodic_rate,
	uint_least16_t requested_timeout,
	scl_pgb_j1939_event_clbk_t *event_clbk,
	void *event_context
)
{
	return CallKrakenMethod(n_wpJ1939Pgb, TRUE, &IJ1939Pgb::scl_pgb_j1939_add_rx_grps,
		itself,
		ecm_idx,
		remote_addr,
		num_rx_pids,
		rx_pid_table,
		diag_context_ptrs,
		requested_periodic_rate,
		requested_timeout,
		event_clbk,
		event_context);
}
