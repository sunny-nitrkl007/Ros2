/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclInfo.h

#include "SclInfo.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<ISclInfoDcm> n_wpSclInfoDcm;
}

namespace Shark
{
namespace Kraken
{
void SetISclInfoDcm(std::shared_ptr<ISclInfoDcm> const& spSclInfoDcm)
{
	n_wpSclInfoDcm = spSclInfoDcm;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

scl_dcm_error_state_t scl_dcm_init(
	const scl_dcm_config_t *config_data)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_init, config_data);
}
scl_dcm_error_state_t scl_dcm_add_j1939_link(
	scl_j1939_link_t link,
	uint_least8_t ecm_index,
	scl_dcm_link_id_t *link_index)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_add_j1939_link,
		link,
		ecm_index,
		link_index);
}
scl_dcm_error_state_t scl_dcm_register_peer(
	scl_dcm_link_id_t link_indx,
	const scl_dcm_peer_config_t *peer_cfg,
	scl_dcm_peer_id_t *peer_id)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_register_peer,
		link_indx,
		peer_cfg,
		peer_id);
}

scl_dcm_error_state_t scl_dcm_peer_get_num_codes(
	scl_dcm_peer_id_t peer_index,
	scl_dcm_tbl_code_type_t code_type,
	uint_least16_t *num_codes)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_peer_get_num_codes,
		peer_index,
		code_type,
		num_codes);
}
scl_dcm_error_state_t scl_dcm_read_diag_codes(
	scl_dcm_peer_id_t peer_id,
	scl_dcm_db_fault_s *buffer,
	uint_least16_t buffer_size,
	uint_least16_t *entries_filled)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_read_diag_codes,
		peer_id,
		buffer,
		buffer_size,
		entries_filled);
}
scl_dcm_error_state_t scl_dcm_read_event_codes(
	scl_dcm_peer_id_t peer_id,
	scl_dcm_db_fault_s *buffer,
	uint_least16_t buffer_size,
	uint_least16_t *entries_filled)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_read_event_codes,
		peer_id,
		buffer,
		buffer_size,
		entries_filled);
}
scl_dcm_error_state_t scl_dcm_read_spn_codes(
	scl_dcm_peer_id_t peer_id,
	scl_dcm_db_fault_s *buffer,
	uint_least16_t buffer_size,
	uint_least16_t *entries_filled)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_read_spn_codes,
		peer_id,
		buffer,
		buffer_size,
		entries_filled);
}
void scl_dcm_update()
{
	CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_update);
}
scl_dcm_error_state_t scl_dcm_peer_request_ai(
	scl_dcm_peer_id_t peer_index,
	scl_dcm_req_msg_types_t req_type,
	uint_least32_t code,
	uint_least8_t wci,
	uint_least8_t fmi)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_peer_request_ai,
		peer_index,
		req_type,
		code,
		wci,
		fmi);
}
scl_dcm_error_state_t scl_dcm_register_own_peer(
	scl_dcm_link_id_t link_indx,
	const scl_dcm_peer_config_t* peer_cfg,
	scl_dcm_event_sys_type_t event_sys_type,
	scl_obd_es_t* obd_es_obj,
	void* data_link_obj,
	scl_dcm_peer_id_t* peer_id)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_register_own_peer,
		link_indx,
		peer_cfg,
		event_sys_type,
		obd_es_obj,
		data_link_obj,
		peer_id);
}
scl_dcm_error_state_t scl_dcm_peer_get_support_ai_grps(
	scl_dcm_peer_id_t peer_index,
	uint_least8_t* ai_group_buff,
	uint_least8_t buffer_size,
	uint_least8_t* filled_size)
{
	*filled_size = 0; // Default to 0 entries
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_peer_get_support_ai_grps,
		peer_index,
		ai_group_buff,
		buffer_size,
		filled_size);
}

scl_dcm_error_state_t scl_dcm_get_link_index(
	scl_dcm_peer_id_t peer_index,
	scl_dcm_link_id_t* link_index)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_get_link_index, peer_index, link_index);
}

scl_dcm_error_state_t scl_dcm_get_peer_address(
	scl_dcm_peer_id_t peer_index,
	uint_least8_t* peer_address)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_get_peer_address, peer_index, peer_address);
}

scl_dcm_peer_id_t scl_dcm_get_peer_index(
	scl_dcm_link_id_t link_index,
	uint_least8_t peer_address)
{
	return CallKrakenMethod(n_wpSclInfoDcm, 0, &ISclInfoDcm::scl_dcm_get_peer_index, link_index, peer_address);
}

scl_dcm_error_state_t scl_dcm_peer_request_dm(
	scl_dcm_peer_id_t peer_index,
	scl_dcm_req_msg_types_t req_type)
{
	return CallKrakenMethod(n_wpSclInfoDcm, SCL_DCM_SUCCESS, &ISclInfoDcm::scl_dcm_peer_request_dm, peer_index, req_type);
}