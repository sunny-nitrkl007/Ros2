/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Nvm.h

#include "Nvm.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<INvm> n_wpNvm;
}

namespace Shark
{
namespace Kraken
{
void SetINvm(std::shared_ptr<INvm> const& spNvm)
{
	n_wpNvm = spNvm;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

unsigned_8 nvm_file_init(unsigned_16 const max_blocks)
{
	return CallKrakenMethod(n_wpNvm, NVM_SUCCESS, &INvm::nvm_file_init, max_blocks);
}
unsigned_8 nvm_file_block_cfg(nvm_file_block_cfg_t const* block_config)
{
	return CallKrakenMethod(n_wpNvm, NVM_SUCCESS, &INvm::nvm_file_block_cfg, block_config);
}
unsigned_8 nvm_block_init(
	unsigned_8 block_type,
	unsigned_8* block_cache_ptr,
	unsigned_32 data_id,
	int block_priority,
	NVM_block_handle_t* block_handle_ptr)
{
	return CallKrakenMethod(
		n_wpNvm, NVM_SUCCESS, &INvm::nvm_block_init, block_type, block_cache_ptr, data_id, block_priority, block_handle_ptr);
}
unsigned_8 nvm_block_read(
	NVM_block_handle_t block_handle,
	unsigned_32	read_size,
	unsigned_32	read_offset,
	unsigned_8* destination_ptr,
	int read_task_priority)
{
	return CallKrakenMethod(n_wpNvm, NVM_SUCCESS, &INvm::nvm_block_read, block_handle, read_size, read_offset, destination_ptr, read_task_priority);
}
unsigned_8 nvm_block_write(
	NVM_block_handle_t	block_handle,
	unsigned_32	write_size,
	unsigned_32	write_offset,
	unsigned_8* source_ptr,
	int write_task_priority)
{
	return CallKrakenMethod(n_wpNvm, NVM_SUCCESS, &INvm::nvm_block_write, block_handle, write_size, write_offset, source_ptr, write_task_priority);
}
unsigned_8 nvm_file_update()
{
	return CallKrakenMethod(n_wpNvm, NVM_SUCCESS, &INvm::nvm_file_update);
}
