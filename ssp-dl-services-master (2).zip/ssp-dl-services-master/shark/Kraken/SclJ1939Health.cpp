/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclJ1939Health.h

#include "SclJ1939Health.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<IJ1939Health> n_wpJ1939Health;
}

namespace Shark
{
namespace Kraken
{
void SetIJ1939Health(std::shared_ptr<IJ1939Health> const& spJ1939Health)
{
	n_wpJ1939Health = spJ1939Health;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

scl_health_j39_error_t scl_health_j39_init()
{
	return CallKrakenMethod(n_wpJ1939Health, SCL_HEALTH_J39_SUCCESS, &IJ1939Health::scl_health_j39_init);
}
scl_health_j39_error_t scl_health_j39_link_set_pgb_ptr(
	scl_health_j39_link_t* link_ptr,
	scl_pgb_j1939_t* pgb_ptr)
{
	return CallKrakenMethod(
		n_wpJ1939Health,
		SCL_HEALTH_J39_SUCCESS,
		&IJ1939Health::scl_health_j39_link_set_pgb_ptr,
		link_ptr,
		pgb_ptr);
}
scl_health_j39_error_t scl_health_j39_link_set_adt_handle(
	scl_health_j39_link_t* link_ptr,
	scl_adt_j1939_link_handle_t handle)
{
	return CallKrakenMethod(
		n_wpJ1939Health,
		SCL_HEALTH_J39_SUCCESS,
		&IJ1939Health::scl_health_j39_link_set_adt_handle,
		link_ptr,
		handle);
}
scl_health_j39_error_t scl_health_j39_link_set_fault_mgr(
	scl_health_j39_link_t* link_ptr,
	const scl_health_j39_fault_mgr_ifc_t* fault_mgr_ifc,
	void* fault_mgr_ptr,
	void* no_comm_fault_ptr,
	void* config_err_fault_ptr)
{
	return CallKrakenMethod(
		n_wpJ1939Health,
		SCL_HEALTH_J39_SUCCESS,
		&IJ1939Health::scl_health_j39_link_set_fault_mgr,
		link_ptr,
		fault_mgr_ifc,
		fault_mgr_ptr,
		no_comm_fault_ptr,
		config_err_fault_ptr);
}
scl_health_j39_link_t* scl_health_j39_add_link(
	scl_j1939_link_t j1939_link,
	const scl_health_j39_link_config_t* link_config,
	bool_t start,
	scl_health_j39_error_t *error_code)
{
	*error_code = SCL_HEALTH_J39_SUCCESS;
	return CallKrakenMethod(
		n_wpJ1939Health,
		reinterpret_cast<scl_health_j39_link_t*>(0x42),
		&IJ1939Health::scl_health_j39_add_link,
		j1939_link,
		link_config,
		start,
		error_code);
}
scl_health_j39_ecm_t* scl_health_j39_link_add_ecm(
	scl_health_j39_link_t* link_ptr,
	uint_least8_t ecm_idx,
	const scl_health_j39_ecm_config_t* ecm_config,
	bool_t start,
	scl_health_j39_error_t* error_code)
{
	*error_code = SCL_HEALTH_J39_SUCCESS;
	return CallKrakenMethod(
		n_wpJ1939Health,
		reinterpret_cast<scl_health_j39_ecm_t*>(0x42),
		&IJ1939Health::scl_health_j39_link_add_ecm,
		link_ptr,
		ecm_idx,
		ecm_config,
		start,
		error_code);
}
scl_health_j39_peer_t* scl_health_j39_ecm_add_peer(
	scl_health_j39_ecm_t* ecm_ptr,
	const scl_health_j39_peer_config_t* peer_config,
	bool_least_t start,
	scl_health_j39_error_t* error_code)
{
	*error_code = SCL_HEALTH_J39_SUCCESS;
	return CallKrakenMethod(
		n_wpJ1939Health,
		reinterpret_cast<scl_health_j39_peer_t*>(0x42),
		&IJ1939Health::scl_health_j39_ecm_add_peer,
		ecm_ptr,
		peer_config,
		start,
		error_code);
}
scl_health_j39_grp_t* scl_health_j39_peer_add_rx_grps(
	scl_health_j39_peer_t* peer_ptr,
	uint_least16_t num_rx_pids,
	const scl_pgb_j1939_rx_pid_cfg_ptr_t* rx_pid_table,
	uint_least16_t requested_periodic_rate,
	uint_least16_t requested_timeout,
	uint_least16_t pgb_comm_delay,
	bool_t start_mon,
	bool_t begin_comm,
	scl_health_j39_error_t* error_code)
{
	*error_code = SCL_HEALTH_J39_SUCCESS;
	return CallKrakenMethod(
		n_wpJ1939Health,
		reinterpret_cast<scl_health_j39_grp_t*>(0x42),
		&IJ1939Health::scl_health_j39_peer_add_rx_grps,
		peer_ptr,
		num_rx_pids,
		rx_pid_table,
		requested_periodic_rate,
		requested_timeout,
		pgb_comm_delay,
		start_mon,
		begin_comm,
		error_code);
}
scl_health_j39_pgn_t* scl_health_j39_peer_add_rx_pgn(
	scl_health_j39_peer_t* peer_ptr,
	uint_least8_t msg_idx,
	uint_least16_t timeout,
	scl_health_j39_mon_type_t mon_type,
	const scl_health_j39_cum_config_t* cum_config,
	uint_least16_t num_ids,
	const scl_health_j39_id_and_type_t* id_list,
	bool_t start,
	scl_health_j39_error_t* error_code)
{
	*error_code = SCL_HEALTH_J39_SUCCESS;
	return CallKrakenMethod(
		n_wpJ1939Health,
		reinterpret_cast<scl_health_j39_pgn_t*>(0x42),
		&IJ1939Health::scl_health_j39_peer_add_rx_pgn,
		peer_ptr,
		msg_idx,
		timeout,
		mon_type,
		cum_config,
		num_ids,
		id_list,
		start,
		error_code);
}
scl_health_j39_adt_grp_t* scl_health_j39_peer_add_adt_rx_grps(
	scl_health_j39_peer_t* peer_ptr,
	uint_least8_t num_rx_pids,
	const scl_adt_j1939_client_grp_pid_config_ptr_t* client_grp_pid_configs,
	bool_least_t dm13_support,
	uint_least16_t adt_comm_delay,
	bool_t start_mon,
	bool_t begin_comm,
	scl_health_j39_error_t* error_code)
{
	*error_code = SCL_HEALTH_J39_SUCCESS;
	return CallKrakenMethod(
		n_wpJ1939Health,
		reinterpret_cast<scl_health_j39_adt_grp_t*>(0x42),
		&IJ1939Health::scl_health_j39_peer_add_adt_rx_grps,
		peer_ptr,
		num_rx_pids,
		client_grp_pid_configs,
		dm13_support,
		adt_comm_delay,
		start_mon,
		begin_comm,
		error_code);
}
scl_health_j39_error_t scl_health_j39_peer_get_qs(
	scl_health_j39_peer_t* peer_ptr,
	scl_health_j39_qs_t* qualified_status)
{
	return CallKrakenMethod(
		n_wpJ1939Health,
		SCL_HEALTH_J39_SUCCESS,
		&IJ1939Health::scl_health_j39_peer_get_qs,
		peer_ptr,
		qualified_status);
}
scl_health_j39_error_t scl_health_j39_link_start(scl_health_j39_link_t *link_ptr)
{
	return CallKrakenMethod(n_wpJ1939Health, SCL_HEALTH_J39_SUCCESS, &IJ1939Health::scl_health_j39_link_start, link_ptr);
}
scl_health_j39_error_t scl_health_j39_link_pause(scl_health_j39_link_t *link)
{
	return CallKrakenMethod(n_wpJ1939Health, SCL_HEALTH_J39_SUCCESS, &IJ1939Health::scl_health_j39_link_pause, link);
}
scl_health_j39_error_t scl_health_j39_peer_start(scl_health_j39_peer_t *peer_ptr)
{
	return CallKrakenMethod(n_wpJ1939Health, SCL_HEALTH_J39_SUCCESS, &IJ1939Health::scl_health_j39_peer_start, peer_ptr);
}
scl_health_j39_error_t scl_health_j39_peer_pause(scl_health_j39_peer_t *peer_ptr)
{
	return CallKrakenMethod(n_wpJ1939Health, SCL_HEALTH_J39_SUCCESS, &IJ1939Health::scl_health_j39_peer_pause, peer_ptr);
}
boolean_t scl_health_j39_peer_set_eval_delay(scl_health_j39_peer_t *peer_ptr, uint_least32_t eval_delay)
{
	return CallKrakenMethod(n_wpJ1939Health, true, &IJ1939Health::scl_health_j39_peer_set_eval_delay,
		peer_ptr,
		eval_delay);
}
void scl_health_j39_adt_grp_set_timeout(scl_health_j39_adt_grp_t *grp, uint_least32_t timeout)
{
	return CallKrakenMethod(n_wpJ1939Health, &IJ1939Health::scl_health_j39_adt_grp_set_timeout,
		grp,
		timeout);
}

