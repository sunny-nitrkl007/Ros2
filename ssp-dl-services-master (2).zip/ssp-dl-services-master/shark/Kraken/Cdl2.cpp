/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Cdl2.h

#include "Cdl2.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<ICdl2> n_wpCdl2;
}

namespace Shark
{
namespace Kraken
{
void SetICdl2(std::shared_ptr<ICdl2> const& spCdl2)
{
	n_wpCdl2 = spCdl2;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

void cdl2_ginit()
{
	CallKrakenMethod(n_wpCdl2, &ICdl2::cdl2_ginit);
}
int_32 cdl2_transmit_ginit()
{
	return CallKrakenMethod(n_wpCdl2, CDL2_TRANSMIT_STATUS_OKAY, &ICdl2::cdl2_transmit_ginit);
}
void cdl_rcv_did_set(boolean_t val, unsigned_8 lo_did, unsigned_8 hi_did)
{
	CallKrakenMethod(n_wpCdl2, &ICdl2::cdl_rcv_did_set, val, lo_did, hi_did);
}
void cdl_default_mid_set(unsigned_8 mid)
{
	CallKrakenMethod(n_wpCdl2, &ICdl2::cdl_default_mid_set, mid);
}
int_32 cdl2_cbs_ginit(
	unsigned_8 harness_code,
	cdl2_cbs_system_cfg_t* system_table_ptr,
	cdl2_cbs_ecm_cfg_t* ecm_table_ptr,
	cdl2_cbs_parm_cfg_t* parm_tbl_ptr,
	cdl2_cbs_input_tbl_t* input_tbl_ptr,
	cdl2_cbs_get_func_ptr_t get_fnc_ptr,
	cdl2_cbs_get_data_ptr_t get_data_ptr)
{
	return CallKrakenMethod(
		n_wpCdl2,
		CBS_STATUS_OKAY,
		&ICdl2::cdl2_cbs_ginit,
		harness_code,
		system_table_ptr,
		ecm_table_ptr,
		parm_tbl_ptr,
		input_tbl_ptr,
		get_fnc_ptr,
		get_data_ptr);
}
void cdl2_receive_main()
{
	CallKrakenMethod(n_wpCdl2, &ICdl2::cdl2_receive_main);
}
int_16 cdl2_add_to_con_rx_pit(unsigned_32 new_data_ID, cdl2_con_rx_hdlr_t *new_hdlr, void const *new_pie)
{
	return CallKrakenMethod(n_wpCdl2, CDL2_SUCCESSFUL, &ICdl2::cdl2_add_to_con_rx_pit, new_data_ID, new_hdlr, new_pie);
}
int_16 cdl2_add_to_tx_pit(unsigned_32 new_data_ID, cdl2_tx_hdlr_t *new_hdlr, void const *new_pie)
{
	return CallKrakenMethod(n_wpCdl2, CDL2_SUCCESSFUL, &ICdl2::cdl2_add_to_tx_pit, new_data_ID, new_hdlr, new_pie);
}
int_16 cdl2_add_to_wr_pit(unsigned_32 new_data_ID, Cdl_wr_hdlr_t *new_hdlr, void const *new_pie)
{
	return CallKrakenMethod(n_wpCdl2, CDL2_SUCCESSFUL, &ICdl2::cdl2_add_to_wr_pit, new_data_ID, new_hdlr, new_pie);
}
