/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Security.h

#include "Security.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<ISclFps> n_wpSclFps;
std::weak_ptr<ISclFpsJ1939> n_wpSclFpsJ1939;
std::weak_ptr<ISclSecurity> n_wpSclSecurity;
}

namespace Shark
{
namespace Kraken
{
void SetISclFps(std::shared_ptr<ISclFps> const& spSclFps)
{
	n_wpSclFps = spSclFps;
}
void SetISclFpsJ1939(std::shared_ptr<ISclFpsJ1939> const& spSclFpsJ1939)
{
	n_wpSclFpsJ1939 = spSclFpsJ1939;
}
void SetISclSecurity(std::shared_ptr<ISclSecurity> const& spSclSecurity)
{
	n_wpSclSecurity = spSclSecurity;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

bool_t scl_fps_init(const scl_fps_cfg_t* fps_cfg)
{
	return CallKrakenMethod(n_wpSclFps, TRUE, &ISclFps::scl_fps_init, fps_cfg);
}
scl_fps_key_result_t scl_fps_install_crypto_key(void* key_context)
{
	return CallKrakenMethod(n_wpSclFps, SCL_FPS_KEY_RESULT_OK, &ISclFps::scl_fps_install_crypto_key, key_context);
}
void scl_fps_background()
{
	CallKrakenMethod(n_wpSclFps, &ISclFps::scl_fps_background);
}

scl_fps_j1939_link_t* scl_fps_j1939_link_init(
	scl_j1939_link_t link,
	scl_fps_j1939_link_config_t* link_config)
{
	return CallKrakenMethod(n_wpSclFpsJ1939, reinterpret_cast<scl_fps_j1939_link_t*>(0x42424242), &ISclFpsJ1939::scl_fps_j1939_link_init, link, link_config);
}
bool_t scl_fps_j1939_link_add_ecm(
	scl_fps_j1939_link_t *itself,
	int_least8_t ecm_idx,
	const scl_fps_j1939_ecm_config_t *j1939_ecm_config)
{
	return CallKrakenMethod(n_wpSclFpsJ1939, TRUE, &ISclFpsJ1939::scl_fps_j1939_link_add_ecm, itself, ecm_idx, j1939_ecm_config);
}

scl_security_ret_val_t scl_security_install_fps()
{
	return CallKrakenMethod(n_wpSclSecurity, SCL_SECURITY_RET_VAL_SUCCESS, &ISclSecurity::scl_security_install_fps);
}

scl_security_ret_val_t scl_security_install_passwd()
{
	return CallKrakenMethod(n_wpSclSecurity, SCL_SECURITY_RET_VAL_SUCCESS, &ISclSecurity::scl_security_install_passwd);
}
void passwd_pkg_init(PASSWD_Pkg_Work_t *work, PASSWD_Pkg_Config_t *config)
{
	CallKrakenMethod(n_wpSclSecurity, &ISclSecurity::passwd_pkg_init, work, config);
}
void passwd_pkg_main(PASSWD_Pkg_Work_t *work, PASSWD_Pkg_Config_t *config)
{
	CallKrakenMethod(n_wpSclSecurity, &ISclSecurity::passwd_pkg_main, work, config);
}
unsigned_8 passwd_get_seclvl()
{
	return CallKrakenMethod(n_wpSclSecurity, 0, &ISclSecurity::passwd_get_seclvl);
}

// Required externals
const void* scl_fps_key_am1_key001{};
