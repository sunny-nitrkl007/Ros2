/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclJ1939Rw.h

#include "SclJ1939Rw.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<IJ1939Rw> n_wpJ1939Rw;
}

namespace Shark
{
namespace Kraken
{
void SetIJ1939Rw(std::shared_ptr<IJ1939Rw> const& spJ1939Rw)
{
	n_wpJ1939Rw = spJ1939Rw;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

bool_t scl_rw_j1939_client_init(scl_j1939_link_t link)
{
	return CallKrakenMethod(n_wpJ1939Rw, TRUE, &IJ1939Rw::scl_rw_j1939_client_init, link);
}
bool_t scl_rw_j1939_server_init(scl_j1939_link_t link)
{
	return CallKrakenMethod(n_wpJ1939Rw, TRUE, &IJ1939Rw::scl_rw_j1939_server_init, link);
}
