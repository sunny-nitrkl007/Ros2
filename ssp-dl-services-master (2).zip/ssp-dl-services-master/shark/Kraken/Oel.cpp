/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Oel.h

#include "Oel.h"
#include <Utilities/Kraken/CallKrakenMethod.h>
#include <ct_common.h>
#include <oel_u_crc.h>

using Shark::Kraken::IOel;

namespace
{
std::weak_ptr<IOel> n_wpOel{};
}

namespace Shark
{
namespace Kraken
{
void SetIOel(std::shared_ptr<IOel> const& spOel)
{
	n_wpOel = spOel;
}
oel_rtos_posix_config_t const& GetOelConfig()
{
	return app_oel_rtos_posix_config;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

void oel_u_init(
  oel_rtos_init_object_t const* never_used)
{
	CallKrakenMethod(n_wpOel, &IOel::oel_u_init, never_used);
}
void oel_sys_init(
   void)
{
	CallKrakenMethod(n_wpOel, &IOel::oel_sys_init);
}
void oel_rtos_startup_init(
   void)
{
	CallKrakenMethod(n_wpOel, &IOel::oel_rtos_startup_init);
}
oel_rtos_status_t oel_rtos_task_get_context(
   oel_rtos_task_context_t* context)
{
	return CallKrakenMethod(n_wpOel, OEL_RTOS_STATUS_OK, &IOel::oel_rtos_task_get_context, context);
}
oel_rtos_status_t oel_rtos_event_pend(
   oel_rtos_task_context_t context,
   oel_rtos_event_t pend_events,
   oel_rtos_event_t* received_events)
{
	return CallKrakenMethod(n_wpOel, OEL_RTOS_STATUS_OK, &IOel::oel_rtos_event_pend, context, pend_events, received_events);
}
oel_rtos_status_t oel_rtos_event_post(
   oel_rtos_task_id_t task_id,
   oel_rtos_event_t events)
{
	return CallKrakenMethod(n_wpOel, OEL_RTOS_STATUS_OK, &IOel::oel_rtos_event_post, task_id, events);
}
oel_rtos_resource_t* oel_rtos_resource_pi_vnew(void)
{
	return CallKrakenMethod(n_wpOel, nullptr, &IOel::oel_rtos_resource_pi_vnew);
}
uint_least32_t oel_u_crc_32(
	const uint_least8_t *buffer_ptr,
	size_t length,
	uint_least32_t initial_value)
{
	return CallKrakenMethod(n_wpOel, 0, &IOel::oel_u_crc_32, buffer_ptr, length, initial_value);
}

std::string ct_common::get_verity_name(const std::string& default_name)
{
	return default_name;
}