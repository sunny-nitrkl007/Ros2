/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclJ1939Pgb.h

#include "SclJ1939QualifiedRead.h"
#include <Utilities/Kraken/CallKrakenMethod.h>

using namespace Shark::Kraken;

namespace
{
std::weak_ptr<IJ1939QualifiedRead> n_wpJ1939QualifiedRead;
}

namespace Shark
{
namespace Kraken
{
void SetIJ1939QualifiedRead(std::shared_ptr<IJ1939QualifiedRead> const& spJ1939QualifiedRead)
{
	n_wpJ1939QualifiedRead = spJ1939QualifiedRead;
}
}
}

using Utilities::Kraken::CallKrakenMethod;

scl_qr_j1939_t* scl_qr_j1939_init(
	scl_j1939_link_t link,
	const scl_qr_j1939_config_t *config)
{
	auto const pDefaultResult = reinterpret_cast<scl_qr_j1939_t*>(0x42424242);
	return CallKrakenMethod(
		n_wpJ1939QualifiedRead, pDefaultResult, &IJ1939QualifiedRead::scl_qr_j1939_init, link, config);
}
scl_qr_j1939_client_t* scl_qr_j1939_add_client(
	scl_qr_j1939_t *itself,
	int_least8_t ecm_idx,
	uint_least8_t max_remote_nodes)
{
	auto const pDefaultResult = reinterpret_cast<scl_qr_j1939_client_t*>(0x42424242);
	return CallKrakenMethod(
		n_wpJ1939QualifiedRead, pDefaultResult, &IJ1939QualifiedRead::scl_qr_j1939_add_client, itself, ecm_idx, max_remote_nodes);
}
bool_t scl_qr_j1939_tx_request(
	scl_qr_j1939_t *itself,
	int_least8_t ecm_idx,
	uint_least8_t remote_addr,
	uint_least32_t pid,
	scl_qr_j1939_pid_type_t pid_type,
	scl_qr_j1939_qualifier_type_t qualifier_type,
	scl_qr_j1939_datalink_endian_t datalink_endian,
	uint_least8_t data_length,
	scl_qr_j1939_data_sign_t data_sign,
	scl_qr_j1939_rqst_clbk_t *rqst_clbk,
	void *rqst_clbk_context)
{
	return CallKrakenMethod(n_wpJ1939QualifiedRead, TRUE, &IJ1939QualifiedRead::scl_qr_j1939_tx_request,
		itself,
		ecm_idx,
		remote_addr,
		pid,
		pid_type,
		qualifier_type,
		datalink_endian,
		data_length,
		data_sign,
		rqst_clbk,
		rqst_clbk_context);
}
