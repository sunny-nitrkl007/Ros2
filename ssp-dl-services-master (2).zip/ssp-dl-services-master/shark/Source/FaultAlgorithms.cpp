/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See FaultAlgorithms.h

#include "FaultAlgorithms.h"
#include <cassert>
#include <climits>

namespace Shark
{
bool NullFaultAlgorithm::IsValid(uint32_t)
{
	return true;
}

namespace
{
constexpr uint32_t n_minimumValueHighByte{ 0xFB };

uint32_t CreateErrorRange(unsigned bitCount)
{
	assert(bitCount > 1);
	assert(bitCount <= 32);
	uint32_t minimumErrorValue{};

	if (bitCount % CHAR_BIT == 0)
	{
		// Errors for byte values (1-4) are denoted by values greater than the following values
		// 1 - 0xFA, 2 - 0xFAFF, 3 - 0xFAFFFF, 4 - 0xFAFFFFFF
		minimumErrorValue = n_minimumValueHighByte << (bitCount - 8);
	}
	else
	{
		// Errors for bit value (2-7) are denoted by the highest value the bitfield can represent
		// Ex 3 bits - 111
		minimumErrorValue = (1u << bitCount) - 1;
	}
	return minimumErrorValue;
}
}
SpnFaultAlgorithm::SpnFaultAlgorithm(unsigned bitCount) noexcept
	: m_minimumErrorValue(CreateErrorRange(bitCount))
{
}
bool SpnFaultAlgorithm::IsValid(uint32_t byteValue)
{
	return (byteValue < m_minimumErrorValue);
}
}