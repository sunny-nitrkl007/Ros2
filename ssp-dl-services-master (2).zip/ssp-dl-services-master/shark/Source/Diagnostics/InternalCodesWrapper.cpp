/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See InternalCodesWrapper.h

#include "InternalCodesWrapper.h"
#include "DependencyContainer.h"
#include "IInternalCodesWrapper.h"
#include "J1939/IJ1939Wrapper.h"
#include "J1939/J1939Definitions.h"
#include "Log.h"
#include "Nvm/INvmBlockDefinitions.h"
#include "SharkBytes/ISharkByteManager.h"
#include "SharkBytes/IWriteSharkByteManager.h"
#include <Config/ProtobufConversions.h>
#include <Utilities/SharkBytes/SimpleSharkByte.h>
#include <Utilities/SharkBytes/WriteSharkByteReferenceWrapper.h>
#include <Utilities/Clock.h>
#include <Utilities/Conversions.h>
#include <Utilities/CountOf.h>
#include <Utilities/narrow_cast.h>
#include <Utilities/ToUnderlying.h>
#include <Utilities/ThisThread.h>
#include <passwd_proto.h>

using namespace std::literals::chrono_literals;
using Utilities::ToUnderlying;

namespace Shark
{
namespace Diagnostics
{
namespace
{
constexpr char const* n_sclObdErrorToString[]
{
	"SUCCESS",
	"BUFFER_TOO_SMALL",
	"DUP_TEST_REGISTERED",
	"EVT_QUEUE_OVERFLOW",
	"MALLOC_FAILED",
	"NOT_INITIALIZED",
	"NO_ANNUNC_ENTRY",
	"NO_REGISTRY_ENTRY",
	"NO_SUBSC_ENTRY",
	"PERSISTENT_MEM_TOO_SMALL",
	"SECURITY_LEVEL_TOO_LOW",
	"TOO_MANY_READINESS_GRPS",
	"UNKNOWN_READINESS_GRP",
	"UNKNOWN_TEST_HANDLE",
	"NO_OCCUR_INFO",
	"CLEAR_REQ_NOT_AUTHORIZED",
	"HOLD_OFF_TIMER_NOT_EXPIRED",
	"2CPY_NOT_SUPPORTED",
	"MULTIPLE_INIT",
	"NULL_PTR_ERROR",
	"INVALID_API_CALL",
	"MC_CALL_FROM_INVALID_CORE",
	"MC_MEMORY_ALLOCATION_FAILED",
	"MC_INVALID_NUMBER_OF_CFG_CORES",
	"MC_CORE_NOT_INITIALIZED",
	"MC_INVALID_CFG",
	"MC_INIT_API_INVALID_CALL",
};
static_assert(Utilities::CountOf(n_sclObdErrorToString) == SCL_OBD_ES_MC_INIT_API_INVALID_CALL + 1, "Size mismatch");

std::string ConvertObdErrorToString(scl_obd_es_error_t const& error)
{
	std::string result{"UNKNOWN"};
	if (error < Utilities::CountOf(n_sclObdErrorToString))
	{
		result = n_sclObdErrorToString[error];
	}
	else
	{
		assert(false);
	}
	return result;
}

constexpr uint_least16_t n_maxNumberOfCodes{100};
// Need large buffer to have enough room for mass updates when object detect codes are configured, this used to be half the size of maxNumberOfCodes
constexpr uint_least16_t n_maxCodeQueueSize{n_maxNumberOfCodes * 2};

scl_obd_es_config_t CreateObdEsConfig(NVM_block_handle_t* pNvmBlockHandle)
{
	return {
		n_maxNumberOfCodes,
		n_maxCodeQueueSize,
		n_maxCodeQueueSize,
		n_maxNumberOfCodes,
		1,
		5,
		5,
		5,
		n_maxNumberOfCodes,
		n_maxNumberOfCodes,
		{
			pNvmBlockHandle,
			nullptr,
			0,
		},
		SCL_OBD_ES_FEAT_USE_RTC | SCL_OBD_ES_FEAT_NO_TEMP_COPY,
		SCL_OBD_ES_MIN_ACTIVE_DRV_CYCLES,
		SCL_OBD_ES_MIN_ACTIVE_SHM_TIME,
		SCL_OBD_ES_AUTO_CLEAR_WARMUP_CYCLES,
		SCL_OBD_ES_MIN_ACTIVE_SHM_TIME,
		0xFF,
		TRUE,
		0,
		0,
		0};
}
scl_diag_pj1939_config_t CreateEddtConfig()
{
	return {
		n_maxNumberOfCodes,
		n_maxNumberOfCodes,
		6,
		5,
		passwd_get_seclvl,
		TRUE};
}
scl_obd_es_test_config_t CreateObdTestConfig(InternalCodeConfig const& internalCode)
{
	auto const wci = internalCode.warning_category_indicator();
	auto const code = internalCode.code();
	scl_obd_es_fault_class_t codeType{};
	unsigned persistentId{};
	if (internalCode.code_type() == cat::shark::Diagnostics_InternalCodeList_CodeType_CODE_TYPE_DIAGNOSTIC)
	{
		codeType = SCL_OBD_ES_CLASS_DIAG;
		persistentId = SCL_OBD_PERSISTENT_ID_CDL_DIAG_WCI(code, internalCode.failure_mode_identifier(), wci);
	}
	else if (internalCode.code_type() == cat::shark::Diagnostics_InternalCodeList_CodeType_CODE_TYPE_EVENT)
	{
		codeType = SCL_OBD_ES_CLASS_EVENT;
		persistentId = SCL_OBD_PERSISTENT_ID_CDL_EVENT(code, wci);
	}
	else
	{
		assert("Unknown code type for internal diagnostic!" == nullptr);
	}

	unsigned testConfigFlags = SCL_OBD_ES_TST_CFG_CONT_MON;
	if (internalCode.storage_type() == cat::shark::Diagnostics_InternalCodeList_StorageType_STORAGE_TYPE_LOGGED_AND_ACTIVE)
	{
		testConfigFlags |= SCL_OBD_ES_TST_CFG_PERSISTENT | SCL_OBD_ES_TST_CFG_STORE_CONFIRM | SCL_OBD_ES_TST_CFG_PERSISTENT_ACTIVE;
	}
	return {
		codeType,
		SCL_OBD_ES_GRP_NONE,
		persistentId,
		SCL_OBD_ES_PERSIST_PRIORITY_MAX,
		Utilities::narrow_cast<uint_least8_t>(internalCode.security_level()),
		testConfigFlags,
		0,
		0,
		0,
		0,
		SCL_OBD_ES_FF_PRIORITY_NORMAL,
		Utilities::narrow_cast<uint_least8_t>(internalCode.annunciation_requirement()),
		nullptr};
}
scl_eddt_fault_config_t CreateEddtFaultConfig(InternalCodeConfig const& internalCode)
{
	return {
		internalCode.description().c_str(),
		SCL_EDDT_EVENT_TYPE_MAINT_AND_OP,
		FALSE,
		Utilities::narrow_cast<uint_least16_t>(internalCode.code()),
		Utilities::narrow_cast<scl_eddt_wci_t>(internalCode.warning_category_indicator()),
		Utilities::narrow_cast<uint_least8_t>(internalCode.failure_mode_identifier()),
		0,
		FALSE};
}
std::unique_ptr<InternalCode> CreateInternalCode(
	IInternalCodesWrapper& internalCodesWrapper,
	InternalCodeConfig const& internalCode,
	SharkUtilities::IEventCallbackFactory& eventCallbackFactory)
{
	auto spInternalCode =  std::make_unique<InternalCode>(
		internalCodesWrapper,
		eventCallbackFactory);

	std::vector<std::unique_ptr<IInternalCodeState>> states{};
	states.reserve(ToUnderlying(InternalCodeStateId::Count));
	states.emplace_back(std::make_unique<InitializedState>(
		*spInternalCode,
		std::chrono::seconds(internalCode.start_up_delay())));
	states.emplace_back(std::make_unique<ReadyState>(*spInternalCode));
	states.emplace_back(std::make_unique<UnknownState>(*spInternalCode));
	states.emplace_back(std::make_unique<ActiveState>(
		*spInternalCode,
		std::chrono::seconds(internalCode.activation_delay())));
	states.emplace_back(std::make_unique<InactiveState>(
		*spInternalCode,
		std::chrono::seconds(internalCode.deactivation_delay())));
	states.emplace_back(std::make_unique<ActiveConfirmedState>(*spInternalCode));
	states.emplace_back(std::make_unique<InactiveConfirmedState>(*spInternalCode));
	spInternalCode->SetStates(std::move(states));

	return spInternalCode;
}
InternalCodesConfigData CreateInternalCodesConfig(
	ISharkByteRetriever const& sharkByteRetriever,
	std::vector<InternalCodeConfig> const& internalCodes,
	NVM_block_handle_t* pNvmBlockHandle)
{
	std::vector<InternalCodeData> internalCodeData{};
	internalCodeData.reserve(internalCodes.size());
	for (auto const& internalCode : internalCodes)
	{
		auto& testSharkByte = sharkByteRetriever.Retrieve(internalCode.middleware_id().c_str());
		internalCodeData.push_back(
			{
				CreateObdTestConfig(internalCode),
				CreateEddtFaultConfig(internalCode),
				testSharkByte,
			});
	}

	return
		{
			CreateObdEsConfig(pNvmBlockHandle),
			CreateEddtConfig(),
			internalCodeData
		};
}
void CreateStatusControlSharkByte(
	SharkBytes::ISharkByteManager& sharkByteManager,
	SharkBytes::IWriteSharkByteManager& writeSharkByteManager,
	char const* pStatusSharkByteId)
{
	auto spStatusSharkByte = std::make_unique<Utilities::SimpleSharkByte>(pStatusSharkByteId);
	auto spWriteStatusSharkByte = std::make_unique<Utilities::WriteSharkByteReferenceWrapper>(*spStatusSharkByte);
	sharkByteManager.AddSharkByte(std::move(spStatusSharkByte));
	writeSharkByteManager.AddWriteSharkByte(std::move(spWriteStatusSharkByte));
}
void PopulateConfiguredCodes(
	SharkBytes::ISharkByteManager& sharkByteManager,
	SharkBytes::IWriteSharkByteManager& writeSharkByteManager,
	cat::shark::Diagnostics const& diagnostics,
	std::vector<InternalCodeConfig>& internalCodes)
{
	for (auto const& internalCode : diagnostics.internal_code_list().internal_codes())
	{
		CreateStatusControlSharkByte(
			sharkByteManager,
			writeSharkByteManager,
			internalCode.middleware_id().c_str());
		internalCodes.push_back(internalCode);
	}
}
void ThrowErrorIfFail(scl_obd_es_error_t result, char const* pMessage)
{
	if (result != SCL_OBD_ES_SUCCESS)
	{
		if (result == SCL_OBD_ES_NO_REGISTRY_ENTRY)
		{
			throw IInternalCodesWrapper::Error(std::string{pMessage} + ": Need to increase maximum number of codes!");
		}
		else
		{
			throw IInternalCodesWrapper::Error(std::string{pMessage} + ": " + ConvertObdErrorToString(result));
		}
	}
}
void ThrowErrorIfFail(scl_diag_pj1939_error_t result, char const* pMessage)
{
	if (result != SCL_DIAG_PJ1939_SUCCESSFUL)
	{
		throw IInternalCodesWrapper::Error(std::string{pMessage} + ": " + To<std::string>(result));
	}
}
constexpr auto n_internalCodesFileName = "InternalCodes";
constexpr auto n_internalCodesFileSize = SCL_OBD_ES_PERSISTENT_RTC_SIZE(n_maxNumberOfCodes, n_maxNumberOfCodes);
constexpr auto n_taskPeriod = TaskPeriod::Is100ms;
}

InternalCodesConfiguration::InternalCodesConfiguration(
	ISharkByteRetriever const& sharkByteRetriever,
	std::vector<InternalCodeConfig> const& internalCodes,
	NVM_block_handle_t* pNvmBlockHandle)
	: m_internalCodesConfigData(
		CreateInternalCodesConfig(sharkByteRetriever, internalCodes, pNvmBlockHandle))
{
}

std::shared_ptr<InternalCodesWrapper> InternalCodesWrapper::Create(DependencyContainer const& dependencyContainer)
{
	auto internalCodesNvmDataId = dependencyContainer.GetNvmBlockDefinitions().Add(n_internalCodesFileName, n_internalCodesFileSize);
	auto const& diagnostics = dependencyContainer.GetSharkConfig().diagnostics();
	auto spInternalCodesWrapper = std::make_shared<InternalCodesWrapper>(
		dependencyContainer.GetIJ1939Wrapper(::Config::ToConfigCanPort(diagnostics.internal_code_list().service_can_port())),
		internalCodesNvmDataId);
	AddPeriodicTask(
		dependencyContainer.GetIPeriodicTaskManager(),
		*spInternalCodesWrapper);

	std::vector<InternalCodeConfig> internalCodeEntries{};
	PopulateConfiguredCodes(
		dependencyContainer.GetISharkByteManager(),
		dependencyContainer.GetIWriteSharkByteManager(),
		diagnostics,
		internalCodeEntries);

	std::vector<std::unique_ptr<IInternalCode>> internalCodes;
	internalCodes.reserve(static_cast<unsigned>(internalCodeEntries.size()));
	LOG_INFO_LOW_TAG(Log::Init, "internal code count = " << static_cast<unsigned>(internalCodeEntries.size()));
	for (auto const& internalCode : internalCodeEntries)
	{
		internalCodes.emplace_back(
			CreateInternalCode(*spInternalCodesWrapper, internalCode, dependencyContainer.GetIEventCallbackFactory()));
	}
	spInternalCodesWrapper->SetDependencies(std::move(internalCodeEntries), std::move(internalCodes));

	return spInternalCodesWrapper;
}
void InternalCodesWrapper::AddPeriodicTask(
	IPeriodicTaskManager& periodicTaskManager,
	InternalCodesWrapper& internalCodesWrapper)
{
	periodicTaskManager.Add(
		n_taskPeriod,
		[&internalCodesWrapper]
		{
			internalCodesWrapper.Update();
		});
}
InternalCodesWrapper::InternalCodesWrapper(
	J1939::IJ1939Wrapper& j1939Wrapper,
	unsigned internalCodesNvmDataId) noexcept
	: m_j1939Wrapper(j1939Wrapper)
	, m_internalCodesNvmDataId(internalCodesNvmDataId)
{
}
void InternalCodesWrapper::SetDependencies(
	std::vector<InternalCodeConfig>&& internalCodeEntries,
	std::vector<std::unique_ptr<IInternalCode>>&& internalCodes)
{
	assert(m_internalCodes.empty());
	assert(m_internalCodeEntries.empty());
	assert(internalCodeEntries.size() == internalCodes.size());

	m_internalCodeEntries = std::move(internalCodeEntries);
	m_internalCodes = std::move(internalCodes);
}
void InternalCodesWrapper::Initialize(ISharkByteRetriever const& sharkByteRetriever, Nvm::ISclNvmWrapper& sclNvmWrapper)
{
	assert(m_spInternalCodesConfiguration == nullptr);
	m_spInternalCodesConfiguration = std::make_unique<InternalCodesConfiguration>(
		sharkByteRetriever,
		m_internalCodeEntries,
		sclNvmWrapper.GetNvmBlockHandle(m_internalCodesNvmDataId));
	scl_obd_es_error_t obdEsError;
	m_spObdEsInstance = scl_obd_es_init(
		&m_spInternalCodesConfiguration->GetObdEsConfig(),
		FALSE,
		&obdEsError);
	ThrowErrorIfFail(obdEsError, "Obd event system initialization failed");
	scl_diag_pj1939_error_t eddtError;
	m_spEddtInstance = scl_diag_pj1939_init(
		&m_spInternalCodesConfiguration->GetEddtConfig(),
		m_j1939Wrapper.GetLink(),
		J1939::J1939Definitions::VirtualEcmIndex(),
		m_spObdEsInstance,
		nullptr,
		&eddtError);
	ThrowErrorIfFail(eddtError, "Eddt diagnostic system initialization failed");
	auto const pHandleGenerator = scl_obd_handle_gen_init();
	if (pHandleGenerator == nullptr)
	{
		throw Error("scl_obd_handle_gen_init failed!");
	}
	auto const& internalCodeData = m_spInternalCodesConfiguration->GetInternalCodeData();
	assert(internalCodeData.size() == m_internalCodes.size());
	for (auto i = 0u; i < m_internalCodes.size(); ++i)
	{
		auto& codeData = internalCodeData[i];
		auto handle = ConfigureSclCode(pHandleGenerator, codeData.testConfig, codeData.faultConfig);
		m_internalCodes[i]->Initialize(codeData.statusSharkByte, handle);
	}

	scl_obd_persistent_id_t persistentIds[n_maxNumberOfCodes];
	uint_least16_t actualIdCount{0};
	auto const removeError = scl_obd_es_remove_unregistered_faults(
		m_spObdEsInstance,
		persistentIds,
		n_maxNumberOfCodes * sizeof(scl_obd_persistent_id_t),
		&actualIdCount);
	ThrowErrorIfFail(removeError, "scl_obd_es_remove_unregistered_faults failed");
	for (auto id = 0; id < actualIdCount; ++id)
	{
		LOG_INFO_HIGH_TAG(Log::Diagnostics, "Persistent Id removed from nvm: " << std::hex << persistentIds[id]);
	}
}
Utilities::nice_ptr<scl_obd_es_t> InternalCodesWrapper::GetObdEsInstance() const
{
	return m_spObdEsInstance;
}
Utilities::nice_ptr<scl_diag_pj1939_t> InternalCodesWrapper::GetEddtInstance() const
{
	return m_spEddtInstance;
}
namespace
{
char const* GetHandleString(scl_obd_test_handle_t handle)
{
	static constexpr char const* const s_handleStrings[] =
	{
		"FAIL",
		"PASS",
		"UNKNOWN",
		"NOT_READY",
	};
	assert(handle <= SCL_OBD_ES_TEST_RESULTS_NOT_READY);
	return s_handleStrings[handle];
}
}
void InternalCodesWrapper::SetTestStatus(scl_obd_test_handle_t testHandle, std::optional<bool> testStatus)
{
	auto testResult = SCL_OBD_ES_TEST_RESULTS_UNKNOWN;
	if (testStatus)
	{
		testResult = *testStatus ? SCL_OBD_ES_TEST_RESULTS_FAIL : SCL_OBD_ES_TEST_RESULTS_PASS;
	}
	LOG_DEBUG_TAG(Log::Diagnostics, "Setting handle " << testHandle << " to " << GetHandleString(testResult));
	auto const error = scl_obd_es_notify_test_results(
		m_spObdEsInstance,
		testHandle,
		testResult);
	if (error != SCL_OBD_ES_SUCCESS)
	{
		LOG_ERROR_TAG(Log::Diagnostics, "Error: " << ConvertObdErrorToString(error) << " When setting handle " << testHandle << " to " << GetHandleString(testResult));
	}
}
bool InternalCodesWrapper::GetActiveStatus(ActivatableDataLinkHealthDiagnostics diagnostic)
{
	bool status{false};
	if (m_healthHandles[diagnostic])
	{
		scl_obd_es_fault_rep_t faultReport;
		scl_obd_es_error_t error = scl_obd_es_get_fault_rep(
			m_spObdEsInstance,
			*(m_healthHandles[diagnostic]),
			&faultReport);

		if(error == SCL_OBD_ES_SUCCESS)
		{
			status = (SCL_OBD_ES_REP_ACTIVE_DIAG & faultReport);
		}
	}
	return status;
}
scl_obd_test_handle_t InternalCodesWrapper::ConfigureSclCode(
	scl_obd_handle_gen_t* pHandleGenerator,
	scl_obd_es_test_config_t const& testConfig,
	scl_eddt_fault_config_t const& faultConfig)
{
	auto handle = scl_obd_handle_gen_get(pHandleGenerator);
	ThrowErrorIfFail(
		scl_obd_es_register_test(m_spObdEsInstance, handle, &testConfig),
		"Obd registration of test failed");
	ThrowErrorIfFail(
		scl_diag_pj1939_register_fault(m_spEddtInstance, handle, &faultConfig),
		"Eddt registration of fault failed");

	LOG_DEBUG_TAG(Log::Diagnostics, "Initialized Code " << faultConfig.eid_or_cid << "-"
		<< static_cast<unsigned>(faultConfig.fmi) << "-"
		<< static_cast<unsigned>(faultConfig.wci) << ": Handle is " << handle << "!");

	return handle;
}
void InternalCodesWrapper::Update()
{
	scl_obd_es_update(m_spObdEsInstance);
	scl_diag_pj1939_update(m_spEddtInstance);
}
}
}