/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Scl Code Helpers

#pragma once

#include "Diagnostics/CodeDefinitions.h"
#include "Utilities/Conversions.h"
#include <scl_dcm_types.h>
#include <ostream>

struct DcmErrorState
{
	scl_dcm_error_state_t value;
};
std::ostream& operator<<(std::ostream& stream, DcmErrorState errorState);

struct SclTableStatus
{
	scl_dcm_tbl_status_t value;
};
std::ostream& operator<<(std::ostream& stream, SclTableStatus tableStatus);

struct SclCodeType
{
	scl_dcm_tbl_code_type_t value;
};
std::ostream& operator<<(std::ostream& stream, SclCodeType codeType);

struct SclCodeStatus
{
	scl_dcm_eddt_status_type_t value;
};
std::ostream& operator<<(std::ostream& stream, SclCodeStatus codeStatus);

template <>
Shark::Diagnostics::CodeType To(scl_dcm_tbl_code_type_t const& sclType);
template <>
Shark::Diagnostics::CodeStatus To(scl_dcm_eddt_status_type_t const& sclStatus);

namespace Shark
{
namespace Diagnostics
{
constexpr uint_least8_t InvalidSclFaultStatus() { return 0xFF; }

void SetFaultWci(scl_dcm_db_fault_s& faultInfo, unsigned wci);
unsigned GetFaultWci(scl_dcm_db_fault_s const& faultInfo);
void SetFaultFmi(scl_dcm_db_fault_s& faultInfo, unsigned fmi);
unsigned GetFaultFmi(scl_dcm_db_fault_s const& faultInfo);
void SetFaultLampStatus(scl_dcm_db_fault_s& faultInfo, unsigned short lampStatus);
}
}
