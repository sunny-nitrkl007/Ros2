/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Code Shark Byte

#pragma once

#include "ICodesHandler.h"
#include "ISharkByte.h"
#include <Utilities/CommonExceptions.h>
#include <Utilities/mutex.h>
#include <memory>
#include <vector>

namespace Utilities { class SimpleSharkByte; }
namespace Shark
{
namespace Diagnostics
{
class ICodesRepository;
class CodesSharkByte final : public ISharkByte, public ICodesHandler
{
public:
	static std::unique_ptr<CodesSharkByte> Create(
		ICodesRepository& codesRepository);

	CodesSharkByte(
		SharkByteId&& id,
		ICodesRepository& codesRepository);
// ISharkByte
	SharkByteId const& Id() const noexcept override { return m_id; }
	std::string Describe() const override;
	SharkByteSubscription SubscribeToValues(boost::function<void(SharkByteValue const&)> const& callback) override;
	SharkByteValue Value() const override { throw Utilities::NotImplemented(); }
	void Refresh() override {}
// ICodesHandler
	void OnCodeUpdate(std::unique_ptr<ICode>&& spCode) override;
private:
	void ProcessCode(std::unique_ptr<ICode>&& spCode);
	void SendCodes();

	SharkByteId const m_id;
	ICodesRepository& m_codesRepository;
	Utilities::mutex m_mutex{};
	std::vector<uint8_t> m_currentCodeList{};
	boost::signals2::signal<void(SharkByteValue const&)> m_signal{};
};
}
}