/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See CodesWrapper.h

#include "CodesWrapper.h"
#include "DependencyContainer.h"
#include "J1939/IJ1939Wrapper.h"
#include "J1939/J1939Definitions.h"
#include "ICodesManager.h"
#include "IInternalCodesWrapper.h"
#include "IPeriodicTaskManager.h"
#include "Log.h"
#include "SclCodeHelpers.h"
#include <Utilities/ArrayToHexString.h>
#include <Utilities/Conversions.h>
#include <Utilities/CountOf.h>
#include <Utilities/narrow_cast.h>
#include <SharkConfiguration.pb.h>
#include <algorithm>
#include <sstream>

using Utilities::narrow_cast;
using namespace std::chrono_literals;
using namespace cat::shark;

namespace ConversionsDetail
{
template <>
scl_dcli_req_msg_types_t Converter<scl_dcli_req_msg_types_t, Shark::Diagnostics::CodeType>::Convert(
	Shark::Diagnostics::CodeType const& codeType)
{
	switch (codeType)
	{
		case Shark::Diagnostics::CodeType::EddtDiagnostic:
			return SCL_DCLI_AI_DIAG_CODE_REQ_MSG;
		case Shark::Diagnostics::CodeType::EddtEvent:
			return SCL_DCLI_AI_EVENT_CODE_REQ_MSG;
		case Shark::Diagnostics::CodeType::PublicDtc:
			return SCL_DCLI_AI_SPN_CODE_REQ_MSG;
		default:
			throw std::logic_error("Unsupported Code Type");
	}
}
}
namespace Shark
{
namespace Diagnostics
{
struct PeerTable
{
	scl_dcm_peer_config_t sclPeerConfig;
	bool isOwnPeer;
};
using PeerTables = std::array<std::vector<PeerTable>, ::Config::CanPortCount>;

namespace
{
scl_dcm_config_t const n_dcmConfig = SCL_DCM_CONFIG_I1(
	nullptr,
	0,
	&CodesWrapper::DcmCodeUpdate,
	nullptr,
	&CodesWrapper::DcmPeerUpdate,
	nullptr,
	&CodesWrapper::DcmAIUpdate,
	nullptr,
	nullptr,
	nullptr,
	&CodesWrapper::DcmErrorUpdate,
	nullptr,
	nullptr,
	nullptr);

scl_dcm_svc_types_t n_ownServices[] =
{
	SCL_DCLI_SVC_TYPE_OWN_CODES,
	SCL_DCLI_SVC_TYPE_OWN_AI
};
scl_dcm_svc_types_t n_eddtServices[] =
{
	SCL_DCLI_SVC_TYPE_EDDT_DIAG,
	SCL_DCLI_SVC_TYPE_EDDT_EVENT,
	SCL_DCLI_SVC_TYPE_AI
};
scl_dcm_svc_types_t n_publicServices[] =
{
	SCL_DCLI_SVC_TYPE_DM1,
	SCL_DCLI_SVC_TYPE_DM2,
	SCL_DCLI_SVC_TYPE_DM31,
	SCL_DCLI_SVC_TYPE_AI
};

constexpr auto n_ownServicesSourceAddress = 0xFF;
constexpr auto n_invalidLinkIndex = 0xFF;

scl_dcm_peer_config_t CreateOwnPeer(J1939::J1939NameFields const& j1939NameFields)
{
	return scl_dcm_peer_config_t{
		SCL_DCM_CFG_VERSION,
		SCL_DCLI_PEER_BY_NAME,
		n_ownServicesSourceAddress,
		SCL_J1939_NAME_FULL(
			j1939NameFields.industryGroup,
			j1939NameFields.vehicleSystemInstance,
			j1939NameFields.vehicleSystem,
			j1939NameFields.function,
			j1939NameFields.functionInstance,
			j1939NameFields.ecmInstance,
			j1939NameFields.manufacturerCode,
			0x00),
		SCL_J1939_NAME_FULL(0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00),
		n_ownServices,
		Utilities::CountOf(n_ownServices)};
}
scl_dcm_peer_config_t CreatePeer(unsigned address, Diagnostics_DiagnosticType diagnosticType)
{
	scl_dcm_svc_types_t* pServices{};
	uint_least8_t serviceCount{};
	if (diagnosticType == Diagnostics_DiagnosticType_DIAGNOSTIC_TYPE_EDDT)
	{
		pServices = n_eddtServices;
		serviceCount = Utilities::CountOf(n_eddtServices);
	}
	else
	{
		assert(diagnosticType == Diagnostics_DiagnosticType_DIAGNOSTIC_TYPE_PUBLIC);
		pServices = n_publicServices;
		serviceCount = Utilities::CountOf(n_publicServices);
	}
	return scl_dcm_peer_config_t{
		SCL_DCM_CFG_VERSION,
		0,
		To<uint_least8_t>(address),
		"",
		"",
		pServices,
		serviceCount};
}
PeerTables CreatePeerTables(
	::cat::shark::Diagnostics const& diagnostics,
	Utilities::nice_ptr<J1939::J1939NameFields const> spJ1939NameFields)
{
	PeerTables peerTables{};
	for (auto const& diagnosticCanPort : diagnostics.diagnostic_client_can_ports())
	{
		auto canPort = ::Config::ToConfigCanPort(diagnosticCanPort.can_port());
		peerTables[canPort].reserve(static_cast<unsigned>(diagnosticCanPort.peer_nodes_size()));
		for (auto const& peerNode : diagnosticCanPort.peer_nodes())
		{
			peerTables[canPort].push_back({CreatePeer(peerNode.address(), peerNode.diagnostic_type()), false});
		}
	}
	if (diagnostics.has_internal_code_list() && spJ1939NameFields)
	{
		auto canPort = ::Config::ToConfigCanPort(diagnostics.internal_code_list().service_can_port());
		peerTables[canPort].push_back({CreateOwnPeer(*spJ1939NameFields), true});
	}
	return peerTables;
}
J1939Wrappers CaptureJ1939Wrappers(DependencyContainer const& dependencyContainer)
{
	J1939Wrappers j1939Wrappers{};
	auto const& diagnostics = dependencyContainer.GetSharkConfig().diagnostics();
	for (auto const& diagnosticCanPort : diagnostics.diagnostic_client_can_ports())
	{
		auto canPort = ::Config::ToConfigCanPort(diagnosticCanPort.can_port());
		j1939Wrappers[canPort] = &dependencyContainer.GetIJ1939Wrapper(canPort);
	}
	if (diagnostics.has_internal_code_list())
	{
		// Most likely a duplicate assignment for the service can port, but it's easier than adding extra logic to only assign it once
		auto serviceCanPort = ::Config::ToConfigCanPort(diagnostics.internal_code_list().service_can_port());
		j1939Wrappers[serviceCanPort] = &dependencyContainer.GetIJ1939Wrapper(serviceCanPort);
	}
	return j1939Wrappers;
}

constexpr auto n_taskPeriod = TaskPeriod::Is100ms;
void AddPeriodicTask(IPeriodicTaskManager& periodicTaskManager, CodesWrapper& codesWrapper)
{
	periodicTaskManager.Add(
		n_taskPeriod,
		[&codesWrapper] {
			codesWrapper.Update();
		});
}
::Config::J1939Address GetAddressFromPeerIndex(scl_dcm_peer_id_t peerIndex)
{
	uint8_t address{};
	auto errorStatus = scl_dcm_get_peer_address(peerIndex, &address);
	if (errorStatus)
	{
		std::stringstream stream;
		stream << "scl_dcm_get_peer_address failed with error: " << DcmErrorState{errorStatus};
		throw CodesWrapper::Error(stream.str());
	}
	return ::Config::J1939Address{address};
}
scl_dcm_peer_id_t GetPeerIndexFromAddress(scl_dcm_link_id_t linkIndex, unsigned address)
{
	auto const peerIndex = scl_dcm_get_peer_index(linkIndex, static_cast<uint_least8_t>(address));
	if (peerIndex == 0xFF)
	{
		throw CodesWrapper::Error("scl_dcm_get_peer_index could not retrieve a valid peer index");
	}
	return peerIndex;
}
void DumpCodeData(scl_dcm_db_fault_s scl_dcm_db_fault_ptr, scl_dcm_tbl_status_t tbl_status, std::string const& functionName)
{
	LOG_DEBUG_TAG(Log::Diagnostics,
		functionName << " called with:\n" << "  Status: " << SclTableStatus{tbl_status} << "\n"
		<< "  " << GetAddressFromPeerIndex(scl_dcm_db_fault_ptr.peer_id) << "\n"
		<< "  Codetype: " << SclCodeType{scl_dcm_db_fault_ptr.code_type} << "\n"
		<< "  Code: " << scl_dcm_db_fault_ptr.code << "-" << GetFaultFmi(scl_dcm_db_fault_ptr) << "-" << GetFaultWci(scl_dcm_db_fault_ptr) << "\n"
		<< "  Occ: " << static_cast<unsigned>(scl_dcm_db_fault_ptr.occ) << "\n"
		<< "  Ar: " << static_cast<unsigned>(scl_dcm_db_fault_ptr.annunc_value) << "\n"
		<< "  Status: " << SclCodeStatus{scl_dcm_db_fault_ptr.status} << "\n"
		<< "  Lamps: " << static_cast<unsigned>(scl_dcm_db_fault_ptr.lamp_status) << "\n"
		<< "  CodeFlags?: " << static_cast<unsigned>(scl_dcm_db_fault_ptr.code_flags) << "\n"
		<< "  Lamp Raw: " << static_cast<unsigned>(scl_dcm_db_fault_ptr.lamp_raw_status));
}
uint_least16_t GetCurrentCodeCount(scl_dcm_peer_id_t peerId, scl_dcm_code_type_t codeType)
{
	uint_least16_t codeCount{};
	auto errorStatus = scl_dcm_peer_get_num_codes(peerId, codeType, &codeCount);
	// Since DM1 and DM2 codes are retrieved through the same method, we need to get the total
	// of both whenever we request either.  CSNS could provide methods to do the individual
	// types but this is a quick fix.
	if (codeType == SCL_DCM_SPN_DM1_CODE)
	{
		uint_least16_t dm2Count{};
		errorStatus = scl_dcm_peer_get_num_codes(peerId, SCL_DCM_SPN_DM2_CODE, &dm2Count);
		codeCount = static_cast<uint_least16_t>(dm2Count + codeCount);
	}
	if (codeType == SCL_DCM_SPN_DM2_CODE)
	{
		uint_least16_t dm1Count{};
		errorStatus = scl_dcm_peer_get_num_codes(peerId, SCL_DCM_SPN_DM1_CODE, &dm1Count);
		codeCount = static_cast<uint_least16_t>(dm1Count + codeCount);
	}
	if (errorStatus)
	{
		LOG_ERROR_TAG(Log::Diagnostics, "Received peer update but read of count of current codes failed with error: " << DcmErrorState{errorStatus});
	}

	return codeCount;
}
using ReadCodesMethod = decltype(&scl_dcm_read_diag_codes);
std::vector<scl_dcm_db_fault_s> CreateListOfCodes(
	ReadCodesMethod pReadCodes,
	scl_dcm_peer_id_t peerId,
	scl_dcm_code_type_t codeType)
{
	auto codeCount = GetCurrentCodeCount(peerId, codeType);
	std::vector<scl_dcm_db_fault_s> readFromSclCodes;
	std::vector<scl_dcm_db_fault_s> finalCodes;
	if (codeCount > 0)
	{
		readFromSclCodes.resize(codeCount);
		uint_least16_t dcmCodeEntriesFilled{0};
		auto errorStatus = pReadCodes(
			peerId,
			readFromSclCodes.data(),
			codeCount,
			&dcmCodeEntriesFilled);
		if (!errorStatus)
		{
			finalCodes.reserve(codeCount);
			for (auto code : readFromSclCodes)
			{
				if (code.code_type == codeType)
				{
					finalCodes.push_back(code);
				}
			}

			LOG_INFO_LOW_TAG(Log::Diagnostics, "Filled vector for " << GetAddressFromPeerIndex(peerId) << ", code type " <<
			                                   SclCodeType{codeType} << " with " << finalCodes.size() << " codes!");
		}
		else
		{
			LOG_ERROR_TAG(Log::Diagnostics, "Received peer update but read of current codes failed with error: " << DcmErrorState{errorStatus});
		}
	}

	return finalCodes;
}

constexpr auto n_group2Id = 2;
constexpr auto n_additionalInformationResponseTimeout = 5s;
Utilities::nice_ptr<CodesWrapper> n_spCodesWrapper{};
}

class SclDcmPeerConfiguration final
{
public:
	SclDcmPeerConfiguration(
		::cat::shark::Diagnostics const& diagnostics,
		Utilities::nice_ptr<J1939::J1939NameFields const> spJ1939NameFields);
	PeerTables const& GetSclDcmPeerTables() const { return m_peerTables; }
private:
	PeerTables const m_peerTables;
};
SclDcmPeerConfiguration::SclDcmPeerConfiguration(
	::cat::shark::Diagnostics const& diagnostics,
	Utilities::nice_ptr<J1939::J1939NameFields const> spJ1939NameFields)
	: m_peerTables(CreatePeerTables(diagnostics, spJ1939NameFields))
{
}

std::shared_ptr<CodesWrapper> CodesWrapper::Create(
	DependencyContainer const& dependencyContainer,
	IInternalCodesWrapper& internalCodesWrapper,
	ICodesManager& codesManager)
{
	Utilities::nice_ptr<J1939::J1939NameFields const> spJ1939NameFields;
	auto const& diagnostics = dependencyContainer.GetSharkConfig().diagnostics();
	if (diagnostics.has_internal_code_list())
	{
		auto serviceCanPort = ::Config::ToConfigCanPort(diagnostics.internal_code_list().service_can_port());
		spJ1939NameFields = &dependencyContainer.GetIJ1939Wrapper(serviceCanPort).GetJ1939NameFields();
	}
	auto& periodicTaskManager = dependencyContainer.GetIPeriodicTaskManager();

	auto j1939Wrappers = CaptureJ1939Wrappers(dependencyContainer);

	auto spCodesWrapper = std::make_shared<CodesWrapper>(
		std::make_unique<SclDcmPeerConfiguration const>(
			diagnostics,
			spJ1939NameFields),
		std::move(j1939Wrappers),
		dependencyContainer.GetIEventCallbackFactory(),
		internalCodesWrapper,
		codesManager);

	AddPeriodicTask(periodicTaskManager, *spCodesWrapper);

	return spCodesWrapper;
}

CodesWrapper::CodesWrapper(
	std::unique_ptr<SclDcmPeerConfiguration const>&& peerConfiguration,
	J1939Wrappers&& j1939Wrappers,
	SharkUtilities::IEventCallbackFactory& eventCallbackFactory,
	IInternalCodesWrapper& internalCodesWrapper,
	ICodesManager& codesManager) noexcept
	: m_spSclDcmPeerConfiguration(std::move(peerConfiguration))
	, m_j1939Wrappers(std::move(j1939Wrappers))
	, m_eventCallbackFactory(eventCallbackFactory)
	, m_internalCodesWrapper(internalCodesWrapper)
	, m_codesManager(codesManager)
{
	assert(m_spSclDcmPeerConfiguration);

	assert(!n_spCodesWrapper);
	n_spCodesWrapper = this;
}
CodesWrapper::~CodesWrapper()
{
	assert(n_spCodesWrapper);
	n_spCodesWrapper.reset();
}
void CodesWrapper::DcmPeerUpdate(
	scl_dcm_peer_id_t peerId,
	scl_dcm_code_type_t codeType,
	void*)
{
	assert(n_spCodesWrapper);
	ReadCodesMethod pReadCodes;
	if (codeType == SCL_DCM_DIAG_CODE)
	{
		pReadCodes = &scl_dcm_read_diag_codes;
	}
	else if (codeType == SCL_DCM_EVENT_CODE)
	{
		pReadCodes = &scl_dcm_read_event_codes;
	}
	else if (codeType == SCL_DCM_SPN_DM1_CODE || codeType == SCL_DCM_SPN_DM2_CODE)
	{
		pReadCodes = &scl_dcm_read_spn_codes;
	}
	else
	{
		LOG_DEBUG_TAG(Log::Diagnostics, "Received peer update for code type " << SclCodeType{codeType}
			<< ", ignoring because only DM1/DM2/EDDT peer updates are processed");
		return;
	}

	n_spCodesWrapper->ProcessPeerUpdate(
		peerId,
		CreateListOfCodes(pReadCodes, peerId, codeType));

	// DM2 is requested periodically (set in scl_dcli_tune.h to 15 at this time)
	// The first request for DM2 will go out the timeout period after startup
	// so inject a request up front so we can get the DM2 update earlier
	// Also was going to request DM31 but it is automatically requested after receiving DM1
	if (codeType == SCL_DCM_SPN_DM1_CODE)
	{
		scl_dcm_peer_request_dm(peerId, SCL_DCLI_DM2_REQ_MSG);
	}
}
void CodesWrapper::DcmCodeUpdate(
	scl_dcm_db_fault_s* pFault,
	scl_dcm_tbl_status_t tableStatus,
	void*)
{
	assert(n_spCodesWrapper);
	n_spCodesWrapper->ProcessCodeUpdate(pFault, tableStatus);
}
void CodesWrapper::DcmErrorUpdate(
	scl_dcm_error_state_t errorStatus,
	scl_dcm_peer_id_t peerId,
	scl_dcm_code_type_t codeType,
	void*)
{
	LOG_INFO_LOW_TAG(Log::Diagnostics,
		"Received error callback from " << GetAddressFromPeerIndex(peerId) << ", code type " << SclCodeType{codeType} <<
		", error_status " <<  DcmErrorState{errorStatus});
}
void CodesWrapper::DcmAIUpdate(
	scl_dcm_clbk_status_t callbackStatus,
	scl_dcm_peer_id_t peerId,
	scl_dcm_code_type_t codeType,
	uint_least32_t codeId,
	uint_least8_t fmi,
	uint_least8_t wci,
	uint_least8_t groupId,
	uint_least8_t dataSize,
	uint_least8_t* pGroupDataBuffer,
	void*)
{
	LOG_DEBUG_TAG(Log::Diagnostics, "CodesWrapper::ProcessAdditionalInformationUpdate: " << codeId);
	assert(n_spCodesWrapper);
	n_spCodesWrapper->ProcessAdditionalInformationUpdate(
		callbackStatus,
		peerId,
		codeType,
		codeId,
		fmi,
		wci,
		groupId,
		dataSize,
		pGroupDataBuffer);

}
void CodesWrapper::Initialize()
{
	LOG_INFO_LOW_TAG(Log::Init | Log::Diagnostics, "Initializing SCL DCM...");

	auto spObdEsInstance = m_internalCodesWrapper.GetObdEsInstance();
	auto spEddtInstance = m_internalCodesWrapper.GetEddtInstance();
	assert(spObdEsInstance);
	assert(spEddtInstance);

	auto errorState = scl_dcm_init(&n_dcmConfig);
	if (errorState)
	{
		std::stringstream stream;
		stream << "scl_dcm_init failed with error: " << DcmErrorState{errorState};
		throw Error(stream.str());
	}

	for (unsigned canPort = 0; canPort < ::Config::CanPortCount; ++canPort)
	{
		auto const& peerConfigsForPort = m_spSclDcmPeerConfiguration->GetSclDcmPeerTables()[canPort];
		m_dcmLinkIndexes[canPort] = n_invalidLinkIndex;
		if (!peerConfigsForPort.empty())
		{
			assert(m_j1939Wrappers[canPort]);
			errorState = scl_dcm_add_j1939_link(
				m_j1939Wrappers[canPort]->GetLink(),
				J1939::J1939Definitions::VirtualEcmIndex(),
				&m_dcmLinkIndexes[canPort]);
			if (errorState)
			{
				std::stringstream stream;
				stream << "scl_dcm_add_j1939_link failed with error: " << DcmErrorState{errorState};
				throw Error(stream.str());
			}

			for (auto const& peerConfig : peerConfigsForPort)
			{
				scl_dcm_peer_id_t peerId;
				if (peerConfig.isOwnPeer)
				{
					errorState = scl_dcm_register_own_peer(
						m_dcmLinkIndexes[canPort],
						&peerConfig.sclPeerConfig,
						SCL_DCLI_EDDT_EVENT_SYS,
						spObdEsInstance,
						spEddtInstance,
						&peerId);
					if (errorState)
					{
						std::stringstream stream;
						stream << "Unable to register own peer for diagnostic code wrapper. Error: " << DcmErrorState{errorState};
						throw Error(stream.str());
					}

					m_ownPeerId = peerId;
					LOG_DEBUG_TAG(Log::Diagnostics, "Own Peer Id = " << static_cast<unsigned>(m_ownPeerId));
				}
				else
				{
					errorState = scl_dcm_register_peer(m_dcmLinkIndexes[canPort], &peerConfig.sclPeerConfig, &peerId);
					if (errorState)
					{
						std::stringstream stream;
						stream << "Unable to register peer for diagnostic code wrapper. Error: " << DcmErrorState{errorState};
						throw Error(stream.str());
					}
				}
			}
		}
	}
	LOG_INFO_LOW_TAG(Log::Init, "CodesWrapper::Initialize end");
}
void CodesWrapper::Update()
{
	scl_dcm_update();
	{
		std::lock_guard<std::mutex> lock(m_mutex);
		if (m_activeAdditionalInformationRequest &&
		    m_activeAdditionalInformationRequest->uniqueId == m_timedOutUniqueId)
		{
			m_timedOutUniqueId.reset();
			SendResponseToActiveRequest();
		}
	}
	SendNextAdditionalInformationRequest();
}
void CodesWrapper::RegisterAdditionalInformationCallback(AdditionalInformationCallback const& callback)
{
	assert(callback);
	assert(!m_additionalInformationCallback);
	m_additionalInformationCallback = callback;
}
void CodesWrapper::RequestAdditionalInformation(UniqueKeyData uniqueKey)
{
	m_additionalInformationRequests.emplace(AdditionalInformationRequest{uniqueKey, {}, m_uniqueId++});
}
void CodesWrapper::ProcessPeerUpdate(
	scl_dcm_peer_id_t peerId,
	std::vector<scl_dcm_db_fault_s> const& codes)
{
	for (auto const& code : codes)
	{
		DumpCodeData(code, SCL_DCM_FAULT_ADDED, "PeerUpdate");

		m_codesManager.OnCodeUpdate(
			GetCanPortFromPeerIndex(peerId),
			GetAddressFromPeerIndex(peerId),
			peerId == m_ownPeerId,
			code,
			SCL_DCM_FAULT_ADDED);
	}
}
void CodesWrapper::ProcessCodeUpdate(
	scl_dcm_db_fault_s* pFault,
	scl_dcm_tbl_status_t tableStatus)
{
	auto const peerId = pFault->peer_id;
	DumpCodeData(*pFault, tableStatus, "CodeUpdate");

	m_codesManager.OnCodeUpdate(
		GetCanPortFromPeerIndex(peerId),
		GetAddressFromPeerIndex(peerId),
		peerId == m_ownPeerId,
		*pFault,
		tableStatus);
}
void CodesWrapper::ProcessAdditionalInformationUpdate(
	scl_dcm_clbk_status_t callbackStatus,
	scl_dcm_peer_id_t peerId,
	scl_dcm_code_type_t codeType,
	uint_least32_t codeId,
	uint_least8_t fmi,
	uint_least8_t wci,
	uint_least8_t groupId,
	uint_least8_t dataSize,
	uint_least8_t* pGroupDataBuffer)
{
	LOG_DEBUG_TAG(Log::Diagnostics, "CodesWrapper::ProcessAdditionalInformationUpdate: " << codeId);
	if (callbackStatus == SCL_DCLI_SVC_SUCCESS)
	{
		if (m_activeAdditionalInformationRequest)
		{
			auto const sharkCodeType = To<CodeType>(codeType);
			if (UpdateMatchesActiveRequest(peerId, sharkCodeType, codeId, fmi, wci))
			{
				LOG_DEBUG_TAG(Log::Diagnostics, "Received AI Group " << static_cast<unsigned>(groupId) << " Data: "
					<< Utilities::ArrayToHexString(pGroupDataBuffer, dataSize));

				if (dataSize > 0 && groupId == n_group2Id)
				{
					// pGroupDataBuffer is re-used for each call, so we need to copy the data out of it.
					assert(dataSize <= SCL_DCM_AI2_OD_SIZE);
					m_activeAdditionalInformationRequest->group2Data = std::vector<uint8_t>(pGroupDataBuffer, pGroupDataBuffer + dataSize);

					SendResponseToActiveRequest();
				}
			}
		}
	}
}
bool CodesWrapper::UpdateMatchesActiveRequest(
	scl_dcm_peer_id_t peerId,
	CodeType codeType,
	uint_least32_t codeId,
	uint_least8_t fmi,
	uint_least8_t wci)
{
	assert(m_activeAdditionalInformationRequest);
	auto const address = GetAddressFromPeerIndex(peerId);
	auto const uniqueKey = m_activeAdditionalInformationRequest->uniqueKeyData;
	auto matches = (address == uniqueKey.Address()) &&
                   (codeType == uniqueKey.Type()) &&
                   (codeId == uniqueKey.Id()) &&
                   (wci == uniqueKey.Wci());

	if (matches && (codeType == CodeType::EddtDiagnostic))
	{
		matches = (fmi == uniqueKey.Fmi());
	}

	return matches;
}

// Sends the next additional information request if there is not an active request
// and there are pending requests in the queue.
// Returns empty response if there is no support for group 2 or if the request fails to send.
void CodesWrapper::SendNextAdditionalInformationRequest()
{
	auto sendResponse = false;
	while (!m_activeAdditionalInformationRequest && !m_additionalInformationRequests.empty())
	{
		m_activeAdditionalInformationRequest.emplace(m_additionalInformationRequests.front());
		m_additionalInformationRequests.pop();

		auto const uniqueKey = m_activeAdditionalInformationRequest->uniqueKeyData;
		auto canPort = uniqueKey.CanPort();
		auto address = uniqueKey.Address();
		auto peerId = GetPeerIndexFromAddress(m_dcmLinkIndexes[canPort], address);
		LOG_INFO_HIGH_TAG(Log::Diagnostics, "Unique Key = " << std::hex << std::uppercase << uniqueKey);
		m_activeAdditionalInformationRequest->group2Supported = IsGroupSupported(peerId, n_group2Id);
		if (!IsActiveRequestSatisfied())
		{
			auto const result = scl_dcm_peer_request_ai(
				peerId,
				To<scl_dcm_req_msg_types_t>(uniqueKey.Type()),
				uniqueKey.Id(),
				uniqueKey.Wci(),
				uniqueKey.Fmi());
			if (result == SCL_DCM_SUCCESS)
			{
				unsigned uniqueId = m_activeAdditionalInformationRequest->uniqueId;
				m_spTimedCallback = m_eventCallbackFactory.CreateTimedCallbackThatFiresIn(
					n_additionalInformationResponseTimeout,
					[this, uniqueId] {
						std::lock_guard<std::mutex> lock(m_mutex);
						m_timedOutUniqueId.emplace(uniqueId);
					});
			}
			else
			{
				sendResponse = true;
				LOG_WARNING_TAG(Log::Diagnostics, "scl_dcm_peer_request_ai request failed: " << DcmErrorState{result});
			}
		}
		else
		{
			sendResponse = true;
			LOG_WARNING_TAG(Log::Diagnostics, "No support for group 2 so return without any request!");
		}
		if (sendResponse)
		{
			SendResponseToActiveRequest();
		}
	}
}
void CodesWrapper::SendResponseToActiveRequest()
{
	assert(m_activeAdditionalInformationRequest);
	assert(m_additionalInformationCallback);
	m_spTimedCallback.reset();
	m_additionalInformationCallback(
		m_activeAdditionalInformationRequest->uniqueKeyData,
		m_activeAdditionalInformationRequest->group2Data);
	m_activeAdditionalInformationRequest.reset();
}
bool CodesWrapper::IsGroupSupported(scl_dcm_peer_id_t peerId, uint_least8_t groupId)
{
	auto supportsGroup = false;
	uint_least8_t groups[SCL_DCLI_MAX_AI_GRPS_SUPPORTED]{};
	uint_least8_t filledCount{0};
	auto error = scl_dcm_peer_get_support_ai_grps(peerId, groups, Utilities::CountOf(groups), &filledCount);
	if (error == SCL_DCM_SUCCESS)
	{
		auto endIter = std::end(groups);
		auto findIter = std::find(std::begin(groups), endIter, groupId);
		if (findIter != endIter)
		{
			supportsGroup = true;
		}
	}
	else
	{
		// data link message to retrieve group support does not go out immediately.
		// If api fails assume we are in this case and wait for the requested group that failed.
		// Worst case if the api fails we will still only wait for the timeout to move to next request.
		supportsGroup = true;
	}
	return supportsGroup;
}
bool CodesWrapper::IsActiveRequestSatisfied()
{
	std::lock_guard<std::mutex> lock(m_mutex);
	assert(m_activeAdditionalInformationRequest);
	return (!m_activeAdditionalInformationRequest->group2Supported || m_activeAdditionalInformationRequest->group2Data.size() > 0);
}
::Config::CanPort CodesWrapper::GetCanPortFromPeerIndex(scl_dcm_peer_id_t peerId)
{
	scl_dcm_link_id_t linkIndex{};
	auto errorStatus = scl_dcm_get_link_index(peerId, &linkIndex);
	if (errorStatus)
	{
		std::stringstream stream;
		stream << "scl_dcm_get_link_index failed with error: " << DcmErrorState{errorStatus};
		throw CodesWrapper::Error(stream.str());
	}
	auto const iterFind = std::find_if(m_dcmLinkIndexes.begin(), m_dcmLinkIndexes.end(),
		[linkIndex](auto const& index) { return index == linkIndex; });
	if (iterFind == m_dcmLinkIndexes.end())
	{
		std::stringstream stream;
		stream << "No CAN port found for link index: " << linkIndex;
		throw CodesWrapper::Error(stream.str());
	}
	return static_cast<::Config::CanPort>(std::distance(m_dcmLinkIndexes.begin(), iterFind));
}
}
}
