/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Protobuf Code Utilities Interface
/// Helps to reduce redundancy and simplify unit testing

#pragma once

#include "ICode.h"
#include "Diagnostics/CodeDefinitions.h"

namespace Shark
{
namespace Diagnostics
{
class IProtobufCodeUtilities
{
public:
	virtual ~IProtobufCodeUtilities() = default;

	// static because they do not need to be overridden for unit tests
	static CodeType GetCodeType(cat::middleware::diagnostics::Code const& protobufCode);
	static cat::middleware::diagnostics::CodeStatus GetCodeStatus(cat::middleware::diagnostics::Code const& protobufCode);
	static unsigned GetAnnunciationRequirement(cat::middleware::diagnostics::Code const& protobufCode);
};
}
}
