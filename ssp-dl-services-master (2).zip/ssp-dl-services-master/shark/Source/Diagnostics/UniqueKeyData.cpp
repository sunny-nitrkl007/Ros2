/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See UniqueKeyData.h

#include "UniqueKeyData.h"
#include "SclCodeHelpers.h"
#include <Utilities/narrow_cast.h>

namespace Shark
{
namespace Diagnostics
{
namespace
{
uint8_t PackCanPortAndCodeType(Config::CanPort canPort, CodeType codeType) noexcept
{
	return static_cast<uint8_t>((static_cast<uint8_t>(canPort) << 4) | static_cast<uint8_t>(codeType));
}
uint64_t CreateUniqueKey(Config::CanPort canPort, Config::J1939Address address, scl_dcm_db_fault_s const &sclCode) noexcept
{
	PackedUniqueKeyData uniqueKey{};
	auto const sharkCodeType = To<CodeType>(sclCode.code_type);
	uniqueKey.codeData.id = sclCode.code;
	uniqueKey.codeData.canPortAndCodeType = PackCanPortAndCodeType(canPort, sharkCodeType);
	uniqueKey.codeData.address = static_cast<uint8_t>(address);
	uniqueKey.codeData.wci = Utilities::narrow_cast<uint8_t>(GetFaultWci(sclCode));
	uniqueKey.codeData.fmi =
		sharkCodeType == CodeType::EddtEvent ? 0 : Utilities::narrow_cast<uint8_t>(GetFaultFmi(sclCode));

	return uniqueKey.value;
}
template <typename SubMessage>
void PopulateUniqueKeyHelper(
	Config::CanPort canPort,
	CodeType codeType,
	unsigned fmi,
	SubMessage const &subMessage,
	PackedUniqueKeyData &uniqueKey)
{
	uniqueKey.codeData.canPortAndCodeType = PackCanPortAndCodeType(canPort, codeType);
	uniqueKey.codeData.fmi = Utilities::narrow_cast<uint8_t>(fmi);
	uniqueKey.codeData.wci = Utilities::narrow_cast<uint8_t>(subMessage.warning_category_indicator());
}
uint64_t CreateUniqueKey(cat::middleware::diagnostics::Code const& protobufCode)
{
	PackedUniqueKeyData uniqueKey{};
	uniqueKey.codeData.address =
		protobufCode.network_address().has_j1939_address() ?
			Utilities::narrow_cast<uint8_t>(protobufCode.network_address().j1939_address().address()) :
			Utilities::narrow_cast<uint8_t>(protobufCode.network_address().self().j1939().address());

	auto const canPort = protobufCode.network_address().has_j1939_address() ?
		Config::ToConfigCanPort(protobufCode.network_address().j1939_address().can_port()) :
		Config::ToConfigCanPort(protobufCode.network_address().self().j1939().can_port());

	auto const& information = protobufCode.information();
	if (information.has_diagnostic())
	{
		auto const &info = information.diagnostic();
		uniqueKey.codeData.id = info.component_identifier();
		PopulateUniqueKeyHelper(canPort, CodeType::EddtDiagnostic, info.failure_mode_identifier(), info, uniqueKey);
	}
	else if (information.has_event())
	{
		auto const &info = information.event();
		uniqueKey.codeData.id = info.event_identifier();
		PopulateUniqueKeyHelper(canPort, CodeType::EddtEvent, 0, info, uniqueKey);
	}
	else
	{
		assert(information.has_public_dtc());
		auto const &info = information.public_dtc();
		uniqueKey.codeData.id = info.suspect_parameter_number();
		PopulateUniqueKeyHelper(canPort, CodeType::PublicDtc, info.failure_mode_identifier(), info, uniqueKey);
	}

	return uniqueKey.value;
}
}

UniqueKeyData::UniqueKeyData(Config::CanPort canPort, Config::J1939Address address, scl_dcm_db_fault_s const& sclCode) noexcept
	: m_uniqueKey{.value = CreateUniqueKey(canPort, address, sclCode)}
{
}
UniqueKeyData::UniqueKeyData(uint64_t uniqueCodeKey) noexcept
	: m_uniqueKey{.value = uniqueCodeKey}
{
}
UniqueKeyData::UniqueKeyData(cat::middleware::diagnostics::Code const& protobufCode) noexcept
	: m_uniqueKey{.value = CreateUniqueKey(protobufCode)}
{
}
UniqueKeyData::UniqueKeyData(
	uint32_t id,
	CodeType codeType,
	Config::CanPort canPort,
	uint8_t address,
	uint8_t wci,
	uint8_t fmi) noexcept
	: m_uniqueKey{.codeData = {id, PackCanPortAndCodeType(canPort, codeType), address, wci, fmi}}
{
}
}
}