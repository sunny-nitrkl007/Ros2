/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Codes Repository

#pragma once

#include "ICodesRepository.h"
#include <Utilities/mutex.h>
#include <memory>
#include <vector>

namespace Utilities { class SimpleSharkByte; }

namespace Shark
{
namespace Diagnostics
{
class CodesRepository final : public ICodesRepository
{
public:
	static std::shared_ptr<CodesRepository> Create(
		Utilities::SimpleSharkByte& highestActiveCodeSeveritySharkByte);

	CodesRepository(Utilities::SimpleSharkByte& highestActiveAnnunciationRequirementSharkByte);

// ICodesRepository
	void OnCodeUpdate(std::unique_ptr<ICode>&& spCode) override;
	Utilities::nice_ptr<ICode const> GetCode(uint64_t uniqueKey) const override;
	std::vector<uint8_t> const SerializeCodeList() const override;

private:
	void ProcessHighestActiveCodeAnnunciationRequirement();
	void ProcessCode(std::unique_ptr<ICode>&& spCode);

	Utilities::SimpleSharkByte& m_highestActiveAnnunciationRequirementSharkByte;
	mutable Utilities::mutex m_mutex{};
	std::vector<std::unique_ptr<ICode>> m_codeList{};
};
}
}