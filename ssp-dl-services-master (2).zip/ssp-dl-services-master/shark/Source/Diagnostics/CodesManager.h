/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Codes Manager

#pragma once

#include "ICodesManager.h"
#include "UniqueKeyData.h"
#include <Utilities/ArrayView.h>
#include <Utilities/SharkBytes/SimpleSharkByte.h>
#include <functional>
#include <memory>

namespace Shark
{
class DependencyContainer;

namespace Diagnostics
{
class ICode;
class ICodeFactory;
class ICodesHandler;
class ICodesRepository;
class ICodesWrapper;

class CodesManager final : public ICodesManager
{
public:
	static bool ShouldBeCreated(DependencyContainer const& dependencyContainer);
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);

	CodesManager(
		std::unique_ptr<ICodeFactory>&& spCodeFactory,
		std::unique_ptr<ICodesHandler>&& spCodesHandler,
		Utilities::SimpleSharkByte& additionalInformationResponseSharkByte,
		ICodesRepository& codesRepository) noexcept;
	~CodesManager() override;

	void SetDependencies(ICodesWrapper& codesWrapper);
	void Initialize();
	void RequestAdditionalInformation(
		std::vector<uint8_t> const& value,
		IWriteSharkByte::CompletedCallback const& completedCallback);

// ICodesManager
	void OnCodeUpdate(
		Config::CanPort canPort,
		Config::J1939Address address,
		bool isOwnCode,
		scl_dcm_db_fault_s const& code,
		scl_dcm_tbl_status_t tableStatus) override;
private:
	void OnAdditionalInformation(
		UniqueKeyData const uniqueKey,
		std::vector<uint8_t> const& data);

	std::unique_ptr<ICodeFactory> const m_spCodeFactory;
	std::unique_ptr<ICodesHandler> const m_spCodesHandler;
	Utilities::SimpleSharkByte& m_additionalInformationResponseSharkByte;
	ICodesRepository& m_codesRepository;
	Utilities::nice_ptr<ICodesWrapper> m_spCodesWrapper{};
};
}
}
