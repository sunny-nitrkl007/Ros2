﻿/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Codes Wrapper

#pragma once

#include "ICodesWrapper.h"
#include "SharkUtilities/IEventCallbackFactory.h"
#include "SharkUtilities/ITimedCallback.h"
#include <Config/ProtobufConversions.h>
#include <SharkConfiguration.pb.h>
#include <functional>
#include <memory>
#include <queue>
#include <scl_dcm.h>
#include <vector>

namespace Shark
{
class DependencyContainer;
class IPeriodicTaskManager;
class ISharkByteManager;

namespace J1939 { class IJ1939Wrapper; }
namespace Diagnostics
{
class IInternalCodesWrapper;

class ICodesManager;
class SclDcmPeerConfiguration;

struct AdditionalInformationRequest
{
	UniqueKeyData uniqueKeyData;
	std::vector<uint8_t> group2Data;
	unsigned uniqueId;
	bool group2Supported;
};

using J1939Wrappers = std::array<Utilities::nice_ptr<J1939::IJ1939Wrapper const>, ::Config::CanPortCount>;

class CodesWrapper final : public ICodesWrapper
{
public:
	static std::shared_ptr<CodesWrapper> Create(
		DependencyContainer const& dependencyContainer,
		IInternalCodesWrapper& internalCodesWrapper,
		ICodesManager& codesManager);

	CodesWrapper(
		std::unique_ptr<SclDcmPeerConfiguration const>&& peerConfiguration,
		J1939Wrappers&& j1939Wrappers,
		SharkUtilities::IEventCallbackFactory& eventCallbackFactory,
		IInternalCodesWrapper& internalCodesWrapper,
		ICodesManager& codesManager) noexcept;
	~CodesWrapper() override;

	static void DcmPeerUpdate(
		scl_dcm_peer_id_t peerId,
		scl_dcm_code_type_t codeType,
		void* pContext);

	static void DcmCodeUpdate(
		scl_dcm_db_fault_s* pFault,
		scl_dcm_tbl_status_t tableStatus,
		void* pContext);

	static void DcmErrorUpdate(
		scl_dcm_error_state_t errorStatus,
		scl_dcm_peer_id_t peerId,
		scl_dcm_code_type_t codeType,
		void* pContext);

	static void DcmAIUpdate(
		scl_dcm_clbk_status_t callbackStatus,
		scl_dcm_peer_id_t peerId,
		scl_dcm_code_type_t codeType,
		uint_least32_t codeId,
		uint_least8_t fmi,
		uint_least8_t wci,
		uint_least8_t groupId,
		uint_least8_t dataSize,
		uint_least8_t* pGroupDataBuffer,
		void* pContext);

	void Initialize();
	void Update();

// ICodesWrapper
	void RegisterAdditionalInformationCallback(AdditionalInformationCallback const& callback) override;
	void RequestAdditionalInformation(UniqueKeyData uniqueKey) override;
private:
	void ProcessPeerUpdate(
		scl_dcm_peer_id_t peerId,
		std::vector<scl_dcm_db_fault_s> const& codes);
	void ProcessCodeUpdate(
		scl_dcm_db_fault_s* pFault,
		scl_dcm_tbl_status_t tableStatus);
	void ProcessAdditionalInformationUpdate(
		scl_dcm_clbk_status_t callbackStatus,
		scl_dcm_peer_id_t peerId,
		scl_dcm_code_type_t codeType,
		uint_least32_t codeId,
		uint_least8_t fmi,
		uint_least8_t wci,
		uint_least8_t groupId,
		uint_least8_t dataSize,
		uint_least8_t* pGroupDataBuffer);
	bool UpdateMatchesActiveRequest(
		scl_dcm_peer_id_t peerId,
		CodeType codeType,
		uint_least32_t codeId,
		uint_least8_t fmi,
		uint_least8_t wci);
	void SendNextAdditionalInformationRequest();
	void SendResponseToActiveRequest();
	bool IsGroupSupported(scl_dcm_peer_id_t peerId, uint_least8_t groupId);
	bool IsActiveRequestSatisfied();
	::Config::CanPort GetCanPortFromPeerIndex(scl_dcm_peer_id_t peerId);

	std::unique_ptr<SclDcmPeerConfiguration const> m_spSclDcmPeerConfiguration;
	J1939Wrappers m_j1939Wrappers;
	SharkUtilities::IEventCallbackFactory& m_eventCallbackFactory;
	IInternalCodesWrapper const& m_internalCodesWrapper;
	ICodesManager& m_codesManager;
	std::array<scl_dcli_link_id_t, ::Config::CanPortCount> m_dcmLinkIndexes{};
	AdditionalInformationCallback m_additionalInformationCallback{};
	std::queue<AdditionalInformationRequest> m_additionalInformationRequests{};
	std::optional<AdditionalInformationRequest> m_activeAdditionalInformationRequest{};
	std::unique_ptr<SharkUtilities::ITimedCallback> m_spTimedCallback{};
	unsigned m_uniqueId{0};
	std::mutex m_mutex{};
	std::optional<unsigned> m_timedOutUniqueId{};
	scl_dcm_peer_id_t m_ownPeerId{};
};
}
}