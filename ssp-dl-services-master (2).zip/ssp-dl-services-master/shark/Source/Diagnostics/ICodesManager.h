/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Codes Manager Interface

#pragma once

#include "Config/CanPort.h"
#include "Config/J1939Address.h"
#include <scl_dcm.h>
#include <vector>

namespace Shark
{
namespace Diagnostics
{
class ICodesManager
{
public:
	virtual ~ICodesManager() = default;

	virtual void OnCodeUpdate(
		Config::CanPort canPort,
		Config::J1939Address address,
		bool isOwnCode,
		scl_dcm_db_fault_s const& code,
		scl_dcm_tbl_status_t tableStatus) = 0;
};
}
}