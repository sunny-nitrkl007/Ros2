/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Code

#pragma once

#include "Diagnostics/CodeDefinitions.h"
#include "ICode.h"
#include <Config/J1939Address.h>
#include <scl_dcm.h>

namespace Shark
{
namespace Diagnostics
{
class Code final : public ICode
{
public:
	Code(Config::CanPort canPort, Config::J1939Address address, bool isOwnCode, scl_dcm_db_fault_s const& sclCode) noexcept;
	Code(cat::middleware::diagnostics::Code const& protobufCode);
	// ICode
	UniqueKeyData const& UniqueKey() const override;
	cat::middleware::diagnostics::Code const& ProtobufCode() const override;
	cat::middleware::diagnostics::CodeStatus CodeStatus() const override;
	unsigned AnnunciationRequirement() const override;

private:
	CodeType GetCodeType() const;

	UniqueKeyData const m_uniqueKey;
	cat::middleware::diagnostics::Code m_protobufCode;
};
}
}
