/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Code Factory Interface

#pragma once

#include "middleware_diagnostics.pb.h"
#include <Config/CanPort.h>
#include <Config/J1939Address.h>
#include <scl_dcm.h>

namespace Shark
{
namespace Diagnostics
{
class ICode;

class ICodeFactory
{
public:
	virtual ~ICodeFactory() = default;

	virtual std::unique_ptr<ICode>
	CreateCode(Config::CanPort canPort, Config::J1939Address address, bool isOwnCode, scl_dcm_db_fault_s const& sclCode) = 0;
};
}  // namespace Diagnostics
}  // namespace Shark
