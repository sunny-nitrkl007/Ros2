/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See InternalCodeStates.h

#include "InternalCodeStates.h"

using Utilities::ToUnderlying;

namespace Shark
{
namespace Diagnostics
{
InternalCodeStateBase::InternalCodeStateBase(
	InternalCodeStateId id,
	IInternalCode& internalCode,
	TestStateChangedDestinations const& destinations)
	: m_id(id)
	, m_internalCode(internalCode)
	, m_destinations(destinations)
{
}
InternalCodeStateId InternalCodeStateBase::TestStateChanged(std::optional<bool> testState)
{
	auto id = m_destinations[ToUnderlying(DestinationId::Invalid)];
	if (testState)
	{
		id = *testState ? m_destinations[ToUnderlying(DestinationId::True)] : m_destinations[ToUnderlying(DestinationId::False)];
	}
	return id;
}

InternalCodeTimingStateBase::InternalCodeTimingStateBase(
	InternalCodeStateId id,
	IInternalCode& internalCode,
	TestStateChangedDestinations const& destinations,
	std::chrono::seconds delayTime)
	: InternalCodeStateBase(id, internalCode, destinations)
	, m_delayTime(delayTime)
{
}
InternalCodeStateId InternalCodeTimingStateBase::TestStateChanged(std::optional<bool> testState)
{
	auto const id =  InternalCodeStateBase::TestStateChanged(testState);
	if (id != Id())
	{
		InternalCode().KillTimer();
	}
	return id;
}
}
}
