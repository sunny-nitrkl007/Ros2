/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Unique Key Data wrapper class

#pragma once

#include "Diagnostics/CodeDefinitions.h"
#include <Config/J1939Address.h>
#include <Config/ProtobufConversions.h>
#include <scl_dcm.h>
#include <middleware_diagnostics.pb.h>

namespace Shark
{
namespace Diagnostics
{
union PackedUniqueKeyData
{
	struct
	{
		uint32_t id;
		uint8_t canPortAndCodeType; // canPort in upper 4 bits, codeType in lower 4 bits
		uint8_t address;
		uint8_t wci;
		uint8_t fmi;
	} codeData;
	uint64_t value;
};
static_assert(sizeof(PackedUniqueKeyData) == sizeof(PackedUniqueKeyData{}.value), "");

class UniqueKeyData final
{
public:
	UniqueKeyData(Config::CanPort canPort, Config::J1939Address address, scl_dcm_db_fault_s const& sclCode) noexcept;
	UniqueKeyData(uint64_t uniqueCodeKey) noexcept;
	UniqueKeyData(cat::middleware::diagnostics::Code const& protobufCode) noexcept;
	UniqueKeyData(
		uint32_t id,
		CodeType codeType,
		Config::CanPort canPort,
		uint8_t address,
		uint8_t wci,
		uint8_t fmi) noexcept;

	constexpr operator uint64_t() const noexcept { return m_uniqueKey.value; }
	constexpr uint32_t Id() const noexcept { return m_uniqueKey.codeData.id; }
	constexpr CodeType Type() const noexcept
		{ return static_cast<CodeType>(m_uniqueKey.codeData.canPortAndCodeType & 0x0F); }
	constexpr Config::CanPort CanPort() const noexcept
		{ return static_cast<Config::CanPort>((m_uniqueKey.codeData.canPortAndCodeType & 0xF0) >> 4); }
	constexpr uint8_t Address() const noexcept { return m_uniqueKey.codeData.address; }
	constexpr uint8_t Wci() const noexcept { return m_uniqueKey.codeData.wci; }
	constexpr uint8_t Fmi() const noexcept { return m_uniqueKey.codeData.fmi; }
private:
	PackedUniqueKeyData m_uniqueKey{};
};
}
}
