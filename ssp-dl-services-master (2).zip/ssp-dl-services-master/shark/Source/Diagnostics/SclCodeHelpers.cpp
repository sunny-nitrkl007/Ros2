/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SclCodeHelpers.h

#include "SclCodeHelpers.h"
#include "Utilities/CountOf.h"
#include <scl_dcm_types.h>

using namespace Shark::Diagnostics;

std::ostream& operator<<(std::ostream& stream, DcmErrorState errorState)
{
	static constexpr char const* s_toString[]
	{
		"SCL_DCM_SUCCESS",
		"SCL_DCM_PEER_NOT_REGISTERED",
		"SCL_DCM_NOT_INITED",
		"SCL_DCM_LINK_MAX_LIMIT",
		"SCL_DCM_MULTIPLE_CDL_LINK_NOT_SUPP",
		"SCL_DCM_LINK_DUPLICATE",
		"SCL_DCM_INVALID_ECM_INDEX",
		"SCL_DCM_LINK_NOT_EXIST",
		"SCL_DCM_ALREADY_INITED",
		"SCL_DCM_CONFIG_NULL",
		"SCL_DCM_BUFF_OR_BUFF_SIZE_NULL",
		"SCL_DCM_INVALID_WCI_LEVEL",
		"SCL_DCM_FAILURE",
		"SCL_DCM_PEER_NOT_ALL_SVCS_ADDED",
		"SCL_DCM_PEER_INVALID_SVC_CFG",
		"SCL_DCM_PEER_ID_INVALID",
		"SCL_DCM_SVC_NULL_PTR_OR_INVALID_SIZE",
		"SCL_DCM_SVC_ARRAY_SZ_NOT_SUFFICIEINT",
		"SCL_DCM_PEER_DM1_SVC_REQD",
		"SCL_DCM_AI_OD_NOT_CONFIGURED",
		"SCL_DCM_AI_NOT_SUPPORTED",
		"SCL_DCM_AI_FAULT_NOT_AVAILABLE",
		"SCL_DCM_AI_OD_NOT_REQUESTED",
		"SCL_DCM_AI_OD_DISABLED",
		"SCL_DCM_AI_QUEUE_FULL",
		"SCL_DCM_CODE_TYPE_INVALID",
		"SCL_DCM_DISCVR_NOT_ENABLED",
		"SCL_DCM_DISCVR_NTFY_NULL",
		"SCL_DCM_DISCVR_INVALID_CFG",
		"SCL_DCM_LINK_INVALID",
		"SCL_DCM_DISCVR_LIST_INVALID",
		"SCL_DCM_QUEUE_FULL",
		"SCL_DCM_DISCVR_NO_PROTOCOl_SUPPORTED",
		"SCL_DCM_INVALID_ECM_ADDR",
		"SCL_DCM_HANDLER_REG_FAILED",
		"SCL_DCM_DISCVR_ALREADY_REGISTERED",
		"SCL_DCM_J1939_NAME_NOT_FOUND",
		"SCL_DCM_FAULT_NOT_AVAILABLE",
		"SCL_DCM_SVC_HEARTBEAT_MISSING",
		"SCL_DCM_SVC_MSG_OUT_OF_SEQ",
		"SCL_DCM_SVC_BUFFER_OVER_FLOW_ERROR",
		"SCL_DCM_SVC_EDDT_CODE_DATA_MISMATCH",
		"SCL_DCM_TBL_RSP_MSG_MISSING",
		"SCL_DCM_SVC_RSP_TIMEOUT",
		"SCL_DCM_SVC_FEATURE_RSP_NAK",
		"SCL_DCM_SVC_EDDT_DIAG_TABLE_RSP_NACK",
		"SCL_DCM_SVC_EDDT_EVENT_TABLE_RSP_NACK",
		"SCL_DCM_SVC_FEATURE_RSP_MISSING",
		"SCL_DCM_SVC_UPDATE_RATE_RSP_MISSING",
		"SCL_DCM_SVC_DM1_RSP_NACK",
		"SCL_DCM_SVC_DM2_RSP_NACK",
		"SCL_DCM_SVC_DM31_RSP_NACK",
		"SCL_DCM_SVC_AI_CODE_RSP_NACK",
		"SCL_DCM_SVC_AI_CODE_TYPE_RSP_NACK",
		"SCL_DCM_SVC_AI_GROUP_RSP_NAK",
		"SCL_DCM_SVC_AI_GROUP_RSP_MISSING",
		"SCL_DCM_SVC_AI_CODE_RSP_MISSING",
		"SCL_DCM_SVC_AI_CODE_TYPE_RSP_INVALID",
		"SCL_DCM_SVC_DM_SPN_CONV_METHOD_NOT_SUPPORTED",
		"SCL_DCM_SVC_SUBSC_FAILED"
	};

	assert(errorState.value < Utilities::CountOf(s_toString));
	return stream << s_toString[errorState.value];
}
std::ostream& operator<<(std::ostream& stream, SclTableStatus tableStatus)
{
	static constexpr char const* s_toString[]
	{
		"No Change",
		"Deleted",
		"Updated",
		"Added",
	};

	assert(tableStatus.value < Utilities::CountOf(s_toString));
	return stream << s_toString[tableStatus.value];
}
std::ostream& operator<<(std::ostream& stream, SclCodeType codeType)
{
	static constexpr char const* s_toString[]
	{
		"Diagnostic",
		"Event",
		"DM1",
		"DM31",
		"DM2",
		"DM12"
	};

	assert(codeType.value < Utilities::CountOf(s_toString));
	return stream << s_toString[codeType.value];
}
std::ostream& operator<<(std::ostream& stream, SclCodeStatus codeStatus)
{
	static constexpr char const* s_toString[]
	{
		"ActiveAndLogged",
		"ActiveOnly",
		"LoggedOnly",
		"NotActiveOrLogged",
		"PreviouslyActiveAndLogged",
		"PreviouslyActive",
	};

	assert(codeStatus.value < Utilities::CountOf(s_toString));
	return stream << s_toString[codeStatus.value];
}

template <>
Shark::Diagnostics::CodeType To(scl_dcm_tbl_code_type_t const& sclType)
{
	constexpr auto invalid = CodeType::Count;
	static constexpr CodeType s_toCodeType[]
	{
		CodeType::EddtDiagnostic,
		CodeType::EddtEvent,
		CodeType::PublicDtc,
		CodeType::PublicDtc,
		CodeType::PublicDtc,
		invalid
	};

	if (sclType >= Utilities::CountOf(s_toCodeType) || s_toCodeType[sclType] == invalid)
	{
		throw std::logic_error("Unknown Code Type");
	}

	return s_toCodeType[sclType];
}
template <>
Shark::Diagnostics::CodeStatus To(scl_dcm_eddt_status_type_t const& sclStatus)
{
	static constexpr CodeStatus s_toCodeStatus[]
	{
		CodeStatus::ActiveAndLogged,
		CodeStatus::Active,
		CodeStatus::Logged,
		CodeStatus::None,
		CodeStatus::Logged,
		CodeStatus::Logged,
	};

	CodeStatus status{};
	if (sclStatus < Utilities::CountOf(s_toCodeStatus))
	{
		status = s_toCodeStatus[sclStatus];
	}
	else if (sclStatus == Shark::Diagnostics::InvalidSclFaultStatus())
	{
		status = CodeStatus::Invalid;
	}
	else
	{
		throw std::logic_error("Unknown Code Status");
	}

	return status;
}

namespace Shark
{
namespace Diagnostics
{
void SetFaultWci(scl_dcm_db_fault_s& faultInfo, unsigned wci)
{
	assert(wci <= SCL_DCM_WCI_MASK);
	unsigned const originalShiftedFmi = faultInfo.wci_fmi & SCL_DCM_FMI_SHIFT_MASK;
	faultInfo.wci_fmi = static_cast<uint_least8_t>(originalShiftedFmi | wci);
}
unsigned GetFaultWci(scl_dcm_db_fault_s const& faultInfo)
{
	return faultInfo.wci_fmi & SCL_DCM_WCI_MASK;
}
void SetFaultFmi(scl_dcm_db_fault_s& faultInfo, unsigned fmi)
{
	assert(fmi <= (SCL_DCM_FMI_SHIFT_MASK >> SCL_DCM_FMI_SHIFT_3BITS));
	unsigned const originalWci = faultInfo.wci_fmi & SCL_DCM_WCI_MASK;
	unsigned const shiftedFmi = fmi << SCL_DCM_FMI_SHIFT_3BITS;
	faultInfo.wci_fmi = static_cast<uint_least8_t>(shiftedFmi | originalWci);
}
unsigned GetFaultFmi(scl_dcm_db_fault_s const& faultInfo)
{
	return static_cast<unsigned>(faultInfo.wci_fmi >> SCL_DCM_FMI_SHIFT_3BITS);
}
void SetFaultLampStatus(scl_dcm_db_fault_s& faultInfo, unsigned short lampStatus)
{
	faultInfo.lamp_status = lampStatus;
}
}
}
