/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Code.h

#include "Code.h"
#include "Diagnostics/SclCodeHelpers.h"
#include "IProtobufCodeUtilities.h"
#include <Utilities/CountOf.h>
#include <Utilities/narrow_cast.h>
#include <Utilities/ToUnderlying.h>
#include <algorithm>
#include <boost/endian/arithmetic.hpp>

template <>
cat::middleware::diagnostics::CodeStatus To(scl_dcm_eddt_status_type_t const &sclStatus)
{
	using cat::middleware::diagnostics::CodeStatus;
	static constexpr CodeStatus s_toCodeStatus[]{
		CodeStatus::CODE_STATUS_ACTIVE_AND_LOGGED,
		CodeStatus::CODE_STATUS_ACTIVE_ONLY,
		CodeStatus::CODE_STATUS_LOGGED_ONLY,
		CodeStatus::CODE_STATUS_NONE,
		CodeStatus::CODE_STATUS_LOGGED_ONLY,
		CodeStatus::CODE_STATUS_PREVIOUSLY_ACTIVE,
	};

	CodeStatus status{};
	if (sclStatus < Utilities::CountOf(s_toCodeStatus))
	{
		status = s_toCodeStatus[sclStatus];
	}
	else if (sclStatus == Shark::Diagnostics::InvalidSclFaultStatus())
	{
		status = CodeStatus::CODE_STATUS_NONE;
	}
	else
	{
		throw std::logic_error("Unknown Code Status");
	}

	return status;
}

namespace Shark
{
namespace Diagnostics
{
using boost::endian::big_uint32_t;
using boost::endian::little_uint16_t;

namespace
{
constexpr auto n_minimumAnnunciationValue = 1u;
constexpr auto n_maximumAnnunciationValue = 6u;
constexpr auto n_annunciationValueForWciOne = 1u;
constexpr auto n_annunciationValueForWciTwo = 4u;
constexpr auto n_annunciationValueForWciThree = 6u;

unsigned ResolveAnnunciationValue(scl_dcm_db_fault_s const& sclCode)
{
	auto const& wci = GetFaultWci(sclCode);
	auto const& actualAnnunciationValue = sclCode.annunc_value;
	unsigned resolvedValue = wci == 3 ? n_annunciationValueForWciThree : actualAnnunciationValue;

	if (std::clamp(resolvedValue, n_minimumAnnunciationValue, n_maximumAnnunciationValue) != resolvedValue)
	{
		if (wci == 1)
		{
			resolvedValue = n_annunciationValueForWciOne;
		}
		else if (wci == 2)
		{
			resolvedValue = n_annunciationValueForWciTwo;
		}
	}
	return resolvedValue;
}

template <typename SubMessage>
void PopulateInformationSubMessage(scl_dcm_db_fault_s const& sclCode, SubMessage &subMessage)
{
	subMessage.set_warning_category_indicator(GetFaultWci(sclCode));
	subMessage.set_annunciation_requirement(ResolveAnnunciationValue(sclCode));
	subMessage.set_status(To<cat::middleware::diagnostics::CodeStatus>(sclCode.status));
}
void SetLampStatuses(uint_least16_t rawLamps, cat::middleware::diagnostics::LampStatuses& lampStatuses)
{
	using namespace cat::middleware::diagnostics;
	union PackedRawLampStatuses
	{
		uint16_t value;
		struct
		{
			uint8_t protectLampFlash : 2;
			uint8_t amberLampFlash : 2;
			uint8_t redLampFlash : 2;
			uint8_t malfunctionLampFlash : 2;
			uint8_t protectLamp : 2;
			uint8_t amberLamp : 2;
			uint8_t redLamp : 2;
			uint8_t malfunctionLamp : 2;
		} lamps;
	};
	PackedRawLampStatuses packedRawLamps{rawLamps};
	auto const& lamps = packedRawLamps.lamps;
	lampStatuses.set_protect_lamp(static_cast<LampStatuses_LampStatus>(lamps.protectLamp));
	lampStatuses.set_amber_lamp(static_cast<LampStatuses_LampStatus>(lamps.amberLamp));
	lampStatuses.set_red_lamp(static_cast<LampStatuses_LampStatus>(lamps.redLamp));
	lampStatuses.set_malfunction_lamp(static_cast<LampStatuses_MilLampStatus>(lamps.malfunctionLamp));
	lampStatuses.set_protect_lamp_flash(static_cast<LampStatuses_LampFlashStatus>(lamps.protectLampFlash));
	lampStatuses.set_amber_lamp_flash(static_cast<LampStatuses_LampFlashStatus>(lamps.amberLampFlash));
	lampStatuses.set_red_lamp_flash(static_cast<LampStatuses_LampFlashStatus>(lamps.redLampFlash));
	lampStatuses.set_malfunction_lamp_flash(static_cast<LampStatuses_MilLampFlashStatus>(lamps.malfunctionLampFlash));
}
cat::middleware::diagnostics::Code CreateProtobufCode(
	Config::CanPort canPort,
	Config::J1939Address address,
	bool isOwnCode,
	scl_dcm_db_fault_s const& sclCode,
	uint64_t uniqueKey)
{
	assert(sclCode.code_type == SCL_DCM_DIAG_CODE || sclCode.code_type == SCL_DCM_EVENT_CODE ||
	       sclCode.code_type == SCL_DCM_SPN_DM1_CODE || sclCode.code_type == SCL_DCM_SPN_DM2_CODE);
	cat::middleware::diagnostics::Code protobufCode{};
	auto pNetworkAddress = protobufCode.mutable_network_address();
	if (isOwnCode)
	{
		auto pJ1939Address = pNetworkAddress->mutable_self()->mutable_j1939();
		pJ1939Address->set_can_port(Config::ToCodesProtobufCanPort(canPort));
		pJ1939Address->set_address(address);
	}
	else
	{
		auto pJ1939Address = pNetworkAddress->mutable_j1939_address();
		pJ1939Address->set_can_port(Config::ToCodesProtobufCanPort(canPort));
		pJ1939Address->set_address(address);
	}

	protobufCode.set_code_key(uniqueKey);

	auto &information = *protobufCode.mutable_information();
	if (sclCode.code_type == SCL_DCM_DIAG_CODE)
	{
		auto &diagnostic = *information.mutable_diagnostic();
		PopulateInformationSubMessage(sclCode, diagnostic);
		diagnostic.set_component_identifier(sclCode.code);
		diagnostic.set_failure_mode_identifier(GetFaultFmi(sclCode));
	}
	else if (sclCode.code_type == SCL_DCM_EVENT_CODE)
	{
		auto &event = *information.mutable_event();
		PopulateInformationSubMessage(sclCode, event);
		event.set_event_identifier(sclCode.code);
	}
	else
	{
		assert(sclCode.code_type == SCL_DCM_SPN_DM1_CODE || sclCode.code_type == SCL_DCM_SPN_DM2_CODE);
		auto& publicDtc = *information.mutable_public_dtc();
		PopulateInformationSubMessage(sclCode, publicDtc);
		auto& lampStatuses = *publicDtc.mutable_lamp_statuses();
		SetLampStatuses(sclCode.lamp_raw_status, lampStatuses);
		publicDtc.set_suspect_parameter_number(sclCode.code);
		publicDtc.set_failure_mode_identifier(GetFaultFmi(sclCode));
		publicDtc.set_occurrence_count(sclCode.occ);
	}

	return protobufCode;
}
}

/// The (I)ProtobufCodeUtilities are unit tested indirectly through Code tests
CodeType IProtobufCodeUtilities::GetCodeType(cat::middleware::diagnostics::Code const& protobufCode)
{
	auto codeType = CodeType::PublicDtc;
	auto &information = protobufCode.information();
	if (information.has_diagnostic())
	{
		codeType = CodeType::EddtDiagnostic;
	}
	else if (information.has_event())
	{
		codeType = CodeType::EddtEvent;
	}
	else
	{
		assert(information.has_public_dtc());
	}

	return codeType;
}
cat::middleware::diagnostics::CodeStatus IProtobufCodeUtilities::GetCodeStatus(cat::middleware::diagnostics::Code const& protobufCode)
{
	auto &information = protobufCode.information();
	cat::middleware::diagnostics::CodeStatus status{};
	if (information.has_diagnostic())
	{
		status = information.diagnostic().status();
	}
	else if (information.has_event())
	{
		status = information.event().status();
	}
	else
	{
		assert(information.has_public_dtc());
		status = information.public_dtc().status();
	}
	return status;
}
unsigned IProtobufCodeUtilities::GetAnnunciationRequirement(cat::middleware::diagnostics::Code const& protobufCode)
{
	auto &information = protobufCode.information();
	unsigned ar{};
	if (information.has_diagnostic())
	{
		ar = information.diagnostic().annunciation_requirement();
	}
	else if (information.has_event())
	{
		ar = information.event().annunciation_requirement();
	}
	else
	{
		assert(information.has_public_dtc());
		ar = information.public_dtc().annunciation_requirement();
	}
	return ar;
}

Code::Code(Config::CanPort canPort, Config::J1939Address address, bool isOwnCode, scl_dcm_db_fault_s const& sclCode) noexcept
	: m_uniqueKey{UniqueKeyData(canPort, address, sclCode)}
	, m_protobufCode{CreateProtobufCode(canPort, address, isOwnCode, sclCode, m_uniqueKey)}
{
}
Code::Code(cat::middleware::diagnostics::Code const &protobufCode)
	: m_uniqueKey{UniqueKeyData(protobufCode)}
	, m_protobufCode{protobufCode}
{
}
UniqueKeyData const& Code::UniqueKey() const
{
	return m_uniqueKey;
}
cat::middleware::diagnostics::Code const &Code::ProtobufCode() const
{
	return m_protobufCode;
}
cat::middleware::diagnostics::CodeStatus Code::CodeStatus() const
{
	return IProtobufCodeUtilities::GetCodeStatus(m_protobufCode);
}
CodeType Code::GetCodeType() const
{
	return IProtobufCodeUtilities::GetCodeType(m_protobufCode);
}
unsigned Code::AnnunciationRequirement() const
{
	return IProtobufCodeUtilities::GetAnnunciationRequirement(m_protobufCode);
}
}
}