/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See CodesRepository.h

#include "CodesRepository.h"
#include "Code.h"
#include "Log.h"
#include <Utilities/SharkBytes/SimpleSharkByte.h>

namespace Shark
{
namespace Diagnostics
{
namespace
{
std::vector<uint8_t> SerializeCodes(cat::middleware::diagnostics::Codes const& protobufCodes)
{
	auto size = protobufCodes.ByteSizeLong();
	std::vector<uint8_t> serializedCodes(size);
	[[maybe_unused]] auto const serializedSuccessfully =
		protobufCodes.SerializeToArray(serializedCodes.data(), Utilities::narrow_cast<int>(size));
	assert(serializedSuccessfully);

	return serializedCodes;
}
std::string DumpCodes(std::string const& description, cat::middleware::diagnostics::Codes const& protobufCodes)
{
	std::stringstream stream{};
	stream << description << ": Count: " << protobufCodes.codes_size();
	for (auto const& protobufCode : protobufCodes.codes())
	{
		stream << "\n  " << protobufCode.ShortDebugString();
	}
	return stream.str();
}

constexpr auto n_noAnnunciationRequirementValue = 0u;
}

std::shared_ptr<CodesRepository> CodesRepository::Create(
	Utilities::SimpleSharkByte& highestActiveCodeSeveritySharkByte)
{
	return std::make_shared<CodesRepository>(highestActiveCodeSeveritySharkByte);
}
CodesRepository::CodesRepository(Utilities::SimpleSharkByte& highestActiveAnnunciationRequirementSharkByte)
	: m_highestActiveAnnunciationRequirementSharkByte{highestActiveAnnunciationRequirementSharkByte}
{
	m_highestActiveAnnunciationRequirementSharkByte.SetValue({{n_noAnnunciationRequirementValue}});
}

void CodesRepository::OnCodeUpdate(std::unique_ptr<ICode>&& spCode)
{
	assert(spCode);
	std::lock_guard<Utilities::mutex> lock{m_mutex};

	ProcessCode(std::move(spCode));
	ProcessHighestActiveCodeAnnunciationRequirement();
}
Utilities::nice_ptr<ICode const> CodesRepository::GetCode(uint64_t uniqueKey) const
{
	std::lock_guard<Utilities::mutex> lock{m_mutex};
	Utilities::nice_ptr<ICode const> result = nullptr;

	auto const itEnd = m_codeList.end();
	auto itFound = std::find_if(m_codeList.begin(), itEnd,
		[uniqueKey](std::unique_ptr<ICode> const& spListCode)
		{
			return spListCode->UniqueKey() == uniqueKey;
		});

	if (itFound != itEnd)
	{
		result = itFound->get();
	}
	return result;
}
std::vector<uint8_t> const CodesRepository::SerializeCodeList() const
{
	std::lock_guard<Utilities::mutex> lock{m_mutex};

	cat::middleware::diagnostics::Codes protobufCodes{};
	for (auto const& spCode : m_codeList)
	{
		*protobufCodes.add_codes() = spCode->ProtobufCode();
	}
	auto const serializedCodes = SerializeCodes(protobufCodes);
	LOG_DEBUG_TAG(Log::Diagnostics, DumpCodes("Code List Update: ", protobufCodes));
	return serializedCodes;
}
void CodesRepository::ProcessCode(std::unique_ptr<ICode>&& spCode)
{
	assert(m_mutex.IsLockedByCaller());

	char const* pLogString{};
	auto const codeStatus = spCode->CodeStatus();
	auto const uniqueKey = spCode->UniqueKey();
	auto const itEnd = m_codeList.end();
	auto itFound = std::find_if(
		m_codeList.begin(),
		itEnd,
		[uniqueKey](std::unique_ptr<ICode> const& spListCode) { return spListCode->UniqueKey() == uniqueKey; });
	if (itFound == itEnd)
	{
		assert(codeStatus != cat::middleware::diagnostics::CodeStatus::CODE_STATUS_NONE);
		m_codeList.emplace_back(std::move(spCode));
		pLogString = "added";
	}
	else if (codeStatus == cat::middleware::diagnostics::CodeStatus::CODE_STATUS_NONE)
	{
		m_codeList.erase(itFound);
		pLogString = "removed";
	}
	else
	{
		*itFound   = std::move(spCode);
		pLogString = "updated";
	}

	assert(pLogString);
	LOG_DEBUG_TAG(
		Log::Diagnostics,
		"CodesSharkByte: Code " << pLogString << ": 0x" << std::uppercase << std::hex << std::setfill('0')
								<< std::setw(16) << uniqueKey);
}
void CodesRepository::ProcessHighestActiveCodeAnnunciationRequirement()
{
	auto highestActiveAnnunciationRequirement = n_noAnnunciationRequirementValue;
	for (auto const& spCode : m_codeList)
	{
		auto const codeStatus = spCode->CodeStatus();
		if (codeStatus == cat::middleware::diagnostics::CODE_STATUS_ACTIVE_ONLY ||
			codeStatus == cat::middleware::diagnostics::CODE_STATUS_ACTIVE_AND_LOGGED)
		{
			auto const annunciationRequirement = spCode->AnnunciationRequirement();
			if (annunciationRequirement > highestActiveAnnunciationRequirement)
			{
				highestActiveAnnunciationRequirement = annunciationRequirement;
			}
		}
	}
	m_highestActiveAnnunciationRequirementSharkByte.SetValue({{Utilities::narrow_cast<uint8_t>(highestActiveAnnunciationRequirement)}});
}
}
}