/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See InternalCode.h

#include "InternalCode.h"
#include "IInternalCodesWrapper.h"
#include "Log.h"
#include "Utilities/CountOf.h"
#include "Utilities/ToUnderlying.h"

using Utilities::ToUnderlying;
using namespace std::chrono_literals;

namespace ConversionsDetail
{
namespace
{
using namespace Shark::Diagnostics;
constexpr char const* const n_stateIdToString[]
{
	"Initialized",
	"Ready",
	"Unknown",
	"Active",
	"Inactive",
	"ActiveConfirmed",
	"InactiveConfirmed",
};
static_assert(Utilities::CountOf(n_stateIdToString) == ToUnderlying(InternalCodeStateId::Count), "Size mismatch");
}

template <>
std::string Converter<std::string, InternalCodeStateId>::Convert(InternalCodeStateId const& id)
{
	assert(id < InternalCodeStateId::Count);
	return n_stateIdToString[ToUnderlying(id)];
}
}

namespace Shark
{
namespace Diagnostics
{
InternalCode::InternalCode(
	IInternalCodesWrapper& internalCodesWrapper,
	SharkUtilities::IEventCallbackFactory& eventCallbackFactory)
	: m_internalCodesWrapper(internalCodesWrapper)
	, m_eventCallbackFactory(eventCallbackFactory)
{
}
void InternalCode::SetStates(std::vector<std::unique_ptr<IInternalCodeState>>&& states)
{
	assert(m_states.empty());
	assert(states.size() == ToUnderlying(InternalCodeStateId::Count));

	m_states = std::move(states);
}
void InternalCode::Initialize(ISharkByte& testSharkByte, scl_obd_test_handle_t testHandle)
{
	assert(!m_spCurrentState);
	m_spTestSharkByte = &testSharkByte;
	m_testHandle = testHandle;

	m_spCurrentState = m_states[ToUnderlying(InternalCodeStateId::Initialized)].get();
	m_spCurrentState->Enter();
	LOG_INFO_LOW_TAG(Log::Diagnostics, "Diagnostic Handle: " << m_testHandle << " Initialized!");
}
void InternalCode::StartTimer(std::chrono::seconds delayTime)
{
	std::chrono::milliseconds delayTimeInMilliseconds = delayTime;
	// Timed callback factory will not accept 0ms.  Adjust to 1 ms.
	if (delayTimeInMilliseconds == 0ms)
	{
		delayTimeInMilliseconds = 1ms;
	}
	auto id = m_spCurrentState->Id();
	m_spTimedCallback = m_eventCallbackFactory.CreateTimedCallbackThatFiresIn(
		delayTimeInMilliseconds,
		[this, id]
		{
			std::unique_lock<std::recursive_mutex> lock{m_mutex};
			if (id == m_spCurrentState->Id())
			{
				ChangeState(m_spCurrentState->TimerExpired());
			}
		});
}
void InternalCode::KillTimer()
{
	m_spTimedCallback.reset();
}
namespace
{
std::optional<bool> GetTestResult(SharkByteValue const& statusValue)
{
	std::optional<bool> testResult{};
	if (statusValue)
	{
		assert(statusValue->size() > 0);
		testResult = (*statusValue)[0];
	}
	return testResult;
}
}
void InternalCode::StartTestMonitor()
{
	assert(!m_testSubscription.IsConnected());

	m_testSubscription = m_spTestSharkByte->SubscribeToValues(
		[this](SharkByteValue const& statusValue)
		{
			auto testResult = GetTestResult(statusValue);
			std::unique_lock<std::recursive_mutex> lock{m_mutex};
			ChangeState(m_spCurrentState->TestStateChanged(testResult));
		});
}
void InternalCode::SetTestStatus(std::optional<bool> testStatus)
{
	m_internalCodesWrapper.SetTestStatus(m_testHandle, testStatus);
}
void InternalCode::ChangeState(InternalCodeStateId id)
{
	auto const pNewState = m_states[ToUnderlying(id)].get();
	if (pNewState != m_spCurrentState.get())
	{
		LOG_INFO_LOW_TAG(Log::Diagnostics, "Diagnostic Handle: " << m_testHandle <<
			" changing from " << To<std::string>(m_spCurrentState->Id()) << " to " << To<std::string>(id));

		m_spCurrentState = pNewState;
		m_spCurrentState->Enter();
	}
}
}
}
