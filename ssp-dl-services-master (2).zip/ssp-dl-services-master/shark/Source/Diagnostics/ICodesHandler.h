/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Codes Handler Interface

#pragma once

#include "ICode.h"
#include "Diagnostics/CodeDefinitions.h"
#include <Config/J1939Address.h>
#include <memory>
#include <vector>

namespace Shark
{
namespace Diagnostics
{
class ICodesHandler
{
public:
	virtual ~ICodesHandler() = default;

	/// May take ownership of the code
	virtual void OnCodeUpdate(std::unique_ptr<ICode>&& spCode) = 0;
};
}
}
