/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Internal Codes Wrapper

#pragma once

#include "IInternalCodesWrapper.h"
#include "InternalCode.h"
#include <SharkConfiguration.pb.h>
#include <Utilities/nice_ptr.h>
#include <scl_obd_handle_gen.h>

namespace Shark
{
class DependencyContainer;
namespace J1939 { class IJ1939Wrapper; }

namespace Diagnostics
{
using InternalCodeConfig = cat::shark::Diagnostics::InternalCodeList::InternalCode;

struct InternalCodeData
{
	scl_obd_es_test_config_t testConfig;
	scl_eddt_fault_config_t faultConfig;
	ISharkByte& statusSharkByte;
};
struct InternalCodesConfigData
{
	scl_obd_es_config_t obdEsConfig;
	scl_diag_pj1939_config_t eddtConfig;
	std::vector<InternalCodeData> internalCodeData;
};
class InternalCodesConfiguration
{
public:
	InternalCodesConfiguration(
		ISharkByteRetriever const& sharkByteRetriever,
		std::vector<InternalCodeConfig> const& internalCodes,
		NVM_block_handle_t* pNvmBlockHandle);
	scl_obd_es_config_t const& GetObdEsConfig() const { return m_internalCodesConfigData.obdEsConfig; }
	scl_diag_pj1939_config_t const& GetEddtConfig() const { return m_internalCodesConfigData.eddtConfig; }
	std::vector<InternalCodeData> const& GetInternalCodeData() const { return m_internalCodesConfigData.internalCodeData; }
private:
	InternalCodesConfigData m_internalCodesConfigData;
};

class InternalCodesWrapper final : public IInternalCodesWrapper
{
public:
	static std::shared_ptr<InternalCodesWrapper> Create(DependencyContainer const& dependencyContainer);

	static void AddPeriodicTask(IPeriodicTaskManager& periodicTaskManager, InternalCodesWrapper& internalCodesWrapper);
	InternalCodesWrapper(J1939::IJ1939Wrapper& j1939Wrapper, unsigned internalCodesNvmDataId) noexcept;
	void SetDependencies(
		std::vector<InternalCodeConfig>&& internalCodeEntries,
		std::vector<std::unique_ptr<IInternalCode>>&& internalCodes);
// IInternalCodesWrapper
	void Initialize(ISharkByteRetriever const& sharkByteRetriever, Nvm::ISclNvmWrapper& sclNvmWrapper) override;
	Utilities::nice_ptr<scl_obd_es_t> GetObdEsInstance() const override;
	Utilities::nice_ptr<scl_diag_pj1939_t> GetEddtInstance() const override;
	void SetTestStatus(scl_obd_test_handle_t testHandle, std::optional<bool> testStatus) override;
	bool GetActiveStatus(ActivatableDataLinkHealthDiagnostics diagnostic) override;
	void ReportStatus(ActivatableDataLinkHealthDiagnostics, bool) override {};
private:
	scl_obd_test_handle_t ConfigureSclCode(
		scl_obd_handle_gen_t* pHandleGenerator,
		scl_obd_es_test_config_t const& testConfig,
		scl_eddt_fault_config_t const& faultConfig);
	void Update();

	J1939::IJ1939Wrapper& m_j1939Wrapper;
	unsigned const m_internalCodesNvmDataId;
	std::unique_ptr<InternalCodesConfiguration const> m_spInternalCodesConfiguration{};
	Utilities::nice_ptr<scl_obd_es_t> m_spObdEsInstance{};
	Utilities::nice_ptr<scl_diag_pj1939_t> m_spEddtInstance{};
	std::vector<InternalCodeConfig> m_internalCodeEntries{};
	std::vector<std::unique_ptr<IInternalCode>> m_internalCodes{};
	std::array<std::optional<scl_obd_test_handle_t>, Utilities::ToUnderlying(ActivatableDataLinkHealthDiagnosticsCount)> m_healthHandles{};
};
}
}