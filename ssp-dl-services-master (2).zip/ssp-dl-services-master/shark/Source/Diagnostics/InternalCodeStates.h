/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Internal Code states

#pragma once

#include "IInternalCode.h"
#include "Utilities/CommonExceptions.h"
#include "Utilities/ToUnderlying.h"
#include <array>
#include <chrono>
#include <optional>

namespace Shark
{
namespace Diagnostics
{
enum class InternalCodeStateId : unsigned
{
	Initialized,
	Ready,
	Unknown,
	Active,
	Inactive,
	ActiveConfirmed,
	InactiveConfirmed,

	Count
};

class IInternalCodeState
{
public:
	virtual ~IInternalCodeState() = default;

	virtual InternalCodeStateId Id() const = 0;
	virtual void Enter() = 0;
	virtual InternalCodeStateId TimerExpired() = 0;
	virtual InternalCodeStateId TestStateChanged(std::optional<bool> testState) = 0;
};

class InternalCodeStateBase : public IInternalCodeState
{
public:
	enum class DestinationId : unsigned
	{
		Invalid,
		True,
		False,

		Count
	};
	using TestStateChangedDestinations = std::array<InternalCodeStateId, Utilities::ToUnderlying(DestinationId::Count)>;

// IInternalCodeState
	InternalCodeStateId Id() const override final { return m_id; }
	void Enter() override {};
	InternalCodeStateId TimerExpired() override { throw Utilities::NotImplemented(); }
	InternalCodeStateId TestStateChanged(std::optional<bool>) override;
protected:
	InternalCodeStateBase(InternalCodeStateId id, IInternalCode& internalCode, TestStateChangedDestinations const& destinations);
	IInternalCode& InternalCode() { return m_internalCode; }
private:
	InternalCodeStateId const m_id;
	IInternalCode& m_internalCode;
	TestStateChangedDestinations const m_destinations;
};

class InternalCodeTimingStateBase : public InternalCodeStateBase
{
public:
// IInternalCodeState
	void Enter() override { InternalCode().StartTimer(m_delayTime); }
	InternalCodeStateId TestStateChanged(std::optional<bool>) override;
protected:
	InternalCodeTimingStateBase(
		InternalCodeStateId id,
		IInternalCode& internalCode,
		TestStateChangedDestinations const& destinations,
		std::chrono::seconds delayTime);
private:
	std::chrono::seconds const m_delayTime;
};

class InitializedState final : public InternalCodeTimingStateBase
{
public:
	InitializedState(IInternalCode& internalCode, std::chrono::seconds startupDelay)
		: InternalCodeTimingStateBase(
			InternalCodeStateId::Initialized,
			internalCode,
			{},
			startupDelay)
	{}
// InternalCodeStateBase
	InternalCodeStateId TimerExpired() override { return InternalCodeStateId::Ready; }
	InternalCodeStateId TestStateChanged(std::optional<bool>) override { throw Utilities::NotImplemented(); }
};

class ReadyState final : public InternalCodeStateBase
{
public:
	ReadyState(IInternalCode& internalCode)
		: InternalCodeStateBase(
			InternalCodeStateId::Ready,
			internalCode,
			{InternalCodeStateId::Unknown, InternalCodeStateId::Active, InternalCodeStateId::Inactive})
	{}
// InternalCodeStateBase
	void Enter() override { InternalCode().StartTestMonitor(); }
};

class UnknownState final : public InternalCodeStateBase
{
public:
	UnknownState(IInternalCode& internalCode)
		: InternalCodeStateBase(
			InternalCodeStateId::Unknown,
			internalCode,
			{InternalCodeStateId::Unknown, InternalCodeStateId::Active, InternalCodeStateId::Inactive})
	{}
// InternalCodeStateBase
	void Enter() override { InternalCode().SetTestStatus(std::nullopt); }
};

class ActiveState final : public InternalCodeTimingStateBase
{
public:
	ActiveState(IInternalCode& internalCode, std::chrono::seconds activationDelay)
		: InternalCodeTimingStateBase(
			InternalCodeStateId::Active,
			internalCode,
			{InternalCodeStateId::Unknown, InternalCodeStateId::Active, InternalCodeStateId::Inactive},
			activationDelay)
	{}
// InternalCodeStateBase
	InternalCodeStateId TimerExpired() override { return InternalCodeStateId::ActiveConfirmed; }
};

class InactiveState final : public InternalCodeTimingStateBase
{
public:
	InactiveState(IInternalCode& internalCode, std::chrono::seconds deactivationDelay)
		: InternalCodeTimingStateBase(
			InternalCodeStateId::Inactive,
			internalCode,
			{InternalCodeStateId::Unknown, InternalCodeStateId::Active, InternalCodeStateId::Inactive},
			deactivationDelay)
	{}
// InternalCodeStateBase
	InternalCodeStateId TimerExpired() override { return InternalCodeStateId::InactiveConfirmed; }
};

class ActiveConfirmedState final : public InternalCodeStateBase
{
public:
	ActiveConfirmedState(IInternalCode& internalCode)
		: InternalCodeStateBase(
			InternalCodeStateId::ActiveConfirmed,
			internalCode,
			{InternalCodeStateId::Unknown, InternalCodeStateId::ActiveConfirmed, InternalCodeStateId::Inactive})
	{}
// InternalCodeStateBase
	void Enter() override { InternalCode().SetTestStatus(true); }
};
class InactiveConfirmedState final : public InternalCodeStateBase
{
public:
	InactiveConfirmedState(IInternalCode& internalCode)
		: InternalCodeStateBase(
			InternalCodeStateId::InactiveConfirmed,
			internalCode,
			{InternalCodeStateId::Unknown, InternalCodeStateId::Active, InternalCodeStateId::InactiveConfirmed})
	{}
// InternalCodeStateBase
	void Enter() override { InternalCode().SetTestStatus(false); }
};
}
}
