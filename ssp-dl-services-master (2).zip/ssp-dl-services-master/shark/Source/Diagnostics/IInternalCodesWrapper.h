/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Internal Codes Wrapper Interface

#pragma once

#include "Nvm/ISclNvmWrapper.h"
#include "Shark/ISharkByteRetriever.h"
#include "Utilities/DefineExceptionClass.h"
#include "Utilities/nice_ptr.h"
#include <scl_obd_es.h>
#include <scl_diag_pj1939.h>
#include <optional>

namespace Shark
{
namespace Diagnostics
{
enum ActivatableDataLinkHealthDiagnostics : unsigned
{
	J1939NoCommunicationDiagnostic,
	J1939ConfigurationErrorDiagnostic,
	EthernetLink1NoCommunicationDiagnostic,
	EthernetLink1ConfigurationErrorDiagnostic,

	ActivatableDataLinkHealthDiagnosticsCount
};
class IInternalCodesWrapper
{
public:
	virtual ~IInternalCodesWrapper() = default;

	DEFINE_EXCEPTION_CLASS(Error);

	/// \exception IInternalCodesWrapper::Error
	///		Thrown when an unrecoverable error occurs in the scl_obd_es or scl_diag_pj1939 libraries
	virtual void Initialize(ISharkByteRetriever const& sharkByteRetriever, Nvm::ISclNvmWrapper& sclNvmWrapper) = 0;

	virtual Utilities::nice_ptr<scl_obd_es_t> GetObdEsInstance() const = 0;
	virtual Utilities::nice_ptr<scl_diag_pj1939_t> GetEddtInstance() const = 0;

	virtual void SetTestStatus(scl_obd_test_handle_t testHandle, std::optional<bool> testStatus) = 0;

	virtual bool GetActiveStatus(ActivatableDataLinkHealthDiagnostics diagnostic) = 0;
	virtual void ReportStatus(ActivatableDataLinkHealthDiagnostics diagnostic, bool isFailed) = 0;
};
}
}