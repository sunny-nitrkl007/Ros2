/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See CodesManager.h

#include "CodesManager.h"
#include "Code.h"
#include "CodesRepository.h"
#include "CodesSharkByte.h"
#include "CodesWrapper.h"
#include "DependencyContainer.h"
#include "ICodeFactory.h"
#include "ICodesHandler.h"
#include "InternalCodesWrapper.h"
#include "Log.h"
#include "SclCodeHelpers.h"
#include "SharkByteDetails.h"
#include "SharkBytes/AsynchronousValueWriteSlot.h"
#include "SharkBytes/ISharkByteManager.h"
#include "SharkBytes/IWriteSharkByteManager.h"
#include "Utilities/ArrayToHexString.h"
#include <Utilities/SharkBytes/SharkByteReferenceWrapper.h>
#include <Utilities/SharkBytes/SimpleSharkByte.h>
#include <memory>

using namespace Shark::Diagnostics;

namespace Shark
{
namespace Diagnostics
{
namespace
{
class CodeFactory final : public ICodeFactory
{
public:
	// ICodeFactory
	std::unique_ptr<ICode> CreateCode(
		Config::CanPort canPort,
		Config::J1939Address address,
		bool isOwnCode,
		scl_dcm_db_fault_s const &sclCode) override;
};
std::unique_ptr<ICode> CodeFactory::CreateCode(
	Config::CanPort canPort,
	Config::J1939Address address,
	bool isOwnCode,
	scl_dcm_db_fault_s const &sclCode)
{
	return std::make_unique<Code>(canPort, address, isOwnCode, sclCode);
}

bool IsSupportedEddtCodeType(scl_dcm_tbl_code_type_t sclCodeType)
{
	return sclCodeType == SCL_DCM_DIAG_CODE ||
		   sclCodeType == SCL_DCM_EVENT_CODE;
}
bool IsSupportedPublicCodeType(scl_dcm_tbl_code_type_t sclCodeType)
{
	return sclCodeType == SCL_DCM_SPN_DM1_CODE ||
	       sclCodeType == SCL_DCM_SPN_DM2_CODE;
}
bool IsSupported(scl_dcm_tbl_code_type_t sclCodeType)
{
	return IsSupportedEddtCodeType(sclCodeType) || IsSupportedPublicCodeType(sclCodeType);
}
Utilities::nice_ptr<CodesManager> n_spCodesManager{};
}

bool CodesManager::ShouldBeCreated(DependencyContainer const& dependencyContainer)
{
	return dependencyContainer.GetSharkConfig().has_diagnostics();
}
std::function<void()> CodesManager::CreateInitializer(DependencyContainer const &dependencyContainer)
{
	auto spInternalCodesWrapper = InternalCodesWrapper::Create(dependencyContainer);

	auto spHighestActiveAnnunciationRequirementSharkByte =
		std::make_unique<Utilities::SimpleSharkByte>(SharkByteDetails::DiagnosticCodes::HighestActiveAnnunciationRequirementSharkByteId());
	auto spCodesRepository = CodesRepository::Create(*spHighestActiveAnnunciationRequirementSharkByte);
	auto spCodesSharkByte = CodesSharkByte::Create(*spCodesRepository);
	auto spCodesSharkByteReferenceWrapper = std::make_unique<Utilities::SharkByteReferenceWrapper>(
		spCodesSharkByte->Id(),
		*spCodesSharkByte);
	auto spAdditionalInformationResponseSharkByte =
		std::make_unique<Utilities::SimpleSharkByte>(SharkByteDetails::DiagnosticCodes::AdditionalInformationResponseSharkByteId());

	auto spCodesManager = std::make_shared<CodesManager>(
		std::make_unique<CodeFactory>(),
		std::move(spCodesSharkByte),
		*spAdditionalInformationResponseSharkByte,
		*spCodesRepository);

	dependencyContainer.GetISharkByteManager().AddSharkBytes(
		std::move(spCodesSharkByteReferenceWrapper),
		std::move(spHighestActiveAnnunciationRequirementSharkByte),
		std::move(spAdditionalInformationResponseSharkByte));

	auto spCodesWrapper = CodesWrapper::Create(
		dependencyContainer,
		*spInternalCodesWrapper,
		*spCodesManager);

	spCodesManager->SetDependencies(*spCodesWrapper);

	auto spAdditionalInformationRequestSharkByte = std::make_unique<SharkBytes::AsynchronousValueWriteSlot>(
		SharkByteDetails::DiagnosticCodes::AdditionalInformationRequestSharkByteId(),
		[spCodesManager](std::vector<uint8_t> const& value, IWriteSharkByte::CompletedCallback const& completedCallback)
		{
			assert(spCodesManager);
			spCodesManager->RequestAdditionalInformation(value, completedCallback);
		});

	dependencyContainer.GetIWriteSharkByteManager().AddWriteSharkByte(std::move(spAdditionalInformationRequestSharkByte));

	return [spInternalCodesWrapper, spCodesWrapper, spCodesRepository, &dependencyContainer, spCodesManager]
	{
		if (spInternalCodesWrapper)
		{
			spInternalCodesWrapper->Initialize(
				dependencyContainer.GetISharkByteRetriever(),
				dependencyContainer.GetISclNvmWrapper());
		}
		spCodesWrapper->Initialize();
		spCodesManager->Initialize();
	};
}

CodesManager::CodesManager(
	std::unique_ptr<ICodeFactory>&& spCodeFactory,
	std::unique_ptr<ICodesHandler>&& spCodesHandler,
	Utilities::SimpleSharkByte& additionalInformationResponseSharkByte,
	ICodesRepository& codesRepository) noexcept
	: m_spCodeFactory{std::move(spCodeFactory)}
	, m_spCodesHandler{std::move(spCodesHandler)}
	, m_additionalInformationResponseSharkByte{additionalInformationResponseSharkByte}
	, m_codesRepository{codesRepository}
{
	assert(m_spCodeFactory);
	assert(m_spCodesHandler);

	assert(!n_spCodesManager);
	n_spCodesManager = this;
}
CodesManager::~CodesManager()
{
	assert(n_spCodesManager);
	n_spCodesManager.reset();
}
void CodesManager::RequestAdditionalInformation(
	std::vector<uint8_t> const& value,
	IWriteSharkByte::CompletedCallback const& completedCallback)
{
	assert(value.size() == 8);
	uint64_t uniqueId = 0;
	std::memcpy(&uniqueId, value.data(), sizeof(uint64_t));
	LOG_DEBUG_TAG(Log::Diagnostics, "Additional Info requested for id " << std::hex << std::uppercase << uniqueId);
	auto const& spCode = m_codesRepository.GetCode(uniqueId);
	if (spCode)
	{
		auto const& uniqueKeyData = spCode->UniqueKey();
		m_spCodesWrapper->RequestAdditionalInformation(uniqueKeyData);
	}
	else
	{
		assert(n_spCodesManager);
		n_spCodesManager->OnAdditionalInformation(uniqueId, {});
	}
	completedCallback(std::nullopt);
}
void CodesManager::SetDependencies(ICodesWrapper& codesWrapper)
{
	m_spCodesWrapper = &codesWrapper;
}
void CodesManager::Initialize()
{
	assert(m_spCodesWrapper);
	m_spCodesWrapper->RegisterAdditionalInformationCallback(
		[this](
			UniqueKeyData const uniqueKey,
			std::vector<uint8_t> const& data)
		{
			this->OnAdditionalInformation(uniqueKey, data);
		});
}
void CodesManager::OnCodeUpdate(
	Config::CanPort canPort,
	Config::J1939Address address,
	bool isOwnCode,
	scl_dcm_db_fault_s const &sclCode,
	scl_dcm_tbl_status_t tableStatus)
{
	auto const codeType = sclCode.code_type;
	LOG_DEBUG_TAG(Log::Diagnostics, "Code update for " << address << " code type " << SclCodeType{codeType}
		<< "\n  Code: " << sclCode.code << "-" << GetFaultFmi(sclCode) << "-" <<
		GetFaultWci(sclCode) << " Status: " << SclTableStatus{tableStatus});

	if (IsSupported(codeType))
	{
		if (tableStatus == SCL_DCM_FAULT_ADDED || tableStatus == SCL_DCM_FAULT_UPDATED || tableStatus == SCL_DCM_FAULT_DELETED)
		{
			scl_dcm_db_fault_s modifiedSclCode; // This is initialized when it is used
			Utilities::nice_ptr<scl_dcm_db_fault_s const> spSclCodeToForward = &sclCode;
			if (tableStatus == SCL_DCM_FAULT_DELETED)
			{
				modifiedSclCode = sclCode;
				modifiedSclCode.status = SCL_DCLI_FAULT_NOT_ACTIVE;
				spSclCodeToForward = &modifiedSclCode;
			}

			m_spCodesHandler->OnCodeUpdate(m_spCodeFactory->CreateCode(canPort, address, isOwnCode, *spSclCodeToForward));
		}
	}
}
void CodesManager::OnAdditionalInformation(
	UniqueKeyData const uniqueKey,
	std::vector<uint8_t> const& data)
{
	std::vector<uint8_t> responseData(sizeof(uint64_t) + data.size());
	std::memcpy(responseData.data(), &uniqueKey, sizeof(uint64_t));
	if (data.size() > 0)
	{
		LOG_DEBUG_TAG(Log::Diagnostics, "Additional Info response for id " << std::hex << std::uppercase << uniqueKey <<
			" Data: " << Utilities::ArrayToHexString(data.data(), static_cast<unsigned>(data.size())));
		std::memcpy(responseData.data() + sizeof(uint64_t), data.data(), data.size());
	}
	else
	{
		LOG_DEBUG_TAG(Log::Diagnostics, "Additional Info response for id " << std::hex << std::uppercase << uniqueKey << " No Data");
	}

	LOG_DEBUG_TAG(Log::Diagnostics, "AI response = " << std::hex << std::uppercase <<
		Utilities::ArrayToHexString(responseData.data(), static_cast<unsigned>(responseData.size())));
	m_additionalInformationResponseSharkByte.SetInvalidThenSetValue(responseData);
}
}
}