/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Code Interface

#pragma once

#include "UniqueKeyData.h"
#include "middleware_diagnostics.pb.h"

namespace Shark
{
namespace Diagnostics
{
class ICode
{
public:
	virtual ~ICode() = default;

	virtual UniqueKeyData const& UniqueKey() const                         = 0;
	virtual cat::middleware::diagnostics::Code const& ProtobufCode() const = 0;
	virtual cat::middleware::diagnostics::CodeStatus CodeStatus() const	   = 0;
	virtual unsigned AnnunciationRequirement() const                       = 0;
};
}
}
