/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Internal Code Interface

#pragma once

#include <chrono>
#include <optional>
#include <scl_obd_es.h>

namespace Shark
{
class ISharkByte;

namespace Diagnostics
{
class IInternalCode
{
public:
	virtual ~IInternalCode() = default;

	virtual void Initialize(ISharkByte& testSharkByte, scl_obd_test_handle_t testHandle) = 0;
	virtual void StartTimer(std::chrono::seconds delayTime) = 0;
	virtual void KillTimer() = 0;
	virtual void StartTestMonitor() = 0;
	virtual void SetTestStatus(std::optional<bool> testStatus) = 0;
};
}
}
