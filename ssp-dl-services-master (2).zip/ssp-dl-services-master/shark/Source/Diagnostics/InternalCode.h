/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Internal Code

#pragma once

#include "IInternalCode.h"
#include "InternalCodeStates.h"
#include "Shark/ISharkByte.h"
#include "SharkUtilities/IEventCallbackFactory.h"
#include "Utilities/nice_ptr.h"
#include <memory>
#include <mutex>
#include <scl_diag_pj1939.h>

namespace Shark
{
namespace Diagnostics
{
class IInternalCodesWrapper;

class InternalCode final : public IInternalCode
{
public:
	InternalCode(
		IInternalCodesWrapper& internalCodesWrapper,
		SharkUtilities::IEventCallbackFactory& eventCallbackFactory);
	void SetStates(std::vector<std::unique_ptr<IInternalCodeState>>&& states);
// IInternalCode
	void Initialize(ISharkByte& testSharkByte, scl_obd_test_handle_t testHandle) override;
	void StartTimer(std::chrono::seconds delayTime) override;
	void KillTimer() override;
	void StartTestMonitor() override;
	void SetTestStatus(std::optional<bool> testStatus) override;
private:
	void ChangeState(InternalCodeStateId id);

	std::vector<std::unique_ptr<IInternalCodeState>> m_states{};
	Utilities::nice_ptr<IInternalCodeState> m_spCurrentState{};
	scl_obd_test_handle_t m_testHandle{SCL_OBD_TEST_HANDLE_INVALID};
	SharkByteSubscription m_testSubscription{};
	std::unique_ptr<SharkUtilities::ITimedCallback> m_spTimedCallback{};
	Utilities::nice_ptr<ISharkByte> m_spTestSharkByte{};
	std::recursive_mutex m_mutex{};

	IInternalCodesWrapper& m_internalCodesWrapper;
	SharkUtilities::IEventCallbackFactory& m_eventCallbackFactory;
};
}
}
