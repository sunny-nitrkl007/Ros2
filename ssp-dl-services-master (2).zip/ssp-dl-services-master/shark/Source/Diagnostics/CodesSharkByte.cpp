/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See CodesSharkByte.h

#include "CodesSharkByte.h"
#include "CodesRepository.h"
#include "SharkByteDetails.h"
#include <cassert>

namespace Shark
{
namespace Diagnostics
{
std::unique_ptr<CodesSharkByte> CodesSharkByte::Create(
	ICodesRepository& codesRepository)
{
	return std::make_unique<CodesSharkByte>(
		SharkByteDetails::DiagnosticCodes::CodesSharkByteId(),
		codesRepository);
}
CodesSharkByte::CodesSharkByte(
	SharkByteId&& id,
	ICodesRepository& codesRepository)
	: m_id{std::move(id)}
	, m_codesRepository{codesRepository}
{
}
std::string CodesSharkByte::Describe() const
{
	return Id();
}
SharkByteSubscription CodesSharkByte::SubscribeToValues(boost::function<void(SharkByteValue const&)> const& callback)
{
	std::lock_guard<Utilities::mutex> lock{m_mutex};

	callback(m_currentCodeList);

	return m_signal.connect(callback);
}
void CodesSharkByte::OnCodeUpdate(std::unique_ptr<ICode>&& spCode)
{
	assert(spCode);
	std::lock_guard<Utilities::mutex> lock{m_mutex};
	m_codesRepository.OnCodeUpdate(std::move(spCode));
	SendCodes();
}
void CodesSharkByte::SendCodes()
{
	assert(m_mutex.IsLockedByCaller());
	auto const serializedCodes = m_codesRepository.SerializeCodeList();
	if ((serializedCodes.size() != m_currentCodeList.size()) ||
		std::memcmp(serializedCodes.data(), m_currentCodeList.data(), serializedCodes.size()) != 0)
	{
		m_currentCodeList = serializedCodes;
		m_signal(m_currentCodeList);
	}
}
}
}