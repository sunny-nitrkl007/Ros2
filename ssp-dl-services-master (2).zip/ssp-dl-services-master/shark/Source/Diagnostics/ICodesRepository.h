/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Codes Repository Interface

#pragma once

#include "ICode.h"

namespace Shark
{
namespace Diagnostics
{
class ICodesRepository
{
public:
	virtual ~ICodesRepository() = default;

	virtual void OnCodeUpdate(std::unique_ptr<ICode>&& spCode) = 0;
	virtual Utilities::nice_ptr<ICode const> GetCode(uint64_t uniqueKey) const = 0;
	virtual std::vector<uint8_t> const SerializeCodeList() const = 0;
};
}
}
