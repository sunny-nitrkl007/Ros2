/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Codes Wrapper Interface

#pragma once

#include "Diagnostics/CodeDefinitions.h"
#include "UniqueKeyData.h"
#include <Utilities/DefineExceptionClass.h>
#include <vector>

namespace Shark
{
namespace Diagnostics
{
class ICodesWrapper
{
public:
	virtual ~ICodesWrapper() = default;

	DEFINE_EXCEPTION_CLASS(Error);

	/// \exception ICodesWrapper::Error
	///		Thrown when an unrecoverable error occurs in the scl_info library
	using AdditionalInformationCallback = std::function<void(
		UniqueKeyData const uniqueKey,
		std::vector<uint8_t> const& data)>;
	virtual void RegisterAdditionalInformationCallback(AdditionalInformationCallback const& callback) = 0;
	virtual void RequestAdditionalInformation(UniqueKeyData uniqueKey) = 0;
};
}
}