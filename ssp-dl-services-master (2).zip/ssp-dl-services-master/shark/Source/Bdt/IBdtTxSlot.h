/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// BDT Transmit Slot Interface

#pragma once

#include <functional>
#include <vector>

namespace Shark
{
namespace Bdt
{
class IBdtTxSlot
{
public:
	using CompletionCallback = std::function<void(bool succeeded)>;

	virtual ~IBdtTxSlot() = default;

	virtual unsigned GetDataType() const = 0;
	virtual void Configure(std::vector<uint8_t>&& dataToTransmit, CompletionCallback&& completionCallback) = 0;
	virtual unsigned GetSize() const = 0;
	virtual void CopyNextBytesIntoBuffer(uint8_t* pBuffer, unsigned bufferSize) = 0;
	virtual void Completed(bool succeeded) = 0;
};
}
}
