/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See BdtClientWrapper.h

#include "BdtClientWrapper.h"
#include "BdtRxSlot.h"
#include "BdtTxSlot.h"
#include "Config/ProtobufConversions.h"
#include "DataTypes.h"
#include "DependencyContainer.h"
#include "IPeriodicTaskManager.h"
#include "Log.h"
#include "J1939/IJ1939Wrapper.h"
#include "J1939/J1939Definitions.h"
#include "SharkBytes/AsynchronousValueWriteSlot.h"
#include "SharkBytes/ISharkByteManager.h"
#include "SharkBytes/IWriteSharkByteManager.h"
#include "SlotDetail.h"
#include <SharkConfiguration.pb.h>
#include <Utilities/Conversions.h>
#include <Utilities/CountOf.h>
#include <Utilities/narrow_cast.h>
#include <Utilities/nice_ptr.h>
#include <Utilities/SharkBytes/TransientSharkByte.h>
#include <oel_rtos_posix.h>
#include <ranges>

namespace Shark
{
namespace Bdt
{
std::ostream& operator<<(std::ostream& stream, AccessMode accessMode)
{
	static constexpr char const* n_toString[]
	{
		"Transmit",
		"Receive",
	};
	static_assert(Utilities::CountOf(n_toString) == Utilities::ToUnderlying(AccessMode::Count), "");

	auto const index = Utilities::ToUnderlying(accessMode);
	assert(index < Utilities::CountOf(n_toString));
	return stream << n_toString[index];
}

namespace
{
void J1939ErrorHandler(
	void*,
	unsigned_8 type,
	[[maybe_unused]] unsigned_8 sid,
	unsigned_8 did,
	unsigned_16 datatype,
	unsigned_32 index,
	bdt_error_t error)
{
	LOG_ERROR_TAG(Log::Bdt, "J1939 Error: " << Type{type} << ", " << Config::J1939Address{did} << ", " << DataType{datatype}
		<< ", " << DataIndex{index} << ", "<< BdtError{error});
}
/// Should always return BDT_OPEN_SUCCESS for client
unsigned_8 OpenData(unsigned_16 datatype)
{
	LOG_DEBUG_TAG(Log::Bdt, "OpenData(" << DataType{datatype} << ")");
	return BDT_OPEN_SUCCESS;
}

constexpr auto n_maxSimultaneousClients = 1;
// Maximum buffer size when only using J1939 (not CDL or ATA) should/can be set to 1785 from the CSNS BDT specification
constexpr auto n_bufferSize = 1785;
constexpr auto n_j1939MaxConnectionHandlers = 1;
constexpr auto n_callbackBlockClientCount = 1;

constexpr oel_rtos_resource_pi_vconfig_t bdt_j1939_resource_vconfig = OEL_RTOS_RESOURCE_PI_VCONFIG();
constexpr oel_rtos_resource_config_t const* app_bdt_j1939_resource  = OEL_BASE(&bdt_j1939_resource_vconfig);

constexpr auto n_bdtTaskPeriod = TaskPeriod::Is100ms;
// The statistics update hangs sometimes on MWL so we don't want to force an abort
void AddPeriodicTasks(IPeriodicTaskManager& periodicTaskManager, BdtClientWrapper& wrapper)
{
	periodicTaskManager.Add(
		n_bdtTaskPeriod,
		[&wrapper]
		{
			wrapper.UpdateBdt();
		});
}
SlotDetails CreateSlotDetails(cat::shark::Config const& config)
{
	SlotDetails slotDetails{};
	for (auto& entry : config.bdt_entries())
	{
		auto const dataType = entry.type();
		auto spSlotDetail = std::make_unique<SlotDetail>(dataType);
		// For simplicity, we're creating both an Rx and Tx slot for each data type,
		// even though not all data types will necessarily support both directions.
		// Read and Write access will be controlled by shark bytes.
		auto spBdtRxSlot = std::make_unique<BdtRxSlot>(dataType, entry.maximum_byte_count());
		spSlotDetail->SetRxSlot(std::move(spBdtRxSlot));
		auto spBdtTxSlot = std::make_unique<BdtTxSlot>(dataType);
		spSlotDetail->SetTxSlot(std::move(spBdtTxSlot));
		slotDetails.emplace_back(std::move(spSlotDetail));
	}
	return slotDetails;
}
void CreateSharkBytes(
	BdtClientWrapper& bdtClientWrapper, // cppcheck-suppress constParameterReference
	cat::shark::J1939DataLink const& j1939DataLink,
	SharkBytes::ISharkByteManager& sharkByteManager,
	SharkBytes::IWriteSharkByteManager& writeSharkByteManager)
{
	auto const canPort = Config::ToConfigCanPort(j1939DataLink.can_port());
	for (auto& peerNode : j1939DataLink.peer_nodes())
	{
		if (peerNode.has_bdt())
		{
			auto const address = peerNode.address();
			for (auto const& bdtType : peerNode.bdt().bdt_types())
			{
				auto const dataType = bdtType.type();
				auto const dataIndex = bdtType.index();
				auto const id = bdtType.middleware_id();
				auto const accessMode = bdtType.access_mode();
				if (accessMode == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_READ_ONLY ||
				    accessMode == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_READ_WRITE)
				{
					auto spSharkByte = std::make_unique<Utilities::TransientSharkByte>(
						id.c_str(),
						[&wrapper = bdtClientWrapper, canPort, address, dataType, dataIndex](Utilities::TransientSharkByte& sharkByte)
						{
							wrapper.InitiateRead(
								canPort,
								address,
								dataType,
								dataIndex,
								sharkByte);
						});
					sharkByteManager.AddSharkByte(std::move(spSharkByte));
				}
				if (accessMode == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_WRITE_ONLY ||
				    accessMode == cat::shark::J1939DataLink::PeerNode::Bdt::ACCESS_MODE_READ_WRITE)
				{
					auto spWriteSharkByte = std::make_unique<Shark::SharkBytes::AsynchronousValueWriteSlot>(
						id.c_str(),
						[&wrapper = bdtClientWrapper, canPort, address, dataType, dataIndex](auto&& value, auto&& completedCallback)
						{
							wrapper.InitiateWrite(
								canPort,
								address,
								dataType,
								dataIndex,
								std::vector<uint8_t>{value},
								completedCallback);
						});
					writeSharkByteManager.AddWriteSharkByte(std::move(spWriteSharkByte));
				}
			}
		}
	}
}
bool J1939DataLinkConfigHasBdt(cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	auto const& peerNodes = j1939DataLinkConfig.peer_nodes();
	return std::any_of(peerNodes.begin(),peerNodes.end(),
		[](auto const& peerNode)
		{
			return peerNode.has_bdt() && peerNode.bdt().bdt_types().size() > 0;
		});
}
Utilities::nice_ptr<BdtClientWrapper> n_spJ1939BdtClientWrapper;
}

bool BdtClientWrapper::ShouldBeCreated(DependencyContainer const& dependencyContainer)
{
	auto const& configs = dependencyContainer.GetJ1939DataLinkConfigs();
	return std::any_of(configs.begin(), configs.end(),
		[](auto const& spJ1939DataLinkConfig)
		{
			return J1939DataLinkConfigHasBdt(*spJ1939DataLinkConfig);
		});
}
std::function<void()> BdtClientWrapper::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	SlotDetails slotDetails{};
	std::vector<Utilities::nice_ptr<J1939::IJ1939Wrapper>> j1939Wrappers{};
	auto spWrapper = std::make_shared<BdtClientWrapper>();

	slotDetails = CreateSlotDetails(dependencyContainer.GetSharkConfig());

	for (auto spJ1939DataLinkConfig : dependencyContainer.GetJ1939DataLinkConfigs())
	{
		if (J1939DataLinkConfigHasBdt(*spJ1939DataLinkConfig))
		{
			auto const canPort = Config::ToConfigCanPort(spJ1939DataLinkConfig->can_port());
			auto& j1939Wrapper = dependencyContainer.GetIJ1939Wrapper(canPort);
			j1939Wrappers.push_back(&j1939Wrapper);

			CreateSharkBytes(
				*spWrapper,
				*spJ1939DataLinkConfig,
				dependencyContainer.GetISharkByteManager(),
				dependencyContainer.GetIWriteSharkByteManager());
		}
	}
	spWrapper->SetSlotDetails(std::move(slotDetails));
	AddPeriodicTasks(
		dependencyContainer.GetIPeriodicTaskManager(),
		*spWrapper);

	return [spWrapper, j1939Wrappers]()
		{
			spWrapper->Initialize(j1939Wrappers);
		};
}

BdtClientWrapper::BdtClientWrapper()
{
	assert(!n_spJ1939BdtClientWrapper);
	n_spJ1939BdtClientWrapper = this;
}
BdtClientWrapper::~BdtClientWrapper()
{
	assert(n_spJ1939BdtClientWrapper == this);
	n_spJ1939BdtClientWrapper.reset();
}
void BdtClientWrapper::Initialize(std::vector<Utilities::nice_ptr<J1939::IJ1939Wrapper>> const& j1939Wrappers)
{
	if (!bdt_init(n_maxSimultaneousClients, n_bufferSize, n_maxSimultaneousClients, n_bufferSize, static_cast<unsigned_8>(j1939Wrappers.size())))
	{
		throw Error("bdt_init failed!");
	}
	bdt_j1939_set_resource(app_bdt_j1939_resource);

	for (auto const j1939Wrapper : j1939Wrappers)
	{
		auto datalinkHandle = bdt_j1939_init(j1939Wrapper->GetLink());
		if (datalinkHandle == BDT_INVALID_DATALINK)
		{
			throw Error("bdt_j1939_init failed!");
		}
		m_dataLinkHandles[j1939Wrapper->GetCanPort()] = datalinkHandle;
	}
	if (!bdt_set_conn_status_hdlr_max_count(n_j1939MaxConnectionHandlers))
	{
		throw Error("bdt_set_conn_status_hdlr_max_count failed!");
	}
	if (!bdt_set_notify_conn_status_hdlr(nullptr, StaticJ1939ConnectionStatusHandler))
	{
		throw Error("bdt_set_notify_conn_status_hdlr failed!");
	}
	if (!bdt_set_callback_block_count(Utilities::narrow_cast<unsigned_16>(n_callbackBlockClientCount)))
	{
		throw Error("bdt_set_callback_block_count failed!");
	}
	if (!bdt_set_report_error_hdlr(nullptr, J1939ErrorHandler))
	{
		throw Error("bdt_set_report_error_hdlr failed!");
	}
	if (!bdt_set_datatype_count(Utilities::narrow_cast<unsigned_16>(m_slotDetails.size())))
	{
		throw Error("bdt_set_datatype_count failed!");
	}

	if (!m_slotDetails.empty())
	{
		auto const bdtHandle = bdt_set_callback_block(
			StaticQueryIndexSupported,
			StaticObtainDataAccess,
			StaticReleaseDataAccess,
			StaticGetDataSize,
			OpenData,
			StaticCloseData,
			StaticGetData,
			StaticSetData);
		if (bdtHandle == BDT_INVALID_HANDLE)
		{
			throw Error("bdt_set_callback_block failed!");
		}

		for (auto&& dataType : m_slotDetails | std::views::transform([](auto&& spSlotDetail) { return spSlotDetail->GetDataType(); }))
		{
			if (!bdt_set_datatype(Utilities::narrow_cast<unsigned_16>(dataType), bdtHandle))
			{
				throw Error("bdt_set_datatype failed: " + To<std::string>(dataType));
			}
		}
	}

	std::chrono::microseconds const taskPeriodInMicroseconds = TaskPeriodToMilliseconds(n_bdtTaskPeriod);
	bdt_set_period(Utilities::narrow_cast<unsigned>(taskPeriodInMicroseconds.count()));
}
void BdtClientWrapper::UpdateBdt()
{
	std::vector<std::function<void()>> bdtRequestFunctions{};
	{
		std::lock_guard<std::mutex> lock{m_mutex};

		if (!m_bdtRequestFunctions.empty())
		{
			bdtRequestFunctions.swap(m_bdtRequestFunctions);
		}
	}
	for (auto&& bdtRequestFunction : bdtRequestFunctions)
	{
		bdtRequestFunction();
	}
	bdt_main();
}
void BdtClientWrapper::SetSlotDetails(SlotDetails&& slotDetails)
{
	assert(m_slotDetails.empty());
	m_slotDetails = std::move(slotDetails);
}
void BdtClientWrapper::InitiateRead(
	Config::CanPort canPort,
	unsigned address,
	unsigned dataType,
	unsigned index,
	Utilities::TransientSharkByte& sharkByte)
{
	auto&& slotDetail = TryFindSlotDetail(dataType);
	if (!slotDetail)
	{
		throw Error("BDT slot does not exist for data type " + To<std::string>(dataType));
	}

	auto requestConnection =
		[this, canPort, address, dataType, index]() -> bool
		{
			return this->RequestConnection(AccessMode::Receive, canPort, address, dataType, index);
		};
	auto completionCallback =
		[&sharkByte](std::optional<std::vector<uint8_t>>&& data)
		{
			if (data)
			{
				sharkByte.Write(std::move(*data));
			}
			else
			{
				sharkByte.WriteInvalid();
			}
		};
	auto&& requestFunction = (*slotDetail)->InitiateRead(
		std::move(requestConnection),
		std::move(completionCallback));
	if (requestFunction)
	{
		// Success! Queue the request function to be called on the next UpdateBdt() call.
		std::lock_guard<std::mutex> lock{m_mutex};
		m_bdtRequestFunctions.push_back(std::move(*requestFunction));
	}
}
void BdtClientWrapper::InitiateWrite(
	Config::CanPort canPort,
	unsigned address,
	unsigned dataType,
	unsigned index,
	std::vector<uint8_t>&& data,
	IWriteSharkByte::CompletedCallback const& completedCallback)
{
	auto&& slotDetail = TryFindSlotDetail(dataType);
	if (!slotDetail)
	{
		throw Error("BDT slot does not exist for data type " + To<std::string>(dataType));
	}

	std::optional<std::function<void()>> requestFunction{};
	auto requestConnection =
		[this, canPort, address, dataType, index]() -> bool
		{
			return this->RequestConnection(AccessMode::Transmit, canPort, address, dataType, index);
		};
	auto completionCallback =
		[completedCallback](bool succeeded)
		{
			completedCallback(succeeded ? Shark::TrueSharkByteValue() : Shark::FalseSharkByteValue());
		};
	requestFunction = (*slotDetail)->InitiateWrite(
		std::move(requestConnection),
		std::move(data),
		std::move(completionCallback));
	if (requestFunction)
	{
		std::lock_guard<std::mutex> lock{m_mutex};
		m_bdtRequestFunctions.push_back(std::move(*requestFunction));
	}
}

/// Do we support datatype/index combo for a given accessmode?
/// accessmode == BDT_READ_ACCESS == Shark is transmitting
///     TRUE if Shark can transmit datatype/index
/// accessmode == BDT_WRITE_ACCESS == Shark is receiving
///     TRUE if Shark can receive datatype/index
boolean BdtClientWrapper::StaticQueryIndexSupported(unsigned_16 datatype, unsigned_32 index, unsigned_8 accessmode)
{
	auto const accessMode = AccessModeToEnum(accessmode);
	LOG_DEBUG_TAG(Log::Bdt, "QueryIndexSupported(" << DataType{datatype} << ", " << DataIndex{index} << ", " << accessMode << ")");
	auto const result = n_spJ1939BdtClientWrapper->QueryIndexSupported(datatype, index, accessMode);
	LOG_DEBUG_TAG(Log::Bdt, "QueryIndexSupported() returning " << result);
	return result ? TRUE : FALSE;
}
/// Assumes that every index that is requested will be supported
bool BdtClientWrapper::QueryIndexSupported(unsigned dataType, [[maybe_unused]] unsigned dataIndex, AccessMode accessMode)
{
	auto isSupported = false;
	auto const slotDetail = TryFindSlotDetail(dataType);
	if (slotDetail)
	{
		isSupported = (*slotDetail)->IsAccessModeSupported(accessMode);
	}
	return isSupported;
}
/// if transmitting
///		acquire mechanism to read from when requested
/// if receiving
///		acquire mechanism to write to when data received
///
/// always return TRUE, resources are assumed to be good
boolean BdtClientWrapper::StaticObtainDataAccess(unsigned_16 datatype, unsigned_32 index, unsigned_8 accessmode)
{
	auto const accessMode = AccessModeToEnum(accessmode);
	LOG_DEBUG_TAG(Log::Bdt, "ObtainDataAccess(" << DataType{datatype} << ", " << DataIndex{index} << ", " << accessMode << ")");
	n_spJ1939BdtClientWrapper->ObtainDataAccess(datatype, index, accessMode);
	return TRUE;
}
void BdtClientWrapper::ObtainDataAccess(unsigned dataType, [[maybe_unused]] unsigned dataIndex, [[maybe_unused]] AccessMode accessMode)
{
	auto&& spSlotDetail = FindSlotDetail(dataType);
	assert(spSlotDetail->CurrentAccessMode() == accessMode);
	spSlotDetail->ObtainDataAccess();
}
/// Data transfer is complete and data access can be released
void BdtClientWrapper::StaticReleaseDataAccess(unsigned_16 datatype, unsigned_32 index, unsigned_8 accessmode)
{
	LOG_DEBUG_TAG(Log::Bdt, "ReleaseDataAccess(" << DataType{datatype} << ", " << DataIndex{index} << ", "
		<< AccessModeToEnum(accessmode) << ")");
	n_spJ1939BdtClientWrapper->ReleaseDataAccess(datatype);
}
void BdtClientWrapper::ReleaseDataAccess(unsigned dataType)
{
	auto&& spSlotDetail = FindSlotDetail(dataType);
	spSlotDetail->DataAccessReleased();
}
/// Retrieve data size for datatype/index combo
/// accessmode == BDT_READ_ACCESS == Shark is transmitting
///		return size of data to be sent
/// accessmode == BDT_WRITE_ACCESS == Shark is receiving
///		return maximum size for buffer that will receive data
unsigned_32 BdtClientWrapper::StaticGetDataSize(
	unsigned_16 datatype,
	unsigned_32 index,
	unsigned_8 accessmode,
	unsigned_32 requestedsize)
{
	auto const accessMode = AccessModeToEnum(accessmode);
	LOG_DEBUG_TAG(Log::Bdt, "GetDataSize(" << DataType{datatype} << ", " << DataIndex{index} << ", " << accessMode << ", "
		<< std::dec << requestedsize << ")");
	if (accessMode == AccessMode::Receive)
	{
		assert(requestedsize == 0);
	}

	auto const result = n_spJ1939BdtClientWrapper->GetDataSize(datatype, requestedsize);
	LOG_DEBUG_TAG(Log::Bdt, "GetDataSize() returning " << result);
	return result;
}
unsigned BdtClientWrapper::GetDataSize(unsigned dataType, [[maybe_unused]] unsigned requestedsize)
{
	auto const& spSlotDetail = FindSlotDetail(dataType);
	return spSlotDetail->GetDataSize();
}
/// Should always return BDT_CLOSE_SUCCESS for client
unsigned_8 BdtClientWrapper::StaticCloseData(unsigned_16 datatype, boolean complete)
{
	auto completedSuccessfully = (complete != FALSE);
	LOG_DEBUG_TAG(Log::Bdt, "CloseData(" << DataType{datatype} << ", " << completedSuccessfully << ")");
	n_spJ1939BdtClientWrapper->CloseData(datatype, completedSuccessfully);
	return BDT_CLOSE_SUCCESS;
}
void BdtClientWrapper::CloseData(unsigned dataType, bool completedSuccessfully)
{
	auto&& spSlotDetail = FindSlotDetail(dataType);
	spSlotDetail->SetCompletedSuccessfully(completedSuccessfully);
}
/// This is only used for accessmode == BDT_READ_ACCESS == Shark is transmitting
/// This will be called to read then next <size> bytes of <datatype> and write them to <read_data>
/// and then report how many bytes we actually wrote <read_data_size>
unsigned_8 BdtClientWrapper::StaticGetData(
	unsigned_16 datatype,
	unsigned_32 size,
	unsigned_8 *read_data,
	unsigned_32 *read_data_size)
{
	assert(read_data);
	assert(read_data_size);
	LOG_DEBUG_TAG(Log::Bdt, "GetData(" << DataType{datatype} << ", " << std::dec << size << ")");
	n_spJ1939BdtClientWrapper->GetData(datatype, size, read_data);
	*read_data_size = size; // We assume everything was read successfully
	return BDT_READ_OK;
}
void BdtClientWrapper::GetData(unsigned dataType, unsigned dataSize, uint8_t* pData)
{
	auto&& spSlotDetail = FindSlotDetail(dataType);
	spSlotDetail->CopyNextBytesIntoBuffer(pData, dataSize);
}
/// This is only used for accessmode == BDT_WRITE_ACCESS == Shark is receiving
/// This will be called to write the next <size> bytes of <datatype> from <write_data>
/// and then report how many bytes we actually accepted <write_data_size>
unsigned_8 BdtClientWrapper::StaticSetData(
	unsigned_16 datatype,
	unsigned_32 size,
	unsigned_8 write_data[],
	unsigned_32 *write_data_size)
{
	assert(write_data);
	assert(write_data_size);
	LOG_DEBUG_TAG(Log::Bdt, "SetData(" << DataType{datatype} << ", " << std::dec << size << ")");
	n_spJ1939BdtClientWrapper->SetData(datatype, size, write_data);
	*write_data_size = size; // We assume everything was written successfully
	return BDT_WRITE_OK;
}
void BdtClientWrapper::SetData(unsigned dataType, unsigned dataSize, uint8_t const* pData)
{
	auto&& spSlotDetail = FindSlotDetail(dataType);
	spSlotDetail->AppendData(pData, dataSize);
}
void BdtClientWrapper::StaticJ1939ConnectionStatusHandler(
	void*,
	unsigned_8 type,
	unsigned_8 sid,
	unsigned_8 did,
	unsigned_16 datatype,
	unsigned_32 index,
	unsigned_16 status)
{
	LOG_INFO_HIGH_TAG(Log::Bdt, "J1939 Bdt Status: " <<
		"type: "       << Type{type} <<
		", sid: "      << Config::J1939Address{sid} <<
		", did: "      << Config::J1939Address{did} <<
		", datatype: " << DataType{datatype} <<
		", index: "    << index <<
		", status: "   << BdtStatus{status});

	n_spJ1939BdtClientWrapper->ConnectionStatusHandler(datatype, status);
}
void BdtClientWrapper::ConnectionStatusHandler(unsigned dataType, unsigned status)
{
	auto&& spSlotDetail = FindSlotDetail(dataType);
	if (status == BDT_STAT_FAIL || status == BDT_STAT_SUCCESS || status == BDT_STAT_CLOSE_FAIL)
	{
		spSlotDetail->StateMachineFinished();
	}
}
bool BdtClientWrapper::RequestConnection(
	AccessMode accessMode,
	Config::CanPort canPort,
	unsigned address,
	unsigned dataType,
	unsigned index)
{
	assert(m_dataLinkHandles[canPort].has_value());
	bool succeeded{false};
	unsigned_8 const type = (accessMode == AccessMode::Receive) ? BDT_RX : BDT_TX;

	m_bdtApplicationInfo = {};
	LOG_DEBUG_TAG(Log::Bdt, "Requesting J1939 Connection: " << Type{type} << ", "
		<< Config::J1939Address{address} << ", " << DataType{dataType} << ", " << DataIndex{index});
	auto const result = bdt_req_connection(
		type,
		J1939::J1939Definitions::VirtualEcmIndex(),
		Utilities::narrow_cast<unsigned_8>(address),
		Utilities::narrow_cast<unsigned_16>(dataType),
		index,
		0,
		0,
		&m_bdtApplicationInfo,
		*m_dataLinkHandles[canPort],
		0,
		0);
	succeeded = (result == BDT_ERROR_NONE);

	if (!succeeded)
	{
		LOG_WARNING_TAG(Log::Bdt, "bdt_req_connection failed: " << result);
	}
	return succeeded;
}
std::optional<Utilities::nice_ptr<ISlotDetail>> BdtClientWrapper::TryFindSlotDetail(unsigned dataType)
{
	std::optional<Utilities::nice_ptr<ISlotDetail>> found{};
	auto const itEnd = m_slotDetails.end();
	auto const itFound = std::find_if(m_slotDetails.begin(), itEnd,
		[dataType](auto&& spSlotDetail)
		{
			return spSlotDetail->GetDataType() == dataType;
		});
	if (itFound != itEnd)
	{
		found.emplace((*itFound).get());
	}

	return found;
}
Utilities::nice_ptr<ISlotDetail> BdtClientWrapper::FindSlotDetail(unsigned dataType)
{
	auto const found = TryFindSlotDetail(dataType);
	if (!found)
	{
		throw Error("Slot not found for data type " + To<std::string>(dataType));
	}
	return *found;
}
}
}
