/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See BdtRxSlot.h

#include "BdtRxSlot.h"
#include "Log.h"
#include <cassert>

namespace Shark
{
namespace Bdt
{
BdtRxSlot::BdtRxSlot(unsigned dataType, unsigned maximumSize)
	: m_dataType{dataType}
	, m_maximumSize{maximumSize}
{
	assert(m_maximumSize > 0);
}
unsigned BdtRxSlot::GetDataType() const
{
	return m_dataType;
}
void BdtRxSlot::Configure(CompletionCallback&& completionCallback)
{
	LOG_DEBUG_TAG(Log::Bdt, "Starting receive of " << std::hex << m_dataType);

	assert(completionCallback);
	assert(!m_completionCallback);
	m_completionCallback = std::move(completionCallback);
}
unsigned BdtRxSlot::GetMaximumSize() const
{
	return m_maximumSize;
}
void BdtRxSlot::AppendData(uint8_t const* pData, unsigned dataSize)
{
	LOG_DEBUG_TAG(Log::Bdt, std::hex << GetDataType() << ": Received " << dataSize << " bytes");
	m_receivedData.insert(m_receivedData.end(), pData, pData + dataSize);
}
void BdtRxSlot::Completed(bool succeeded)
{
	assert(m_completionCallback);
	// Clear out the callback first in case the callback kicks off another transfer
	auto const callback = m_completionCallback;
	m_completionCallback = {};

	std::optional<std::vector<uint8_t>> data{std::move(m_receivedData)};
	if (succeeded)
	{
		LOG_DEBUG_TAG(Log::Bdt,
			"Receive of " << std::hex << m_dataType << " succeeded");
	}
	else
	{
		LOG_WARNING_TAG(Log::Bdt,
			"Receive of " << std::hex << m_dataType << " failed after receiving " << data->size() << " bytes");
		data.reset();
	}

	// Clear out the data buffer before calling the callback in case the callback kicks off a new transfer
	m_receivedData.clear();
	m_receivedData.shrink_to_fit();
	callback(std::move(data));
}
}
}
