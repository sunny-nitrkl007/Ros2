/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Slot Detail Interface

#pragma once

#include "IBdtRxSlot.h"
#include "IBdtTxSlot.h"
#include <functional>
#include <memory>
#include <optional>
#include <vector>

namespace Shark
{
namespace Bdt
{
enum class AccessMode : unsigned
{
	Transmit,
	Receive,

	Count
};

class ISlotDetail
{
public:
	virtual ~ISlotDetail() = default;

	virtual unsigned GetDataType() const = 0;
	virtual std::optional<AccessMode> CurrentAccessMode() const = 0;
	virtual void SetRxSlot(std::unique_ptr<IBdtRxSlot>&& spRxSlot) = 0;
	virtual void SetTxSlot(std::unique_ptr<IBdtTxSlot>&& spTxSlot) = 0;
	virtual std::optional<std::function<void()>> InitiateRead(
		std::function<bool()>&& requestConnection,
		IBdtRxSlot::CompletionCallback&& completionCallback) = 0;
	virtual std::optional<std::function<void()>> InitiateWrite(
		std::function<bool()>&& requestConnection,
		std::vector<uint8_t>&& data,
		IBdtTxSlot::CompletionCallback&& completionCallback) = 0;
	virtual bool IsAccessModeSupported(AccessMode mode) const = 0;
	virtual void SetCompletedSuccessfully(bool completedSuccessfully) = 0;
	virtual unsigned GetDataSize() const = 0;
	virtual void CopyNextBytesIntoBuffer(uint8_t* pData, unsigned dataSize) = 0;
	virtual void AppendData(uint8_t const* pData, unsigned dataSize) = 0;
	virtual void ObtainDataAccess() = 0;
	virtual void DataAccessReleased() = 0;
	virtual void StateMachineFinished() = 0;
};
using SlotDetails = std::vector<std::unique_ptr<ISlotDetail>>;
}
}
