/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// BDT Receive Slot

#pragma once

#include "IBdtRxSlot.h"
#include <vector>

namespace Shark
{
namespace Bdt
{
class BdtRxSlot final : public IBdtRxSlot
{
public:
	BdtRxSlot(unsigned dataType, unsigned maximumSize);
// IBdtRxSlot
	unsigned GetDataType() const override;
	void Configure(CompletionCallback&& completionCallback) override;
	unsigned GetMaximumSize() const override;
	void AppendData(uint8_t const* pData, unsigned dataSize) override;
	void Completed(bool succeeded) override;
private:
	unsigned const m_dataType;
	unsigned const m_maximumSize;
	std::vector<uint8_t> m_receivedData{};
	CompletionCallback m_completionCallback{};
};
}
}
