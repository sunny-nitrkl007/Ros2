/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// BDT Receive Slot Interface

#pragma once

#include <functional>
#include <optional>

namespace Shark
{
namespace Bdt
{
class IBdtRxSlot
{
public:
	// Will receive std::nullopt if there was an error
	using CompletionCallback = std::function<void(std::optional<std::vector<uint8_t>>&& data)>;

	virtual ~IBdtRxSlot() = default;

	virtual unsigned GetDataType() const = 0;
	virtual void Configure(CompletionCallback&& completionCallback) = 0;
	virtual unsigned GetMaximumSize() const = 0;
	virtual void AppendData(uint8_t const* pData, unsigned dataSize) = 0;
	virtual void Completed(bool succeeded) = 0;
};
}
}
