/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// BDT Transmit Slot

#pragma once

#include "IBdtTxSlot.h"
#include <Utilities/EliminatePointerMemberWarning.h>
#include <optional>

namespace Shark
{
namespace Bdt
{
class BdtTxSlot final : public IBdtTxSlot
{
public:
	explicit BdtTxSlot(unsigned dataType);
// IBdtTxSlot
	unsigned GetDataType() const override;
	void Configure(std::vector<uint8_t>&& dataToTransmit, CompletionCallback&& completionCallback) override;
	unsigned GetSize() const override;
	void CopyNextBytesIntoBuffer(uint8_t* pBuffer, unsigned bufferSize) override;
	void Completed(bool succeeded) override;
private:
	struct TransferDetails
	{
		TransferDetails(std::vector<uint8_t>&& theDataToTransmit, CompletionCallback&& theCompletionCallback);
		TransferDetails(TransferDetails&&) = default;

		ELIMINATE_POINTER_MEMBER_WARNING(TransferDetails);

		std::vector<uint8_t> dataToTransmit;
		CompletionCallback completionCallback;
		uint8_t const* pCurrentData;
	};
	TransferDetails& CurrentTransferDetails();
	TransferDetails const& CurrentTransferDetails() const;

	unsigned const m_dataType;
	std::optional<TransferDetails> m_currentTransferDetails{};
};
}
}
