/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See BdtTxSlot.h

#include "BdtTxSlot.h"
#include "Log.h"
#include <Utilities/narrow_cast.h>
#include <algorithm>
#include <cassert>

namespace Shark
{
namespace Bdt
{
BdtTxSlot::TransferDetails::TransferDetails(
	std::vector<uint8_t>&& theDataToTransmit,
	CompletionCallback&& theCompletionCallback)
	: dataToTransmit{std::move(theDataToTransmit)}
	, completionCallback{std::move(theCompletionCallback)}
	, pCurrentData{dataToTransmit.data()}
{
	assert(completionCallback);
}

BdtTxSlot::BdtTxSlot(unsigned dataType)
	: m_dataType{dataType}
{
}
unsigned BdtTxSlot::GetDataType() const
{
	return m_dataType;
}
void BdtTxSlot::Configure(std::vector<uint8_t>&& dataToTransmit, CompletionCallback&& completionCallback)
{
	assert(completionCallback);
	assert(!m_currentTransferDetails);

	m_currentTransferDetails.emplace(std::move(dataToTransmit), std::move(completionCallback));
}
unsigned BdtTxSlot::GetSize() const
{
	return Utilities::narrow_cast<unsigned>(CurrentTransferDetails().dataToTransmit.size());
}
void BdtTxSlot::CopyNextBytesIntoBuffer(uint8_t* pBuffer, unsigned bufferSize)
{
	auto& currentTransferDetails = CurrentTransferDetails();
	assert(pBuffer);
	assert(
		currentTransferDetails.pCurrentData + bufferSize <=
		currentTransferDetails.dataToTransmit.data() + currentTransferDetails.dataToTransmit.size());

	std::copy_n(currentTransferDetails.pCurrentData, bufferSize, pBuffer);
	currentTransferDetails.pCurrentData += bufferSize;
}
void BdtTxSlot::Completed(bool succeeded)
{
	// Clear out the details first in case the callback kicks off another transfer
	TransferDetails transferDetails{std::move(CurrentTransferDetails())};
	m_currentTransferDetails.reset();

	if (succeeded)
	{
		LOG_DEBUG_TAG(Log::Bdt,
			"Transmit of " << std::hex << m_dataType << " succeeded");
	}
	else
	{
		LOG_WARNING_TAG(Log::Bdt,
			"Transmit of " << std::hex << m_dataType << " failed after sending " <<
			transferDetails.pCurrentData - transferDetails.dataToTransmit.data() << " bytes");
	}

	transferDetails.completionCallback(succeeded);
}
BdtTxSlot::TransferDetails& BdtTxSlot::CurrentTransferDetails()
{
	assert(m_currentTransferDetails);
	return *m_currentTransferDetails;
}
BdtTxSlot::TransferDetails const& BdtTxSlot::CurrentTransferDetails() const
{
	assert(m_currentTransferDetails);
	return *m_currentTransferDetails;
}
}
}
