/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// BDT helpers for pretty-printing

#pragma once

#include <Utilities/CountOf.h>
#include <bdt_proto.h>
#include <iomanip>
#include <ostream>

namespace Shark
{
namespace Bdt
{
constexpr AccessMode AccessModeToEnum(unsigned_8 accessmode)
{
	static_assert(BDT_READ_ACCESS  == Utilities::ToUnderlying(AccessMode::Transmit), "");
	static_assert(BDT_WRITE_ACCESS == Utilities::ToUnderlying(AccessMode::Receive),  "");

	return static_cast<AccessMode>(accessmode);
}
struct Type
{
	unsigned_8 value;
};
inline std::ostream& operator<<(std::ostream& stream, Type type)
{
	return stream << (type.value == BDT_RX ? "BDT_RX" : "BDT_TX");
}
struct DataType
{
	unsigned value;
};
inline std::ostream& operator<<(std::ostream& stream, DataType dataType)
{
	return stream << "0x" << std::hex << std::setw(4) << std::setfill('0') << dataType.value;
}
struct DataIndex
{
	unsigned value;
};
inline std::ostream& operator<<(std::ostream& stream, DataIndex dataIndex)
{
	return stream << "0x" << std::hex << std::setw(8) << std::setfill('0') << dataIndex.value;
}
struct BdtError
{
	bdt_error_t value;
};
inline std::ostream& operator<<(std::ostream& stream, BdtError bdtError)
{
	static constexpr char const* n_errorToString[]
	{
		"BDT_ERROR_NONE",
		"BDT_ERROR_DATATYPE_NA",
		"BDT_ERROR_INDEX_NA",
		"BDT_ERROR_FILE_TOO_LARGE",
		"BDT_ERROR_ENCRYP_NA",
		"BDT_ERROR_COMP_NA",
		"BDT_ERROR_TOO_MANY_CONNECTIONS",
		"BDT_ERROR_BUSY",
		"BDT_ERROR_WRONG_SECURITY",
		"BDT_ERROR_CONDITIONS_NOT_MET",
		"BDT_ERROR_VERSION_NA",
		"BDT_ERROR_INVALID_ENCRYP_CODE",
		"BDT_ERROR_INSUFFICIENT_ENCRYP",
		"BDT_ERROR_COMP_ENCRYP_ORDER_NA",
		"BDT_ERROR_UNKNOWN_DTYPE_IDX_COMBO",
		"BDT_ERROR_TIMEOUT",
		"BDT_ERROR_PTXT_CHKSUM",
		"BDT_ERROR_APP_ABORT",
		"BDT_ERROR_FILE_NOT_MODIFIED",
		"BDT_ERROR_COMMAND_NOT_SUPPORTED"
	};

	assert(bdtError.value < Utilities::CountOf(n_errorToString));
	return stream << n_errorToString[bdtError.value];
}
struct BdtStatus
{
	unsigned value;
};
inline std::ostream& operator<<(std::ostream& stream, BdtStatus bdtStatus)
{
	static constexpr char const* n_statusToString[]
	{
		"",
		"BDT_STAT_WAIT",
		"BDT_STAT_FAIL",
		"BDT_STAT_SEND",
		"BDT_STAT_RECV",
		"BDT_STAT_SUCCESS",
		"BDT_STAT_CLOSE_FAIL"
	};

	assert(bdtStatus.value < Utilities::CountOf(n_statusToString));
	return stream << n_statusToString[bdtStatus.value];
}
}
}
