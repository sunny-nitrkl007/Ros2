/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See SlotDetail.h

#include "SlotDetail.h"
#include "DataTypes.h"
#include "Log.h"
#include <Utilities/Conversions.h>
#include <Utilities/CountOf.h>
#include <Utilities/ToUnderlying.h>

namespace Shark
{
namespace Bdt
{
std::ostream& operator<<(std::ostream& stream, SlotDetail::SlotState state)
{
	static constexpr char const* s_stateNames[]
	{
		"Idle",
		"InProgress",
		"InProgressAndDataAccessObtained",
		"WaitingForReleaseDataAccess",
		"WaitingForStateMachineToFinish",
	};
	static_assert(Utilities::CountOf(s_stateNames) == Utilities::ToUnderlying(SlotDetail::SlotState::Count), "");

	assert(state < SlotDetail::SlotState::Count);
	stream << s_stateNames[Utilities::ToUnderlying(state)];
	return stream;
}

SlotDetail::SlotDetail(unsigned dataType)
	: m_dataType{dataType}
{
}
void SlotDetail::SetRxSlot(std::unique_ptr<IBdtRxSlot>&& spRxSlot)
{
	assert(spRxSlot);
	assert(!m_spRxSlot);
	m_spRxSlot = std::move(spRxSlot);
}
void SlotDetail::SetTxSlot(std::unique_ptr<IBdtTxSlot>&& spTxSlot)
{
	assert(spTxSlot);
	assert(!m_spTxSlot);
	m_spTxSlot = std::move(spTxSlot);
}
std::optional<std::function<void()>> SlotDetail::InitiateRead(
	std::function<bool()>&& requestConnection,
	IBdtRxSlot::CompletionCallback&& completionCallback)
{
	Shark::Bdt::DataType const dataType{GetDataType()};
	if (!m_spRxSlot)
	{
		throw Error("BDT Rx slot does not exist for data type " + To<std::string>(dataType));
	}

	auto requestCallback = InitiateTransfer(
		std::move(requestConnection),
		AccessMode::Receive,
		[&slot = *m_spRxSlot, &completionCallback]() -> IBdtRxSlot&
		{
			slot.Configure(std::move(completionCallback));
			return slot;
		});
	if (!requestCallback)
	{
		LOG_WARNING_TAG(Log::Bdt,
			"Failing to obtain data access: A transfer is already in progress for data type " << dataType);
		completionCallback(std::nullopt);
	}

	return requestCallback;
}
std::optional<std::function<void()>> SlotDetail::InitiateWrite(
	std::function<bool()>&& requestConnection,
	std::vector<uint8_t>&& data,
	IBdtTxSlot::CompletionCallback&& completionCallback)
{
	Shark::Bdt::DataType const dataType{GetDataType()};
	if (!m_spTxSlot)
	{
		throw Error("BDT Tx slot does not exist for data type " + To<std::string>(dataType));
	}

	auto requestCallback = InitiateTransfer(
		std::move(requestConnection),
		AccessMode::Transmit,
		[&slot = *m_spTxSlot, &data, &completionCallback]() -> IBdtTxSlot&
		{
			slot.Configure(std::move(data), std::move(completionCallback));
			return slot;
		});

	if (!requestCallback)
	{
		LOG_WARNING_TAG(Log::Bdt,
			"Failing to obtain data access: A transfer is already in progress for data type " << dataType);
		completionCallback(false);
	}

	return requestCallback;
}
template <typename ConfigureSlot>
std::optional<std::function<void()>> SlotDetail::InitiateTransfer(
	std::function<bool()>&& requestConnection,
	AccessMode accessMode,
	ConfigureSlot configureSlot)
{
	std::lock_guard<Utilities::mutex> lock{m_mutex};
	std::optional<std::function<void()>> requestFunction{};
	if (m_slotState == SlotState::Idle)
	{
		ChangeState(SlotState::InProgress);
		assert(!m_currentAccessMode);
		assert(!m_completedSuccessfully);
		auto& slot = configureSlot();
		requestFunction =
			[this, requestConnection, &slot, accessMode]()
			{
				auto const succeeded = requestConnection();

				std::lock_guard<Utilities::mutex> innerLock{m_mutex};
				if (succeeded)
				{
					m_currentAccessMode = accessMode;
				}
				else
				{
					slot.Completed(false);
					ChangeState(SlotState::Idle);
				}
			};
	}
	else
	{
		LOG_WARNING_TAG(Log::Bdt,
			"Cannot initiate transfer: Slot is not idle for data type " << DataType{GetDataType()} << ", current state is " << m_slotState);
	}
	return requestFunction;
}
bool SlotDetail::IsAccessModeSupported(AccessMode mode) const
{
	return mode == AccessMode::Receive ? static_cast<bool>(m_spRxSlot) : static_cast<bool>(m_spTxSlot);
}
void SlotDetail::SetCompletedSuccessfully(bool completedSuccessfully)
{
	std::lock_guard<Utilities::mutex> lock{m_mutex};
	assert(m_currentAccessMode);
	assert(!m_completedSuccessfully);
	m_completedSuccessfully = completedSuccessfully;
}
unsigned SlotDetail::GetDataSize() const
{
	auto size = 0u;
	assert(m_currentAccessMode);

	if (*m_currentAccessMode == AccessMode::Receive)
	{
		assert(m_spRxSlot);
		size = m_spRxSlot->GetMaximumSize();
	}
	else
	{
		assert(m_spTxSlot);
		size = m_spTxSlot->GetSize();
	}
	return size;
}
void SlotDetail::CopyNextBytesIntoBuffer(uint8_t* pData, unsigned dataSize)
{
	assert(m_spTxSlot);
	m_spTxSlot->CopyNextBytesIntoBuffer(pData, dataSize);
}
void SlotDetail::AppendData(uint8_t const* pData, unsigned dataSize)
{
	assert(m_spRxSlot);
	m_spRxSlot->AppendData(pData, dataSize);
}
void SlotDetail::ObtainDataAccess()
{
	std::lock_guard<Utilities::mutex> lock{m_mutex};
	assert(m_slotState == SlotState::InProgress);
	ChangeState(SlotState::InProgressAndDataAccessObtained);
}
void SlotDetail::DataAccessReleased()
{
	// Depending on success or failure, DataAccessReleased and StateMachineFinished could be called in different orders
	std::function<void()> completedCallback{};
	{
		std::unique_lock<Utilities::mutex> lock{m_mutex};
		if (m_slotState == SlotState::WaitingForReleaseDataAccess)
		{
			completedCallback = Finished();
		}
		else
		{
			assert(m_slotState == SlotState::InProgressAndDataAccessObtained);
			ChangeState(SlotState::WaitingForStateMachineToFinish);
		}
	}
	if (completedCallback)
	{
		completedCallback();
	}
}
void SlotDetail::StateMachineFinished()
{
	// If we are already in Idle, we either haven't started or have already finished and cleaned up, so we don't need to do anything
	if (m_slotState != SlotState::Idle)
	{
		// Depending on success or failure, DataAccessReleased and StateMachineFinished could be called in different orders
		std::function<void()> completedCallback{};
		{
			std::unique_lock<Utilities::mutex> lock{m_mutex};
			if (m_slotState == SlotState::InProgress || m_slotState == SlotState::WaitingForStateMachineToFinish)
			{
				completedCallback = Finished();
			}
			else
			{
				assert(m_slotState == SlotState::InProgressAndDataAccessObtained);
				ChangeState(SlotState::WaitingForReleaseDataAccess);
			}
		}

		LOG_DEBUG_TAG(Log::Bdt,
			"SlotDetail::StateMachineFinished(): " << (completedCallback ? "" : "not ") << "calling the completed callback");
		if (completedCallback)
		{
			completedCallback();
		}
	}
}
std::function<void()> SlotDetail::Finished()
{
	assert(m_mutex.IsLockedByCaller());
	std::function<void()> completedCallback{};
	auto const successful = (m_completedSuccessfully && *m_completedSuccessfully);
	if (*m_currentAccessMode == AccessMode::Receive)
	{
		assert(m_spRxSlot);
		auto& slot = *m_spRxSlot;
		completedCallback =
			[&slot, successful]()
			{
				slot.Completed(successful);
			};
	}
	else
	{
		assert(m_spTxSlot);
		auto& slot = *m_spTxSlot;
		completedCallback =
			[&slot, successful]()
			{
				slot.Completed(successful);
			};
	}

	ChangeState(SlotState::Idle);
	m_currentAccessMode.reset();
	m_completedSuccessfully.reset();
	return completedCallback;
}
void SlotDetail::ChangeState(SlotState newState)
{
	assert(m_mutex.IsLockedByCaller());
	LOG_DEBUG_TAG(Log::Bdt, "SlotDetail(" << m_dataType << "): Changing state from " << m_slotState << " to " << newState);
	m_slotState = newState;
}
}
}
