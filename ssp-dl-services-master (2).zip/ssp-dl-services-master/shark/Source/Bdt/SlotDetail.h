/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Slot Detail

#pragma once

#include "ISlotDetail.h"
#include <Utilities/DefineExceptionClass.h>
#include <Utilities/mutex.h>
#include <Utilities/OptionalSmartPointers.h>

namespace Shark
{
namespace Bdt
{
class SlotDetail final : public ISlotDetail
{
public:
	enum class SlotState
	{
		Idle,
		InProgress,
		InProgressAndDataAccessObtained,
		WaitingForReleaseDataAccess,
		WaitingForStateMachineToFinish,

		Count
	};

	SlotDetail(unsigned dataType);

	DEFINE_EXCEPTION_CLASS(Error);
	/// \exception Error
	///		Thrown when an unrecoverable error occurs in a SlotDetail

	SlotState GetSlotState() const { return m_slotState; } // For testing purposes;
// ISlotDetail
	unsigned GetDataType() const override { return m_dataType; }
	std::optional<AccessMode> CurrentAccessMode() const override { return m_currentAccessMode; }
	void SetRxSlot(std::unique_ptr<IBdtRxSlot>&& spRxSlot) override;
	void SetTxSlot(std::unique_ptr<IBdtTxSlot>&& spTxSlot) override;
	std::optional<std::function<void()>> InitiateRead(
		std::function<bool()>&& requestConnection,
		IBdtRxSlot::CompletionCallback&& completionCallback) override;
	std::optional<std::function<void()>> InitiateWrite(
		std::function<bool()>&& requestConnection,
		std::vector<uint8_t>&& data,
		IBdtTxSlot::CompletionCallback&& completionCallback) override;
	bool IsAccessModeSupported(AccessMode mode) const override;
	void SetCompletedSuccessfully(bool completedSuccessfully) override;
	unsigned GetDataSize() const override;
	void CopyNextBytesIntoBuffer(uint8_t* pData, unsigned dataSize) override;
	void AppendData(uint8_t const* pData, unsigned dataSize) override;
	void ObtainDataAccess() override;
	void DataAccessReleased() override;
	void StateMachineFinished() override;
private:
	std::function<void()> Finished();
	template <typename ConfigureSlot>
	std::optional<std::function<void()>> InitiateTransfer(
		std::function<bool()>&& requestConnection,
		AccessMode accessMode,
		ConfigureSlot configureSlot);
	void ChangeState(SlotState newState);

	unsigned m_dataType{};
	SlotState m_slotState{};
	std::optional<AccessMode> m_currentAccessMode{};
	std::optional<bool> m_completedSuccessfully{};
	Utilities::optional_unique_ptr<IBdtRxSlot> m_spRxSlot{};
	Utilities::optional_unique_ptr<IBdtTxSlot> m_spTxSlot{};
	Utilities::mutex m_mutex{};
};
}
}
