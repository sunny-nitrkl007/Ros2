/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// BDT Client Wrapper

#pragma once

#include "Config/CanPort.h"
#include "ISlotDetail.h"
#include "IWriteSharkByte.h"
#include <Utilities/DefineExceptionClass.h>
#include <Utilities/nice_ptr.h>
#include <Utilities/OptionalSmartPointers.h>
#include <bdt_proto.h>
#include <mutex>
#include <vector>

namespace Utilities { class TransientSharkByte; }
namespace Shark
{
class DependencyContainer;

namespace J1939 { class IJ1939Wrapper; }
class IPeriodicTaskManager;

namespace Bdt
{
class BdtClientWrapper
{
public:
	static bool ShouldBeCreated(DependencyContainer const& dependencyContainer);
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);

	BdtClientWrapper();
	~BdtClientWrapper();

	DEFINE_EXCEPTION_CLASS(Error);
	/// \exception Error
	///		Thrown when an unrecoverable error occurs in the BDT library
	void Initialize(std::vector<Utilities::nice_ptr<J1939::IJ1939Wrapper>> const& j1939Wrappers);
	void UpdateBdt();
	void SetSlotDetails(SlotDetails&& slotDetails);
	void InitiateRead(
		Config::CanPort canPort,
		unsigned address,
		unsigned dataType,
		unsigned index,
		Utilities::TransientSharkByte& sharkByte);
	void InitiateWrite(
		Config::CanPort canPort,
		unsigned address,
		unsigned dataType,
		unsigned index,
		std::vector<uint8_t>&& data,
		IWriteSharkByte::CompletedCallback const& completedCallback);
private:
	static boolean StaticQueryIndexSupported(unsigned_16 datatype, unsigned_32 index, unsigned_8 accessmode);
	bool QueryIndexSupported(unsigned dataType, unsigned index, AccessMode accessMode);

	static boolean StaticObtainDataAccess(unsigned_16 datatype, unsigned_32 index, unsigned_8 accessmode);
	void ObtainDataAccess(unsigned dataType, unsigned index, AccessMode accessMode);

	static void StaticReleaseDataAccess(unsigned_16 datatype, unsigned_32 index, unsigned_8 accessmode);
	void ReleaseDataAccess(unsigned dataType);

	static unsigned_32 StaticGetDataSize(
		unsigned_16 datatype,
		unsigned_32 index,
		unsigned_8 accessmode,
		unsigned_32 requestedsize);
	unsigned GetDataSize(unsigned dataType, unsigned requestedSize);

	static unsigned_8 StaticCloseData(unsigned_16 datatype, boolean complete);
	void CloseData(unsigned dataType, bool completedSuccessfully);

	static unsigned_8 StaticGetData(
		unsigned_16 datatype,
		unsigned_32 size,
		unsigned_8 *read_data,
		unsigned_32 *read_data_size);
	void GetData(unsigned dataType, unsigned dataSize, uint8_t* pData);

	static unsigned_8 StaticSetData(
		unsigned_16 datatype,
		unsigned_32 size,
		unsigned_8 write_data[],
		unsigned_32 *write_data_size);
	void SetData(unsigned dataType, unsigned dataSize, uint8_t const* pData);

	static void StaticJ1939ConnectionStatusHandler(
		void* conn_status_context,
		unsigned_8 type,
		unsigned_8 sid,
		unsigned_8 did,
		unsigned_16 datatype,
		unsigned_32 index,
		unsigned_16 status);
	void ConnectionStatusHandler(unsigned dataType, unsigned status);

	bool RequestConnection(
		AccessMode accessMode,
		Config::CanPort canPort,
		unsigned address,
		unsigned dataType,
		unsigned index);

	std::optional<Utilities::nice_ptr<ISlotDetail>> TryFindSlotDetail(unsigned dataType);
	Utilities::nice_ptr<ISlotDetail> FindSlotDetail(unsigned dataType);

	SlotDetails m_slotDetails{};
	std::array<std::optional<unsigned_8>, Config::CanPort::CanPortCount> m_dataLinkHandles{};
	std::mutex m_mutex{};
	bdt_app_info_t m_bdtApplicationInfo{};
	std::vector<std::function<void()>> m_bdtRequestFunctions{};
};
}
}
