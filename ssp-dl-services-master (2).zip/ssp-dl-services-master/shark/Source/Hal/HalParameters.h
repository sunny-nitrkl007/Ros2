/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Hal Parameters

#pragma once

namespace DesktopHal
{
class HalParameters final
{
public:
	bool KeySwitchIsAsserted() const { return m_keySwitchIsAsserted; }
	void SetKeySwitchIsAsserted(bool isAsserted) { m_keySwitchIsAsserted = isAsserted; }

	bool WakeIsAsserted() const { return m_wakeIsAsserted; }
	void SetWakeIsAsserted(bool isAsserted) { m_wakeIsAsserted = isAsserted; }

	bool RtcAlarmIsAsserted() const { return m_rtcAlarmIsAsserted; }
	void SetRtcAlarmIsAsserted(bool isAsserted) { m_rtcAlarmIsAsserted = isAsserted; }

	bool AnyWakeSourceIsAsserted() const { return KeySwitchIsAsserted() || WakeIsAsserted() || RtcAlarmIsAsserted(); }

	int LcdTemperature() const { return m_lcdTemperature; }
	void SetLcdTemperature(int lcdTemperature) { m_lcdTemperature = lcdTemperature; }

	unsigned LocationCode() const { return m_locationCode; }
	void SetLocationCode(unsigned locationCode) { m_locationCode = locationCode; }

	unsigned SystemVoltage() const { return m_systemVoltage; }
	void SetSystemVoltage(unsigned systemVoltage) { m_systemVoltage = systemVoltage; }

	unsigned long PowerOutput1Error() const { return m_powerOutput1Error; }
	void SetPowerOutput1Error(unsigned long powerOutput1Error) { m_powerOutput1Error = powerOutput1Error; }

	unsigned long PowerOutput2Error() const { return m_powerOutput2Error; }
	void SetPowerOutput2Error(unsigned long powerOutput2Error) { m_powerOutput2Error = powerOutput2Error; }

	unsigned CpuCount() const { return m_cpuCount; }
	void SetCpuCount(unsigned cpuCount) { m_cpuCount = cpuCount; }

private:
	bool m_wakeIsAsserted{false};
	bool m_keySwitchIsAsserted{true}; // On by default so that Shark will Initialize
	bool m_rtcAlarmIsAsserted{false};
	int m_lcdTemperature{20}; // In degrees C
	unsigned m_locationCode{0};
	unsigned m_systemVoltage{12};
	unsigned long m_powerOutput1Error{0x00};
	unsigned long m_powerOutput2Error{0x00};
	unsigned m_cpuCount{0x02};
};
}
