/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See HalParametersFileParser.h

#include "HalParametersFileParser.h"
#include "HalParameters.h"
#include "Log.h"
#include <Utilities/AutoFd.h>
#include <Utilities/Conversions.h>
#include "Utilities/CountOf.h"
#include <Utilities/Filesystem.h>
#include <Utilities/IndexOf.h>
#include <boost/algorithm/string/trim.hpp>
#include <boost/filesystem.hpp>
#include <fstream>
#include <hal_defs.h>
#include <pugixml.hpp>
#include <sys/inotify.h>
#include <thread>

namespace DesktopHal
{
namespace
{
constexpr auto n_pParametersFilePath = "./DesktopHalParameters.xml"; // Lives next to DudeDesktopShark

template <typename T>
struct XmlParameters
{
	char const* pName;
	void (HalParameters::*pSetter)(T value);
};
constexpr XmlParameters<bool> n_booleanXmlParameters[]
{
	{ "KeySwitchIsAsserted", &HalParameters::SetKeySwitchIsAsserted },
	{ "WakeIsAsserted",      &HalParameters::SetWakeIsAsserted },
	{ "RtcAlarmIsAsserted",  &HalParameters::SetRtcAlarmIsAsserted },
};
constexpr XmlParameters<int> n_integerXmlParameters[]
{
	{ "LcdTemperature", &HalParameters::SetLcdTemperature },
};
constexpr XmlParameters<unsigned> n_unsignedXmlParameters[]
{
	{ "LocationCode", &HalParameters::SetLocationCode },
	{ "SystemVoltage", &HalParameters::SetSystemVoltage },
	{ "CpuCount", &HalParameters::SetCpuCount },
};
constexpr XmlParameters<unsigned long> n_halErrorXmlParameters[]
{
	{ "PowerOutput1Error", &HalParameters::SetPowerOutput1Error },
	{ "PowerOutput2Error", &HalParameters::SetPowerOutput2Error },
};

template <typename T, size_t N>
void ParseXmlParameters(
	pugi::xml_node const& rootNode,
	HalParameters& halParameters,
	XmlParameters<T> const (&parameters)[N])
{
	for (auto&& parameter : parameters)
	{
		auto const node = rootNode.child(parameter.pName);
		if (node)
		{
			auto const value = To<T>(node.attribute("Value").value()); // Terminates the process upon failure
			LOG_INFO_HIGH_TAG(Log::DesktopHal, parameter.pName << ": " << value);
			(halParameters.*parameter.pSetter)(value);
		}
	}
}
constexpr char const* n_pErrorTypes[] {
	"No Fault",
	"Low Voltage",
	"High Voltage",
	"High Current"
};
constexpr unsigned long n_errorToHalCode[] {
	HAL_DEFINITE_NO_FAULT,
	HAL_SIGNAL_OOR_LOW,
	HAL_SIGNAL_OOR_HIGH,
	HAL_PIN_A_FAILED_LOW,
};
static_assert(Utilities::CountOf(n_pErrorTypes) == Utilities::CountOf(n_errorToHalCode), "Size mismatch");
void ParseXmlHalErrorParameters(
	pugi::xml_node const& rootNode,
	HalParameters& halParameters)
{
	for (auto&& parameter : n_halErrorXmlParameters)
	{
		auto const node = rootNode.child(parameter.pName);
		if (node)
		{
			unsigned long value{0};

			auto const attribute = std::string{node.attribute("Value").value()};
			auto const intValue = TryTo<unsigned long>(attribute);
			if (intValue)
			{
				value = *intValue;
			}
			else
			{
				auto const index = Utilities::TryIndexOf(n_pErrorTypes, attribute);
				if (index)
				{
					value = n_errorToHalCode[*index];
				}
			}

			(halParameters.*parameter.pSetter)(value);
		}
	}

}

/// Exit because the user might be expecting certain behavior, but will get the defaults instead.
[[noreturn]] void LogErrorAndExit(std::string const& error)
{
	LOG_ERROR_TAG(Log::DesktopHal, error);
	exit(-1);
}

std::string ReadParametersFile()
{
	// For some reason, document.load_file() fails sporadically as the config file is changing
	// because it only ends up with part of the file. Reading the file entirely using an
	// ifstream seems to fix the problem.
	std::ifstream fileStream{n_pParametersFilePath};
	return std::string{std::istreambuf_iterator<char>{fileStream}, std::istreambuf_iterator<char>{}};
}

/// Separate parsing from declaration to avoid release-build type-punning warning.
std::string ExtractFileNameFrom_inotify_event(uint8_t const* pBuffer)
{
	auto const& event = *reinterpret_cast<inotify_event const*>(pBuffer);
	std::string name{event.name, event.len};

	// Remove any extra null-terminators added for alignment
	boost::algorithm::trim_right_if(name, [](char c){ return c == '\0'; });

	return name;
}
}

void HalParametersFileParser::StartParsingThread(HalParameters& halParameters)
{
	auto spParser = std::make_shared<HalParametersFileParser>(halParameters, n_pParametersFilePath);
	spParser->Parse(); // Get the initial values

	std::thread thread{[spParser]{ spParser->ParserThread(); }};
	thread.detach();
}

HalParametersFileParser::HalParametersFileParser(HalParameters& halParameters, std::string const& parametersFilePath)
	: m_halParameters{halParameters}
	, m_parametersFilePath{parametersFilePath}
{
}
void HalParametersFileParser::Parse()
{
	std::lock_guard<std::mutex> lock{m_mutex};

	auto const xml = ReadParametersFile();
	if (!xml.empty())
	{
		pugi::xml_document document{};
		auto const parseResult = document.load_string(xml.c_str());
		if (!parseResult)
		{
			std::stringstream errorStream{};
			errorStream << "Could not parse file: " << n_pParametersFilePath << ": " << parseResult.description();
			LogErrorAndExit(errorStream.str());
		}
		else
		{
			auto const rootNode = document.first_child();
			ParseXmlParameters(rootNode, m_halParameters, n_booleanXmlParameters);
			ParseXmlParameters(rootNode, m_halParameters, n_integerXmlParameters);
			ParseXmlParameters(rootNode, m_halParameters, n_unsignedXmlParameters);
			ParseXmlHalErrorParameters(rootNode, m_halParameters);
		}
	}
}

void HalParametersFileParser::ParserThread()
{
	AutoFd const inotifyFd = inotify_init();
	assert(inotifyFd);

	WaitForTheFileToExist(inotifyFd);
	MonitorTheFile(inotifyFd);
}

void HalParametersFileParser::WaitForTheFileToExist(int inotifyFd)
{
	boost::filesystem::path const boostPath{m_parametersFilePath};
	auto const filename = boostPath.filename();
	auto const directory = boostPath.parent_path();
	AutoFd const wd = inotify_add_watch(inotifyFd, directory.c_str(), IN_CREATE | IN_MOVED_TO);
	assert(wd.IsValid());

	if (!Utilities::Filesystem{}.Exists(m_parametersFilePath))
	{
		alignas(inotify_event) uint8_t buffer[sizeof(inotify_event) + NAME_MAX + 1];
		for (;;)
		{
			auto const readResult = read(inotifyFd, &buffer, sizeof(buffer));
			if (readResult == -1)
			{
				LOG_WARNING_TAG(Log::DesktopHal, "WaitForTheFileToExist: read() failed: " << errno << ": " << strerror(errno));
				continue;
			}

			auto const name = ExtractFileNameFrom_inotify_event(buffer);
			if (name == filename)
			{
				break;
			}

			// TODO: This should really loop over all the inotify results, but since it is monitoring
			//       the artifacts directory, there should not be much simultaneous file creation activity.
		}
	}
}

void HalParametersFileParser::MonitorTheFile(int inotifyFd)
{
	AutoFd const wd = inotify_add_watch(inotifyFd, m_parametersFilePath.c_str(), IN_MODIFY | IN_MOVED_TO | IN_CLOSE_WRITE);
	assert(wd.IsValid()); // This *could* fail if the file is deleted immediately after being created.

	LOG_INFO_HIGH_TAG(Log::DesktopHal, "Monitoring " << m_parametersFilePath);
	Log::Flush();

	alignas(inotify_event) uint8_t buffer[sizeof(inotify_event) + NAME_MAX + 1];
	for (;;)
	{
		Parse(); // Perform an initial parse to ensure we have the latest changes.

		// The results of the read are ignored. We assume it was a modification to the file.
		auto const readResult = read(inotifyFd, &buffer, sizeof(buffer));
		if (readResult == -1)
		{
			LOG_WARNING_TAG(Log::DesktopHal, "MonitorTheFile: read() failed: " << errno << ": " << strerror(errno));
			continue;
		}
	}
}
}
