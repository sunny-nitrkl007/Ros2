/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Hal Parameters File Parser

#pragma once

#include <mutex>
#include <string>

namespace DesktopHal
{
class HalParameters;

class HalParametersFileParser final
{
public:
	static void StartParsingThread(HalParameters& halParameters);

	HalParametersFileParser(HalParameters& halParameters, std::string const& parametersFilePath);
	void Parse();
private:
	void ParserThread();
	void WaitForTheFileToExist(int inotifyFd);
	void MonitorTheFile(int inotifyFd);

	HalParameters& m_halParameters;
	std::string const m_parametersFilePath;
	std::mutex m_mutex{};
};
}
