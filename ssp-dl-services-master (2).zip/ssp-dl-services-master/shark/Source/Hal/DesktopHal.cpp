/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Fake desktop HAL implementation

#include "HalParameters.h"
#include "HalParametersFileParser.h"
#include "Utilities/narrow_cast.h"
#include <cassert>
#include <memory>

namespace DesktopHal
{
namespace
{
std::unique_ptr<HalParameters const> n_spHalParameters{};
auto n_factoryPasswordEnabledSerialNumber = "170215009008000L";
}

void InitializeDesktopHal()
{
	assert(!n_spHalParameters);
	auto spHalParameters = std::make_unique<HalParameters>();
	HalParametersFileParser::StartParsingThread(*spHalParameters);
	n_spHalParameters = std::move(spHalParameters);
}
HalParameters const& GetParameters()
{
	if (!n_spHalParameters)
	{
		InitializeDesktopHal();
	}
	return *n_spHalParameters;
}
}

using namespace DesktopHal;

// hal_boot_proto
#include <cstring>
#include <hal_boot_proto.h>

hal_ecm_id_t hal_boot_get_ecm_id()
{
	return hal_ecm_id_t{};
}
hal_cat_partno_t hal_boot_get_ecm_partno()
{
	return hal_cat_partno_t{10, "4905873-00"};
}
hal_ecm_serialno_t hal_boot_get_ecm_serialno()
{
	hal_ecm_serialno_t serialNumber{16, {}};
	memcpy(&serialNumber.string, n_factoryPasswordEnabledSerialNumber, serialNumber.length);
	return serialNumber;
}
hal_location_code_t hal_boot_read_location_code()
{
	return static_cast<hal_location_code_t>(GetParameters().LocationCode());
}
hal_aftermarket_id_t hal_boot_get_aftermarket_id()
{
	return 1;
}
hal_sw_fileid_t hal_boot_get_sw_fileid(hal_sw_index_t)
{
	return {};
}