/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See DependencyContainer.h

#include "DependencyContainer.h"
#include "Config/ProtobufConversions.h"
#include <Utilities/ToUnderlying.h>
#include <cassert>

namespace Shark
{
namespace
{
unsigned CanIndex(Config::CanPort canPort)
{
	assert(canPort < Config::CanPort::CanPortCount);
	return Utilities::ToUnderlying(canPort);
}
}

DependencyContainer::DependencyContainer(
	cat::shark::Config const& sharkConfig,
	J1939DataLinkConfigs&& j1939DataLinks,
	Utilities::IEnvironment const& environment,
	Utilities::IFilesystem const& filesystem,
	IPidDataReceiver& pidDataReceiver,
	IPeriodicTaskManager& periodicTaskManager,
	SharkBytes::ISharkByteManager& sharkByteManager,
	ISharkByteRetriever const& sharkByteRetriever,
	SharkBytes::IWriteSharkByteManager& writeSharkByteManager,
	IWriteSharkByteRetriever const& writeSharkByteRetriever,
	SharkBytes::ISlotManager& slotManager,
	SharkUtilities::IEventCallbackFactory& eventCallbackFactory,
	Nvm::INvmBlockDefinitions& nvmBlockDefinitions,
	Nvm::ISclNvmWrapper& sclNvmWrapper,
	ISclEncryptFeatureRegistrar& sclEncryptFeatureRegistrar,
	J1939::IJ1939PublicDataReceiver& publicDataReceiver,
	J1939::ITransportProtocolClientSynchronizer& transportProtocolClientSynchronizer,
	IExtensionIdDataReceiver& extensionIdDataReceiver,
	IAsynchronousDispatcher& asynchronousDispatcher)
	: m_sharkConfig{sharkConfig}
	, m_j1939DataLinks{std::move(j1939DataLinks)}
	, m_environment{environment}
	, m_filesystem{filesystem}
	, m_pidDataReceiver{pidDataReceiver}
	, m_periodicTaskManager{periodicTaskManager}
	, m_sharkByteManager{sharkByteManager}
	, m_sharkByteRetriever{sharkByteRetriever}
	, m_writeSharkByteManager{writeSharkByteManager}
	, m_writeSharkByteRetriever{writeSharkByteRetriever}
	, m_slotManager{slotManager}
	, m_eventCallbackFactory{eventCallbackFactory}
	, m_nvmBlockDefinitions{nvmBlockDefinitions}
	, m_sclNvmWrapper(sclNvmWrapper)
	, m_sclEncryptFeatureRegistrar{sclEncryptFeatureRegistrar}
	, m_publicDataReceiver{publicDataReceiver}
	, m_transportProtocolClientSynchronizer{transportProtocolClientSynchronizer}
	, m_extensionIdDataReceiver{extensionIdDataReceiver}
	, m_asynchronousDispatcher{asynchronousDispatcher}
{
}
DependencyContainer::~DependencyContainer() = default;

J1939::IJ1939Wrapper& DependencyContainer::GetIJ1939Wrapper(Config::CanPort canPort) const
{
	auto const index = CanIndex(canPort);
	assert(m_j1939WrapperObjects[index].j1939Wrapper);

	return *m_j1939WrapperObjects[index].j1939Wrapper;
}
IWorkQueue& DependencyContainer::GetJ1939TaskWorkQueue(Config::CanPort canPort) const
{
	auto const index = CanIndex(canPort);
	assert(m_j1939WrapperObjects[index].j1939TaskWorkQueue);

	return *m_j1939WrapperObjects[index].j1939TaskWorkQueue;
}
J1939::IJ1939Wrapper& DependencyContainer::GetIJ1939Wrapper() const
{
	auto const& firstJ1939DataLinkConfig = *GetJ1939DataLinkConfigs()[0];
	auto const firstCanPort = Config::ToConfigCanPort(firstJ1939DataLinkConfig.can_port());
	return GetIJ1939Wrapper(firstCanPort);
}
void DependencyContainer::Set(Config::CanPort canPort, J1939::IJ1939Wrapper& j1939Wrapper, IWorkQueue& j1939TaskWorkQueue)
{
	auto const index = CanIndex(canPort);
	assert(!m_j1939WrapperObjects[index].j1939Wrapper);
	assert(!m_j1939WrapperObjects[index].j1939TaskWorkQueue);

	m_j1939WrapperObjects[index].j1939Wrapper = &j1939Wrapper;
	m_j1939WrapperObjects[index].j1939TaskWorkQueue = &j1939TaskWorkQueue;
}
}