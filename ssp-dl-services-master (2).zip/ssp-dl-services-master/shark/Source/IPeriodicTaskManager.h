/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Periodic task manager

#pragma once

#include "Utilities/ToUnderlying.h"
#include <array>
#include <chrono>
#include <functional>

namespace Shark
{
enum class TaskPeriod : unsigned
{
	Is20ms,
	Is50ms,
	Is100ms,
	Is500ms,
	Is1000ms,
	Is5000ms,

	// The following will not force a crash in case of continual timeouts
	IsNotTimeCritical100ms,
	IsNotTimeCritical1000ms,

	Count,

	MinimumRealTimeTaskPeriod = Is20ms,
	MaximumRealTimeTaskPeriod = Is5000ms,

	MinimumNonRealTimeTaskPeriod = IsNotTimeCritical100ms,
	MaximumNonRealTimeTaskPeriod = IsNotTimeCritical1000ms,
};

inline constexpr bool IsExternalTask(TaskPeriod taskPeriod) { return taskPeriod == TaskPeriod::Is5000ms; }

class IPeriodicTaskManager
{
public:
	virtual ~IPeriodicTaskManager() = default;

	virtual void Add(TaskPeriod period, std::function<void()> const& taskMethod) = 0;
	virtual std::function<void()> GetTaskUpdater(TaskPeriod period) = 0;
};

namespace Detail
{
/// Ideally this would all be in TaskPeriodToMilliseconds if we had a C++14 compiler
class TaskPeriodToMillisecondsConverter final
{
public:
	constexpr TaskPeriodToMillisecondsConverter()
		: m_conversions{20, 50, 100, 500, 1000, 5000, 100, 1000}
	{
	}
	constexpr std::chrono::milliseconds Convert(TaskPeriod period)
	{
		return std::chrono::milliseconds{m_conversions[Utilities::ToUnderlying(period)]};
	}
private:
	std::array<unsigned, Utilities::ToUnderlying(TaskPeriod::Count)> const m_conversions;
};
static_assert(TaskPeriodToMillisecondsConverter{}
	.Convert(static_cast<TaskPeriod>(Utilities::ToUnderlying(TaskPeriod::Count) - 1)) != std::chrono::milliseconds{0}, "");
}
constexpr std::chrono::milliseconds TaskPeriodToMilliseconds(TaskPeriod period)
{
	return Detail::TaskPeriodToMillisecondsConverter{}.Convert(period);
}
}
