/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Binary Data Converter

#pragma once

#include "IBinaryDataConverter.h"
#include "IFaultAlgorithm.h"
#include <memory>

namespace Shark
{
class BinaryDataConverter : public IBinaryDataConverter
{
public:
	BinaryDataConverter(std::unique_ptr<IFaultAlgorithm>&& spFaultAlgorithm) noexcept;
// IBinaryDataConverter
	std::optional<double> ConvertUint64(std::optional<uint64_t> data, BitwiseSharkByteDefinition const& definition) const override;
	std::optional<double> ConvertMBuf(J1939::MbufWrapper mbuf, BitwiseSharkByteDefinition const& definition) const override;
private:
	std::optional<double> ScaleAndOffsetData(std::optional<uint32_t> rawValue, BitwiseSharkByteDefinition const& definition) const;

	std::unique_ptr<IFaultAlgorithm> const m_spFaultAlgorithm;
};
}