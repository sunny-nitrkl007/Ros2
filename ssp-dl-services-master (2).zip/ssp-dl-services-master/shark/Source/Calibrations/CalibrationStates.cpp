/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See CalibrationStates.h

#include "CalibrationStates.h"
#include <cassert>

namespace Shark
{
namespace Calibrations
{
CalibrationStateBase::CalibrationStateBase(ICalibrationWrapper& calibrationWrapper, State state)
	: m_calibrationWrapper(calibrationWrapper)
	, m_state(state)
{
	assert(m_state < State::Count);
}
State CalibrationStateBase::Engage(CalibrationConfig const&) { return m_state; }
State CalibrationStateBase::FinishedServiceTest() { return m_state; }
State CalibrationStateBase::Abort() { return m_state; }
State CalibrationStateBase::RequestProceed() { return m_state; }
State CalibrationStateBase::Disengage() { return m_state; }
State CalibrationStateBase::OnStatusReceived(uint_least8_t) { return m_state; }

DisabledState::DisabledState(ICalibrationWrapper& calibrationWrapper)
	: CalibrationStateBase(calibrationWrapper, State::Disabled)
{
}
State DisabledState::Engage(CalibrationConfig const& calibrationConfig)
{
	m_calibrationWrapper.InitializeAndStartService(calibrationConfig);
	return GetState();
}
State DisabledState::OnStatusReceived(uint_least8_t status)
{
	State newState = GetState();
	switch (status)
	{
		case SCL_CAL_CLIENT_STAT_ENABLED_START_WAIT:
			newState = State::Enabled;
			break;
		case SCL_CAL_CLIENT_STAT_SUCCESS_NO_ERR_WARN:
		case SCL_CAL_CLIENT_STAT_SUCCESS_WITH_ERR_WARN:
		case SCL_CAL_CLIENT_STAT_FAIL:
		case SCL_CAL_CLIENT_STAT_TIMEOUT:
		case SCL_CAL_CLIENT_STAT_INIT_ERR:
			newState = State::Completed;
			break;
		default:
			break;
	}

	return newState;
}

EnabledState::EnabledState(ICalibrationWrapper& calibrationWrapper)
	: CalibrationStateBase(calibrationWrapper, State::Enabled)
{
}
State EnabledState::Abort()
{
	m_calibrationWrapper.AbortService();
	return GetState();
}
State EnabledState::RequestProceed()
{
	m_calibrationWrapper.SendCommand(SCL_CAL_CLIENT_AC_START);
	return GetState();
}
State EnabledState::OnStatusReceived(uint_least8_t status)
{
	State newState = GetState();
	switch (status)
	{
		case SCL_CAL_CLIENT_STAT_EXEC:
		case SCL_CAL_CLIENT_STAT_EXEC_BUSY:
			newState = DetermineExecutingState();
			break;
		case SCL_CAL_CLIENT_STAT_SUCCESS_NO_ERR_WARN:
		case SCL_CAL_CLIENT_STAT_SUCCESS_WITH_ERR_WARN:
		case SCL_CAL_CLIENT_STAT_FAIL:
		case SCL_CAL_CLIENT_STAT_TIMEOUT:
			newState = State::Completed;
			break;
		default:
			break;
	}

	return newState;
}
State EnabledState::DetermineExecutingState() const
{
	auto newState = State::ExecutingCalibration;
	auto const activeType = m_calibrationWrapper.ActiveType();
	if (activeType == Type::ServiceTest)
	{
		newState = State::ExecutingServiceTest;
	}
	else
	{
		assert(activeType == Type::Calibration);
	}

	return newState;
}

ExecutingStateBase::ExecutingStateBase(ICalibrationWrapper& calibrationWrapper, State state)
	: CalibrationStateBase(calibrationWrapper, state)
{
}
State ExecutingStateBase::Abort()
{
	m_calibrationWrapper.AbortService();
	return GetState();
}
State ExecutingStateBase::RequestProceed()
{
	m_calibrationWrapper.SendCommand(SCL_CAL_CLIENT_AC_CONTINUE);
	return GetState();
}
State ExecutingStateBase::OnStatusReceived(uint_least8_t status)
{
	State newState = GetState();
	switch (status)
	{
		case SCL_CAL_CLIENT_STAT_SUCCESS_NO_ERR_WARN:
		case SCL_CAL_CLIENT_STAT_SUCCESS_WITH_ERR_WARN:
		case SCL_CAL_CLIENT_STAT_FAIL:
		case SCL_CAL_CLIENT_STAT_TIMEOUT:
			newState = State::Completed;
			break;
		default:
			break;
	}

	return newState;
}

ExecutingCalibrationState::ExecutingCalibrationState(ICalibrationWrapper& calibrationWrapper)
	: ExecutingStateBase(calibrationWrapper, State::ExecutingCalibration)
{
}

ExecutingServiceTestState::ExecutingServiceTestState(ICalibrationWrapper& calibrationWrapper)
	: ExecutingStateBase(calibrationWrapper, State::ExecutingServiceTest)
{
}
State ExecutingServiceTestState::FinishedServiceTest()
{
	m_calibrationWrapper.SendCommand(SCL_CAL_CLIENT_AC_STOP_SRVTST);
	return GetState();
}

CompletedState::CompletedState(ICalibrationWrapper& calibrationWrapper)
	: CalibrationStateBase(calibrationWrapper, State::Completed)
{
}
State CompletedState::Disengage()
{
	m_calibrationWrapper.StopService();
	return GetState();
}
State CompletedState::OnStatusReceived(uint_least8_t status)
{
	State newState = GetState();
	if (status == SCL_CAL_CLIENT_STAT_DISABLED || status == SCL_CAL_CLIENT_STAT_DISABLE_ACTION_FAIL)
	{
		m_calibrationWrapper.DeinitializeService();
		newState = State::Disabled;
	}

	return newState;
}
}
}
