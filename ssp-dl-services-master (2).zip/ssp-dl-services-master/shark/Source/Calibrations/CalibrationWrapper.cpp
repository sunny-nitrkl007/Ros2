/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See CalibrationWrapper.h

#include "CalibrationWrapper.h"
#include "CalibrationStates.h"
#include "Config/ProtobufConversions.h"
#include "DependencyContainer.h"
#include "SharkByteDetails.h"
#include "IPeriodicTaskManager.h"
#include "J1939/IJ1939Wrapper.h"
#include "J1939/J1939Definitions.h"
#include "Log.h"
#include "SharkBytes/AsynchronousValueWriteSlot.h"
#include "SharkBytes/ISharkByteManager.h"
#include "SharkBytes/IWriteSharkByteManager.h"
#include <SharkConfiguration.pb.h>
#include <Utilities/CountOf.h>
#include <Utilities/IndexOf.h>
#include <Utilities/narrow_cast.h>
#include <Utilities/nice_ptr.h>
#include <Utilities/ToUnderlying.h>
#include <Utilities/SharkBytes/SimpleSharkByte.h>
#include <boost/algorithm/string/predicate.hpp>
#include <concepts>
#include <limits>
#include <nlohmann/json.hpp>
#include <sstream>

using Utilities::CountOf;
using Utilities::narrow_cast;
using Utilities::ToUnderlying;

namespace Shark
{
using namespace SharkByteDetails::Calibrations;

namespace Calibrations
{
namespace
{
class CalibrationCommandProcessor
{
public:
	explicit CalibrationCommandProcessor(ICalibrationWrapper& calibrationWrapper)
		: m_calibrationWrapper(calibrationWrapper)
	{
	}
	void ProcessCommand(std::vector<uint8_t> const& value, auto&& completedCallback) const
	{
		auto isValidCommand = false;
		auto commandName = std::string{};
		try
		{
			auto const json = nlohmann::json::parse(value.begin(), value.end());
			if (json.is_object() && json.contains(Command::FieldCommand()) && json[Command::FieldCommand()].is_string())
			{
				commandName = json[Command::FieldCommand()].get<std::string>();
				isValidCommand = ProcessParsedCommand(commandName, json);
			}
		}
		catch (nlohmann::json::exception const&)
		{
			isValidCommand = false;
		}

		if (!isValidCommand)
		{
			std::string valueString(value.begin(), value.end());
			LOG_WARNING_TAG(Log::Calibrations, "Invalid command: " << valueString);
		}
		m_calibrationWrapper.AddToQueuedWork(
			[completedCallback = std::move(completedCallback), isValidCommand]()
			{
				completedCallback(isValidCommand ? Shark::TrueSharkByteValue() : Shark::FalseSharkByteValue());
			});
	}
private:
	bool ProcessParsedCommand(std::string const& commandName, nlohmann::json const& json) const
	{
		auto isValidCommand = true;
		if (commandName == Command::Engage())
		{
			isValidCommand = ProcessEngageCommand(json);
		}
		else if (commandName == Command::FinishedServiceTest())
		{
			m_calibrationWrapper.FinishedServiceTest();
		}
		else if (commandName == Command::Abort())
		{
			m_calibrationWrapper.Abort();
		}
		else if (commandName == Command::Proceed())
		{
			m_calibrationWrapper.RequestProceed();
		}
		else if (commandName == Command::Disengage())
		{
			m_calibrationWrapper.Disengage();
		}
		else if (commandName == Command::YesAffirmation())
		{
			m_calibrationWrapper.AffirmationCommand(AffirmationCommandType::Yes);
		}
		else if (commandName == Command::NoAffirmation())
		{
			m_calibrationWrapper.AffirmationCommand(AffirmationCommandType::No);
		}
		else if (commandName == Command::GoToStep())
		{
			isValidCommand = ProcessGoToStepCommand(json);
		}
		else if (commandName == Command::CommandButton())
		{
			isValidCommand = ProcessCommandButtonCommand(json);
		}
		else if (commandName == Command::RevertToDefaultValues())
		{
			m_calibrationWrapper.RevertToDefaultValues();
		}
		else
		{
			static constexpr char const* s_incrementalCommands[]
			{
				Command::SmallIncrement(),
				Command::SmallDecrement(),
				Command::LargeIncrement(),
				Command::LargeDecrement(),
			};
			static_assert(CountOf(s_incrementalCommands) == ToUnderlying(IncrementalCommandType::Count), "Size mismatch");

			unsigned index{};
			try
			{
				index = Utilities::IndexOf(s_incrementalCommands, commandName);
			}
			catch (std::exception&)
			{
				isValidCommand = false;
			}

			if (isValidCommand)
			{
				auto const command = static_cast<IncrementalCommandType>(index);
				m_calibrationWrapper.IncrementalCommand(command);
			}
		}

		return isValidCommand;
	}
	bool ProcessEngageCommand(nlohmann::json const& json) const
	{
		auto isValidCommand = false;
		if (json.contains(Command::FieldContext()) && json[Command::FieldContext()].is_string())
		{
			auto const calibrationName = json[Command::FieldContext()].get<std::string>();
			isValidCommand = m_calibrationWrapper.Engage(calibrationName);
		}
		return isValidCommand;
	}
	bool ProcessGoToStepCommand(nlohmann::json const& json) const
	{
		auto const result = ReadUnsignedContext<uint_least16_t>(json);
		if (result.has_value())
		{
			auto const stepNumber = result.value();
			m_calibrationWrapper.GoToStep(stepNumber);
		}
		return result.has_value();
	}
	bool ProcessCommandButtonCommand(nlohmann::json const& json) const
	{
		auto const result = ReadUnsignedContext<uint8_t>(json);
		if (result.has_value())
		{
			auto const buttonNumber = result.value();
			m_calibrationWrapper.CommandButton(buttonNumber);
		}
		return result.has_value();
	}
	template<std::unsigned_integral T>
	std::optional<T> ReadUnsignedContext(nlohmann::json const& json) const
	{
		std::optional<T> result{};
		if (json.contains(Command::FieldContext()) && json[Command::FieldContext()].is_number_unsigned())
		{
			auto const context = json[Command::FieldContext()].get<uint64_t>();
			if (context <= std::numeric_limits<T>::max())
			{
				result = static_cast<T>(context);
			}
		}
		return result;
	}

	ICalibrationWrapper& m_calibrationWrapper;
};

constexpr char const* GetStatusString(uint_least8_t status)
{
	static constexpr char const* s_pStatusStrings[]
	{
		"ENABLED_START_WAIT",
		"EXEC",
		"EXEC_BUSY",
		"SUCCESS_NO_ERR_WARN",
		"SUCCESS_WITH_ERR_WARN",
		"FAIL",
		"INIT_ERR",
		"LAST_CAL_SUCCESS_NO_ERR_WARN",
		"LAST_CAL_SUCCESS_WITH_ERR_WARN",
		"LAST_CAL_FAIL",
		"TIMEOUT",
		"DISABLED",
		"START_ACTION_FAIL",
		"ABORT_ACTION_FAIL",
		"DISABLE_ACTION_FAIL",
		"LAST_CAL_ACTION_FAIL",
		"ACTION_FAIL",
		"PEER_NOT_AVAILABLE"
	};
	assert(status < CountOf(s_pStatusStrings));

	return s_pStatusStrings[status];
}
void DumpStatusData(
	uint_least16_t cal_or_srvtst_id,
	uint_least8_t status,
	uint_least16_t step_no,
	uint_least16_t const *err_warn,
	uint_least8_t err_warn_count)
{
	auto constexpr severity = Log::SeverityLevel::Debug;
	if (Log::ShouldLog(severity, Log::Calibrations))
	{
		std::stringstream errorStream{};
		if (err_warn_count > 0)
		{
			errorStream << static_cast<unsigned>(err_warn_count) << " Errors: " << std::hex << std::uppercase;
			for (auto i = 0u; i < err_warn_count; ++i)
			{
				errorStream << err_warn[i] << " ";
			}
		}

		LOG_TAG(severity, Log::Calibrations,
			"ID: " << std::hex << std::uppercase << cal_or_srvtst_id << " "
			"Status: " << GetStatusString(status) << " "
			"Step: " << std::dec << step_no << " - " <<
			errorStream.str());
	}
}
constexpr char const* GetStatusSharkByteValue(uint_least8_t status)
{
	static constexpr char const* s_statusToString[]
	{
		Status::StatusInitialized(),
		Status::StatusExecuting(),
		Status::StatusBusy(),
		Status::StatusSucceeded(),
		Status::StatusSucceeded(),
	};

	char const* result = Status::StatusFailed();
	if (status < CountOf(s_statusToString))
	{
		result = s_statusToString[status];
	}

	return result;
}
constexpr char const* GetTypeSharkByteValue(Type type)
{
	static constexpr char const* s_typeToString[]
	{
		Status::TypeCalibration(),
		Status::TypeServiceTest(),
	};

	char const* result = "";
	auto const unsignedType = static_cast<unsigned>(type);
	if (unsignedType < CountOf(s_typeToString))
	{
		result = s_typeToString[unsignedType];
	}

	return result;
}

bool J1939DataLinkConfigHasCalibrations(cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	auto const& peerNodes = j1939DataLinkConfig.peer_nodes();
	return std::any_of(peerNodes.begin(),peerNodes.end(),
		[](auto const& peerNode)
		{
			return peerNode.has_calibration_services() &&
			       (peerNode.calibration_services().calibrations().size() > 0 ||
			        peerNode.calibration_services().service_tests().size() > 0);
		});
}
void CreateCalibrationConfigs(
	cat::shark::J1939DataLink const& j1939DataLinkConfig,
	CalibrationConfigs& calibrationConfigs)
{
	auto const canPort = Config::ToConfigCanPort(j1939DataLinkConfig.can_port());
	auto const& peerNodes = j1939DataLinkConfig.peer_nodes();
	for (auto const& peerNode : peerNodes)
	{
		auto const sourceAddress = peerNode.address();
		if (peerNode.has_calibration_services())
		{
			auto const addServices = [canPort, sourceAddress, &calibrationConfigs](auto const& services, Type type)
			{
				for (auto const& service : services)
				{
					calibrationConfigs.emplace_back(CalibrationConfig{
						canPort,
						Utilities::narrow_cast<uint_least8_t>(sourceAddress),
						type,
						Utilities::narrow_cast<uint_least16_t>(service.index()),
						service.middleware_id().c_str()});
				}
			};

			auto const& calibrationServices = peerNode.calibration_services();
			addServices(calibrationServices.calibrations(), Type::Calibration);
			addServices(calibrationServices.service_tests(), Type::ServiceTest);
		}
	}
}
constexpr auto n_taskPeriod = TaskPeriod::Is100ms;
}

std::ostream& operator<<(std::ostream& stream, State state)
{
	static constexpr char const* s_stateNames[]
	{
		"Disabled",
		"Enabled",
		"ExecutingCalibration",
		"ExecutingServiceTest",
		"Completed",
	};
	static_assert(CountOf(s_stateNames) == ToUnderlying(State::Count), "Size mismatch");

	assert(state < State::Count);
	stream << s_stateNames[ToUnderlying(state)];
	return stream;
}

bool CalibrationWrapper::ShouldBeCreated(DependencyContainer const& dependencyContainer)
{
	auto const& configs = dependencyContainer.GetJ1939DataLinkConfigs();
	return std::any_of(configs.begin(), configs.end(),
		[](auto const& spJ1939DataLinkConfig)
		{
			return J1939DataLinkConfigHasCalibrations(*spJ1939DataLinkConfig);
		});
}
std::function<void()> CalibrationWrapper::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	auto& periodicTaskManager = dependencyContainer.GetIPeriodicTaskManager();
	auto& sharkByteManager = dependencyContainer.GetISharkByteManager();
	auto& writeSharkByteManager = dependencyContainer.GetIWriteSharkByteManager();

	CalibrationConfigs calibrationConfigs{};
	std::array<Utilities::nice_ptr<J1939::IJ1939Wrapper>, Config::CanPortCount> j1939Wrappers{};
	for (auto const& spJ1939DataLinkConfig : dependencyContainer.GetJ1939DataLinkConfigs())
	{
		if (J1939DataLinkConfigHasCalibrations(*spJ1939DataLinkConfig))
		{
			CreateCalibrationConfigs(*spJ1939DataLinkConfig, calibrationConfigs);
			auto const canPort = Config::ToConfigCanPort(spJ1939DataLinkConfig->can_port());
			j1939Wrappers[canPort] = &dependencyContainer.GetIJ1939Wrapper(canPort);
		}
	}

	auto spStatusSharkByte = std::make_unique<Utilities::SimpleSharkByte>(Status::SharkByteId());

	auto spCalibrationWrapper = std::make_shared<CalibrationWrapper>(
		std::move(calibrationConfigs),
		*spStatusSharkByte);
	AddPeriodicTask(periodicTaskManager, *spCalibrationWrapper);

	sharkByteManager.AddSharkByte(std::move(spStatusSharkByte));

	auto stateArray = std::array<std::unique_ptr<ICalibrationState>, ToUnderlying(State::Count)>{
		std::make_unique<DisabledState>(*spCalibrationWrapper),
		std::make_unique<EnabledState>(*spCalibrationWrapper),
		std::make_unique<ExecutingCalibrationState>(*spCalibrationWrapper),
		std::make_unique<ExecutingServiceTestState>(*spCalibrationWrapper),
		std::make_unique<CompletedState>(*spCalibrationWrapper)};
	States states{std::make_move_iterator(stateArray.begin()), std::make_move_iterator(stateArray.end())};

	spCalibrationWrapper->SetStates(std::move(states));

	CalibrationCommandProcessor commandProcessor(*spCalibrationWrapper);
	writeSharkByteManager.AddWriteSharkByte(std::make_unique<Shark::SharkBytes::AsynchronousValueWriteSlot>(
		Command::SharkByteId(),
		[commandProcessor](auto&& value, auto&& completedCallback)
		{
			commandProcessor.ProcessCommand(value, completedCallback);
		}));
	return [spCalibrationWrapper, j1939Wrappers]{ spCalibrationWrapper->Initialize(j1939Wrappers); };
}
void CalibrationWrapper::AddPeriodicTask(IPeriodicTaskManager& periodicTaskManager, CalibrationWrapper& calibrationWrapper)
{
	periodicTaskManager.Add(
		n_taskPeriod,
		[&calibrationWrapper]
		{
			calibrationWrapper.Update();
		});
}

CalibrationWrapper::CalibrationWrapper(
	CalibrationConfigs&& calibrationConfigs,
	Utilities::SimpleSharkByte& statusSharkByte)
	: m_calibrationConfigs(std::move(calibrationConfigs))
	, m_statusSharkByte(statusSharkByte)
{
	m_linkIndexes.fill(s_invalidIndex);
	assert(!m_calibrationConfigs.empty());
	assert(!m_statusSharkByte.Value());
}
void CalibrationWrapper::SetStates(States&& states)
{
	assert(m_states.empty());
	assert(states.size() == ToUnderlying(State::Count));
	m_states = std::move(states);
}
void CalibrationWrapper::Initialize(J1939Wrappers const& j1939Wrappers)
{
	scl_cal_client_init();
	for (auto const& spJ1939Wrapper : j1939Wrappers)
	{
		if (spJ1939Wrapper)
		{
			auto const canPort = spJ1939Wrapper->GetCanPort();
			assert(m_linkIndexes[canPort] == s_invalidIndex);

			scl_cal_client_status_t status{};
			m_linkIndexes[canPort] = scl_cal_client_link_add_j1939(
				spJ1939Wrapper->GetLink(),
				J1939::J1939Definitions::VirtualEcmIndex(),
				&status);
			if (status != SCL_CAL_CLIENT_SUCCESS)
			{
				throw Error("scl_cal_client_link_add_j1939 failed");
			}
		}
	}
}
bool CalibrationWrapper::Engage(std::string_view calibrationName)
{
	auto isValidCommand = false;
	auto const iterEnd = m_calibrationConfigs.end();
	auto const iterFound = std::find_if(m_calibrationConfigs.begin(), iterEnd,
		[calibrationName](auto const& config)
		{
			return config.pCalibrationName == calibrationName;
		});
	if (iterFound != iterEnd)
	{
		ChangeState(GetCurrentState().Engage(*iterFound));
		isValidCommand = true;
	}
	return isValidCommand;
}
void CalibrationWrapper::FinishedServiceTest()
{
	ChangeState(GetCurrentState().FinishedServiceTest());
}
void CalibrationWrapper::Abort()
{
	ChangeState(GetCurrentState().Abort());
}
void CalibrationWrapper::RequestProceed()
{
	ChangeState(GetCurrentState().RequestProceed());
}
void CalibrationWrapper::AffirmationCommand(AffirmationCommandType type)
{
	auto const command = (type == AffirmationCommandType::Yes) ? SCL_CAL_CLIENT_AC_YES : SCL_CAL_CLIENT_AC_NO;
	SendCommand(command);
}
void CalibrationWrapper::IncrementalCommand(IncrementalCommandType type)
{
	auto const command = narrow_cast<scl_cal_client_ac_t>(ToUnderlying(type) + SCL_CAL_CLIENT_AC_INCR_SMALL_1);
	SendCommand(command);
}
void CalibrationWrapper::GoToStep(uint_least16_t stepNumber)
{
	SendCommandWithData(
		SCL_CAL_CLIENT_AC_GOTO,
		// Send data MSB first since that's how the calibration client expects it
		std::vector<uint8_t>{static_cast<uint8_t>((stepNumber >> 8) & 0xFF), static_cast<uint8_t>(stepNumber & 0xFF)});
}
void CalibrationWrapper::CommandButton(uint8_t buttonNumber)
{
	SendCommandWithData(SCL_CAL_CLIENT_AC_CMD_BTN, {buttonNumber});
}
void CalibrationWrapper::RevertToDefaultValues()
{
	SendCommand(SCL_CAL_CLIENT_AC_REV_DEF_VAL);
}
void CalibrationWrapper::Disengage()
{
	ChangeState(GetCurrentState().Disengage());
}
void CalibrationWrapper::AddToQueuedWork(std::function<void()>&& work)
{
	m_workQueue.Push(std::move(work));
}
void CalibrationWrapper::InitializeAndStartService(CalibrationConfig const& calibrationConfig)
{
	m_workQueue.Push([this, calibrationConfig]
	{
		assert(calibrationConfig.type < Type::Count);
		assert( (m_peerIndex == s_invalidIndex) && (m_serviceIndex == s_invalidIndex) );

		m_statusSharkByte.SetInvalid();

		LOG_INFO_LOW_TAG(Log::Calibrations, "Adding peer: 0x" << std::hex << calibrationConfig.sourceAddress);

		scl_cal_client_status_t peerStatus{};
		m_peerIndex = scl_cal_client_link_add_peer_by_addr(
			m_linkIndexes[calibrationConfig.canPort], calibrationConfig.sourceAddress, &peerStatus);
		if (peerStatus != SCL_CAL_CLIENT_SUCCESS)
		{
			throw Error("scl_cal_client_link_add_peer_by_addr failed");
		}

		LOG_INFO_LOW_TAG(Log::Calibrations, "Adding service: " << (calibrationConfig.type == Type::Calibration ? "Calibration" : "Service Test"));
		scl_cal_client_svc_types_t const sclType =
			(calibrationConfig.type == Type::Calibration) ? SCL_CAL_CLIENT_SVC_TYPE_CAL : SCL_CAL_CLIENT_SVC_TYPE_SRVTST;
		scl_cal_client_status_t serviceStatus{};
		m_serviceIndex = scl_cal_client_peer_add_svc(m_peerIndex, sclType, &StatusCallback, this, &serviceStatus);
		if (serviceStatus != SCL_CAL_CLIENT_SUCCESS)
		{
			throw Error("scl_cal_client_peer_add_svc failed");
		}

		LOG_INFO_LOW_TAG(Log::Calibrations, "Starting service for id 0x" << std::hex << calibrationConfig.id);
		auto const startResult = scl_cal_client_start_svc(calibrationConfig.id, m_serviceIndex);
		if (startResult != SCL_CAL_CLIENT_SUCCESS)
		{
			throw Error("scl_cal_client_start_svc failed");
		}

		m_activeConfig = calibrationConfig;
	});
}
void CalibrationWrapper::SendCommand(scl_cal_client_ac_t command)
{
	SendCommandWithData(command, {0});
}
void CalibrationWrapper::SendCommandWithData(scl_cal_client_ac_t command, std::vector<uint8_t> const& data)
{
	m_workQueue.Push([this, command, data]
	{
		LOG_INFO_LOW_TAG(Log::Calibrations, "Sending command 0x" << std::hex << command << " with data size " << std::dec << data.size());

		auto const result = scl_cal_client_user_action(command, const_cast<uint8_t*>(data.data()), narrow_cast<uint_least8_t>(data.size()), m_serviceIndex);
		if (result == SCL_CAL_CLIENT_ERR_SVC_QUEUE_FULL)
		{
			LOG_WARNING_TAG(Log::Calibrations, "Ignoring command 0x" << std::hex << command << " since the queue is full");
		}
		else if (result != SCL_CAL_CLIENT_SUCCESS)
		{
			auto const unsignedResult = static_cast<unsigned>(result); // Prints as a char if leaving as a uint8_t
			throw Error("scl_cal_client_user_action failed: " + To<std::string>(unsignedResult));
		}
	});
}
void CalibrationWrapper::AbortService()
{
	m_workQueue.Push([this]
	{
		LOG_INFO_LOW_TAG(Log::Calibrations, "Aborting...");
		auto const result = scl_cal_client_abort_svc(m_serviceIndex);
		if (result != SCL_CAL_CLIENT_SUCCESS)
		{
			throw Error("scl_cal_client_abort_svc");
		}
	});
}
void CalibrationWrapper::StopService()
{
	m_workQueue.Push([this]
	{
		LOG_INFO_LOW_TAG(Log::Calibrations, "Ending service");
		auto const endResult = scl_cal_client_end_svc(m_serviceIndex);
		if (endResult != SCL_CAL_CLIENT_SUCCESS)
		{
			throw Error("scl_cal_client_end_svc failed");
		}
		m_serviceIndex = s_invalidIndex;
	});
}
void CalibrationWrapper::DeinitializeService()
{
	m_workQueue.Push([this]
	{
		LOG_INFO_LOW_TAG(Log::Calibrations, "Removing peer");
		auto const removeResult = scl_cal_client_remove_peer(m_peerIndex);
		if (removeResult != SCL_CAL_CLIENT_SUCCESS)
		{
			throw Error("scl_cal_client_remove_peer failed");
		}
		m_peerIndex = s_invalidIndex;
		m_activeConfig.reset();
	});
}
Type CalibrationWrapper::ActiveType() const
{
	if (!m_activeConfig)
	{
		throw std::runtime_error("ActiveType() called when nothing was active!");
	}

	return m_activeConfig->type;
}
void CalibrationWrapper::Update()
{
	// Only execute one piece of work each time. Any more can mess up scl_cal_client.
	m_workQueue.ExecuteOne();
	scl_cal_client_update();
}
ICalibrationState& CalibrationWrapper::GetCurrentState()
{
	assert(m_currentState < State::Count);
	return *m_states[ToUnderlying(m_currentState)];
}
void CalibrationWrapper::ChangeState(State state)
{
	if (state != m_currentState)
	{
		LOG_INFO_LOW_TAG(Log::Calibrations, "Changing state: " << m_currentState << " to " << state);
		m_currentState = state;
	}
}
void CalibrationWrapper::StatusCallback(
	uint_least16_t cal_or_srvtst_id,
	uint_least8_t status,
	uint_least16_t step_no,
	uint_least16_t const* err_warn,
	uint_least8_t err_warn_count,
	void* status_context)
{
	DumpStatusData(cal_or_srvtst_id, status, step_no, err_warn, err_warn_count);

	auto const pCalibrationWrapper = static_cast<CalibrationWrapper*>(status_context);
	assert(pCalibrationWrapper);
	pCalibrationWrapper->InternalStatusCallback(status, step_no, err_warn, err_warn_count);
}
void CalibrationWrapper::InternalStatusCallback(
	uint_least8_t status,
	uint_least16_t step_no,
	uint_least16_t const* err_warn,
	uint_least8_t err_warn_count)
{
	if (status != SCL_CAL_CLIENT_STAT_DISABLED)
	{
		nlohmann::json document;

		if (m_activeConfig)
		{
			document[Status::FieldName()] = m_activeConfig->pCalibrationName;
			document[Status::FieldType()] = GetTypeSharkByteValue(m_activeConfig->type);
		}

		document[Status::FieldStep()] = step_no;
		document[Status::FieldStatus()] = GetStatusSharkByteValue(status);
		document[Status::FieldErrors()] = std::vector<uint_least16_t>(err_warn, err_warn + err_warn_count);

		auto const jsonString = document.dump();
		std::vector<uint8_t> jsonData(jsonString.begin(), jsonString.end());
		m_statusSharkByte.SetValue(jsonData);
	}
	else
	{
		m_statusSharkByte.SetInvalid();
	}

	ChangeState(GetCurrentState().OnStatusReceived(status));
}
}
}

// There is no CDL on D6:Cx so this is needed to make everything link.
#include <cdl2_proto.h>
int_32 cdl2_transmit(unsigned_8*)
{
	assert(false); // This should never be called!
	return 1;
}