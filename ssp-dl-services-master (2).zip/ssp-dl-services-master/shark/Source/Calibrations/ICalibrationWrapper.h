/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Calibration and Service Test Wrapper Interface

#pragma once

#include "Config/CanPort.h"
#include <Utilities/DefineExceptionClass.h>
#include <compare>
#include <scl_cal_client.h>
#include <cstring>
#include <string_view>

namespace Shark
{
class DependencyContainer;

namespace Calibrations
{
enum class Type
{
	Calibration,
	ServiceTest,

	Count
};
enum class AffirmationCommandType
{
	Yes,
	No,

	Count
};
enum class IncrementalCommandType
{
	SmallIncrement,
	SmallDecrement,
	LargeIncrement,
	LargeDecrement,

	Count
};
struct CalibrationConfig
{
	Config::CanPort canPort;
	uint_least8_t sourceAddress;
	Type type;
	uint_least16_t id;
	std::string pCalibrationName;

	auto operator<=>(CalibrationConfig const&) const = default;
};

class ICalibrationWrapper
{
public:
	virtual ~ICalibrationWrapper() = default;

	DEFINE_EXCEPTION_CLASS(Error);

	/// \exception ICalibrationWrapper::Error
	///		Thrown when an unrecoverable error occurs in the SCL Calibration Client library

	// Called by External Client (through middleware)
	virtual bool Engage(std::string_view calibrationName) = 0;
	virtual void FinishedServiceTest() = 0;
	virtual void Abort() = 0;
	virtual void RequestProceed() = 0;
	virtual void AffirmationCommand(AffirmationCommandType type) = 0;
	virtual void IncrementalCommand(IncrementalCommandType type) = 0;
	virtual void GoToStep(uint_least16_t stepNumber) = 0;
	virtual void CommandButton(uint8_t buttonNumber) = 0;
	virtual void RevertToDefaultValues() = 0;
	virtual void Disengage() = 0;
	virtual void AddToQueuedWork(std::function<void()>&& work) = 0;

	// Called by states
	virtual void InitializeAndStartService(CalibrationConfig const& calibrationConfig) = 0;
	virtual void SendCommand(scl_cal_client_ac_t command) = 0;
	virtual void SendCommandWithData(scl_cal_client_ac_t command, std::vector<uint8_t> const& data) = 0;
	virtual void AbortService() = 0;
	virtual void StopService() = 0;
	virtual void DeinitializeService() = 0;

	/// Throws if there is not an active service
	virtual Type ActiveType() const = 0;
};
}
}
