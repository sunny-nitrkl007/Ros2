/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Calibration and Service Test State Machine Interface

#pragma once

#include "ICalibrationWrapper.h"

namespace Shark
{
namespace Calibrations
{
enum class State : unsigned
{
	Disabled,
	Enabled,
	ExecutingCalibration,
	ExecutingServiceTest,
	Completed,

	Count
};

class ICalibrationState
{
public:
	virtual ~ICalibrationState() = default;

	virtual State Engage(CalibrationConfig const& calibrationConfig) = 0;
	virtual State FinishedServiceTest() = 0;
	virtual State Abort() = 0;
	virtual State RequestProceed() = 0;
	virtual State Disengage() = 0;
	virtual State OnStatusReceived(uint_least8_t status) = 0;
};
}
}
