/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Common Services scl_cal_client Wrapper

#pragma once

#include "ICalibrationWrapper.h"
#include "ICalibrationState.h"
#include "WorkQueue.h"
#include <array>
#include <memory>
#include <optional>
#include <vector>

namespace Utilities
{
class SimpleSharkByte;
}

namespace Shark
{
class IPeriodicTaskManager;
class ISharkByteManager;
class IWriteSharkByteManager;

namespace J1939 { class IJ1939Wrapper; }

namespace Calibrations
{
using CalibrationConfigs = std::vector<CalibrationConfig>;

class CalibrationWrapper final : public ICalibrationWrapper
{
public:
	using States = std::vector<std::unique_ptr<ICalibrationState>>;
	using J1939Wrappers = std::array<Utilities::nice_ptr<J1939::IJ1939Wrapper>, Config::CanPortCount>;

	static bool ShouldBeCreated(DependencyContainer const& dependencyContainer);
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);
	static void AddPeriodicTask(IPeriodicTaskManager& periodicTaskManager, CalibrationWrapper& calibrationWrapper);

	CalibrationWrapper(
		CalibrationConfigs&& calibrationConfigs,
		Utilities::SimpleSharkByte& statusSharkByte);
	void SetStates(States&& states);
	void Initialize(J1939Wrappers const& j1939Wrappers);

	// ICalibrationWrapper
	bool Engage(std::string_view calibrationName) override;
	void FinishedServiceTest() override;
	void Abort() override;
	void RequestProceed() override;
	void AffirmationCommand(AffirmationCommandType type) override;
	void IncrementalCommand(IncrementalCommandType type) override;
	void GoToStep(uint_least16_t stepNumber) override;
	void CommandButton(uint8_t buttonNumber) override;
	void RevertToDefaultValues() override;
	void Disengage() override;
	void AddToQueuedWork(std::function<void()>&& work) override;

	void InitializeAndStartService(CalibrationConfig const& calibrationConfig) override;
	void SendCommand(scl_cal_client_ac_t command) override;
	void SendCommandWithData(scl_cal_client_ac_t command, std::vector<uint8_t> const& data) override;
	void AbortService() override;
	void StopService() override;
	void DeinitializeService() override;
	Type ActiveType() const override;
private:
	static constexpr uint_least8_t s_invalidIndex = 0xFF;

	static void StatusCallback(
		uint_least16_t cal_or_srvtst_id,
		uint_least8_t status,
		uint_least16_t step_no,
		uint_least16_t const* err_warn,
		uint_least8_t err_warn_count,
		void* status_context);
	void InternalStatusCallback(
		uint_least8_t status,
		uint_least16_t step_no,
		uint_least16_t const* err_warn,
		uint_least8_t err_warn_count);

	void Update();
	ICalibrationState& GetCurrentState();
	void ChangeState(State state);

	CalibrationConfigs const m_calibrationConfigs;
	Utilities::SimpleSharkByte& m_statusSharkByte;
	States m_states{};
	State m_currentState{State::Disabled};
	std::array<uint_least8_t, Config::CanPortCount> m_linkIndexes{};
	uint_least8_t m_peerIndex{s_invalidIndex};
	uint_least8_t m_serviceIndex{s_invalidIndex};
	std::optional<CalibrationConfig> m_activeConfig{};
	WorkQueue m_workQueue{};
};
}
}
