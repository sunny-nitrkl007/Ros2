/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Calibration and Service Test State Machine

#pragma once

#include "ICalibrationState.h"

namespace Shark
{
namespace Calibrations
{
class CalibrationStateBase : public ICalibrationState
{
public:
	State GetState() const { return m_state; }
// ICalibrationState
	virtual State Engage(CalibrationConfig const& calibrationConfig) override;
	virtual State FinishedServiceTest() override;
	virtual State Abort() override;
	virtual State RequestProceed() override;
	virtual State Disengage() override;
	virtual State OnStatusReceived(uint_least8_t status) override;
protected:
	CalibrationStateBase(ICalibrationWrapper& calibrationWrapper, State state);

	ICalibrationWrapper& m_calibrationWrapper;
private:
	State const m_state;
};

class DisabledState final : public CalibrationStateBase
{
public:
	DisabledState(ICalibrationWrapper& calibrationWrapper);
// CalibrationStateBase
	State Engage(CalibrationConfig const& calibrationConfig) override;
	State OnStatusReceived(uint_least8_t status) override;
};

class EnabledState final : public CalibrationStateBase
{
public:
	EnabledState(ICalibrationWrapper& calibrationWrapper);
// CalibrationStateBase
	State Abort() override;
	State RequestProceed() override;
	State OnStatusReceived(uint_least8_t status) override;
private:
	State DetermineExecutingState() const;
};

class ExecutingStateBase : public CalibrationStateBase
{
public:
// CalibrationStateBase
	State Abort() final;
	State RequestProceed() final;
	State OnStatusReceived(uint_least8_t status) final;
protected:
	ExecutingStateBase(ICalibrationWrapper& calibrationWrapper, State state);
};

class ExecutingCalibrationState final : public ExecutingStateBase
{
public:
	ExecutingCalibrationState(ICalibrationWrapper& calibrationWrapper);
};

class ExecutingServiceTestState final : public ExecutingStateBase
{
public:
	ExecutingServiceTestState(ICalibrationWrapper& calibrationWrapper);
// ExecutingStateBase
	State FinishedServiceTest() override;
};

class CompletedState final : public CalibrationStateBase
{
public:
	CompletedState(ICalibrationWrapper& calibrationWrapper);
// CalibrationStateBase
	State Disengage() override;
	State OnStatusReceived(uint_least8_t status) override;
};
}
}
