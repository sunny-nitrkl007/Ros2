/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Time Retriever Interface

#pragma once

#include <chrono>
#include <optional>

namespace Shark
{
class ISharkByteRetriever;
class IWriteSharkByteRetriever;

class ITimeRetriever
{
public:
	virtual ~ITimeRetriever() = default;

	virtual void Initialize(
		ISharkByteRetriever const& sharkByteRetriever,
		IWriteSharkByteRetriever const& writeSharkByteRetriever) = 0;
	virtual std::optional<std::chrono::seconds> TimeSinceMidnight() const = 0;
};
}
