/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See BinaryDataConverter.h

#include "BinaryDataConverter.h"
#include "Log.h"
#include "Utilities/narrow_cast.h"
#include <algorithm>

namespace Shark
{
namespace
{
uint64_t CreateDataMask(BitwiseSharkByteDefinition const& definition)
{
	uint64_t mask = static_cast<uint64_t>(~0);
	mask >>= sizeof(mask) * CHAR_BIT - definition.bitCount;
	mask <<= definition.bitOffset;

	return mask;
}
uint8_t CreateSingleByteMask(BitwiseSharkByteDefinition const& definition)
{
	auto mask = static_cast<uint32_t>(~0); // use uint32_t instead of uint8_t to avoid noisy cast warnings
	mask >>= sizeof(mask) * CHAR_BIT - definition.bitCount;
	mask <<= definition.bitOffset % CHAR_BIT;

	return Utilities::narrow_cast<uint8_t>(mask);
}
}
BinaryDataConverter::BinaryDataConverter(std::unique_ptr<IFaultAlgorithm>&& spFaultAlgorithm) noexcept
	: m_spFaultAlgorithm(std::move(spFaultAlgorithm))
{
}
std::optional<double> BinaryDataConverter::ConvertUint64(std::optional<uint64_t> data, BitwiseSharkByteDefinition const& definition) const
{
	assert(definition.bitOffset + definition.bitCount <= 64);

	std::optional<uint32_t> rawValue{};
	if (data)
	{
		rawValue.emplace(Utilities::narrow_cast<uint32_t>((data.value() & CreateDataMask(definition)) >> definition.bitOffset));

		if (definition.reverseBytes)
		{
			auto const pRawValueBegin = reinterpret_cast<unsigned char*>(&rawValue.value());
			std::reverse(pRawValueBegin, pRawValueBegin + definition.bitCount / CHAR_BIT);
		}
	}

	return ScaleAndOffsetData(rawValue, definition);
}
std::optional<double> BinaryDataConverter::ConvertMBuf(J1939::MbufWrapper mbuf, BitwiseSharkByteDefinition const& definition) const
{
	std::optional<uint32_t> rawValue{};

	if (mbuf.IsValid())
	{
		auto const startByteIndex = definition.bitOffset / CHAR_BIT;
		auto const byteCount = std::max(1u, definition.bitCount / CHAR_BIT);
		auto const mbufLength = mbuf.Length();

		if (startByteIndex + byteCount > mbufLength)
		{
			assert(!rawValue);
			LOG_WARNING("BinaryDataConverter: mbuf is too short (" << mbufLength << ") to extract " <<
				definition.bitCount << " bits at bit offset " << definition.bitOffset);
		}
		else
		{
			rawValue.emplace();
			auto const pDestination = reinterpret_cast<unsigned char*>(&rawValue.value());
			auto const succeeded = mbuf.GetBytes(startByteIndex, byteCount, pDestination);
			assert(succeeded); (void) succeeded;

			if (definition.bitCount < CHAR_BIT)
			{
				auto const mask = CreateSingleByteMask(definition);
				assert(mask < 0xFF);

				rawValue = (*pDestination & mask) >> (definition.bitOffset % CHAR_BIT);
			}
			else if (definition.reverseBytes)
			{
				std::reverse(pDestination, pDestination + byteCount);
			}
		}
	}

	return ScaleAndOffsetData(rawValue, definition);
}
std::optional<double> BinaryDataConverter::ScaleAndOffsetData(std::optional<uint32_t> rawValue, BitwiseSharkByteDefinition const& definition) const
{
	std::optional<double> result{};
	if (rawValue && m_spFaultAlgorithm->IsValid(*rawValue))
	{
		result = (Utilities::narrow_cast<double>(rawValue.value()) * definition.unitsPerBit) + definition.valueOffset;
	}

	return result;
}
}