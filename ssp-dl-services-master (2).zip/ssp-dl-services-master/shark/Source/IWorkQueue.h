/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Work Queue Interface

#pragma once

#include <functional>

namespace Shark
{
class IWorkQueue
{
public:
	virtual ~IWorkQueue() = default;

	virtual void Push(std::function<void()>&& function) = 0;
	virtual void ExecuteOne() = 0;
};
}
