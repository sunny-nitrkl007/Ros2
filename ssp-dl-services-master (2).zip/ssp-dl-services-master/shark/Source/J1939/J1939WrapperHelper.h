/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Wrapper Helper

#pragma once

#include "Config/CanPort.h"
#include "Config/J1939Address.h"
#include <scl_j1939.h>

namespace Shark
{
namespace J1939
{
class J1939WrapperHelper final
{
public:
	explicit J1939WrapperHelper(Config::CanPort canPort) noexcept;

	void LogAddressClaimResult(SCL_J1939_AC_STATUS_CB_ENUM_t status, Config::J1939Address address) const;
private:
	Config::CanPort const m_canPort;
};
}
}
