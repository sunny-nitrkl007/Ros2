/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Uber Wrapper Interface which manages the aspects that are common to both
/// can0 and can1.

#pragma once

#include "IPeriodicTaskManager.h"
#include "Utilities/DefineExceptionClass.h"

namespace Shark
{
namespace J1939
{
class IJ1939UberWrapper
{
public:
	static constexpr Shark::TaskPeriod TaskPeriod() { return Shark::TaskPeriod::Is20ms; }

	virtual ~IJ1939UberWrapper() = default;

	DEFINE_EXCEPTION_CLASS(Error);

	virtual void Initialize() = 0;
};
}
}
