/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Qualified Read Data Refresher Interface

#pragma once

#include "PidDefinition.h"
#include "Config/QualifiedReadConfig.h"

namespace Shark
{
namespace J1939
{
class IJ1939QualifiedReadDataRefresher
{
public:
	virtual ~IJ1939QualifiedReadDataRefresher() = default;

	virtual void RefreshPidData(
		PidDefinition const& pidDefinition,
		Config::QualifiedReadPidEntry const& qualifiedReadPidEntry) = 0;
	virtual void RefreshSpnData(
		Config::SpnDefinition const& spnDefinition,
		Config::QualifiedReadSpnEntry const& qualifiedReadSpnEntry) = 0;
};
}
}
