/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Numeric PID Data Processor

#pragma once

#include "INumericPidDataProcessor.h"
#include "Config/Pid.h"

namespace Shark
{
class IPidDataReceiver;

namespace J1939
{
class NumericPidDataProcessor final : public INumericPidDataProcessor
{
public:
	NumericPidDataProcessor(IPidDataReceiver& pidDataReceiver) noexcept;
// INumericPidDataProcessor
	void ProcessBuffer(
		Config::CanPort canPort,
		Config::J1939Address address,
		Config::Pid pid,
		Utilities::ArrayView<uint8_t const> const& data) const override;
	void ReportFailure(
		Config::CanPort canPort,
		Config::J1939Address address,
		Config::Pid pid,
		unsigned dataStatus) const override;
private:
	IPidDataReceiver& m_pidDataReceiver;
};
}
}