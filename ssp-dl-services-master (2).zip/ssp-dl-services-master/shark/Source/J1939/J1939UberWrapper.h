/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Uber Wrapper

#pragma once

#include "IJ1939UberWrapper.h"
#include "Config/CanPort.h"
#include <functional>
#include <memory>
#include <vector>

namespace Shark
{
class DependencyContainer;
class ICommandManager;
class IPeriodicTaskManager;

namespace J1939
{
class IJ1939PublicDataReceiver;
class IJ1939Wrapper;
class IPgnHelper;

using J1939Wrappers = std::vector<std::unique_ptr<IJ1939Wrapper>>;

class J1939UberWrapper final : public IJ1939UberWrapper
{
public:
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);

	J1939UberWrapper(
		J1939Wrappers&& j1939Wrappers,
		std::unique_ptr<IPgnHelper>&& spPgnHelper,
		std::function<void()>&& updateCallback) noexcept;
	~J1939UberWrapper() override;
	void Update();

	// IJ1939UberWrapper
	void Initialize() override;
private:
	void BeginSclConfiguration();
	void EndSclConfiguration();

	J1939Wrappers const m_j1939Wrappers;
	std::unique_ptr<IPgnHelper> const m_spPgnHelper; // only here for permanent storage
	std::function<void()> const m_updateCallback;
};
}
}
