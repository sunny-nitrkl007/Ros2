/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Adt Manager

#pragma once

#include "GroupConfigDataFactory.h"
#include <chrono>

using namespace std::chrono_literals;

namespace Shark
{
class DependencyContainer;
class IPidDataReceiver;

namespace J1939
{
class IJ1939Wrapper;

struct AdtTimeoutOverride
{
	unsigned address;
	std::chrono::milliseconds timeout;
};

class J1939AdtManager final
{
public:
	static bool ShouldBeCreated(DependencyContainer const& dependencyContainer);
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);
	static int_least16_t ReceiveHandler(
		uint_least8_t* pData,
		uint_least8_t data_len,
		void* rx_hdlr_context,
		uint_least16_t dataStatus);

	J1939AdtManager(
		IPidDataReceiver& pidDataReceiver,
		IJ1939Wrapper& j1939Wrapper) noexcept;
	~J1939AdtManager();
	void Initialize(AdtConfigData&& adtConfigData, std::vector<AdtTimeoutOverride>&& adtTimeoutOverrides);

private:
	std::optional<std::chrono::milliseconds> CalculateTimeoutValue(
		std::vector<AdtTimeoutOverride>& adtTimeoutOverrides,
		unsigned sourceAddress);
	void ProcessData(
		uint_least8_t* pData,
		uint_least8_t data_len,
		CallbackContext const& callbackContext,
		uint_least16_t dataStatus);

	IPidDataReceiver& m_pidDataReceiver;
	IJ1939Wrapper& m_j1939Wrapper;
	AdtConfigData m_adtConfigData{};
};
}
}
