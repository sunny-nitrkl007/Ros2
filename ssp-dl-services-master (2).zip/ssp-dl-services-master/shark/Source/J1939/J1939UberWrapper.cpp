/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See J1939UberWrapper.h

#include "J1939UberWrapper.h"
#include "DependencyContainer.h"
#include "J1939Wrapper.h"
#include "PgnHelper.h"
#include "SharkUtilities/FirstCallLogger.h"
#include "Utilities/PointerContainerUtilities.h"
#include <cassert>
#include <oel_rtos_posix.h>

namespace Shark
{
namespace J1939
{
namespace
{
constexpr oel_rtos_resource_pi_vconfig_t const n_halCanv3VConfig = OEL_RTOS_RESOURCE_PI_VCONFIG();
constexpr oel_rtos_resource_config_t const* n_pHalCanv3Config = OEL_BASE(&n_halCanv3VConfig);

constexpr oel_rtos_resource_pi_vconfig_t n_sclJ1939VConfig = OEL_RTOS_RESOURCE_PI_VCONFIG();
constexpr scl_j1939_config_t n_sclJ1939Config =
{
	OEL_BASE(&n_sclJ1939VConfig),
	TRUE,
	TRUE
}; // This structure will be used for every CAN data link.

void AddPeriodicTask(IPeriodicTaskManager& periodicTaskManager, J1939UberWrapper& uberWrapper)
{
	periodicTaskManager.Add(
		IJ1939UberWrapper::TaskPeriod(),
		[&uberWrapper] { uberWrapper.Update(); });
}
}

std::function<void()> J1939UberWrapper::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	auto& publicDataReceiver = dependencyContainer.GetPublicDataReceiver();
	auto spPgnHelper = PgnHelper::Create(publicDataReceiver);

	auto const& j1939DataLinkConfigs = dependencyContainer.GetJ1939DataLinkConfigs();
	J1939Wrappers j1939Wrappers{};
	std::vector<Utilities::nice_ptr<J1939Wrapper>> j1939WrapperPointers{}; // Used for Update callback

	for (auto const& spJ1939DataLinkConfig : j1939DataLinkConfigs)
	{
		auto spJ1939Wrapper = J1939Wrapper::Create(
			const_cast<DependencyContainer&>(dependencyContainer),
			*spPgnHelper,
			*spJ1939DataLinkConfig);
		j1939WrapperPointers.emplace_back(spJ1939Wrapper.get());
		j1939Wrappers.emplace_back(std::move(spJ1939Wrapper));
	}

	auto spUberWrapper = std::make_shared<J1939UberWrapper>(
		std::move(j1939Wrappers),
		std::move(spPgnHelper),
		[j1939WrapperPointers]
		{
			for (auto const& spJ1939Wrapper : j1939WrapperPointers)
			{
				spJ1939Wrapper->Update();
			}
		});

	AddPeriodicTask(dependencyContainer.GetIPeriodicTaskManager(), *spUberWrapper);

	return [spUberWrapper]
	{
		spUberWrapper->Initialize();
	};
}

J1939UberWrapper::J1939UberWrapper(
	J1939Wrappers&& j1939Wrappers,
	std::unique_ptr<IPgnHelper>&& spPgnHelper,
	std::function<void()>&& updateCallback) noexcept
	: m_j1939Wrappers{std::move(j1939Wrappers)}
	, m_spPgnHelper{std::move(spPgnHelper)}
	, m_updateCallback{std::move(updateCallback)}
{
	assert(Utilities::AllPointersAreValid(m_j1939Wrappers));
	assert(m_spPgnHelper);
	assert(m_updateCallback);
}
J1939UberWrapper::~J1939UberWrapper() = default;
void J1939UberWrapper::Update()
{
	static SharkUtilities::FirstCallLogger s_firstCallLogger{"J1939 Task"};
	s_firstCallLogger();

	scl_j1939_periodic_ctrl_task();
	m_updateCallback();
}
void J1939UberWrapper::Initialize()
{
	BeginSclConfiguration();

	// All links must be established before configuration continues because some functions like
	// scl_j1939_set_max_dm13_clients expect every link (based on scl_j1939_set_num_links) to
	// be established before it is called.
	for (auto const& spJ1939Wrapper : m_j1939Wrappers)
	{
		spJ1939Wrapper->EstablishLink(n_sclJ1939Config);
		m_spPgnHelper->RegisterLink(spJ1939Wrapper->GetCanPort(), spJ1939Wrapper->GetLink());
	}

	for (auto const& spJ1939Wrapper : m_j1939Wrappers)
	{
		spJ1939Wrapper->Initialize();
	}

	EndSclConfiguration();
}
void J1939UberWrapper::BeginSclConfiguration()
{
	for (auto const& spJ1939Wrapper : m_j1939Wrappers)
	{
		auto const canPort = spJ1939Wrapper->GetCanPort();
		hal_canv3_port_set_resource(
			J1939Wrapper::GetHalCanv3Port(canPort),
			n_pHalCanv3Config);
	}

	auto const linkCount = Utilities::narrow_cast<uint8_t>(m_j1939Wrappers.size());
	if (scl_j1939_set_num_links(linkCount) != TRUE)
	{
		throw IJ1939UberWrapper::Error("Unable to set number of data links for SCL J1939");
	}
}
void J1939UberWrapper::EndSclConfiguration()
{
	constexpr auto taskPeriodInMilliseconds = TaskPeriodToMilliseconds(IJ1939UberWrapper::TaskPeriod()).count();
	scl_j1939_init_tasks(taskPeriodInMilliseconds);
}
}
}
