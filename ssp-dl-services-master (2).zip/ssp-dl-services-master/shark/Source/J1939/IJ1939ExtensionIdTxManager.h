/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Extension Id Transmit Manager Interface

#pragma once

namespace Shark
{
namespace J1939
{
class IJ1939ExtensionIdTxManager
{
public:
	virtual ~IJ1939ExtensionIdTxManager() = default;

	virtual void Initialize() = 0;
};
}
}
