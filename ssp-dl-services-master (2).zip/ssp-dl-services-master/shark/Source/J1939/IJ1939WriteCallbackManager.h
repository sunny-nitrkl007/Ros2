/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Write Callback Mananager Interface

#pragma once

#include "IWriteSharkByte.h"
#include <functional>
#include <optional>
#include <vector>

namespace Shark
{
namespace J1939
{
class IJ1939WriteCallbackManager
{
public:
	virtual ~IJ1939WriteCallbackManager() = default;

	virtual void Add(unsigned address, unsigned pid, IWriteSharkByte::CompletedCallback const& callback) = 0;
	virtual void Callback(unsigned address, unsigned pid, std::optional<std::vector<uint8_t>> const& responseData) = 0;
};
}
}
