/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Extension Id Data Refresher Interface

#pragma once

#include "Config/ExtensionId.h"
#include "Config/J1939Address.h"

namespace Shark
{
namespace J1939
{
class IJ1939ExtensionIdDataRefresher
{
public:
	virtual ~IJ1939ExtensionIdDataRefresher() = default;

	virtual void Refresh(Config::J1939Address address, Config::ExtensionId extensionId) = 0;
};
}
}
