/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// SCL ADT and PGB Configuration Data Factory
/// Transforms Shark ADT and PGB configurations into SCL configurations

#pragma once

#include "Config/CanPort.h"
#include <SharkConfiguration.pb.h>
#include <scl_adt_j1939.h>
#include <scl_pgb_j1939.h>

namespace Shark
{
namespace J1939
{
struct CallbackContext
{
	Config::CanPort canPort;
	unsigned address;
	unsigned pid;
};
using CallbackContexts = std::vector<CallbackContext>;

struct AdtEntry
{
	unsigned address;
	unsigned pid;
};
struct AdtSet
{
	unsigned address;
	std::vector<scl_adt_j1939_client_grp_pid_config_t> pidConfigs;
	std::vector<scl_adt_j1939_client_grp_pid_config_t*> pidConfigPointers;
};
using AdtSets = std::vector<AdtSet>;
struct AdtConfigData
{
	AdtSets adtSets{};
	CallbackContexts callbackContexts{};
	unsigned adtGroupCount{};
};

struct PgbEntry
{
	unsigned address;
	unsigned pid;
	unsigned requestedUpdateRate;
};
struct PgbSet
{
	unsigned address;
	unsigned requestedUpdateRate;
	std::vector<scl_pgb_j1939_rx_pid_config_t> pidConfigs;
	std::vector<scl_pgb_j1939_rx_pid_config_t*> pidConfigPointers;
};
using PgbSets = std::vector<PgbSet>;

struct PgbConfigData
{
	PgbSets pgbSets{};
	CallbackContexts callbackContexts{};
	unsigned pgbGroupCount{};
};

class GroupConfigDataFactory final
{
public:
	static AdtConfigData CreateAdtConfigData(
		cat::shark::J1939DataLink const& j1939DataLink,
		scl_adt_j1939_client_grp_pid_hdlr_t* pReceiveHandler);
	static PgbConfigData CreatePgbConfigData(
		cat::shark::J1939DataLink const& j1939DataLink,
		scl_pgb_j1939_rx_pid_hdlr_t* pReceiveHandler);
};
}
}
