/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pgn Helper

#pragma once

#include "IPgnHelper.h"
#include "MbufWrapper.h"
#include <memory>
#include <scl_j1939.h>

namespace Shark
{
namespace J1939
{
class IJ1939PublicDataReceiver;

class PgnHelper final : public IPgnHelper
{
public:
	static std::unique_ptr<PgnHelper> Create(IJ1939PublicDataReceiver& publicDataReceiver);
	static void ReceiveHandler(
		scl_j1939_link_t link,
		const scl_j1939_rx_msg_t *Ppst_rx_msg,
		int_8,
		SCL_J1939_RX_MSG_CB_ENUM_t Pe_event,
		const scl_j1939_mbuf_hdr_t *mbuf_ptr);

	PgnHelper(IJ1939PublicDataReceiver& publicDataReceiver) noexcept;
	~PgnHelper() override;

// IPgnHelper
	void RegisterLink(Config::CanPort canPort, scl_j1939_link_t link) override;
	bool SendPgnMessage(
		scl_j1939_link_t link,
		unsigned pgn,
		unsigned destinationAddress,
		uint8_t const* pData,
		unsigned dataLength) override;
private:
	void ProcessPgnData(scl_j1939_link_t link, MbufWrapper mbuf, scl_j1939_rx_msg_t const* pRxMsg);

	IJ1939PublicDataReceiver& m_publicDataReceiver;
};
}
}
