/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See J1939Wrapper.h

#include "J1939Wrapper.h"
#include "DependencyContainer.h"
#include "J1939Definitions.h"
#include "Log.h"
#include "Config/ProtobufConversions.h"
#include "Config/Pgn.h"
#include "SharkBytes/ISharkByteManager.h"
#include "SharkBytes/ISlotManager.h"
#include "SharkBytes/PgnSlot.h"
#include "SharkBytes/RefreshablePgnSlot.h"
#include "Utilities/ArrayToHexString.h"
#include "Utilities/CommonExceptions.h"
#include "Utilities/Conversions.h"
#include "Utilities/CountOf.h"
#include "Utilities/narrow_cast.h"
#include "Utilities/ToUnderlying.h"
#include "TimedRepeater.h"
#include "WorkQueue.h"
#include <scl_cdl_tune.h>
#include <cdl2_proto.h>
#include <scl_rw_j1939.h>
#include <algorithm>
#include <sstream>
#include <vector>

namespace Shark
{
namespace J1939
{
constexpr char const* s_dataAckEventToString[]
{
	"RXED",
	"RD_NOT_SUPPORTED",
	"WR_NOT_SUPPORTED",
	"WR_UNSUCCESS",
	"RETRY",
};
static_assert(Utilities::CountOf(s_dataAckEventToString) == CDL2_CON_RX_PID_RETRY + 1, "Size mismatch");

std::string ConvertRxEventToString(cdl2_con_rx_event_t const& event)
{
	std::string result{"UNKNOWN"};
	if (event < Utilities::CountOf(s_dataAckEventToString))
	{
		result = s_dataAckEventToString[event];
	}
	else
	{
		assert(false);
	}
	return result;
}

constexpr char const* s_DM13StatusToString[]
{
	"Suspend All",
	"Suspend Some",
	"Suspend Temp All",
	"Suspend Temp Some",
	"UNKNOWN-0x04",
	"UNKNOWN-0x05",
	"UNKNOWN-0x06",
	"UNKNOWN-0x07",
	"UNKNOWN-0x08",
	"UNKNOWN-0x09",
	"UNKNOWN-0x0A",
	"UNKNOWN-0x0B",
	"UNKNOWN-0x0C",
	"UNKNOWN-0x0D",
	"Suspend Resume",
	"Suspend NA",
};
static_assert(Utilities::CountOf(s_DM13StatusToString) == SCL_J1939_SUSPEND_NA + 1, "Size mismatch");

char const* ConvertDM13StatusToString(scl_j1939_suspend_t const& status)
{
	char const* result{"UNKNOWN"};
	if (static_cast<unsigned>(status) < Utilities::CountOf(s_DM13StatusToString))
	{
		result = s_DM13StatusToString[status];
	}
	else
	{
		assert(false);
	}
	return result;
}

namespace
{
constexpr auto n_dummyExtensionId = 0x00;
constexpr auto n_maximumNetworkAddresses = 32u;
constexpr auto n_maximumNumberOfTransportProtocolSessions = 20u;

constexpr unsigned_8 const n_maxWritePidDataLength{ 0xFF };
scl_j1939_rx_msg_t const common_ecm_rx_table
{
	J1939Definitions::PropAPgn(),
	scl_j1939_cat_ppgn_hdlr,
	J1939Definitions::DefaultPriority(),
	FALSE,
	0xFF,
	{},
	SCL_J1939_RX_MSG_CBF_ENABLED,
	0
};

unsigned_32 const n_ecmIdentityNumber = 0;

void CreatePgnBroadcastSharkBytes(
	::google::protobuf::RepeatedPtrField<cat::shark::J1939DataLink::PeerNode> const& peerNodes,
	Config::CanPort canPort,
	SharkBytes::ISlotManager& slotManager,
	SharkBytes::ISharkByteManager& readSharkByteManager)
{
	for (auto const& peerNode : peerNodes)
	{
		if (peerNode.has_pgn())
		{
			auto const& pgn = peerNode.pgn();
			auto const address = peerNode.address();
			for (auto const& broadcastPgn : pgn.receive_broadcast_pgns())
			{
				auto id = broadcastPgn.middleware_id();
				std::unique_ptr<ISharkByte> spPgnSharkByte{};
				auto spPgnSlot = std::make_unique<SharkBytes::PgnSlot>(std::move(id));
				slotManager.AddPgnSlot(*spPgnSlot, canPort, address, broadcastPgn.pgn());
				spPgnSharkByte = std::move(spPgnSlot);
				readSharkByteManager.AddSharkByte(std::move(spPgnSharkByte));
			}
		}
	}
}
void CreatePgnOnRequestSharkBytes(
	::google::protobuf::RepeatedPtrField<cat::shark::J1939DataLink::PeerNode> const& peerNodes,
	Config::CanPort canPort,
	IPgnDataRefresher& pgnDataRefresher,
	SharkBytes::ISlotManager& slotManager,
	SharkBytes::ISharkByteManager& readSharkByteManager)
{
	unsigned currentIndex = 1; // On-request PGNs must start at table index 1 (after 0xEF00)
	for (auto const& peerNode : peerNodes)
	{
		if (peerNode.has_pgn())
		{
			auto const& pgn = peerNode.pgn();
			auto const address = peerNode.address();
			for (auto const& onRequestPgn : pgn.receive_on_request_pgns())
			{
				auto id = onRequestPgn.middleware_id();
				auto spPgnSlot = std::make_unique<SharkBytes::RefreshablePgnSlot>(
					std::move(id),
					pgnDataRefresher,
					currentIndex);
				slotManager.AddPgnSlot(*spPgnSlot, canPort, address, onRequestPgn.pgn());
				readSharkByteManager.AddSharkByte(std::move(spPgnSlot));
				++currentIndex;
			}
		}
	}
}
std::vector<uint8_t> CreateAddressList(cat::shark::J1939DataLink::Identity const& identity)
{
	std::vector<uint8_t> addressList{};
	addressList.reserve(static_cast<unsigned>(identity.valid_addresses_size()));
	for (auto address : identity.valid_addresses())
	{
		addressList.push_back(Utilities::narrow_cast<uint8_t>(address));
	}
	return addressList;
}
AddressTableConfigData CreateAddressTable(
	std::vector<uint8_t> const& addressList,
	J1939NameFields const& j1939NameFields,
	cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	AddressTableConfigData addressTableConfigData;
	addressTableConfigData.rxPgnConfigs.emplace_back(common_ecm_rx_table);

	// Add all the on-request PGNs first. They expect to start at table index 1 (after 0xEF00).
	for (auto const& peerNode : j1939DataLinkConfig.peer_nodes())
	{
		if (peerNode.has_pgn())
		{
			auto const address = peerNode.address();
			for (auto const& onRequestPgn : peerNode.pgn().receive_on_request_pgns())
			{
				addressTableConfigData.rxPgnConfigs.emplace_back(
					IPgnHelper::CreateSclPgnConfig(
						onRequestPgn.pgn(),
						address,
						0)); // No timeout for on-request PGNs
			}
		}
	}

	// Add all the remaining PGNs after the on-request PGNs
	for (auto const& peerNode : j1939DataLinkConfig.peer_nodes())
	{
		if (peerNode.has_pgn())
		{
			auto const address = peerNode.address();
			for (auto const& broadcastPgn : peerNode.pgn().receive_broadcast_pgns())
			{
				addressTableConfigData.rxPgnConfigs.emplace_back(
					IPgnHelper::CreateSclPgnConfig(
						broadcastPgn.pgn(),
						address,
						broadcastPgn.timeout()));
			}
		}
	}

	addressTableConfigData.addressTable = scl_j1939_addr_tbl_t{
		&j1939NameFields.industryGroup,
		&j1939NameFields.vehicleSystem,
		&j1939NameFields.vehicleSystemInstance,
		&j1939NameFields.function,
		&j1939NameFields.functionInstance,
		&j1939NameFields.ecmInstance,
		&j1939NameFields.manufacturerCode,
		&n_ecmIdentityNumber,
		addressList.data(),
		Utilities::narrow_cast<unsigned_8>(addressList.size()),
		addressList.data(),
		TRUE,
		FALSE,
		Utilities::narrow_cast<unsigned_8>(addressTableConfigData.rxPgnConfigs.size()),
		addressTableConfigData.rxPgnConfigs.data(),
		0,
		nullptr};

	return addressTableConfigData;
}
J1939NameFields CreateJ1939NameFields(cat::shark::J1939DataLink::Identity const& identity)
{
	return J1939NameFields{
		Utilities::narrow_cast<uint8_t>(identity.industry_group()),
		Utilities::narrow_cast<uint8_t>(identity.vehicle_system()),
		Utilities::narrow_cast<uint8_t>(identity.vehicle_system_instance()),
		Utilities::narrow_cast<uint8_t>(identity.function()),
		Utilities::narrow_cast<uint8_t>(identity.function_instance()),
		Utilities::narrow_cast<uint8_t>(identity.ecu_instance()),
		Utilities::narrow_cast<uint16_t>(identity.manufacturer_code())};
}

scl_j1939_ppgn_enable_t app_scl_j1939_ppgn_enable[] =
{
	{0xFA, 0x08, 0, 0, 0, 0, 0, 0, 0, 0},
};

void DumpExtensionIdCommandRxData(unsigned address, unsigned_8 const* pData, unsigned dataLength)
{
	auto constexpr severity = Log::SeverityLevel::Debug;
	if (Log::ShouldLog(severity, Log::ExtId))
	{
		auto hexBytes = Utilities::ArrayToHexString(pData, dataLength);
		LOG_TAG(severity, Log::ExtId,
			"ExtId Rx Handler: SA: 0x" << std::hex << std::uppercase << address << " " <<
			"Data: " << hexBytes);
	}
}
void DumpPidRxData(unsigned address, unsigned_8 const* pData, unsigned dataLength)
{
	auto constexpr severity = Log::SeverityLevel::Debug;
	if (Log::ShouldLog(severity, Log::Rw))
	{
		auto hexBytes = Utilities::ArrayToHexString(pData, dataLength);
		LOG_TAG(severity, Log::Rw,
			"Pid Rx Handler: SA: 0x" << std::hex << std::uppercase << address << " " <<
			"Data: " << hexBytes);
	}
}

// Every machine will use the same values. They can be increased or made configurable if necessary.
// Knowledge of all communications of each Application is necessary to precisely determine the
// perfect values.
constexpr scl_pgb_j1939_ecm_config_t const n_ecmConfig =
{
	J1939Definitions::VirtualEcmIndex(), // scl_j1939 virtual ecm index number
	10,                // Number of RX Connections
	10,                // Number of TX Connections
	IJ1939Wrapper::MaxRxPgbGroups(),
	50,                // Maximum Number of TX Groups
	20,                // Maximum Number of Transmit Broadcasts
};

std::vector<Utilities::nice_ptr<J1939Wrapper>> n_spJ1939Wrappers{};

J1939Wrapper& LookupJ1939Wrapper(scl_j1939_link_t link)
{
	auto const itEnd = n_spJ1939Wrappers.end();
	auto const itFound = std::find_if(n_spJ1939Wrappers.begin(), itEnd,
		[link](auto const& spWrapper)
		{
			return spWrapper->GetLink() == link;
		});
	if (itFound == itEnd)
	{
		throw J1939Wrapper::Error("Could not find J1939Wrapper for link " +
			To<std::string>(static_cast<unsigned>(link)));
	}

	return **itFound;
}
} // unnamed namespace

SclAddressTableConfiguration::SclAddressTableConfiguration(
	cat::shark::J1939DataLink const& j1939DataLinkConfig)
	: m_addressList(CreateAddressList(j1939DataLinkConfig.identity()))
	, m_j1939NameFields(CreateJ1939NameFields(j1939DataLinkConfig.identity()))
	, m_addressTableData(CreateAddressTable(
		GetAddressList(),
		m_j1939NameFields,
		j1939DataLinkConfig))
{
}

volatile hal_canv3_port_t* J1939Wrapper::GetHalCanv3Port(Config::CanPort canPort)
{
	static volatile hal_canv3_port_t* const s_halCanv3Ports[] = // cppcheck-suppress constVariable
	{
		HAL_CANV3_PORT_01,
		HAL_CANV3_PORT_02,
		HAL_CANV3_PORT_03,
		HAL_CANV3_PORT_04,
		HAL_CANV3_PORT_05,
		HAL_CANV3_PORT_06,
	};
	static_assert(std::size(s_halCanv3Ports) == static_cast<unsigned>(Config::CanPort::CanPortCount));

	assert(canPort < std::size(s_halCanv3Ports));
	return s_halCanv3Ports[static_cast<unsigned>(canPort)];
}

std::unique_ptr<SclAddressTableConfiguration const> J1939Wrapper::CreateSclAddressTableConfiguration(
	cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	return std::make_unique<SclAddressTableConfiguration const>(j1939DataLinkConfig);
}
std::unique_ptr<J1939Wrapper> J1939Wrapper::Create(
	DependencyContainer& dependencyContainer,
	IPgnHelper& pgnHelper,
	cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	auto const canPort = Config::ToConfigCanPort(j1939DataLinkConfig.can_port());
	LOG_INFO_HIGH_TAG(Log::Init, "Creating J1939Wrapper for " << canPort);

	CreatePgnBroadcastSharkBytes(
		j1939DataLinkConfig.peer_nodes(),
		canPort,
		dependencyContainer.GetISlotManager(),
		dependencyContainer.GetISharkByteManager());

	auto spTaskWorkQueue = std::make_unique<WorkQueue>();
	auto &taskWorkQueue = *spTaskWorkQueue;

	auto spJ1939Wrapper = std::make_unique<J1939Wrapper>(
		pgnHelper,
		std::move(spTaskWorkQueue),
		j1939DataLinkConfig,
		canPort);
	dependencyContainer.Set(canPort, *spJ1939Wrapper, taskWorkQueue);

	CreatePgnOnRequestSharkBytes(
		j1939DataLinkConfig.peer_nodes(),
		canPort,
		*spJ1939Wrapper,
		dependencyContainer.GetISlotManager(),
		dependencyContainer.GetISharkByteManager());

	auto spSclAddressTableConfiguration = CreateSclAddressTableConfiguration(j1939DataLinkConfig);
	spJ1939Wrapper->SetAddressTableConfig(std::move(spSclAddressTableConfiguration));

	return spJ1939Wrapper;
}

J1939Wrapper::J1939Wrapper(
	IPgnHelper& pgnHelper,
	std::unique_ptr<IWorkQueue>&& spTaskWorkQueue,
	cat::shark::J1939DataLink const& j1939DataLinkConfig,
	Config::CanPort canPort) noexcept
	: m_pgnHelper(pgnHelper)
	, m_spTaskWorkQueue(std::move(spTaskWorkQueue))
	, m_canPort(canPort)
	, m_wrapperHelper(m_canPort)
{
	assert(m_spTaskWorkQueue);
	assert(m_canPort < Config::CanPort::CanPortCount);
	assert(std::find(n_spJ1939Wrappers.begin(), n_spJ1939Wrappers.end(), this) == n_spJ1939Wrappers.end());

	InitializeDM13Statuses(j1939DataLinkConfig);
	n_spJ1939Wrappers.emplace_back(this);
}
J1939Wrapper::~J1939Wrapper()
{
	auto const itEnd = n_spJ1939Wrappers.end();
	auto const itFound = std::find(n_spJ1939Wrappers.begin(), itEnd, this);
	assert(itFound != itEnd);
	n_spJ1939Wrappers.erase(itFound);
}
void J1939Wrapper::SetAddressTableConfig(std::unique_ptr<SclAddressTableConfiguration const>&& spSclAddressTableConfiguration)
{
	assert(spSclAddressTableConfiguration);
	assert(!m_spSclAddressTableConfiguration);
	m_spSclAddressTableConfiguration = std::move(spSclAddressTableConfiguration);
}
void J1939Wrapper::EstablishLink(scl_j1939_config_t const& j1939Config)
{
	assert(m_link == SCL_J1939_INVALID_LINK);
	assert(m_spSclAddressTableConfiguration);

	m_link = scl_j1939_establish_link(
		GetHalCanv3Port(m_canPort),
		m_spSclAddressTableConfiguration->GetSclAddressTable(),
		1,
		100,
		10,
		n_maximumNumberOfTransportProtocolSessions,
		n_maximumNetworkAddresses,
		&AddressClaimCallback,
		&j1939Config);

	if (m_link == SCL_J1939_INVALID_LINK)
	{
		throw Error("Unable to establish SCL " + To<std::string>(m_canPort) + " J1939 link");
	}

	LOG_INFO_HIGH_TAG(Log::Init, "Established J1939 link " << static_cast<unsigned>(m_link) << " for " << m_canPort);
}
void J1939Wrapper::Initialize()
{
	ConfigureScl();
}
Config::CanPort J1939Wrapper::GetCanPort() const
{
	return m_canPort;
}
scl_j1939_link_t J1939Wrapper::GetLink() const
{
	assert(m_link != SCL_J1939_INVALID_LINK);
	return m_link;
}
J1939::J1939NameFields const& J1939Wrapper::GetJ1939NameFields() const
{
	assert(m_spSclAddressTableConfiguration);
	return m_spSclAddressTableConfiguration->GetJ1939NameFields();
}
Utilities::nice_ptr<scl_pgb_j1939_t> J1939Wrapper::GetPgbContext() const
{
	assert(IsInitialized());
	return m_spPgbContext;
}
scl_adt_j1939_link_handle_t J1939Wrapper::GetAdtHandle() const
{
	assert(IsInitialized());
	return m_adtLinkHandle;
}
bool J1939Wrapper::SendPropAMessage(unsigned destinationAddress, uint8_t const* pData, unsigned dataLength)
{
	return SendPgnMessage(J1939Definitions::PropAPgn(), destinationAddress, pData, dataLength);
}
bool J1939Wrapper::SendPropAMessageByName(J1939Name const j1939Name, uint8_t const* pData, unsigned dataLength)
{
	assert(pData);
	assert(dataLength);
	assert(IsInitialized());

	auto const succeeded = scl_j1939_que_tx_msg_by_name(
		GetLink(),
		J1939Definitions::PropAPgn(),
		J1939Definitions::DefaultPriority(),
		j1939Name.data(),
		J1939Definitions::VirtualEcmIndex(),
		pData,
		Utilities::narrow_cast<unsigned_16>(dataLength));
	if (!succeeded)
	{
		LOG_INFO_LOW_TAG(Log::Rw, "scl_j1939_que_tx_msg_by_name failed");
	}

	return succeeded;
}
bool J1939Wrapper::SendPgnMessage(unsigned pgn, unsigned destinationAddress, uint8_t const* pData, unsigned dataLength)
{
	assert(IsInitialized());

	return m_pgnHelper.SendPgnMessage(GetLink(), pgn, destinationAddress, pData, dataLength);
}
namespace
{
constexpr unsigned n_dm13Pgn{0x00DF00};
constexpr unsigned n_broadcastAddress{0xFF};
constexpr uint8_t const n_dm13Message[] {0xFF, 0xFF, 0xFF, 0xF0, 0xFF, 0xFF, 0xFF, 0xFF};
static_assert(Utilities::CountOf(n_dm13Message) == 8, "DM13 message length mismatch");
}
bool J1939Wrapper::SendDM13Suspend()
{
	return SendPgnMessage(n_dm13Pgn, n_broadcastAddress, n_dm13Message, Utilities::CountOf(n_dm13Message));
}
void J1939Wrapper::RegisterExtensionIdCommandHandler(
	unsigned extensionIdCommand,
	std::function<ExtensionIdHandler>&& handler)
{
	auto& context = AddExtensionIdHandler(extensionIdCommand, n_dummyExtensionId, std::move(handler));
	if (!scl_j1939_cat_ppgn_id_install_command(GetLink(), &context.m_sclHandler))
	{
		throw Error("Failed to install extension id command handler!");
	}
}
void J1939Wrapper::RegisterExtensionIdCommandIdHandler(
	ExtensionIdCommand extensionIdCommand,
	unsigned extensionId,
	std::function<ExtensionIdHandler>&& handler)
{
	auto& context = AddExtensionIdHandler(Utilities::ToUnderlying(extensionIdCommand), extensionId, std::move(handler));
	if (!scl_j1939_cat_ppgn_id_install_command_id(GetLink(), &context.m_sclHandler))
	{
		throw Error("Failed to install extension id command id handler!");
	}
}
void J1939Wrapper::RegisterPidRequestHandler(
	unsigned pid,
	std::function<PidRequestHandler>&& handler)
{
	auto const isFirstTimePidIsAdded = m_pidRequestHandlerCallbacks.find(pid) == m_pidRequestHandlerCallbacks.cend();
	m_pidRequestHandlerCallbacks[pid].push_back(std::move(handler));
	if (isFirstTimePidIsAdded && cdl2_add_to_con_rx_pit(pid, &CommonPidRequestHandler, nullptr))
	{
		throw Error("Failed to install pid request command id handler!");
	}
}
void J1939Wrapper::RegisterPidReadHandler(unsigned pid, std::function<PidReadHandler>&& handler)
{
	m_pidReadHandlerCallbacks.push_back(std::move(handler));
	if (cdl2_add_to_tx_pit(pid, &CommonPidReadHandler, &m_pidReadHandlerCallbacks.back()))
	{
		throw Error("Failed to install pid read command id handler!");
	}
}
void J1939Wrapper::RegisterPidWriteHandler(unsigned pid, std::function<PidWriteHandler>&& handler)
{
	// cdl2 write pit expects an 8-bit length on the front of the void* passed as the pie
	// We set this to max since we are checking the data length separately
	m_pidWriteHandlerPies.push_back({n_maxWritePidDataLength, std::move(handler)});
	if (cdl2_add_to_wr_pit(pid, &CommonPidWriteHandler, &m_pidWriteHandlerPies.back()))
	{
		throw Error("Failed to install pid write command id handler!");
	}
}
void J1939Wrapper::AddPgbGroups(
	unsigned address,
	unsigned pidCount,
	scl_pgb_j1939_rx_pid_cfg_ptr_t const* pPidTable,
	unsigned requestedUpdateRate,
	unsigned timeOut)
{
	auto const result = scl_pgb_j1939_add_rx_grps(
		m_spPgbContext,
		J1939Definitions::VirtualEcmIndex(),
		Utilities::narrow_cast<uint_least8_t>(address),
		Utilities::narrow_cast<uint_least16_t>(pidCount),
		pPidTable,
		nullptr,
		Utilities::narrow_cast<uint_least16_t>(requestedUpdateRate),
		Utilities::narrow_cast<uint_least16_t>(timeOut),
		nullptr,
		nullptr);

	if (result != TRUE)
	{
		throw Error("Unable to add PGB receive group!"); // Refer to settings in s_ecmConfig
	}
}
void J1939Wrapper::AddAdtGroups(
	unsigned address,
	unsigned pidCount,
	scl_adt_j1939_client_grp_pid_config_ptr_t const* pPidConfig,
	std::optional<std::chrono::milliseconds> timeout)
{
	auto const resultGroup = scl_adt_j1939_link_add_group(
		m_adtLinkHandle,
		J1939Definitions::VirtualEcmIndex(),
		Utilities::narrow_cast<uint_least8_t>(address),
		Utilities::narrow_cast<uint_least8_t>(pidCount),
		TRUE,
		pPidConfig,
		nullptr,
		nullptr,
		nullptr);

	if (resultGroup == SCL_ADT_J1939_INVALID_GROUP_ID)
	{
		throw Error("Unable to add Adt receive group!");
	}
	else if (timeout)
	{
		auto const success = scl_adt_j1939_client_grp_set_timeout(
			m_adtLinkHandle,
			J1939Definitions::VirtualEcmIndex(),
			Utilities::narrow_cast<uint_least8_t>(address),
			resultGroup,
			static_cast<unsigned>(timeout->count()));
		if (!success)
		{
			throw Error("Timeout override of Adt receive group was not successful!");
		}
	}
}
unsigned J1939Wrapper::GetPgnRxTableIndex(unsigned address, unsigned pgn) const
{
	auto const itBegin = m_spSclAddressTableConfiguration->GetRxPgnConfigs().begin();
	auto const itEnd = m_spSclAddressTableConfiguration->GetRxPgnConfigs().end();
	auto const itFound = std::find_if(itBegin, itEnd,
		[address, pgn](auto const& rxTableEntry)
		{
			return (rxTableEntry.Mu8_source_address == address) && (rxTableEntry.Mu32_pgn == pgn);
		});
	if (itFound == itEnd)
	{
		throw Utilities::NotFound("Unable to find source address and pgn in Rx Table");
	}
	return To<unsigned>(std::distance(itBegin, itFound));;
}
unsigned J1939Wrapper::GetPgnRxTableTimeout(unsigned address, unsigned pgn) const
{
	auto tableIndex = GetPgnRxTableIndex(address, pgn);
	return To<unsigned>(m_spSclAddressTableConfiguration->GetRxPgnConfigs()[tableIndex].Mi16_lost_timeout);
}
void J1939Wrapper::RegisterForDM13Status(std::function<DM13StatusCallback>&& callback)
{
	std::unique_lock<std::mutex> lock{m_dm13Mutex};
	for (auto&& status : m_dm13Statuses)
	{
		callback(status.first, status.second);
	}
	m_dm13StatusCallbacks.emplace_back(std::move(callback));
}
bool J1939Wrapper::EcmIsConnectedToLink(Config::J1939Address j1939Address)
{
	unsigned_8 j1939Name[SCL_J1939_NAME_LEN]{};
	auto const result = scl_j1939_find_name_by_address(GetLink(), Utilities::narrow_cast<unsigned_8, unsigned>(j1939Address), j1939Name);
	return result;
}
std::vector<scl_j1939_nar_entry_t> J1939Wrapper::GetConnectedEcms()
{
	std::vector<scl_j1939_nar_entry_t> connectedEcms{};
	scl_j1939_nar_entry_t entry{};
	scl_j1939_nar_handle_t narHandle{};

	if (scl_j1939_get_first_nar_entry(m_link, &entry, &narHandle))
	{
		connectedEcms.push_back(entry);
		while (scl_j1939_get_next_nar_entry(m_link, &entry, &narHandle))
		{
			connectedEcms.push_back(entry);
		}
	}

	return connectedEcms;
}
void J1939Wrapper::Refresh(unsigned refreshContext)
{
	auto const createLogMessage([this, refreshContext]()
	{
		std::stringstream stream{};
		auto const& configs = m_spSclAddressTableConfiguration->GetRxPgnConfigs();
		assert(refreshContext < configs.size());
		auto const& config = configs[refreshContext];
		Config::Pgn const pgn{config.Mu32_pgn};
		unsigned const address{config.Mu8_source_address};

		stream << GetCanPort() << ": Sending request for " << pgn << " from 0x"
		       << std::hex << address << std::dec << " (index " << refreshContext << ")";
		return stream.str();
	});

	LOG_DEBUG_TAG(Log::Pgn, createLogMessage());
	if (!scl_j1939_set_rx_msg_send_request_bit(GetLink(), J1939Definitions::VirtualEcmIndex(), To<unsigned_8>(refreshContext)))
	{
		LOG_ERROR_TAG(Log::Pgn,
			"Failure requesting send for refresh context: " << refreshContext);
	}
}
void J1939Wrapper::CommonExtensionIdCommandIdHandler(scl_j1939_mbuf_hdr_t const* mbuf_ptr, void* pContext)
{
	assert(mbuf_ptr);
	assert(pContext);

	auto const address = scl_j1939_get_mbuf_sa(mbuf_ptr);
	auto const messageLength = scl_j1939_get_mbuf_len(mbuf_ptr);
	std::vector<unsigned_8> message(messageLength);
	scl_j1939_get_data_from_mbuf(mbuf_ptr, message.data(), messageLength, 0); // 0 is offset from beginning of message
	DumpExtensionIdCommandRxData(address, message.data(), messageLength);

	auto const& handlerContext = *reinterpret_cast<ExtensionIdHandlerContext const*>(pContext);
	assert(handlerContext.m_handler);
	handlerContext.m_handler(address, message.data(), messageLength);
}
int_16 J1939Wrapper::CommonPidRequestHandler(
	[[maybe_unused]] cdl2_con_rx_data_link_t data_link_type,
	unsigned_32 connection_handle,
	cdl2_con_rx_event_t ack_event,
	void*,
	unsigned_8 sid,
	unsigned_8,
	unsigned_32 data_ID,
	unsigned_8 pdl,
	unsigned_8 *data)
{
	assert(data_link_type == CDL2_CON_RX_DATA_LINK_J1939);
	auto& j1939Wrapper = LookupJ1939Wrapper(static_cast<scl_j1939_link_t>(connection_handle));

	auto requestStatus = PidRequestStatus::RequestFailed;
	if (ack_event == CDL2_CON_RX_PID_RXED)
	{
		DumpPidRxData(sid, data, pdl);
		requestStatus = PidRequestStatus::Received;
	}
	else if (ack_event == CDL2_CON_RX_PID_RETRY)
	{
		LOG_WARNING_TAG(Log::Rw, "Write failed, need to retry! " <<
			" 0x" << std::hex << std::uppercase << static_cast<unsigned>(sid) << " PID 0x" << data_ID);
		requestStatus = PidRequestStatus::Retry;
	}
	else
	{
		LOG_INFO_LOW_TAG(Log::Rw, "Write failed: Event: " << ConvertRxEventToString(ack_event) <<
			" 0x" << std::hex << std::uppercase << static_cast<unsigned>(sid) << " PID 0x" << data_ID);
	}
	j1939Wrapper.CallbackPidRequests(
		requestStatus,
		sid,
		data_ID,
		requestStatus == PidRequestStatus::Received ? data : nullptr,
		requestStatus == PidRequestStatus::Received ? pdl : 0);
	return 0; // Return value is ignored
}
int_16 J1939Wrapper::CommonPidReadHandler(void* tx_pie, unsigned_8* data)
{
	assert(tx_pie);
	auto pHandler = reinterpret_cast<std::function<PidReadHandler>*>(tx_pie);

	return (*pHandler)(data);
}
int_16 J1939Wrapper::CommonPidWriteHandler(void* wr_pie, unsigned_16 len, unsigned_8* data)
{
	assert(wr_pie);
	auto const pPie = reinterpret_cast<PidWriteHandlerPie*>(wr_pie);
	return (pPie->pidWriteHandler)(data, len); // NOTE: The scl caller simply throws away the return value
}
void J1939Wrapper::ConfigureScl()
{
	LOG_INFO_HIGH_TAG(Log::Init, "Configuring SCL for " << m_canPort);

	auto result = scl_j1939_set_ppgn_enable_table(
		m_link,
		Utilities::CountOf(app_scl_j1939_ppgn_enable),
		app_scl_j1939_ppgn_enable);
	if (result != TRUE)
	{
		throw Error("Unable to set ppgn table for SCL J1939");
	}
	if (scl_j1939_cmgr_init(m_link, 10, 10) != TRUE)
	{
		throw Error("Unable to initialize SCL J1939 Connection Manager");
	}
	m_spPgbContext = scl_pgb_j1939_init(m_link);
	if (!m_spPgbContext)
	{
		throw Error("scl_pgb_j1939_init failed!");
	}
	if (scl_pgb_j1939_add_ecm(m_spPgbContext, &n_ecmConfig) != TRUE)
	{
		throw Error("scl_pgb_j1939_add_ecm failed!");
	}
	// first two parameters are not used so just pass in 0, display is always ok to shut down broadcasts so return TRUE
	if (!scl_j1939_set_max_dm13_clients(0, 0, []() -> boolean_t { return TRUE; }))
	{
		throw Error("scl_j1939_set_max_dm13_clients failed!");
	}
	if (!scl_j1939_install_dm13(m_link, J1939Definitions::VirtualEcmIndex()))
	{
		throw Error("scl_j1939_install_dm13 failed!");
	}
	if (!scl_j1939_add_suspend_client(&J1939Wrapper::DM13Callback, nullptr))
	{
		throw Error("scl_j1939_add_suspend_client failed!");
	}
	if (!scl_rw_j1939_client_init(m_link))
	{
		throw Error("scl_rw_j1939_client_init failed!");
	}
	if (!scl_rw_j1939_server_init(m_link))
	{
		throw Error("scl_rw_j1939_server_init failed");
	}
	m_adtLinkHandle = scl_adt_j1939_link_init(m_link);
	if (m_adtLinkHandle == SCL_ADT_J1939_INVALID_HANDLE)
	{
		throw Error("scl_adt_j1939_link_init failed");
	}
	if (!scl_adt_j1939_link_add_ecm(m_adtLinkHandle, J1939Definitions::VirtualEcmIndex()))
	{
		throw Error("scl_adt_j1939_link_add_ecm failed");
	}
}
void J1939Wrapper::HandleAddressClaim(SCL_J1939_AC_STATUS_CB_ENUM_t Pu8_status, unsigned_8 Pu8_address)
{
	m_addressClaimCallbackOccurred = true;
	m_wrapperHelper.LogAddressClaimResult(Pu8_status, Pu8_address);
}
void J1939Wrapper::AddressClaimCallback(
	const scl_j1939_link_t link,
	const int_8,
	const SCL_J1939_AC_STATUS_CB_ENUM_t Pu8_status,
	const unsigned_8 Pu8_address)
{
	auto& j1939Wrapper = LookupJ1939Wrapper(link);
	j1939Wrapper.HandleAddressClaim(Pu8_status, Pu8_address);
}
namespace
{
bool IsDM13Suspended(scl_j1939_suspend_t status)
{
	auto suspended = false;
	if (status == SCL_J1939_SUSPEND_INDEF_ALL ||
		status == SCL_J1939_SUSPEND_INDEF_SOME ||
		status == SCL_J1939_SUSPEND_TEMP_ALL ||
		status == SCL_J1939_SUSPEND_TEMP_SOME)
	{
		suspended = true;
	}
	return suspended;
}
}
void J1939Wrapper::DM13Callback(
	scl_j1939_link_t link,
	[[maybe_unused]] unsigned_8 ecm_index,
	unsigned_8 remote_address,
	scl_j1939_suspend_t status,
	unsigned_16,
	boolean_t,
	void*)
{
	assert(ecm_index == J1939Definitions::VirtualEcmIndex());

	auto& j1939Wrapper = LookupJ1939Wrapper(link);
	auto const dm13State = IsDM13Suspended(status) ? DM13State::Suspended : DM13State::Active;
	j1939Wrapper.UpdateRemoteDM13Status(remote_address, dm13State);
	LOG_INFO_HIGH_TAG(Log::Init, "DM13 status for 0x" << std::hex << std::uppercase <<
		static_cast<unsigned>(remote_address) << " is " << ConvertDM13StatusToString(status));
}
void J1939Wrapper::InitializeDM13Statuses(cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	m_dm13Statuses.reserve(static_cast<unsigned>(j1939DataLinkConfig.peer_nodes_size()));
	for (auto&& peer : j1939DataLinkConfig.peer_nodes())
	{
		m_dm13Statuses.emplace_back(peer.address(), DM13State::Active);
	}
}
void J1939Wrapper::UpdateRemoteDM13Status(unsigned address, DM13State state)
{
	std::unique_lock<std::mutex> lock{m_dm13Mutex};
	auto const itEnd = m_dm13Statuses.end();
	auto const itFound = std::find_if(m_dm13Statuses.begin(), itEnd,
		[address](auto const& addressStatus)
		{
			return addressStatus.first == address;
		});
	if (itFound != itEnd && itFound->second != state)
	{
		itFound->second = state;
		for (auto&& callback : m_dm13StatusCallbacks)
		{
			callback(address, state);
		}
	}
}
void J1939Wrapper::CallbackPidRequests(PidRequestStatus status, unsigned address, unsigned pid, uint8_t const* pData, unsigned dataLength)
{
	for (auto const& callback : m_pidRequestHandlerCallbacks[pid])
	{
		callback(status, address, pid, pData, dataLength);
	}
}
void J1939Wrapper::Update()
{
	if (m_addressClaimCallbackOccurred)
	{
		m_spTaskWorkQueue->ExecuteOne();
	}
}
J1939Wrapper::ExtensionIdHandlerContext& J1939Wrapper::AddExtensionIdHandler(
	unsigned extensionIdCommand,
	unsigned extensionId,
	std::function<ExtensionIdHandler>&& handler)
{
	// Only one handler may be registered for the same command and extension ID. The first
	// one registered will win--its handler will always be called.
	assert(std::none_of(m_extensionIdHandlerContexts.begin(), m_extensionIdHandlerContexts.end(),
		[extensionIdCommand, extensionId](ExtensionIdHandlerContext const& context)
		{
			return context.m_sclHandler.command == extensionIdCommand &&
			       context.m_sclHandler.cat_id  == extensionId;
		}));

	m_extensionIdHandlerContexts.push_back({
		{
			Utilities::narrow_cast<unsigned_16>(extensionIdCommand),
			Utilities::narrow_cast<unsigned_16>(extensionId),
			nullptr,
			nullptr,
			&CommonExtensionIdCommandIdHandler,
			nullptr // Filled in later
		},
		std::move(handler)});
	auto& context = m_extensionIdHandlerContexts.back();
	context.m_sclHandler.context = &context;
	return context;
}
}
}

// Following global definitions are used by cdl and j1939
// They need to be declared here instead of scl_cdl_config.c to avoid multiple definition conflicts with library
constexpr unsigned_16 cdl2_num_tx_pit{CDL2_NUM_TX_PIT};
cdl2_tx_pit_t cdl2_tx_pit[cdl2_num_tx_pit];

constexpr unsigned_16 cdl2_sublist_D0_num_tx_pit{CDL2_SUBLIST_D0_NUM_TX_PIT};
cdl2_tx_pit_t cdl2_sublist_D0_tx_pit[cdl2_sublist_D0_num_tx_pit];

constexpr unsigned_16 cdl2_sublist_D1_num_tx_pit{CDL2_SUBLIST_D1_NUM_TX_PIT};
cdl2_tx_pit_t cdl2_sublist_D1_tx_pit[cdl2_sublist_D1_num_tx_pit];

constexpr unsigned_16 cdl2_sublist_D2_num_tx_pit{CDL2_SUBLIST_D2_NUM_TX_PIT};
cdl2_tx_pit_t cdl2_sublist_D2_tx_pit[cdl2_sublist_D2_num_tx_pit];

constexpr unsigned_16 cdl2_sublist_D3_num_tx_pit{CDL2_SUBLIST_D3_NUM_TX_PIT};
cdl2_tx_pit_t cdl2_sublist_D3_tx_pit[cdl2_sublist_D3_num_tx_pit];

constexpr unsigned_16 cdl2_sublist_F916_num_tx_pit{CDL2_SUBLIST_F916_NUM_TX_PIT};
cdl2_tx_pit_t cdl2_sublist_F916_tx_pit[cdl2_sublist_F916_num_tx_pit];

constexpr unsigned_16 cdl2_num_wr_pit{CDL2_NUM_WR_PIT};
cdl2_wr_pit_t cdl2_wr_pit[cdl2_num_wr_pit];

constexpr unsigned_16 cdl2_sublist_D0_num_wr_pit{CDL2_SUBLIST_D0_NUM_WR_PIT};
cdl2_wr_pit_t cdl2_sublist_D0_wr_pit[cdl2_sublist_D0_num_wr_pit];

constexpr unsigned_16 cdl2_sublist_D1_num_wr_pit{CDL2_SUBLIST_D1_NUM_WR_PIT};
cdl2_wr_pit_t cdl2_sublist_D1_wr_pit[cdl2_sublist_D1_num_wr_pit];

constexpr unsigned_16 cdl2_sublist_D2_num_wr_pit{CDL2_SUBLIST_D2_NUM_WR_PIT};
cdl2_wr_pit_t cdl2_sublist_D2_wr_pit[cdl2_sublist_D2_num_wr_pit];

constexpr unsigned_16 cdl2_sublist_D3_num_wr_pit{CDL2_SUBLIST_D3_NUM_WR_PIT};
cdl2_wr_pit_t cdl2_sublist_D3_wr_pit[cdl2_sublist_D3_num_wr_pit];

constexpr unsigned_16 cdl2_sublist_F916_num_wr_pit{CDL2_SUBLIST_F916_NUM_WR_PIT};
cdl2_wr_pit_t cdl2_sublist_F916_wr_pit[cdl2_sublist_F916_num_wr_pit];

constexpr unsigned_16 cdl2_num_cmn_rx_pit{CDL2_NUM_CMN_RX_PIT};
const cdl2_cmn_rx_pit_t* cdl2_cmn_rx_pit[cdl2_num_cmn_rx_pit];