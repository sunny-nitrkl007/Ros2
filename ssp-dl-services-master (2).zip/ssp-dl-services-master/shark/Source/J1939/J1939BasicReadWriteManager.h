/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Basic Read Write Manager

#pragma once

#include "IWriteSharkByte.h"
#include <Config/Pid.h>
#include <SharkConfiguration.pb.h>
#include <Utilities/nice_ptr.h>
#include <memory>
#include <vector>

namespace Shark
{
class DependencyContainer;
class IWorkQueue;

namespace J1939
{
class IJ1939Wrapper;
class IJ1939WriteCallbackManager;

class J1939BasicReadWriteManager final
{
public:
	static bool ShouldBeCreated(DependencyContainer const& dependencyContainer);
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);

	J1939BasicReadWriteManager(
		cat::shark::J1939DataLink const& j1939DataLink,
		IWorkQueue& j1939TaskWorkQueue,
		IJ1939Wrapper& j1939Wrapper,
		std::unique_ptr<IJ1939WriteCallbackManager>&& spWriteCallbackManager) noexcept;
	~J1939BasicReadWriteManager();

	void Initialize();

	void Write(
		unsigned destinationAddress,
		unsigned pid,
		std::vector<uint8_t> const& data,
		IWriteSharkByte::CompletedCallback const& completedCallback);

private:
	void ResponseHandler(
		unsigned address,
		unsigned pid,
		uint8_t const* pData,
		unsigned dataLength);
	struct WriteCompleteCallback
	{
		unsigned address;
		unsigned pid;
		IWriteSharkByte::CompletedCallback completedCallback;
	};

	cat::shark::J1939DataLink const& m_j1939DataLink;
	IWorkQueue& m_j1939TaskWorkQueue;
	IJ1939Wrapper& m_j1939Wrapper;
	std::unique_ptr<IJ1939WriteCallbackManager> const m_spWriteCallbackManager;
};
}
}
