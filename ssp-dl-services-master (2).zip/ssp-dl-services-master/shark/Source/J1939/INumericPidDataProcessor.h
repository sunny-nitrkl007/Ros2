/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Numeric PID Data Processor Interface

#pragma once

#include "Utilities/ArrayView.h"
#include "Config/CanPort.h"
#include "Config/J1939Address.h"
#include "Config/Pid.h"
#include <cstdint>

namespace Shark
{
namespace J1939
{
class INumericPidDataProcessor
{
public:
	virtual ~INumericPidDataProcessor() = default;

	virtual void ProcessBuffer(
		Config::CanPort canPort,
		Config::J1939Address address,
		Config::Pid pid,
		Utilities::ArrayView<uint8_t const> const& data) const = 0;

	/// dataStatus should be of the form 0xFFxx
	virtual void ReportFailure(
		Config::CanPort canPort,
		Config::J1939Address address,
		Config::Pid pid,
		unsigned dataStatus) const = 0;
};
}
}