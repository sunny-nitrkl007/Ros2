/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See J1939ExtensionIdTxManager.h

#include "J1939ExtensionIdTxManager.h"
#include "DependencyContainer.h"
#include "IJ1939Wrapper.h"
#include <Config/ProtobufConversions.h>
#include "Utilities/CountOf.h"
#include <hal_boot_proto.h>
#include <algorithm>
#include <cstring>
#include <optional>

namespace Shark
{
namespace J1939
{
namespace
{
constexpr unsigned const n_readExtensionIdsToHandle[] { 0xF003, 0xF019, 0xF01A, 0xF0A6, 0xF0BD };
constexpr unsigned const n_deviceIdReadExtensionId = 0xF016;
constexpr auto n_pPartNumber = "1234567-89";
constexpr auto n_pGroupDescription = "A7Hx POC";
constexpr auto n_pReleaseDate = "AUG2025";
constexpr auto n_flashComponentId = 49;
constexpr auto n_flashApplicationId = 588;
constexpr auto n_pNameCode = "A4043";

void AppendMultiByteValueToMessage(unsigned value, unsigned byteCount, std::vector<unsigned_8>& message, bool swapBytes = true)
{
	unsigned_8 const* pValueArray = reinterpret_cast<unsigned_8 const*>(&value);
	if (swapBytes)
	{
		std::reverse_copy(pValueArray, pValueArray + byteCount, back_inserter(message));
	}
	else
	{
		std::copy(pValueArray, pValueArray + byteCount, back_inserter(message));
	}
}
// outputs big-endian
unsigned AddTwoByteValueToMessage(unsigned value, unsigned index, unsigned_8 message[])
{
	unsigned_8 const* pValueArray = reinterpret_cast<unsigned_8 const*>(&value);
	std::reverse_copy(pValueArray, pValueArray + 2, &message[index]);
	return index + 2;
}
unsigned AddStringToMessage(char const* pStringToAdd, unsigned length, unsigned index, unsigned_8 message[])
{
	std::copy_n(pStringToAdd, length, &message[index]);
	return index + length;
}
}

std::function<void()> J1939ExtensionIdTxManager::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	auto const& j1939DataLinkConfigs = dependencyContainer.GetJ1939DataLinkConfigs();
	std::vector<Utilities::nice_ptr<IJ1939Wrapper>> j1939Wrappers{};
	j1939Wrappers.reserve(j1939DataLinkConfigs.size());
	for (auto const& j1939DataLinkConfig : j1939DataLinkConfigs)
	{
		auto const canPort = Config::ToConfigCanPort(j1939DataLinkConfig->can_port());
		j1939Wrappers.push_back(&dependencyContainer.GetIJ1939Wrapper(canPort));
	}

	auto const& sharkConfig = dependencyContainer.GetSharkConfig();
	std::optional<cat::shark::J1939DataLink::DeviceId> deviceIdConfig{};
	if (sharkConfig.has_j1939_device_id())
	{
		deviceIdConfig.emplace(sharkConfig.j1939_device_id());
	}
	auto spJ1939ExtensionIdTxManager = std::make_shared<J1939ExtensionIdTxManager>(
		std::move(j1939Wrappers),
		deviceIdConfig);

	return [spJ1939ExtensionIdTxManager]{ spJ1939ExtensionIdTxManager->Initialize(); };
}

J1939ExtensionIdTxManager::J1939ExtensionIdTxManager(
	std::vector<Utilities::nice_ptr<IJ1939Wrapper>>&& j1939Wrappers,
	std::optional<cat::shark::J1939DataLink::DeviceId> deviceIdConfig) noexcept
	: m_j1939Wrappers(std::move(j1939Wrappers))
	, m_deviceIdConfig(deviceIdConfig)
{
}
void J1939ExtensionIdTxManager::Initialize()
{
	auto const serialNumber = hal_boot_get_ecm_serialno();
	auto const pSerialNumberString = serialNumber.string;
	m_hardwareSerialNumberStringValue = std::string{pSerialNumberString, pSerialNumberString + serialNumber.length};

	auto const partNumber = hal_boot_get_ecm_partno();
	auto const pPartNumberString = partNumber.string;
	m_hardwarePartNumberStringValue = std::string{pPartNumberString, pPartNumberString + partNumber.length};

	m_locationCodeValue = hal_boot_read_location_code();

	for (auto spJ1939Wrapper : m_j1939Wrappers)
	{
		RegisterHandlers(*spJ1939Wrapper);
	}
}
void J1939ExtensionIdTxManager::RegisterHandlers(IJ1939Wrapper& j1939Wrapper)
{
	for (auto extensionId : n_readExtensionIdsToHandle)
	{
		j1939Wrapper.RegisterExtensionIdCommandIdHandler(
			ExtensionIdCommand::ReadRequest,
			extensionId,
			[this, extensionId, &j1939Wrapper](unsigned address, uint8_t const*, unsigned)
			{
				ResponseHandler(j1939Wrapper, extensionId, address);
			});
	}
	if (m_deviceIdConfig)
	{
		j1939Wrapper.RegisterExtensionIdCommandIdHandler(
			ExtensionIdCommand::ReadRequest,
			n_deviceIdReadExtensionId,
			[this, &j1939Wrapper](unsigned address, uint8_t const*, unsigned)
			{
				ResponseHandler(j1939Wrapper, n_deviceIdReadExtensionId, address);
			});
	}
}
void J1939ExtensionIdTxManager::ResponseHandler(IJ1939Wrapper& j1939Wrapper, unsigned extensionId, unsigned address)
{
	struct IdToHandler
	{
		unsigned extensionId;
		void (J1939ExtensionIdTxManager::*pHandler)(IJ1939Wrapper& j1939Wrapper, unsigned address);
	};
	static constexpr IdToHandler const n_extensionIdToHandlerMappings[]
	{
		{ 0xF003, &J1939ExtensionIdTxManager::SendF003ReadResponse },
		{ n_deviceIdReadExtensionId, &J1939ExtensionIdTxManager::SendF016ReadResponse },
		{ 0xF019, &J1939ExtensionIdTxManager::SendF019ReadResponse },
		{ 0xF01A, &J1939ExtensionIdTxManager::SendF01AReadResponse },
		{ 0xF0A6, &J1939ExtensionIdTxManager::SendF0A6ReadResponse },
		{ 0xF0BD, &J1939ExtensionIdTxManager::SendF0BDReadResponse },
	};

	auto const itFound = std::ranges::find_if(n_extensionIdToHandlerMappings,
		[extensionId](auto const& mapping)
		{
			return mapping.extensionId == extensionId;
		});
	if (itFound != std::end(n_extensionIdToHandlerMappings))
	{
		(this->*(itFound->pHandler))(j1939Wrapper, address);
	}
	else
	{
		assert(false && "No handler created for this read request!");
	}
}
namespace
{
constexpr unsigned_8 n_F003Message[]
{
	0xF0, 0x03,
	0x91, 0x10, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, // insert ecm serial number
	0x92, 0x04, 0xFF, 0xFF, 0xFF, 0xFF, // insert ecm hardware type code
	0x40, 0x02, 0xFF, 0xFF, // insert location code
	0x01, 0x01, 0x04,
	0x82, 0x0A, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, // insert ecm part number
	0x83, 0x10, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
	0x45, 0x03, 0xFF, 0x00, 0x01,
	0x46, 0x02, 0xFF, 0xFF,
	0x41, 0x02, 0xFF, 0xFF, // insert flash component id
	0x42, 0x02, 0xFF, 0xFF, // insert flash application id
	0x84, 0x0B, 0x02, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, // insert software part number
	0x90, 0x02, 0x00, 0x04,
	0x84, 0x00,
};
constexpr unsigned_8 const n_asterisk { 0x2A };
constexpr unsigned_8 const n_F016Version1 { 0x01 };
constexpr unsigned_8 const n_F016Version2 { 0x02 };
constexpr unsigned n_F003MessageLength { Utilities::CountOf(n_F003Message) };
constexpr unsigned n_hardwareSerialNumberStartByte { 4 };
constexpr unsigned n_hardwareSerialNumberLength { 16 };
constexpr unsigned n_hardwareTypeCodeStartByte{ 22 };
constexpr unsigned n_hardwareTypeCodeLength{ 4 };
constexpr unsigned n_hardwareTypeCodeOffset{ 12 };
constexpr unsigned n_locationcodeStartByte{ 28 };
constexpr unsigned n_hardwarePartNumberStartByte { 35 };
constexpr unsigned n_hardwarePartNumberLength { 10 };
constexpr unsigned n_flashComponentIdStartByte { 74 };
constexpr unsigned n_flashApplicationIdStartByte { 78 };
constexpr unsigned n_softwarePartNumberStartByte { 83 };
constexpr unsigned n_softwarePartNumberLength { 10 };
constexpr unsigned_8 const n_useBasicReadWriteWithET { 0x01 };
}
void J1939ExtensionIdTxManager::SendF003ReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address)
{
	unsigned_8 localMessage[n_F003MessageLength] {};
	std::copy_n(n_F003Message, n_F003MessageLength, localMessage);

	assert(m_hardwareSerialNumberStringValue.size() == n_hardwareSerialNumberLength);
	AddStringToMessage(
		m_hardwareSerialNumberStringValue.c_str(),
		n_hardwareSerialNumberLength,
		n_hardwareSerialNumberStartByte,
		localMessage);
	AddStringToMessage(
		m_hardwareSerialNumberStringValue.c_str() + n_hardwareTypeCodeOffset,
		n_hardwareTypeCodeLength,
		n_hardwareTypeCodeStartByte,
		localMessage);

	assert(m_hardwarePartNumberStringValue.size() == n_hardwarePartNumberLength);
	AddStringToMessage(
		m_hardwarePartNumberStringValue.c_str(),
		n_hardwarePartNumberLength,
		n_hardwarePartNumberStartByte,
		localMessage);

	AddTwoByteValueToMessage(m_locationCodeValue, n_locationcodeStartByte, localMessage);

	AddTwoByteValueToMessage(
		n_flashComponentId,
		n_flashComponentIdStartByte,
		localMessage);

	AddTwoByteValueToMessage(
		n_flashApplicationId,
		n_flashApplicationIdStartByte,
		localMessage);

	AddStringToMessage(
		n_pPartNumber,
		n_softwarePartNumberLength,
		n_softwarePartNumberStartByte,
		localMessage);

	j1939Wrapper.SendPropAMessage(address, localMessage, Utilities::CountOf(localMessage));
}
void J1939ExtensionIdTxManager::SendF016ReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address)
{
	std::vector<unsigned_8> message{};
	message.reserve(2 + 1 + 2 + 2 + 2 + 2 + 4);
	AppendMultiByteValueToMessage(n_deviceIdReadExtensionId, 2, message);

	assert(m_deviceIdConfig);
	auto const& config = m_deviceIdConfig.value();
	config.has_fid() ? message.push_back(n_F016Version2) : message.push_back(n_F016Version1);
	AppendMultiByteValueToMessage(config.module_id(), 2, message, false);
	AppendMultiByteValueToMessage(config.service_tool_support_level(), 2, message, false);
	AppendMultiByteValueToMessage(config.application_id(), 2, message, false);
	AppendMultiByteValueToMessage(config.minimum_service_tool_support_level(), 2, message, false);
	if (config.has_fid())
	{
		AppendMultiByteValueToMessage(config.fid(), 4, message, false);
	}

	j1939Wrapper.SendPropAMessage(address, message.data(), static_cast<unsigned>(message.size()));
}
void J1939ExtensionIdTxManager::SendF019ReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address)
{
	std::vector<unsigned_8> message{};
	message.reserve(2 + 50 + 1 + 100 + 1 + 7 + 1);

	AppendMultiByteValueToMessage(0xF019, 2, message);
	auto& pPartNumber = n_pPartNumber;
	message.insert(message.end(), pPartNumber, pPartNumber + std::strlen(pPartNumber));
	message.push_back(n_asterisk);
	auto& pGroupDescription = n_pGroupDescription;
	message.insert(message.end(), pGroupDescription, pGroupDescription + std::strlen(pGroupDescription));
	message.push_back(n_asterisk);
	auto& pReleaseDate = n_pReleaseDate;
	message.insert(message.end(), pReleaseDate, pReleaseDate + std::strlen(pReleaseDate));
	message.push_back(n_asterisk);
	j1939Wrapper.SendPropAMessage(address, message.data(), static_cast<unsigned>(message.size()));
}
void J1939ExtensionIdTxManager::SendF01AReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address)
{
	std::vector<unsigned_8> message{};
	message.reserve(2 + 50 + 1 + 50 + 1);

	AppendMultiByteValueToMessage(0xF01A, 2, message);
	message.insert(message.end(), m_hardwarePartNumberStringValue.begin(), m_hardwarePartNumberStringValue.end());
	message.push_back(n_asterisk);
	message.insert(message.end(), m_hardwareSerialNumberStringValue.begin(), m_hardwareSerialNumberStringValue.end());
	message.push_back(n_asterisk);
	j1939Wrapper.SendPropAMessage(address, message.data(), static_cast<unsigned>(message.size()));
}
void J1939ExtensionIdTxManager::SendF0A6ReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address)
{
	std::vector<unsigned_8> message{};
	message.reserve(2 + 6);

	AppendMultiByteValueToMessage(0xF0A6, 2, message);
	message.push_back(n_useBasicReadWriteWithET);
	message.insert(message.end(), 5, 0xFF);
	j1939Wrapper.SendPropAMessage(address, message.data(), static_cast<unsigned>(message.size()));
}
void J1939ExtensionIdTxManager::SendF0BDReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address)
{
	std::vector<unsigned_8> message{};
	message.reserve(2 + 1 + 5);

	AppendMultiByteValueToMessage(0xF0BD, 2, message);
	auto& pNameCode = n_pNameCode;
	message.push_back(static_cast<unsigned_8>(std::strlen(pNameCode)));
	message.insert(message.end(), pNameCode, pNameCode + std::strlen(pNameCode));
	j1939Wrapper.SendPropAMessage(address, message.data(), static_cast<unsigned>(message.size()));
}
}
}
