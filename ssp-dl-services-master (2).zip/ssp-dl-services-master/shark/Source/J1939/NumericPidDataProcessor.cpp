/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See NumericPidDataProcessor.h

#include "NumericPidDataProcessor.h"
#include "IPidDataReceiver.h"
#include "J1939Definitions.h"
#include "Utilities/CountOf.h"
#include "Utilities/narrow_cast.h"
#include <tuple>

namespace Shark
{
namespace J1939
{
NumericPidDataProcessor::NumericPidDataProcessor(IPidDataReceiver& pidDataReceiver) noexcept
	: m_pidDataReceiver{pidDataReceiver}
{
}
void NumericPidDataProcessor::ProcessBuffer(
	Config::CanPort canPort,
	Config::J1939Address address,
	Config::Pid pid,
	Utilities::ArrayView<uint8_t const> const& data) const
{
	auto pDataToPass = data.begin(); // Let the receiver handle the error of the dataLength not matching the PID definition.
	auto const dataLength = Utilities::narrow_cast<unsigned>(data.size());
	unsigned dataStatus{0};

	if (pDataToPass)
	{
		m_pidDataReceiver.ReceivePidData(
			canPort,
			address,
			pid,
			pDataToPass,
			dataLength,
			dataStatus);
	}
	else
	{
		ReportFailure(canPort, address, pid, dataStatus);
	}
}
void NumericPidDataProcessor::ReportFailure(Config::CanPort canPort, Config::J1939Address address, Config::Pid pid, unsigned dataStatus) const
{
	m_pidDataReceiver.ReceivePidData(canPort, address, pid, nullptr, 0, dataStatus);
}
}
}