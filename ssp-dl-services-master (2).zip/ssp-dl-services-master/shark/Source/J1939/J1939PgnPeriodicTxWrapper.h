/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 PGN Broadcast Transmit Wrapper

#pragma once

#include <Utilities/DefineExceptionClass.h>
#include <functional>

namespace Shark
{
class DependencyContainer;

namespace J1939
{
class IJ1939Wrapper;

class J1939PgnPeriodicTxWrapper final
{
public:
	struct SharkByteAndTxMessagePair
	{
		ISharkByte& sharkByte;
		scl_j1939_tx_msg_t sclJ1939TxMessage;
	};
	using SharkByteAndTxMessagePairs = std::vector<SharkByteAndTxMessagePair>;

	static bool ShouldBeCreated(DependencyContainer const& dependencyContainer);
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);
	static boolean_t PopulatePgn(
		scl_j1939_mbuf_hdr_t* pMBuf,
		const scl_j1939_tx_msg_t* pTxMsg,
		unsigned_8 statusByte,
		void* pContext);

	J1939PgnPeriodicTxWrapper(IJ1939Wrapper& j1939Wrapper) noexcept;
	~J1939PgnPeriodicTxWrapper();

	DEFINE_EXCEPTION_CLASS(Error);

	void Initialize(SharkByteAndTxMessagePairs const& sharkByteAndTxMessagePairs);
private:
	IJ1939Wrapper& m_j1939Wrapper;
};
}
}
