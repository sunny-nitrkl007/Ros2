/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Write Callback Manager

#pragma once

#include "IJ1939WriteCallbackManager.h"
#include "SharkUtilities/IEventCallbackFactory.h"
#include <memory>
#include <mutex>
#include <vector>

namespace Shark
{
namespace SharkUtilities
{
class ITimedCallback;
class IEventCallbackFactory;
}

namespace J1939
{
class J1939WriteCallbackManager final : public IJ1939WriteCallbackManager
{
public:
	J1939WriteCallbackManager(SharkUtilities::IEventCallbackFactory& eventCallbackFactory) noexcept;
// IJ1939WriteCallbackManager
	void Add(unsigned address, unsigned id, IWriteSharkByte::CompletedCallback const& callback) override;
	void Callback(unsigned address, unsigned id, std::optional<std::vector<uint8_t>> const& responseData) override;
private:
	struct CallbackData
	{
		unsigned address;
		unsigned id;
		IWriteSharkByte::CompletedCallback callback;
		std::unique_ptr<SharkUtilities::ITimedCallback> spTimedCallback;
	};

	SharkUtilities::IEventCallbackFactory& m_eventCallbackFactory;
	std::vector<CallbackData> m_activeCallbacks{};
	std::mutex m_mutex{};
};
}
}
