/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Transport Protocol Client Synchronizer

#pragma once

#include "ITransportProtocolClientSynchronizer.h"
#include "Utilities/Clock.h"
#include <cassert>
#include <memory>
#include <mutex>
#include <vector>

namespace Shark
{
class IPeriodicTaskManager;

namespace J1939
{
class TransportProtocolSender;

class TransportProtocolClientSynchronizer final : public ITransportProtocolClientSynchronizer
{
public:
	static std::unique_ptr<TransportProtocolClientSynchronizer> Create(IPeriodicTaskManager& periodicTaskManager);
	static void AddPeriodicTask(
		IPeriodicTaskManager& periodicTaskManager,
		TransportProtocolClientSynchronizer& TransportProtocolClientSynchronizer);

	TransportProtocolClientSynchronizer() noexcept;
// ITransportProtocolClientSynchronizer
	void Add(TransportProtocolRequest const& request, std::function<SendMethod>&& sendMethod) override;
	void Remove(TransportProtocolRequest const& request) override;
	void RetryLaterIfCurrent(TransportProtocolRequest const& request) override;
private:
	void Update();
	void RemoveCurrentRequest();
	void ResetRetryParameters();

	Utilities::Clock::time_point m_retryTime{};
	unsigned m_retryCount{};
	std::mutex m_mutex{};
	std::vector<std::shared_ptr<TransportProtocolSender>> m_requests{};
};
}
}
