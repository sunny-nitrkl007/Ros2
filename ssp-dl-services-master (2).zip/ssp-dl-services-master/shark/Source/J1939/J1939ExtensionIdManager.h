/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Extension Id Read Manager

#pragma once

#include "ITransportProtocolClientSynchronizer.h"
#include <Config/CanPort.h>
#include <SharkConfiguration.pb.h>
#include <Utilities/nice_ptr.h>
#include <memory>
#include <vector>

namespace Utilities
{
class TransientSharkByte;
}

namespace Shark
{
class DependencyContainer;

namespace J1939
{
class IJ1939Wrapper;

class J1939ExtensionIdManager final
{
public:
	struct SharkByteMapping
	{
		unsigned address;
		unsigned extensionId;
		Utilities::nice_ptr<Utilities::TransientSharkByte> spSharkByte;
	};

	static bool ShouldBeCreated(DependencyContainer const& dependencyContainer);
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);

	J1939ExtensionIdManager(
		cat::shark::J1939DataLink const& j1939DataLink,
		IJ1939Wrapper& j1939Wrapper,
		ITransportProtocolClientSynchronizer& synchronizer) noexcept;
	~J1939ExtensionIdManager();

	void SetSharkByteMappings(std::vector<SharkByteMapping>&& mappings);
	void Initialize();

	void Refresh(unsigned address, unsigned extensionId);

private:
	void SendReadRequest(TransportProtocolRequest const& request);
	void RegisterReceiveHandlers(unsigned extensionId);
	Utilities::nice_ptr<Utilities::TransientSharkByte> FindSharkByte(unsigned address, unsigned extensionId) const;
	void ReadResponseHandler(unsigned address, uint8_t const* pMessage, unsigned messageLength);
	void NackHandler(unsigned address, unsigned extensionId, uint8_t const* pMessage, unsigned messageLength);

	cat::shark::J1939DataLink const& m_j1939DataLink;
	IJ1939Wrapper& m_j1939Wrapper;
	ITransportProtocolClientSynchronizer& m_synchronizer;
	std::vector<SharkByteMapping> m_sharkByteMappings;
};
}
}
