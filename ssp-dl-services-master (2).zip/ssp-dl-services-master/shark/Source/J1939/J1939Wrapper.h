/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Wrapper

#pragma once

#include "IJ1939Wrapper.h"
#include "IPgnDataRefresher.h"
#include "J1939WrapperHelper.h"
#include "IPgnHelper.h"
#include "Utilities/nice_ptr.h"
#include <SharkConfiguration.pb.h>
#include <cstdint>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <unordered_map>

namespace Utilities { class SimpleSharkByte; }
namespace Shark
{
class DependencyContainer;
class ICommandManager;
class IWorkQueue;

namespace J1939
{
class IJ1939PublicDefinitionRetriever;

struct AddressTableConfigData
{
	scl_j1939_addr_tbl_t addressTable{};
	std::vector<scl_j1939_rx_msg_t> rxPgnConfigs{};
};
std::string ConvertRxEventToString(cdl2_con_rx_event_t const& event);

class SclAddressTableConfiguration final
{
public:
	SclAddressTableConfiguration(cat::shark::J1939DataLink const& j1939DataLinkConfig);
	std::vector<uint8_t> const& GetAddressList() const { return m_addressList; }
	scl_j1939_addr_tbl_t const* GetSclAddressTable() const { return &m_addressTableData.addressTable; }
	std::vector<scl_j1939_rx_msg_t> const& GetRxPgnConfigs() const { return m_addressTableData.rxPgnConfigs; }
	J1939NameFields const& GetJ1939NameFields() const { return m_j1939NameFields; }
private:
	std::vector<uint8_t> m_addressList;
	J1939NameFields const m_j1939NameFields;
	AddressTableConfigData m_addressTableData;
};

struct PidWriteHandlerPie
{
	unsigned_8 length;
	std::function<IJ1939Wrapper::PidWriteHandler> pidWriteHandler;
};

class J1939Wrapper final : public IJ1939Wrapper, public IPgnDataRefresher
{
public:
	static volatile hal_canv3_port_t* GetHalCanv3Port(Config::CanPort canPort);

	static std::unique_ptr<SclAddressTableConfiguration const> CreateSclAddressTableConfiguration(
		cat::shark::J1939DataLink const& j1939DataLinkConfig);

	static std::unique_ptr<J1939Wrapper> Create(
		DependencyContainer& dependencyContainer,
		IPgnHelper& pgnHelper,
		cat::shark::J1939DataLink const& j1939DataLinkConfig);

	J1939Wrapper(
		IPgnHelper& pgnHelper,
		std::unique_ptr<IWorkQueue>&& spTaskWorkQueue,
		cat::shark::J1939DataLink const& j1939DataLinkConfig,
		Config::CanPort canPort) noexcept;
	~J1939Wrapper() override;
	void SetAddressTableConfig(std::unique_ptr<SclAddressTableConfiguration const>&& spSclAddressTableConfiguration);
	void Update();

	static void AddressClaimCallback(
		const scl_j1939_link_t Ph_link,
		const int_8 Pu8_ecm_idx,
		const SCL_J1939_AC_STATUS_CB_ENUM_t Pu8_status,
		const unsigned_8 Pu8_address);
	static void DM13Callback(
		scl_j1939_link_t link,
		unsigned_8 ecm_index,
		unsigned_8 remote_address,
		scl_j1939_suspend_t status,
		unsigned_16,
		boolean_t,
		void*);

// IJ1939Wrapper
	void EstablishLink(scl_j1939_config_t const& j1939Config) override;
	void Initialize() override;
	Config::CanPort GetCanPort() const override;
	scl_j1939_link_t GetLink() const override;
	J1939NameFields const& GetJ1939NameFields() const override;
	Utilities::nice_ptr<scl_pgb_j1939_t> GetPgbContext() const override;
	scl_adt_j1939_link_handle_t GetAdtHandle() const override;
	bool SendPropAMessage(unsigned destinationAddress, uint8_t const* pData, unsigned dataLength) override;
	bool SendPropAMessageByName(J1939Name const j1939Name, uint8_t const* pData, unsigned dataLength) override;
	bool SendPgnMessage(unsigned pgn, unsigned destinationAddress, uint8_t const* pData, unsigned dataLength) override;
	bool SendDM13Suspend() override;
	void RegisterExtensionIdCommandHandler(
		unsigned extensionIdCommand,
		std::function<ExtensionIdHandler>&& handler) override;
	void RegisterExtensionIdCommandIdHandler(
		ExtensionIdCommand extensionIdCommand,
		unsigned extensionId,
		std::function<ExtensionIdHandler>&& handler) override;
	void RegisterPidRequestHandler(unsigned pid, std::function<PidRequestHandler>&& handler) override;
	void RegisterPidReadHandler(unsigned pid, std::function<PidReadHandler>&& handler) override;
	void RegisterPidWriteHandler(unsigned pid, std::function<PidWriteHandler>&& handler) override;
	void AddPgbGroups(
		unsigned address,
		unsigned pidCount,
		scl_pgb_j1939_rx_pid_cfg_ptr_t const* pPidTable,
		unsigned requestedUpdateRate,
		unsigned timeOut) override;
	void AddAdtGroups(
		unsigned address,
		unsigned pidCount,
		scl_adt_j1939_client_grp_pid_config_ptr_t const* pPidConfig,
		std::optional<std::chrono::milliseconds> timeout) override;
	unsigned GetPgnRxTableIndex(unsigned address, unsigned pgn) const override;
	unsigned GetPgnRxTableTimeout(unsigned address, unsigned pgn) const override;
	void RegisterForDM13Status(std::function<DM13StatusCallback>&& callback) override;
	bool EcmIsConnectedToLink(Config::J1939Address address) override;
	std::vector<scl_j1939_nar_entry_t> GetConnectedEcms() override;

// IPgnDataRefresher
	void Refresh(unsigned refreshContext) override;
private:
	static void CommonExtensionIdCommandIdHandler(scl_j1939_mbuf_hdr_t const* mbuf_ptr, void* context);
	static int_16 CommonPidRequestHandler(
		cdl2_con_rx_data_link_t data_link_type,
		unsigned_32 con_index,
		cdl2_con_rx_event_t ack_event,
		void *rx_pie,
		unsigned_8 sid,
		unsigned_8 did,
		unsigned_32 data_ID,
		unsigned_8 pdl,
		unsigned_8 *data);
	static int_16 CommonPidReadHandler(void* tx_pie, unsigned_8* data);
	static int_16 CommonPidWriteHandler(void* wr_pie, unsigned_16 len, unsigned_8* data);

	bool IsInitialized() const { return static_cast<bool>(m_spPgbContext); }
	void ConfigureScl();
	void HandleAddressClaim(SCL_J1939_AC_STATUS_CB_ENUM_t Pu8_status, unsigned_8 Pu8_address);
	void InitializeDM13Statuses(cat::shark::J1939DataLink const& j1939DataLinkConfig);
	void UpdateRemoteDM13Status(unsigned address, DM13State state);
	void CallbackPidRequests(PidRequestStatus status, unsigned address, unsigned pid, uint8_t const* pData, unsigned dataLength);

	IPgnHelper& m_pgnHelper;
	std::unique_ptr<IWorkQueue> const m_spTaskWorkQueue;
	Config::CanPort const m_canPort;
	std::unique_ptr<SclAddressTableConfiguration const> m_spSclAddressTableConfiguration{};
	scl_j1939_link_t m_link{SCL_J1939_INVALID_LINK};
	scl_adt_j1939_link_handle_t m_adtLinkHandle{SCL_ADT_J1939_INVALID_HANDLE};
	Utilities::nice_ptr<scl_pgb_j1939_t> m_spPgbContext{};
	J1939WrapperHelper const m_wrapperHelper;
	bool m_addressClaimCallbackOccurred{false};

	// Uses a deque instead of a vector so that emplace_back does not invalidate pointers to existing entries
	struct ExtensionIdHandlerContext
	{
		SCL_J1939_CAT_PPGN_ID_HDLR_t m_sclHandler;
		std::function<ExtensionIdHandler> m_handler;
	};
	ExtensionIdHandlerContext& AddExtensionIdHandler(
		unsigned extensionIdCommand,
		unsigned extensionId,
		std::function<ExtensionIdHandler>&& handler);
	std::deque<ExtensionIdHandlerContext> m_extensionIdHandlerContexts{};

	std::unordered_map<unsigned, std::vector<std::function<PidRequestHandler>>> m_pidRequestHandlerCallbacks{};
	std::deque<std::function<PidReadHandler>> m_pidReadHandlerCallbacks{};
	std::deque<PidWriteHandlerPie> m_pidWriteHandlerPies{};
	std::deque<std::function<DM13StatusCallback>> m_dm13StatusCallbacks{};
	std::mutex m_dm13Mutex{};
	std::vector<std::pair<unsigned, DM13State>> m_dm13Statuses{};
};
}
}
