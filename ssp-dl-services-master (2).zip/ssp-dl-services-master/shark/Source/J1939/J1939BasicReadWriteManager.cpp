/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See J1939BasicReadWriteManager.h

#include "J1939BasicReadWriteManager.h"
#include "Config/ProtobufConversions.h"
#include "DependencyContainer.h"
#include "IJ1939Wrapper.h"
#include "SharkBytes/IWriteSharkByteManager.h"
#include "J1939Definitions.h"
#include "J1939WriteCallbackManager.h"
#include "Log.h"
#include "SharkBytes/AsynchronousValueWriteSlot.h"
#include <Utilities/ArrayToHexString.h>

namespace Shark
{
namespace J1939
{
namespace
{
void CreateWriteSharkBytes(
	J1939BasicReadWriteManager& readWriteManager,
	SharkBytes::IWriteSharkByteManager& writeSharkByteManager,
	cat::shark::J1939DataLink const& j1939DataLink)
{
	for (auto&& peerNode : j1939DataLink.peer_nodes())
	{
		if (peerNode.has_basic_read_write())
		{
			auto const address = peerNode.address();
			for (auto&& readWriteEntry : peerNode.basic_read_write().basic_read_write_pids())
			{
				auto const pid = readWriteEntry.pid();
				writeSharkByteManager.AddWriteSharkByte(std::make_unique<Shark::SharkBytes::AsynchronousValueWriteSlot>(
					readWriteEntry.middleware_id().c_str(),
					[&readWriteManager, address, pid](auto&& value, auto&& completedCallback)
					{
						readWriteManager.Write(
							address,
							pid,
							value,
							completedCallback);
					}));
			}
		}
	}
}
bool J1939DataLinkConfigHasBasicReadWrite(cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	auto const& peerNodes = j1939DataLinkConfig.peer_nodes();
	return std::any_of(peerNodes.begin(),peerNodes.end(),
		[](auto const& peerNode) { return peerNode.has_basic_read_write(); });
}

std::array<Utilities::nice_ptr<J1939BasicReadWriteManager>, Config::CanPort::CanPortCount> n_j1939BasicReadWriteManagers{};
}

bool J1939BasicReadWriteManager::ShouldBeCreated(DependencyContainer const& dependencyContainer)
{
	auto const& configs = dependencyContainer.GetJ1939DataLinkConfigs();
	return std::any_of(configs.begin(), configs.end(),
		[](auto const& spJ1939DataLinkConfig)
		{
			return J1939DataLinkConfigHasBasicReadWrite(*spJ1939DataLinkConfig);
		});
}
std::function<void()> J1939BasicReadWriteManager::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	struct InitializerContext
	{
		std::shared_ptr<J1939BasicReadWriteManager> spJ1939BasicReadWriteManager;
	};
	std::vector<InitializerContext> initializerContexts{};

	for (auto spJ1939DataLinkConfig : dependencyContainer.GetJ1939DataLinkConfigs())
	{
		if (J1939DataLinkConfigHasBasicReadWrite(*spJ1939DataLinkConfig))
		{
			auto const canPort = Config::ToConfigCanPort(spJ1939DataLinkConfig->can_port());

			auto spJ1939BasicReadWriteManager = std::make_unique<J1939BasicReadWriteManager>(
				*spJ1939DataLinkConfig,
				dependencyContainer.GetJ1939TaskWorkQueue(canPort),
				dependencyContainer.GetIJ1939Wrapper(canPort),
				std::make_unique<J1939WriteCallbackManager>(dependencyContainer.GetIEventCallbackFactory()));

			CreateWriteSharkBytes(
				*spJ1939BasicReadWriteManager,
				dependencyContainer.GetIWriteSharkByteManager(),
				*spJ1939DataLinkConfig);

			initializerContexts.emplace_back(InitializerContext{std::move(spJ1939BasicReadWriteManager)});
		}
	}
	assert(!initializerContexts.empty());

	return [initializerContexts = std::move(initializerContexts)]()
	{
		for (auto const& context : initializerContexts)
		{
			context.spJ1939BasicReadWriteManager->Initialize();
		}
	};
}

J1939BasicReadWriteManager::J1939BasicReadWriteManager(
	cat::shark::J1939DataLink const& j1939DataLink,
	IWorkQueue& j1939TaskWorkQueue,
	IJ1939Wrapper& j1939Wrapper,
	std::unique_ptr<IJ1939WriteCallbackManager>&& spWriteCallbackManager) noexcept
	: m_j1939DataLink{j1939DataLink}
	, m_j1939TaskWorkQueue{j1939TaskWorkQueue}
	, m_j1939Wrapper{j1939Wrapper}
	, m_spWriteCallbackManager{std::move(spWriteCallbackManager)}
{
	auto const canPort = m_j1939Wrapper.GetCanPort();
	assert(!n_j1939BasicReadWriteManagers[canPort]);
	n_j1939BasicReadWriteManagers[canPort] = this;
}
J1939BasicReadWriteManager::~J1939BasicReadWriteManager()
{
	// Don't use m_j1939Wrapper here since it may have already been destroyed
	auto const itEnd = n_j1939BasicReadWriteManagers.end();
	auto const itFound = std::find(n_j1939BasicReadWriteManagers.begin(), itEnd, this);
	assert(itFound != itEnd);
	itFound->reset();

	[[maybe_unused]] auto const canPort =
		static_cast<Config::CanPort>(std::distance(n_j1939BasicReadWriteManagers.begin(), itFound));
	LOG_DEBUG_TAG(Log::Rw, "J1939BasicReadWriteManager destroyed for " << canPort);
}
void J1939BasicReadWriteManager::Initialize()
{
	for (auto const& peerNode : m_j1939DataLink.peer_nodes())
	{
		if (peerNode.has_basic_read_write())
		{
			for (auto const& readWritePid : peerNode.basic_read_write().basic_read_write_pids())
			{
				m_j1939Wrapper.RegisterPidRequestHandler(
					readWritePid.pid(),
					[this](
						PidRequestStatus,
						unsigned sourceAddress,
						unsigned pid,
						uint8_t const* pData,
						unsigned dataLength)
					{
						ResponseHandler(sourceAddress, pid, pData, dataLength);
					});
			}
		}
	}
}

namespace
{
void DumpTxData(unsigned destinationAddress, unsigned pid, std::vector<uint8_t> const& data)
{
	auto constexpr severity = Log::SeverityLevel::Debug;
	if (Log::ShouldLog(severity, Log::Rw))
	{
		std::string hexBytes = Utilities::ArrayToHexString(data.data(), static_cast<unsigned>(data.size()));
		LOG_TAG(severity, Log::Rw,
			"Basic Write Tx: DA: 0x" << std::hex << std::uppercase << destinationAddress << " " <<
			"PID: 0x" << pid << ", Data: " << hexBytes);
	}
}
}

void J1939BasicReadWriteManager::Write(
	unsigned destinationAddress,
	unsigned pid,
	std::vector<uint8_t> const& data,
	IWriteSharkByte::CompletedCallback const& completedCallback)
{
	assert(completedCallback);

	DumpTxData(destinationAddress, pid, data);

	unsigned messageSize =
		J1939Definitions::WriteWithDataResponseExtIdLength() + // The length of the Write extension id
		J1939Definitions::PidIdentifierByteCount(pid) + // The bytes needed to encode the PID
		(J1939Definitions::IsMultiBytePid(pid) ? 1 : 0) + // If the PID is a multi-byte PID, then we need an additional length byte
		static_cast<unsigned>(data.size()); // The data bytes

	std::vector<uint8_t> message(messageSize, J1939Definitions::WriteWithDataResponseExtId());

	auto currentIndex = J1939Definitions::AddPidToMessage(
		pid,
		J1939Definitions::WriteWithDataResponseExtIdLength(),
		message.data(),
		messageSize);

	if (J1939Definitions::IsMultiBytePid(pid))
	{
		message[currentIndex] = static_cast<uint8_t>(data.size());
		currentIndex++;
	}

	memcpy(&message[currentIndex], data.data(), data.size());
	currentIndex += static_cast<unsigned>(data.size());

	assert(currentIndex == message.size());

	auto const succeeded = m_j1939Wrapper.SendPropAMessage(destinationAddress, message.data(), currentIndex);

	if (!succeeded)
	{
		completedCallback(std::nullopt);
	}
	else
	{
		m_spWriteCallbackManager->Add(destinationAddress, pid, completedCallback);
	}
}
void J1939BasicReadWriteManager::ResponseHandler(
	unsigned address,
	unsigned pid,
	uint8_t const* pData,
	unsigned dataLength)
{
	std::optional<std::vector<uint8_t>> responseData{};
	if (pData)
	{
		responseData.emplace(pData, pData + dataLength);
		LOG_INFO_HIGH("Basic Write Response: SA: 0x" << std::hex << std::uppercase << address << " " <<
			"PID: 0x" << pid << ", Data: " << Utilities::ArrayToHexString(pData, dataLength));
	}

	m_spWriteCallbackManager->Callback(address, pid, responseData);
}
}
}
