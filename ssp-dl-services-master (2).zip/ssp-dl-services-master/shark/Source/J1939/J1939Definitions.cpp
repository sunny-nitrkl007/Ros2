/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See J1939Definitions.h

#include "J1939Definitions.h"
#include "Utilities/CountOf.h"
#include <algorithm>
#include <cassert>

namespace Shark
{
namespace J1939
{
unsigned J1939Definitions::PidIdentifierByteCount(Config::Pid pid)
{
	unsigned count{};
	if (pid & 0xFF0000)
	{
		count = 3;
	}
	else if (pid & 0xFF00)
	{
		count = 2;
	}
	else
	{
		count = 1;
	}

	return count;
}
unsigned J1939Definitions::AddPidToMessage(Config::Pid pid, unsigned index, uint8_t message[], unsigned maxLength)
{
	auto const pidByteCount = PidIdentifierByteCount(pid);
	assert(pidByteCount > 0 && pidByteCount <= 3);
	assert(index + pidByteCount <= maxLength); (void)maxLength;
	uint8_t const* pPidByteArray = reinterpret_cast<uint8_t const*>(&pid);
	std::reverse_copy(pPidByteArray, pPidByteArray + pidByteCount, &message[index]);
	return index + pidByteCount;
}
bool J1939Definitions::IsMultiBytePid(Config::Pid pid)
{
	return (0x80   <= pid && pid <= 0xC7  ) ||
	       (0xF800 <= pid && pid <= 0xFBFF);
}
bool J1939Definitions::IsFixedBytePid(Config::Pid pid)
{
	return (0x01     <= pid && pid <= 0x7F     ) ||
	       (0xC8     <= pid && pid <= 0xCE     ) ||
	       (0xF001   <= pid && pid <= 0xF3FF   ) ||
	       (0xF401   <= pid && pid <= 0xF7FF   ) ||
	       (0xFC01   <= pid && pid <= 0xFFFF   ) ||
	       (0xD00001 <= pid && pid <= 0xD0FFFF ) ||
	       (0xD10001 <= pid && pid <= 0xD1FFFF );
}
unsigned J1939Definitions::FixedPidDataLength(Config::Pid pid)
{
	auto dataLength = 0u;
	if ((0x40 <= pid && pid <= 0x7F) ||
	    (0xF401 <= pid && pid <= 0xF7FF) ||
	    (0xD00001 <= pid && pid <= 0xD0FFFF ) ||
	    (0xD10001 <= pid && pid <= 0xD1FFFF ))
	{
		dataLength = 2;
	}
	else if ((0x01 <= pid && pid <= 0x3F) || (0xF001 <= pid && pid <= 0xF3FF))
	{
		dataLength = 1;
	}
	else if ((0xC8 <= pid && pid <= 0xCE) || (0xFC01 <= pid && pid <= 0xFFFF))
	{
		dataLength = 4;
	}
	else
	{
		assert("Not a fixed byte PID");
	}
	return dataLength;
}
}
}
