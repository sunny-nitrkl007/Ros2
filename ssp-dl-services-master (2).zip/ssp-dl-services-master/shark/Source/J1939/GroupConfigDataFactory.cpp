/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PgbConfigDataFactory.h

#include "GroupConfigDataFactory.h"
#include "Config/ProtobufConversions.h"
#include "J1939Definitions.h"
#include "Log.h"
#include "Utilities/Conversions.h"
#include "Utilities/narrow_cast.h"
#include "Utilities/VectorReallocationMonitor.h"
#include <algorithm>
#include <boost/iterator/filter_iterator.hpp>
#include <tuple>

namespace Shark
{
namespace J1939
{
namespace
{
constexpr auto n_maxAdtGroupSize = 5u;
constexpr auto n_maxPgbGroupSize = 6u;

template <typename SclConfigObject, typename SclConfigCallbackType>
SclConfigObject CreateGroupConfig(
	Config::Pid pid,
	SclConfigCallbackType* pReceiveHandler)
{
	assert(pReceiveHandler);

	static_assert(SCL_ADT_J1939_RX_PID_SIGNED    == SCL_PGB_J1939_RX_PID_SIGNED,    "ADT and PGB defines need to be equal");
	static_assert(SCL_ADT_J1939_RX_PID_UNSIGNED  == SCL_PGB_J1939_RX_PID_UNSIGNED,  "ADT and PGB defines need to be equal");
	static_assert(SCL_ADT_J1939_RX_PID_DSI_AVAIL == SCL_PGB_J1939_RX_PID_DSI_AVAIL, "ADT and PGB defines need to be equal");
	static_assert(SCL_ADT_J1939_RX_PID_DSI_NA    == SCL_PGB_J1939_RX_PID_DSI_NA,    "ADT and PGB defines need to be equal");
	static_assert(SCL_ADT_J1939_RX_PID_SWAP_DATA == SCL_PGB_J1939_RX_PID_SWAP_DATA, "ADT and PGB defines need to be equal");
	static_assert(SCL_ADT_J1939_RX_PID_NO_SWAP   == SCL_PGB_J1939_RX_PID_NO_SWAP,   "ADT and PGB defines need to be equal");

	// Disable all data manipulation since we perform all data manipulation in Jaws based on the PidConfig.
	auto const flags = SCL_ADT_J1939_RX_PID_UNSIGNED | SCL_ADT_J1939_RX_PID_DSI_NA | SCL_ADT_J1939_RX_PID_NO_SWAP;

	return SclConfigObject{
		pid,
		pReceiveHandler,
		nullptr,
		To<uint_least8_t>(J1939Definitions::FixedPidDataLength(pid)),
		Utilities::narrow_cast<uint_least8_t>(flags)};
}
void CreatePgbEntries(
	cat::shark::J1939DataLink const& j1939DataLink,
	std::vector<PgbEntry>& highPriorityEntries,
	std::vector<PgbEntry>& normalPriorityEntries)
{
	assert(highPriorityEntries.empty());
	assert(normalPriorityEntries.empty());

	auto pgbCount = 0u;
	for (auto const& peerNode : j1939DataLink.peer_nodes())
	{
		if (peerNode.has_pgb())
		{
			pgbCount += static_cast<unsigned>(peerNode.pgb().pgb_pids_size());
		}
	}
	highPriorityEntries.reserve(pgbCount); // assume worst case
	normalPriorityEntries.reserve(pgbCount); // assume worst case
	for (auto const& peerNode : j1939DataLink.peer_nodes())
	{
		if (peerNode.has_pgb())
		{
			auto const& address = peerNode.address();
			for (auto const& pgbPid : peerNode.pgb().pgb_pids())
			{
				if (pgbPid.priority() == cat::shark::J1939DataLink::PeerNode::Pgb::PRIORITY_HIGH)
				{
					highPriorityEntries.emplace_back(PgbEntry{address, pgbPid.pid(), static_cast<unsigned>(pgbPid.request_rate())});
				}
				else
				{
					assert(pgbPid.priority() == cat::shark::J1939DataLink::PeerNode::Pgb::PRIORITY_LOW);
					normalPriorityEntries.emplace_back(PgbEntry{address, pgbPid.pid(), static_cast<unsigned>(pgbPid.request_rate())});
				}
			}
		}
	}
}
void CreateAdtEntries(
	cat::shark::J1939DataLink const& j1939DataLink,
	std::vector<AdtEntry>& entries)
{
	assert(entries.empty());

	auto adtCount = 0u;
	for (auto const& peerNode : j1939DataLink.peer_nodes())
	{
		if (peerNode.has_adt())
		{
			adtCount += static_cast<unsigned>(peerNode.adt().adt_pids_size());
		}
	}
	entries.reserve(adtCount);
	for (auto const& peerNode : j1939DataLink.peer_nodes())
	{
		if (peerNode.has_adt())
		{
			auto const& address = peerNode.address();
			for (auto const& adtPid : peerNode.adt().adt_pids())
			{
				entries.emplace_back(AdtEntry{address, adtPid.pid()});
			}
		}
	}
}

bool CompareEntries(AdtEntry const& first, AdtEntry const& second)
{
	return (first.address == second.address);
}
bool CompareEntries(PgbEntry const& first, PgbEntry const& second)
{
	return (first.address == second.address) &&
		   (first.requestedUpdateRate == second.requestedUpdateRate);
}
template <typename GroupEntry>
using GroupRanges = std::vector<std::tuple<typename std::vector<GroupEntry>::const_iterator, typename std::vector<GroupEntry>::const_iterator>>;
template <typename GroupEntry>
auto GetSetRanges(std::vector<GroupEntry> const& entries)
{
	GroupRanges<GroupEntry> ranges;
	ranges.reserve(entries.size()); // This is likely more space then necessary, but the vector is short-lived.

	auto const endIt = entries.end();
	for (auto currentIt = entries.begin(); currentIt != endIt;)
	{
		auto setEndIt = std::find_if_not(currentIt, endIt,
			[currentIt](auto&& entry)
			{
				return CompareEntries(*currentIt, entry);
			});

		ranges.emplace_back(currentIt, setEndIt);
		currentIt = setEndIt;
	}

	assert(ranges.size() <= entries.size());
	return ranges;
}

// Ideally we wouldn't need this external object, but it would instead simply be a part of
// a creator class that also contains the SortRanges() method.
class GroupCounter final
{
public:
	unsigned Count() const { return m_count; }
	void Increment() { ++m_count; }
	void Reset() { m_count = {}; }
private:
	unsigned m_count{};
};
GroupCounter n_groupCounter{};

template <typename GroupEntry, typename IT>
class GroupMakerHelper
{
public:
	GroupMakerHelper(std::vector<GroupEntry>& group, IT const& endIt, unsigned byteLimit)
		: m_group{group}
		, m_endIt{endIt}
		, m_bytesRemaining{byteLimit}
	{
	}
	void FillGroup(unsigned byteCount, IT& it)
	{
		while ((m_bytesRemaining >= byteCount) && (it != m_endIt))
		{
			m_group.emplace_back(*it);
			++it;
			m_bytesRemaining -= byteCount;
		}
	}
private:
	std::vector<GroupEntry>& m_group;
	IT const& m_endIt;
	unsigned m_bytesRemaining;
};
template<typename GroupEntry, typename IT>
std::vector<GroupEntry> MakeNextOptimalGroup(IT& fourByteIt, IT& twoByteIt, IT& oneByteIt, IT const& endIt, unsigned groupSize)
{
	std::vector<GroupEntry> group;
	group.reserve(groupSize);
	GroupMakerHelper<GroupEntry, IT> helper{group, endIt, groupSize};

	helper.FillGroup(4, fourByteIt);
	helper.FillGroup(2, twoByteIt);
	helper.FillGroup(1, oneByteIt);

	return group;
}
template <typename GroupEntry>
struct ByteCountFilter
{
	ByteCountFilter(unsigned byteCount)
		: m_byteCount{byteCount}
	{
	}
	bool operator()(GroupEntry const& entry) const
	{
		auto const byteCount = J1939Definitions::FixedPidDataLength(entry.pid);
		return byteCount == m_byteCount;
	}
private:
	unsigned const m_byteCount;
};
template <typename GroupEntry>
std::vector<std::vector<GroupEntry>> SortRanges(
	GroupRanges<GroupEntry> const& ranges,
	unsigned const groupSize)
{
	// Use const pointers instead
	std::vector<std::vector<GroupEntry>> sortedRanges;
	sortedRanges.reserve(ranges.size());

	for (auto&& range : ranges)
	{
		auto const rangeBegin = std::get<0>(range);
		auto const rangeEnd = std::get<1>(range);
		assert(rangeBegin != rangeEnd);

		auto fourIt = boost::make_filter_iterator(
			ByteCountFilter<GroupEntry>(4), rangeBegin, rangeEnd);
		auto twoIt = boost::make_filter_iterator(
			ByteCountFilter<GroupEntry>(2), rangeBegin, rangeEnd);
		auto oneIt = boost::make_filter_iterator(
			ByteCountFilter<GroupEntry>(1), rangeBegin, rangeEnd);
		auto endIt = boost::make_filter_iterator(
			ByteCountFilter<GroupEntry>(1), rangeEnd, rangeEnd);
		assert((fourIt != endIt) || (twoIt != endIt) || (oneIt != endIt));

		std::vector<GroupEntry> entries;
		auto const entryCount = std::distance(rangeBegin, rangeEnd);
		entries.reserve(Utilities::narrow_cast<size_t>(entryCount));
		while (Utilities::narrow_cast<int>(entries.size()) < entryCount)
		{
			auto const group = MakeNextOptimalGroup<GroupEntry>(fourIt, twoIt, oneIt, endIt, groupSize);
			assert(group.size() <= groupSize);
			entries.insert(entries.cend(), group.cbegin(), group.cend());
			n_groupCounter.Increment();
		}

		assert(Utilities::narrow_cast<int>(entries.size()) == entryCount);
		sortedRanges.emplace_back(std::move(entries));
	}

	assert(sortedRanges.size() == ranges.size());
	return sortedRanges;
}
bool PidWillFitInAdtGroup(AdtEntry const& entry, unsigned currentGroupSize)
{
	auto const byteCount = J1939Definitions::FixedPidDataLength(entry.pid);
	return byteCount + currentGroupSize <= n_maxAdtGroupSize;
}
// FillAdtConfig will take the setRanges and build adt groups based on the max data size for a given adt group
// It is different from FillPgbConfig because the scl adt api only takes single groups where scl pgb api will
// take a list and break the groups for you
void FillAdtConfig(
	Config::CanPort canPort,
	std::vector<std::vector<AdtEntry>> const& setRanges,
	scl_adt_j1939_client_grp_pid_hdlr_t* pReceiveHandler,
	AdtConfigData& adtConfigData)
{
	auto& adtSets = adtConfigData.adtSets;
	auto& callbackContexts = adtConfigData.callbackContexts;
	auto const callbackContextsReallocationMonitor = Utilities::CreateVectorReallocationMonitor(callbackContexts);

	for (auto&& setRange : setRanges)
	{
		auto beginIt = setRange.cbegin();
		auto endIt = setRange.cend();
		auto address = beginIt->address;
		auto currentIt = beginIt;

		while (currentIt != endIt)
		{
			adtSets.emplace_back(AdtSet{address});
			auto& adtSet = adtSets.back();

			auto pidConfigCount = std::min(n_maxAdtGroupSize, static_cast<unsigned>(std::distance(currentIt, endIt)));
			adtSet.pidConfigs.reserve(pidConfigCount);
			auto const pidConfigReallocationMonitor = Utilities::CreateVectorReallocationMonitor(adtSet.pidConfigs);
			adtSet.pidConfigPointers.reserve(pidConfigCount);

			auto groupSize = 0u;
			while (currentIt != endIt && PidWillFitInAdtGroup(*currentIt, groupSize))
			{
				auto pid = currentIt->pid;
				adtSet.pidConfigs.emplace_back(
					CreateGroupConfig<scl_adt_j1939_client_grp_pid_config_t, scl_adt_j1939_client_grp_pid_hdlr_t>(
						pid,
						pReceiveHandler));
				auto& pidConfig = adtSet.pidConfigs.back();

				callbackContexts.emplace_back(CallbackContext{canPort, address, pid});
				auto& callbackContext = callbackContexts.back();
				pidConfig.context = &callbackContext;

				adtSet.pidConfigPointers.emplace_back(&pidConfig);
				groupSize += J1939Definitions::FixedPidDataLength(pid);
				++currentIt;
			}
			assert(adtSet.pidConfigs.size() == adtSet.pidConfigPointers.size());
		}
	}
}
// FillPgbConfig will take the setRanges and build pgb groups based on common address/request rate/priority
// It is different from FillAdtConfig because the scl adt api only takes single groups where scl pgb api will
// take a list and break the groups for you
void FillPgbConfig(
	Config::CanPort canPort,
	std::vector<std::vector<PgbEntry>> const& setRanges,
	scl_pgb_j1939_rx_pid_hdlr_t* pReceiveHandler,
	PgbConfigData& pgbConfigData)
{
	auto& pgbSets = pgbConfigData.pgbSets;
	CallbackContexts& callbackContexts = pgbConfigData.callbackContexts;
	auto const callbackContextsReallocationMontitor = Utilities::CreateVectorReallocationMonitor(callbackContexts);

	for (auto&& setRange : setRanges)
	{
		auto beginIt = setRange.cbegin();
		auto endIt = setRange.cend();
		auto const address = beginIt->address;
		pgbSets.emplace_back(PgbSet{address, beginIt->requestedUpdateRate});
		auto& pgbSet = pgbSets.back();

		auto pidConfigCount = static_cast<size_t>(std::distance(beginIt, endIt));
		pgbSet.pidConfigs.reserve(pidConfigCount);
		auto const pidConfigReallocationMonitor = Utilities::CreateVectorReallocationMonitor(pgbSet.pidConfigs);
		pgbSet.pidConfigPointers.reserve(pidConfigCount);

		for (auto currentIt = beginIt; currentIt != endIt; ++currentIt)
		{
			auto const pid = currentIt->pid;
			pgbSet.pidConfigs.emplace_back(
				CreateGroupConfig<scl_pgb_j1939_rx_pid_config_t, scl_pgb_j1939_rx_pid_hdlr_t>(pid, pReceiveHandler));
			auto& pidConfig = pgbSet.pidConfigs.back();

			callbackContexts.emplace_back(CallbackContext{canPort, address, pid});
			auto& callbackContext = callbackContexts.back();
			pidConfig.rx_hdlr_context = &callbackContext;

			pgbSet.pidConfigPointers.emplace_back(&pidConfig);
		}

		assert(pgbSet.pidConfigs.size() == pgbSet.pidConfigPointers.size());
	}
}
void DumpAdtGroups(Config::CanPort canPort, AdtConfigData const& adtConfigData)
{
	auto constexpr severity = Log::SeverityLevel::Debug;
	if (Log::ShouldLog(severity, Log::Adt))
	{
		LOG_TAG(severity, Log::Adt, "Count of ADT Groups for " << canPort << ": " << adtConfigData.adtGroupCount);
		for (auto const& adtSet : adtConfigData.adtSets)
		{
			LOG_TAG(severity, Log::Adt, "SA: 0x" << std::hex << std::uppercase << adtSet.address);
			for (auto const& config : adtSet.pidConfigs)
			{
				LOG_TAG(severity, Log::Adt, "\t" << Config::Pid{config.pid} << ", Size: "
					<< static_cast<unsigned>(config.data_size));
			}
		}
	}
}
void DumpPgbGroups(Config::CanPort canPort, PgbConfigData const& pgbConfigData)
{
	auto constexpr severity = Log::SeverityLevel::Debug;
	if (Log::ShouldLog(severity, Log::Pgb))
	{
		LOG_TAG(severity, Log::Pgb, "Count of PGB Groups for " << canPort << ": " << pgbConfigData.pgbGroupCount);
		for (auto const& pgbSet : pgbConfigData.pgbSets)
		{
			LOG_TAG(severity, Log::Pgb, "SA: 0x" << std::hex << std::uppercase << pgbSet.address << ", Rate: "
				<< std::dec << pgbSet.requestedUpdateRate);
			for (auto const& config : pgbSet.pidConfigs)
			{
				LOG_TAG(severity, Log::Pgb, "\t" << Config::Pid{config.pid} << ", Size: "
					<< static_cast<unsigned>(config.data_size));
			}
		}
	}
}
}

AdtConfigData GroupConfigDataFactory::CreateAdtConfigData(
	cat::shark::J1939DataLink const& j1939DataLink,
	scl_adt_j1939_client_grp_pid_hdlr_t* pReceiveHandler)
{
	n_groupCounter.Reset();

	std::vector<AdtEntry> entries{};
	CreateAdtEntries(j1939DataLink, entries);

	auto const setRanges = SortRanges<AdtEntry>(GetSetRanges(entries), n_maxAdtGroupSize);

	auto const adtConfigSize = entries.size();

	AdtConfigData adtConfigData{};
	adtConfigData.adtSets.reserve(setRanges.size());
	adtConfigData.callbackContexts.reserve(adtConfigSize);
	adtConfigData.adtGroupCount = n_groupCounter.Count();

	auto const canPort = Config::ToConfigCanPort(j1939DataLink.can_port());
	FillAdtConfig(canPort, setRanges, pReceiveHandler, adtConfigData);

	assert(adtConfigData.callbackContexts.size() == adtConfigSize);
	DumpAdtGroups(canPort, adtConfigData);
	return adtConfigData;
}
PgbConfigData GroupConfigDataFactory::CreatePgbConfigData(
	cat::shark::J1939DataLink const& j1939DataLink,
	scl_pgb_j1939_rx_pid_hdlr_t* pReceiveHandler)
{
	n_groupCounter.Reset();

	std::vector<PgbEntry> highPriorityEntries{};
	std::vector<PgbEntry> normalPriorityEntries{};
	CreatePgbEntries(j1939DataLink, highPriorityEntries, normalPriorityEntries);

	auto const highPrioritySetRanges =
		SortRanges<PgbEntry>(
			GetSetRanges(highPriorityEntries),
			n_maxPgbGroupSize);
	auto const normalPrioritySetRanges =
		SortRanges<PgbEntry>(
			GetSetRanges(normalPriorityEntries),
			n_maxPgbGroupSize);

	auto const pgbSetSize =
		highPrioritySetRanges.size() +
		normalPrioritySetRanges.size();
	auto const pgbConfigSize =
		highPriorityEntries.size() +
		normalPriorityEntries.size();

	PgbConfigData pgbConfigData{};
	pgbConfigData.pgbSets.reserve(pgbSetSize);
	pgbConfigData.callbackContexts.reserve(pgbConfigSize);
	pgbConfigData.pgbGroupCount = n_groupCounter.Count();

	auto const canPort = Config::ToConfigCanPort(j1939DataLink.can_port());
	FillPgbConfig(canPort, highPrioritySetRanges, pReceiveHandler, pgbConfigData);
	FillPgbConfig(canPort, normalPrioritySetRanges, pReceiveHandler, pgbConfigData);

	assert(pgbConfigData.callbackContexts.size() == pgbConfigSize);
	DumpPgbGroups(canPort, pgbConfigData);
	return pgbConfigData;
}
}
}
