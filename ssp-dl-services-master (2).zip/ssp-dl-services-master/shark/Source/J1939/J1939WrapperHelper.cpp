/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See J1939WrapperHelper.h

#include "J1939WrapperHelper.h"
#include "Log.h"
#include "Utilities/CountOf.h"

namespace Shark
{
namespace J1939
{
namespace
{
char const* ConvertClaimStatusToString(SCL_J1939_AC_STATUS_CB_ENUM_t status)
{
	static constexpr char const* s_addressClaimStatusToString[]
	{
		"Claimed",
		"Lost",
		"Failed",
		"Timeout"
	};
	static_assert(Utilities::CountOf(s_addressClaimStatusToString) == SCL_J1939_AC_STAT_TIMEDOUT + 1, "Size mismatch");

	assert(static_cast<unsigned>(status) < Utilities::CountOf(s_addressClaimStatusToString)); // cast is to make clang happy
	return s_addressClaimStatusToString[status];
}
}

J1939WrapperHelper::J1939WrapperHelper(Config::CanPort canPort) noexcept
	: m_canPort{canPort}
{
}
void J1939WrapperHelper::LogAddressClaimResult(SCL_J1939_AC_STATUS_CB_ENUM_t status, Config::J1939Address address) const
{
	if (status == SCL_J1939_AC_STAT_CLAIMED)
	{
		LOG_INFO_HIGH_TAG(Log::Init, m_canPort << ": Address claim status for " << address <<
			" is " << ConvertClaimStatusToString(status));
	}
	else
	{
		LOG_WARNING_TAG(Log::Init, m_canPort << ": Address claim failed because of " << ConvertClaimStatusToString(status));
	}
}
}
}
