/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Wrapper Interface

#pragma once

#include "IJ1939BaseWrapper.h"
#include "J1939NameFields.h"
#include "Utilities/nice_ptr.h"
#include "Config/CanPort.h"
#include "Config/J1939Address.h"
#include <cdl2_proto.h>
#include <chrono>
#include <scl_adt_j1939.h>
#include <scl_j1939.h>
#include <scl_pgb_j1939.h>
#include <array>
#include <functional>
#include <vector>

namespace Shark
{
namespace J1939
{
enum class ExtensionIdCommand : unsigned
{
	ReadRequest                         = 0x80,
	WriteRequestWithDataResponse        = 0x81,
	WriteRequestWithAcknowledgeResponse = 0x82,
	WriteDataResponse                   = 0x83,

	AcknowledgeResponse                 = 0xF004,
};
enum class PidRequestStatus : unsigned
{
	Received,
	Retry,
	RequestFailed,

	Count
};
enum class DM13State : unsigned
{
	Active,
	Suspended,

	Count
};
class IJ1939Wrapper : public IJ1939BaseWrapper
{
public:
	static constexpr std::size_t s_j1939NameLength = 4;
	using J1939Name = std::array<uint8_t, s_j1939NameLength>;
	static constexpr unsigned MaxRxPgbGroups() { return 170; }

	virtual ~IJ1939Wrapper() override = default;

	virtual void Initialize() = 0;
	virtual Config::CanPort GetCanPort() const = 0;
	virtual J1939NameFields const& GetJ1939NameFields() const = 0;
	virtual Utilities::nice_ptr<scl_pgb_j1939_t> GetPgbContext() const = 0;
	virtual scl_adt_j1939_link_handle_t GetAdtHandle() const = 0;
	virtual bool SendPropAMessage(unsigned destinationAddress, uint8_t const* pData, unsigned dataLength) = 0;
	virtual bool SendPropAMessageByName(J1939Name const j1939Name, uint8_t const* pData, unsigned dataLength) = 0;
	virtual bool SendDM13Suspend() = 0;

	using ExtensionIdHandler = void(unsigned address, uint8_t const* pMessage, unsigned messageLength);
	virtual void RegisterExtensionIdCommandHandler(
		unsigned extensionIdCommand,
		std::function<ExtensionIdHandler>&& handler) = 0;
	virtual void RegisterExtensionIdCommandIdHandler(
		ExtensionIdCommand extensionIdCommand,
		unsigned extensionId,
		std::function<ExtensionIdHandler>&& handler) = 0;

	using PidRequestHandler
		= void(PidRequestStatus status, unsigned address, unsigned pid, uint8_t const* pData, unsigned dataLength);
	using PidReadHandler = int16_t(uint8_t* pData); // Note that the caller will prepend the returned length
	using PidWriteHandler = int16_t(uint8_t const* pData, unsigned dataLength);

	virtual void RegisterPidRequestHandler(unsigned pid, std::function<PidRequestHandler>&& handler) = 0;
	virtual void RegisterPidReadHandler(unsigned pid, std::function<PidReadHandler>&& handler) = 0;
	virtual void RegisterPidWriteHandler(unsigned pid, std::function<PidWriteHandler>&& handler) = 0;

	virtual void AddPgbGroups(
		unsigned address,
		unsigned pidCount,
		scl_pgb_j1939_rx_pid_cfg_ptr_t const* pPidTable,
		unsigned requestedUpdateRate,
		unsigned timeOut) = 0;

	virtual void AddAdtGroups(
		unsigned address,
		unsigned pidCount,
		scl_adt_j1939_client_grp_pid_config_ptr_t const* pPidConfig,
		std::optional<std::chrono::milliseconds> timeout) = 0;

	virtual unsigned GetPgnRxTableIndex(unsigned address, unsigned pgn) const = 0;
	virtual unsigned GetPgnRxTableTimeout(unsigned address, unsigned pgn) const = 0;

	using DM13StatusCallback = void(unsigned address, DM13State state);
	virtual void RegisterForDM13Status(std::function<DM13StatusCallback>&& callback) = 0;
	virtual bool EcmIsConnectedToLink(Config::J1939Address address) = 0;
	virtual std::vector<scl_j1939_nar_entry_t> GetConnectedEcms() = 0;
};
}
}
