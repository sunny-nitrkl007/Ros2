/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See J1939PgnPeriodicTxWrapper.h

#include "J1939PgnPeriodicTxWrapper.h"
#include "DependencyContainer.h"
#include "IJ1939Wrapper.h"
#include "SharkBytes/ISharkByteManager.h"
#include "SharkBytes/IWriteSharkByteManager.h"
#include "J1939Definitions.h"
#include "Log.h"
#include "Config/ProtobufConversions.h"
#include "Utilities/SharkBytes/SimpleSharkByte.h"
#include "Utilities/SharkBytes/WriteSharkByteReferenceWrapper.h"
#include <scl_j1939.h>
#include <scl_j1939_proto.h>
#include <scl_j1939_struct.h>
#include <cassert>

using namespace std::chrono_literals;

namespace Shark
{
namespace J1939
{
namespace
{
constexpr auto n_initialDelay = 1000ms;
constexpr auto n_pgnLength = 8;
constexpr uint8_t n_defaultPgnData[n_pgnLength] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

bool J1939DataLinkConfigHasPgnToBroadcast(cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	return j1939DataLinkConfig.transmit_broadcast_pgns_size() > 0;
}
void CreateSharkByte(
	DependencyContainer const& dependencyContainer,
	cat::shark::J1939DataLink::TransmitBroadcastPgn const& transmitBroadcastPgnEntry)
{
	auto spSharkByte = std::make_unique<Utilities::SimpleSharkByte>(transmitBroadcastPgnEntry.middleware_id());
	dependencyContainer.GetIWriteSharkByteManager().AddWriteSharkByte(
		std::make_unique<Utilities::WriteSharkByteReferenceWrapper>(*spSharkByte));
	dependencyContainer.GetISharkByteManager().AddSharkByte(std::move(spSharkByte));
}
scl_j1939_tx_msg_t CreateSclJ1939TxMessage(
	cat::shark::J1939DataLink::TransmitBroadcastPgn const& transmitBroadcastPgnEntry)
{
	return {
		transmitBroadcastPgnEntry.pgn(),
		J1939Definitions::DefaultPriority(),
		FALSE,
		0xFF,
		{},
		nullptr,
		SCL_J1939_TX_MSG_CBF_ON_REQUEST | SCL_J1939_TX_MSG_CBF_PERIODIC,
		TRUE,
		static_cast<int_16>(transmitBroadcastPgnEntry.broadcast_rate()),
		TRUE,
		n_initialDelay.count()}; // Don't transmit until a bit of time has passed
}

std::array<Utilities::nice_ptr<J1939PgnPeriodicTxWrapper>, Config::CanPort::CanPortCount> n_j1939PgnPeriodicTxWrappers;
}

bool J1939PgnPeriodicTxWrapper::ShouldBeCreated(DependencyContainer const& dependencyContainer)
{
	auto const& configs = dependencyContainer.GetJ1939DataLinkConfigs();
	return std::any_of(configs.begin(), configs.end(),
		[](auto const& spJ1939DataLinkConfig)
		{
			return J1939DataLinkConfigHasPgnToBroadcast(*spJ1939DataLinkConfig);
		});
}
std::function<void()> J1939PgnPeriodicTxWrapper::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	struct InitializerContext
	{
		SharkByteAndTxMessagePairs sharkByteAndTxMessagePairs;
		std::shared_ptr<J1939PgnPeriodicTxWrapper> spJ1939PgnPeriodicTxWrapper;
	};
	std::vector<InitializerContext> initializerContexts{};

	for (auto spJ1939DataLinkConfig : dependencyContainer.GetJ1939DataLinkConfigs())
	{
		if (J1939DataLinkConfigHasPgnToBroadcast(*spJ1939DataLinkConfig))
		{
			SharkByteAndTxMessagePairs sharkByteAndTxMessagePairs{};
			auto const canPort = Config::ToConfigCanPort(spJ1939DataLinkConfig->can_port());
			auto spJ1939PgnPeriodicTxWrapper =
				std::make_shared<J1939PgnPeriodicTxWrapper>(dependencyContainer.GetIJ1939Wrapper(canPort));
			for (auto const& transmitBroadcastPgnEntry : spJ1939DataLinkConfig->transmit_broadcast_pgns())
			{
				CreateSharkByte(dependencyContainer, transmitBroadcastPgnEntry);
				sharkByteAndTxMessagePairs.push_back(SharkByteAndTxMessagePair{
					dependencyContainer.GetISharkByteRetriever().Retrieve(transmitBroadcastPgnEntry.middleware_id()),
					CreateSclJ1939TxMessage(transmitBroadcastPgnEntry)});
			}
			initializerContexts.emplace_back(
				std::move(sharkByteAndTxMessagePairs),
				std::move(spJ1939PgnPeriodicTxWrapper));
		}
	}
	assert(!initializerContexts.empty());

	return [initializerContexts = std::move(initializerContexts)]()
	{
		for (auto const& initializerContext : initializerContexts)
		{
			initializerContext.spJ1939PgnPeriodicTxWrapper->Initialize(
				initializerContext.sharkByteAndTxMessagePairs);
		}
	};
}
boolean_t J1939PgnPeriodicTxWrapper::PopulatePgn(
	scl_j1939_mbuf_hdr_t* pMBuf,
	[[maybe_unused]] const scl_j1939_tx_msg_t* pTxMsg,
	[[maybe_unused]] unsigned_8 statusByte,
	void* pContext)
{
	assert(pContext);
	assert(scl_j1939_get_mbuf_len(pMBuf) == n_pgnLength);
	auto const& sharkByteAndTxMessagePair = *reinterpret_cast<SharkByteAndTxMessagePair*>(pContext);
	auto const& value = sharkByteAndTxMessagePair.sharkByte.Value();

	auto fillReturn{false};
	if (value)
	{
		assert(value->size() == n_pgnLength);
		fillReturn = scl_j1939_fill_mbuf_data(pMBuf, value->data(), n_pgnLength);
	}
	else
	{
		fillReturn = scl_j1939_fill_mbuf_data(pMBuf, n_defaultPgnData, n_pgnLength);
	}
	return fillReturn;
}
J1939PgnPeriodicTxWrapper::J1939PgnPeriodicTxWrapper(IJ1939Wrapper& j1939Wrapper) noexcept
	: m_j1939Wrapper(j1939Wrapper)
{
	auto const canPort = m_j1939Wrapper.GetCanPort();
	assert(!n_j1939PgnPeriodicTxWrappers[canPort]);
	n_j1939PgnPeriodicTxWrappers[canPort] = this;

	LOG_DEBUG_TAG(Log::Pgn, "J1939PgnPeriodicTxWrapper created for " << canPort);
}
J1939PgnPeriodicTxWrapper::~J1939PgnPeriodicTxWrapper()
{
	// Don't use m_j1939Wrapper here since it may have already been destroyed
	auto const itEnd = n_j1939PgnPeriodicTxWrappers.end();
	auto const itFound = std::find(n_j1939PgnPeriodicTxWrappers.begin(), itEnd, this);
	assert(itFound != itEnd);
	*itFound = nullptr;

	[[maybe_unused]]auto const canPort =
		static_cast<Config::CanPort>(std::distance(n_j1939PgnPeriodicTxWrappers.begin(), itFound));
	LOG_DEBUG_TAG(Log::Pgn, "J1939PgnPeriodicTxWrapper destroyed for " << canPort);

}
void J1939PgnPeriodicTxWrapper::Initialize(SharkByteAndTxMessagePairs const& sharkByteAndTxMessagePairs)
{
	for (auto const& sharkByteAndTxMessagePair : sharkByteAndTxMessagePairs)
	{
		auto const& sclTxMsg = sharkByteAndTxMessagePair.sclJ1939TxMessage;

		auto const txIndex = scl_j1939_add_tx_msg_table_entry(
			m_j1939Wrapper.GetLink(),
			J1939Definitions::VirtualEcmIndex(),
			&sclTxMsg,
			reinterpret_cast<void*>(const_cast<SharkByteAndTxMessagePair*>(&sharkByteAndTxMessagePair)),
			J1939PgnPeriodicTxWrapper::PopulatePgn);
		if (txIndex == SCL_J1939_INVALID_MSG_INDEX)
		{
			throw Error("scl_j1939_add_tx_msg_table_entry failed!");
		}
	}
}
}
}
