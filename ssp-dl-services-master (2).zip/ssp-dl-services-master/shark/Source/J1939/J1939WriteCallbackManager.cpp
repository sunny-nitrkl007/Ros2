/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See J1939WriteCallbackManager

#include "J1939WriteCallbackManager.h"
#include "Log.h"
#include "SharkUtilities/IEventCallbackFactory.h"
#include <algorithm>

using namespace std::chrono_literals;

namespace Shark
{
namespace J1939
{
namespace
{
constexpr auto const n_writeTimeout = 1500ms;
}
J1939WriteCallbackManager::J1939WriteCallbackManager(SharkUtilities::IEventCallbackFactory& eventCallbackFactory) noexcept
	: m_eventCallbackFactory(eventCallbackFactory)
{
}
void J1939WriteCallbackManager::Add(unsigned address, unsigned id, IWriteSharkByte::CompletedCallback const& callback)
{
	auto spTimedCallback = m_eventCallbackFactory.CreateTimedCallbackThatFiresIn(n_writeTimeout,
		[this, address, id]
		{
			LOG_WARNING_TAG(Log::Rw, "Timeout: 0x" << std::hex << std::uppercase << address << " " <<
				"PID: 0x" << id);
			Callback(address, id, std::nullopt);
		});

	Callback(address, id, std::nullopt); // If the address/id pair is active, call the callback

	std::unique_lock<std::mutex> lock{m_mutex};
	m_activeCallbacks.push_back({
		address,
		id,
		callback,
		std::move(spTimedCallback)});
}
void J1939WriteCallbackManager::Callback(unsigned address, unsigned id, std::optional<std::vector<uint8_t>> const& responseData)
{
	IWriteSharkByte::CompletedCallback callback{};
	{
		std::unique_lock<std::mutex> lock{m_mutex};
		auto const itEnd = m_activeCallbacks.end();
		auto const itFound = std::find_if(m_activeCallbacks.begin(), itEnd,
			[address, id](auto const& callbackData)
			{
				return (callbackData.address == address &&
						callbackData.id      == id);
			});
		if (itFound != itEnd)
		{
			callback = std::move(itFound->callback);
			m_activeCallbacks.erase(itFound);
		}
	}

	if (callback)
	{
		callback(responseData);
	}
}
}
}
