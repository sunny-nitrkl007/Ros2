/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See MbufWrapper.cpp

#include "MbufWrapper.h"
#include "Utilities/narrow_cast.h"
#include <scl_j1939_proto.h>

namespace Shark
{
namespace J1939
{
unsigned MbufWrapper::Length() const
{
	assert(IsValid());
	return scl_j1939_get_mbuf_len(m_pMbuf);
}
bool MbufWrapper::GetBytes(unsigned byteOffset, unsigned byteCount, uint8_t* pDestination) const
{
	assert(pDestination);
	assert(byteCount + byteOffset <= Length()); // scl_j1939_get_data_from_mbuf returns false if this happens
	assert(IsValid());

	return scl_j1939_get_data_from_mbuf(
		m_pMbuf,
		pDestination,
		Utilities::narrow_cast<uint16_t>(byteCount),
		Utilities::narrow_cast<uint16_t>(byteOffset));
}
}
}