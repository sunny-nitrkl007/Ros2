/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Qualified Read Wrapper Interface

#pragma once

#include "Utilities/DefineExceptionClass.h"
#include <scl_qr_j1939.h>

namespace Shark
{
namespace J1939
{
class IJ1939QualifiedReadWrapper
{
public:
	virtual ~IJ1939QualifiedReadWrapper() = default;

	DEFINE_EXCEPTION_CLASS(Error);

	/// \exception IJ1939QualifiedReadWrapper::Error
	///		Thrown when an unrecoverable error occurs in the SCL Qualified Read library
	virtual void Initialize(scl_j1939_link_t link) = 0;
};
}
}
