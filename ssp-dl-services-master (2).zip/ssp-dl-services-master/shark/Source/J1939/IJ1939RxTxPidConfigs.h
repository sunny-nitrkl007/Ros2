/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Rx/Tx Pid Configs interface

#pragma once

#include "Config/PidRxTxServerConfig.h"

namespace Shark
{
namespace J1939
{
class IJ1939RxTxPidConfigs
{
public:
	virtual ~IJ1939RxTxPidConfigs() = default;

	/// The config may contain numeric and non-numeric entries
	virtual void AddConfig(Config::PidRxTxServerConfig const& config) = 0;

	virtual void AddNonNumericPid(Config::PidRxTxServerEntry const& entry) = 0;
};
}
}
