/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pgn Helper interface

#pragma once

#include "Config/CanPort.h"
#include <scl_j1939.h>

namespace Shark
{
namespace J1939
{
class IPgnHelper
{
public:
	static scl_j1939_rx_msg_t CreateSclPgnConfig(
		unsigned pgn,
		unsigned address,
		unsigned timeout);

	virtual ~IPgnHelper() = default;

	// The mapping from link to canPort is needed by the static rx callback.
	virtual void RegisterLink(Config::CanPort canPort, scl_j1939_link_t link) = 0;

	virtual bool SendPgnMessage(
		scl_j1939_link_t link,
		unsigned pgn,
		unsigned destinationAddress,
		uint8_t const* pData,
		unsigned dataLength) = 0;
};
}
}
