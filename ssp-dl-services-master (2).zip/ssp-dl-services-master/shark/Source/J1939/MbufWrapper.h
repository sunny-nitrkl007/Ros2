/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Memory Buffer Wrapper

#pragma once

#include <cstdint>

struct scl_j1939_mbuf_hdr_s;

namespace Shark
{
namespace J1939
{
class MbufWrapper
{
public:
	constexpr MbufWrapper() noexcept = default;
	constexpr MbufWrapper(scl_j1939_mbuf_hdr_s const* pMbuf) noexcept : m_pMbuf{pMbuf} {}

	constexpr bool IsValid() const { return static_cast<bool>(m_pMbuf); }
	unsigned Length() const;
	bool GetBytes(unsigned byteOffset, unsigned byteCount, uint8_t* pDestination) const;

	constexpr bool operator==(MbufWrapper other) const noexcept { return m_pMbuf == other.m_pMbuf; }
	constexpr bool operator!=(MbufWrapper other) const noexcept { return !(*this == other); }
private:
	scl_j1939_mbuf_hdr_s const* m_pMbuf{};
};
}
}