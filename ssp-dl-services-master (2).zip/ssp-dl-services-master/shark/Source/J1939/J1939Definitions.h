/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Definitions

#pragma once

#include "Config/Pid.h"
#include <scl_j1939.h>

namespace Shark
{
namespace J1939
{
class J1939Definitions
{
public:
	static unsigned PidIdentifierByteCount(Config::Pid pid);
	static unsigned AddPidToMessage(Config::Pid pid, unsigned index, uint8_t message[], unsigned maxLength);
	static bool IsMultiBytePid(Config::Pid pid);
	static bool IsFixedBytePid(Config::Pid pid);
	static unsigned FixedPidDataLength(Config::Pid pid);
	static constexpr uint32_t DataStatusPrefix() { return 0xFF00u; }
	static constexpr uint32_t MakeDataStatus(uint32_t status) { return DataStatusPrefix() | status; }

	static constexpr unsigned DefaultPriority()                      { return 0x06; }
	static constexpr unsigned CommonPgnLength()                      { return 8; }
	static constexpr unsigned PropAPgn()                             { return 0xEF00; }
	static constexpr unsigned JogDialSourceAddress()                 { return 0xF5; }
	static constexpr unsigned SwitchBankStatusPgn()                  { return 0xFED9; }
	static constexpr unsigned SwitchBankStatusPgnTimeout()           { return 1250; }
	static constexpr unsigned KeypadSourceAddress()                  { return 0x81; }
	static constexpr unsigned ReadExtIdHighByte()                    { return 0xF0; }
	static constexpr unsigned ReadExtIdLowByte()                     { return 0x87; }
	static constexpr unsigned ReadExtIdLength()                      { return 2; }
	static constexpr unsigned WriteWithDataResponseExtId()           { return 0x9E; }
	static constexpr unsigned WriteWithDataResponseExtIdLength()     { return 1; }
	static constexpr unsigned VirtualEcmIndex()                      { return 0; }
};
}
}
