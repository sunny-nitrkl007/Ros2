/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See J1939AdtManager.h

#include "DependencyContainer.h"
#include "IJ1939Wrapper.h"
#include "IPidDataReceiver.h"
#include "J1939AdtManager.h"
#include "Log.h"
#include "Config/ProtobufConversions.h"
#include "SharkBytes/ISharkByteManager.h"
#include "SharkBytes/ISlotManager.h"
#include "SharkBytes/PidSlot.h"
#include <Utilities/SharkBytes/SimpleSharkByte.h>
#include "Utilities/ArrayToHexString.h"
#include <algorithm>
#include <array>
#include <algorithm>

namespace Shark
{
namespace J1939
{
namespace
{
void DumpRxData(uint_least8_t const* pData, uint_least8_t data_len, CallbackContext const& callbackContext, uint_least16_t dataStatus)
{
	auto constexpr severity = Log::SeverityLevel::Debug;
	if (Log::ShouldLog(severity, Log::Adt))
	{
		auto hexBytes = Utilities::ArrayToHexString(pData, data_len);
		LOG_TAG(severity, Log::Adt,
			"ADT Rx Handler: " << callbackContext.canPort << " " <<
			"SA: 0x" << std::hex << std::uppercase << callbackContext.address << " " <<
			"PID: 0x" << callbackContext.pid << ", DSI: 0x" << dataStatus << ", Data: " << hexBytes);
	}
}
void CreateAdtSharkBytes(
	Config::CanPort canPort,
	cat::shark::J1939DataLink const& j1939DataLink,
	SharkBytes::ISlotManager& slotManager,
	SharkBytes::ISharkByteManager& sharkByteManager)
{
	for (auto& peerNode : j1939DataLink.peer_nodes())
	{
		if (peerNode.has_adt())
		{
			auto const address = peerNode.address();
			for (auto const& adtPid : peerNode.adt().adt_pids())
			{
				auto id = adtPid.middleware_id();
				auto const pid = adtPid.pid();
				auto spPidSlot = std::make_unique<SharkBytes::PidSlot>(pid, std::move(id));
				slotManager.AddPidSlot(*spPidSlot, canPort, address, pid);
				sharkByteManager.AddSharkByte(std::move(spPidSlot));
			}
		}
	}
}
std::vector<AdtTimeoutOverride> CreateAdtTimeoutOverrides(cat::shark::J1939DataLink const& j1939DataLink)
{
	std::vector<AdtTimeoutOverride> timeoutOverrides{};
	timeoutOverrides.reserve(static_cast<unsigned>(j1939DataLink.peer_nodes_size()));
	for (auto const& peerNode : j1939DataLink.peer_nodes())
	{
		if (peerNode.has_adt() && peerNode.adt().has_timeout())
		{
			std::chrono::milliseconds timeout{peerNode.adt().timeout()};
			timeoutOverrides.emplace_back(AdtTimeoutOverride{peerNode.address(), timeout});
		}
	}
	return timeoutOverrides;
}
bool J1939DataLinkConfigHasAdt(cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	auto const& peerNodes = j1939DataLinkConfig.peer_nodes();
	return std::any_of(peerNodes.begin(),peerNodes.end(),
		[](auto const& peerNode)
		{
			return peerNode.has_adt() && peerNode.adt().adt_pids().size() > 0;
		});
}

std::array<Utilities::nice_ptr<J1939AdtManager>, Config::CanPort::CanPortCount> n_j1939AdtManagers;
}

bool J1939AdtManager::ShouldBeCreated(DependencyContainer const& dependencyContainer)
{
	auto const& configs = dependencyContainer.GetJ1939DataLinkConfigs();
	return std::any_of(configs.begin(), configs.end(),
		[](auto const& spJ1939DataLinkConfig)
		{
			return J1939DataLinkConfigHasAdt(*spJ1939DataLinkConfig);
		});
}
std::function<void()> J1939AdtManager::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	struct InitializerContext
	{
		cat::shark::J1939DataLink const& j1939DataLinkConfig;
		std::shared_ptr<J1939AdtManager> spJ1939AdtManager;
	};
	std::vector<InitializerContext> initializerContexts{};

	for (auto spJ1939DataLinkConfig : dependencyContainer.GetJ1939DataLinkConfigs())
	{
		if (J1939DataLinkConfigHasAdt(*spJ1939DataLinkConfig))
		{
			auto const canPort = Config::ToConfigCanPort(spJ1939DataLinkConfig->can_port());
			CreateAdtSharkBytes(
				canPort,
				*spJ1939DataLinkConfig,
				dependencyContainer.GetISlotManager(),
				dependencyContainer.GetISharkByteManager());

			auto spJ1939AdtManager = std::make_shared<J1939AdtManager>(
				dependencyContainer.GetIPidDataReceiver(),
				dependencyContainer.GetIJ1939Wrapper(canPort));

			initializerContexts.emplace_back(*spJ1939DataLinkConfig, std::move(spJ1939AdtManager));
		}
	}
	assert(!initializerContexts.empty());

	return [initializerContexts = std::move(initializerContexts)]()
	{
		for (auto const& context : initializerContexts)
		{
			context.spJ1939AdtManager->Initialize(
				GroupConfigDataFactory::CreateAdtConfigData(
					context.j1939DataLinkConfig,
					&ReceiveHandler),
				CreateAdtTimeoutOverrides(context.j1939DataLinkConfig));
		}
	};
}
int_least16_t J1939AdtManager::ReceiveHandler(
	uint_least8_t* pData,
	uint_least8_t data_len,
	void* rx_hdlr_context,
	uint_least16_t dataStatus)
{
	assert(rx_hdlr_context);
	auto& callbackContext = *reinterpret_cast<CallbackContext const*>(rx_hdlr_context);
	DumpRxData(pData, data_len, callbackContext, dataStatus);

	auto const canPort = callbackContext.canPort;
	if (n_j1939AdtManagers[canPort])
	{
		n_j1939AdtManagers[canPort]->ProcessData(pData, data_len, callbackContext, dataStatus);
	}
	else
	{
		LOG_WARNING_TAG(Log::Adt, "Data received but wrapper is not instantiated for " << canPort << "!");
	}

	return 0;
}

J1939AdtManager::J1939AdtManager(
	IPidDataReceiver& pidDataReceiver,
	IJ1939Wrapper& j1939Wrapper) noexcept
	: m_pidDataReceiver(pidDataReceiver)
	, m_j1939Wrapper(j1939Wrapper)
{
	auto const canPort = m_j1939Wrapper.GetCanPort();
	assert(!n_j1939AdtManagers[canPort]);
	n_j1939AdtManagers[canPort] = this;

	LOG_DEBUG_TAG(Log::Adt, "J1939AdtManager created for " << canPort);
}
J1939AdtManager::~J1939AdtManager()
{
	// Don't use m_j1939Wrapper here since it may have already been destroyed
	auto const itEnd = n_j1939AdtManagers.end();
	auto const itFound = std::find(n_j1939AdtManagers.begin(), itEnd, this);
	assert(itFound != itEnd);
	*itFound = nullptr;

	[[maybe_unused]] auto const canPort =
		static_cast<Config::CanPort>(std::distance(n_j1939AdtManagers.begin(), itFound));
	LOG_DEBUG_TAG(Log::Adt, "J1939AdtManager destroyed for " << canPort);
}
void J1939AdtManager::Initialize(AdtConfigData&& adtConfigData, std::vector<AdtTimeoutOverride>&& adtTimeoutOverrides)
{
	assert(m_adtConfigData.adtSets.empty());
	m_adtConfigData = std::move(adtConfigData);

	for (auto&& adtSet : m_adtConfigData.adtSets)
	{
		m_j1939Wrapper.AddAdtGroups(
			adtSet.address,
			To<unsigned>(adtSet.pidConfigs.size()),
			adtSet.pidConfigPointers.data(),
			CalculateTimeoutValue(adtTimeoutOverrides, adtSet.address));
	}
}
void J1939AdtManager::ProcessData(
	uint_least8_t* pData,
	uint_least8_t data_len,
	CallbackContext const& callbackContext,
	uint_least16_t dataStatus)
{
	m_pidDataReceiver.ReceivePidData(
		m_j1939Wrapper.GetCanPort(),
		callbackContext.address,
		callbackContext.pid,
		dataStatus == 0 ? pData : nullptr,
		dataStatus == 0 ? data_len : 0,
		dataStatus);
}
std::optional<std::chrono::milliseconds> J1939AdtManager::CalculateTimeoutValue(
	std::vector<AdtTimeoutOverride>& adtTimeoutOverrides,
	unsigned address)
{
	std::optional<std::chrono::milliseconds> timeoutValue{};
	auto itEnd = adtTimeoutOverrides.end();
	auto itFound = std::find_if(adtTimeoutOverrides.begin(), itEnd,
		[address](auto const& entry)
		{
			return address == entry.address;
		});

	if (itFound != itEnd)
	{
		timeoutValue.emplace(itFound->timeout);
	}
	return timeoutValue;
}
}
}
