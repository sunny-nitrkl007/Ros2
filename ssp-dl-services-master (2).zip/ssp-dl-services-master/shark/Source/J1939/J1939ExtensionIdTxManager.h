/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Extension Id Transmit Manager

#pragma once

#include "IJ1939ExtensionIdTxManager.h"
#include "IJ1939Wrapper.h"
#include <SharkConfiguration.pb.h>
#include <Utilities/nice_ptr.h>
#include <vector>

namespace Shark
{
class DependencyContainer;

namespace J1939
{
class J1939ExtensionIdTxManager final : public IJ1939ExtensionIdTxManager
{
public:
	static std::function<void()> CreateInitializer(DependencyContainer const& dependencyContainer);

	J1939ExtensionIdTxManager(
		std::vector<Utilities::nice_ptr<IJ1939Wrapper>>&& j1939Wrappers,
		std::optional<cat::shark::J1939DataLink::DeviceId> deviceIdConfig) noexcept;
// IJ1939ExtensionIdTxManager
	void Initialize() override;
private:
	void RegisterHandlers(IJ1939Wrapper& j1939Wrapper);
	void ResponseHandler(IJ1939Wrapper& j1939Wrapper, unsigned extensionId, unsigned address);
	void SendF003ReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address);
	void SendF016ReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address);
	void SendF019ReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address);
	void SendF01AReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address);
	void SendF0A6ReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address);
	void SendF0BDReadResponse(IJ1939Wrapper& j1939Wrapper, unsigned address);

	std::vector<Utilities::nice_ptr<IJ1939Wrapper>> m_j1939Wrappers;
	std::optional<cat::shark::J1939DataLink::DeviceId> m_deviceIdConfig;
	std::string m_hardwareSerialNumberStringValue{};
	std::string m_hardwarePartNumberStringValue{};
	unsigned m_locationCodeValue{};
};
}
}
