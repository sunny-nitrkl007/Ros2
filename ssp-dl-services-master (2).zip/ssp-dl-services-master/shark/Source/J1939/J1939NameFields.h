/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Name Fields

#pragma once

#include <std_types.h>

namespace Shark
{
namespace J1939
{
/// Used to help with scl_j1939_addr_tbl_t initialization since that struct is made up of pointers.
struct J1939NameFields
{
	unsigned_8 industryGroup;
	unsigned_8 vehicleSystem;
	unsigned_8 vehicleSystemInstance;
	unsigned_8 function;
	unsigned_8 functionInstance;
	unsigned_8 ecmInstance;
	unsigned_16 manufacturerCode;
};
}
}