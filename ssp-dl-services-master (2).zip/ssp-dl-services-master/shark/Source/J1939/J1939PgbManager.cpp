/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See J1939PgbManager.h

#include "J1939PgbManager.h"
#include "DependencyContainer.h"
#include "IJ1939Wrapper.h"
#include "IPidDataReceiver.h"
#include "Log.h"
#include "Config/ProtobufConversions.h"
#include "SharkBytes/ISharkByteManager.h"
#include "SharkBytes/ISlotManager.h"
#include "SharkBytes/PidSlot.h"
#include "SharkError.h"
#include "SharkUtilities/BeginEndLogger.h"
#include "Utilities/ArrayToHexString.h"
#include "Utilities/Conversions.h"
#include <Utilities/SharkBytes/SimpleSharkByte.h>
#include <SharkConfiguration.pb.h>

namespace Shark
{
namespace J1939
{
namespace
{
unsigned CalculateDefaultTimeout(unsigned requestedUpdateRate) noexcept
{
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wold-style-cast"
	return SCL_PGB_J1939_CALC_DFLT_TIMEOUT(requestedUpdateRate);
#pragma GCC diagnostic pop
}
void DumpRxData(
	uint_least8_t const* pData,
	uint_least8_t data_len,
	CallbackContext const& callbackContext,
	uint_least16_t dataStatus)
{
	auto constexpr severity = Log::SeverityLevel::Debug;
	if (Log::ShouldLog(severity, Log::Pgb))
	{
		auto hexBytes = Utilities::ArrayToHexString(pData, data_len);
		LOG_TAG(severity, Log::Pgb,
			"PGB Rx Handler: " << callbackContext.canPort << " " <<
			"SA: 0x" << std::hex << std::uppercase << callbackContext.address << " " <<
			"PID: 0x" << callbackContext.pid << ", DSI: 0x" << dataStatus << ", Data: " << hexBytes);
	}
}
void CreatePgbSharkBytes(
	Config::CanPort canPort,
	cat::shark::J1939DataLink const& j1939DataLink,
	SharkBytes::ISlotManager& slotManager,
	SharkBytes::ISharkByteManager& sharkByteManager)
{
	for (auto& peerNode : j1939DataLink.peer_nodes())
	{
		if (peerNode.has_pgb())
		{
			auto const address = peerNode.address();
			for (auto const& pgbPid : peerNode.pgb().pgb_pids())
			{
				auto id = pgbPid.middleware_id();
				auto const pid = pgbPid.pid();
				auto spPidSlot = std::make_unique<SharkBytes::PidSlot>(pid, std::move(id));
				slotManager.AddPidSlot(*spPidSlot, canPort, address, pid);
				sharkByteManager.AddSharkByte(std::move(spPidSlot));
			}
		}
	}
}
bool J1939DataLinkConfigHasPgb(cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	auto const& peerNodes = j1939DataLinkConfig.peer_nodes();
	return std::any_of(peerNodes.begin(),peerNodes.end(),
		[](auto const& peerNode) { return peerNode.has_pgb(); });
}

std::array<Utilities::nice_ptr<J1939PgbManager>, Config::CanPort::CanPortCount> n_j1939PgbManagers;
}

bool J1939PgbManager::ShouldBeCreated(DependencyContainer const& dependencyContainer)
{
	auto const& configs = dependencyContainer.GetJ1939DataLinkConfigs();
	return std::any_of(configs.begin(), configs.end(),
		[](auto const& spJ1939DataLinkConfig)
		{
			return J1939DataLinkConfigHasPgb(*spJ1939DataLinkConfig);
		});
}
std::function<void()> J1939PgbManager::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	struct InitializerContext
	{
		cat::shark::J1939DataLink const& j1939DataLinkConfig;
		std::shared_ptr<J1939PgbManager> spJ1939PgbManager;
	};
	std::vector<InitializerContext> initializerContexts{};

	for (auto spJ1939DataLinkConfig : dependencyContainer.GetJ1939DataLinkConfigs())
	{
		if (J1939DataLinkConfigHasPgb(*spJ1939DataLinkConfig))
		{
			auto const canPort = Config::ToConfigCanPort(spJ1939DataLinkConfig->can_port());
			CreatePgbSharkBytes(
				canPort,
				*spJ1939DataLinkConfig,
				dependencyContainer.GetISlotManager(),
				dependencyContainer.GetISharkByteManager());

			auto spJ1939PgbManager = std::make_shared<J1939PgbManager>(
				dependencyContainer.GetIPidDataReceiver(),
				dependencyContainer.GetIJ1939Wrapper(canPort));

			initializerContexts.emplace_back(*spJ1939DataLinkConfig, std::move(spJ1939PgbManager));
		}
	}
	assert(!initializerContexts.empty());

	return [initializerContexts = std::move(initializerContexts)]
	{
		for (auto const& context : initializerContexts)
		{
			context.spJ1939PgbManager->Initialize(
				GroupConfigDataFactory::CreatePgbConfigData(
					context.j1939DataLinkConfig,
					&ReceiveHandler));
		}
	};
}
int_least16_t J1939PgbManager::ReceiveHandler(
	uint_least8_t* pData,
	uint_least8_t data_len,
	void* rx_hdlr_context,
	uint_least16_t dataStatus)
{
	assert(rx_hdlr_context);
	auto& callbackContext = *reinterpret_cast<CallbackContext const*>(rx_hdlr_context);
	DumpRxData(pData, data_len, callbackContext, dataStatus);

	auto const canPort = callbackContext.canPort;
	if (n_j1939PgbManagers[canPort])
	{
		n_j1939PgbManagers[canPort]->ProcessData(pData, data_len, callbackContext, dataStatus);
	}
	else
	{
		LOG_WARNING_TAG(Log::Pgb, "Data received but wrapper is not instantiated for " << canPort << "!");
	}

	return 0;
}

J1939PgbManager::J1939PgbManager(
	IPidDataReceiver& pidDataReceiver,
	IJ1939Wrapper& j1939Wrapper) noexcept
	: m_pidDataReceiver(pidDataReceiver)
	, m_j1939Wrapper(j1939Wrapper)
{
	auto const canPort = m_j1939Wrapper.GetCanPort();
	assert(!n_j1939PgbManagers[canPort]);
	n_j1939PgbManagers[canPort] = this;

	LOG_DEBUG_TAG(Log::Pgb, "J1939PgbManager created for " << canPort);
}
J1939PgbManager::~J1939PgbManager()
{
	// Don't use m_j1939Wrapper here since it may have already been destroyed
	auto const itEnd = n_j1939PgbManagers.end();
	auto const itFound = std::find(n_j1939PgbManagers.begin(), itEnd, this);
	assert(itFound != itEnd);
	*itFound = nullptr;

	[[maybe_unused]] auto const canPort =
		static_cast<Config::CanPort>(std::distance(n_j1939PgbManagers.begin(), itFound));
	LOG_DEBUG_TAG(Log::Pgb, "J1939PgbManager destroyed for " << canPort);
}
void J1939PgbManager::Initialize(PgbConfigData&& pgbConfigData)
{
	assert(m_pgbConfigData.pgbSets.empty());
	SharkUtilities::BeginEndLogger beginEndLogger{"PGB Initialization"};
	m_pgbConfigData = std::move(pgbConfigData);

	if (m_pgbConfigData.pgbGroupCount > IJ1939Wrapper::MaxRxPgbGroups())
	{
		throw SharkError("Too many PGB groups: " + To<std::string>(m_pgbConfigData.pgbGroupCount));
	}

	for (auto&& pgbSet : m_pgbConfigData.pgbSets)
	{
		assert(pgbSet.pidConfigs.size() == pgbSet.pidConfigPointers.size());
		assert(pgbSet.pidConfigs.size() > 0);

		auto const& requestedUpdateRate = pgbSet.requestedUpdateRate;
		m_j1939Wrapper.AddPgbGroups(
			pgbSet.address,
			To<unsigned>(pgbSet.pidConfigs.size()),
			pgbSet.pidConfigPointers.data(),
			requestedUpdateRate,
			CalculateDefaultTimeout(requestedUpdateRate));
	}
}
void J1939PgbManager::ProcessData(
	uint_least8_t* pData, uint_least8_t data_len, CallbackContext const& callbackContext, uint_least16_t dataStatus)
{
	m_pidDataReceiver.ReceivePidData(
		m_j1939Wrapper.GetCanPort(),
		callbackContext.address,
		callbackContext.pid,
		dataStatus == 0 ? pData : nullptr,
		dataStatus == 0 ? data_len : 0,
		dataStatus);
}
}
}
