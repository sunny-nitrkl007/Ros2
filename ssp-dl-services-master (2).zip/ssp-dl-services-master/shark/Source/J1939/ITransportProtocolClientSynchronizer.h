/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Transport Protocol Client Synchronizer Interface

#pragma once

#include <functional>

namespace Shark
{
namespace J1939
{
enum class RequestType : unsigned
{
	ExtensionId,
	BasicRead,

	Count,
};
struct TransportProtocolRequest
{
	RequestType type;
	unsigned address;
	unsigned id;
};
constexpr inline bool operator==(TransportProtocolRequest const& Request1, TransportProtocolRequest const& Request2) noexcept
{
	return Request1.type == Request2.type &&
		   Request1.address == Request2.address &&
		   Request1.id == Request2.id;
}

class ITransportProtocolClientSynchronizer
{
public:
	virtual ~ITransportProtocolClientSynchronizer() = default;

	using SendMethod = void(TransportProtocolRequest const& request);
	virtual void Add(TransportProtocolRequest const& request, std::function<SendMethod>&& sendMethod) = 0;
	virtual void Remove(TransportProtocolRequest const& request) = 0;
	virtual void RetryLaterIfCurrent(TransportProtocolRequest const& request) = 0;
};
}
}
