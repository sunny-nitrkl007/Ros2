/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See J1939ExtensionIdManager.h

#include "J1939ExtensionIdManager.h"
#include "Config/ProtobufConversions.h"
#include "DependencyContainer.h"
#include "IJ1939Wrapper.h"
#include "J1939Definitions.h"
#include "Log.h"
#include "SharkBytes/ISharkByteManager.h"
#include <Utilities/SharkBytes/TransientSharkByte.h>
#include <algorithm>
#include <cassert>
#include <set>

namespace Shark
{
namespace J1939
{
namespace
{
constexpr unsigned n_extensionIdReadRequestCommand{0x80};
constexpr unsigned n_nackRetryLaterCode{0x0005};
constexpr unsigned n_extensionIdRequestSize{3};         // outgoing: 1 command byte + 2 extension id bytes
constexpr unsigned n_extensionIdResponseHeaderSize{2};  // incoming: 2-byte extension id
constexpr unsigned n_nackErrorCodeOffset{4};            // incoming NACK: error code follows a 4-byte header
constexpr unsigned n_nackMessageMinSize{n_nackErrorCodeOffset + 2};

constexpr unsigned n_supportedExtensionIds[]{0xF019, 0xF01A};

bool IsExtensionIdSupported(unsigned extensionId)
{
	return std::ranges::find(n_supportedExtensionIds, extensionId) != std::end(n_supportedExtensionIds);
}

bool J1939DataLinkConfigHasExtensionId(cat::shark::J1939DataLink const& j1939DataLinkConfig)
{
	auto const& peerNodes = j1939DataLinkConfig.peer_nodes();
	return std::any_of(peerNodes.begin(), peerNodes.end(),
		[](auto const& peerNode) { return peerNode.has_extension_id(); });
}

unsigned ParseBigEndianUint16(uint8_t const* pData)
{
	return (static_cast<unsigned>(pData[0]) << 8) | static_cast<unsigned>(pData[1]);
}

std::array<Utilities::nice_ptr<J1939ExtensionIdManager>, Config::CanPort::CanPortCount> n_j1939ExtensionIdManagers{};

std::vector<J1939ExtensionIdManager::SharkByteMapping> CreateExtensionIdSharkBytes(
	cat::shark::J1939DataLink const& j1939DataLinkConfig,
	J1939ExtensionIdManager& manager,
	SharkBytes::ISharkByteManager& sharkByteManager)
{
	std::vector<J1939ExtensionIdManager::SharkByteMapping> mappings{};
	for (auto const& peerNode : j1939DataLinkConfig.peer_nodes())
	{
		if (peerNode.has_extension_id())
		{
			auto const address = peerNode.address();
			for (auto const& extensionIdRead : peerNode.extension_id().extension_id_reads())
			{
				auto const extensionId = extensionIdRead.extension_id();
				auto const& middlewareId = extensionIdRead.middleware_id();

				auto spSharkByte = std::make_unique<Utilities::TransientSharkByte>(
					middlewareId.c_str(),
					[&manager, address, extensionId](Utilities::TransientSharkByte&)
					{
						manager.Refresh(address, extensionId);
					});

				mappings.push_back({address, extensionId, spSharkByte.get()});
				sharkByteManager.AddSharkByte(std::move(spSharkByte));
			}
		}
	}
	return mappings;
}
}

bool J1939ExtensionIdManager::ShouldBeCreated(DependencyContainer const& dependencyContainer)
{
	auto const& configs = dependencyContainer.GetJ1939DataLinkConfigs();
	return std::any_of(configs.begin(), configs.end(),
		[](auto const& spJ1939DataLinkConfig)
		{
			return J1939DataLinkConfigHasExtensionId(*spJ1939DataLinkConfig);
		});
}
std::function<void()> J1939ExtensionIdManager::CreateInitializer(DependencyContainer const& dependencyContainer)
{
	struct InitializerContext
	{
		std::shared_ptr<J1939ExtensionIdManager> spJ1939ExtensionIdManager;
	};
	std::vector<InitializerContext> initializerContexts{};

	for (auto spJ1939DataLinkConfig : dependencyContainer.GetJ1939DataLinkConfigs())
	{
		if (J1939DataLinkConfigHasExtensionId(*spJ1939DataLinkConfig))
		{
			auto const canPort = Config::ToConfigCanPort(spJ1939DataLinkConfig->can_port());

			auto spJ1939ExtensionIdManager = std::make_shared<J1939ExtensionIdManager>(
				*spJ1939DataLinkConfig,
				dependencyContainer.GetIJ1939Wrapper(canPort),
				dependencyContainer.GetTransportProtocolClientSynchronizer());

			auto& sharkByteManager = dependencyContainer.GetISharkByteManager();
			spJ1939ExtensionIdManager->SetSharkByteMappings(
				CreateExtensionIdSharkBytes(*spJ1939DataLinkConfig, *spJ1939ExtensionIdManager, sharkByteManager));

			initializerContexts.emplace_back(InitializerContext{std::move(spJ1939ExtensionIdManager)});
		}
	}
	assert(!initializerContexts.empty());

	return [initializerContexts = std::move(initializerContexts)]()
	{
		for (auto const& context : initializerContexts)
		{
			context.spJ1939ExtensionIdManager->Initialize();
		}
	};
}
J1939ExtensionIdManager::J1939ExtensionIdManager(
	cat::shark::J1939DataLink const& j1939DataLink,
	IJ1939Wrapper& j1939Wrapper,
	ITransportProtocolClientSynchronizer& synchronizer) noexcept
	: m_j1939DataLink{j1939DataLink}
	, m_j1939Wrapper{j1939Wrapper}
	, m_synchronizer{synchronizer}
	, m_sharkByteMappings{}
{
	auto const canPort = m_j1939Wrapper.GetCanPort();
	assert(!n_j1939ExtensionIdManagers[canPort]);
	n_j1939ExtensionIdManagers[canPort] = this;
}
J1939ExtensionIdManager::~J1939ExtensionIdManager()
{
	// Don't use m_j1939Wrapper here since it may have already been destroyed
	auto const itEnd = n_j1939ExtensionIdManagers.end();
	auto const itFound = std::find(n_j1939ExtensionIdManagers.begin(), itEnd, this);
	assert(itFound != itEnd);
	*itFound = nullptr;

	[[maybe_unused]] auto const canPort =
		static_cast<Config::CanPort>(std::distance(n_j1939ExtensionIdManagers.begin(), itFound));
	LOG_DEBUG_TAG(Log::ExtId, "J1939ExtensionIdManager destroyed for " << canPort);
}
void J1939ExtensionIdManager::SetSharkByteMappings(std::vector<SharkByteMapping>&& mappings)
{
	assert(m_sharkByteMappings.empty());
	m_sharkByteMappings = std::move(mappings);
}
void J1939ExtensionIdManager::Initialize()
{
	std::set<unsigned> registeredExtensionIds{};
	for (auto const& peerNode : m_j1939DataLink.peer_nodes())
	{
		if (peerNode.has_extension_id())
		{
			for (auto const& extensionIdRead : peerNode.extension_id().extension_id_reads())
			{
				auto const extensionId = extensionIdRead.extension_id();
				if (!IsExtensionIdSupported(extensionId))
				{
					LOG_WARNING_TAG(Log::ExtId, "Unsupported ExtensionId 0x" << std::hex << std::uppercase
						<< extensionId << " will not be registered");
					continue;
				}
				// The Common Services code underneath the register calls will fail and we will throw if
				// a duplicate registration is attempted. Only register once per unique extensionId.
				if (registeredExtensionIds.insert(extensionId).second)
				{
					RegisterReceiveHandlers(extensionId);
				}
			}
		}
	}
}
void J1939ExtensionIdManager::Refresh(unsigned address, unsigned extensionId)
{
	auto const request = TransportProtocolRequest{
		RequestType::ExtensionId, address, extensionId};

	m_synchronizer.Add(request,
		[this](auto const& req) { SendReadRequest(req); });
}
void J1939ExtensionIdManager::SendReadRequest(TransportProtocolRequest const& request)
{
	uint8_t message[n_extensionIdRequestSize]{};
	message[0] = static_cast<uint8_t>(n_extensionIdReadRequestCommand);
	message[1] = static_cast<uint8_t>((request.id >> 8) & 0xFF); // MSB
	message[2] = static_cast<uint8_t>(request.id & 0xFF);        // LSB

	LOG_DEBUG_TAG(Log::ExtId,
		"ExtensionId Read Request: DA: 0x" << std::hex << std::uppercase << request.address
		<< " ExtId: 0x" << request.id);

	m_j1939Wrapper.SendPropAMessage(request.address, message, sizeof(message));
}
void J1939ExtensionIdManager::RegisterReceiveHandlers(unsigned extensionId)
{
	m_j1939Wrapper.RegisterExtensionIdCommandIdHandler(
		ExtensionIdCommand::AcknowledgeResponse,
		extensionId,
		[this, extensionId](unsigned address, uint8_t const* pMessage, unsigned messageLength)
		{
			NackHandler(address, extensionId, pMessage, messageLength);
		});

	// ECM read responses arrive as [ExtId MSB][ExtId LSB][payload...] — the 2-byte ExtId
	// acts as the SCL command, so use command-only registration (no separate cat_id).
	m_j1939Wrapper.RegisterExtensionIdCommandHandler(
		extensionId,
		[this](unsigned address, uint8_t const* pMessage, unsigned messageLength)
		{
			ReadResponseHandler(address, pMessage, messageLength);
		});
}
Utilities::nice_ptr<Utilities::TransientSharkByte> J1939ExtensionIdManager::FindSharkByte(
	unsigned address,
	unsigned extensionId) const
{
	auto const itFound = std::ranges::find_if(m_sharkByteMappings,
		[address, extensionId](SharkByteMapping const& mapping)
		{
			return mapping.address == address && mapping.extensionId == extensionId;
		});
	return itFound != m_sharkByteMappings.end() ? itFound->spSharkByte
	                                             : Utilities::nice_ptr<Utilities::TransientSharkByte>{};
}
void J1939ExtensionIdManager::ReadResponseHandler(unsigned address, uint8_t const* pMessage, unsigned messageLength)
{
	if (messageLength >= n_extensionIdResponseHeaderSize)
	{
		// Message format: [ExtId MSB][ExtId LSB][payload...]
		// The 2-byte ExtId doubles as the SCL command (registered via RegisterExtensionIdCommandHandler).
		auto const extensionId = ParseBigEndianUint16(pMessage);

		auto const request = TransportProtocolRequest{
			RequestType::ExtensionId, address, extensionId};
		m_synchronizer.Remove(request);

		auto const* pPayload = pMessage + n_extensionIdResponseHeaderSize;
		auto const payloadLength = messageLength - n_extensionIdResponseHeaderSize;

		LOG_DEBUG_TAG(Log::ExtId,
			"ExtensionId Read Response: SA: 0x" << std::hex << std::uppercase << address
			<< " ExtId: 0x" << extensionId);

		std::vector<uint8_t> const value{pPayload, pPayload + payloadLength};

		auto const spSharkByte = FindSharkByte(address, extensionId);
		if (spSharkByte)
		{
			spSharkByte->Write(value);
		}
		else
		{
			LOG_WARNING_TAG(Log::ExtId, "ExtensionId Read Response: No SharkByte mapping for SA: 0x"
				<< std::hex << std::uppercase << address << " ExtId: 0x" << extensionId);
		}
	}
}
void J1939ExtensionIdManager::NackHandler(unsigned address, unsigned extensionId, uint8_t const* pMessage, unsigned messageLength)
{
	if (messageLength >= n_nackMessageMinSize)
	{
		auto const errorCode = ParseBigEndianUint16(pMessage + n_nackErrorCodeOffset);

		auto const request = TransportProtocolRequest{
			RequestType::ExtensionId, address, extensionId};

		LOG_DEBUG_TAG(Log::ExtId,
			"ExtensionId NACK: SA: 0x" << std::hex << std::uppercase << address
			<< " ExtId: 0x" << extensionId << " Error: 0x" << errorCode);

		if (errorCode == n_nackRetryLaterCode)
		{
			m_synchronizer.RetryLaterIfCurrent(request);
		}
		else
		{
			m_synchronizer.Remove(request);

			auto const spSharkByte = FindSharkByte(address, extensionId);
			if (spSharkByte)
			{
				spSharkByte->WriteInvalid();
			}
			else
			{
				LOG_WARNING_TAG(Log::ExtId, "ExtensionId NACK: No SharkByte mapping for SA: 0x"
					<< std::hex << std::uppercase << address << " ExtId: 0x" << extensionId);
			}
		}
	}
}
}
}
