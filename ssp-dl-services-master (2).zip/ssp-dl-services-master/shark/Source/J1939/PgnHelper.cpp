/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See PgnHelper.h

#include "PgnHelper.h"
#include "IJ1939PublicDataReceiver.h"
#include "J1939Definitions.h"
#include "Log.h"
#include "Utilities/ArrayToHexString.h"
#include "Utilities/narrow_cast.h"
#include "Utilities/ToUnderlying.h"
#include <cassert>


namespace Shark
{
namespace J1939
{
namespace
{
MbufWrapper CreateMbufWrapper(scl_j1939_mbuf_hdr_t const* pMbuf, SCL_J1939_RX_MSG_CB_ENUM_t event)
{
	auto const isValid = event == SCL_J1939_RX_MSG_PGN_RXED;
	assert(!isValid || pMbuf);
	return isValid ? MbufWrapper{pMbuf} : MbufWrapper{};
}

Utilities::nice_ptr<PgnHelper> n_spPgnHelper{};
std::array<scl_j1939_link_t, Config::CanPort::CanPortCount> n_j1939links{};

constexpr auto n_mbufStartIndexZero = 0;

void InitializeJ1939Links()
{
	n_j1939links.fill(SCL_J1939_INVALID_LINK);
}
void DumpRxData(Config::CanPort canPort, MbufWrapper mbuf, scl_j1939_rx_msg_t const* pRxMsg)
{
	auto constexpr severity = Log::SeverityLevel::Debug;
	if (Log::ShouldLog(severity, Log::Pgn))
	{
		std::string hexBytes{};

		if (mbuf.IsValid())
		{
			auto const length = mbuf.Length();
			std::vector<uint8_t> data(length);
			auto const getBytesSucceeded = mbuf.GetBytes(n_mbufStartIndexZero, length, data.data());
			assert(getBytesSucceeded); (void) getBytesSucceeded;
			hexBytes = Utilities::ArrayToHexString(data.data(), length);
		}
		LOG_TAG(severity, Log::Pgn,
			"PGN Rx Handler: " << canPort << " SA: " << Config::J1939Address{pRxMsg->Mu8_source_address} << " "
			"PGN: " << Config::Pgn{pRxMsg->Mu32_pgn} << ", DataStatus is " << (mbuf.IsValid() ? "GOOD" : "BAD") << ", "
			"Data: " << hexBytes);
	}
}
}

scl_j1939_rx_msg_t IPgnHelper::CreateSclPgnConfig(
	unsigned pgn,
	unsigned address,
	unsigned timeout)
{
	unsigned_8 const controlFlags =
		(timeout == 0) ? SCL_J1939_RX_MSG_CBF_ENABLED : SCL_J1939_RX_MSG_CBF_ENABLED | SCL_J1939_RX_MSG_CBF_LOST_TIMER_APPLICABLE;
	return scl_j1939_rx_msg_t{
		pgn,
		PgnHelper::ReceiveHandler,
		J1939Definitions::DefaultPriority(),
		FALSE,
		Utilities::narrow_cast<unsigned_8>(address),
		{},
		controlFlags,
		Utilities::narrow_cast<int_16>(timeout)};
}

std::unique_ptr<PgnHelper> PgnHelper::Create(IJ1939PublicDataReceiver& publicDataReceiver)
{
	return std::make_unique<PgnHelper>(publicDataReceiver);
}
void PgnHelper::ReceiveHandler(
	scl_j1939_link_t link,
	const scl_j1939_rx_msg_t *Ppst_rx_msg,
	int_8,
	SCL_J1939_RX_MSG_CB_ENUM_t Pe_event,
	const scl_j1939_mbuf_hdr_t *mbuf_ptr)
{
	assert(link != SCL_J1939_INVALID_LINK);
	assert(Ppst_rx_msg);
	assert(n_spPgnHelper);
	n_spPgnHelper->ProcessPgnData(link, CreateMbufWrapper(mbuf_ptr, Pe_event), Ppst_rx_msg);
}

PgnHelper::PgnHelper(IJ1939PublicDataReceiver& publicDataReceiver) noexcept
	: m_publicDataReceiver{publicDataReceiver}
{
	assert(!n_spPgnHelper);
	n_spPgnHelper = this;

	InitializeJ1939Links();
}
PgnHelper::~PgnHelper()
{
	assert(n_spPgnHelper);
	n_spPgnHelper = nullptr;

	// Clear the links to make it more obvious if a callback occurs after destruction.
	InitializeJ1939Links();
}
void PgnHelper::RegisterLink(Config::CanPort canPort, scl_j1939_link_t link)
{
	assert(canPort < Config::CanPort::CanPortCount);
	assert(link != SCL_J1939_INVALID_LINK);
	assert(n_j1939links[Utilities::ToUnderlying(canPort)] == SCL_J1939_INVALID_LINK);

	n_j1939links[Utilities::ToUnderlying(canPort)] = link;
}
bool PgnHelper::SendPgnMessage(
	scl_j1939_link_t link,
	unsigned pgn,
	unsigned destinationAddress,
	uint8_t const* pData,
	unsigned dataLength)
{
	assert(pData);
	assert(dataLength);

	auto const succeeded = scl_j1939_que_tx_msg_by_address(
		link,
		pgn,
		J1939Definitions::DefaultPriority(),
		Utilities::narrow_cast<unsigned_8>(destinationAddress),
		J1939Definitions::VirtualEcmIndex(),
		pData,
		Utilities::narrow_cast<unsigned_16>(dataLength));
	if (!succeeded)
	{
		LOG_INFO_LOW_TAG(Log::Pgn, "scl_j1939_que_tx_msg_by_address failed!");
	}

	return succeeded;
}
void PgnHelper::ProcessPgnData(scl_j1939_link_t link, MbufWrapper mbuf, scl_j1939_rx_msg_t const* pRxMsg)
{
	assert(link != SCL_J1939_INVALID_LINK);
	auto const itEnd = n_j1939links.end();
	auto const itFound = std::find(n_j1939links.begin(), itEnd, link);
	assert(itFound != itEnd);
	auto const canPort = static_cast<Config::CanPort>(std::distance(n_j1939links.begin(), itFound));

	DumpRxData(canPort, mbuf, pRxMsg);
	m_publicDataReceiver.ReceivePgnData(canPort, pRxMsg->Mu8_source_address, pRxMsg->Mu32_pgn, mbuf);
}
}
}
