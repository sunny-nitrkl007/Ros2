/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Base Wrapper Interface

#pragma once

#include "Utilities/DefineExceptionClass.h"
#include <scl_j1939.h>

namespace Shark
{
namespace J1939
{
class IJ1939BaseWrapper
{
public:
	virtual ~IJ1939BaseWrapper() = default;

	DEFINE_EXCEPTION_CLASS(Error);

	/// \exception IJ1939BaseWrapper::Error
	///		Thrown when an unrecoverable error occurs in the SCL library
	virtual void EstablishLink(scl_j1939_config_t const& j1939Config) = 0;

	virtual scl_j1939_link_t GetLink() const = 0;

	virtual bool SendPgnMessage(unsigned pgn, unsigned destinationAddress, uint8_t const* pData, unsigned dataLength) = 0;
};
}
}
