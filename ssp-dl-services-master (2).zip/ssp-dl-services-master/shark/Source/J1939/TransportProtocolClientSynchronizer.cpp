/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See TransportProtocolClientSynchronizer.h

#include "TransportProtocolClientSynchronizer.h"
#include "IJ1939UberWrapper.h"
#include "IPeriodicTaskManager.h"
#include "Log.h"
#include <algorithm>

using namespace std::chrono_literals;

namespace Shark
{
namespace J1939
{
namespace
{
constexpr unsigned n_maxRetries{4};
constexpr std::chrono::milliseconds n_timeout{250ms};
}

class TransportProtocolSender final
{
public:
	TransportProtocolSender(
		TransportProtocolRequest const& request,
		std::function<ITransportProtocolClientSynchronizer::SendMethod>&& sender) noexcept;
	void Send();
	TransportProtocolRequest const& GetRequest() const;
private:
	TransportProtocolRequest const m_request;
	std::function<ITransportProtocolClientSynchronizer::SendMethod> const m_sendMethod;
};
TransportProtocolSender::TransportProtocolSender(
	TransportProtocolRequest const& request,
	std::function<ITransportProtocolClientSynchronizer::SendMethod>&& sender) noexcept
	: m_request(request)
	, m_sendMethod(std::move(sender))
{
}
void TransportProtocolSender::Send()
{
	m_sendMethod(m_request);
}
TransportProtocolRequest const& TransportProtocolSender::GetRequest() const
{
	return m_request;
}

std::unique_ptr<TransportProtocolClientSynchronizer> TransportProtocolClientSynchronizer::Create(
	IPeriodicTaskManager& periodicTaskManager)
{
	auto spTransportProtocolClientSynchronizer = std::make_unique<TransportProtocolClientSynchronizer>();
	AddPeriodicTask(periodicTaskManager, *spTransportProtocolClientSynchronizer);

	return spTransportProtocolClientSynchronizer;
}
void TransportProtocolClientSynchronizer::AddPeriodicTask(
	IPeriodicTaskManager& periodicTaskManager,
	TransportProtocolClientSynchronizer& TransportProtocolClientSynchronizer)
{
	periodicTaskManager.Add(
		IJ1939UberWrapper::TaskPeriod(),
		[&TransportProtocolClientSynchronizer]
		{
			TransportProtocolClientSynchronizer.Update();
		});
}
TransportProtocolClientSynchronizer::TransportProtocolClientSynchronizer() noexcept
{
}
void TransportProtocolClientSynchronizer::Add(TransportProtocolRequest const& request, std::function<SendMethod>&& sendMethod)
{
	std::unique_lock<std::mutex> lock(m_mutex);
	if (m_requests.empty())
	{
		ResetRetryParameters();
	}
	LOG_DEBUG("TP Request Added: " << std::hex << std::uppercase << "address = " << request.address << " id = " << request.id);
	auto spSender = std::make_shared<TransportProtocolSender>(request, std::move(sendMethod));
	m_requests.emplace_back(std::move(spSender));
}
void TransportProtocolClientSynchronizer::Remove(TransportProtocolRequest const& request)
{
	std::unique_lock<std::mutex> lock(m_mutex);

	auto const itEnd = m_requests.cend();
	auto const itFound = std::find_if(m_requests.cbegin(), itEnd,
		[&request](std::shared_ptr<TransportProtocolSender> const& sender)
		{
			return sender->GetRequest() == request;
		});
	if (itFound != itEnd)
	{
		m_requests.erase(itFound);
		LOG_DEBUG("Transport Protocol Request Removed: "
			<< std::hex << std::uppercase << "address = " << request.address << " id = " << request.id);
		ResetRetryParameters();
	}
	else
	{
		LOG_DEBUG("Transport Protocol Request Not Found For Removal: "
			<< std::hex << std::uppercase << "address = " << request.address << " id = " << request.id);
	}
}
void TransportProtocolClientSynchronizer::RetryLaterIfCurrent(TransportProtocolRequest const& request)
{
	std::unique_lock<std::mutex> lock(m_mutex);
	bool invalidRequest{false};

	if (!m_requests.empty())
	{
		auto const& currentRequest = m_requests.front();
		if (currentRequest->GetRequest() == request)
		{
			m_requests.emplace_back(currentRequest);
			RemoveCurrentRequest();
			ResetRetryParameters();
		}
		else
		{
			invalidRequest = true;
		}
	}
	else
	{
		invalidRequest = true;
	}

	if (invalidRequest)
	{
		LOG_INFO_HIGH_TAG(
			Log::ExtId,
			"Ignored out of order retry request for " << request.id << " from " << std::hex << std::uppercase << request.address);
	}
}
void TransportProtocolClientSynchronizer::Update()
{
	std::shared_ptr<TransportProtocolSender> spSender{};
	{
		std::unique_lock<std::mutex> lock(m_mutex);
		if (!m_requests.empty())
		{
			if (m_retryCount == 0)
			{
				RemoveCurrentRequest();
				ResetRetryParameters();
			}
			else
			{
				auto currentTime = Utilities::Clock::now();
				if (m_retryTime <= currentTime)
				{
					m_retryTime = currentTime + n_timeout;
					--m_retryCount;
					spSender = m_requests.front();
				}
			}
		}
	}
	if (spSender)
	{
		spSender->Send();
	}
}
void TransportProtocolClientSynchronizer::RemoveCurrentRequest()
{
	assert(!m_requests.empty());
	auto itBegin = m_requests.begin();
	LOG_DEBUG("Current TP Request Removed:");
	m_requests.erase(itBegin);
}
void TransportProtocolClientSynchronizer::ResetRetryParameters()
{
	m_retryCount = n_maxRetries;
	m_retryTime = Utilities::Clock::now();
}
}
}
