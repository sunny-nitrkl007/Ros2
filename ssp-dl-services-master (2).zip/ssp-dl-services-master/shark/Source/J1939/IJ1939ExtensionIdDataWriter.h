/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Interface for writing data to a remote J1939 Extension Id server

#pragma once

#include "Shark/IWriteSharkByte.h"
#include <cstdint>

namespace Shark
{
namespace J1939
{
class IJ1939ExtensionIdDataWriter
{
public:
	virtual ~IJ1939ExtensionIdDataWriter() = default;

	virtual void Write(
		unsigned destinationAddress,
		unsigned extensionId,
		uint8_t const* pData,
		unsigned dataLength,
		IWriteSharkByte::CompletedCallback const& completedCallback) = 0;
};
}
}
