/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Public Data Receiver Interface

#pragma once

#include "MbufWrapper.h"
#include "Config/CanPort.h"
#include "Config/J1939Address.h"
#include "Config/Pgn.h"
#include "Config/Spn.h"
#include <cstdint>
#include <optional>
#include <vector>

namespace Shark
{
namespace J1939
{
class IJ1939PublicDataReceiver
{
public:
	virtual ~IJ1939PublicDataReceiver() = default;

	/// Called when data has been received
	/// \param data If !mbuf.IsValid(), then the SPN Shark Bytes will be invalidated
	virtual void ReceivePgnData(
		Config::CanPort canPort,
		Config::J1939Address address,
		Config::Pgn pgn,
		MbufWrapper mbuf) = 0;

	virtual void ReceivePgnData(
		Config::CanPort canPort,
		Config::J1939Address address,
		Config::Pgn pgn,
		SharkByteValue&& value) = 0;
};
}
}
