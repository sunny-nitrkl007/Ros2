/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pid Data Writer Interface

#pragma once

#include "Utilities/nice_ptr.h"
#include <array>
#include <cstdint>
#include <functional>

namespace Shark
{
class IPidDataWriter
{
public:
	static constexpr unsigned s_maximumByteCount = 4;
	using Data = std::array<uint8_t, s_maximumByteCount>;

	virtual ~IPidDataWriter() = default;

	/// Called to write data
	/// \param data The data to send. It must already be in the correct byte order (LSB or MSB).
	///             Only the first dataLength bytes will be used.
	virtual void Write(
		unsigned destinationAddress,
		unsigned pid,
		Data const& data,
		unsigned dataLength,
		std::function<void()> const& completedCallback) = 0;
};
}
