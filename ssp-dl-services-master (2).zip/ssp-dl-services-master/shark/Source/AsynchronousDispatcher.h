/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// AsynchronousDispatcher: Performs work on the timed callback thread

#pragma once

#include "IAsynchronousDispatcher.h"
#include "SharkUtilities/IEventCallbackFactory.h"
#include <Utilities/SingleThreadedUsageValidator.h>
#include <mutex>
#include <optional>
#include <vector>

namespace Shark
{
class AsynchronousDispatcher final : public IAsynchronousDispatcher
{
public:
	AsynchronousDispatcher(SharkUtilities::IEventCallbackFactory& eventCallbackFactory);
// IAsynchronousDispatcher
	void Dispatch(Work const& function) override;
private:
	void PerformQueuedWork();

	SharkUtilities::IEventCallbackFactory& m_eventCallbackFactory;

	std::mutex m_mutex{};
	std::unique_ptr<SharkUtilities::ITimedCallback> m_spTimedCallback{};
	std::vector<Work> m_queuedWork{};
	std::vector<Work> m_queuedWorkBeingPerformed{};
	std::optional<Utilities::SingleThreadedUsageValidator> m_singleThreadUsageValidator;
};
}
