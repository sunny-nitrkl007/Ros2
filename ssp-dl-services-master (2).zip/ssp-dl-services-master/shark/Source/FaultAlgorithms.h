/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Fault Algorithm interface

#pragma once

#include "IFaultAlgorithm.h"

namespace Shark
{
class NullFaultAlgorithm : public IFaultAlgorithm
{
public:
	bool IsValid(uint32_t) override;
};

class SpnFaultAlgorithm : public IFaultAlgorithm
{
public:
	SpnFaultAlgorithm(unsigned bitCount) noexcept;
	bool IsValid(uint32_t byteValue) override;
private:
	uint32_t m_minimumErrorValue;
};
}