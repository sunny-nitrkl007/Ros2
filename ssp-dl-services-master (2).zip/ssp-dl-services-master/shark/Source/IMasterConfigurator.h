/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Master Configurator Interface

#pragma once

#include <memory>
#include <SharkConfiguration.pb.h>

namespace Utilities
{
class IEnvironment;
class IFilesystem;
}

namespace Shark
{
class IExtensionIdDataReceiver;
class IPidDataReceiver;

namespace SharkBytes
{
class ISharkByteManager;
class ISlotManager;
class IWriteSharkByteManager;
}

namespace Bdt
{
class IBdtManager;
}
namespace J1939
{
class IJ1939PublicDataReceiver;
}
namespace SharkUtilities
{
class IEventCallbackFactory;
}

class IMasterConfigurator
{
public:
	virtual ~IMasterConfigurator() = default;

	virtual void Initialize() const = 0;

	static std::unique_ptr<IMasterConfigurator> Create(
		cat::shark::Config const& sharkConfig,
		SharkBytes::ISharkByteManager& sharkByteManager,
		SharkBytes::IWriteSharkByteManager& writeSharkByteManager,
		IPidDataReceiver& pidDataReceiver,
		J1939::IJ1939PublicDataReceiver& publicDataReceiver,
		IExtensionIdDataReceiver& extensionIdDataReceiver,
		SharkBytes::ISlotManager& slotManager,
		Utilities::IEnvironment const& environment,
		SharkUtilities::IEventCallbackFactory& eventCallbackFactory,
		Utilities::IFilesystem& filesystem);
};
}
