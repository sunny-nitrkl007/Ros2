/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Binary Data Converter interface

#pragma once

#include "J1939/MbufWrapper.h"
#include "Utilities/Units.h"
#include <optional>
#include <stdint.h>

namespace Shark
{
struct BitwiseSharkByteDefinition
{
	unsigned bitOffset;
	unsigned bitCount; // Only supports up to 32 bits
	double unitsPerBit;
	Units::Unit units;
	double valueOffset;
	bool reverseBytes;
};

class IBinaryDataConverter
{
public:
	virtual ~IBinaryDataConverter() = default;

	virtual std::optional<double> ConvertUint64(std::optional<uint64_t> data, BitwiseSharkByteDefinition const& definition) const = 0;
	virtual std::optional<double> ConvertMBuf(J1939::MbufWrapper mbuf, BitwiseSharkByteDefinition const& definition) const = 0;
};
}