/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See InitializerFactory.h

#include "InitializerFactory.h"
#include "Bdt/BdtClientWrapper.h"
#include "Calibrations/CalibrationWrapper.h"
#include "DependencyContainer.h"
#include "Diagnostics/CodesManager.h"
#include "J1939/J1939AdtManager.h"
#include "J1939/J1939BasicReadWriteManager.h"
#include "J1939/J1939ExtensionIdManager.h"
#include "J1939/J1939ExtensionIdTxManager.h"
#include "J1939/J1939PgbManager.h"
#include "J1939/J1939PgnPeriodicTxWrapper.h"
#include "J1939/J1939UberWrapper.h"
#include "MachineSecuritySystem/MachineSecuritySystemFactory.h"
#include "Utilities/CountOf.h"
#include <cassert>

namespace Shark
{
namespace
{
bool ShouldAlwaysBeCreated(DependencyContainer const&) { return true; }

struct InitializerFactoryEntry
{
	bool (*pShouldCreateInitializer)(DependencyContainer const& container);
	std::function<void()> (*pCreateInitializer)(DependencyContainer const& container);
};

#define INITIALIZER_FACTORY_ENTRY(x) { &x::ShouldBeCreated, &x::CreateInitializer }
#define INITIALIZER_FACTORY_ALWAYS_INITIALIZED_ENTRY(x) { &ShouldAlwaysBeCreated, &x::CreateInitializer }

constexpr InitializerFactoryEntry n_initializerFactoryEntries[] {
	INITIALIZER_FACTORY_ALWAYS_INITIALIZED_ENTRY(J1939::J1939UberWrapper),
	INITIALIZER_FACTORY_ENTRY(J1939::J1939PgbManager),
	INITIALIZER_FACTORY_ENTRY(J1939::J1939AdtManager),
	INITIALIZER_FACTORY_ENTRY(J1939::J1939PgnPeriodicTxWrapper),
	INITIALIZER_FACTORY_ENTRY(J1939::J1939BasicReadWriteManager),
	INITIALIZER_FACTORY_ENTRY(J1939::J1939ExtensionIdManager),

	INITIALIZER_FACTORY_ALWAYS_INITIALIZED_ENTRY(J1939::J1939ExtensionIdTxManager),
	INITIALIZER_FACTORY_ENTRY(MachineSecuritySystem::MachineSecuritySystemFactory),
	INITIALIZER_FACTORY_ENTRY(Bdt::BdtClientWrapper),
	INITIALIZER_FACTORY_ENTRY(Calibrations::CalibrationWrapper),

// This creates the diagnostics initializers
	INITIALIZER_FACTORY_ENTRY(Diagnostics::CodesManager),
};
}

InitializerFactory::InitializerFactory(DependencyContainer const& dependencyContainer)
	: m_dependencyContainer{dependencyContainer}
{
}
std::vector<std::function<void()>> InitializerFactory::CreateInitializers()
{
	std::vector<std::function<void()>> initializers{};
	initializers.reserve(Utilities::CountOf(n_initializerFactoryEntries));
	for (auto&& entry : n_initializerFactoryEntries)
	{
		if (entry.pShouldCreateInitializer(m_dependencyContainer))
		{
			auto initializer = entry.pCreateInitializer(m_dependencyContainer);
			assert(initializer);
			initializers.emplace_back(std::move(initializer));
		}
	}

	return initializers;
}
}
