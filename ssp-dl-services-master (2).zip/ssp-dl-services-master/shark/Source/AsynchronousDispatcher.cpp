/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See AsynchronousDispatcher.h

#include "AsynchronousDispatcher.h"
#include <cassert>

namespace Shark
{
namespace
{
using namespace std::chrono_literals;

constexpr auto n_dispatchDelay = 1ms; // 0 does not work in timed callbacks.
}

AsynchronousDispatcher::AsynchronousDispatcher(SharkUtilities::IEventCallbackFactory& eventCallbackFactory)
	: m_eventCallbackFactory(eventCallbackFactory)
	, m_singleThreadUsageValidator{}
{
}
void AsynchronousDispatcher::Dispatch(Work const& work)
{
	std::lock_guard<std::mutex> lock{m_mutex};

	m_queuedWork.emplace_back(work);

	if (!m_spTimedCallback)
	{
		assert(m_queuedWork.size() == 1);
		m_spTimedCallback = m_eventCallbackFactory.CreateTimedCallbackThatFiresIn(
			n_dispatchDelay,
			[this, work]{ PerformQueuedWork(); });
	}
}
void AsynchronousDispatcher::PerformQueuedWork()
{
	// Don't hold the lock while performing the work
	{
		std::lock_guard<std::mutex> lock(m_mutex);
		assert(m_queuedWorkBeingPerformed.empty());

		// This method must always be called by the same thread--that is the only way to
		// guarantee that the work is performed in order.
		if (!m_singleThreadUsageValidator)
		{
			m_singleThreadUsageValidator.emplace();
		}
		m_singleThreadUsageValidator->ValidateCurrentThread();

		m_queuedWorkBeingPerformed.swap(m_queuedWork);
		m_spTimedCallback.reset();
	}

	assert(!m_queuedWorkBeingPerformed.empty());
	for (auto&& work : m_queuedWorkBeingPerformed)
	{
		work();
	}
	m_queuedWorkBeingPerformed.clear();
}
}
