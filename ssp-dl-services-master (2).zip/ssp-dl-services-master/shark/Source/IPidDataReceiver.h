/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pid Data Receiver Interface

#pragma once

#include <Config/CanPort.h>
#include <Config/J1939Address.h>
#include <Config/Pid.h>
#include <cstdint>

namespace Shark
{

class IPidDataReceiver
{
public:
	virtual ~IPidDataReceiver() = default;

	/// Called when data has been received
	/// \param pData If there was a DSI, then it must be set to nullptr.
	/// \param byteOrder Byte order of pData
	/// \param dataStatus 0x0000 if no dsi, 0xFF00-0xFF1F if dsi
	virtual void ReceivePidData(
		Config::CanPort canPort,
		Config::J1939Address address,
		Config::Pid pid,
		uint8_t const* pData,
		unsigned dataLength,
		unsigned dataStatus) = 0;
};

}
