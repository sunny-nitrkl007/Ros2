/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Initializer Factory

#pragma once

#include <functional>
#include <vector>

namespace Shark
{
class DependencyContainer;

class InitializerFactory
{
public:
	InitializerFactory(DependencyContainer const& dependencyContainer);
	std::vector<std::function<void()>> CreateInitializers();
private:
	DependencyContainer const& m_dependencyContainer;
};
}
