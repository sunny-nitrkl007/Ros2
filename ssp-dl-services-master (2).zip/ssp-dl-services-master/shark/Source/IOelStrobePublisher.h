/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// OEL Strobe Publisher Interface

#pragma once

namespace Shark
{
class IOelStrobePublisher
{
public:
	virtual ~IOelStrobePublisher() = default;
	virtual void Strobe() = 0;
};
}
