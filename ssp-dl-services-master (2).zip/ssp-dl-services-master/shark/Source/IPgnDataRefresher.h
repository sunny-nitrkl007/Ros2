/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pgn Data Refresher Interface

#pragma once

namespace Shark
{
class IPgnDataRefresher
{
public:
	virtual ~IPgnDataRefresher() = default;

	virtual void Refresh(unsigned refresherContext) = 0;
};
}
