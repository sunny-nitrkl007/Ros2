/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// OEL Wrapper Interface

#pragma once

namespace Shark
{
class IOelWrapper
{
public:
	virtual ~IOelWrapper() = default;

	virtual void Initialize() = 0;
	virtual void StopAllTasks() = 0;
};
}
