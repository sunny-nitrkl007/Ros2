/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Fault Algorithm interface

#pragma once

#include <stdint.h>

namespace Shark
{
class IFaultAlgorithm
{
public:
	virtual ~IFaultAlgorithm() = default;

	virtual bool IsValid(uint32_t byteValue) = 0;
};
}