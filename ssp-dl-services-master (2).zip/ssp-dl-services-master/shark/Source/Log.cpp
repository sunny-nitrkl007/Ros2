/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// See Log.h

#include "Log.h"
#include "Utilities/narrow_cast.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <iomanip>

namespace Log
{
namespace
{
std::ostream& OutputTag(std::ostream& stream, SharkTag tag, std::vector<char const*> const& tagStrings)
{
	if (tag != Log::None)
	{
		stream << "[";
		auto needsComma = false;
		auto const one = typename std::underlying_type<SharkTag>::type{1};
		for (size_t index = 0; index < tagStrings.size(); ++index)
		{
			if ((one << index) & tag)
			{
				if (needsComma)
				{
					stream << ",";
				}

				stream << tagStrings[index];
				needsComma = true;
			}
		}
		stream << "] ";
	}

	return stream;
}
}

std::ostream& operator<<(std::ostream& stream, SharkTag tag)
{
	static auto const s_tagStrings = std::vector<char const*>
	{
		// Do not include "None" since it is never displayed.
		"Shark Init",
		"SharkByte",
		"Pgb",
		"Pgn",
		"Rw",
		"Diagnostics",
		"ExtId",
		"EventCallback",
		"Nvm",
		"Mss",
		"Performance",
		"Bdt",
		"Adt",
		"Calibrations"
	};
	assert( (Utilities::narrow_cast<size_t>(std::log2(static_cast<double>(Log::MaxTagPlusOne - 1))) + 1) == s_tagStrings.size() );

	return OutputTag(stream, tag, s_tagStrings);
}
}
