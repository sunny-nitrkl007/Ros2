/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Dispatches work to be performed on a different thread.

#pragma once

#include <functional>

namespace Shark
{
class IAsynchronousDispatcher
{
public:
	using Work = std::function<void()>;

	virtual ~IAsynchronousDispatcher() = default;

	/// Returns immediately. Performs the work in the order it was received.
	virtual void Dispatch(Work const& work) = 0;
};
}
