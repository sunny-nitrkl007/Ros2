/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pid Data Refresher Interface

#include <functional>

#pragma once

namespace Shark
{
class IPidDataRefresher
{
public:
	using MessageSentCallback = std::function<void()>;
	virtual ~IPidDataRefresher() = default;

	virtual void Refresh(unsigned address, unsigned pid, MessageSentCallback&& messageSent) = 0;
};
}
