/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Extension Id Data Receiver Interface

#pragma once

#include "Config/CanPort.h"
#include "Config/J1939Address.h"
#include "Config/ExtensionId.h"
#include <cstdint>

namespace Shark
{

class IExtensionIdDataReceiver
{
public:
	virtual ~IExtensionIdDataReceiver() = default;

	/// Called when extension id data has been received
	/// \param pData If acknowledge message is received then it must be set to nullptr.
	virtual void ReceiveExtensionIdData(
		Config::CanPort canPort,
		Config::J1939Address address,
		Config::ExtensionId extensionId,
		uint8_t const* pData,
		unsigned dataLength) = 0;
};

}
