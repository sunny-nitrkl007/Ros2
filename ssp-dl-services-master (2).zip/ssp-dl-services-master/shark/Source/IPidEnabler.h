/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Pid Enabler Interface

#pragma once

#include "Config/Fid.h"
#include "Config/J1939Address.h"
#include "Config/Pid.h"

namespace Shark
{
class IPidEnabler
{
public:
	virtual ~IPidEnabler() = default;

	virtual bool IsJ1939PidEnabled(Config::J1939Address address, Config::Pid pid) const = 0;
	virtual bool IsEthernetPidEnabled(Config::Fid fid, Config::Pid pid) const= 0;
};
}
