/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Dependency Container. Note that it does not own any of the objects.

#pragma once

#include "Config/CanPort.h"
#include "Utilities/nice_ptr.h"
#include "Utilities/OptionalSmartPointers.h"
#include <array>
#include <vector>

namespace cat::shark
{
	class Config;
	class J1939DataLink;
}

namespace Utilities
{
	class IEnvironment;
	class IFilesystem;
}

namespace Shark
{
class IAsynchronousDispatcher;
class IExtensionIdDataReceiver;
class IPidDataReceiver;
class ISclEncryptFeatureRegistrar;

namespace Ethernet { class IEthernetHealthWrapper; }

namespace J1939
{
class IJ1939HealthWrapper;
class IJ1939PublicDataReceiver;
class IJ1939Wrapper;
class ITransportProtocolClientSynchronizer;
}

namespace Nvm
{
class INvmBlockDefinitions;
class ISclNvmWrapper;
}

namespace SharkBytes
{
class ISharkByteManager;
class ISlotManager;
class IWriteSharkByteManager;
}

namespace SharkUtilities
{
class IEventCallbackFactory;
}

class IClockWrapper;
class IPeriodicTaskManager;
class ISharkByteRetriever;
class IWorkQueue;
class IWriteSharkByteRetriever;

using J1939DataLinkConfigs = std::vector<Utilities::nice_ptr<cat::shark::J1939DataLink const>>;

class DependencyContainer
{
public:
	DependencyContainer(
		cat::shark::Config const& sharkConfig,
		J1939DataLinkConfigs&& j1939DataLinks,
		Utilities::IEnvironment const& environment,
		Utilities::IFilesystem const& filesystem,
		IPidDataReceiver& pidDataReceiver,
		IPeriodicTaskManager& periodicTaskManager,
		SharkBytes::ISharkByteManager& sharkByteManager,
		ISharkByteRetriever const& sharkByteRetriever,
		SharkBytes::IWriteSharkByteManager& writeSharkByteManager,
		IWriteSharkByteRetriever const& writeSharkByteRetriever,
		SharkBytes::ISlotManager& slotManager,
		SharkUtilities::IEventCallbackFactory& eventCallbackFactory,
		Nvm::INvmBlockDefinitions& nvmBlockDefinitions,
		Nvm::ISclNvmWrapper& sclNvmWrapper,
		ISclEncryptFeatureRegistrar& sclEncryptFeatureRegistrar,
		J1939::IJ1939PublicDataReceiver& publicDataReceiver,
		J1939::ITransportProtocolClientSynchronizer& transportProtocolClientSynchronizer,
		IExtensionIdDataReceiver& extensionIdDataReceiver,
		IAsynchronousDispatcher& asynchronousDispatcher);
	~DependencyContainer();

	cat::shark::Config const& GetSharkConfig() const { return m_sharkConfig; }
	J1939DataLinkConfigs const& GetJ1939DataLinkConfigs() const { return m_j1939DataLinks; }
	Utilities::IEnvironment const& GetIEnvironment() const { return m_environment; }
	Utilities::IFilesystem const& GetIFilesystem() const { return m_filesystem; }
	IPidDataReceiver& GetIPidDataReceiver() const { return m_pidDataReceiver; }
	IPeriodicTaskManager& GetIPeriodicTaskManager() const { return m_periodicTaskManager; }
	SharkBytes::ISharkByteManager& GetISharkByteManager() const { return m_sharkByteManager; }
	ISharkByteRetriever const& GetISharkByteRetriever() const { return m_sharkByteRetriever; }
	SharkBytes::IWriteSharkByteManager& GetIWriteSharkByteManager() const { return m_writeSharkByteManager; }
	IWriteSharkByteRetriever const& GetIWriteSharkByteRetriever() const { return m_writeSharkByteRetriever; }
	SharkBytes::ISlotManager& GetISlotManager() const { return m_slotManager; }
	SharkUtilities::IEventCallbackFactory& GetIEventCallbackFactory() const { return m_eventCallbackFactory; }
	Nvm::INvmBlockDefinitions& GetNvmBlockDefinitions() const { return m_nvmBlockDefinitions; }
	Nvm::ISclNvmWrapper& GetISclNvmWrapper() const { return m_sclNvmWrapper; }
	ISclEncryptFeatureRegistrar& GetISclEncryptFeatureRegistrar() const { return m_sclEncryptFeatureRegistrar; };
	J1939::IJ1939PublicDataReceiver& GetPublicDataReceiver() const { return m_publicDataReceiver; };
	J1939::ITransportProtocolClientSynchronizer& GetTransportProtocolClientSynchronizer() const { return m_transportProtocolClientSynchronizer; };
	IExtensionIdDataReceiver& GetExtensionIdDataReceiver() const { return m_extensionIdDataReceiver; };
	IAsynchronousDispatcher& GetIAsynchronousDispatcher() const { return m_asynchronousDispatcher; }
	// Dependencies that get set after construction
	J1939::IJ1939Wrapper& GetIJ1939Wrapper(Config::CanPort canPort) const;
	IWorkQueue& GetJ1939TaskWorkQueue(Config::CanPort canPort) const;
	IClockWrapper& GetIClockWrapper() const { return *m_spClockWrapper; }

	// Exists only to allow protocols that do not yet support multiple CAN ports
	// to access the IJ1939Wrapper of the *first* J1939DataLinkConfig. Once all
	// protocols support multiple CAN ports, this method should be removed.
	J1939::IJ1939Wrapper& GetIJ1939Wrapper() const;

	// Getters that get optional components
	Utilities::optional_nice_ptr<J1939::IJ1939HealthWrapper> GetIJ1939HealthWrapper() const { return m_spJ1939HealthWrapper; }
	Utilities::optional_nice_ptr<Ethernet::IEthernetHealthWrapper> GetIEthernetHealthWrapper() const
	{
		return m_spEthernetHealthWrapper;
	}

	// Setters
	void Set(Config::CanPort canPort, J1939::IJ1939Wrapper& j1939Wrapper, IWorkQueue& j1939TaskWorkQueue);
	void Set(IClockWrapper& clockWrapper) { m_spClockWrapper = &clockWrapper; }
	void Set(J1939::IJ1939HealthWrapper& j1939HealthWrapper) { m_spJ1939HealthWrapper = &j1939HealthWrapper; }
	void Set(Ethernet::IEthernetHealthWrapper& ethernetHealthWrapper) { m_spEthernetHealthWrapper = &ethernetHealthWrapper; }
private:
	struct J1939WrapperObjects
	{
		Utilities::nice_ptr<J1939::IJ1939Wrapper> j1939Wrapper;
		Utilities::nice_ptr<IWorkQueue> j1939TaskWorkQueue;
	};

	cat::shark::Config const& m_sharkConfig;
	J1939DataLinkConfigs const m_j1939DataLinks;
	Utilities::IEnvironment const& m_environment;
	Utilities::IFilesystem const& m_filesystem;
	IPidDataReceiver& m_pidDataReceiver;
	IPeriodicTaskManager& m_periodicTaskManager;
	SharkBytes::ISharkByteManager& m_sharkByteManager;
	ISharkByteRetriever const& m_sharkByteRetriever;
	SharkBytes::IWriteSharkByteManager& m_writeSharkByteManager;
	IWriteSharkByteRetriever const& m_writeSharkByteRetriever;
	SharkBytes::ISlotManager& m_slotManager;
	SharkUtilities::IEventCallbackFactory& m_eventCallbackFactory;
	Nvm::INvmBlockDefinitions& m_nvmBlockDefinitions;
	Nvm::ISclNvmWrapper& m_sclNvmWrapper;
	ISclEncryptFeatureRegistrar& m_sclEncryptFeatureRegistrar;
	J1939::IJ1939PublicDataReceiver& m_publicDataReceiver;
	J1939::ITransportProtocolClientSynchronizer& m_transportProtocolClientSynchronizer;
	IExtensionIdDataReceiver& m_extensionIdDataReceiver;
	IAsynchronousDispatcher& m_asynchronousDispatcher;

	std::array<J1939WrapperObjects, Config::CanPort::CanPortCount> m_j1939WrapperObjects{};
	Utilities::optional_nice_ptr<IClockWrapper> m_spClockWrapper{};
	Utilities::optional_nice_ptr<J1939::IJ1939HealthWrapper> m_spJ1939HealthWrapper{};
	Utilities::optional_nice_ptr<Ethernet::IEthernetHealthWrapper> m_spEthernetHealthWrapper{};
};
}
