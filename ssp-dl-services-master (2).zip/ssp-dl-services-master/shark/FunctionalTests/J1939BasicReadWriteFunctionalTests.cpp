/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Basic Write Functional Tests

#include "TestHarness.h"
#include "SimpleSharkConfigBuilder.h"
#include <Kraken/MockICdl2.h>
#include <Kraken/MockIJ1939.h>
#include <Utilities/CountOf.h>
#include <Utilities/DefaultSmartPointers.h>
#include <Utilities/OptionalSmartPointers.h>
#include <vector>

using namespace Shark::Kraken;
using namespace testing;

namespace FunctionalTests
{
namespace
{
constexpr auto n_sourceAddress = 0x42;

constexpr auto n_testFixedBytePid = 0x00FC42u;
constexpr auto n_testFixedByteWriteId = "fixed_byte_pid";
constexpr std::array<uint8_t, 4> n_testFixedByteData = {0x01, 0x02, 0x03, 0x04};
constexpr std::array<uint8_t, 7> n_expectedFixedByteMessage = {0x9E, 0xFC, 0x42, 0x01, 0x02, 0x03, 0x04};

constexpr auto n_testMultiBytePid = 0x00F815u;
constexpr auto n_testMultiByteWriteId = "multi_byte_pid";
constexpr std::array<uint8_t, 10> n_testMultiByteData = {0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39};
constexpr std::array<uint8_t, 14> n_expectedMultiByteMessage = {0x9E, 0xF8, 0x15, 0x0A, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39};

constexpr Config::BasicReadWritePidEntry n_basicReadWritePidEntries[]
{
	{ n_testFixedBytePid, n_testFixedByteWriteId },
	{ n_testMultiBytePid, n_testMultiByteWriteId }
};
}

/// Matches pid, data_size, and flags
MATCHER(PgbPidInfoEq, "")
{
	auto const& actual = std::get<0>(arg);
	auto const& expected = std::get<1>(arg);
	*result_listener << actual->pid;

	auto const matched = (actual->pid == expected.pid) &&
		(actual->data_size == expected.data_size) &&
		(actual->flags == expected.flags);
	return matched;
}

class TestBasicReadWriteHarness : public TestHarness
{
public:
	struct RxPidHandler
	{
		unsigned pid;
		cdl2_con_rx_hdlr_t* pHandler;
	};
	struct TransmittedMessage
	{
		unsigned_8 destAddress;
		std::vector<unsigned_8> messageData;
	};
	TestBasicReadWriteHarness()
	{
		ON_CALL(*m_spMockCdl2, cdl2_add_to_con_rx_pit(_, NotNull(), _))
			.WillByDefault(DoAll(
				WithArgs<0, 1>(Invoke(this, &TestBasicReadWriteHarness::AddRxPidHandler)),
				Return(CDL2_SUCCESSFUL)));
		ON_CALL(*m_spMockJ1939, scl_j1939_que_tx_msg_by_address(_, _, _, _, _, _, _))
			.WillByDefault(DoAll(
				WithArgs<3, 5, 6>(Invoke(this, &TestBasicReadWriteHarness::StoreTransmittedMessage)),
				Return(TRUE)));

		SetICdl2(m_spMockCdl2);
		SetIJ1939(m_spMockJ1939);


		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder
			.UsingJ1939DataLink(Config::CanPort::Can0)
				.UsingPeerNode(n_sourceAddress)
					.WithBasicReadWriteConfig(n_basicReadWritePidEntries);
		SetSharkConfig(configBuilder.Build());
	}

	std::vector<RxPidHandler> const& GetRxPidHandlers() const
	{
		return m_rxPidHandlers;
	}
	RxPidHandler const& GetRxPidHandlerByPid(unsigned pid) const
	{
		auto endIter = m_rxPidHandlers.end();
		auto it = std::find_if(m_rxPidHandlers.begin(), endIter,
			[pid](auto const& handler)
			{
				return handler.pid == pid;
			});
		return *it;
	}
	TransmittedMessage const& GetLastTransmittedMessage() const
	{
		return m_lastTransmittedMessage;
	}
private:
	// Save the parameters we care about.
	bool_t AddRxPidHandler(unsigned_32 new_data_ID, cdl2_con_rx_hdlr_t* new_hdlr)
	{
		m_rxPidHandlers.emplace_back(RxPidHandler{
			new_data_ID,
			new_hdlr});
		return TRUE;
	}
	void StoreTransmittedMessage(unsigned_8 const dest_address, unsigned_8 const pidByteArray[], unsigned_8 const data_length)
	{
		m_lastTransmittedMessage.destAddress = dest_address;
		m_lastTransmittedMessage.messageData.clear();
		m_lastTransmittedMessage.messageData.insert(m_lastTransmittedMessage.messageData.end(), pidByteArray, pidByteArray + data_length);
	}

	Utilities::default_shared_ptr<NiceMock<MockICdl2>> m_spMockCdl2{};
	Utilities::default_shared_ptr<NiceMock<MockIJ1939>> m_spMockJ1939{};

	std::vector<RxPidHandler> m_rxPidHandlers{};
	TransmittedMessage m_lastTransmittedMessage{};
};

class J1939BasicReadWriteFunctionalTests : public Test
{
protected:
	void ExecuteWrite(auto const& id, auto const& data)
	{
		auto testData = std::vector<uint8_t>(data.begin(), data.end());
		m_harness.WriteSharkByteValue(id, testData,
			[this](auto writtenValue)
			{
				m_writtenDataResponse = writtenValue;
				m_callbackCalled = true;
			});
	}
	void SendResponse(auto const pid, auto const& data)
	{
		auto const& pidHandler = m_harness.GetRxPidHandlerByPid(pid);
		pidHandler.pHandler(
			CDL2_CON_RX_DATA_LINK_J1939,
			0,
			CDL2_CON_RX_PID_RXED,
			nullptr,
			n_sourceAddress,
			0,
			pid,
			static_cast<unsigned_8>(data.size()),
			const_cast<unsigned_8*>(data.data()));
	}
	void SendInvalidResponse(auto const pid)
	{
		auto const& pidHandler = m_harness.GetRxPidHandlerByPid(pid);
		pidHandler.pHandler(
			CDL2_CON_RX_DATA_LINK_J1939,
			0,
			CDL2_CON_RX_PID_WR_UNSUCCESS,
			nullptr,
			n_sourceAddress,
			0,
			pid,
			0,
			nullptr);
	}
	void ExpectThatBasicReadWritePidsAreAddedToCdl2() const
	{
		auto const& handlers = m_harness.GetRxPidHandlers();
		ASSERT_THAT(
			handlers,
			SizeIs(Utilities::CountOf(n_basicReadWritePidEntries)));
		auto const& pidHandler1 = handlers[0];
		EXPECT_THAT(pidHandler1.pid, Eq(n_testFixedBytePid));
		EXPECT_THAT(pidHandler1.pHandler, NotNull());
		auto const& pidHandler2 = handlers[1];
		EXPECT_THAT(pidHandler2.pid, Eq(n_testMultiBytePid));
		EXPECT_THAT(pidHandler2.pHandler, NotNull());
	}
	void ExpectThatTransmittedMessageMatchesExpected(auto const& expectedMessage) const
	{
		auto const& transmittedMessage = m_harness.GetLastTransmittedMessage();
		EXPECT_THAT(transmittedMessage.destAddress, Eq(n_sourceAddress));
		EXPECT_THAT(transmittedMessage.messageData, ElementsAreArray(expectedMessage));
	}
	void ExpectThatReturnedValueIsInvalid() const
	{
		EXPECT_TRUE(m_callbackCalled);
		EXPECT_FALSE(m_writtenDataResponse.has_value());
	}
	void ExpectThatReturnValueContainsWrittenData(auto const& expectedData) const
	{
		EXPECT_TRUE(m_callbackCalled);
		ASSERT_TRUE(m_writtenDataResponse.has_value());
		EXPECT_THAT(m_writtenDataResponse.value(), ElementsAreArray(expectedData));
	}

	TestBasicReadWriteHarness m_harness{};
	std::optional<std::vector<uint8_t>> m_writtenDataResponse{};
	bool m_callbackCalled{false};
};
TEST_F(J1939BasicReadWriteFunctionalTests, TheBasicReadWritePidsAreAddedToCdl2)
{
	// Given: Shark is configured with Basic read write PIDs
	// When: Shark is started
	// Then: Pids registered with correct pid and handler in cdl2_con_rx_pit

	m_harness.StartShark();
	ExpectThatBasicReadWritePidsAreAddedToCdl2();
}
TEST_F(J1939BasicReadWriteFunctionalTests, BasicFixedBytePidWritesSendTheCorrectMessageDataToTheCorrectDestination)
{
	// Given: Shark is configured with Basic read write PIDs
	// And: Shark is started
	// When: A write is performed on a basic write middleware id
	// Then: Basic fixed byte pid writes send the correct message data to the correct destination

	m_harness.StartShark();
	ExecuteWrite(n_testFixedByteWriteId, n_testFixedByteData);
	ExpectThatTransmittedMessageMatchesExpected(n_expectedFixedByteMessage);

}
TEST_F(J1939BasicReadWriteFunctionalTests, BasicMultiBytePidWritesSendTheCorrectMessageDataToTheCorrectDestination)
{
	// Given: Shark is configured with Basic read write PIDs
	// And: Shark is started
	// When: A write is performed on a basic write middleware id
	// Then: Basic multi-byte pid writes send the correct message data to the correct destination

	m_harness.StartShark();
	ExecuteWrite(n_testMultiByteWriteId, n_testMultiByteData);
	ExpectThatTransmittedMessageMatchesExpected(n_expectedMultiByteMessage);

}
TEST_F(J1939BasicReadWriteFunctionalTests, IfNoResponseIsReceivedForBasicWriteRequestThenEmptyOptionalIsReturnedInCallbackAfterTimeout)
{
	// Given: Shark is configured with Basic read write PIDs
	// And: Shark is started
	// And: A write is performed on a basic write middleware id
	// When: No response is received for a basic write pid for 1.5 seconds
	// Then: The returned written value is invalid

	m_harness.StartShark();
	ExecuteWrite(n_testFixedByteWriteId, n_testFixedByteData);
	m_harness.AdvanceClockBy(std::chrono::milliseconds{1500});
	ExpectThatReturnedValueIsInvalid();
}
TEST_F(J1939BasicReadWriteFunctionalTests, ValidResponsesToFixedBytePidBasicWriteRequestsWillReturnTheDataInTheCallback)
{
	// Given: Shark is configured with Basic read write PIDs
	// And: Shark is started
	// And: A write is performed on a fixed byte pid basic write middleware id
	// When: Valid response is received for a basic write pid
	// Then: The corresponding SharkByte value contains the response data

	m_harness.StartShark();
	ExecuteWrite(n_testFixedByteWriteId, n_testFixedByteData);
	SendResponse(n_testFixedBytePid, n_testFixedByteData);
	ExpectThatReturnValueContainsWrittenData(n_testFixedByteData);
}
TEST_F(J1939BasicReadWriteFunctionalTests, ValidResponsesToMultiBytePidBasicWriteRequestsWillReturnTheDataInTheCallback)
{
	// Given: Shark is configured with Basic read write PIDs
	// And: Shark is started
	// And: A write is performed on a multi-byte pid basic write middleware id
	// When: Valid response is received for a basic write pid
	// Then: The corresponding SharkByte value contains the response data

	m_harness.StartShark();
	ExecuteWrite(n_testMultiByteWriteId, n_testMultiByteData);
	SendResponse(n_testMultiBytePid, n_testMultiByteData);
	ExpectThatReturnValueContainsWrittenData(n_testMultiByteData);
}
TEST_F(J1939BasicReadWriteFunctionalTests, InvalidResponsesToBasicWriteRequestsWillResultInTheSharkByteValueBeingInvalid)
{
	// Given: Shark is configured with Basic read write PIDs
	// And: Shark is started
	// And: A write is performed on a basic write middleware id
	// When: Invalid response is received for a basic write pid
	// Then: The corresponding SharkByte value is invalid

	m_harness.StartShark();
	ExecuteWrite(n_testFixedByteWriteId, n_testFixedByteData);
	SendInvalidResponse(n_testFixedBytePid);
	ExpectThatReturnedValueIsInvalid();
}
}
