/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Extension ID Read (Rx) Functional Tests

#include "SimpleSharkConfigBuilder.h"
#include "TestHarness.h"
#include <Kraken/MockIJ1939.h>
#include <Kraken/MockIJ1939MemoryBuffers.h>
#include <Utilities/DefaultSmartPointers.h>
#include <Utilities/narrow_cast.h>
#include <vector>
#include <chrono>

using namespace Shark::Kraken;
using namespace testing;

namespace FunctionalTests
{
namespace
{
using namespace std::chrono_literals;

struct Default
{
	static constexpr scl_j1939_mbuf_hdr_t* Mbuf() { return reinterpret_cast<scl_j1939_mbuf_hdr_t*>(0x1234); }
	static std::vector<uint8_t> Payload() { return {0x41, 0x42, 0x43}; }
};

constexpr auto const n_propAPgn          = 0xEF00;
constexpr auto const n_acknowledgeResponseId = 0xF004;

constexpr Config::DeviceIdEntry n_deviceIdEntry
{
	0x1234,
	0x9876,
	0x5678,
	1,
	std::nullopt
};

constexpr unsigned n_peerAddress                       = 0x00;
constexpr auto n_middlewareIdF019                      = "ExtId_00_F019";
constexpr auto n_middlewareIdF01A                      = "ExtId_00_F01A";
constexpr unsigned n_nackRetryLaterCode                = 0x0005;
constexpr unsigned n_nackOtherErrorCode                = 0x0003;
constexpr unsigned n_commandOnlyCatId                  = 0;    // SCL cat_id for command-only (no extension id) handlers
constexpr auto n_synchronizerRetryTimeout              = 250ms;

constexpr Config::ExtensionIdReadEntry n_extensionIdReadEntries[]
{
	{ 0xF019, n_middlewareIdF019 },
	{ 0xF01A, n_middlewareIdF01A },
};

std::vector<uint8_t> BuildBigEndianBytes(unsigned value, std::vector<uint8_t> const& tail = {})
{
	std::vector<uint8_t> bytes{
		static_cast<uint8_t>(value >> 8),
		static_cast<uint8_t>(value),
	};
	bytes.insert(bytes.end(), tail.begin(), tail.end());
	return bytes;
}
}

class TestExtensionIdReadHarness : public TestHarness
{
public:
	struct ExtIdHandler
	{
		scl_j1939_link_t link;
		SCL_J1939_CAT_PPGN_ID_HDLR_t const* pHandler;
	};
	struct TxMessage
	{
		scl_j1939_link_t        link;
		unsigned_32             pgn;
		unsigned_8              destinationAddress;
		std::vector<unsigned_8> data;
	};

	TestExtensionIdReadHarness()
	{
		ON_CALL(*m_spMockJ1939, scl_j1939_establish_link(_, _, _, _, _, _, _, _, _))
			.WillByDefault(InvokeWithoutArgs(this, &TestExtensionIdReadHarness::GetNextLink));
		ON_CALL(*m_spMockJ1939, scl_j1939_cat_ppgn_id_install_command_id(_, _))
			.WillByDefault(DoAll(
				WithArgs<0, 1>(Invoke(this, &TestExtensionIdReadHarness::AddCommandIdHandler)),
				Return(TRUE)));
		// Also capture command-only handlers (used for ECM read responses, where
		// the extensionId itself serves as the 2-byte SCL command).
		ON_CALL(*m_spMockJ1939, scl_j1939_cat_ppgn_id_install_command(_, _))
			.WillByDefault(DoAll(
				WithArgs<0, 1>(Invoke(this, &TestExtensionIdReadHarness::AddCommandIdHandler)),
				Return(TRUE)));
		ON_CALL(*m_spMockJ1939, scl_j1939_que_tx_msg_by_address(_, _, _, _, _, _, _))
			.WillByDefault(DoAll(
				WithArgs<0, 1, 3, 5, 6>(Invoke(this, &TestExtensionIdReadHarness::QueueTxMessage)),
				Return(TRUE)));
		SetIJ1939(m_spMockJ1939);

		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_mbuf_len(_))
			.WillByDefault(Return(0));
		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_data_from_mbuf(_, _, _, _))
			.WillByDefault(Return(TRUE));
		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_mbuf_sa(_))
			.WillByDefault(Return(static_cast<unsigned_8>(n_peerAddress)));
		SetIJ1939MemoryBuffers(m_spMockJ1939MemoryBuffers);

		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder.WithDeviceId(n_deviceIdEntry);
		configBuilder
			.UsingJ1939DataLink(Config::CanPort::Can0)
				.UsingPeerNode(n_peerAddress)
					.WithExtensionIdConfig(n_extensionIdReadEntries);
		SetSharkConfig(configBuilder.Build());
	}
	void SimulateReadResponse(unsigned extensionId, std::vector<uint8_t> const& responsePayload)
	{
		// ECM read responses arrive as [ExtId MSB][ExtId LSB][payload...].
		// The 2-byte ExtId is the SCL command (registered via install_command with cat_id=0).
		auto const fullMessage = BuildBigEndianBytes(extensionId, responsePayload);
		InvokeHandlerWithMessage(extensionId, n_commandOnlyCatId, n_peerAddress, fullMessage);
	}
	void SimulateNack(unsigned extensionId, unsigned errorCode)
	{
		// NACK message: 4-byte header (zeroed) followed by 2-byte error code
		std::vector<uint8_t> nackMessage(4, 0);
		auto const errorCodeBytes = BuildBigEndianBytes(errorCode);
		nackMessage.insert(nackMessage.end(), errorCodeBytes.begin(), errorCodeBytes.end());

		InvokeHandlerWithMessage(n_acknowledgeResponseId, extensionId, n_peerAddress, nackMessage);
	}
	std::vector<TxMessage> const& GetTxMessages() const
	{
		return m_txMessages;
	}
	void ClearTxMessages()
	{
		m_txMessages.clear();
	}
	void TriggerSynchronizerSend()
	{
		GetFakeOel().ExecuteAllTasks();
	}

private:
	void InvokeHandlerWithMessage(
		unsigned command,
		unsigned extensionId,
		unsigned sourceAddress,
		std::vector<uint8_t> const& message)
	{
		auto const link = GetLink(0);
		auto const itFound = std::ranges::find_if(
			m_commandIdHandlers,
			[link, command, extensionId](auto const& extIdHandler)
			{
				return extIdHandler.link == link &&
				       extIdHandler.pHandler->command == command &&
				       extIdHandler.pHandler->cat_id == extensionId;
			});
		ASSERT_THAT(itFound, Ne(m_commandIdHandlers.end()))
			<< "Could not find handler for command: 0x" << std::hex << command
			<< " extensionId: 0x" << extensionId;

		// Configure mocks for this specific response
		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_mbuf_sa(Default::Mbuf()))
			.WillByDefault(Return(Utilities::narrow_cast<unsigned_8>(sourceAddress)));
		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_mbuf_len(Default::Mbuf()))
			.WillByDefault(Return(Utilities::narrow_cast<unsigned_16>(message.size())));
		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_data_from_mbuf(Default::Mbuf(), NotNull(), _, _))
			.WillByDefault(DoAll(
				WithArgs<1>(Invoke(
					[message](unsigned_8* pDest) { std::copy(message.begin(), message.end(), pDest); })),
				Return(TRUE)));

		itFound->pHandler->context_parse_f(Default::Mbuf(), itFound->pHandler->context);
	}
	scl_j1939_link_t GetNextLink()
	{
		return m_nextLink++;
	}
	scl_j1939_link_t GetLink(unsigned index) const
	{
		return Utilities::narrow_cast<scl_j1939_link_t>(index);
	}
	void AddCommandIdHandler(scl_j1939_link_t link, SCL_J1939_CAT_PPGN_ID_HDLR_t const* pHandler)
	{
		m_commandIdHandlers.emplace_back(ExtIdHandler{link, pHandler});
	}
	void QueueTxMessage(
		scl_j1939_link_t  link,
		unsigned_32       pgn,
		unsigned_8        destinationAddress,
		unsigned_8 const* pData,
		unsigned_16       dataLength)
	{
		TxMessage txMessage{
			link,
			pgn,
			destinationAddress,
			{pData, pData + dataLength}
		};
		m_txMessages.push_back(txMessage);
	}

	Utilities::default_shared_ptr<NiceMock<MockIJ1939>> m_spMockJ1939{};
	Utilities::default_shared_ptr<NiceMock<MockIJ1939MemoryBuffers>> m_spMockJ1939MemoryBuffers{};

	scl_j1939_link_t m_nextLink{};
	std::vector<ExtIdHandler> m_commandIdHandlers{};
	std::vector<TxMessage> m_txMessages{};
};

class J1939ExtensionIdReadFunctionalTests : public Test
{
protected:
	TestExtensionIdReadHarness m_harness{};
};
TEST_F(J1939ExtensionIdReadFunctionalTests, RefreshSendsReadRequestWithCorrectMessage)
{
	// Given: Shark is configured with ExtensionId read for F019
	// And: Shark is started
	// When: The ExtensionId SharkByte is refreshed
	// Then: A PropA read request message [0x80, 0xF0, 0x19] is sent to the peer address

	m_harness.StartShark();

	m_harness.RefreshSharkByte(n_middlewareIdF019);
	m_harness.TriggerSynchronizerSend();

	auto const& txMessages = m_harness.GetTxMessages();
	ASSERT_THAT(txMessages, SizeIs(1));
	auto const& txMessage = txMessages[0];
	EXPECT_THAT(txMessage.pgn, Eq(n_propAPgn));
	EXPECT_THAT(txMessage.destinationAddress, Eq(n_peerAddress));

	std::vector<uint8_t> const expectedMessage{0x80, 0xF0, 0x19};
	EXPECT_THAT(txMessage.data, ElementsAreArray(expectedMessage));
}
TEST_F(J1939ExtensionIdReadFunctionalTests, RefreshF01ASendsReadRequestWithCorrectExtensionId)
{
	// Given: Shark is configured with ExtensionId read for F01A
	// And: Shark is started
	// When: The ExtensionId F01A SharkByte is refreshed
	// Then: A PropA read request message [0x80, 0xF0, 0x1A] is sent

	m_harness.StartShark();

	m_harness.RefreshSharkByte(n_middlewareIdF01A);
	m_harness.TriggerSynchronizerSend();

	auto const& txMessages = m_harness.GetTxMessages();
	ASSERT_THAT(txMessages, SizeIs(1));

	std::vector<uint8_t> const expectedMessage{0x80, 0xF0, 0x1A};
	EXPECT_THAT(txMessages[0].data, ElementsAreArray(expectedMessage));
}
TEST_F(J1939ExtensionIdReadFunctionalTests, SuccessfulResponsePopulatesSharkByteWithPayloadBytes)
{
	// Given: Shark is configured with ExtensionId read for F019
	// And: Shark is started
	// And: The SharkByte is refreshed and the request is sent
	// When: A successful read response is received with payload [0x41, 0x42, 0x43]
	// Then: The SharkByte value contains the raw payload bytes

	m_harness.StartShark();

	auto& callback = m_harness.SubscribeToSharkByte(n_middlewareIdF019);

	m_harness.RefreshSharkByte(n_middlewareIdF019);
	m_harness.TriggerSynchronizerSend();

	Shark::SharkByteValue capturedValue{};
	EXPECT_CALL(callback, Call(_))
		.WillOnce(SaveArg<0>(&capturedValue));

	m_harness.SimulateReadResponse(0xF019, Default::Payload());

	EXPECT_THAT(capturedValue, Optional(ContainerEq(Default::Payload())));
}
TEST_F(J1939ExtensionIdReadFunctionalTests, Nack0x0005RetriesIndefinitely)
{
	// Given: Shark is configured with ExtensionId read for F019
	// And: Shark is started
	// And: The SharkByte is refreshed and the request is sent
	// When: A NACK with error 0x0005 is received
	// Then: The request is retried (another send occurs after re-queuing)

	m_harness.StartShark();

	m_harness.RefreshSharkByte(n_middlewareIdF019);
	m_harness.TriggerSynchronizerSend();
	m_harness.ClearTxMessages();

	// Simulate NACK 0x0005 - should trigger RetryLaterIfCurrent
	m_harness.SimulateNack(0xF019, n_nackRetryLaterCode);

	// The request should be re-queued; advancing the clock should produce another send
	m_harness.TriggerSynchronizerSend();

	auto const& txMessages = m_harness.GetTxMessages();
	ASSERT_THAT(txMessages, SizeIs(1));

	std::vector<uint8_t> const expectedMessage{0x80, 0xF0, 0x19};
	EXPECT_THAT(txMessages[0].data, ElementsAreArray(expectedMessage));
}
TEST_F(J1939ExtensionIdReadFunctionalTests, NackOtherErrorInvalidatesSharkByte)
{
	// Given: Shark is configured with ExtensionId read for F019
	// And: Shark is started
	// And: The SharkByte is refreshed and the request is sent
	// When: A NACK with a non-0x0005 error is received
	// Then: The SharkByte is invalidated (value is nullopt)

	m_harness.StartShark();

	auto& callback = m_harness.SubscribeToSharkByte(n_middlewareIdF019);

	m_harness.RefreshSharkByte(n_middlewareIdF019);
	m_harness.TriggerSynchronizerSend();

	Shark::SharkByteValue capturedValue{std::vector<uint8_t>{0xFF}};
	EXPECT_CALL(callback, Call(_))
		.WillOnce(SaveArg<0>(&capturedValue));

	m_harness.SimulateNack(0xF019, n_nackOtherErrorCode);

	EXPECT_THAT(capturedValue, Eq(std::nullopt));
}
TEST_F(J1939ExtensionIdReadFunctionalTests, NoResponseRetriesUpTo4TimesViaSynchronizer)
{
	// Given: Shark is configured with ExtensionId read for F019
	// And: Shark is started
	// And: The SharkByte is refreshed
	// When: No response is received within the retry window
	// Then: The synchronizer sends the request up to 4 times total

	m_harness.StartShark();

	m_harness.RefreshSharkByte(n_middlewareIdF019);

	// The synchronizer sends once immediately, then retries every 250ms up to 4 times total
	unsigned sendCount{0};
	for (unsigned i = 0; i < 4; ++i)
	{
		m_harness.ClearTxMessages();
		m_harness.AdvanceClockBy(n_synchronizerRetryTimeout);
		m_harness.GetFakeOel().ExecuteAllTasks();

		auto const& txMessages = m_harness.GetTxMessages();
		if (!txMessages.empty())
		{
			++sendCount;
		}
	}

	EXPECT_THAT(sendCount, Eq(4u));

	// After exhausting retries, no more sends should occur
	m_harness.ClearTxMessages();
	m_harness.AdvanceClockBy(n_synchronizerRetryTimeout);
	m_harness.GetFakeOel().ExecuteAllTasks();
	auto const& finalMessages = m_harness.GetTxMessages();
	EXPECT_THAT(finalMessages, IsEmpty());
}
}
