/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Diagnostic Codes Functional Tests

#include "Kraken/MockIJ1939.h"
#include "Kraken/MockISclInfoDcm.h"
#include "SimpleSharkConfigBuilder.h"
#include "TestHarness.h"
#include <Config/ProtobufConversions.h>
#include <SharkConfiguration.pb.h>
#include <Utilities/DefaultSmartPointers.h>
#include <Utilities/TestUtilities.h>
#include <middleware_diagnostics.pb.h>
#include <vector>


using namespace Shark::Kraken;
using namespace testing;
using namespace cat::shark;

namespace FunctionalTests
{
namespace
{
struct Default
{
	static constexpr scl_dcm_link_id_t DcmLinkIndex() { return 33; }
	static constexpr uint8_t SourceAddress() { return 0x21; }
	static constexpr uint8_t OtherSourceAddress() { return 0x22; }
	static constexpr uint8_t OwnSourceAddress() { return 0x42; }
	static constexpr scl_dcm_peer_id_t PeerId() { return 3; }
	static constexpr scl_dcm_peer_id_t OtherPeerId() { return 5; }
	static constexpr scl_dcm_peer_id_t OwnPeerId() { return 76; }
	static constexpr ::Config::CanPort CanPort() { return ::Config::CanPort::Can0; }
	static constexpr ::Config::CanPort OtherCanPort() { return ::Config::CanPort::Can3; }
};
constexpr ::Config::DiagnosticPeerEntry n_defaultPeers0[]{
	{ Default::SourceAddress(), ::Config::DiagnosticType::Eddt }};
constexpr ::Config::DiagnosticPeerEntry n_defaultPeers1[]{
	{ Default::OtherSourceAddress(), ::Config::DiagnosticType::Eddt }};
constexpr ::Config::DiagnosticClientCanPort n_defaultClientCanPort[]
{
	{Default::CanPort(), { n_defaultPeers0 } },
	{Default::OtherCanPort(), { n_defaultPeers1 } },
};
constexpr ::Config::DiagnosticsEntry n_defaultDiagnosticsEntry{
	{ n_defaultClientCanPort }};
}

class TestDiagnosticCodesHarness : public TestHarness
{
public:
	struct DcmPeerConfig
	{
		uint_least8_t sourceAddress;
		std::vector<scl_dcm_svc_types_t> serviceTypes;
	};

	TestDiagnosticCodesHarness()
	{
		SetIJ1939(m_spMockJ1939);

		ON_CALL(*m_spMockSclInfoDcm, scl_dcm_init(_))
			.WillByDefault(DoAll(
				SaveArgPointee<0>(&m_dcmConfig),
				Return(SCL_DCM_SUCCESS)));
		ON_CALL(*m_spMockSclInfoDcm, scl_dcm_add_j1939_link(_, _, _))
			.WillByDefault(DoAll(SetArgPointee<2>(Default::DcmLinkIndex()), Return(SCL_DCM_SUCCESS)));
		ON_CALL(*m_spMockSclInfoDcm, scl_dcm_register_peer(_, _, _))
			.WillByDefault(WithArgs<1, 2>(Invoke(this, &TestDiagnosticCodesHarness::RegisterPeer)));
		ON_CALL(*m_spMockSclInfoDcm, scl_dcm_register_own_peer(_, _, _, _, _, _))
			.WillByDefault(WithArgs<1, 5>(Invoke(this, &TestDiagnosticCodesHarness::RegisterOwnPeer)));
		ON_CALL(*m_spMockSclInfoDcm, scl_dcm_get_peer_address(_, _))
			.WillByDefault(Invoke(this, &TestDiagnosticCodesHarness::GetPeerAddress));
		ON_CALL(*m_spMockSclInfoDcm, scl_dcm_get_link_index(_, _))
			.WillByDefault(Invoke(
				[]([[maybe_unused]] scl_dcm_peer_id_t peerId, scl_dcm_link_id_t* linkIndex) noexcept
				{
					*linkIndex = Default::DcmLinkIndex();
					return SCL_DCM_SUCCESS;
				}));
		SetISclInfoDcm(m_spMockSclInfoDcm);

		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder
			.WithDiagnostics(n_defaultDiagnosticsEntry)
			.UsingJ1939DataLink(Default::CanPort())
				.UsingPeerNode(Default::SourceAddress());
		configBuilder
			.UsingJ1939DataLink(Default::OtherCanPort())
				.UsingPeerNode(Default::OtherSourceAddress());
		SetSharkConfig(configBuilder.Build());
	}
	std::vector<DcmPeerConfig> const& GetPeerConfigs() const
	{
		return m_dcmPeerConfigs;
	}
	void InjectDiagnosticCodes(std::vector<scl_dcm_db_fault_s> const& codes)
	{
		scl_dcm_tbl_code_type_t codeType{};
		if (!codes.empty())
		{
			// We only support diagnostic codes in these tests for now
			assert(std::all_of(std::begin(codes), std::end(codes),
				[](auto&& code){ return code.code_type == SCL_DCM_DIAG_CODE; }));
		}

		ON_CALL(*m_spMockSclInfoDcm, scl_dcm_peer_get_num_codes(_, codeType, _))
			.WillByDefault(DoAll(
				SetArgPointee<2>(codes.size()),
				Return(SCL_DCM_SUCCESS)));
		ON_CALL(*m_spMockSclInfoDcm, scl_dcm_read_diag_codes(_, _, _, _))
			.WillByDefault(DoAll(
				SetArrayArgument<1>(codes.data(), codes.data() + codes.size()),
				SetArgPointee<3>(codes.size()),
				Return(SCL_DCM_SUCCESS)));

		m_dcmConfig.peer_update_clbk(Default::PeerId(), codeType, m_dcmConfig.peer_clbk_context_ptr);
	}
private:
	scl_dcm_error_state_t RegisterPeer(
		const scl_dcm_peer_config_t *peer_cfg,
		scl_dcm_peer_id_t *peer_id)
	{
		scl_dcm_error_state_t errorStatus = SCL_DCM_SUCCESS;
		if (peer_cfg->peer_addr == Default::SourceAddress())
		{
			*peer_id = Default::PeerId();
		}
		else if (peer_cfg->peer_addr == Default::OtherSourceAddress())
		{
			*peer_id = Default::OtherPeerId();
		}
		else
		{
			errorStatus = SCL_DCM_FAILURE;
		}
		m_dcmPeerConfigs.emplace_back(DcmPeerConfig{peer_cfg->peer_addr,
			{peer_cfg->svc_type, peer_cfg->svc_type + peer_cfg->svc_array_size}});
		return errorStatus;
	}
	scl_dcm_error_state_t RegisterOwnPeer(
		[[maybe_unused]] const scl_dcm_peer_config_t *peer_cfg,
		scl_dcm_peer_id_t *peer_id)
	{
		*peer_id = Default::OwnPeerId();
		return SCL_DCM_SUCCESS;
	}
	scl_dcm_error_state_t GetPeerAddress(
		scl_dcm_peer_id_t peer_index,
		uint_least8_t* peerAddress) noexcept
	{
		scl_dcm_error_state_t returnValue = SCL_DCM_PEER_ID_INVALID;
		if (peer_index == Default::OwnPeerId())
		{
			*peerAddress = Default::OwnSourceAddress();
			returnValue = SCL_DCM_SUCCESS;
		}
		else if (peer_index == Default::PeerId())
		{
			*peerAddress = Default::SourceAddress();
			returnValue = SCL_DCM_SUCCESS;
		}

		return returnValue;
	}

	Utilities::default_shared_ptr<NiceMock<MockIJ1939>> m_spMockJ1939{};
	Utilities::default_shared_ptr<NiceMock<MockISclInfoDcm>> m_spMockSclInfoDcm{};

	scl_dcm_config_t m_dcmConfig{};
	std::vector<DcmPeerConfig> m_dcmPeerConfigs{};
};

class DiagnosticCodesFunctionalTests : public Test
{
protected:
	void SubscribeToCodesSharkByte()
	{
		auto& codesSharkByte = m_harness.GetSharkByte("Codes");
		m_codesSubscription = codesSharkByte.SubscribeToValues(
			[this](Shark::SharkByteValue const& value)
			{
				m_receivedCodes.push_back(value);
			});
	}

	void ExpectThatDiagnosticCodesAreEnabledForConfiguredPeers()
	{
		auto const peerConfigs = m_harness.GetPeerConfigs();
		ASSERT_THAT(peerConfigs, SizeIs(Eq(2)));
		EXPECT_THAT(peerConfigs[0].sourceAddress, Eq(Default::SourceAddress()));
		EXPECT_THAT(peerConfigs[0].serviceTypes, UnorderedElementsAre(
			SCL_DCLI_SVC_TYPE_EDDT_DIAG,
			SCL_DCLI_SVC_TYPE_EDDT_EVENT,
			SCL_DCLI_SVC_TYPE_AI));
		EXPECT_THAT(peerConfigs[1].sourceAddress, Eq(Default::OtherSourceAddress()));
		EXPECT_THAT(peerConfigs[1].serviceTypes, UnorderedElementsAre(
			SCL_DCLI_SVC_TYPE_EDDT_DIAG,
			SCL_DCLI_SVC_TYPE_EDDT_EVENT,
			SCL_DCLI_SVC_TYPE_AI));
	}
	void ExpectInitialSharkByteValueIsEmpty()
	{
		ASSERT_THAT(m_receivedCodes, SizeIs(1));
		EXPECT_THAT(m_receivedCodes[0], Optional(IsEmpty()));
	}
	cat::middleware::diagnostics::Code CreateExpectedCodeProtobuf(scl_dcm_db_fault_s const& fault)
	{
		assert(fault.code_type == SCL_DCM_DIAG_CODE &&
		       fault.status == SCL_DCLI_FAULT_ACTIVE); // This is all we support for now

		cat::middleware::diagnostics::Code code{};
		auto pJ1939Address = code.mutable_network_address()->mutable_j1939_address();
		pJ1939Address->set_can_port(::Config::ToCodesProtobufCanPort(Default::CanPort()));
		pJ1939Address->set_address(m_harness.GetPeerConfigs()[0].sourceAddress);

		auto* diagnosticInfo = code.mutable_information()->mutable_diagnostic();
		diagnosticInfo->set_component_identifier(fault.code);
		diagnosticInfo->set_warning_category_indicator(fault.wci_fmi & SCL_DCM_WCI_MASK);
		diagnosticInfo->set_failure_mode_identifier(fault.wci_fmi >> SCL_DCM_FMI_SHIFT_3BITS);
		diagnosticInfo->set_status(cat::middleware::diagnostics::CodeStatus::CODE_STATUS_ACTIVE_ONLY);
		diagnosticInfo->set_annunciation_requirement(fault.annunc_value);
		return code;
	}
	void ExpectCodeWasReceived(scl_dcm_db_fault_s const& fault)
	{
		auto const& expectedCode = CreateExpectedCodeProtobuf(fault);

		ASSERT_THAT(m_receivedCodes, SizeIs(1));
		EXPECT_THAT(m_receivedCodes[0], Optional(_));

		cat::middleware::diagnostics::Codes codes{};
		codes.ParseFromArray(m_receivedCodes[0]->data(), Utilities::narrow_cast<int>(m_receivedCodes[0]->size()));
		ASSERT_THAT(codes.codes_size(), Eq(1));
		EXPECT_THAT(codes.codes(0), Utilities::ProtobufEquals(expectedCode, {"code_key"}));
	}

	TestDiagnosticCodesHarness m_harness{};
	Shark::SharkByteSubscription m_codesSubscription{};
	std::vector<Shark::SharkByteValue> m_receivedCodes{};
};
TEST_F(DiagnosticCodesFunctionalTests, DiagnosticCodesAreEnabledOnConfiguredJ1939DataLink)
{
	// Given: Shark is configured with peers supporting diagnostic codes
	// When: Shark is started
	// Then: Diagnostic codes are enabled for the configured peers

	m_harness.StartShark();
	ExpectThatDiagnosticCodesAreEnabledForConfiguredPeers();
}
TEST_F(DiagnosticCodesFunctionalTests, CodesAreProvidedOnTheSharkByte)
{
	// Given: Shark is configured with peers supporting diagnostic codes
	// And: Shark is started
	// And: Subscribed to the Codes SharkByte
	// When: Codes are injected
	// Then: The protobuf codes are accessible through the SharkByte

	static scl_dcm_db_fault_s const fault{
		.peer_id = Default::PeerId(),
		.code_type = SCL_DCM_DIAG_CODE,
		.code = 1296,
		.wci_fmi = 0x11,
		.annunc_value = 1,
		.status = SCL_DCLI_FAULT_ACTIVE,
	};

	m_harness.StartShark();

	SubscribeToCodesSharkByte();
	ExpectInitialSharkByteValueIsEmpty();
	m_receivedCodes.clear();

	m_harness.InjectDiagnosticCodes({fault});
	ExpectCodeWasReceived(fault);
}
}