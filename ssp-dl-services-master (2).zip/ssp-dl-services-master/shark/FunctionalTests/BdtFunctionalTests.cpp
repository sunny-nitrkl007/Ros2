/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Bdt Functional Tests

#include "TestHarness.h"
#include "SimpleSharkConfigBuilder.h"
#include <Kraken/MockIBdt.h>
#include <Utilities/DefaultSmartPointers.h>
#include <Utilities/OptionalSmartPointers.h>
#include <vector>

using namespace Shark::Kraken;
using namespace testing;

namespace FunctionalTests
{
namespace
{
constexpr auto n_sourceAddress = 0x42;

constexpr auto n_bdtTypeC000 = 0xC000u;
constexpr auto n_bdtIndexC000 = 0x00000001u;
constexpr auto n_testId_C000 = "C000_id";
constexpr uint8_t n_testC000BdtData[]
{
	0xB1, 0x00, 0x00, 0x01, 0xFF, 0xFF, 0xC0, 0x00, 0x01, 0x01, 0x00, 0x00, 0x00, 0x01,
	0xC0, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x01, 0x00, 0x5B, 0x01, 0x00, 0x0F, 0x00, 0x01, 0x00, 0x01,
	0x4B, 0x10, 0x00, 0x01, 0x00, 0x01, 0x00, 0x02,
	0x4C, 0x01, 0x00, 0x01, 0x03,
	0x40, 0x01, 0x03, 0xFE, 0x22, 0xFC, 0x06, 0xFC, 0xF8,
	0x40, 0x11, 0x01, 0x13, 0x24, 0x55, 0x55, 0x24, 0x58, 0x88, 0x88, 0x42, 0x00, 0x00, 0x00,
	0x40, 0x11, 0x02, 0x3D, 0x24, 0x55, 0x55, 0x4E, 0x58, 0x88, 0x88, 0x6C, 0x00, 0x00, 0x00,
	0x4C, 0x02, 0x00, 0x01, 0x02,
	0x40, 0x01, 0x02, 0xD0, 0x16, 0x4C, 0xFE, 0x23,
	0x40, 0x11, 0x01, 0x8F, 0x01, 0x8F, 0x01, 0x00, 0x00,
};

constexpr auto n_bdtTypeC820 = 0xC820u;
constexpr auto n_bdtIndexC820 = 0x00000003u;
constexpr auto n_testId_C820 = "C820_id";
constexpr std::array<uint8_t, 10> n_testMultiByteData = {0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39};
constexpr std::array<uint8_t, 14> n_expectedMultiByteMessage = {0x9E, 0xF8, 0x15, 0x0A, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39};

constexpr Config::BdtDefinitionEntry n_bdtDefinitionEntries[]
{
	{ n_bdtTypeC000, 10000 },
	{ n_bdtTypeC820, 10000 }
};
constexpr Config::BdtConfig n_bdtConfig{ n_bdtDefinitionEntries };
constexpr Config::BdtTypeEntry n_bdtTypeEntries[]
{
	{ n_bdtTypeC000, n_bdtIndexC000, Config::BdtAccessMode::ReadWrite, n_testId_C000 },
	{ n_bdtTypeC820, n_bdtIndexC820, Config::BdtAccessMode::ReadWrite, n_testId_C820 }
};
}

class TestBdtHarness : public TestHarness
{
public:
	struct RequestParameters
	{
		unsigned_8 type;
		unsigned_16 datatype;
		unsigned_32 index;
		unsigned_8 address;
	};

	TestBdtHarness()
	{
		ON_CALL(*m_spMockBdt, bdt_set_callback_block(_, _, _, _, _, _, _, _))
			.WillByDefault(Invoke(this, &TestBdtHarness::SaveCallbackBlock));
		ON_CALL(*m_spMockBdt, bdt_set_notify_conn_status_hdlr(_, _))
			.WillByDefault(DoAll(
				SaveArgPointee<1>(&m_j1939ConnectionStatusHandler),
				Return(TRUE)));
		ON_CALL(*m_spMockBdt, bdt_req_connection(_, _, _, _, _, _, _, _, _, _, _))
			.WillByDefault(DoAll(
				WithArgs<0, 2, 3, 4>(Invoke(this, &TestBdtHarness::SaveRequestParameters)),
				ReturnPointee(&m_requestConnectionResult)));

		SetIBdt(m_spMockBdt);

		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder
			.WithBdtConfig(n_bdtConfig)
			.UsingJ1939DataLink(Config::CanPort::Can0)
				.UsingPeerNode(n_sourceAddress)
					.WithBdtEntries(n_bdtTypeEntries);

		SetSharkConfig(configBuilder.Build());
	}

	void AllowTransfersToSucceed(bool succeed)
	{
		m_requestConnectionResult = succeed ? BDT_ERROR_NONE : BDT_ERROR_WRONG_SECURITY;
	}
	void HandleReceive()
	{
		HandleTransfer(true);
	}
	void HandleTransmit()
	{
		HandleTransfer(false);
	}
	std::vector<uint8_t>& Data()
	{
		return m_data;
	}
	std::optional<RequestParameters> TakeAndClearRequestParameters()
	{
		auto requestParameters = std::move(m_requestParameters);
		m_requestParameters.reset();
		return requestParameters;
	}
	void ExpectThatBdtWasRequested() const
	{
		EXPECT_TRUE(m_requestParameters.has_value());
	}

private:
	void HandleTransfer(bool isReceive)
	{
		AssertThatCallbackBlockIsSet();
		ASSERT_TRUE(m_requestParameters);

		unsigned_8 const accessmode = isReceive ? BDT_WRITE_ACCESS : BDT_READ_ACCESS;

		ASSERT_TRUE(m_callbackBlock.query_index_supported(m_requestParameters->datatype, m_requestParameters->index, accessmode));
		ASSERT_TRUE(m_callbackBlock.obtain_data_access(m_requestParameters->datatype, m_requestParameters->index, accessmode));
		ASSERT_THAT(m_callbackBlock.open_data(m_requestParameters->datatype), Eq(BDT_OPEN_SUCCESS));
		auto const requestedSize = isReceive ? 0 : static_cast<unsigned>(m_data.size());
		auto const actualSize =	m_callbackBlock.get_data_size(m_requestParameters->datatype, m_requestParameters->index, accessmode, requestedSize);

		unsigned_32 actualBytes = 0;
		if (isReceive)
		{
			ASSERT_THAT(actualSize, Ge(m_data.size()));
			auto const byteCountToTransfer = Utilities::narrow_cast<unsigned>(m_data.size());

			// Send in two chunks
			auto const firstChunkSize = byteCountToTransfer / 2;
			auto pCurrentChunk = m_data.data();
			for (auto chunkSize : { firstChunkSize, byteCountToTransfer - firstChunkSize })
			{
				ASSERT_THAT(
					m_callbackBlock.set_data(m_requestParameters->datatype, chunkSize, pCurrentChunk, &actualBytes),
					Eq(BDT_WRITE_OK));
				ASSERT_THAT(actualBytes, Eq(chunkSize));
				pCurrentChunk += chunkSize;
			}
		}
		else
		{
			m_data.resize(actualSize);
			actualBytes = actualSize;
			ASSERT_THAT(
				m_callbackBlock.get_data(m_requestParameters->datatype, actualSize, m_data.data(), &actualBytes),
				Eq(BDT_READ_OK));
			ASSERT_THAT(actualBytes, Eq(actualSize));
		}

		ASSERT_THAT(m_callbackBlock.close_data(m_requestParameters->datatype, true), Eq(BDT_CLOSE_SUCCESS));
		m_callbackBlock.release_data_access(m_requestParameters->datatype, m_requestParameters->index, accessmode);
		ASSERT_THAT(m_j1939ConnectionStatusHandler, NotNull());
		m_j1939ConnectionStatusHandler(
			nullptr,
			m_requestParameters->type,
			0, //actual callback always returns 0, so we should too
			m_requestParameters->address,
			m_requestParameters->datatype,
			m_requestParameters->index,
			BDT_STAT_SUCCESS);

		m_requestParameters.reset(); // Clear these out so future checks can work
	}

	struct CallbackBlock
	{
		bdt_query_index_supported_t* query_index_supported;
		bdt_obtain_data_access_t*    obtain_data_access;
		bdt_release_data_access_t*   release_data_access;
		bdt_get_data_size_t*         get_data_size;
		bdt_open_data_t*             open_data;
		bdt_close_data_t*            close_data;
		bdt_get_data_t*              get_data;
		bdt_set_data_t*              set_data;
	};
	unsigned_16 SaveCallbackBlock(
		bdt_query_index_supported_t bdt_query_index_supported,
		bdt_obtain_data_access_t bdt_obtain_data_access,
		bdt_release_data_access_t bdt_release_data_access,
		bdt_get_data_size_t bdt_get_data_size,
		bdt_open_data_t bdt_open_data,
		bdt_close_data_t bdt_close_data,
		bdt_get_data_t bdt_get_data,
		bdt_set_data_t bdt_set_data)
	{
		m_callbackBlock = {
			bdt_query_index_supported,
			bdt_obtain_data_access,
			bdt_release_data_access,
			bdt_get_data_size,
			bdt_open_data,
			bdt_close_data,
			bdt_get_data,
			bdt_set_data};
		return 1;
	}
	void AssertThatCallbackBlockIsSet()
	{
		ASSERT_THAT(m_callbackBlock.query_index_supported, NotNull());
		ASSERT_THAT(m_callbackBlock.obtain_data_access,    NotNull());
		ASSERT_THAT(m_callbackBlock.release_data_access,   NotNull());
		ASSERT_THAT(m_callbackBlock.get_data_size,         NotNull());
		ASSERT_THAT(m_callbackBlock.open_data,             NotNull());
		ASSERT_THAT(m_callbackBlock.close_data,            NotNull());
		ASSERT_THAT(m_callbackBlock.get_data,              NotNull());
		ASSERT_THAT(m_callbackBlock.set_data,              NotNull());
	}
	void SaveRequestParameters(
		unsigned_8 type,
		unsigned_8 address,
		unsigned_16 datatype,
		unsigned_32 index)
	{
		m_requestParameters.emplace(RequestParameters{type, datatype, index, address});
	}

	Utilities::default_shared_ptr<NiceMock<MockIBdt>> const m_spMockBdt{};
	CallbackBlock m_callbackBlock{};
	bdt_notify_conn_status_hdlr_t m_j1939ConnectionStatusHandler{};
	std::optional<RequestParameters> m_requestParameters{};
	std::vector<uint8_t> m_data{};
	bdt_error_t m_requestConnectionResult{BDT_ERROR_NONE};
};

class BdtFunctionalTests : public Test
{
protected:
	void SendRefresh()
	{
		m_harness.RefreshSharkByte(n_testId_C000);
		m_harness.GetFakeOel().ExecuteAllTasks();
	}
	void SendWrite()
	{
		m_harness.WriteSharkByteValue(
			n_testId_C000,
			{std::begin(n_testC000BdtData), std::end(n_testC000BdtData)},
			[this](auto const& writeResponse)
			{
				ASSERT_TRUE(writeResponse);
				m_writeResponse = writeResponse == Shark::TrueSharkByteValue() ? true : false;
			});
		m_harness.GetFakeOel().ExecuteAllTasks();
	}
	void SendResponse()
	{
		m_harness.Data().assign(n_testC000BdtData, n_testC000BdtData + sizeof(n_testC000BdtData));
		m_harness.HandleReceive();
	}
	void SendWriteResponse()
	{
		m_harness.HandleTransmit();
	}
	void SubscribeToBdtSharkByte()
	{
		auto& mockOnChanged = m_harness.SubscribeToSharkByte(n_testId_C000);
		ON_CALL(mockOnChanged, Call(_)).WillByDefault(SaveArg<0>(&m_lastSharkByteValue));
	}
	void ExpectThatBdtResponseDataIsValid() const
	{
		EXPECT_THAT(m_lastSharkByteValue, Ne(std::nullopt));
		EXPECT_THAT(*m_lastSharkByteValue, Optional(ElementsAreArray(n_testC000BdtData)));
	}
	void ExpectThatBdtResponseDataIsInvalid() const
	{
		EXPECT_THAT(m_lastSharkByteValue, Ne(std::nullopt));
		EXPECT_THAT(*m_lastSharkByteValue, Eq(std::nullopt));
	}
	void ExpectThatWriteSharkByteCallbackIsSuccessful(bool success) const
	{
		EXPECT_THAT(m_writeResponse, Optional(success));
	}

	std::optional<bool> m_writeResponse{};
	TestBdtHarness m_harness{};
	std::optional<Shark::SharkByteValue> m_lastSharkByteValue{}; // Note: optional inside an optional
};
TEST_F(BdtFunctionalTests, ValidDataIsAvailableWhenABdtRefreshIsSuccessful)
{
	// Given: Shark is configured with Bdt entries
	// And: Shark is started
	// And: A refresh is sent for a Bdt SharkByte
	// When: The Bdt transfer is successful
	// Then: The SharkByte calls subscriber callback with the data from the Bdt transfer

	m_harness.AllowTransfersToSucceed(true);
	m_harness.StartShark();
	SubscribeToBdtSharkByte();
	SendRefresh();
	SendResponse();
	ExpectThatBdtResponseDataIsValid();
}
TEST_F(BdtFunctionalTests, InvalidDataIsAvailableWhenABdtRefreshIsUnSuccessful)
{
	// Given: Shark is configured with Bdt entries
	// And: Shark is started
	// And: A refresh is sent for a Bdt SharkByte
	// When: The Bdt transfer is unsuccessful
	// Then: The SharkByte calls subscriber callback with invalid data

	m_harness.AllowTransfersToSucceed(false);
	m_harness.StartShark();
	SubscribeToBdtSharkByte();
	SendRefresh();
	ExpectThatBdtResponseDataIsInvalid();
}
TEST_F(BdtFunctionalTests, WhenBdtDataIsWrittenSuccessfullyASuccessfulCallbackIsReturned)
{
	// Given: Shark is configured with Bdt entries
	// And: Shark is started
	// When: A successful Bdt write occurs for a set of data
	// Then: A successful callback occurs

	m_harness.AllowTransfersToSucceed(true);
	m_harness.StartShark();
	SendWrite();
	SendWriteResponse();
	ExpectThatWriteSharkByteCallbackIsSuccessful(true);
}
TEST_F(BdtFunctionalTests, WhenBdtDataIsWrittenUnsuccessfullyAnUnsuccessfulCallbackIsReturned)
{
	// Given: Shark is configured with Bdt entries
	// And: Shark is started
	// And: An unsuccessful Bdt write occurs for a set of data
	// Then: An unsuccessful callback occurs

	m_harness.AllowTransfersToSucceed(false);
	m_harness.StartShark();
	SendWrite();
	ExpectThatWriteSharkByteCallbackIsSuccessful(false);
}
}
