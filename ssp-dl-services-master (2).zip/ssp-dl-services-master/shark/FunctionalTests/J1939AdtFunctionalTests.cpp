/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 ADT Functional Tests

#include "SimpleSharkConfigBuilder.h"
#include "TestHarness.h"
#include <Kraken/MockIJ1939Adt.h>
#include <Utilities/DefaultSmartPointers.h>
#include <vector>

using namespace Shark::Kraken;
using namespace testing;

namespace FunctionalTests
{
namespace
{
struct Any
{
	static constexpr unsigned AdtGroupIdentifier() { return 3; }
};

constexpr unsigned n_sourceAddress = 0x00;
constexpr uint_least16_t n_sclReceivedValue = 0x0000;

using namespace Config;
constexpr AdtPidEntry n_adtPidEntries_00[]
{
	{ 0x000001, "testable id" },
};
constexpr AdtEntry n_adtEntries{ std::nullopt, n_adtPidEntries_00 };

// This cannot be const because the rx_hndlr takes it as non-const.
uint_least8_t n_pidMsbData[] = {0x42};
}

class TestAdtHarness : public TestHarness
{
public:
	struct AddedAdtParameters
	{
		unsigned sourceAddress;
		scl_adt_j1939_client_grp_pid_config_t const* pPidConfig;
	};

	TestAdtHarness()
	{
		ON_CALL(*m_spMockJ1939Adt, scl_adt_j1939_link_add_ecm(_, _))
			.WillByDefault(Return(true));
		ON_CALL(*m_spMockJ1939Adt, scl_adt_j1939_link_add_group(_, _, _, _, _, _, _, _, _))
			.WillByDefault(DoAll(
				WithArgs<2, 3, 5>(Invoke(this, &TestAdtHarness::AddGroup)),
				Return(Any::AdtGroupIdentifier())));

		SetIJ1939Adt(m_spMockJ1939Adt);

		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder
			.UsingJ1939DataLink(Config::CanPort::Can0)
				.UsingPeerNode(n_sourceAddress)
					.WithAdtConfig(n_adtEntries);
		SetSharkConfig(configBuilder.Build());
	}

	std::vector<AddedAdtParameters> const& GetAddedAdtParameters() const
	{
		return m_addedAdtParameters;
	}
	void SendGoodAdtData()
	{
		auto const& addedAdtParameters = GetAddedAdtParameters();
		ASSERT_THAT(addedAdtParameters, SizeIs(Ge(1)));
		auto const& adtPidConfig = addedAdtParameters[0].pPidConfig;

		adtPidConfig->rx_hndlr(
			n_pidMsbData,
			std::size(n_pidMsbData),
			adtPidConfig->context,
			n_sclReceivedValue
		);
	}
private:
	void AddGroup(
		uint_least8_t remote_addr,
		uint_least8_t num_of_pids,
		const scl_adt_j1939_client_grp_pid_config_ptr_t* client_grp_pid_configs)
	{
		assert(num_of_pids > 0);

		for (auto pidIndex = 0u; pidIndex < num_of_pids; ++pidIndex)
		{
			m_addedAdtParameters.emplace_back(AddedAdtParameters{remote_addr, client_grp_pid_configs[pidIndex]});
		}
	}

	Utilities::default_shared_ptr<NiceMock<MockIJ1939Adt>> m_spMockJ1939Adt{};

	std::vector<AddedAdtParameters> m_addedAdtParameters{};
};

class J1939AdtFunctionalTests : public Test
{
protected:
	void ExpectThatAdtPidsAreRegistered()
	{
		auto const& addedAdtParameters = m_harness.GetAddedAdtParameters();
		ASSERT_THAT(addedAdtParameters, SizeIs(1));

		auto const& adtParameters = addedAdtParameters[0];
		EXPECT_THAT(adtParameters.sourceAddress, Eq(n_sourceAddress));

		auto const& expectedPidConfig = n_adtPidEntries_00[0];
		EXPECT_THAT(adtParameters.pPidConfig->pid, Eq(expectedPidConfig.pid));
		EXPECT_THAT(adtParameters.pPidConfig->data_size, Eq(1));
	}
	void ExpectThatSharkByteValueContainsTheData()
	{
		auto const value = m_harness.GetSharkByteValue(n_adtPidEntries_00[0].pMiddlewareId);
		ASSERT_TRUE(value);
		EXPECT_THAT(*value, ElementsAreArray(n_pidMsbData));
	}

	TestAdtHarness m_harness{};
};
TEST_F(J1939AdtFunctionalTests, TheAdtPidsAreRegistered)
{
	// Given: Shark is configured with ADT PIDs
	// When: Shark is started
	// Then: The expected ADT PID parameters are registered with correct configuration

	m_harness.StartShark();
	ExpectThatAdtPidsAreRegistered();
}
TEST_F(J1939AdtFunctionalTests, AdtDataIsProvidedThroughItsSharkByte)
{
	// Given: Shark is configured with ADT PIDs
	// And: Shark is started
	// When: ADT data is received via the rx_hndlr callback
	// Then: The data is accessible through the corresponding SharkByte

	m_harness.StartShark();
	m_harness.SendGoodAdtData();
	ExpectThatSharkByteValueContainsTheData();
}
}