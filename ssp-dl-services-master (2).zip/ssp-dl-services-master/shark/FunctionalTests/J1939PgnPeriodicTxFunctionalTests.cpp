/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 PGN Periodic TX Functional Tests

#include "Kraken/MockIJ1939.h"
#include "Kraken/MockIJ1939MemoryBuffers.h"
#include "SimpleSharkConfigBuilder.h"
#include "TestHarness.h"
#include <Utilities/DefaultSmartPointers.h>

using namespace Shark::Kraken;
using namespace testing;

namespace FunctionalTests
{
namespace
{
struct Any
{
	static constexpr unsigned Pgn() { return 0x00FEED;}
	static constexpr unsigned PgnTableIndex() { return 5; }
	static constexpr const char* PgnMiddlewareId() { return "testable id"; }
};

constexpr Config::TransmitBroadcastPgnEntry n_transmitBroadcastPgnEntries_0[]
{
	{ Any::Pgn(), 1000, {}, Any::PgnMiddlewareId() },
};

constexpr uint8_t n_defaultPgnData[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
constexpr uint8_t n_pgnData[8] = {0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0};
}

class TestPgnPeriodicTxHarness : public TestHarness
{
public:
	TestPgnPeriodicTxHarness()
	{
		ON_CALL(*m_spMockJ1939, scl_j1939_add_tx_msg_table_entry(_, _, _, _, _))
			.WillByDefault(DoAll(
				WithArgs<2, 3, 4>(Invoke(this, &TestPgnPeriodicTxHarness::AddPeriodicTxPgn)),
				Return(Any::PgnTableIndex())));
		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_mbuf_len(_))
			.WillByDefault(Return(sizeof(n_pgnData)));
		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_fill_mbuf_data(_, _, _))
			.WillByDefault(DoAll(
				WithArgs<1, 2>(Invoke(this, &TestPgnPeriodicTxHarness::FillMemoryBufferData)),
				Return(TRUE)));

		SetIJ1939(m_spMockJ1939);
		SetIJ1939MemoryBuffers(m_spMockJ1939MemoryBuffers);

		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder
			.UsingJ1939DataLink(Config::CanPort::Can0)
				.WithTransmitBroadcastPgns(n_transmitBroadcastPgnEntries_0);
		SetSharkConfig(configBuilder.Build());
	}

	void InvalidateSharkByte()
	{
		// Nothing to do since the default state of the SharkByte is invalid
	}
	void ReceiveRequestForPgnData()
	{
		assert(m_callback);
		assert(m_pContext);

		scl_j1939_mbuf_hdr_t* mbufHeader{};

		m_callback(mbufHeader, nullptr, 0, m_pContext);
	}
	void SendSharkByteValue()
	{
		auto& writeSharkByte = GetWriteSharkByte(Any::PgnMiddlewareId());
		writeSharkByte.Write(std::vector<uint8_t>(std::begin(n_pgnData), std::end(n_pgnData)));
	}
	unsigned GetRequestedPgn() const
	{
		return m_requestedPgn;
	}
	std::vector<uint8_t> const& GetActualTxData() const
	{
		return m_filledData;
	}

private:
	void AddPeriodicTxPgn(
		scl_j1939_tx_msg_t const* pTxMsg,
		void* pContext,
		scl_j1939_tx_msg_context_builder callback)
	{
		m_requestedPgn = pTxMsg->Mu32_pgn;
		m_pContext = pContext;
		m_callback = callback;
	}
	void FillMemoryBufferData(
		const void* pData,
		unsigned_16 length)
	{
		m_filledData.resize(length);
		std::copy_n(reinterpret_cast<const uint8_t*>(pData), length, m_filledData.begin());
	}

	Utilities::default_shared_ptr<NiceMock<MockIJ1939>> m_spMockJ1939{};
	Utilities::default_shared_ptr<NiceMock<MockIJ1939MemoryBuffers>> m_spMockJ1939MemoryBuffers{};

	unsigned m_requestedPgn{};
	void* m_pContext{};
	scl_j1939_tx_msg_context_builder m_callback{};
	std::vector<uint8_t> m_filledData{};
};

class J1939PgnPeriodicTxFunctionalTests : public Test
{
protected:
	void ExpectThatPeriodicTxPgnsAreAdded()
	{
		EXPECT_THAT(m_harness.GetRequestedPgn(), Eq(Any::Pgn()));
	}
	void ExpectThatMemoryBufferContainsAllFFData()
	{
		EXPECT_THAT(m_harness.GetActualTxData(), ElementsAreArray(n_defaultPgnData));
	}
	void ExpectThatMemoryBufferContainsTheValue()
	{
		EXPECT_THAT(m_harness.GetActualTxData(), ElementsAreArray(n_pgnData));
	}

	TestPgnPeriodicTxHarness m_harness{};
};
TEST_F(J1939PgnPeriodicTxFunctionalTests, ThePeriodicTxPgnsAreAddedToTheTxMessageTable)
{
	// Given: Shark is configured with Periodic Tx Pgns
	// When: Shark is started
	// Then: The expected Pgn is added to the tx message table

	m_harness.StartShark();
	ExpectThatPeriodicTxPgnsAreAdded();
}
TEST_F(J1939PgnPeriodicTxFunctionalTests, TheDataBroadcastedForAPgnIsAll_FF_WhenTheSharkByteValueIsInvalid)
{
	// Given: Shark is configured with Periodic Tx Pgns
	// And: Shark is started
	// When: The SharkByte value is invalid
	// And: A request is received for the Pgn data
	// Then: The broadcasted data for the Pgn is all 0xFF

	m_harness.StartShark();
	m_harness.InvalidateSharkByte();
	m_harness.ReceiveRequestForPgnData();
	ExpectThatMemoryBufferContainsAllFFData();
}
TEST_F(J1939PgnPeriodicTxFunctionalTests, TheDataBroadcastedForAPgnMatchesTheWrittenSharkByteValue)
{
	// Given: Shark is configured with Periodic Tx Pgns
	// And: Shark is started
	// When: The SharkByte value is valid
	// And: A request is received for the Pgn data
	// Then: The broadcasted data for the Pgn matches the written SharkByte value

	m_harness.StartShark();
	m_harness.SendSharkByteValue();
	m_harness.ReceiveRequestForPgnData();
	ExpectThatMemoryBufferContainsTheValue();
}
}