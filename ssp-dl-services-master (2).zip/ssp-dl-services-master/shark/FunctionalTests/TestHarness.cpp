/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Test Harness

#include "TestHarness.h"
#include "FakeOel.h"
#include <Utilities/IEnvironment.h>
#include "Utilities/Kraken/FakeClock.h"
#include <Utilities/Mocks/MockIEnvironment.h>

using namespace Shark::Kraken;
using namespace testing;

namespace FunctionalTests
{
namespace
{
std::unique_ptr<Shark::Kraken::FakeOel::FakeOelDestroyerHelper> CreateFakeOelDestroyerHelper()
{
	auto const spFakeOel = std::make_shared<Shark::Kraken::FakeOel>(Shark::Kraken::GetOelConfig());
	return std::make_unique<Shark::Kraken::FakeOel::FakeOelDestroyerHelper>(spFakeOel);
}
}

TestHarness::TestHarness()
	: m_spFakeOelDestroyerHelper{CreateFakeOelDestroyerHelper()}
{
	ON_CALL(m_mockEnvironment, Application())
		.WillByDefault(ReturnRefOfCopy(std::string{"FunctionalTests"}));
	ON_CALL(m_mockEnvironment, PersistentStoragePath())
		.WillByDefault(ReturnRefOfCopy(std::string{"/tmp"}));

	SetIOel(m_spFakeOelDestroyerHelper->GetFakeOel());
}
TestHarness::~TestHarness()
{
	m_spShark.reset(); // Shark must be destroyed first so that OEL can clean up properly
}
void TestHarness::StartShark()
{
	m_spShark = Shark::CreateShark(
		m_mockEnvironment,
		m_sharkConfig);
	GetFakeOel().ExecuteAllTasks();
}
void TestHarness::AdvanceClockBy(std::chrono::milliseconds milliseconds)
{
	Utilities::Kraken::FakeClock::AdvanceBy(milliseconds);
	Shark::SharkUtilities::GetFakeEventCallbackManager().Update();
}
Shark::Kraken::FakeOel& TestHarness::GetFakeOel()
{
	return *m_spFakeOelDestroyerHelper->GetFakeOel();
}
Shark::ISharkByte& TestHarness::GetSharkByte(std::string const& id) const
{
	assert(m_spShark);
	return m_spShark->GetSharkByteRetriever().Retrieve(id);
}
Shark::SharkByteValue TestHarness::GetSharkByteValue(std::string const& id) const
{
	auto const& sharkByte = GetSharkByte(id);
	return sharkByte.Value();
}
NiceMock<MockFunction<void(Shark::SharkByteValue const&)>>&
TestHarness::SubscribeToSharkByte(std::string const& id)
{
	auto spMock = std::make_unique<NiceMock<MockFunction<void(Shark::SharkByteValue const&)>>>();
	m_sharkByteSubscriptions.push_back(GetSharkByte(id).SubscribeToValues(spMock->AsStdFunction()));
	m_sharkByteCallbacks.push_back(std::move(spMock));
	return *m_sharkByteCallbacks.back();
}
Shark::IWriteSharkByte& TestHarness::GetWriteSharkByte(std::string const& id) const
{
	assert(m_spShark);
	return m_spShark->GetWriteSharkByteRetriever().Retrieve(id);
}
void TestHarness::WriteSharkByteValue(
	std::string const& id,
	std::vector<uint8_t> const& value,
	Shark::IWriteSharkByte::CompletedCallback const& callback) const
{
	auto& writeSharkByte = GetWriteSharkByte(id);
	writeSharkByte.Write(value, callback);
}
void TestHarness::SetSharkConfig(cat::shark::Config const& config)
{
	m_sharkConfig = config;
}
void TestHarness::RefreshSharkByte(std::string const& id) const
{
	auto& sharkByte = GetSharkByte(id);
	sharkByte.Refresh();
}
}