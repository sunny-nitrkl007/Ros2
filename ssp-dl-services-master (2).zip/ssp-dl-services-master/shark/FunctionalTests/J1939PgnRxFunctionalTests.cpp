/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 PGN Rx Functional Tests

#include "TestHarness.h"
#include "SimpleSharkConfigBuilder.h"
#include <Kraken/MockIJ1939.h>
#include <Kraken/MockIJ1939MemoryBuffers.h>
#include <Utilities/DefaultSmartPointers.h>
#include <Utilities/narrow_cast.h>
#include <Utilities/OptionalSmartPointers.h>
#include <algorithm>
#include <array>
#include <span>

using namespace Shark::Kraken;
using namespace testing;

namespace FunctionalTests
{
struct Default
{
	static constexpr unsigned SourceAddress() { return 0x26; }
	static constexpr unsigned BroadcastPgn() { return 0x00FEEE; }
	static constexpr unsigned OnRequestPgn() { return 0x00FEB0; }
	static constexpr unsigned TimeOut() { return 1000; }
	static constexpr const char* BroadcastId() { return "a broadcast pgn"; }
	static constexpr const char* OnRequestId() { return "an on-request pgn"; }
	static constexpr int_8 EcmIndex() { return 42; }
	// The mbuf* must simply be a unique pointer.
	static constexpr scl_j1939_mbuf_hdr_t* Mbuf() { return reinterpret_cast<scl_j1939_mbuf_hdr_t*>(0x1234); }
};
constexpr Config::ReceiveBroadcastPgnEntry n_receiveBroadcastPgnEntries[]
{
	{ Default::BroadcastPgn(), Default::TimeOut(), {}, Default::BroadcastId() },
};
constexpr Config::ReceiveOnRequestPgnEntry n_receiveOnRequestPgnEntries[]
{
	{ Default::OnRequestPgn(), {}, Default::OnRequestId() },
};
constexpr std::array<uint8_t, 8> n_testData{ 0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80 };

scl_j1939_rx_msg_t CreateExpectedRxMsgConfig(unsigned sourceAddress, unsigned pgn, unsigned timeout)
{
	uint8_t const timeoutEnabled = timeout > 0 ? SCL_J1939_RX_MSG_CBF_LOST_TIMER_APPLICABLE : 0;

	return scl_j1939_rx_msg_t{
		pgn,
		nullptr,
		0x00,
		FALSE,
		static_cast<unsigned_8>(sourceAddress),
		{},
		Utilities::narrow_cast<uint8_t>(SCL_J1939_RX_MSG_CBF_ENABLED | timeoutEnabled),
		static_cast<int_16>(timeout)
	};
}

/// Matches all elements except callback, priority and source name
MATCHER_P(PgnInfoEq, expected, "")
{
	auto const& actual = arg;
	*result_listener << "Pgn: " << actual.Mu32_pgn;
	return (actual.Mu32_pgn == expected.Mu32_pgn) &&
		(actual.Mb_address_by_name == expected.Mb_address_by_name) &&
		(actual.Mu8_source_address == expected.Mu8_source_address) &&
		(actual.Mu8_init_cntrl == expected.Mu8_init_cntrl) &&
		(actual.Mi16_lost_timeout == expected.Mi16_lost_timeout);
}

class TestPgnHarness : public TestHarness
{
public:
	TestPgnHarness()
	{
		ON_CALL(*m_spMockJ1939, scl_j1939_establish_link(_, _, _, _, _, _, _, _, _))
			.WillByDefault(DoAll(
				SaveArgPointee<1>(&m_addressTable),
				Return(MockIJ1939::Default::Link())
			));
		ON_CALL(*m_spMockJ1939, scl_j1939_set_rx_msg_send_request_bit(_, _, _))
			.WillByDefault(DoAll(
				SaveArg<2>(&m_lastRequestedTableIndex),
				Return(TRUE)));
		SetIJ1939(m_spMockJ1939);

		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_mbuf_len(Default::Mbuf()))
			.WillByDefault(Return(n_testData.size()));
		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_data_from_mbuf(Default::Mbuf(), NotNull(), _, _))
			.WillByDefault(Invoke(WithArgs<1, 2, 3>(
				[](unsigned_8* pDestination, unsigned_16 length, unsigned_16 startIndex)
				{
					auto result = FALSE;
					if (startIndex + length <= n_testData.size())
					{
						std::copy_n(n_testData.begin() + startIndex, length, pDestination);
						result = TRUE;
					}

					return result;
				})));
		SetIJ1939MemoryBuffers(m_spMockJ1939MemoryBuffers);

		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder
			.UsingJ1939DataLink(Config::CanPort::Can0)
				.UsingPeerNode(Default::SourceAddress())
					.WithPgnBroadcastRxConfig(n_receiveBroadcastPgnEntries)
					.WithPgnOnRequestRxConfig(n_receiveOnRequestPgnEntries);
		SetSharkConfig(configBuilder.Build());
	}
	std::span<scl_j1939_rx_msg_t const> GetRxMsgConfigs() const
	{
		return {m_addressTable.Mpast_rx_msg_table, m_addressTable.Mu8_rx_msg_table_size};
	}
	unsigned GetLastRequestedTableIndex() const
	{
		return m_lastRequestedTableIndex;
	}
	void PerformCallback(unsigned pgn)
	{
		auto const spConfig = TryFindRxMsgConfig(pgn);
		ASSERT_TRUE(spConfig);
		ASSERT_THAT(spConfig->Mpfn_parser, NotNull());

		spConfig->Mpfn_parser(
			MockIJ1939::Default::Link(),
			&(*spConfig),
			Default::EcmIndex(),
			SCL_J1939_RX_MSG_PGN_RXED,
			Default::Mbuf());
	}
	std::optional<unsigned> TryFindRxMsgConfigIndex(unsigned pgn) const
	{
		auto const found = TryFindRxMsgConfigAndIndex(pgn);
		return found ? std::make_optional(found->second) : std::nullopt;
	}
	Utilities::optional_nice_ptr<scl_j1939_rx_msg_t const> TryFindRxMsgConfig(unsigned pgn) const
	{
		auto const found = TryFindRxMsgConfigAndIndex(pgn);
		return found ? found->first : nullptr;
	}
private:
	std::optional<std::pair<scl_j1939_rx_msg_t const*, size_t>> TryFindRxMsgConfigAndIndex(unsigned pgn) const
	{
		std::optional<std::pair<scl_j1939_rx_msg_t const*, size_t>> result{};

		auto const rxMsgConfigs = GetRxMsgConfigs();
		auto const itFound = std::ranges::find_if(rxMsgConfigs,
			[pgn](scl_j1939_rx_msg_t const& config){ return config.Mu32_pgn == pgn; });
		if (itFound != rxMsgConfigs.end())
		{
			auto const index = Utilities::narrow_cast<unsigned>(std::distance(rxMsgConfigs.begin(), itFound));
			result = std::make_pair(&(*itFound), index);
		}

		return result;
	}

	Utilities::default_shared_ptr<NiceMock<MockIJ1939>> m_spMockJ1939{};
	Utilities::default_shared_ptr<NiceMock<MockIJ1939MemoryBuffers>> m_spMockJ1939MemoryBuffers{};

	scl_j1939_addr_tbl_t m_addressTable{};
	unsigned m_lastRequestedTableIndex{};
};

class J1939PgnRxFunctionalTests : public Test
{
protected:
	void ExpectThatThePgnIsConfigured(scl_j1939_rx_msg_t const& expectedConfig)
	{
		auto const rxMsgConfigs = m_harness.GetRxMsgConfigs();
		// Use "Contains" since 0xEF00 is always added for PropA
		EXPECT_THAT(rxMsgConfigs, Contains(PgnInfoEq(expectedConfig)));
	}
	void ExpectThatTheSharkByteContainsTheData(std::string const& sharkByteId)
	{
		auto const value = m_harness.GetSharkByteValue(sharkByteId);
		EXPECT_THAT(value, Optional(ElementsAreArray(n_testData)));
	}

	TestPgnHarness m_harness{};
};

class J1939PgnBroadcastRxFunctionalTests : public J1939PgnRxFunctionalTests
{
protected:
	void ExpectThatThePgnIsConfigured()
	{
		auto const expectedConfig = CreateExpectedRxMsgConfig(
			Default::SourceAddress(),
			Default::BroadcastPgn(),
			Default::TimeOut());
		J1939PgnRxFunctionalTests::ExpectThatThePgnIsConfigured(expectedConfig);
	}
};
TEST_F(J1939PgnBroadcastRxFunctionalTests, EveryPgnIsRegisteredWithSclWhenSharkStarts)
{
	// Given: Shark is configured with broadcast Rx PGNs
	// When: Shark is started
	// Then: The expected broadcast PGNs are registered with SCL

	m_harness.StartShark();
	ExpectThatThePgnIsConfigured();
}
TEST_F(J1939PgnBroadcastRxFunctionalTests, TheBinaryPgnDataIsProvidedWhenThePgnIsReceived)
{
	// Given: Shark is configured with broadcast Rx PGNs
	// And: Shark is started
	// When: The broadcast PGN data is received
	// Then: The PGN data is accessible through the corresponding SharkByte

	m_harness.StartShark();
	m_harness.PerformCallback(Default::BroadcastPgn());
	ExpectThatTheSharkByteContainsTheData(Default::BroadcastId());
}

class J1939PgnOnRequestRxFunctionalTests : public J1939PgnRxFunctionalTests
{
protected:
	void ExpectThatThePgnIsConfigured()
	{
		auto const expectedConfig = CreateExpectedRxMsgConfig(
			Default::SourceAddress(),
			Default::OnRequestPgn(),
			0); // On-request PGNs have no timeout
		J1939PgnRxFunctionalTests::ExpectThatThePgnIsConfigured(expectedConfig);
	}
	void ExpectThatTheSharkByteHasBeenRefreshed()
	{
		auto const pgnIndex = m_harness.TryFindRxMsgConfigIndex(Default::OnRequestPgn());
		ASSERT_TRUE(pgnIndex.has_value());

		auto const tableIndex = *pgnIndex;
		EXPECT_THAT(m_harness.GetLastRequestedTableIndex(), Eq(tableIndex));
	}
};
TEST_F(J1939PgnOnRequestRxFunctionalTests, EveryPgnIsRegisteredWithSclWhenSharkStarts)
{
	// Given: Shark is configured with on-request Rx PGNs
	// When: Shark is started
	// Then: The expected on-request PGNs are registered with SCL

	m_harness.StartShark();
	ExpectThatThePgnIsConfigured();
}
TEST_F(J1939PgnOnRequestRxFunctionalTests, RefreshingTheSharkByteRefreshesTheCorrectPgnIndex)
{
	// Given: Shark is configured with on-request Rx PGNs
	// And: Shark is started
	// When: The SharkByte for the on-request PGN is refreshed
	// Then: A request to refresh the PGN is sent to SCL

	m_harness.StartShark();
	m_harness.RefreshSharkByte(Default::OnRequestId());
	ExpectThatTheSharkByteHasBeenRefreshed();
}
TEST_F(J1939PgnOnRequestRxFunctionalTests, TheBinaryPgnDataIsProvidedWhenThePgnIsReceived)
{
	// Given: Shark is configured with on-request Rx PGNs
	// And: Shark is started
	// And: The SharkByte for the on-request PGN is refreshed
	// When: The on-request PGN data is received
	// Then: The PGN data is accessible through the corresponding SharkByte

	m_harness.StartShark();
	m_harness.RefreshSharkByte(Default::OnRequestId());
	m_harness.PerformCallback(Default::OnRequestPgn());
	ExpectThatTheSharkByteContainsTheData(Default::OnRequestId());
}
}
