/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Overrides for weak symbols in Shark

#include "TestHarness.h"
#include "FakeEventCallbackFactory.h"
#include <Utilities/SingleThreadedUsageValidator.h>
#include <Utilities/TestUtilities.h>

namespace Shark
{
namespace SharkUtilities
{
namespace
{
Utilities::TestUniquePtr<Kraken::FakeEventCallbackFactory> n_spFakeEventCallbackFactory;
}
std::unique_ptr<IEventCallbackFactory> IEventCallbackFactory::Create()
{
	n_spFakeEventCallbackFactory = Kraken::FakeEventCallbackFactory::CreateFake();
	return n_spFakeEventCallbackFactory.TakeUniquePtr();
}
Kraken::IFakeEventCallbackManager& GetFakeEventCallbackManager()
{
	assert(n_spFakeEventCallbackFactory.get());
	return *n_spFakeEventCallbackFactory;
}
}
}

namespace Utilities
{
#ifndef NDEBUG
void SingleThreadedUsageValidator::ValidateCurrentThread() const
{
	// The acceptance tests spawn a new thread for each test so we'll need to
	// override this method so it does not assert.
}
#endif
}
