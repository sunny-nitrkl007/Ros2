/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 PGB Functional Tests

#include "TestHarness.h"
#include "SimpleSharkConfigBuilder.h"
#include <Kraken/MockIJ1939Pgb.h>
#include <Utilities/DefaultSmartPointers.h>
#include <Utilities/OptionalSmartPointers.h>
#include <cdl2_struct.h>
#include <scl_pgb_j1939.h>
#include <ranges>
#include <vector>

using namespace Shark::Kraken;
using namespace testing;

namespace FunctionalTests
{
namespace
{
constexpr unsigned n_sourceAddress = 0x42;
constexpr unsigned n_requestRate = 50;
constexpr uint_least16_t n_sclReceivedValue = 0x0000;
// SCL is not checking for DSI in the data, but it sends this when the value has not been received.
constexpr uint_least16_t n_sclDidNotReceiveValue = 0xFF00 | CDL2_DSI_PARAM_NOT_AVAIL;

constexpr Config::PgbPidEntry n_pgbPidEntries[]
{
	{ 0x000001, n_requestRate, false, "a" },
	{ 0x000040, n_requestRate, false, "b" },
	{ 0x0000C8, n_requestRate, false, "c" },
};
Config::PgbPidEntry const& FindConfigPidEntry(unsigned pid)
{
	auto const itFound = std::ranges::find_if(n_pgbPidEntries, [pid](auto const& entry) {
		return entry.pid == pid;
	});
	assert(itFound != std::end(n_pgbPidEntries));

	return *itFound;
}
}

/// Matches pid, data_size, and flags
MATCHER(PgbPidInfoEq, "")
{
	auto const& actual = std::get<0>(arg);
	auto const& expected = std::get<1>(arg);
	*result_listener << actual->pid;

	auto const matched = (actual->pid == expected.pid) &&
		(actual->data_size == expected.data_size) &&
		(actual->flags == expected.flags);
	return matched;
}

constexpr auto n_expectedFlags =
	SCL_PGB_J1939_RX_PID_UNSIGNED | SCL_PGB_J1939_RX_PID_DSI_NA | SCL_PGB_J1939_RX_PID_NO_SWAP;
constexpr scl_pgb_j1939_rx_pid_config_t n_expectedPidConfigEntries[]
{
	{ 0x000001, nullptr, nullptr, 1, n_expectedFlags },
	{ 0x000040, nullptr, nullptr, 2, n_expectedFlags },
	{ 0x0000C8, nullptr, nullptr, 4, n_expectedFlags },
};

constexpr auto n_testPid = 0x0000C8;
constexpr auto n_testData = std::to_array<uint8_t>({ 0x1, 0x2, 0x3, 0x4 });

/// Used to hold the relevant parameters passed to rx_add_grps
struct AddRxGrpsParameters
{
	uint_least8_t remote_addr;
	uint_least16_t num_rx_pids;
	const scl_pgb_j1939_rx_pid_cfg_ptr_t *rx_pid_table;
	uint_least16_t requested_periodic_rate;
};

class TestPgbHarness : public TestHarness
{
public:
	struct Default
	{
		static scl_pgb_j1939_t* PgbContext() { return reinterpret_cast<scl_pgb_j1939_t*>(42); }
	};

	TestPgbHarness()
	{
		ON_CALL(*m_spMockJ1939Pgb, scl_pgb_j1939_init(_))
			.WillByDefault(Return(Default::PgbContext()));
		ON_CALL(*m_spMockJ1939Pgb, scl_pgb_j1939_add_ecm(_, _))
			.WillByDefault(Return(TRUE));
		ON_CALL(*m_spMockJ1939Pgb, scl_pgb_j1939_add_rx_grps(_, _, _, _, _, _, _, _, _, _))
			.WillByDefault(WithArgs<2, 3, 4, 6>(Invoke(this, &TestPgbHarness::add_rx_grps)));

		SetIJ1939Pgb(m_spMockJ1939Pgb);

		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder
			.UsingJ1939DataLink(Config::CanPort::Can0)
				.UsingPeerNode(n_sourceAddress)
					.WithPgbConfig(n_pgbPidEntries);
		SetSharkConfig(configBuilder.Build());
	}

	void SendPgbData(unsigned pid, std::span<uint8_t const> data, uint_least16_t dsiCode)
	{
		auto const spEntry = FindSclPidEntry(pid);
		ASSERT_THAT(spEntry, NotNull());

		spEntry->rx_hdlr(
			const_cast<uint8_t*>(data.data()),
			static_cast<uint_least8_t>(data.size()),
			spEntry->rx_hdlr_context,
			dsiCode
		);
	}
	std::vector<AddRxGrpsParameters> const& GetAddRxGrpsParameters() const
	{
		return m_addRxGrpsParameters;
	}
private:
	// Save the parameters we care about.
	bool_t add_rx_grps(
		uint_least8_t remote_addr,
		uint_least16_t num_rx_pids,
		const scl_pgb_j1939_rx_pid_cfg_ptr_t *rx_pid_table,
		uint_least16_t requested_periodic_rate)
	{
		m_addRxGrpsParameters.emplace_back(AddRxGrpsParameters{
			remote_addr,
			num_rx_pids,
			rx_pid_table,
			requested_periodic_rate});
		return TRUE;
	}
	Utilities::optional_nice_ptr<scl_pgb_j1939_rx_pid_config_t const> FindSclPidEntry(unsigned pid) const
	{
		Utilities::optional_nice_ptr<scl_pgb_j1939_rx_pid_config_t const> spResult{};

		// Flatten the list of all pid entries added via add_rx_grps
		auto allEntries = m_addRxGrpsParameters
			| std::views::transform(
				[](auto const& parameters)
				{
					return std::span{parameters.rx_pid_table, parameters.num_rx_pids};
				})
			| std::views::join;

		auto const itFound = std::ranges::find_if(allEntries, [pid](auto pEntry) { return pEntry->pid == pid; });
		if (itFound != allEntries.end()) {
			spResult = *itFound;
		}

		return spResult;
	}

	Utilities::default_shared_ptr<NiceMock<MockIJ1939Pgb>> m_spMockJ1939Pgb{};

	std::vector<AddRxGrpsParameters> m_addRxGrpsParameters{};
};

class J1939PgbFunctionalTests : public Test
{
protected:
	void ExpectThatPgbGroupsAreConfigured() const
	{
		ASSERT_THAT(m_harness.GetAddRxGrpsParameters(), SizeIs(1));
		auto const& parameters = m_harness.GetAddRxGrpsParameters()[0];
		EXPECT_THAT(parameters.remote_addr, Eq(n_sourceAddress));
		EXPECT_THAT(parameters.requested_periodic_rate, Eq(n_requestRate));
	}
	void ExpectThatPgbEntriesArePopulated() const
	{
		ASSERT_THAT(m_harness.GetAddRxGrpsParameters(), SizeIs(Ge(1)));
		auto const& parameters = m_harness.GetAddRxGrpsParameters()[0];
		std::vector<scl_pgb_j1939_rx_pid_config_t const*> const pidConfigEntries{
			parameters.rx_pid_table,
			parameters.rx_pid_table + parameters.num_rx_pids
		};
		EXPECT_THAT(pidConfigEntries, UnorderedPointwise(PgbPidInfoEq(), n_expectedPidConfigEntries));
	}
	void ExpectThatSharkByteValueContains(unsigned pid, std::span<uint8_t const> expectedData) const
	{
		auto const& pgbPidEntry = FindConfigPidEntry(pid);
		auto const value = m_harness.GetSharkByteValue(pgbPidEntry.pMiddlewareId);
		ASSERT_TRUE(value);
		EXPECT_THAT(*value, ElementsAreArray(expectedData));
	}
	void ExpectThatSharkByteValueIsInvalid(unsigned pid) const
	{
		auto const& pgbPidEntry = FindConfigPidEntry(pid);
		auto const value = m_harness.GetSharkByteValue(pgbPidEntry.pMiddlewareId);
		EXPECT_FALSE(value);
	}

	TestPgbHarness m_harness{};
};
TEST_F(J1939PgbFunctionalTests, ThePgbGroupsContainTheCorrectSourceAddressAndRequestRate)
{
	// Given: Shark is configured with PGB PIDs
	// When: Shark is started
	// Then: PGB groups are configured with correct source address and request rate

	m_harness.StartShark();
	ExpectThatPgbGroupsAreConfigured();
}
TEST_F(J1939PgbFunctionalTests, ThePgbEntriesArePopulatedWithTheCorrectPidInformation)
{
	// Given: Shark is configured with PGB PIDs
	// When: Shark is started
	// Then: PGB entries are populated with correct PID information

	m_harness.StartShark();
	ExpectThatPgbEntriesArePopulated();
}
TEST_F(J1939PgbFunctionalTests, ValidPgbDataIsProvidedWithoutChangesInItsSharkByte)
{
	// Given: Shark is configured with PGB PIDs
	// And: Shark is started
	// When: Valid PGB data is received
	// Then: The PGB PID SharkByte contains the data

	m_harness.StartShark();
	m_harness.SendPgbData(n_testPid, n_testData, n_sclReceivedValue);
	ExpectThatSharkByteValueContains(n_testPid, n_testData);
}
TEST_F(J1939PgbFunctionalTests, PgbDataThatIsNotReceivedLeadsToInvalidSharkByteValue)
{
	// Given: Shark is configured with PGB PIDs
	// And: Shark is started
	// When: PGB data is not received
	// Then: The PGB PID SharkByte value is invalid

	m_harness.StartShark();
	m_harness.SendPgbData(n_testPid, n_testData, n_sclDidNotReceiveValue);
	ExpectThatSharkByteValueIsInvalid(n_testPid);
}

}
