/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Test Harness

#include "FakeEventCallbackFactory.h"
#include "FakeOel.h"
#include "IWriteSharkByte.h"
#include "Shark.h"
#include <Utilities/IEnvironment.h>
#include <Utilities/Mocks/MockIEnvironment.h>

namespace Shark
{
namespace SharkUtilities
{
Kraken::IFakeEventCallbackManager& GetFakeEventCallbackManager();
}
}

namespace FunctionalTests
{
class TestHarness
{
public:
	TestHarness();
	virtual ~TestHarness();

	void StartShark();
	void AdvanceClockBy(std::chrono::milliseconds milliseconds);
	Shark::Kraken::FakeOel& GetFakeOel();
	Shark::ISharkByte& GetSharkByte(std::string const& id) const;
	Shark::SharkByteValue GetSharkByteValue(std::string const& id) const;
	testing::NiceMock<testing::MockFunction<void(Shark::SharkByteValue const&)>>& SubscribeToSharkByte(std::string const& id);
	Shark::IWriteSharkByte& GetWriteSharkByte(std::string const& id) const;
	void RefreshSharkByte(std::string const& id) const;
	void WriteSharkByteValue(
		std::string const& id,
		std::vector<uint8_t> const& value,
		Shark::IWriteSharkByte::CompletedCallback const& callback) const;
protected:
	void SetSharkConfig(cat::shark::Config const& config);
private:
	std::unique_ptr<Shark::Kraken::FakeOel::FakeOelDestroyerHelper> m_spFakeOelDestroyerHelper;
	testing::NiceMock<Utilities::Mocks::MockIEnvironment> m_mockEnvironment{};
	cat::shark::Config m_sharkConfig{};

	std::unique_ptr<Shark::IShark> m_spShark{};

	// Store the SharkByte callbacks in the harness so that they stay alive just as long as the subscriptions
	std::vector<std::unique_ptr<testing::NiceMock<testing::MockFunction<void(Shark::SharkByteValue const&)>>>> m_sharkByteCallbacks;
	std::vector<Shark::SharkByteSubscription> m_sharkByteSubscriptions;
};
}