/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Shark Functional Tests

#include <gmock/gmock.h>

int main(int argc, char* argv[])
{
//#define DEBUGGING_TEST_EXCEPTIONS // Do not commit with this uncommented!
#ifdef DEBUGGING_TEST_EXCEPTIONS
	::testing::FLAGS_gtest_catch_exceptions = 0;
#endif
	testing::InitGoogleMock(&argc, argv);
	return RUN_ALL_TESTS();
}

// Required so the acceptance tests can link without bringing in scl_encrypt_keys.
const void* scl_encrypt_key2 = reinterpret_cast<void*>(0xdeadbeef);
