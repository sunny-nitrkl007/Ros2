/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Internal Codes Functional Tests

#include "Kraken/MockIJ1939.h"
#include "Kraken/MockIDiagPJ1939.h"
#include "Kraken/MockISclObd.h"
#include "SimpleSharkConfigBuilder.h"
#include "TestHarness.h"
#include "Utilities/Kraken/FakeClock.h"
#include <SharkConfiguration.pb.h>
#include <Utilities/DefaultSmartPointers.h>
#include <Utilities/TestUtilities.h>
#include <middleware_diagnostics.pb.h>
#include <vector>


using namespace Shark::Kraken;
using namespace testing;
using namespace std::chrono_literals;
using namespace cat::shark;

namespace FunctionalTests
{
namespace
{
struct Default
{
	static constexpr uint8_t SourceAddress() { return 0x21; }
	static constexpr ::Config::CanPort CanPort() { return ::Config::CanPort::Can0; }
	static constexpr std::chrono::seconds StartUpDelay() { return 3s; }
	static constexpr std::chrono::seconds ActivationDelay() { return 4s; }
	static constexpr std::chrono::seconds DeactivationDelay() { return 5s; }
};
constexpr ::Config::DiagnosticPeerEntry n_defaultPeers[]{{ Default::SourceAddress(), ::Config::DiagnosticType::Eddt }};
constexpr ::Config::DiagnosticClientCanPort n_defaultClientCanPort{ Default::CanPort(), { n_defaultPeers } };
constexpr ::Config::InternalCodeEntry n_defaultInternalCodeEntry[]{
{
	::Config::CodeType::Diagnostic,
	::Config::StorageType::ActiveOnly,
	1296,
	7,
	2,
	5,
	"Description",
	2,
	Default::StartUpDelay().count(),
	Default::ActivationDelay().count(),
	Default::DeactivationDelay().count(),
	"middleware_id"
}};
constexpr ::Config::InternalCodeList n_defaultInternalCodeList
{
	Default::CanPort(),
	{ n_defaultInternalCodeEntry },
};

constexpr ::Config::DiagnosticsEntry n_defaultDiagnosticsEntry{{ n_defaultClientCanPort }, { n_defaultInternalCodeList }};
}

class TestInternalCodesHarness : public TestHarness
{
public:
	TestInternalCodesHarness()
	{
		ON_CALL(*m_spMockSclObd, scl_obd_es_register_test(_, _, NotNull()))
			.WillByDefault(WithArgs<1,2>(Invoke(this, &TestInternalCodesHarness::RegisterObdEsTest)));
		ON_CALL(*m_spMockSclObd, scl_obd_es_notify_test_results(_, _, _))
			.WillByDefault(WithArgs<1,2>(Invoke(this, &TestInternalCodesHarness::SetObdEsTestStatus)));
		ON_CALL(*m_spMockDiagPJ1939, scl_diag_pj1939_register_fault(_, _, NotNull()))
			.WillByDefault(WithArg<2>(Invoke(this, &TestInternalCodesHarness::RegisterEddtFault)));

		SetISclObd(m_spMockSclObd);
		SetIDiagPJ1939(m_spMockDiagPJ1939);

		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder
			.WithDiagnostics(n_defaultDiagnosticsEntry)
			.UsingJ1939DataLink(Default::CanPort())
				.UsingPeerNode(Default::SourceAddress());
		SetSharkConfig(configBuilder.Build());
	}
	scl_obd_es_test_config_t const& GetObdEsTestConfig() const
	{
		assert(m_pObdEsTestConfig);
		return *m_pObdEsTestConfig;
	}
	scl_eddt_fault_config_t const& GetEddtFaultConfig() const
	{
		assert(m_pEddtFaultConfig);
		return *m_pEddtFaultConfig;
	}
	scl_obd_test_handle_t GetObdEsTestHandle() const
	{
		return m_obdEsTestHandle;
	}
	std::pair<scl_obd_test_handle_t, scl_obd_es_test_results_t> const& GetLastObdEsTestResult() const
	{
		return m_lastObdEsTestResult;
	}
private:
	scl_obd_es_error_t RegisterObdEsTest(scl_obd_test_handle_t testHandle, scl_obd_es_test_config_t const* pTestConfig)
	{
		m_obdEsTestHandle = testHandle;
		m_pObdEsTestConfig = const_cast<scl_obd_es_test_config_t*>(pTestConfig);
		return SCL_OBD_ES_SUCCESS;
	}
	scl_diag_pj1939_error_t RegisterEddtFault(scl_eddt_fault_config_t const* pFaultConfig)
	{
		m_pEddtFaultConfig = const_cast<scl_eddt_fault_config_t*>(pFaultConfig);
		return SCL_DIAG_PJ1939_SUCCESSFUL;
	}
	scl_obd_es_error_t SetObdEsTestStatus(
		scl_obd_test_handle_t test_handle,
		scl_obd_es_test_results_t test_results)
	{
		m_lastObdEsTestResult = {test_handle, test_results};
		return SCL_OBD_ES_SUCCESS;
	}

	Utilities::default_shared_ptr<NiceMock<MockIDiagPJ1939>> m_spMockDiagPJ1939{};
	Utilities::default_shared_ptr<NiceMock<MockISclObd>> m_spMockSclObd{};

	scl_obd_es_test_config_t* m_pObdEsTestConfig{};
	scl_eddt_fault_config_t* m_pEddtFaultConfig{};
	scl_obd_test_handle_t m_obdEsTestHandle{};
	std::pair<scl_obd_test_handle_t, scl_obd_es_test_results_t> m_lastObdEsTestResult{};
};

class InternalCodesFunctionalTests : public Test
{
protected:
	void InternalCodesAreConfiguredForObdEsAndEddt()
	{
		auto const& testConfig = m_harness.GetObdEsTestConfig();
		auto const& faultConfig = m_harness.GetEddtFaultConfig();

		EXPECT_THAT(testConfig.fault_class, Eq(SCL_OBD_ES_CLASS_DIAG));
		EXPECT_THAT(testConfig.annunc_req_lvl, Eq(n_defaultInternalCodeEntry[0].annunciationRequirement));
		EXPECT_THAT(testConfig.security_level, Eq(n_defaultInternalCodeEntry[0].securityLevel));


		EXPECT_THAT(faultConfig.ascii_text, StrEq(n_defaultInternalCodeEntry[0].pDescription));
		EXPECT_THAT(faultConfig.eid_or_cid, Eq(n_defaultInternalCodeEntry[0].code));
		EXPECT_THAT(faultConfig.wci, Eq(n_defaultInternalCodeEntry[0].warningCategoryIndicator));
		EXPECT_THAT(faultConfig.fmi, Eq(n_defaultInternalCodeEntry[0].failureModeIdentifier));
	}
	void ExpectThatInternalCodeTestStateIs(scl_obd_es_test_results_t expectedState)
	{
		auto const& testResult = m_harness.GetLastObdEsTestResult();
		EXPECT_THAT(testResult.first, Eq(m_harness.GetObdEsTestHandle()));
		EXPECT_THAT(testResult.second, Eq(expectedState));
	}

	TestInternalCodesHarness m_harness{};
};
TEST_F(InternalCodesFunctionalTests, InternalCodesAreConfiguredInTheObdEsAndEddtLibraries)
{
	// Given: Shark is configured with internal codes
	// When: Shark is started
	// Then: Internal codes are configured for both the OBDEs and EDDT libraries

	m_harness.StartShark();
	InternalCodesAreConfiguredForObdEsAndEddt();
}
TEST_F(InternalCodesFunctionalTests,
	InternalCodeWillBecomeActiveOnlyAfterStartupDelayHasElapsedAndTheSharkByteHasTransitionedToTrueAndTheActivationDelayHasElapsed)
{
	// Given: Shark is configured with internal codes
	// And: Shark is started
	// When: The start up delay has elapsed
	// Then: I see the internal code test result is unknown
	// When: The SharkByte has transitioned to true
	// And: The activation delay has elapsed
	// Then: I see the internal code test result is fail (active)
	// When: The SharkByte has transitioned to false
	// And: The deactivation delay has elapsed
	// Then: I see the internal code test result is pass (inactive)

	m_harness.StartShark();
	m_harness.AdvanceClockBy(Default::StartUpDelay());
	ExpectThatInternalCodeTestStateIs(SCL_OBD_ES_TEST_RESULTS_UNKNOWN);
	m_harness.WriteSharkByteValue(n_defaultInternalCodeEntry[0].pMiddlewareId, Shark::TrueSharkByteValue(), [](Shark::SharkByteValue const&){});
	m_harness.AdvanceClockBy(Default::ActivationDelay());
	ExpectThatInternalCodeTestStateIs(SCL_OBD_ES_TEST_RESULTS_FAIL);
	m_harness.WriteSharkByteValue(n_defaultInternalCodeEntry[0].pMiddlewareId, Shark::FalseSharkByteValue(), [](Shark::SharkByteValue const&){});
	m_harness.AdvanceClockBy(Default::DeactivationDelay());
	ExpectThatInternalCodeTestStateIs(SCL_OBD_ES_TEST_RESULTS_PASS);
}
}
