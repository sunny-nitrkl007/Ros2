/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// J1939 Extension ID Functional Tests

#include "SimpleSharkConfigBuilder.h"
#include "TestHarness.h"
#include <Kraken/MockIJ1939.h>
#include <Kraken/MockIJ1939MemoryBuffers.h>
#include <Utilities/DefaultSmartPointers.h>
#include <Utilities/narrow_cast.h>
#include <Utilities/ToUnderlying.h>
#include <vector>
#include <span>

using namespace Shark::Kraken;
using namespace testing;

namespace FunctionalTests
{
namespace
{
struct Default
{
	static constexpr scl_j1939_mbuf_hdr_t* Mbuf() { return reinterpret_cast<scl_j1939_mbuf_hdr_t*>(0x1234); }
	static constexpr unsigned_8 RequesterSourceAddress() { return 0x84; }
};

constexpr auto const n_propAPgn                                    = 0xEF00;
constexpr auto const n_extensionIdReadRequestByte                  = 0x80;
constexpr auto const n_extensionIdWriteWithDataResponseRequestByte = 0x81;
constexpr auto const n_extensionIdWriteDataResponseByte            = 0x83;
constexpr auto const n_acknowledgeResponseId                       = 0xF004;

constexpr Config::DeviceIdEntry n_deviceIdEntry
{
	0x1234,
	0x9876,
	0x5678,
	1,
	std::nullopt
};
constexpr uint8_t n_expectedF016Data[] { 0xF0, 0x16, 0x01, 0x34, 0x12, 0x76, 0x98, 0x78, 0x56, 0x01, 0x00 };

constexpr unsigned n_j1939DataLinkCount = 2;
static_assert(n_j1939DataLinkCount < Utilities::ToUnderlying(Config::CanPort::CanPortCount));
}

class TestExtensionIdHarness : public TestHarness
{
public:
	struct ExtIdHandler
	{
		scl_j1939_link_t link;
		SCL_J1939_CAT_PPGN_ID_HDLR_t const* pHandler;
	};
	struct TxMessage
	{
		scl_j1939_link_t        link;
		unsigned_32             pgn;
		unsigned_8              destinationAddress;
		std::vector<unsigned_8> data;
	};

	TestExtensionIdHarness()
	{
		ON_CALL(*m_spMockJ1939, scl_j1939_establish_link(_, _, _, _, _, _, _, _, _))
			.WillByDefault(InvokeWithoutArgs(this, &TestExtensionIdHarness::GetNextLink));
		ON_CALL(*m_spMockJ1939, scl_j1939_cat_ppgn_id_install_command_id(_, _))
			.WillByDefault(DoAll(
				WithArgs<0, 1>(Invoke(this, &TestExtensionIdHarness::AddCommandIdHandler)),
				Return(TRUE)));
		ON_CALL(*m_spMockJ1939, scl_j1939_que_tx_msg_by_address(_, _, _, _, _, _, _))
			.WillByDefault(DoAll(
				WithArgs<0, 1, 3, 5, 6>(Invoke(this, &TestExtensionIdHarness::QueueTxMessage)),
				Return(TRUE)));
		SetIJ1939(m_spMockJ1939);

		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_mbuf_len(Default::Mbuf()))
			.WillByDefault(Return(0));
		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_data_from_mbuf(Default::Mbuf(), NotNull(), _, _))
			.WillByDefault(Return(TRUE));
		ON_CALL(*m_spMockJ1939MemoryBuffers, scl_j1939_get_mbuf_sa(Default::Mbuf()))
			.WillByDefault(Return(Default::RequesterSourceAddress()));
		SetIJ1939MemoryBuffers(m_spMockJ1939MemoryBuffers);


		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder.WithDeviceId(n_deviceIdEntry);
		for (unsigned i = 0; i < n_j1939DataLinkCount; ++i)
		{
			auto canPort = static_cast<Config::CanPort>(i);
			configBuilder.UsingJ1939DataLink(canPort);
		}
		SetSharkConfig(configBuilder.Build());
	}
	void RequestExtensionIdRead(unsigned linkIndex, unsigned extensionId)
	{
		auto const link = GetLink(linkIndex);
		auto const itFound = std::ranges::find_if(
			m_commandIdHandlers,
			[link, extensionId](auto const& extIdHandler)
			{
				return extIdHandler.link == link &&
				       extIdHandler.pHandler->command == n_extensionIdReadRequestByte &&
				       extIdHandler.pHandler->cat_id == extensionId;
			});
		ASSERT_THAT(itFound, Ne(m_commandIdHandlers.end()))
			<< "Could not find handler on link: " << static_cast<unsigned>(link);

		itFound->pHandler->context_parse_f(Default::Mbuf(), itFound->pHandler->context);
	}
	std::vector<TxMessage> const& GetTxMessages() const
	{
		return m_txMessages;
	}
	void ClearTxMessages()
	{
		m_txMessages.clear();
	}
	scl_j1939_link_t GetLink(unsigned index) const
	{
		return Utilities::narrow_cast<scl_j1939_link_t>(index);
	}
private:
	scl_j1939_link_t GetNextLink()
	{
		return m_nextLink++;
	}
	void AddCommandIdHandler(scl_j1939_link_t link, SCL_J1939_CAT_PPGN_ID_HDLR_t const* pHandler)
	{
		m_commandIdHandlers.emplace_back(ExtIdHandler{link, pHandler});
	}
	void QueueTxMessage(
		scl_j1939_link_t  link,
		unsigned_32       pgn,
		unsigned_8        destinationAddress,
		unsigned_8 const* pData,
		unsigned_16      dataLength)
	{
		TxMessage txMessage {
			link,
			pgn,
			destinationAddress,
			{pData, pData + dataLength}
		};
		m_txMessages.push_back(txMessage);
	}

	Utilities::default_shared_ptr<NiceMock<MockIJ1939>> m_spMockJ1939{};
	Utilities::default_shared_ptr<NiceMock<MockIJ1939MemoryBuffers>> m_spMockJ1939MemoryBuffers{};

	scl_j1939_link_t m_nextLink{};
	std::vector<ExtIdHandler> m_commandIdHandlers{};
	std::vector<TxMessage> m_txMessages{};
};

class J1939ExtensionIdFunctionalTests : public Test
{
protected:
	void ExpectThatTransmittedMessageMatchesExpected(unsigned linkIndex, unsigned pgn, std::span<uint8_t const> expectedData)
	{
		auto const& txMessages = m_harness.GetTxMessages();
		ASSERT_THAT(txMessages, SizeIs(1));
		auto const& txMessage = txMessages[0];
		EXPECT_THAT(txMessage.link, Eq(m_harness.GetLink(linkIndex)));
		EXPECT_THAT(txMessage.pgn, Eq(pgn));
		EXPECT_THAT(txMessage.destinationAddress, Eq(Default::RequesterSourceAddress()));
		EXPECT_THAT(txMessage.data, ElementsAreArray(expectedData));
	}
	TestExtensionIdHarness m_harness{};
};
TEST_F(J1939ExtensionIdFunctionalTests, F016MayBeRequestedOnAnyJ1939DataLinkWhenDeviceIdIsConfigured)
{
	// Given: Shark is configured with Device ID
	// And: Shark is started
	// When: F016 extension ID is requested on each J1939 data link
	// Then: Shark responds with the Device ID data on each link

	m_harness.StartShark();

	for (unsigned linkIndex = 0; linkIndex < n_j1939DataLinkCount; ++linkIndex)
	{
		m_harness.RequestExtensionIdRead(linkIndex, 0xF016);
		ExpectThatTransmittedMessageMatchesExpected(linkIndex, n_propAPgn, n_expectedF016Data);
		m_harness.ClearTxMessages();
	}
}
}