/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Machine Security System Functional Tests

#include "Kraken/MockICsfAtsJ1939.h"
#include "Kraken/MockICsfSidmc.h"
#include "Kraken/MockIJ1939.h"
#include "Utilities/Kraken/FakeClock.h"
#include "SharkByteDetails.h"
#include "SimpleSharkConfigBuilder.h"
#include "TestHarness.h"
#include <SharkConfiguration.pb.h>
#include <Utilities/CountOf.h>
#include <Utilities/DefaultSmartPointers.h>
#include <Utilities/TestUtilities.h>
#include <vector>

using namespace Shark::Kraken;
using namespace Shark::SharkByteDetails::MachineSecuritySystem;
using namespace std::chrono_literals;
using namespace testing;

namespace FunctionalTests
{
namespace
{
struct Default
{
	static constexpr Config::CanPort CanPort() { return Config::CanPort::Can1; }
	static constexpr uint8_t Address() { return 0x21; }
	static constexpr Config::MachineSecuritySystemEntry MssConfig()
	{
		return Config::MachineSecuritySystemEntry{CanPort(), Address()};
	}
	static constexpr std::vector<uint8_t> LogInId(){
		return std::vector<uint8_t>{0x31, 0x32, 0x33, 0x34};}
	static csf_sidmc_key_info_t KeyInfo()
	{
		static uint_least8_t description[] = {'d', 'e', 's', 'c'};
		csf_sidmc_key_info_t keyInfo
		{
			CSF_SIDMC_PASSWORD_ID,
			CSF_SIDMC_SECID_DOES_NOT_EXPIRE,
			CSF_SIDMC_MASTER,
			{},
			6,
			Utilities::CountOf(description),
			{'0', '1', '2', '3', '4', ' '},
			description
		};
		return keyInfo;
	}
};

class TestMachineSecuritySystemHarness : public TestHarness
{
public:
	TestMachineSecuritySystemHarness()
	{
		SetIJ1939(m_spMockJ1939);

		ON_CALL(*m_spMockCsfAtsJ1939, csf_ats_j1939_client_init(_, _, _))
			.WillByDefault(DoAll(
				SaveArgPointee<0>(&m_atsJ1939Config),
				Return(CSF_ATS_J1939_CLIENT_SUCCESS)));
		ON_CALL(*m_spMockCsfAtsJ1939, csf_ats_j1939_client_cmd_req(_))
			.WillByDefault(DoAll(
				SaveArg<0>(&m_lastAtsJ1939CmdReq),
				Return(CSF_ATS_J1939_CLIENT_SUCCESS)));
		SetICsfAtsJ1939(m_spMockCsfAtsJ1939);

		ON_CALL(*m_spMockCsfSidmc, csf_sidmc_init(_, _, _))
			.WillByDefault(DoAll(
				SaveArgPointee<2>(&m_sidmcConfig),
				Return(CSF_SIDMC_SUCCESS)));
		ON_CALL(*m_spMockCsfSidmc, csf_sidmc_cmd_req(_, _))
			.WillByDefault(DoAll(
				SaveArg<0>(&m_lastSidmcCommand),
				Return(CSF_SIDMC_SUCCESS)));
		SetICsfSidmc(m_spMockCsfSidmc);

		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder
			.WithMachineSecuritySystem(Default::MssConfig())
			.UsingJ1939DataLink(Default::CanPort());
		SetSharkConfig(configBuilder.Build());
	}

	csf_ats_j1939_client_config_t const& GetAtsConfig() const
	{
		return m_atsJ1939Config;
	}
	std::optional<csf_ats_j1939_cmd_req_t> const& GetLastAtsJ1939CmdReq() const
	{
		return m_lastAtsJ1939CmdReq;
	}
	std::optional<csf_sidmc_cmd_t> const& GetLastSidmcCommand() const
	{
		return m_lastSidmcCommand;
	}
	csf_sidmc_config_t const& GetSidmcConfig() const
	{
		return m_sidmcConfig;
	}
private:
	Utilities::default_shared_ptr<NiceMock<MockIJ1939>> m_spMockJ1939{};
	Utilities::default_shared_ptr<NiceMock<MockICsfAtsJ1939>> m_spMockCsfAtsJ1939{};
	Utilities::default_shared_ptr<NiceMock<MockICsfSidmc>> m_spMockCsfSidmc{};

	csf_ats_j1939_client_config_t m_atsJ1939Config{};
	std::optional<csf_ats_j1939_cmd_req_t> m_lastAtsJ1939CmdReq{};
	std::optional<csf_sidmc_cmd_t> m_lastSidmcCommand{};
	csf_sidmc_config_t m_sidmcConfig{};
};

class MachineSecuritySystemFunctionalTests : public Test
{
protected:
	void SendWriteCommand(std::string const& id, std::vector<uint8_t> const& value)
	{
		m_harness.WriteSharkByteValue(id, value, m_mockWriteSharkByteCompletedHandler.AsStdFunction());
		m_harness.AdvanceClockBy(1ms);
	}
	void SendCurrentOperatorResponse()
	{
		auto const& sidmcConfig = m_harness.GetSidmcConfig();
		auto const keyInfo = Default::KeyInfo();
		sidmcConfig.csf_sidmc_notify_clbk(
			CSF_SIDMC_READ_ID,
			CSF_SIDMC_SUCCESS,
			&keyInfo,
			sidmcConfig.context_ptr);
		m_harness.AdvanceClockBy(1ms);
	}
	void CallSidmcCallbackWithFailure()
	{
		auto const& sidmcConfig = m_harness.GetSidmcConfig();
		sidmcConfig.csf_sidmc_notify_clbk(
			CSF_SIDMC_READ_ID,
			CSF_SIDMC_INVALID_CMD,
			nullptr,
			sidmcConfig.context_ptr);
		m_harness.AdvanceClockBy(1ms);
	}
	void ExpectThatMachineSecuritySystemIsEnabled()
	{
		auto const atsConfig = m_harness.GetAtsConfig();
		EXPECT_THAT(atsConfig.serv_addr, Eq(Default::Address()));

		auto const sidmcConfig = m_harness.GetSidmcConfig();
		EXPECT_THAT(sidmcConfig.serv_addr, Eq(Default::Address()));
	}
	void ExpectThatCommandWasSentToAtsJ1939WithId(
		csf_ats_j1939_client_cmd_t command,
		std::vector<uint8_t> const& expectedId)
	{
		auto const& lastCmdReq = m_harness.GetLastAtsJ1939CmdReq();
		ASSERT_TRUE(lastCmdReq.has_value());
		EXPECT_THAT(lastCmdReq->ats_cmd, Eq(command));
		EXPECT_THAT(
			std::vector<uint8_t>(
				lastCmdReq->user_pwd,
				lastCmdReq->user_pwd + lastCmdReq->user_pwd_len),
			ContainerEq(expectedId));
	}
	void ExpectThatNoCommandWasSentToAtsJ1939()
	{
		EXPECT_FALSE(m_harness.GetLastAtsJ1939CmdReq().has_value());
	}
	void ExpectThatRequestWasSentToSidmc(csf_sidmc_cmd_t command)
	{
		auto const& lastCommand = m_harness.GetLastSidmcCommand();
		ASSERT_TRUE(lastCommand.has_value());
		EXPECT_THAT(*lastCommand, Eq(command));
	}
	void ExpectThatOperatorSharkBytesArePopulated()
	{
		EXPECT_THAT(m_harness.GetSharkByteValue(OperatorDetected()), Eq(Shark::TrueSharkByteValue()));
		EXPECT_THAT(m_harness.GetSharkByteValue(OperatorIsGuest()), Eq(Shark::FalseSharkByteValue()));
		EXPECT_THAT(m_harness.GetSharkByteValue(OperatorIsMaster()), Eq(Shark::TrueSharkByteValue()));
	}
	void CallAtsCallbackWithStatus(csf_ats_j1939_status_t status)
	{
		auto const& atsConfig = m_harness.GetAtsConfig();
		atsConfig.p_serv_status_notify_clbk(status);
		m_harness.AdvanceClockBy(1ms);
	}
	void ExpectThatStatusSharkByteIs(std::string const& id, bool expectedValue)
	{
		auto&& value = m_harness.GetSharkByteValue(id);
		ASSERT_TRUE(value.has_value());
		EXPECT_THAT(*value, Eq(expectedValue ? Shark::TrueSharkByteValue() : Shark::FalseSharkByteValue()));
	}
	void ExpectThatWriteSharkByteCompletedHandlerWasCalled()
	{
		EXPECT_CALL(m_mockWriteSharkByteCompletedHandler, Call(_));
	}

	NiceMock<MockFunction<void(Shark::SharkByteValue const&)>> m_mockWriteSharkByteCompletedHandler{};
	TestMachineSecuritySystemHarness m_harness{};
};
TEST_F(MachineSecuritySystemFunctionalTests, MachineSecuritySystemIsEnabledOnConfiguredJ1939DataLink)
{
	// Given: Shark is configured to support machine security system
	//  When: Shark is started
	//  Then: All machine security system libraries are initialized

	m_harness.StartShark();
	ExpectThatMachineSecuritySystemIsEnabled();
}
TEST_F(MachineSecuritySystemFunctionalTests, LogInCommandIsSentToAtsJ1939WhenRequested)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//  When: A Log In is requested with a log in identifier
	//  Then: A Log In request is sent to the csf_ats_j1939 library with the log in identifier

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::LogIn(), Default::LogInId());
	ExpectThatCommandWasSentToAtsJ1939WithId(CSF_ATS_J1939_CLIENT_CMD_LOGIN, Default::LogInId());
}
TEST_F(MachineSecuritySystemFunctionalTests, LogInCommandSuccessfulUpdateIsHandledCorrectly)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: A Log In is requested with a log in identifier
	//  When: A response is received from the csf_ats_j1939 library that the log in is successful
	//  Then: The log in status shark byte is set to true
	//   And: The write shark byte completed handler is called

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::LogIn(), Default::LogInId());
	ExpectThatWriteSharkByteCompletedHandlerWasCalled();
	CallAtsCallbackWithStatus(CSF_ATS_J1939_LOGIN_SUCCESSFUL);
	ExpectThatStatusSharkByteIs(Shark::SharkByteDetails::MachineSecuritySystem::LogInStatus(), true);
}
TEST_F(MachineSecuritySystemFunctionalTests, LogInCommandFailedUpdateIsHandledCorrectly)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: A Log In is requested with a log in identifier
	//  When: A response is received from the csf_ats_j1939 library that the log in is unsuccessful
	//  Then: The log in status shark byte is set to false
	//   And: The write shark byte completed handler is called

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::LogIn(), Default::LogInId());
	ExpectThatWriteSharkByteCompletedHandlerWasCalled();
	CallAtsCallbackWithStatus(CSF_ATS_J1939_INVALID_PASSWORD);
	ExpectThatStatusSharkByteIs(Shark::SharkByteDetails::MachineSecuritySystem::LogInStatus(), false);
}
TEST_F(MachineSecuritySystemFunctionalTests, LogOutCommandDoesNotSendLogInWhenCurrentLoginMethodIsUnknown)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: The current operator's log in method is unknown
	//  When: A Log Out is requested
	//  Then: No request is sent to the csf_ats_j1939 library

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::LogOut(), {});
	ExpectThatNoCommandWasSentToAtsJ1939();
}
TEST_F(MachineSecuritySystemFunctionalTests, LogOutCommandIsSentToAtsJ1939WhenRequested)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: The current operator's log in method is known
	//  When: A Log Out is requested
	//  Then: A Log In request is sent to the csf_ats_j1939 library with a blank password

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::RequestCurrentOperator(), {});
	SendCurrentOperatorResponse();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::LogIn(), {});
	ExpectThatCommandWasSentToAtsJ1939WithId(CSF_ATS_J1939_CLIENT_CMD_LOGIN, {});
}
TEST_F(MachineSecuritySystemFunctionalTests, LogOutCommandSuccessfulUpdateIsHandledCorrectly)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: The current operator's log in method is known
	//   And: A Log Out is requested
	//  When: A response is received from the csf_ats_j1939 library that the log out is successful
	//  Then: The log out status shark byte is set to true
	//   And: The write shark byte completed handler is called

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::RequestCurrentOperator(), {});
	SendCurrentOperatorResponse();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::LogOut(), {});
	ExpectThatWriteSharkByteCompletedHandlerWasCalled();
	CallAtsCallbackWithStatus(CSF_ATS_J1939_LOGIN_SUCCESSFUL);
	ExpectThatStatusSharkByteIs(Shark::SharkByteDetails::MachineSecuritySystem::LogOutStatus(), true);
}
TEST_F(MachineSecuritySystemFunctionalTests, LogOutCommandFailedUpdateIsHandledCorrectly)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: The current operator's log in method is known
	//   And: A Log Out is requested
	//  When: A response is received from the csf_ats_j1939 library that the log out is unsuccessful
	//  Then: The log out status shark byte is set to false
	//   And: The write shark byte completed handler is called

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::RequestCurrentOperator(), {});
	SendCurrentOperatorResponse();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::LogOut(), {});
	ExpectThatWriteSharkByteCompletedHandlerWasCalled();
	CallAtsCallbackWithStatus(CSF_ATS_J1939_INVALID_PASSWORD);
	ExpectThatStatusSharkByteIs(Shark::SharkByteDetails::MachineSecuritySystem::LogOutStatus(), false);
}
TEST_F(MachineSecuritySystemFunctionalTests, LockCommandIsSentToAtsJ1939WhenRequested)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//  When: A Lock is requested
	//  Then: A Lock request is sent to the csf_ats_j1939 library with a blank password

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::Lock(), {});
	ExpectThatCommandWasSentToAtsJ1939WithId(CSF_ATS_J1939_CLIENT_CMD_LOCK, {});
}
TEST_F(MachineSecuritySystemFunctionalTests, LockCommandSuccessfulUpdateIsHandledCorrectly)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: A Lock is requested
	//  When: A response is received from the csf_ats_j1939 library that the lock is successful
	//  Then: The lock status shark byte is set to true
	//   And: The write shark byte completed handler is called

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::Lock(), {});
	ExpectThatWriteSharkByteCompletedHandlerWasCalled();
	CallAtsCallbackWithStatus(CSF_ATS_J1939_LOCKED);
	ExpectThatStatusSharkByteIs(Shark::SharkByteDetails::MachineSecuritySystem::LockStatus(), true);
}
TEST_F(MachineSecuritySystemFunctionalTests, LockCommandFailedUpdateIsHandledCorrectly)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: A Lock is requested
	//  When: A response is received from the csf_ats_j1939 library that the lock is unsuccessful
	//  Then: The lock status shark byte is set to false
	//   And: The write shark byte completed handler is called

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::Lock(), {});
	ExpectThatWriteSharkByteCompletedHandlerWasCalled();
	CallAtsCallbackWithStatus(CSF_ATS_J1939_INVALID_PASSWORD);
	ExpectThatStatusSharkByteIs(Shark::SharkByteDetails::MachineSecuritySystem::LockStatus(), false);
}
TEST_F(MachineSecuritySystemFunctionalTests, UnlockCommandIsSentToAtsJ1939WhenRequested)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//  When: An Unlock is requested
	//  Then: An Unlock request is sent to the csf_ats_j1939 library with a valid password

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::Unlock(), Default::LogInId());
	ExpectThatCommandWasSentToAtsJ1939WithId(CSF_ATS_J1939_CLIENT_CMD_UNLOCK, Default::LogInId());
}
TEST_F(MachineSecuritySystemFunctionalTests, UnlockCommandSuccessfulUpdateIsHandledCorrectly)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: An Unlock is requested
	//  When: A response is received from the csf_ats_j1939 library that the unlock is successful
	//  Then: The unlock status shark byte is set to true
	//   And: The write shark byte completed handler is called

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::Unlock(), Default::LogInId());
	ExpectThatWriteSharkByteCompletedHandlerWasCalled();
	CallAtsCallbackWithStatus(CSF_ATS_J1939_UNLOCKED);
	ExpectThatStatusSharkByteIs(Shark::SharkByteDetails::MachineSecuritySystem::UnlockStatus(), true);
}
TEST_F(MachineSecuritySystemFunctionalTests, UnlockCommandFailedUpdateIsHandledCorrectly)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: An Unlock is requested
	//  When: A response is received from the csf_ats_j1939 library that the unlock is unsuccessful
	//  Then: The unlock status shark byte is set to false
	//   And: The write shark byte completed handler is called

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::Unlock(), Default::LogInId());
	ExpectThatWriteSharkByteCompletedHandlerWasCalled();
	CallAtsCallbackWithStatus(CSF_ATS_J1939_INVALID_PASSWORD);
	ExpectThatStatusSharkByteIs(Shark::SharkByteDetails::MachineSecuritySystem::UnlockStatus(), false);
}
TEST_F(MachineSecuritySystemFunctionalTests, RequestCurrentOperatorCommandIsSentToSidmcWhenRequested)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//  When: Current Operator is requested
	//  Then: An operator write request is sent to the csf_sidmc library

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::RequestCurrentOperator(), {});
	ExpectThatRequestWasSentToSidmc(CSF_SIDMC_READ_ID);
}
TEST_F(MachineSecuritySystemFunctionalTests, RequestCurrentOperatorCommandSuccessfulUpdateIsHandledCorrectly)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: Current Operator is requested
	//  When: A response is received from the csf_sidmc library with the current operator
	//  Then: The request operator status shark byte is set to true
	//   And: The write shark byte completed handler is called

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::RequestCurrentOperator(), {});
	ExpectThatWriteSharkByteCompletedHandlerWasCalled();
	SendCurrentOperatorResponse();
	ExpectThatStatusSharkByteIs(Shark::SharkByteDetails::MachineSecuritySystem::OperatorRequestStatus(), true);
}
TEST_F(MachineSecuritySystemFunctionalTests, RequestCurrentOperatorCommandFailedUpdateIsHandledCorrectly)
{
	// Given: Shark is configured to support machine security system
	//   And: Shark is started
	//   And: Current Operator is requested
	//  When: A response is received from the csf_sidmc library that the request is unsuccessful
	//  Then: The request operator status shark byte is set to false
	//   And: The write shark byte completed handler is called

	m_harness.StartShark();

	SendWriteCommand(Shark::SharkByteDetails::MachineSecuritySystem::RequestCurrentOperator(), {});
	ExpectThatWriteSharkByteCompletedHandlerWasCalled();
	CallSidmcCallbackWithFailure();
	ExpectThatStatusSharkByteIs(Shark::SharkByteDetails::MachineSecuritySystem::OperatorRequestStatus(), false);
}
}
}