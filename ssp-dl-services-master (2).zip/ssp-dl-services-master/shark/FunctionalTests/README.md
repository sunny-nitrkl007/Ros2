# Shark Functional Tests

These functional tests are written to be black box tests based on requirements. They will validate that our Shark code is doing what is expected with respect to the protocols.

Eventually each test will be mapped to a requirement so that a "requirements coverage percentage" will be measurable.

## Implementation Notes

- Cucumber-cpp and gherkin will not be used due to their clunky REGEX matching and client/server architecture.
- Instead, regular Google Tests will be written, but the test cases themselves must follow these rules:
  - Given/When/Then is provided as comments in the tests
  - The code in a test function must be minimal -- the "given, when, then" actions and checks should be obvious.
  - Eventually each test case will be traceable to a specific requirement. (That mechanism is TBD.)
- A common `TestHarness` class will be used to reduce duplication across tests.
