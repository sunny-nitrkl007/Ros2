/// \copyright
/// Copyright (C) Caterpillar Inc. All Rights Reserved.
///
/// \file
/// Calibration and Service Test Functional Tests

#include "Kraken/MockIJ1939.h"
#include "Kraken/MockISclCalClient.h"
#include "CalibrationCommandTestUtilities.h"
#include "SharkByteDetails.h"
#include "SimpleSharkConfigBuilder.h"
#include "TestHarness.h"
#include <Utilities/DefaultSmartPointers.h>
#include <Utilities/TestUtilities.h>
#include <nlohmann/json.hpp>
#include <scl_cal_client.h>
#include <array>
#include <optional>
#include <span>
#include <string>
#include <vector>

using namespace Shark::Kraken;
using namespace Shark::SharkByteDetails::Calibrations;
using namespace testing;

namespace FunctionalTests
{
namespace
{
using Shark::TestUtilities::Calibrations::MakeCommand;

enum Type
{
	Calibration,
	ServiceTest
};

struct Any
{
	static constexpr uint_least16_t StepNumber() { return 42; }
};
struct Default
{
	static constexpr Config::CanPort CanPort() { return Config::CanPort::Can0; }
	static constexpr uint8_t Address() { return 0x21; }
	static constexpr uint_least8_t LinkIndex() { return 5; }
	static constexpr uint_least8_t PeerIndex() { return 8; }
	static constexpr uint_least8_t CalibrationServiceIndex() { return 3; }
	static constexpr uint_least8_t ServiceTestServiceIndex() { return 4; }

	static constexpr unsigned CalibrationIndex() { return 0x0010; }
	static constexpr char const* CalibrationName() { return "Calibration_0010"; }
	static constexpr unsigned ServiceTestIndex() { return 0x1020; }
	static constexpr char const* ServiceTestName() { return "ServiceTest_1020"; }
};

constexpr Config::CalibrationServiceDataEntry n_calibrationEntries[]
{
	{ Default::CalibrationIndex(), Default::CalibrationName() },
};
constexpr Config::CalibrationServiceDataEntry n_serviceTestEntries[]
{
	{ Default::ServiceTestIndex(), Default::ServiceTestName() },
};
constexpr Config::CalibrationServicesEntry n_calibrationServicesEntry
{
	n_calibrationEntries,
	n_serviceTestEntries,
};
}

class TestCalibrationHarness : public TestHarness
{
public:
	TestCalibrationHarness()
	{
		SetIJ1939(m_spMockJ1939);

		ON_CALL(*m_spMockSclCalClient, scl_cal_client_link_add_j1939(_, _, _))
			.WillByDefault(DoAll(
				SetArgPointee<2>(SCL_CAL_CLIENT_SUCCESS),
				Return(Default::LinkIndex())));
		ON_CALL(*m_spMockSclCalClient, scl_cal_client_link_add_peer_by_addr(_, _, _))
			.WillByDefault(DoAll(
				SetArgPointee<2>(SCL_CAL_CLIENT_SUCCESS),
				Return(Default::PeerIndex())));
		ON_CALL(*m_spMockSclCalClient, scl_cal_client_peer_add_svc(_, SCL_CAL_CLIENT_SVC_TYPE_CAL, _, _, _))
			.WillByDefault(DoAll(
				SaveArg<2>(&m_statusCallback),
				SaveArg<3>(&m_statusCallbackContext),
				SetArgPointee<4>(SCL_CAL_CLIENT_SUCCESS),
				Return(Default::CalibrationServiceIndex())));
		ON_CALL(*m_spMockSclCalClient, scl_cal_client_peer_add_svc(_, SCL_CAL_CLIENT_SVC_TYPE_SRVTST, _, _, _))
			.WillByDefault(DoAll(
				SaveArg<2>(&m_statusCallback),
				SaveArg<3>(&m_statusCallbackContext),
				SetArgPointee<4>(SCL_CAL_CLIENT_SUCCESS),
				Return(Default::ServiceTestServiceIndex())));
		ON_CALL(*m_spMockSclCalClient, scl_cal_client_start_svc(_, _))
			.WillByDefault(DoAll(
				SaveArg<0>(&m_lastStartedId),
				Return(SCL_CAL_CLIENT_SUCCESS)));
		ON_CALL(*m_spMockSclCalClient, scl_cal_client_user_action(_, _, _, _))
			.WillByDefault(Invoke(this, &TestCalibrationHarness::SaveUserAction));
		SetISclCalClient(m_spMockSclCalClient);

		Shark::SimpleSharkConfigBuilder configBuilder{};
		configBuilder
			.UsingJ1939DataLink(Default::CanPort())
				.UsingPeerNode(Default::Address())
					.WithCalibrationServices(n_calibrationServicesEntry);
		SetSharkConfig(configBuilder.Build());
	}
	MockISclCalClient& GetMockSclCalClient()
	{
		return *m_spMockSclCalClient;
	}
	void InvokeStatusCallback(
		uint_least16_t id,
		uint_least8_t status,
		uint_least16_t stepNumber,
		std::vector<uint_least16_t> const& errors = {})
	{
		assert(m_statusCallback);
		m_statusCallback(
			id,
			status,
			stepNumber,
			errors.data(),
			Utilities::narrow_cast<uint_least8_t>(errors.size()),
			m_statusCallbackContext);
	}
	struct UserAction
	{
		scl_cal_client_ac_t command;
		std::vector<uint_least8_t> data;
		uint_least8_t serviceIndex;
	};
	std::optional<UserAction> const& GetLastAction() const
	{
		return m_lastAction;
	}
	uint_least16_t GetLastStartedId() const
	{
		return m_lastStartedId;
	}
private:
	scl_cal_client_status_t SaveUserAction(
		scl_cal_client_ac_t command,
		uint_least8_t* pData,
		uint_least8_t dataLength,
		uint_least8_t serviceIndex)
	{
		m_lastAction.emplace(UserAction{
			command,
			std::vector<uint_least8_t>(pData, pData + dataLength),
			serviceIndex});
		return SCL_CAL_CLIENT_SUCCESS;
	}

	Utilities::default_shared_ptr<NiceMock<MockIJ1939>> m_spMockJ1939{};
	Utilities::default_shared_ptr<NiceMock<MockISclCalClient>> m_spMockSclCalClient{};

	scl_cal_client_notify_app_status_t m_statusCallback{};
	void* m_statusCallbackContext{};
	uint_least16_t m_lastStartedId{};
	std::optional<UserAction> m_lastAction{};
};

class CalibrationFunctionalTests : public Test
{
protected:
	void SendCommand(std::vector<uint8_t> const& command)
	{
		m_harness.WriteSharkByteValue(
			Command::SharkByteId(),
			command,
			[](Shark::SharkByteValue const&){});
		// Run the periodic task twice, once for the command message and once for the completion callback
		m_harness.GetFakeOel().ExecuteAllTasks();
		m_harness.GetFakeOel().ExecuteAllTasks();
	}
	void SendEngageCommand(std::string const& name)
	{
		SendCommand(MakeCommand(Command::Engage(), name));
	}
	void SendCallbackWithStatus(uint_least8_t status)
	{
		m_harness.InvokeStatusCallback(Default::CalibrationIndex(), status, Any::StepNumber(), {});
	}
	void EngageAndStartCalibration(std::string const& name)
	{
		SendEngageCommand(name);
		SendCallbackWithStatus(SCL_CAL_CLIENT_STAT_ENABLED_START_WAIT);
		SendCommand(MakeCommand(Command::Proceed()));
		SendCallbackWithStatus(SCL_CAL_CLIENT_STAT_EXEC);
	}
	void DrainWorkQueue()
	{
		m_harness.GetFakeOel().ExecuteAllTasks();
	}
	nlohmann::json GetStatusSharkByteAsJson()
	{
		auto const& value = m_harness.GetSharkByteValue(Status::SharkByteId());
		assert(value);
		std::string const jsonString(value->begin(), value->end());
		return nlohmann::json::parse(jsonString);
	}
	void ExpectThatStatusSharkByteIsInvalid()
	{
		EXPECT_THAT(m_harness.GetSharkByteValue(Status::SharkByteId()), Eq(std::nullopt));
	}
	void ExpectEngageAndStartFor(Type type)
	{
		auto& mockSclCalClient = m_harness.GetMockSclCalClient();
		InSequence inSequence{};
		EXPECT_CALL(mockSclCalClient, scl_cal_client_link_add_peer_by_addr(
			Default::LinkIndex(),
			Default::Address(),
			_));
		EXPECT_CALL(mockSclCalClient, scl_cal_client_peer_add_svc(
			Default::PeerIndex(),
			type == Type::Calibration ? SCL_CAL_CLIENT_SVC_TYPE_CAL : SCL_CAL_CLIENT_SVC_TYPE_SRVTST, _, _, _));
		EXPECT_CALL(mockSclCalClient, scl_cal_client_start_svc(
			type == Type::Calibration ? Default::CalibrationIndex() : Default::ServiceTestIndex(),
			type == Type::Calibration ? Default::CalibrationServiceIndex() : Default::ServiceTestServiceIndex()));
	}

	TestCalibrationHarness m_harness{};
};
TEST_F(CalibrationFunctionalTests, SclCalClientIsInitializedOnConfiguredJ1939DataLinkWhenCalibrationsAreConfigured)
{
	// Given: Shark is configured with calibrations and service tests on a J1939 data link
	//  When: Shark is started
	//  Then: The SCL Cal Client library is initialized and the configured J1939 link is added

	EXPECT_CALL(m_harness.GetMockSclCalClient(), scl_cal_client_init());
	EXPECT_CALL(m_harness.GetMockSclCalClient(), scl_cal_client_link_add_j1939(MockIJ1939::Default::Link(), _, _));
	m_harness.StartShark();
}
TEST_F(CalibrationFunctionalTests, EngageCommandAddsPeerAndCalibrationServiceAndStartsItForACalibration)
{
	// Given: Shark is configured with a calibration
	//   And: Shark is started
	//  When: An Engage command is sent with the configured calibration's middleware id
	//  Then: A peer is added, a calibration service is added, and the calibration is started

	m_harness.StartShark();
	ExpectEngageAndStartFor(Type::Calibration);
	SendEngageCommand(Default::CalibrationName());
}
TEST_F(CalibrationFunctionalTests, EngageCommandAddsPeerAndServiceTestServiceAndStartsItForAServiceTest)
{
	// Given: Shark is configured with a service test
	//   And: Shark is started
	//  When: An Engage command is sent with the configured service test's middleware id
	//  Then: A peer is added, a service test service is added, and the service test is started

	m_harness.StartShark();
	ExpectEngageAndStartFor(Type::ServiceTest);
	SendEngageCommand(Default::ServiceTestName());
}
TEST_F(CalibrationFunctionalTests, EngageCommandWithUnknownNameDoesNotStartAnyService)
{
	// Given: Shark is configured with calibrations and service tests
	//   And: Shark is started
	//  When: An Engage command is sent with a middleware id that is not configured
	//  Then: No peer or service is added and no service is started

	m_harness.StartShark();
	auto& mockSclCalClient = m_harness.GetMockSclCalClient();
	EXPECT_CALL(mockSclCalClient, scl_cal_client_link_add_peer_by_addr(_, _, _)).Times(0);
	EXPECT_CALL(mockSclCalClient, scl_cal_client_peer_add_svc(_, _, _, _, _)).Times(0);
	EXPECT_CALL(mockSclCalClient, scl_cal_client_start_svc(_, _)).Times(0);

	SendEngageCommand("UnknownCalibration");
}
TEST_F(CalibrationFunctionalTests, StatusCallbackPopulatesStatusSharkByteJson)
{
	// Given: Shark is configured with a calibration
	//   And: Shark is started
	//   And: A calibration is engaged
	//  When: The SCL Cal Client library reports a status update
	//  Then: The calibration status shark byte contains a JSON document with the
	//        calibration's name, type, executing status, step number, and errors

	m_harness.StartShark();
	SendEngageCommand(Default::CalibrationName());

	std::vector<uint_least16_t> const errors{0x1234, 0x5678};
	m_harness.InvokeStatusCallback(Default::CalibrationIndex(), SCL_CAL_CLIENT_STAT_EXEC, 42, errors);

	auto const json = GetStatusSharkByteAsJson();
	EXPECT_THAT(json[Status::FieldName()].get<std::string>(), Eq(Default::CalibrationName()));
	EXPECT_THAT(json[Status::FieldType()].get<std::string>(), Eq("calibration"));
	EXPECT_THAT(json[Status::FieldStatus()].get<std::string>(), Eq("executing"));
	EXPECT_THAT(json[Status::FieldStep()].get<uint_least16_t>(), Eq(42));
	EXPECT_THAT(json[Status::FieldErrors()].get<std::vector<uint_least16_t>>(), ElementsAreArray(errors));
}
TEST_F(CalibrationFunctionalTests, ProceedCommandSendsStartUserActionAfterCalibrationIsEnabled)
{
	// Given: Shark is configured with a calibration
	//   And: Shark is started
	//   And: A calibration is engaged
	//   And: The SCL Cal Client library reports the calibration is enabled and waiting to start
	//  When: A Proceed command is sent
	//  Then: A Start user action is sent to the SCL Cal Client library

	m_harness.StartShark();
	SendEngageCommand(Default::CalibrationName());
	SendCallbackWithStatus(SCL_CAL_CLIENT_STAT_ENABLED_START_WAIT);
	SendCommand(MakeCommand(Command::Proceed()));

	ASSERT_TRUE(m_harness.GetLastAction());
	EXPECT_THAT(m_harness.GetLastAction()->command, Eq(SCL_CAL_CLIENT_AC_START));
	EXPECT_THAT(m_harness.GetLastAction()->serviceIndex, Eq(Default::CalibrationServiceIndex()));
}
TEST_F(CalibrationFunctionalTests, ProceedCommandSendsContinueUserActionWhileCalibrationIsExecuting)
{
	// Given: Shark is configured with a calibration
	//   And: Shark is started
	//   And: A calibration is engaged and executing
	//   And: A Proceed command is sent to start the calibration
	//   And: The SCL Cal Client library reports the calibration is executing
	//  When: Another Proceed command is sent
	//  Then: A Continue user action is sent to the SCL Cal Client library

	m_harness.StartShark();
	EngageAndStartCalibration(Default::CalibrationName());

	SendCommand(MakeCommand(Command::Proceed()));

	ASSERT_TRUE(m_harness.GetLastAction());
	EXPECT_THAT(m_harness.GetLastAction()->command, Eq(SCL_CAL_CLIENT_AC_CONTINUE));
}
TEST_F(CalibrationFunctionalTests, AbortCommandAbortsTheActiveService)
{
	// Given: Shark is configured with a calibration
	//   And: Shark is started
	//   And: A calibration is engaged and executing
	//   And: A Proceed command is sent to start the calibration
	//  When: An Abort command is sent
	//  Then: The active service is aborted

	m_harness.StartShark();
	EngageAndStartCalibration(Default::CalibrationName());

	EXPECT_CALL(m_harness.GetMockSclCalClient(),
		scl_cal_client_abort_svc(Default::CalibrationServiceIndex()));

	SendCommand(MakeCommand(Command::Abort()));
}
TEST_F(CalibrationFunctionalTests, DisengageAfterSuccessfulCompletionEndsTheService)
{
	// Given: Shark is configured with a calibration
	//   And: Shark is started
	//   And: A calibration is engaged and executing
	//   And: A Proceed command is sent to start the calibration
	//   And: The SCL Cal Client library reports the calibration completed successfully
	//  When: A Disengage command is sent
	//  Then: The active service is ended
	//  When: The SCL_CAL_CLIENT_STAT_DISABLED status is reported
	//  Then: The active peer is removed

	m_harness.StartShark();
	EngageAndStartCalibration(Default::CalibrationName());
	SendCallbackWithStatus(SCL_CAL_CLIENT_STAT_SUCCESS_NO_ERR_WARN);

	EXPECT_CALL(m_harness.GetMockSclCalClient(),
		scl_cal_client_end_svc(Default::CalibrationServiceIndex()));

	SendCommand(MakeCommand(Command::Disengage()));
	SendCallbackWithStatus(SCL_CAL_CLIENT_STAT_DISABLED);

	EXPECT_CALL(m_harness.GetMockSclCalClient(),
		scl_cal_client_remove_peer(Default::PeerIndex()));

	DrainWorkQueue();
}
TEST_F(CalibrationFunctionalTests, FinishedServiceTestSendsStopUserActionWhileServiceTestIsExecuting)
{
	// Given: Shark is configured with a service test
	//   And: Shark is started
	//   And: A service test is engaged and executing
	//  When: A FinishedServiceTest command is sent
	//  Then: A StopSrvTest user action is sent to the SCL Cal Client library

	m_harness.StartShark();
	EngageAndStartCalibration(Default::ServiceTestName());

	SendCommand(MakeCommand(Command::FinishedServiceTest()));

	ASSERT_TRUE(m_harness.GetLastAction());
	EXPECT_THAT(m_harness.GetLastAction()->command, Eq(SCL_CAL_CLIENT_AC_STOP_SRVTST));
	EXPECT_THAT(m_harness.GetLastAction()->serviceIndex, Eq(Default::ServiceTestServiceIndex()));
}
namespace
{
struct CommandMapping
{
	char const* command;
	std::optional<unsigned> context;
	scl_cal_client_ac_t expectedUserAction;
	std::span<uint8_t const> expectedData;
};
constexpr std::array<uint8_t, 1> n_zeroData{0};
constexpr std::array<uint8_t, 2> n_goToStepData{0x02, 0x01};
constexpr std::array<uint8_t, 1> n_commandButtonData{0x03};

constexpr CommandMapping n_commandMappings[]
{
	{ Command::YesAffirmation(),        std::nullopt, SCL_CAL_CLIENT_AC_YES,          n_zeroData },
	{ Command::NoAffirmation(),         std::nullopt, SCL_CAL_CLIENT_AC_NO,           n_zeroData },
	{ Command::SmallIncrement(),        std::nullopt, SCL_CAL_CLIENT_AC_INCR_SMALL_1, n_zeroData },
	{ Command::SmallDecrement(),        std::nullopt, SCL_CAL_CLIENT_AC_DECR_SMALL_1, n_zeroData },
	{ Command::LargeIncrement(),        std::nullopt, SCL_CAL_CLIENT_AC_INCR_LARGE_1, n_zeroData },
	{ Command::LargeDecrement(),        std::nullopt, SCL_CAL_CLIENT_AC_DECR_LARGE_1, n_zeroData },
	{ Command::RevertToDefaultValues(), std::nullopt, SCL_CAL_CLIENT_AC_REV_DEF_VAL,  n_zeroData },
	{ Command::GoToStep(),              0x0201,       SCL_CAL_CLIENT_AC_GOTO,         n_goToStepData },
	{ Command::CommandButton(),         0x03,         SCL_CAL_CLIENT_AC_CMD_BTN,      n_commandButtonData },
};
}
TEST_F(CalibrationFunctionalTests, CommandSendsDefinedUserActionWhenCalibrationIsExecuting)
{
	// Given: Shark is configured with a calibration
	//   And: Shark is started
	//   And: A calibration is engaged and executing
	//   And: A Proceed command is sent to start the calibration
	//  When: A <command> command is sent
	//  Then: A <user action> user action is sent to the SCL Cal Client library
	//   And: <data> is sent to the SCL Cal Client library (if defined)
	// Examples:
	//   | Command               | User Action                       | Data       |
	//   | YesAffirmation        | SCL_CAL_CLIENT_AC_YES             | 0          |
	//   | NoAffirmation         | SCL_CAL_CLIENT_AC_NO              | 0          |
	//   | SmallIncrement        | SCL_CAL_CLIENT_AC_SMALL_INCREMENT | 0          |
	//   | SmallDecrement        | SCL_CAL_CLIENT_AC_SMALL_DECREMENT | 0          |
	//   | LargeIncrement        | SCL_CAL_CLIENT_AC_LARGE_INCREMENT | 0          |
	//   | LargeDecrement        | SCL_CAL_CLIENT_AC_LARGE_DECREMENT | 0          |
	//   | RevertToDefaultValues | SCL_CAL_CLIENT_AC_REV_DEF_VAL     | 0          |
	//   | GoToStep              | SCL_CAL_CLIENT_AC_GOTO            | 0x01, 0x02 |
	//   | CommandButton         | SCL_CAL_CLIENT_AC_CMD_BTN         | 0x03       |

	m_harness.StartShark();
	EngageAndStartCalibration(Default::CalibrationName());

	for (auto const& mapping : n_commandMappings)
	{
		if (mapping.context)
		{
			SendCommand(MakeCommand(mapping.command, *mapping.context));
		}
		else
		{
			SendCommand(MakeCommand(mapping.command));
		}

		ASSERT_TRUE(m_harness.GetLastAction());
		EXPECT_THAT(m_harness.GetLastAction()->command, Eq(mapping.expectedUserAction));
		EXPECT_THAT(m_harness.GetLastAction()->data, ElementsAreArray(mapping.expectedData));
		EXPECT_THAT(m_harness.GetLastAction()->serviceIndex, Eq(Default::CalibrationServiceIndex()));
	}
}
}
