<div align="center">

  # Data Link Engine <!-- omit in toc -->

  An Application to bridge between gen7 applications and the system data link networks
  <br/><br/>

</div>

- [Quick Start](#quick-start)
- [Architecture](#architecture)
	- [Shark](#shark)
	- [Jaws](#jaws)
- [Getting Started](#getting-started)
- [Generating Verities](#generating-verities)
- [Running on an A7:Hx DV1](#running-on-an-a7hx-dv1)

## Quick Start

Data Link Engine is a software component that serves as a bridge between the physical system data links and the gen 7 applications.  It is intended to be the one system data link representative for the gen 7 applications.  It will accept a configuration file that will allow identity on the data link and sending/receiving messages and information on any of the Can or ethernet interfaces at a minimum.  There will also be some features that the data link engine will assume a larger role as they are heavily data link based and the logic lives in lower level data link components.

Data Link Engine will do the majority of its communication with the system through the gen 7 middleware component.

## Architecture

Data Link Engine is composed of two primary components.  Shark and Jaws.
### Shark

Shark is the data link interaction layer that wraps J1939 and Ethernet libraries to implement the set of protocols that are needed by Caterpillar systems that will be using the gen 7 architecture.  There will be a single configuration file that can be sent to Shark that will define all aspects of the data link communication needed to communicate with the physical data link and push the raw information to the Jaws component.

### Jaws
Jaws is the component that sends/receives raw data link data and is responsible for converting to/from middleware data packages.  There will be a single configuration file that will define the characteristics of any pids/pgns/spns/apids/etc... that need to be used to convert between data link and middleware components.  Jaws will use one representation for each identifier that the configurer will need to pick, if the system needs to adjust displayed units or have data in a different format it will be up to the individual applications to make that conversion.

## Getting Started

1. Make a data-engine directory

    ```
    $ cd ~
    $ mkdir data-engine
    $ cd data-engine
    ```

2. Clone the data link engine repository

	```
	$ git clone git@gitgis.ecorp.cat.com:es-csf-core-info/dl-services/ssp-dl-services.git
	```

3. Run the submodule update command within your data link engine repository

	```
    $ cd ssp-dl-services
	$ git submodule update --init --recursive
	```

5. Clone development-tools

    ```
    $ cd ~/data-engine
    $ git clone git@gitgis.ecorp.cat.com:es-csf-core-info/info-services/development-tools.git
    ```

6. Start docker container
	1. [Instructions for building and starting the common docker build environment](https://gitgis.ecorp.cat.com/es-csf-core-info/info-services/development-tools/-/tree/master/docker?ref_type=heads)
	

7. Exec into the container

	```
	$ docker exec -it bogtrotter-user-build-instance /bin/bash
	```

8. Install Conan settings required for building data link engine

	```
    $ sudo chown -R <user-name> ~/.conan2
	$ cd ~/repos/ssp-dl-services/utilities/Build
	$ conan remote login cat-e-conan-virt <user-name>
	```

9. Build data link engine

	```
	$ ./BuildAll.sh
	```

## Generating Verities

1. Create all verities (Velocirider, Jaws and Tests)

	```
    $ cd ~/data-engine/ssp-dl-services/utilities/Deployment
	$ ./CreateAllVerities.sh
	```

## Running on an A7:Hx DV1

`DV1s` include the VM architecture. We will need to create the configuration verities and copy them to the appropriate locations on the A7. For now we are utilizing this infrastructure that was created for Bosko.

1. [Build Bosko](https://gitgis.ecorp.cat.com/es-oi-displayapp/target/gen7/onboard/bosko#getting-started)
2. Make the following changes to Bosko's `vmconfig.toml`
```diff
diff --git a/tools/verity/BoskoVM/vmconfig.toml b/tools/verity/BoskoVM/vmconfig.toml
index 80b09e6..b46fcfc 100644
--- a/tools/verity/BoskoVM/vmconfig.toml
+++ b/tools/verity/BoskoVM/vmconfig.toml
@@ -15,3 +15,4 @@ graphical=false
 securityApp=true
 middleware=true
 vsock=true
+can0=true
```
3. `cd tools/vertity`
4. `./CreateBoskoVMVerity.sh`
5. `./CreateDefaultConfigVerities.sh`
6. `scp` `../artifacts/armv8/verity/DefaultConfig_Host_*` and `../artifacts/armv8/verity/BoskoVM_*`to the a7's `/opt/active`
7. `ssh` into the a7
8. `cd /opt/active`
9. `rm` any other `DefaultConfig` verities that might take precedence (like the `DefaultConfig_01` verity included in the flash file)
10. `mkdir /opt/active/BoskoVM`
11. `cp /opt/active/TestVM1/zzDevTools_ARM64_Guest_2025071501_TestVM1.verity* /opt/active/BoskoVM`
12. Back on the host...
13. `scp` `Jaws` verities to the a7's `/opt/active/BoskoVM` . You can also copy over `Velocirider` and `JawsSubscriber` verities.
14. Reboot the a7. Now datalink should be working properly.

