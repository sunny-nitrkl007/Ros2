# Agent Instructions — ssp-dl-services

## Build Environment Setup

Before building any target, source the Conan-generated environment scripts:

```bash
source build/<target>/<config>/generators/conanbuild.sh
source build/<target>/<config>/generators/conanrun.sh
```

Example for desktop debug:
```bash
source build/tgt_gcc_x86_64_ubuntu_workstation/Debug/generators/conanbuild.sh
source build/tgt_gcc_x86_64_ubuntu_workstation/Debug/generators/conanrun.sh
```

If generators are missing (first time or after conanfile changes):
```bash
utilities/Build/BuildConanDependencies.sh -z tgt_gcc_ubuntu -t Debug
```

Build targets with ninja from the build directory:
```bash
cd build/tgt_gcc_x86_64_ubuntu_workstation/Debug
ninja Shark_Tests
ninja Jaws_Tests
ninja              # build everything
```

Available targets: `tgt_gcc_x86_64_ubuntu_workstation` (desktop), `tgt_gcc_arm64_guest` (ARM). Each supports `Debug` and `RelWithDebInfo`.

---

## Deployment (ARM64 verity to bosko) using JawsRos as an example

### SSH Access
- **a7** (host): `ssh a7` — BusyBox; source `/etc/profile` for PATH or use full paths for commands
- **bosko** (guest VM running on a7): `ssh bosko` — also BusyBox; source `/etc/profile` for PATH or use full paths for commands
- Neither system has bash — use `sh`-compatible syntax in remote commands

### Deploy Flow
1. Build the verity:
   ```bash
   utilities/Deployment/CreateJawsRosVerity.sh -t RelWithDebInfo
   ```
   Output: `artifacts/tgt_gcc_arm64_guest_ros2/RelWithDebInfo/verity/JawsRos_ARM64_GUEST_<timestamp>.verity{,_verify}`

2. Remove old verities from a7:
   ```bash
   ssh a7 "/bin/rm /opt/active/BoskoVM/JawsRos*"
   ```

3. Copy new verity files to a7:
   ```bash
   scp artifacts/.../JawsRos_ARM64_GUEST_*.verity* \
       a7:/opt/active/BoskoVM/
   ```

4. **Reboot A7** — not just bosko:
   ```bash
   ssh a7 "/sbin/reboot"
   ```

5. Wait ~40 seconds, then check logs on bosko:
   ```bash
   ssh bosko ". /etc/profile; cat /tmp/JawsRos_*.log"
   ```

### CRITICAL: Always reboot A7 after deploying a new verity
Verities are dm-verity block devices mounted by a7's init at boot time. Rebooting only bosko does NOT remount the new verity — a7 must reboot to pick up the new image.

### Verity Mount on bosko
- Mounted at: `/opt/JawsRos/` (read-only)

---

## Unit & Functional Testing

For comprehensive testing guidance, see [.github/copilot-instructions.md](.github/copilot-instructions.md#unit-testing) and [design/UNIT_TESTING.md](./design/UNIT_TESTING.md).

### Test Execution

**Unit tests** (isolated, mocked):
```bash
cd build/tgt_gcc_x86_64_ubuntu_workstation/Debug
ninja Shark_Tests
ninja Jaws_Tests
```

**Functional tests** (integration, minimal mocks):
```bash
cd build/tgt_gcc_x86_64_ubuntu_workstation/Debug
ninja Shark_Functional_Tests
ninja Jaws_Functional_Tests
```

**Run all tests for a target:**
```bash
utilities/Build/RunUnitTests.sh -z tgt_gcc_ubuntu -t Debug
utilities/Build/RunFunctionalTests.sh -t Debug
```

### Key Convention Reminders

- **Assertions**: Use `EXPECT_THAT(value, Matcher())` instead of `EXPECT_EQ()` for cleaner error messages
- **Fixtures**: All test suites must use `::testing::Test` fixtures to avoid duplication
- **Test naming**: Reflect the requirement, not the implementation
- **Mocks**: Use `EnsureMockKindIsSpecified(ClassName)` macro in every mock declaration

