///////////////////////////////////////////////////////////////////////////////
/// @file      testCSVReader.cpp
/// @author    bode
/// @date      8/13/2008
/// @brief     Tests for propper .csv file parsing
///
///
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////

#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE "Unit tests for serializable specialization"
#include <iostream>
#include <fstream>
#include <boost/test/unit_test.hpp>
#include "csvUtil/CsvReader.h"

BOOST_AUTO_TEST_SUITE( csvReaderTestSuite )

BOOST_AUTO_TEST_CASE( testCsvReader) {
  const unsigned int numDataLines = 20;
  std::vector<std::string> fieldNames;
  fieldNames.push_back("Elapsed Time");
  fieldNames.push_back("\"Speed,kph\"");
  fieldNames.push_back("\"Curv\"\"ature\"");

  std::vector<std::string> sfieldNames;
  sfieldNames.push_back("Elapsed Time");
  sfieldNames.push_back("Speed,kph");
  sfieldNames.push_back("Curv\"ature");

  std::ofstream outFile;
  outFile.open("test.csv");
  if(outFile.fail())
  {
    std::cerr << "Unable to open output file\n";
    BOOST_CHECK(false);
  }

  for(unsigned int field = 0; field < fieldNames.size()-1; ++field)
  {
    outFile << fieldNames[field] << ",";
  }
  outFile << fieldNames[fieldNames.size()-1] << "\n";

  for(unsigned int line = 0; line < numDataLines; ++line) {
    outFile << line << "," << numDataLines-line << ",0.0\n";
  }
  outFile.close();

  CsvReader reader;
  BOOST_CHECK(reader.load("test.csv"));

  for(unsigned int field = 0; field < fieldNames.size(); ++field)
  {
    BOOST_CHECK_EQUAL(reader.getColumnIndex(sfieldNames[field]), field);
  }

  int timeIndex = reader.getColumnIndex("Elapsed Time");
  int speedIndex = reader.getColumnIndex("Speed,kph");
  int curvIndex = reader.getColumnIndex("Curv\"ature");
  //std::cerr << "Num rows = " << reader.getNumRows() << "\n";
  //std::cerr << "Num cols = " << reader.getNumCols() << "\n";

  for(unsigned int line = 0; line < numDataLines; ++line) {
    BOOST_CHECK_EQUAL(reader.getNumericalValue(line, timeIndex), line);
    BOOST_CHECK_EQUAL(reader.getNumericalValue(line, speedIndex), numDataLines-line);
    BOOST_CHECK_EQUAL(reader.getNumericalValue(line, curvIndex), 0.0);
  }

  BOOST_CHECK(reader.setTextValue(1,0,"Bad,String"));  // requires escape characters, but ok
  BOOST_CHECK(reader.setTextValue(2,0,"Bad\"String2")); // requires escape characters, but ok
  BOOST_CHECK(reader.setTextValue(0,0,"Good String"));
  reader.setNumericalValue(0,1,3.14159);
  reader.setNumericalValue(0,2,-12345.3);
  BOOST_CHECK(reader.save("test2.csv"));
}

/// This test was constructed because there was questions about whether or not the
/// CVS grammar was properly parsing the dash character ("-").  The test reveals
/// that it indeed is, the problem CSV file was that the character was being represented
/// in UNICODE and not ASCII and therefore in ASCII it was not truely a dash.
/// The parsing grammer is only set up to handle the ASCII character set.
BOOST_AUTO_TEST_CASE( testCsvReaderDashes) {
  const unsigned int numDataLines = 20;
  std::vector<std::string> fieldNames;
  fieldNames.push_back("Test column 1");
  fieldNames.push_back("Test column 2");

  std::ofstream outFile;
  outFile.open("test-dash.csv");
  if(outFile.fail())
  {
    std::cerr << "Unable to open output file\n";
    BOOST_CHECK(false);
  }

  for(unsigned int field = 0; field < fieldNames.size()-1; ++field)
  {
    outFile << fieldNames[field] << ",";
  }
  outFile << fieldNames[fieldNames.size()-1] << "\n";

  for(unsigned int line = 0; line < numDataLines; ++line) {
    outFile << "something-strange,happended here\n";
  }
  outFile.close();

  CsvReader reader;
  BOOST_CHECK(reader.load("test-dash.csv"));

  for(unsigned int field = 0; field < fieldNames.size(); ++field)
  {
    BOOST_CHECK_EQUAL(reader.getColumnIndex(fieldNames[field]), field);
  }

  int col1Index = reader.getColumnIndex("Test column 1");
  int col2Index = reader.getColumnIndex("Test column 2");
  //std::cerr << "Num rows = " << reader.getNumRows() << "\n";
  //std::cerr << "Num cols = " << reader.getNumCols() << "\n";

  for(unsigned int line = 0; line < numDataLines; ++line) {
    BOOST_CHECK_EQUAL(reader.getTextValue(line, col1Index), "something-strange");
    BOOST_CHECK_EQUAL(reader.getTextValue(line, col2Index), "happended here");
  }
}

BOOST_AUTO_TEST_CASE( testCsvReaderRowsAndColumns) {
  CsvReader reader;

  BOOST_CHECK_EQUAL(reader.getNumColumns(), 0);
  BOOST_CHECK_EQUAL(reader.getNumRows(), 0);


  BOOST_CHECK_EQUAL(reader.addColumn("TestCol1", "foo"), 0);  // first column index should be 0
  BOOST_CHECK_EQUAL(reader.getNumColumns(), 1);
  BOOST_CHECK_EQUAL(reader.getNumRows(), 0);
  BOOST_CHECK_EQUAL(reader.getColumnIndex("TestCol1"), 0);

  BOOST_CHECK(reader.addColumn("TestCol2", "bag"));
  BOOST_CHECK_EQUAL(reader.getNumColumns(), 2);
  BOOST_CHECK_EQUAL(reader.getNumRows(), 0);
  BOOST_CHECK_EQUAL(reader.getColumnIndex("TestCol2"), 1);

  BOOST_CHECK_EQUAL(reader.addRow("firstRow"), 0);    // first row index should be 0
  BOOST_CHECK_EQUAL(reader.getNumColumns(), 2);
  BOOST_CHECK_EQUAL(reader.getNumRows(), 1);
  BOOST_CHECK(reader.addRow("secondRow"));
  BOOST_CHECK_EQUAL(reader.getNumColumns(), 2);
  BOOST_CHECK_EQUAL(reader.getNumRows(), 2);
  BOOST_CHECK(reader.addRow("thirdRow"));
  BOOST_CHECK_EQUAL(reader.getNumColumns(), 2);
  BOOST_CHECK_EQUAL(reader.getNumRows(), 3);

  BOOST_CHECK_EQUAL(reader.addColumn("TestCol1", "firstCol"),0);  // this call shouldn't add a new column
  BOOST_CHECK_EQUAL(reader.getNumColumns(), 2);
  BOOST_CHECK_EQUAL(reader.getNumRows(), 3);
  BOOST_CHECK_EQUAL(reader.getColumnIndex("TestCol1"), 0);

  std::vector<std::string> secondRow = reader.getRow(1);
  BOOST_CHECK_EQUAL(secondRow[0], "firstCol");
  BOOST_CHECK_EQUAL(secondRow[1], "secondRow");

  BOOST_CHECK(reader.addColumn("TestCol3", "9"));
  BOOST_CHECK_EQUAL(reader.getNumColumns(), 3);
  BOOST_CHECK_EQUAL(reader.getNumRows(), 3);
  BOOST_CHECK_EQUAL(reader.getColumnIndex("TestCol3"), 2);

  int val = reader.getValue<int>(2,2);
  BOOST_CHECK_EQUAL(val, 9);

  BOOST_CHECK(reader.setValue(1,2,46));
  val = reader.getValue<int>(1,2);
  BOOST_CHECK_EQUAL(val, 46);

  BOOST_CHECK(reader.setValue(0,0,"Bad\"String2"));  // requires escape characters, but ok
  BOOST_CHECK(reader.save("test3.csv"));

}




BOOST_AUTO_TEST_SUITE_END()



