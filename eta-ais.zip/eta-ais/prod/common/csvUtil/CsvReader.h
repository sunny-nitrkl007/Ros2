///////////////////////////////////////////////////////////////////////////////
/// @file      CsvReader.h
/// @author    bode
/// @date      8/13/2008
/// @brief     A class that can read in and store a CSV file as a 2D array
///
/// Pathfinder CSV files all start with a leading comment line that describes
/// the contents of each column of the CSV file.  This class parses the top
/// comment line of the csv file and allows users to query for the index of a
/// particular data field.  This class stores the values internally as strings
/// so that they can be used to represent both numerical values as well as text
/// values.  To index a numerical value, the method "getNumericalValue" should
/// be called
///
/// For Example:
///
/// foo.csv:
/// VehicleX,VehicleY,Speed
/// 29392.23,59392.34,6.87
/// ...
///
/// userCode:
/// CsvReader reader;
/// reader.load("foo.csv");
/// int speedIndex = reader.getColumnIndex("Speed");
/// double initialSpeed = reader.getNumericalValue(0,speedIndex);
///
/// Note: this class should be renamed CsvDataStore since it has evolved into
/// much more than just reading the data
///
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef CsvReader_h
#define CsvReader_h

#include <map>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
#include <fstream>

const int DefaultPrecision = 2;

class CsvReader
{
  public:
    bool load(const std::string& fileName);
    bool save(const std::string& fileName) const;
    int getColumnIndex(const std::string& fieldName) const;
    std::string getColumnName(int colIndex) const;
    int getNumRows() const;
    int getNumColumns() const;

    std::string getTextValue(int rowIndex, int columnIndex) const;
    bool setTextValue(int rowIndex, int columnIndex, const std::string& value);

    double getNumericalValue(int rowIndex, int columnIndex) const;

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Returns the entry at the passed row and column as a value specified by a template argument
    /// @return the value at the passed row and column
    /// @param rowIndex the row of the field to access
    /// @param columnIndex the column of the field to access
    ///
    /// The string stream conversion of the text data will fail if the data stored
    /// in the specified field can not be converted to the desrired type
    ///////////////////////////////////////////////////////////////////////////////
    template <typename T>
    T getValue(int rowIndex, int columnIndex) const {
      return textToType<T>(getTextValue(rowIndex,columnIndex));
    }

    bool setNumericalValue(int rowIndex, int columnIndex, double value, int percision = DefaultPrecision);

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Sets the value at the specified row and column of the data table
    /// @param rowIndex the row of the field to be set
    /// @param columnIndex the column of the field to be set
    /// @param value the value to set the field to
    ///////////////////////////////////////////////////////////////////////////////
    template <typename T>
    bool setValue(int rowIndex, int columnIndex, const T& value, int precision = DefaultPrecision) {
      return setTextValue(rowIndex,columnIndex,typeToText(value, precision));
    }

    std::vector<std::string> getRow(int rowIndex) const;
    int addColumn(const std::string& fieldName, const std::string& initialValue);
    int addRow(const std::string& initialValue);

  protected:
    std::string getEscapedTextValue(int rowIndex, int columnIndex) const;

    bool parseFieldNames(const std::string& line);
    bool parseDataLine(const std::string& line, unsigned int rowNumber);
    bool tokenizeLine(const std::string& line, std::vector<std::string>& tokens);
    bool validCSVEntry(const std::string& entry);

    typedef std::map<std::string, int> FieldMap;
    FieldMap m_fieldMap;
    std::vector<std::vector<std::string> > m_data;


    template <typename T>
    T textToType(const std::string& text) const {
      T value;
      std::stringstream strStream;
      strStream << text;
      strStream >> value;
      return value;
    }

    template <typename T>
    std::string typeToText(const T& value, int precision) const {
      std::string text;
      std::stringstream strStream;
      strStream.setf(std::ios::fixed,std::ios::floatfield);
      strStream.precision(precision);
      strStream << value;
      strStream >> text;
      return text;
    }
};

///////////////////////////////////////////////////////////////////////////////
/// @brief This class uses CsvReader to read a csv file one line at a time
/// Only one line is ever loaded into memory, making this suitable for accessing very large files.
/// However, the file cannot be edited or saved using this class
/// All members function the same as CsvReader but only on the current row, so no row index is needed
///////////////////////////////////////////////////////////////////////////////
class CsvLineReader : private CsvReader
{
  public:
    CsvLineReader();
    ~CsvLineReader();
    bool load(const std::string& fileName);
    bool nextRow();

    int getColumnIndex(const std::string& fieldName) const
    {
      return CsvReader::getColumnIndex(fieldName);
    }
    std::string getColumnName(int colIndex) const
    {
      return CsvReader::getColumnName(colIndex);
    }
    int getNumColumns() const
    {
      return CsvReader::getNumColumns();
    }

    std::string getTextValue(int columnIndex) const
    {
      return CsvReader::getTextValue(0,columnIndex);
    }

    double getNumericalValue(int columnIndex) const
    {
      return getValue<double>(columnIndex);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Returns the entry at the passed row and column as a value specified by a template argument
    /// @return the value at the passed row and column
    /// @param rowIndex the row of the field to access
    /// @param columnIndex the column of the field to access
    ///
    /// The string stream conversion of the text data will fail if the data stored
    /// in the specified field can not be converted to the desrired type
    ///////////////////////////////////////////////////////////////////////////////
    template <typename T>
    T getValue(int columnIndex) const {
      return textToType<T>(getTextValue(columnIndex));
    }

    std::vector<std::string> getRow() const
    {
      return CsvReader::getRow(0);
    }

  private:
    std::ifstream *m_dataFile;

};


#endif
