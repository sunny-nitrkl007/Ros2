///////////////////////////////////////////////////////////////////////////////
/// @file      CsvReader.cpp
/// @author    bode
/// @date      8/13/2008
/// @brief     A class that can read in and store a CSV file as a 2D array
///
/// Pathfinder CSV files all start with a leading comment line that describes
/// the contents of each column of the CSV file.  This class parses the top
/// comment line of the csv file and allows users to query for the index of a
/// particular data field.
///
/// The grammar implemented is the one specified in RFC4180.  To be properly
/// parsed all CSV files must adhear to this grammar
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#include <cassert>
#include <fstream>
#include <errno.h>

#ifndef BOOST_SPIRIT_THREADSAFE
#define BOOST_SPIRIT_THREADSAFE //spirit is not threadsafe by default
#endif
#include <boost/spirit/include/classic_core.hpp>
#include <boost/spirit/include/classic_confix.hpp>
#include <boost/spirit/include/classic_lists.hpp>
#include <boost/spirit/include/classic_escape_char.hpp>
#include <boost/algorithm/string.hpp>

#include "csvUtil/CsvReader.h"

using namespace std;
using namespace boost::spirit;
using namespace boost::spirit::classic;

///////////////////////////////////////////////////////////////////////////////
/// @brief loads in the csv data from file
///
/// @return  true on success, false on failure
///
/// @param fileName the name of the file to load
///
/// The grammar implemented is the one specified in RFC4180.  To be properly
/// parsed all CSV files must adhear to this grammar
///////////////////////////////////////////////////////////////////////////////
bool CsvReader::load(const string& fileName) {
  // open the file
  std::ifstream dataFile;
  dataFile.open(fileName.c_str());

  // clear field names and data
  m_fieldMap.clear();
  m_data.clear();

  if(dataFile.fail())
  {
    cerr << "Unable to open " << fileName << " for reading (" << strerror(errno) << ")\n";
    return false;
  }
  else
  {
    string line;
    // load the field names
    if(!getline(dataFile, line))
    {
      cerr << "Unable to read field names from " << fileName << "\n";
      return false;
    }
    else
    {
      if(!parseFieldNames(line))
      {
        cerr << "Unable to parse field names from " << fileName << "\n";
        return false;
      }
    }
    // load the data
    unsigned int rowCount = 1;
    while(getline(dataFile, line))
    {
      rowCount++;
      if(!parseDataLine(line, rowCount))
      {
        cerr << "Unable to parse row " << rowCount << " of data from " << fileName << "\n";
        return false;
      }
    }
  }
  return true;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief writes the csv data to a csv file
///
/// @return true on success, false otherwise
///
/// @param fileName the name of the file to write to
///////////////////////////////////////////////////////////////////////////////
bool CsvReader::save(const string& fileName) const {
  ofstream outFile;
  outFile.open(fileName.c_str());
  if(outFile.fail())
  {
    std::cerr << "Unable to open output file" << fileName << "\n";
    return false;
  }

  for(unsigned int fieldNum = 0; fieldNum < m_fieldMap.size()-1; ++fieldNum)
  {
    outFile << getColumnName(fieldNum) << ",";
  }
  outFile << getColumnName(m_fieldMap.size()-1) << "\n";

  for(int line = 0; line < getNumRows(); ++line) {
    for(int field = 0; field < getNumColumns()-1; ++field) {
      outFile << getEscapedTextValue(line,field) << ",";
    }
    outFile << getEscapedTextValue(line,getNumColumns()-1) << "\n";
  }
  outFile.close();
  return true;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Returns the index of the corresponding column name
///
/// @return the column index if the name is valid, -1 otherwise
///////////////////////////////////////////////////////////////////////////////
int CsvReader::getColumnIndex(const string& fieldName) const {
  FieldMap::const_iterator iter = m_fieldMap.find(fieldName);
  if(iter != m_fieldMap.end()) return iter->second;
  else return -1;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Returns the name of the corresponding column index
///////////////////////////////////////////////////////////////////////////////
std::string CsvReader::getColumnName(int colIndex) const {
  FieldMap::const_iterator iter;
  std::string ret;
  for(iter = m_fieldMap.begin(); iter != m_fieldMap.end(); ++iter)
  {
    if(iter->second == colIndex)
    {
      return iter->first;
    }
  }
  return ret;
}


///////////////////////////////////////////////////////////////////////////////
/// @brief returns the number of rows loaded
///////////////////////////////////////////////////////////////////////////////
int CsvReader::getNumRows() const {
  int numRows = static_cast<int>(m_data.size());
  return numRows;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief returns the number of columns loaded
///////////////////////////////////////////////////////////////////////////////
int CsvReader::getNumColumns() const {
  int numCols = static_cast<int>(m_fieldMap.size());
  return numCols;
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Returns the specified entry as a text string
///
/// @return  the specified entry
///
/// @param rowIndex the row of the entry to access
/// @param columnIndex the column of the entry to access
///////////////////////////////////////////////////////////////////////////////
string CsvReader::getTextValue(int rowIndex, int columnIndex) const {
  if ((m_data.size() > ((unsigned int) rowIndex)) && (m_data.at(rowIndex).size() > ((unsigned int) columnIndex)))
  {
    return m_data.at(rowIndex).at(columnIndex);
  }
  else
  {
    return "";
  }
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Returns the raw text value that may contain excape characters
///
/// @return  the specified entry
///
/// @param rowIndex the row of the entry to access
/// @param columnIndex the column of the entry to access
///////////////////////////////////////////////////////////////////////////////
string CsvReader::getEscapedTextValue(int rowIndex, int columnIndex) const {
  std::string retString = "";
  if ((m_data.size() > ((unsigned int) rowIndex)) && (m_data.at(rowIndex).size() > ((unsigned int) columnIndex)))
  {
    std::string textString = m_data.at(rowIndex).at(columnIndex);
    bool hasCommaOrNewLine = false;
    for(unsigned int charIndex = 0; charIndex < textString.size(); ++charIndex)
    {
      if(textString[charIndex] == '\n' || textString[charIndex] == ',')
      {
        hasCommaOrNewLine = true;
      }
      if(textString[charIndex] == '\"')
      {
        hasCommaOrNewLine = true;
        retString.push_back('\"');
      }
      retString.push_back(textString[charIndex]);
    }
    if(hasCommaOrNewLine)
    {
      retString = "\"" + retString + "\"";
    }
  }
  return retString;
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Sets the text value of the specified field
///
/// @return true on success
///         false of the passed value cannot be parsed by the CVS field grammar
///
/// @param rowIndex the row of the specified entry
/// @param columnIndex the column of the specified entry
/// @param value the value to set the entry to
///////////////////////////////////////////////////////////////////////////////
bool CsvReader::setTextValue(int rowIndex, int columnIndex, const string& value) {
  // see if the string is a correctly formed field
  //if(!validCSVEntry(value)) return false;
  string& stringToSet = m_data.at(rowIndex).at(columnIndex);
  stringToSet = value;
  return true;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Returns the entry at the passed row and column as a numerical value
///
/// @return the numerical value at the passed row and column
///
/// @param rowIndex the row of the field to access
/// @param columnIndex the column of the field to access
///
/// The string stream conversion of the text data will fail if the data stored
/// in the specified field can not be converted to the desrired type
///
/// Legacy method - now mapped to getValue<double>()
///////////////////////////////////////////////////////////////////////////////
double CsvReader::getNumericalValue(int rowIndex, int columnIndex) const {
  return getValue<double>(rowIndex, columnIndex);
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Returns the data in the row of the csv data stor in string format
/// @return the text values contained in the specified row
/// @param rowIndex the row of the field to access
///////////////////////////////////////////////////////////////////////////////
vector<string> CsvReader::getRow(int rowIndex) const {
  return m_data.at(rowIndex);
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Sets the value at the specified row and column of the data table
///
/// @param rowIndex the row of the field to be set
/// @param columnIndex the column of the field to be set
/// @param value the value to set the field to
/// Legacy method - now mapped to setValue<double>()
///////////////////////////////////////////////////////////////////////////////
bool CsvReader::setNumericalValue(int rowIndex, int columnIndex, double value, int percision) {
  return setValue(rowIndex,columnIndex,value,percision);
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Adds a column of data with the specified field name to the csv data store
/// @param initialValue the value that all data in the column will be set to
/// @return the column index for the column that has been added, or -1 if the column
///         could not be added because the intialial value is invalid
/// @post the csv data store will contain a column with the field name specified
///       and all the contents of that column will be set to the specified value.
///       Generally this will be accomplished by added a column to the end of the
///       data store and setting all existing rows to have the passed value.
///       However if the csv data store already contains a column with the passed
///       field name, no column is created, but rather the existing column is
///       overwritten.  This is analgous to the std::map operator[]
///////////////////////////////////////////////////////////////////////////////
int CsvReader::addColumn(const std::string& fieldName, const std::string& initialValue)
{
  int colIndex = -1;
  if(!validCSVEntry(initialValue)) return colIndex;

  FieldMap::const_iterator iter = m_fieldMap.find(fieldName);
  if(iter == m_fieldMap.end())
  {
    colIndex = m_fieldMap.size();
    m_fieldMap.insert(make_pair(fieldName, m_fieldMap.size()));
    for(unsigned int rowIndex = 0; rowIndex < m_data.size(); ++rowIndex)
    {
      m_data[rowIndex].push_back(initialValue);
    }
  }
  else
  {
    colIndex = iter->second;
    for(unsigned int rowIndex = 0; rowIndex < m_data.size(); ++rowIndex)
    {
      m_data[rowIndex][colIndex] = initialValue;
    }
  }
  return colIndex;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief adds a row of data to the csv data store
/// @return true if the initialValue is a valid csv token
/// @param initialValue the value to set each column netry to
///////////////////////////////////////////////////////////////////////////////
int CsvReader::addRow(const std::string& initialValue)
{
  int rowIndex = -1;
  if(!validCSVEntry(initialValue)) return rowIndex;
  vector<string> temp(m_fieldMap.size(), initialValue);
  rowIndex = m_data.size();
  m_data.push_back(temp);
  return rowIndex;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Parses the header values for each of the CSV columns
///
/// @return  true on success, false on an invalid parse or duplicate entries
///
/// @param line the line of text to be parsed
///
/// Unlike the RFC4180 standard, pathfinder csv files are required to have
/// header column names at the start of the file.  These column names can
/// be used in user code to access data values
///
/// NOTE: The logic has been modfied slightly from RFC4180 in that the
/// reader will accept and skip over blank lines in the file.  When this
/// happens a message will be printed.
///////////////////////////////////////////////////////////////////////////////
bool CsvReader::parseFieldNames(const string& line) {
  vector<string> tokens;
  if(tokenizeLine(line, tokens))
  {
    int index = 0;
    for(vector<string>::iterator iter = tokens.begin(); iter != tokens.end(); ++iter)
    {
      std::string token = *iter;
      if(token.size() > 0)
      {
        // make sure this field hasn't already been added
        FieldMap::const_iterator iter = m_fieldMap.find(token);
        if(iter != m_fieldMap.end())
        {
          cerr << "Field name " << token << " appears in more than one column\n";
          return false;
        }

        m_fieldMap.insert(make_pair(token, index));
        ++index;
        //cout << "Adding field name " << token << endl;
      }
    }
  } else {
    return false;
  }
  return true;
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Parses a line of CVS data and appends it to the data table
/// @return true on success, false for and invalid parse or if there are the
///         wrong number of entries
/// @param line the line of text to be parsed
///////////////////////////////////////////////////////////////////////////////
bool CsvReader::parseDataLine(const string& line, unsigned int rowNumber) {
  vector<string> tokens;
  if(tokenizeLine(line, tokens))
  {
    if(tokens.size() != m_fieldMap.size()) {
//      cerr << "Expected " << m_fieldMap.size() << " entries in row " << rowNumber << ", but found " << tokens.size() << endl;
    }
  }
  else
  {
    return false;
  }

  if ((tokens.size() == 1) && (tokens[0].size() == 0))
  {
    cerr << "Skipping blank line at row " << rowNumber << "\n";
  }
  else
  {
    m_data.push_back(tokens);
  }
  return true;
}

struct append_action
{
  template<typename ValueT>
    void act(std::string& ref, ValueT const& value) const
    {
      ref += string(value);
    }

    template<
      typename IteratorT
      >
    void act(std::string& ref,
             IteratorT const& first,
             IteratorT const& last) const
    {
      std::string vt(first, last);
      ref += vt;
    }
};

// assign_a is a polymorphic helper function that generators an
// append_actor based on ref_value_actor, append_action and the
// type of its argument.
inline ref_value_actor<std::string, append_action>
append_a(std::string& ref)
{
  return ref_value_actor<std::string, append_action>(ref);
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Creates grammar to parses CSV lines and uses it to parse input line
///
/// @return  a flag that indicates a successful parse of the line
///
/// @param line the input line to be tokenized
/// @param tokens the returned tokenized fields that the input line contained
///
/// The grammar implemented is the one specified in RFC4180.  To be properly
/// parsed all CSV files must adhear to this grammar
///////////////////////////////////////////////////////////////////////////////
bool CsvReader::tokenizeLine(const string& line, vector<string>& tokens) {
  const bool parseDebug = false;
  tokens.clear();
  std::string escapedString;
  rule<> record, field, escapedBody, escaped, nonEscaped, doubleQuote, commaOrNewLine, text;

  text = range_p(static_cast<char>(0x20),static_cast<char>(0x21)) |
    range_p(static_cast<char>(0x23),static_cast<char>(0x2B)) |
    range_p(static_cast<char>(0x2D),static_cast<char>(0x7E));


  nonEscaped = *(text);
  doubleQuote = ch_p(static_cast<char>(0x22));
  commaOrNewLine = ch_p(',') | ch_p('\n');

  escapedBody =  *(text[append_a(escapedString)] | commaOrNewLine[append_a(escapedString)] | (doubleQuote >> doubleQuote[append_a(escapedString)]));
  escaped = doubleQuote[assign_a(escapedString,"")] >> escapedBody >> doubleQuote[push_back_a(tokens,escapedString)];

  field = (escaped | nonEscaped[push_back_a(tokens)]);
  record = field >> *(ch_p(',') >> field);

  parse_info<> result = parse(line.c_str(), record);

  if (result.hit)
  {
    if(parseDebug)
    {
      cout << "Parsing CSV list (comma separated values) " << endl
        << "\t" << line << endl
        << "Parsed successfully!" << endl << endl;

      if (result.full)
      {
        cout << "Matched " << (int)tokens.size() <<
          " list elements (full list): " << endl;
      }
      else
      {
        cout << "Matched " << (int)tokens.size() <<
          " list elements: " << endl;
      }

      cout << endl << "Item(s) got directly from the item parser:" << endl;
      for (vector<string>::iterator it = tokens.begin();
            it != tokens.end(); ++it)
      {
        cout << *it << endl;
      }
    }
    return true;
  }
  else
  {
    cout << "Failed to parse CSV list!" << endl;
    return false;
  }
}

///////////////////////////////////////////////////////////////////////////////
/// @brief returns true if the text string is a valid csv entry
/// @return true if the text string is a valid csv entry
/// @param entry the entry to test
///////////////////////////////////////////////////////////////////////////////
bool CsvReader::validCSVEntry(const string& entry)
{
  vector<string> tokens;
  if(!tokenizeLine(entry,tokens)) return false;
  if(entry != tokens[0]) return false;
  return true;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief constructor, sets the open file to NULL
///////////////////////////////////////////////////////////////////////////////
CsvLineReader::CsvLineReader() : m_dataFile(NULL)
{

}

///////////////////////////////////////////////////////////////////////////////
/// @brief closes the open file
///////////////////////////////////////////////////////////////////////////////
CsvLineReader::~CsvLineReader()
{
  if (m_dataFile != NULL)
  {
    m_dataFile->close();
    m_dataFile = NULL;
  }
}

///////////////////////////////////////////////////////////////////////////////
/// @brief opens the csv file and reads the column names from the first line
/// @param fileName the file to open
/// @return  true on success, false on failure
///
/// will close the currently open file if necessary
///////////////////////////////////////////////////////////////////////////////
bool CsvLineReader::load(const std::string& fileName)
{
  if (m_dataFile != NULL)
  {
    m_dataFile->close();
    delete m_dataFile;
    m_dataFile = NULL;
  }
  // open the file
  m_dataFile = new std::ifstream();
  m_dataFile->open(fileName.c_str());

  // clear field names and data
  m_fieldMap.clear();
  m_data.clear();

  if(m_dataFile->fail())
  {
    cerr << "Unable to open " << fileName << " for reading\n";
    return false;
  }
  else
  {
    string line;
    // load the field names
    if(!getline(*m_dataFile, line))
    {
      cerr << "Unable to read field names from " << fileName << "\n";
      return false;
    }
    else
    {
      if(!CsvReader::parseFieldNames(line))
      {
        cerr << "Unable to parse field names from " << fileName << "\n";
        return false;
      }
    }
  }
  return true;

}

///////////////////////////////////////////////////////////////////////////////
/// @brief reads the next row into memory
/// @return  true on success, false on failure
///
/// false return indicates the file is complete
///////////////////////////////////////////////////////////////////////////////
bool CsvLineReader::nextRow()
{
  string line;
  if (m_dataFile == NULL)
  {
    return false;
  }
  // load the data
  unsigned int rowCount = 1;
  if(getline(*m_dataFile, line))
  {
    CsvReader::m_data.clear();
    if(!parseDataLine(line, rowCount))
    {
      cerr << "Unable to parse row of data, closing file\n";
      m_dataFile->close();
      delete m_dataFile;
      m_dataFile = NULL;
      return false;
    }
    return true;
  }
  else
  {
    m_dataFile->close();
    delete m_dataFile;
    m_dataFile = NULL;
  }

  return false;
}


