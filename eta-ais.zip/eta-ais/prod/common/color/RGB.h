///////////////////////////////////////////////////////////////////////////////
/// @file      RGB.h
/// @author    bode
/// @date      9/3/2008
/// @brief     Storage and methods for RGB color triplets
///
/// 
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef RGB_h
#define RGB_h

#include <iostream>
#include "ColorBase.h"

namespace nrec{
  namespace color {

template <typename Storage>
class RGB : public ColorBase<Storage, 3> {
public:
  typedef Storage StorageType;
  static const unsigned int NumComponents = ColorBase<Storage, 3>::NumComponents;   
  enum{RedIndex,GreenIndex,BlueIndex};
  RGB() {
    r() = ColorStorageTraits<Storage>::maxValue; 
    g() = ColorStorageTraits<Storage>::maxValue; 
    b() = ColorStorageTraits<Storage>::maxValue;
  }
  RGB(StorageType rr, StorageType gg, StorageType bb) {
    r() = rr; g() = gg; b() = bb;
  }
  RGB(const StorageType col[NumComponents]) {
    r() = col[RedIndex]; g() = col[GreenIndex]; b() = col[BlueIndex];
  }
  inline StorageType& r() {return this->m_color[RedIndex];}
  inline StorageType& g() {return this->m_color[GreenIndex];}
  inline StorageType& b() {return this->m_color[BlueIndex];}
  inline const StorageType& r() const {return this->m_color[RedIndex];}
  inline const StorageType& g() const {return this->m_color[GreenIndex];}
  inline const StorageType& b() const {return this->m_color[BlueIndex];}
  inline const StorageType* getColorVector() const {return this->m_color;}
};


template <typename StorageDest, typename ColorSrc>
RGB<StorageDest> convertStorage(const RGB<ColorSrc>& colorSrc) {
  RGB<StorageDest> ret;
  ret.r() = storageConversion<StorageDest>(colorSrc.r());
  ret.g() = storageConversion<StorageDest>(colorSrc.g());
  ret.b() = storageConversion<StorageDest>(colorSrc.b());
  return ret;
}


template <typename Storage>
bool almostEqual(const RGB<Storage>& lhs, const RGB<Storage>& rhs, Storage tolerance) {
  Storage dr,dg,db;
  if(lhs.r() > rhs.r()) dr = lhs.r() - rhs.r();
  else dr = rhs.r() - lhs.r();
  if(dr > tolerance) return false; 
  if(lhs.g() > rhs.g()) dg = lhs.g() - rhs.g();
  else dg = rhs.g() - lhs.g();
  if(dg > tolerance) return false; 
  if(lhs.b() > rhs.b()) db = lhs.b() - rhs.b();
  else db = rhs.b() - lhs.b();
  if(db > tolerance) return false;
  return true; 
}



template <typename Storage>
inline std::ostream& operator << (std::ostream& out, const RGB<Storage>& c) {
  return out << "R: " << c.r() << " G:" << c.g() << " B:" << c.b() << " ";
}

template <>
inline std::ostream& operator << (std::ostream& out, const RGB<char> & c) {
  return out << "R: " << (int)c.r() << " G:" << (int)c.g() << " B:" << (int)c.b() << " ";
}

template <>
inline std::ostream& operator << (std::ostream& out, const RGB<unsigned char> & c) {
  return out << "R: " << (int)c.r() << " G:" << (int)c.g() << " B:" << (int)c.b() << " ";
}


// typedefs - for RGB colors
typedef RGB<double> DoubleRGB; 
typedef RGB<float>  FloatRGB; 
typedef RGB<int>  IntRGB;
typedef RGB<unsigned int> UIntRGB;
typedef RGB<short>  ShortRGB;
typedef RGB<unsigned short> UShortRGB;
typedef RGB<char> CharRGB;
typedef RGB<unsigned char> UCharRGB;

  };  // namespace color
};  // namespace nrec

#endif

