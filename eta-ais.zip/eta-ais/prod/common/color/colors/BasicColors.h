///////////////////////////////////////////////////////////////////////////////
/// @file      BasicColors.h
/// @author    bode
/// @date      9/4/2008
/// @brief     The set of basic colors
///
/// 
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef BasicColors_h
#define BasicColors_h

#include "../RGB.h"

namespace nrec {
  namespace color {
    namespace basicColors {
      const UCharRGB white = UCharRGB(255,255,255);
      const UCharRGB black = UCharRGB(0,0,0);
      const UCharRGB red = UCharRGB(255,0,0);
      const UCharRGB green = UCharRGB(0,255,0);
      const UCharRGB blue = UCharRGB(0,0,255);
      const UCharRGB magenta = UCharRGB(255,0,255);
      const UCharRGB cyan = UCharRGB(0,255,255);
      const UCharRGB yellow = UCharRGB(255,255,0);
      const UCharRGB lightgray = UCharRGB(191,191,191);
      const UCharRGB gray = UCharRGB(127,127,127);
      const UCharRGB darkgray = UCharRGB(63,63,63);

    }; // basicColors
  }; // color
}; // nrec

#endif
