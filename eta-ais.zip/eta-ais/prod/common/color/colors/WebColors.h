///////////////////////////////////////////////////////////////////////////////
/// @file      WebColors.h
/// @author    bode
/// @date      9/4/2008
/// @brief     The set of standard web colors
///
/// 
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef WebColors_h
#define WebColors_h

#include "../RGB.h"

namespace nrec {
  namespace color {
    namespace webColors {

      // These are the rest of the 140 web-colors in alphabetical order
      const UCharRGB aliceblue = UCharRGB(240,228,255);
      const UCharRGB antiquewhite = UCharRGB(250,235,215);
      const UCharRGB aqua = UCharRGB(0,255,255);
      const UCharRGB aquamarine = UCharRGB(127,255,212);
      const UCharRGB azure = UCharRGB(240,255,255);
      const UCharRGB beige = UCharRGB(245,245,220);
      const UCharRGB bisque = UCharRGB(255,228,196);
      const UCharRGB black = UCharRGB(0,0,0);
      const UCharRGB blanchedalmond = UCharRGB(255,255,205);
      const UCharRGB blue = UCharRGB(0,0,255);
      const UCharRGB blueviolet = UCharRGB(138,43,226);
      const UCharRGB brown = UCharRGB(165,42,42);
      const UCharRGB burlywood = UCharRGB(222,184,135);
      const UCharRGB vadetbule = UCharRGB(95,158,160);
      const UCharRGB chartreuse = UCharRGB(127,255,0);
      const UCharRGB chocolate = UCharRGB(210,105,30);
      const UCharRGB coral = UCharRGB(255,127,80);
      const UCharRGB cornflowerblue = UCharRGB(100,149,237);
      const UCharRGB cornsilk = UCharRGB(255,248,220);
      const UCharRGB crimson = UCharRGB(220,20,60);
      const UCharRGB cyan = UCharRGB(0,255,255);
      const UCharRGB darkblue = UCharRGB(0,0,139);
      const UCharRGB darkcyan = UCharRGB(0,139,139);
      const UCharRGB darkgoldenrod = UCharRGB(184,134,11);
      const UCharRGB darkgray = UCharRGB(169,169,169);
      const UCharRGB darkgreen = UCharRGB(0,100,0);
      const UCharRGB darkkhaki = UCharRGB(189,183,107);
      const UCharRGB darkmagenta = UCharRGB(139,0,139);
      const UCharRGB darkolivegreen = UCharRGB(85,107,47);
      const UCharRGB darkorange = UCharRGB(255,140,0);
      const UCharRGB darkorchid = UCharRGB(153,50,204);
      const UCharRGB darkred = UCharRGB(139,0,0);
      const UCharRGB darksalmon = UCharRGB(233,150,122);
      const UCharRGB darkseagreen = UCharRGB(143,188,143);
      const UCharRGB darkslateblue = UCharRGB(72,61,139);
      const UCharRGB darkslategray = UCharRGB(47,79,79);
      const UCharRGB darkturquoise = UCharRGB(0,206,209);
      const UCharRGB darkviolet = UCharRGB(148,0,211);
      const UCharRGB deeppink = UCharRGB(255,20,147);
      const UCharRGB deepskyblue = UCharRGB(0,191,255);
      const UCharRGB dimgray = UCharRGB(105,105,105);
      const UCharRGB dodgerblue = UCharRGB(30,144,255);
      const UCharRGB firebrick = UCharRGB(178,34,34);
      const UCharRGB floralwhite = UCharRGB(255,250,240);
      const UCharRGB forestgreen = UCharRGB(34,139,34);
      const UCharRGB fushsia = UCharRGB(255,0,255);
      const UCharRGB gainsboro = UCharRGB(220,220,220);
      const UCharRGB ghostwhite = UCharRGB(248,248,255);
      const UCharRGB gold = UCharRGB(255,215,0);
      const UCharRGB goldenrod = UCharRGB(218,165,32);
      const UCharRGB gray = UCharRGB(128,128,128);
      const UCharRGB green = UCharRGB(0,128,0);
      const UCharRGB greenyellow = UCharRGB(173,255,47);
      const UCharRGB honeydew = UCharRGB(240,255,240);
      const UCharRGB hotpink = UCharRGB(255,105,180);
      const UCharRGB indianred = UCharRGB(205,92,92);
      const UCharRGB indigo = UCharRGB(75,0,130);
      const UCharRGB ivory = UCharRGB(255,240,240);
      const UCharRGB khaki = UCharRGB(240,230,140);
      const UCharRGB lavender = UCharRGB(230,230,250);
      const UCharRGB lavenderblush = UCharRGB(255,240,245);
      const UCharRGB lawngreen = UCharRGB(124,252,0);
      const UCharRGB lemonchiffon = UCharRGB(255,250,205);
      const UCharRGB lightblue = UCharRGB(173,216,230);
      const UCharRGB lightcoral = UCharRGB(240,128,128);
      const UCharRGB lightcyan = UCharRGB(224,255,255);
      const UCharRGB lightgoldenrodyellow = UCharRGB(250,250,210);
      const UCharRGB lightgreen = UCharRGB(144,238,144);
      const UCharRGB lightgrey = UCharRGB(211,211,211);
      const UCharRGB lightpink = UCharRGB(255,182,193);
      const UCharRGB lightsalmon = UCharRGB(255,160,122);
      const UCharRGB lightseagreen = UCharRGB(32,178,170);
      const UCharRGB lightskyblue = UCharRGB(135,206,250);
      const UCharRGB lightslategray = UCharRGB(119,136,153);
      const UCharRGB lightsteelblue = UCharRGB(176,196,222);
      const UCharRGB lightyellow = UCharRGB(255,255,224);
      const UCharRGB lime = UCharRGB(0,255,0);
      const UCharRGB limegreen = UCharRGB(50,205,50);
      const UCharRGB linen = UCharRGB(250,240,230);
      const UCharRGB magenta = UCharRGB(255,0,255);
      const UCharRGB maroon = UCharRGB(128,0,0);
      const UCharRGB mediumaquamarine = UCharRGB(102,205,170);
      const UCharRGB mediumblue = UCharRGB(0,0,205);
      const UCharRGB mediumorchid = UCharRGB(186,85,211);
      const UCharRGB mediumpurple = UCharRGB(147,112,219);
      const UCharRGB mediumseagreen = UCharRGB(60,179,113);
      const UCharRGB mediumslateblue = UCharRGB(123,104,238);
      const UCharRGB mediumspringgreen = UCharRGB(0,250,154);
      const UCharRGB mediumturquoise = UCharRGB(72,209,204);
      const UCharRGB mediumvioletred = UCharRGB(199,21,133);
      const UCharRGB midnightblue = UCharRGB(25,25,112);
      const UCharRGB mintcream = UCharRGB(245,255,250);
      const UCharRGB mistyrose = UCharRGB(255,228,225);
      const UCharRGB moccasin = UCharRGB(255,228,181);
      const UCharRGB navajowhite = UCharRGB(255,222,173);
      const UCharRGB navy = UCharRGB(0,0,128);
      const UCharRGB oldlace = UCharRGB(253,245,230);
      const UCharRGB olive = UCharRGB(128,128,0);
      const UCharRGB olivedrab = UCharRGB(107,142,35);
      const UCharRGB orange = UCharRGB(255,165,0);
      const UCharRGB orangered = UCharRGB(255,69,0);
      const UCharRGB orchid = UCharRGB(218,112,214);
      const UCharRGB palegoldenrod = UCharRGB(238,232,170);
      const UCharRGB palegreen = UCharRGB(152,251,152);
      const UCharRGB paleturquoise = UCharRGB(175,238,238);
      const UCharRGB palevioletred = UCharRGB(219,112,147);
      const UCharRGB papayawhip = UCharRGB(255,239,213);
      const UCharRGB peachpuff = UCharRGB(255,239,213);
      const UCharRGB peru = UCharRGB(205,133,63);
      const UCharRGB pink = UCharRGB(255,192,203);
      const UCharRGB plum = UCharRGB(221,160,221);
      const UCharRGB powderblue = UCharRGB(176,224,230);
      const UCharRGB purple = UCharRGB(128,0,128);
      const UCharRGB red = UCharRGB(255,0,0);
      const UCharRGB rosybrown = UCharRGB(188,143,143);
      const UCharRGB royalblue = UCharRGB(65,105,225);
      const UCharRGB saddlebrown = UCharRGB(139,69,19);
      const UCharRGB salmon = UCharRGB(250,128,114);
      const UCharRGB sandybrown = UCharRGB(244,164,96);
      const UCharRGB seagreen = UCharRGB(46,139,87);
      const UCharRGB seashell = UCharRGB(255,245,238);
      const UCharRGB sienna = UCharRGB(160,82,45);
      const UCharRGB silver = UCharRGB(192,192,192);
      const UCharRGB skyblue = UCharRGB(135,206,235);
      const UCharRGB slateblue = UCharRGB(106,90,205);
      const UCharRGB slategray = UCharRGB(112,128,144);
      const UCharRGB snow = UCharRGB(255,250,250);
      const UCharRGB springgreen = UCharRGB(0,255,127);
      const UCharRGB steelblue = UCharRGB(70,130,180);
      const UCharRGB tan = UCharRGB(210,180,140);
      const UCharRGB teal = UCharRGB(0,128,128);
      const UCharRGB thistle = UCharRGB(216,191,216);
      const UCharRGB tomato = UCharRGB(253,99,71);
      const UCharRGB turquoise = UCharRGB(64,224,208);
      const UCharRGB violet = UCharRGB(238,130,238);
      const UCharRGB wheat = UCharRGB(245,222,179);
      const UCharRGB white = UCharRGB(255,255,255);
      const UCharRGB whitesmoke = UCharRGB(245,245,245);
      const UCharRGB yellow = UCharRGB(255,255,0);
      const UCharRGB yellowgreen = UCharRGB(154,205,50);

    }; // webColors
  }; // color
}; // nrec

#endif

