///////////////////////////////////////////////////////////////////////////////
/// @file      testColor.cpp
/// @author    bode
/// @date      9/4/2008
/// @brief     Unit tests for the color library
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////

#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE "Unit tests for serializable specialization"
#include <iostream>
#include <cmath>
#include <boost/test/unit_test.hpp>

#include "../RGB.h"
#include "../ColorMapRGB.h"
#include "../PaletteRGB.h"
#include "../colors/WebColors.h"
#include "../colors/BasicColors.h"
#include "../colorPalettes/JetColorPalette64.h"
#include "../colorPalettes/HotColorPalette64.h"

using namespace nrec::color;

BOOST_AUTO_TEST_SUITE( colorTestSuite )

BOOST_AUTO_TEST_CASE(testUCharRGB) {

  UCharRGB ucharColor1;
  UCharRGB ucharColor2(255, 23, 156);
  UCharRGB ucharColor3(ucharColor2);

  BOOST_CHECK(almostEqual(ucharColor2, ucharColor3, (unsigned char)(0)));
  ucharColor1.r() = 128;
  ucharColor1.g() = 22;
  ucharColor1.b() = 19;
  BOOST_CHECK_EQUAL(ucharColor1.r(), 128);
  BOOST_CHECK_EQUAL(ucharColor1.g(), 22);
  BOOST_CHECK_EQUAL(ucharColor1.b(), 19);

  const unsigned char* colorVector = ucharColor1.getColorVector();
  BOOST_CHECK_EQUAL(colorVector[0], 128);
  BOOST_CHECK_EQUAL(colorVector[1], 22);
  BOOST_CHECK_EQUAL(colorVector[2], 19);

  //std::cerr << "UChar Color 1:" << ucharColor1 << "\n";
  /*
  UCharRGB ucharColor4 = interpolateColors(basicColors::red, basicColors::yellow, 0.5);
  BOOST_CHECK_EQUAL(ucharColor4.r(), 255);
  BOOST_CHECK_EQUAL(ucharColor4.g(), 128);
  BOOST_CHECK_EQUAL(ucharColor4.b(), 0);

  UCharRGB ucharColor5 = interpolateColors(basicColors::red, basicColors::yellow, 0.2);
  BOOST_CHECK(ucharColor4.g() > ucharColor5.g());

  UCharRGB ucharColor6(webColors::aliceblue);
  */
}

BOOST_AUTO_TEST_CASE(testDoubleRGB) {

  DoubleRGB doubleColor1;
  DoubleRGB doubleColor2(0.5, 0.2, 0.0);
  DoubleRGB doubleColor3(doubleColor2);

  BOOST_CHECK(almostEqual(doubleColor2, doubleColor3, 0.0));
  doubleColor1.r() = 0.45;
  doubleColor1.g() = 0.87;
  doubleColor1.b() = 0.15;
  BOOST_CHECK_EQUAL(doubleColor1.r(), 0.45);
  BOOST_CHECK_EQUAL(doubleColor1.g(), 0.87);
  BOOST_CHECK_EQUAL(doubleColor1.b(), 0.15);

  const double* colorVector = doubleColor1.getColorVector();
  BOOST_CHECK_EQUAL(colorVector[0], 0.45);
  BOOST_CHECK_EQUAL(colorVector[1], 0.87);
  BOOST_CHECK_EQUAL(colorVector[2], 0.15);

  //std::cerr << "Double Color 1:" << doubleColor1 << "\n";

  /*
  DoubleRGB doubleColor4 = interpolateColors(convertStorage<double>(basicColors::red),
                                             convertStorage<double>(basicColors::yellow), 0.5);
  BOOST_CHECK_EQUAL(doubleColor4.r(), 1.0);
  BOOST_CHECK_EQUAL(doubleColor4.g(), 0.5);
  BOOST_CHECK_EQUAL(doubleColor4.b(), 0);

  DoubleRGB doubleColor5 = interpolateColors(convertStorage<double>(basicColors::red),
                                             convertStorage<double>(basicColors::yellow), 0.2);

  BOOST_CHECK(doubleColor4.g() > doubleColor5.g());
  */
}


BOOST_AUTO_TEST_CASE(testJetColorMap) {
  double minVal = 0.0;
  double maxVal = 100.0;
  PaletteRGB<double> jetColorPalette(JetColorPalette64, 64);
  ColorMapRGB<double> myJetColorMap(minVal, maxVal);
  myJetColorMap.setClippingColors(convertStorage<double>(webColors::powderblue),
                                  convertStorage<double>(webColors::peachpuff));
  myJetColorMap.addPalette("jetColor", jetColorPalette);
  for(double d=-3.0; d <= 104.0; d=d+5.0) {
    DoubleRGB color = myJetColorMap.valueToColor(d);

    if(d < minVal)
      BOOST_CHECK(almostEqual(convertStorage<double>(webColors::powderblue),
                              color, 0.01));
    if(d > maxVal)
      BOOST_CHECK(almostEqual(convertStorage<double>(webColors::peachpuff),
                              color, 0.01));

    double value = 0.0;

    BOOST_CHECK(myJetColorMap.colorToValue(color,value,0.01));
    //std::cerr << "value " << d << " color " << color << " newVal " << value << "\n";
    BOOST_CHECK(fabs(value-d) <= 5.0);
  }
}


BOOST_AUTO_TEST_CASE(testHotColorMap) {
  double minVal = 0.0;
  double maxVal = 100.0;
  PaletteRGB<double> hotColorPalette(HotColorPalette64, 64);
  PaletteRGB<double> jetColorPalette(JetColorPalette64, 64);
  ColorMapRGB<double> myColorMap(minVal, maxVal);
  myColorMap.addPalette("hotColor", hotColorPalette);
  myColorMap.addPalette("jetColor", jetColorPalette);
  myColorMap.setClippingColors(convertStorage<double>(webColors::peachpuff),
                               convertStorage<double>(webColors::mediumspringgreen));

  bool diff = false;
  for(double d=-5.0; d <= 106.0; d=d+5.0) {
    myColorMap.setPalette("hotColor");
    DoubleRGB color1 = myColorMap.valueToColor(d);
    if(d < minVal) {
      BOOST_CHECK(almostEqual(convertStorage<double>(webColors::peachpuff),
                              color1, 0.01));
    }
    if(d > maxVal) {
      BOOST_CHECK(almostEqual(convertStorage<double>(webColors::mediumspringgreen),
                              color1, 0.01));
    }
    myColorMap.setPalette("jetColor");
    DoubleRGB color2 = myColorMap.valueToColor(d);
    diff = diff | !almostEqual(color1, color2, 0.01);
    double value = 0.0;
    BOOST_CHECK(myColorMap.colorToValue(color2,value,0.01));
    // std::cerr << "color1 " << color1 << " color2 " << color2 << "\n";
    BOOST_CHECK(fabs(value-d) <= 5.0);
  }
  BOOST_CHECK(diff);
}

BOOST_AUTO_TEST_CASE(testDualColorMaps) {
  double minVal = 0.0;
  double maxVal = 100.0;
  PaletteRGB<double> hotColorPalette(HotColorPalette64, 64);
  ColorMapRGB<double> myHotColorMap(minVal, maxVal);
  myHotColorMap.setClippingColors(convertStorage<double>(webColors::pink),
                                  convertStorage<double>(webColors::mediumspringgreen));
  myHotColorMap.addPalette("hotColor", hotColorPalette);

  for(double d=-5.0; d <= 106.0; d=d+5.0) {
    DoubleRGB color = myHotColorMap.valueToColor(d);
    if(d < minVal)
      BOOST_CHECK(almostEqual(convertStorage<double>(webColors::pink),
                              color, 0.01));
    if(d > maxVal)
      BOOST_CHECK(almostEqual(convertStorage<double>(webColors::mediumspringgreen),
                              color, 0.01));
    double value = 0.0;
    BOOST_CHECK(myHotColorMap.colorToValue(color,value,0.01));
    //std::cerr << "value " << d << " color " << color << " newVal " << value << "\n";
    BOOST_CHECK(fabs(value-d) <= 5.0);
  }
}



BOOST_AUTO_TEST_SUITE_END()

