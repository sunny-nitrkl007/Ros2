///////////////////////////////////////////////////////////////////////////////
/// @file      RGBA.h
/// @author    bode
/// @date      9/3/2008
/// @brief     Storage and methods for RGBA colors
///
/// 
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef RGBA_h
#define RGBA_h

#include <iostream>
#include "ColorBase.h"

namespace nrec{
  namespace color {

template <typename Storage>
class RGBA : public ColorBase<Storage, 4> {
public:
  typedef Storage StorageType;
  static const unsigned int NumComponents = ColorBase<Storage, 4>::NumComponents;   
  enum{RedIndex,GreenIndex,BlueIndex,AlphaIndex};
  RGBA() {
    r() = ColorStorageTraits<Storage>::maxValue; 
    g() = ColorStorageTraits<Storage>::maxValue; 
    b() = ColorStorageTraits<Storage>::maxValue;
    a() = ColorStorageTraits<Storage>::maxValue;
  }
  RGBA(StorageType rr, StorageType gg, StorageType bb, StorageType aa) {
    r() = rr; g() = gg; b() = bb; a() = aa;
  }
  RGBA(const StorageType col[NumComponents]) {
    r() = col[RedIndex]; g() = col[GreenIndex]; b() = col[BlueIndex];
  }
  inline StorageType& r() {return this->m_color[RedIndex];}
  inline StorageType& g() {return this->m_color[GreenIndex];}
  inline StorageType& b() {return this->m_color[BlueIndex];}
  inline StorageType& a() {return this->m_color[AlphaIndex];}
  inline const StorageType& r() const {return this->m_color[RedIndex];}
  inline const StorageType& g() const {return this->m_color[GreenIndex];}
  inline const StorageType& b() const {return this->m_color[BlueIndex];}
  inline const StorageType& a() const {return this->m_color[AlphaIndex];}
  inline const StorageType* getColorVector() const {return this->m_color;}
};


template <typename StorageDest, typename ColorSrc>
RGBA<StorageDest> convertStorage(const RGBA<ColorSrc>& colorSrc) {
  RGBA<StorageDest> ret;
  ret.r() = storageConversion<StorageDest>(colorSrc.r());
  ret.g() = storageConversion<StorageDest>(colorSrc.g());
  ret.b() = storageConversion<StorageDest>(colorSrc.b());
  ret.a() = storageConversion<StorageDest>(colorSrc.a());
  return ret;
}

template <typename Storage>
bool almostEqual(const RGBA<Storage>& lhs, const RGBA<Storage>& rhs, Storage tolerance) {
  Storage dr,dg,db,da;
  if(lhs.r() > rhs.r()) dr = lhs.r() - rhs.r();
  else dr = rhs.r() - lhs.r();
  if(dr > tolerance) return false; 
  if(lhs.g() > rhs.g()) dg = lhs.g() - rhs.g();
  else dg = rhs.g() - lhs.g();
  if(dg > tolerance) return false; 
  if(lhs.b() > rhs.b()) db = lhs.b() - rhs.b();
  else db = rhs.b() - lhs.b();
  if(db > tolerance) return false;
  if(lhs.a() > rhs.a()) da = lhs.a() - rhs.a();
  else da = rhs.a() - lhs.a();
  if(da > tolerance) return false;
  return true; 
}



template <typename Storage>
inline std::ostream& operator << (std::ostream& out, const RGBA<Storage>& c) {
  return out << "R: " << c.r() << " G:" << c.g() << " B:" << c.b() << " A:" << c.a() << " ";
}

template <>
inline std::ostream& operator << (std::ostream& out, const RGBA<char> & c) {
  return out << "R: " << (int)c.r() << " G:" << (int)c.g() << " B:" << (int)c.b() << " A:" << (int)c.a() << " ";
}

template <>
inline std::ostream& operator << (std::ostream& out, const RGBA<unsigned char> & c) {
  return out << "R: " << (int)c.r() << " G:" << (int)c.g() << " B:" << (int)c.b() << " A:" << (int)c.a() << " ";
}


// typedefs - for RGBA colors
typedef RGBA<double> DoubleRGBA; 
typedef RGBA<float>  FloatRGBA; 
typedef RGBA<int>  IntRGBA;
typedef RGBA<unsigned int> UIntRGBA;
typedef RGBA<short>  ShortRGBA;
typedef RGBA<unsigned short> UShortRGBA;
typedef RGBA<char> CharRGBA;
typedef RGBA<unsigned char> UCharRGBA;

  };  // namespace color
};  // namespace nrec

#endif

