///////////////////////////////////////////////////////////////////////////////
/// @file      PaletteRGB.h
/// @author    bode
/// @date      9/3/2008
/// @brief     Interface for palettes
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef PaletteRGB_h
#define PaletteRGB_h
#include <vector>

#include "RGB.h"

namespace nrec {
  namespace color {

template <typename StorageType>
class PaletteRGB
{ 
public:
  PaletteRGB(const StorageType palette[][RGB<StorageType>::NumComponents], unsigned int numColors) {
    for(unsigned int index=0; index < numColors; ++index) {
      m_colors.push_back(RGB<StorageType>(palette[index]));
    }
  }
  unsigned int getNumColors() {return m_colors.size(); }
  RGB<StorageType> getColor(unsigned int index) { return m_colors[index]; }
private:
  std::vector<RGB<StorageType> > m_colors;  
};

  }; // namespace color
}; // namespace nrec

#endif
