///////////////////////////////////////////////////////////////////////////////
/// @file      ColorMapRGB.h
/// @author    bode
/// @date      9/3/2008
/// @brief     Interface for color maps
///
/// This object defines the interface for using color maps.  Color maps
/// are stored as a fixed size array of rgb color values.  This allows users to
/// create their own color maps easily.  Several color maps are included with
/// this library and can be found in the colorMaps directory.  These include
/// Hot color, Jet Color, HSV Color and many others.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef ColorMapRGB_h
#define ColorMapRGB_h

#include <map>
#include <string>
#include <vector>
#include "PaletteRGB.h"

namespace nrec {
  namespace color {

template<typename ValueType>
class ColorMapRGB {
public:
  typedef double StorageType;
  typedef RGB<StorageType> ColorType;
  typedef PaletteRGB<StorageType> PaletteType;
  explicit ColorMapRGB(ValueType minVal = 0, ValueType maxVal = 1):
    m_clippingColorsSet(false), m_paletteSet(false), m_absoluteColorMod(false),
    m_minValue(minVal), m_maxValue(maxVal) {}

  ColorType valueToColor(ValueType val) const {
    if(m_paletteSet)
    {
      int index = 0;
      if (m_absoluteColorMod)
      {
        // This is an absolute color map that wraps around so we can do value MOD range
        double range = m_maxValue - m_minValue;
        double modValue = fmod(val + m_minValue, range) / range;
        if(modValue<0) ++modValue;
        index = static_cast<int>(modValue * m_currentPalette->second.getNumColors());
      }
      else
      {
        index = static_cast<int>(
          ((val - m_minValue)/(m_maxValue - m_minValue)) * 
          m_currentPalette->second.getNumColors());
        if(index < 0) return m_lowClippingColor;
        if(index >= static_cast<int>(m_currentPalette->second.getNumColors())) return m_highClippingColor;      
      }
      return m_currentPalette->second.getColor(index);
    }
    else {
      ColorType ret;
      return ret;
    }
  }

  // returns the lowest value that matches the passed color within the passed
  // tolerance
  bool colorToValue(const ColorType& color, ValueType& value,
                    StorageType tolerance) const {
    if(m_paletteSet) {
      if(almostEqual(color,m_lowClippingColor,tolerance)) {
        value = m_minValue;
        return true;
      }
      if(almostEqual(color,m_highClippingColor,tolerance)) {
        value = m_maxValue;
        return true;
      }
      for(unsigned int index = 0;
           index < m_currentPalette->second.getNumColors(); ++index) {
        if(almostEqual(color, m_currentPalette->second.getColor(index), tolerance)) {
          value = static_cast<ValueType>(
            (static_cast<double>(index)/m_currentPalette->second.getNumColors()) *
            (m_maxValue - m_minValue));
          return true;
        }
      }
    }
    return false;
  }

  void setAbsoluteColorMod(bool absoluteMod) {
    m_absoluteColorMod = absoluteMod;
  }
  bool getAbsoluteColorMod() {
    return m_absoluteColorMod;
  }
  void setMinValue(ValueType minVal) {
    m_minValue = minVal;
  }
  void setMaxValue(ValueType maxVal) {
    m_maxValue = maxVal;
  }
  ValueType getMinValue() const {
    return m_minValue;
  }
  ValueType getMaxValue() const {
    return m_maxValue;
  }
  void setClippingColors(ColorType clippedLowColor, ColorType clippedHighColor) {
    m_clippingColorsSet = true;
    m_lowClippingColor = clippedLowColor;
    m_highClippingColor = clippedHighColor;
  }
  void getClippingColors(ColorType& clippedLowColor, ColorType& clippedHighColor) const {
    clippedLowColor = m_lowClippingColor;
    clippedHighColor = m_highClippingColor;
  }
  bool addPalette(const std::string& paletteName, const PaletteType& newPalette) {
    std::pair<Palettes::iterator, bool> ret =
      m_palettes.insert(std::make_pair(paletteName, newPalette));
    if(ret.second)
    {
      m_currentPalette = ret.first;
      if(!m_clippingColorsSet) {
        unsigned int n = m_currentPalette->second.getNumColors();
        if(n) {
          m_lowClippingColor = m_currentPalette->second.getColor(0);
          m_highClippingColor = m_currentPalette->second.getColor(n-1);
        }
      }
      m_paletteSet = true;
    }
    return ret.second;
  }
  bool setPalette(const std::string& paletteName) {
    Palettes::iterator iter = m_palettes.find(paletteName);
    if(iter != m_palettes.end()) {
      m_currentPalette = iter;
      if(!m_clippingColorsSet) {
        unsigned int n = m_currentPalette->second.getNumColors();
        if(n) {
          m_lowClippingColor = m_currentPalette->second.getColor(0);
          m_highClippingColor = m_currentPalette->second.getColor(n-1);
        }
      }
      return true;
    }
    std::cerr << "Palette " << paletteName << " not found\n";
    return false;
  }

private:
  bool m_clippingColorsSet;
  bool m_paletteSet;
  bool m_absoluteColorMod;
  ValueType m_minValue;
  ValueType m_maxValue;
  ColorType m_lowClippingColor;
  ColorType m_highClippingColor;
  typedef std::map<std::string, PaletteType> Palettes;
  Palettes m_palettes;
  Palettes::iterator m_currentPalette;
};

  }; // namespace color
}; // namespace nrec

#endif

