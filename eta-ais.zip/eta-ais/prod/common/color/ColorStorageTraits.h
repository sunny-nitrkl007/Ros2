///////////////////////////////////////////////////////////////////////////////
/// @file      ColorStorageTraits.h
/// @author    bode
/// @date      9/3/2008
/// @brief     Defines bounds for different storage types
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef ColorStorageTraits_h
#define ColorStorageTraits_h

#include <limits.h>

namespace nrec
{
  namespace color
  {

///////////////////////////////////////////////////////////////////////////////
/// @brief Storage traits for pixel elements
///
/// This class defines the mapping for converting between different storage 
/// types while still maintaining the same desired color values.
/// 
/// The defalt specialization handles all floating point types.  Integral types
/// have been specialized to define proper bounds
///////////////////////////////////////////////////////////////////////////////
template <typename StorageType>
class ColorStorageTraits {
public:
  typedef StorageType Type;
  static constexpr StorageType minValue = 0.0; 
  static constexpr StorageType maxValue = 1.0; 
  // this offset is used to insure that integer to floating point to integer 
  // mappings map back to the same original integer value
  static constexpr double roundingErrorOffset = 0.0; 
};

template <>
class ColorStorageTraits<unsigned char> {
public:
  typedef unsigned char Type;
  static const unsigned char minValue = 0;
  static const unsigned char maxValue = UCHAR_MAX;
  static constexpr double roundingErrorOffset = 0.5; 
};

template <>
class ColorStorageTraits<char> {
public:
  typedef char Type;
  static const char minValue = CHAR_MIN;
  static const char maxValue = CHAR_MAX;
  static constexpr double roundingErrorOffset = 0.5; 
};

template <>
class ColorStorageTraits<unsigned short> {
public:
  typedef unsigned short Type;
  static const unsigned short minValue = 0;
  static const unsigned short maxValue = USHRT_MAX;
  static constexpr double roundingErrorOffset = 0.5; 
};

template <>
class ColorStorageTraits<short> {
public:
  typedef short Type;
  static const short minValue = SHRT_MIN;;
  static const short maxValue = SHRT_MAX;
  static constexpr double roundingErrorOffset = 0.5; 
};

template <>
class ColorStorageTraits<unsigned int> {
public:
  typedef unsigned int Type;
  static const unsigned int minValue = 0;
  static const unsigned int maxValue = UINT_MAX;
  static constexpr double roundingErrorOffset = 0.5; 
};

template <>
class ColorStorageTraits<int> {
public:
  typedef int Type;
  static const int minValue = INT_MIN;
  static const int maxValue = INT_MAX;
  static constexpr double roundingErrorOffset = 0.5; 
};

template <>
class ColorStorageTraits<unsigned long> {
public:
  typedef unsigned long Type;
  static const unsigned long minValue = 0;
  static const unsigned long maxValue = ULONG_MAX;
  static constexpr double roundingErrorOffset = 0.5; 
};

template <>
class ColorStorageTraits<long> {
public:
  typedef long Type;
  static const long minValue = LONG_MIN;
  static const long maxValue = LONG_MAX;
  static constexpr double roundingErrorOffset = 0.5; 
};

template <>
class ColorStorageTraits<unsigned long long> {
public:
  typedef unsigned long long Type;
  static const unsigned long long minValue = 0;
  static const unsigned long long maxValue = ULLONG_MAX;
  static constexpr double roundingErrorOffset = 0.5; 
};

template <>
class ColorStorageTraits<long long> {
public:
  typedef long long Type;
  static const long long minValue = LLONG_MIN;
  static const long long maxValue = LLONG_MAX;
  static constexpr double roundingErrorOffset = 0.5; 
};



template<typename SameStorage>
inline SameStorage storageConversion(const SameStorage& srcValue) {
  return srcValue;
}

template<typename DestStorage,typename SrcStorage>
DestStorage storageConversion(const SrcStorage& srcValue) {
  double scale = (srcValue - ColorStorageTraits<SrcStorage>::minValue) / 
    ((double)(ColorStorageTraits<SrcStorage>::maxValue-ColorStorageTraits<SrcStorage>::minValue));
  return (DestStorage)((ColorStorageTraits<DestStorage>::maxValue - 
                        ColorStorageTraits<DestStorage>::minValue) * scale + 
											 ColorStorageTraits<DestStorage>::minValue + 
                       ColorStorageTraits<DestStorage>::roundingErrorOffset);
}

template<typename Storage, typename Argument>
inline void clampValue(Argument& element) {
  if(element > ColorStorageTraits<Storage>::maxValue) element = ColorStorageTraits<Storage>::maxValue;
  if(element < ColorStorageTraits<Storage>::minValue) element = ColorStorageTraits<Storage>::minValue;
} 

  }; // namespace color
}; // namespace nrec
#endif

