///////////////////////////////////////////////////////////////////////////////
/// @file      ColorBase.h
/// @author    bode
/// @date      9/3/2008
/// @brief     A base class for all color objects
///
/// This class defines the storage for the pixel based on the type of storage
/// to be used and the number of components
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef ColorBase_h
#define ColorBase_h

#include "ColorStorageTraits.h"

namespace nrec
{
  namespace color
  {

///////////////////////////////////////////////////////////////////////////////    
/// 
/// \brief Representation of color in component form
///
/// This implemenation of a color class follows the conventions set for by the
/// OpenGL graphics libraray and their use of color.  Particularly:
///
/// Unsigned integer color components, are linearly mapped to floating-point 
/// values such that the largest representable value maps to 1.0 (full 
/// intensity), and 0 maps to 0.0 (zero intensity).
///
/// Signed integer color components, are linearly mapped to floating-point values
/// such that the most positive representable value maps to 1.0, and the most 
/// negative representable value maps to -1.0 (Note that this mapping does not 
/// convert 0 precisely to 0.0.)
///
/// Floating-point values are mapped directly.
/// Neither floating-point nor signed integer values are clamped to the range 
/// [0,1] when operations are performed on the color.
/// Internal structure for colors are contiguous arrays so that fast color 
/// operations can be done using OpenGL
///
/// integer storage types have a range between 0 and typeMax or the optionally  
/// specified limit
///
/// @ingroup NRECColorGroup
///////////////////////////////////////////////////////////////////////////////
template <typename StorageType, unsigned int NComponents>
class ColorBase {
public:
  typedef ColorStorageTraits<StorageType> StorageTraits;
  static const unsigned int NumComponents = NComponents; 
protected:
  StorageType m_color[NComponents];
};

  }; // namespace color
}; // namespace nrec
#endif

