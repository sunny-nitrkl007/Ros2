////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file      RasterizePolygon.h
/// @author    bode
/// @date      02/09/2010
///
/// @brief
///
///
///
///
/// @attention Copyright (C) 2010
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef RasterizePolygonToGrid_h
#define RasterizePolygonToGrid_h

#include <vector>
#include <algorithm>

#include "spatial/grid/Grid.h"
#include "spatial/grid/GridFloor.h"
#include "spatial/coordinate/SizeType.h"
namespace nrec
{
  namespace spatial
  {

template<typename Grid, typename InternalCellFunction>
bool rasterizeToGrid(const Grid& grid,
		     const std::vector<typename Grid::WorldPoint>& polygon,
		     InternalCellFunction& cellInside)
{

  typedef typename Grid::WorldPoint WorldPoint;
  typedef typename WorldPoint::value_type WorldPointValue;
  typedef typename Grid::GridPoint GridPoint;
  typedef typename GridPoint::ValueType GridPointValue;
  typedef typename std::vector<WorldPoint> PolygonType;
  typedef SizeType<2> Sizes;

  // compile time assert to make sure the map is 2D

  // make sure that the polygon has at least three points
  unsigned int numPolyVerts = polygon.size();
  if(numPolyVerts < 3) return false;

  // find the bounds of the polygon
  WorldPoint polyMin = polygon.front();
  WorldPoint polyMax = polygon.front();
  for(typename PolygonType::const_iterator citer = polygon.begin()+1; citer != polygon.end(); ++citer) {
    // change these to fast and slow...
    if(citer->x() < polyMin.x()) polyMin.x() = citer->x();
    if(citer->y() < polyMin.y()) polyMin.y() = citer->y();
    if(citer->x() > polyMax.x()) polyMax.x() = citer->x();
    if(citer->y() > polyMax.y()) polyMax.y() = citer->y();
  }


  WorldPoint cellSizes = grid.getCellSize();
  WorldPoint halfCellSizes = grid.getHalfCellSize();
  WorldPoint unitSizes(1.0/cellSizes.x(),1.0/cellSizes.y());
  WorldPoint scanEnd;


  scanEnd.x() = polyMax.x() + cellSizes.x();
  // run a scan line along the fastest dimension of the viewport looking for intersections with the polygon
  GridPointValue gridMinY = gridFloor<GridPointValue>(polyMin.y() * unitSizes.y());
  GridPointValue gridMaxY = gridFloor<GridPointValue>(polyMax.y() * unitSizes.y());


  for (GridPointValue slowGridCurrent = gridMinY; slowGridCurrent <= gridMaxY; ++slowGridCurrent) {
    std::vector<WorldPointValue> intersections; // list of fast coordinate values where intersections occur
    scanEnd.y() = (slowGridCurrent * cellSizes.y()) + halfCellSizes.y();

    WorldPoint vj = polygon.back();
    GridPoint fillCell;
    fillCell.y() = slowGridCurrent;

    for (unsigned int polyVertIndex = 0; polyVertIndex < numPolyVerts; ++polyVertIndex) {
      WorldPoint vi=polygon[polyVertIndex];

      if ((vi.y() < scanEnd.y() &&
           vj.y() >= scanEnd.y()) ||
          (vj.y() < scanEnd.y() &&
           vi.y() >= scanEnd.y())) {

        WorldPointValue intersection = vi.x()+
          (scanEnd.y()-vi.y()) / (vj.y()-vi.y()) *
          (vj.x()-vi.x());

        if (intersection < scanEnd.x()) {
          intersections.push_back(intersection);
        }
      }
      vj = vi;
    }
    std::sort(intersections.begin(),intersections.end());

    for(unsigned int intersectionIndex = 1; intersectionIndex < intersections.size(); intersectionIndex+=2) {
      //map the first worldCordinate to a grid coordinate and then fill in fast dimension until end is reached
      GridPointValue fillStart =
        gridFloor<GridPointValue>((intersections[intersectionIndex-1] +
                                  halfCellSizes.x()) *
                                  unitSizes.x());
      GridPointValue fillEnd =
        gridFloor<GridPointValue>((intersections[intersectionIndex] +
                                   halfCellSizes.x()) *
                                  unitSizes.x()) - 1;


      for(fillCell.x() = fillStart;
           fillCell.x() <= fillEnd;
           ++fillCell.x()) {
        cellInside(fillCell);
      }
    }
  }
  return true;
}

  }
}

#endif
