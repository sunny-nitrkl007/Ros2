////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file      RasterizePolygon.h
/// @author    bode
/// @date      02/09/2010
///
/// @brief
///
///
///
///
/// @attention Copyright (C) 2010
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file      RasterizePolygonIfValid.h
/// @author    bode, ehaywise
/// @date      08/13/2010
///
/// @brief     Simple, quick derivative of RasterizePolygon.h rasterizing polygons if the valid functor alwyays returns true
///
///
/// Derivative of RasterizePolygon.h that only rasterizes polygons if all cells in the rasterize are valid
/// according to the valid cell functor.
///
/// @attention Copyright (C) 2010
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef RasterizePolygonIfValid_h
#define RasterizePolygonIfValid_h

#include <vector>
#include "spatial/gridMap/viewport/Viewport.h"
#include "spatial/grid/GridFloor.h"

namespace nrec
{
  namespace spatial
  {


    template<typename Viewport, typename InternalCellFunction, typename ValidCellFunction>
bool rasterizeIfValid(Viewport& viewport,
                      const std::vector<typename Viewport::WorldPoint>& polygon,
                      InternalCellFunction& cellInside,
                      ValidCellFunction& cellValid)
{

  typedef typename Viewport::WorldPoint WorldPoint;
  typedef typename WorldPoint::value_type WorldPointValue;
  typedef typename Viewport::GridPoint GridPoint;
  typedef typename GridPoint::value_type GridPointValue;
  typedef typename std::vector<WorldPoint> PolygonType;
  typedef SizeType<2> Sizes;
  typedef typename Viewport::IndexingOrder Order;  //!< The row major order of this viewport

  // compile time assert to make sure the map is 2D

  // make sure that the polygon has at least three points
  unsigned int numPolyVerts = polygon.size();
  if(numPolyVerts < 3) return false;

  // find the bounds of the polygon
  WorldPoint polyMin = polygon.front();
  WorldPoint polyMax = polygon.front();
  for(typename PolygonType::const_iterator citer = polygon.begin()+1; citer != polygon.end(); ++citer) {
    // change these to fast and slow...
    if(citer->x() < polyMin.x()) polyMin.x() = citer->x();
    if(citer->y() < polyMin.y()) polyMin.y() = citer->y();
    if(citer->x() > polyMax.x()) polyMax.x() = citer->x();
    if(citer->y() > polyMax.y()) polyMax.y() = citer->y();
  }


  WorldPoint cellSizes = viewport.getCellSize();
  WorldPoint halfCellSizes = viewport.getHalfCellSize();
  WorldPoint unitSizes(1.0/cellSizes.x(),1.0/cellSizes.y());
  WorldPoint scanEnd;
  GridPoint viewportMin = viewport.getViewportMin();
  GridPoint viewportMax = viewport.getViewportMax();


  scanEnd[Order::rm1] = polyMax[Order::rm1] + cellSizes[Order::rm1];
  // run a scan line along the fastest dimension of the viewport looking for intersections with the polygon
  GridPointValue gridMinSlow = gridFloor<GridPointValue>(polyMin[Order::rm0] * unitSizes[Order::rm0]);
  GridPointValue gridMaxSlow = gridFloor<GridPointValue>(polyMax[Order::rm0] * unitSizes[Order::rm0]);

  // clip to the viewport bounds in the slow dimension
  gridMinSlow = std::max(gridMinSlow, viewportMin[Order::rm0]);
  gridMaxSlow = std::min(gridMaxSlow, viewportMax[Order::rm0]);

  for (GridPointValue slowGridCurrent = gridMinSlow; slowGridCurrent <= gridMaxSlow; ++slowGridCurrent) {
    std::vector<WorldPointValue> intersections; // list of fast coordinate values where intersections occur
    scanEnd[Order::rm0] = (slowGridCurrent * cellSizes[Order::rm0]) + halfCellSizes[Order::rm0];

    WorldPoint vj = polygon.back();
    GridPoint fillCell;
    fillCell[Order::rm0] = slowGridCurrent;

    for (unsigned int polyVertIndex = 0; polyVertIndex < numPolyVerts; ++polyVertIndex) {
      WorldPoint vi=polygon[polyVertIndex];
      //std::cerr << "Checking segment : " << vi.x() << " " << vi.y() << " to " << vj.x() << " " << vj.y() << "\n";
      if ((vi[Order::rm0] < scanEnd[Order::rm0] &&
           vj[Order::rm0] >= scanEnd[Order::rm0]) ||
          (vj[Order::rm0] < scanEnd[Order::rm0] &&
           vi[Order::rm0] >= scanEnd[Order::rm0])) {

        WorldPointValue intersection = vi[Order::rm1]+
          (scanEnd[Order::rm0]-vi[Order::rm0]) / (vj[Order::rm0]-vi[Order::rm0]) *
          (vj[Order::rm1]-vi[Order::rm1]);

        if (intersection < scanEnd[Order::rm1]) {
          intersections.push_back(intersection);
        }
      }
      vj = vi;
    }
    std::sort(intersections.begin(),intersections.end());

    bool allCellsValid = true;

    // Check all points for validity
    for(unsigned int intersectionIndex = 1; intersectionIndex < intersections.size(); intersectionIndex+=2) {
      //map the first worldCordinate to a grid coordinate and then fill in fast dimension until end is reached
      GridPointValue fillStart =
        gridFloor<GridPointValue>((intersections[intersectionIndex-1] +
                                  halfCellSizes[Order::rm1]) *
                                  unitSizes[Order::rm1]);
      GridPointValue fillEnd =
        gridFloor<GridPointValue>((intersections[intersectionIndex] -
                                   halfCellSizes[Order::rm1]) *
                                  unitSizes[Order::rm1]);

      // clip to the viewport bounds in the fast dimension
      fillStart = std::max(fillStart, viewportMin[Order::rm1]);
      fillEnd = std::min(fillEnd, viewportMax[Order::rm1]);

      for(fillCell[Order::rm1] = fillStart;
           fillCell[Order::rm1] <= fillEnd;
           ++fillCell[Order::rm1]) {
        allCellsValid &= cellValid(viewport[fillCell], fillCell);
      }
    }

    // Only fill if all cells are valid
    if(allCellsValid)
      {
        for(unsigned int intersectionIndex = 1; intersectionIndex < intersections.size(); intersectionIndex+=2) {
          //map the first worldCordinate to a grid coordinate and then fill in fast dimension until end is reached
          GridPointValue fillStart =
            gridFloor<GridPointValue>((intersections[intersectionIndex-1] +
                                       halfCellSizes[Order::rm1]) *
                                      unitSizes[Order::rm1]);
          GridPointValue fillEnd =
            gridFloor<GridPointValue>((intersections[intersectionIndex] -
                                       halfCellSizes[Order::rm1]) *
                                      unitSizes[Order::rm1]);

          // clip to the viewport bounds in the fast dimension
          fillStart = std::max(fillStart, viewportMin[Order::rm1]);
          fillEnd = std::min(fillEnd, viewportMax[Order::rm1]);


          for(fillCell[Order::rm1] = fillStart;
              fillCell[Order::rm1] <= fillEnd;
              ++fillCell[Order::rm1]) {
            cellInside(viewport[fillCell], fillCell);
          }
        }
      }
  }
  return true;
}

  }
}


#endif
