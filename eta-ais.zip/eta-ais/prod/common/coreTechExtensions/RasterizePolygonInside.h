////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @file      RasterizePolygonInside.h
/// @author    bode, ehaywise
/// @date      07/01/2010
/// 
/// @brief     Simple, quick derivative of RasterizePolygon.h rasterizing polygons completely inside the map.
/// 
/// 
/// Derivative of RasterizePolygon.h that only rasterizes polygons whos bounding box is completely inside the map.  This
/// function is a placeholder.  Its replacement is pending a more generic implementation of rasterize, viewport, or some
/// other to be defined classes or functions that will handle clipping of polygons that cross map boundardies while
/// discarding those that lie completely outside the map.
/// 
/// @attention Copyright (C) 2010
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef RasterizePolygonInside_h
#define RasterizePolygonInside_h


#endif
#include <vector>
#include "../GeoGridMaps.h"
#include "../grid/Grid.h"
#include "../viewport/Viewport.h"
#include "../indexing/IndexingSettings.h"
#include "geometry/primitives/Point2D.h"

namespace nrec
{
  namespace gridMap
  {

template<typename Viewport, typename InternalCellFunction>
bool rasterizeInside(Viewport& viewport, 
               const std::vector<typename Viewport::WorldPoint>& polygon,
               InternalCellFunction& cellInside)
{
  typedef typename Viewport::WorldPoint WorldPoint;
  typedef typename WorldPoint::ValueType WorldPointValue;
  typedef typename Viewport::GridPoint GridPoint;
  typedef typename GridPoint::ValueType GridPointValue;
  typedef typename std::vector<WorldPoint> PolygonType;
  typedef typename Viewport::IndexingOrder::Order Order;
  typedef typename Viewport::Sizes Sizes;

  // compile time assert to make sure the map is 2D
  
  // make sure that the polygon has at least three points
  unsigned int numPolyVerts = polygon.size();
  if(numPolyVerts < 3) 
  {
    std::cerr << "Number of verticies = "<<numPolyVerts<<" < 3. Aborting rasterize().\n"; //@todo Delete
    return false;
  }
  // find the bounds of the polygon
  WorldPoint polyMin = polygon.front();
  WorldPoint polyMax = polygon.front();
  for(typename PolygonType::const_iterator citer = polygon.begin()+1; citer != polygon.end(); ++citer) {
    // change these to fast and slow...
    if(citer->x() < polyMin.x()) polyMin.x() = citer->x();
    if(citer->y() < polyMin.y()) polyMin.y() = citer->y();
    if(citer->x() > polyMax.x()) polyMax.x() = citer->x();
    if(citer->y() > polyMax.y()) polyMax.y() = citer->y();
  }
 
  // Dont procede for polygons off the map or straddled across map boundary
  // @todo Add fancier handling on boundaries
  nrec::geometry::Vector2D_d viewMin = viewport.gridToWorld(viewport.getViewportMin());
  nrec::geometry::Vector2D_d viewMax = viewport.gridToWorld(viewport.getViewportMax());

  if ( ! ( (viewMin.x() < polyMin.x() ) &&
	   (viewMax.x() > polyMax.x() ) &&
	   (viewMin.y() < polyMin.y() ) &&
	   (viewMax.y() > polyMax.y() ) ) )
  {
    return false;
  }
  WorldPoint cellSizes = viewport.getCellSizesInUnits(); 
  WorldPoint halfCellSizes = viewport.getHalfCellSizesInUnits(); 
  WorldPoint unitSizes = viewport.getUnitSizesInCells(); 
  WorldPoint scanEnd;
  
  scanEnd[At<Order,1>::value] = polyMax[At<Order,1>::value] + cellSizes[At<Order,1>::value];
  // run a scan line along the fastest dimension of the viewport looking for intersections with the polygon
  GridPointValue gridMinSlow = gridFloor<GridPointValue>(polyMin[At<Order,0>::value] * unitSizes[At<Order,0>::value]);
  GridPointValue gridMaxSlow = gridFloor<GridPointValue>(polyMax[At<Order,0>::value] * unitSizes[At<Order,0>::value]);
  
  for (GridPointValue slowGridCurrent = gridMinSlow; slowGridCurrent <= gridMaxSlow; ++slowGridCurrent) {
    std::vector<WorldPointValue> intersections; // list of fast coordinate values where intersections occur
    scanEnd[At<Order,0>::value] = (slowGridCurrent * cellSizes[At<Order,0>::value]) + halfCellSizes[At<Order,0>::value];

    WorldPoint vj = polygon.back();
    GridPoint fillCell;
    fillCell[At<Order,0>::value] = slowGridCurrent;
    
    for (unsigned int polyVertIndex = 0; polyVertIndex < numPolyVerts; ++polyVertIndex) {
      WorldPoint vi=polygon[polyVertIndex];
      //std::cerr << "Checking segment : " << vi.x() << " " << vi.y() << " to " << vj.x() << " " << vj.y() << "\n"; 
      if ((vi[At<Order,0>::value] < scanEnd[At<Order,0>::value] && 
           vj[At<Order,0>::value] >= scanEnd[At<Order,0>::value]) ||
          (vj[At<Order,0>::value] < scanEnd[At<Order,0>::value] && 
           vi[At<Order,0>::value] >= scanEnd[At<Order,0>::value])) {

        WorldPointValue intersection = vi[At<Order,1>::value]+
          (scanEnd[At<Order,0>::value]-vi[At<Order,0>::value]) / (vj[At<Order,0>::value]-vi[At<Order,0>::value]) *
          (vj[At<Order,1>::value]-vi[At<Order,1>::value]);

        if (intersection < scanEnd[At<Order,1>::value]) {
          intersections.push_back(intersection);
        }
      }
      vj = vi;
    }
    std::sort(intersections.begin(),intersections.end());
    
    for(unsigned int intersectionIndex = 1; intersectionIndex < intersections.size(); intersectionIndex+=2) {
      //map the first worldCordinate to a grid coordinate and then fill in fast dimension until end is reached      
      GridPointValue fillStart = 
        gridFloor<GridPointValue>((intersections[intersectionIndex-1] +
                                  halfCellSizes[At<Order,1>::value]) * 
                                  unitSizes[At<Order,1>::value]);      
      GridPointValue fillEnd = 
        gridFloor<GridPointValue>((intersections[intersectionIndex] - 
                                   halfCellSizes[At<Order,1>::value]) * 
                                  unitSizes[At<Order,1>::value]);
              
      for(fillCell[At<Order,1>::value] = fillStart; 
           fillCell[At<Order,1>::value] <= fillEnd; 
           ++fillCell[At<Order,1>::value]) {
        cellInside(viewport[fillCell], fillCell);
      }      
    }
  }  
  return true;
}

  }
}
