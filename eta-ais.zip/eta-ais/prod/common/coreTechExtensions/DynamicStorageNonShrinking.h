///////////////////////////////////////////////////////////////////////////////
/// @file      DynamicStorageNonShrinking.h
/// @author    cjgreen
/// @date      02/13/2013
/// @brief     Storage scheme for resizeable grid maps
///
/// @attention Copyright (C) 2013
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////

#ifndef DynamicStorageNonShrinking_h
#define DynamicStorageNonShrinking_h   //!< Include Guard

#include <vector>

///////////////////////////////////////////////////////////////////////////////
/// @brief A storage policy for grid maps where the number of cells can vary
/// The size of the interal vector will never shrink, meaning that cells are
/// never deleted or re-initialized.
///////////////////////////////////////////////////////////////////////////////
template <class Cell>
class DynamicStorageNonShrinking : public DynamicStorage<Cell> {
public:
  typedef Cell CellType; //!< the type of cell being stored

  DynamicStorageNonShrinking():m_currentNumCells(0){}
    
  /////////////////////////////////////////////////////////////////////////////
  /// @brief reserve space for additional cells
  /// @return true on successful reservation, false if allocation fails
  /// @param numCells the number of total cells to store
  /// @note this method can be used to reserve space if an upper bound on the 
  /// size is known to make calls to resize more efficient (reallocation will 
  /// not be triggered)
  /////////////////////////////////////////////////////////////////////////////
  bool reserve(size_t numCells) {
    //Reserve does not change m_currentNumCells
    if (DynamicStorage<CellType>::getNumCells() < numCells)
    {
      return DynamicStorage<CellType>::resize(numCells);
    }
    return true;
  }

  /////////////////////////////////////////////////////////////////////////////
  /// @brief resizes the number of allocated cells
  /// @return true on successful resize, false if allocation fails
  /// @param numCells the number of cells to store
  /// @param val the value to set newly allocated cells to
  /////////////////////////////////////////////////////////////////////////////
  bool resize(size_t numCells, CellType val = CellType()) {
    if (DynamicStorage<CellType>::getNumCells() < numCells)
    {
      if (!DynamicStorage<CellType>::resize(numCells, val))
      {
        return false;
      }
    }
    m_currentNumCells=numCells;
    return true;
  }

  /////////////////////////////////////////////////////////////////////////////
  /// @brief returns the number of used cells in storage
  /// @return the number of cells in storage
  /////////////////////////////////////////////////////////////////////////////
  size_t getNumCells() const {return m_currentNumCells;}
  
private:
  size_t m_currentNumCells;
};

#endif

