///////////////////////////////////////////////////////////////////////////////
/// @file      IntervalGrid.h
/// @author    bode
/// @date      3/2/2010
/// @brief     A compact storage representation of sparse 2D data
///
/// The interval grid allocates memory only for non-empty cells and stores
/// non empty cells in groups of contiguous intervals.  The interval grid
/// can be constructed for fast indexing in either the X or the Y dimension.
/// The inteval image is most efficent in both memory usage and access time
/// if the data is contiguous along the interval dimension
///
/// Consider the following regular 2D grid
///
/// Y
/// ^
/// | -------------------------
/// |5|               ***     |
/// |4|                       |
/// |3|       ************    |
/// |2|    ********     ***   |
/// |1|   *****               |
/// | -------------------------
/// | 123456789ABCDEFGHIJKLMN
/// ---------------------------------->X
///
/// This grid can be stored as an X interval grid as follows:
///   For Y = 1 a single interval is allocated which extends from X = 5:9
///   For Y = 2 a two intervals are allocated which extends from X = 6:D and X = J:L
///   For Y = 3 a single interval is allocated which extends from X = 9:K
///   For Y = 4 no intervals are allocated
///   For Y = 5 a single interval is allocated which extends from X = H:J
///
/// The grid can also be stored as a Y interval grid by decomposing in the vertical direction
///
/// Data can be accessed via grid coordinates.  For an X interval grid the lookup is performed
/// by finding the appropriate Y row of data and then checking to see if the queried X value is
/// contained in any intervals for the Y row.  Access is O(log2(Ni)) where Ni is the number of
/// intervals in the queried row.
///
/// If the desired access pattern traverses K cells that are row contiguous then the access
/// can be optimized to O(K+log2(Ni))
///
/// If it is know that access patterns will always be contiguous in rows or columns, a Dual
/// Interval Grid can be constructed that contains two interval grids (one in x and one in y)
/// that represent the same data.  This data structure will consume twice as much memory
/// as a single interval grid, but will allow for near constant time access to the data
///
///
/// @attention Copyright 2010(C)
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef IntervalGrid_h
#define IntervalGrid_h

#include <vector>
#include <algorithm>
#include <stdio.h>
#include "spatial/gridMap/viewport/Viewport.h"
#include "spatial/grid/GeoGrids.h"

// These two must be included before other boost/serialization headers
#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>


#include <boost/serialization/map.hpp>
#include <boost/serialization/level.hpp>
#include <boost/serialization/tracking.hpp>
#include <boost/serialization/split_member.hpp>
#include <boost/serialization/binary_object.hpp>
#include <boost/serialization/detail/get_data.hpp>
#include <boost/serialization/version.hpp>
#include "geometry/primitives/Box2D.h"
#include "geometry/primitives/Point2D.h"

namespace nrec
{
  namespace spatial
  {

template <typename Interval>
bool intervalComp(const Interval& target, const Interval& test) {
  if(target.viewportOffset < test.viewportOffset) return true;
  return false;
}


template<typename IntervalCell, unsigned int IntervalDim = 0,
  typename GridType = GeoGrid2D >
class IntervalGrid
{
  // todo add static assert to make sure interval dim is 0 or 1
  public:
    typedef typename GridType::GridPoint GridPoint;
    typedef typename GridType::WorldPoint WorldPoint;
    typedef typename GridPoint::value_type GridPointValue;
    typedef typename WorldPoint::value_type WorldPointValue;
    static const unsigned int intervalDim = IntervalDim;
    static const unsigned int nonIntervalDim = 1 - IntervalDim;

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Interval Class that contains the vector of cells
    ///////////////////////////////////////////////////////////////////////////////
    struct Interval
    {
      Interval():viewportOffset(0),startingIndexOffset(0),sizeOfInterval(0) {}
      unsigned int viewportOffset;      ///<  Offset
      unsigned int startingIndexOffset; ///<  Starting index into the overall array of cell data
      unsigned int sizeOfInterval;      ///<  Size of indices for this Interval into the overall array of cell data

      // Load Serialization for Interval Class
      template<class Archive>
      void load(Archive & ar, const unsigned int version)
      {
        switch (version)
        {
          case 0:
            {
              std::vector<unsigned int> cells; // original method stored each cell in Interval
              ar >> viewportOffset >> cells;
              break;
            }
          case 1:
          {
            unsigned int numCells = 0;
            std::vector<unsigned int> cells;// original method stored each cell in Interval
            ar >> viewportOffset;
            ar >> numCells;
            cells.clear();
            cells.resize(numCells);
            ar >> boost::serialization::make_binary_object(boost::serialization::detail::get_data(cells),
                                                           numCells * sizeof(unsigned int));
            break;
          }
          case 2:
            {
              ar >> viewportOffset >> startingIndexOffset >> sizeOfInterval;
              break;
            }
          default:
            {
              std::cerr << "Unknown version for Interval\n";
              break;
            }
        }
      }

      // Save Serialization for Interval Class
      template<class Archive>
      void save(Archive& ar, unsigned int version) const
      {
        switch(version)
        {
          case 0:
          {
            std::vector<unsigned int> cells;// original method stored each cell in Interval
            ar << viewportOffset << cells;
            break;
          }
          case 1:
          {
            std::vector<unsigned int> cells;// original method stored each cell in Interval
            unsigned int numCells = cells.size();
            ar << viewportOffset;
            ar << numCells;
            ar << boost::serialization::make_binary_object(boost::serialization::detail::get_data(cells),
                                                           numCells * sizeof(unsigned int));
            break;
          }
          case 2:
          {
            ar << viewportOffset << startingIndexOffset << sizeOfInterval;
            break;
          }
          default:
            std::cerr << "Unknown version for Interval\n";
            break;
        }
      }

      BOOST_SERIALIZATION_SPLIT_MEMBER();
    };

    typedef std::vector<Interval> IntervalSet;
    typedef std::vector<IntervalSet> IntervalGridType;

    typedef std::pair<const IntervalCell*,GridPointValue> IndexedCell;

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Find interval overlap
    ///////////////////////////////////////////////////////////////////////////////
    std::vector<IndexedCell> findOverlap(const GridPointValue& nonIntervalValue,
                                         const GridPointValue& intervalStart,
                                         unsigned int intervalSize) const
    {
      std::vector<IndexedCell> ret;
      if(!(nonIntervalValue < m_gridMin[nonIntervalDim] || nonIntervalValue > m_gridMax[nonIntervalDim]))
      {
        unsigned int nonIntervalIndex = nonIntervalValue - m_gridMin[nonIntervalDim];
        unsigned int startOffset = 0;
        unsigned int endOffset = 0;

        if(intervalStart+static_cast<int>(intervalSize) >= m_gridMin[intervalDim])
        {
          // the upper end of the interval is greater than the map min
          if(intervalStart >= m_gridMin[intervalDim])
          {
            // the lower end of the interval is greater than the map min
            startOffset = intervalStart - m_gridMin[intervalDim];
            endOffset = startOffset + intervalSize;
          }
          else
          {
            // the lower end of the interval is not on the map
            startOffset = 0;
            endOffset = intervalStart+static_cast<int>(intervalSize)-m_gridMin[intervalDim];
          }
          Interval query;
          query.viewportOffset = startOffset;

          // find the lower interval for the starting point
          typename IntervalSet::const_iterator lowerInterval;
          lowerInterval = std::upper_bound(m_intervalGrid[nonIntervalIndex].begin(),
                                           m_intervalGrid[nonIntervalIndex].end(),
                                           query, intervalComp<Interval>);

          unsigned int currentOffset = startOffset;

          if(lowerInterval != m_intervalGrid[nonIntervalIndex].begin())
          {
            --lowerInterval;
          }
          bool queryEndReached = false;
          while(lowerInterval != m_intervalGrid[nonIntervalIndex].end() && !queryEndReached)
          {
            //see if there is any overlap in the current interval
            currentOffset = std::max(currentOffset, lowerInterval->viewportOffset);
            if(currentOffset >= lowerInterval->viewportOffset)
            {
              for(unsigned int offset = currentOffset - lowerInterval->viewportOffset;
                   (offset < lowerInterval->sizeOfInterval) && (currentOffset < endOffset);
                   ++offset, ++currentOffset)
              {
                IndexedCell cellToAdd;
                unsigned int indexIntoCellData = offset + lowerInterval->startingIndexOffset;
                if (indexIntoCellData < m_cellData.size())
                {
                  cellToAdd.first = &(m_cellData[indexIntoCellData]);
                  cellToAdd.second = currentOffset + m_gridMin[intervalDim];
                  ret.push_back(cellToAdd);
                }
                else
                {
                  fprintf(stderr, "Error: Invalid index into cellDataArray  Index %d -- size Of Array: %d\n",
                          indexIntoCellData ,m_cellData.size());
                }
              }

              if(currentOffset >= endOffset)
              {
                // the end of the query interval has been reached
                queryEndReached = true;
              }
              ++lowerInterval;
            }
          }
        }
      }
      return ret;
    }


    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Access an interval grid using a GridPoint
    ///////////////////////////////////////////////////////////////////////////////
    const IntervalCell* lookUp(const GridPoint& gpQuery) const {
      if(!(gpQuery.x() < m_gridMin.x() || gpQuery.x() > m_gridMax.x() ||
           gpQuery.y() < m_gridMin.y() || gpQuery.y() > m_gridMax.y()))
      {

        unsigned int nonIntervalIndex = gpQuery[nonIntervalDim] - m_gridMin[nonIntervalDim];
        unsigned int intervalIndex = gpQuery[intervalDim] - m_gridMin[intervalDim];
        Interval query;
        query.viewportOffset = intervalIndex;
        typename IntervalSet::const_iterator lowerInterval;

        lowerInterval = std::upper_bound(m_intervalGrid[nonIntervalIndex].begin(),
                                         m_intervalGrid[nonIntervalIndex].end(),
                                         query, intervalComp<Interval>);
        if(lowerInterval != m_intervalGrid[nonIntervalIndex].begin())
        {
          --lowerInterval;

          unsigned int offset = intervalIndex - lowerInterval->viewportOffset;
          if(offset < lowerInterval->sizeOfInterval)
          {
            unsigned int indexIntoCellData = offset + lowerInterval->startingIndexOffset;
            if (indexIntoCellData < m_cellData.size())
            {
              return &m_cellData[indexIntoCellData];
            }
            else
            {
              fprintf(stderr, "Error: Invalid index into cellDataArray  Index %d -- size Of Array: %d\n",
                          indexIntoCellData ,m_cellData.size());
              return NULL;
            }
          }
        }
      }
      return NULL;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Non const accessor for an interval grid using a viewport
    ///////////////////////////////////////////////////////////////////////////////
    IntervalCell* lookUp(const GridPoint& gpQuery) {
      if(!(gpQuery.x() < m_gridMin.x() || gpQuery.x() > m_gridMax.x() ||
           gpQuery.y() < m_gridMin.y() || gpQuery.y() > m_gridMax.y()))
      {
        unsigned int nonIntervalIndex = gpQuery[nonIntervalDim] - m_gridMin[nonIntervalDim];
        unsigned int intervalIndex = gpQuery[intervalDim] - m_gridMin[intervalDim];
        Interval query;
        query.viewportOffset = intervalIndex;
        typename IntervalSet::iterator lowerInterval;

        lowerInterval = std::upper_bound(m_intervalGrid[nonIntervalIndex].begin(),
                                         m_intervalGrid[nonIntervalIndex].end(),
                                         query, intervalComp<Interval>);
        if(lowerInterval != m_intervalGrid[nonIntervalIndex].begin())
        {
          --lowerInterval;

          unsigned int offset = intervalIndex - lowerInterval->viewportOffset;
          if(offset < lowerInterval->sizeOfInterval)
          {
            unsigned int indexIntoCellData = offset + lowerInterval->startingIndexOffset;
            if (indexIntoCellData < m_cellData.size())
            {
              return &m_cellData[indexIntoCellData ];
            }
            else
            {
              fprintf(stderr, "Error: Invalid index into cellDataArray  Index %d -- size Of Array: %d\n",
                          indexIntoCellData ,m_cellData.size());
              return NULL;
            }
          }
        }
      }
      return NULL;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy data from a viewport (of assumed same cell size) to the interval grid
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
      typename HasDataFunction>
    void fromViewport(const Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                      HasDataFunction& hasData) {
      m_gridMin = viewport.getViewportMin();
      m_gridMax = viewport.getViewportMax();
      int cellsInNonIntervalDim = m_gridMax[nonIntervalDim] - m_gridMin[nonIntervalDim] + 1;
      int cellsInIntervalDim = m_gridMax[intervalDim] - m_gridMin[intervalDim] + 1;
      m_intervalGrid.resize(cellsInNonIntervalDim);

      typename Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>::ViewportPoint current;
      for(current[nonIntervalDim] = 0; current[nonIntervalDim] < cellsInNonIntervalDim; ++current[nonIntervalDim])
      {
        Interval thisInterval;
        for(current[intervalDim] = 0; current[intervalDim] < cellsInIntervalDim; ++current[intervalDim])
        {
          IntervalCell intervalCell;
          if(hasData(viewport[current], intervalCell))
          {
            m_cellData.push_back(intervalCell);  // push back cell into overall array of cell data
            if (thisInterval.sizeOfInterval == 0)  // START this interval
            {
              thisInterval.viewportOffset = current[intervalDim];
              thisInterval.startingIndexOffset = m_cellData.size()-1;// store the offset into overall array
            }
            thisInterval.sizeOfInterval++;
          }
          else
          {

            if (thisInterval.sizeOfInterval != 0)  // END interval if its been started
            {
              m_intervalGrid[current[nonIntervalDim]].push_back(thisInterval);  // save Interval

              // clear thisInterval for next one
              thisInterval.startingIndexOffset = 0;
              thisInterval.sizeOfInterval = 0;
              thisInterval.viewportOffset = 0;
            }
          }
        }
        // close the interval if it is still open
        if (thisInterval.sizeOfInterval != 0)
        {
          m_intervalGrid[current[nonIntervalDim]].push_back(thisInterval);  // save Interval

          thisInterval.startingIndexOffset = 0;
          thisInterval.sizeOfInterval = 0;
          thisInterval.viewportOffset = 0;
        }
      }

      // eliminate excess vector capacity using swap trick
      m_intervalGrid[current[nonIntervalDim]].swap(m_intervalGrid[current[nonIntervalDim]]);
      m_cellData.swap(m_cellData);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy data to a viewport (of assumed same cell size) from an interval grid
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
      typename FillCellFunction>
    void toViewport(Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                    FillCellFunction& fillCell) const {
      typedef Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings> ThisViewport;
      typedef typename ThisViewport::GridPoint GridPoint;
      SizeType<2> nCells;
      nCells.x() = m_gridMax.x() - m_gridMin.x() + 1;
      nCells.y() = m_gridMax.y() - m_gridMin.y() + 1;

      viewport.resize(nCells);
      viewport.dragViewportMin(m_gridMin);

      GridPoint currentGP;
      for(unsigned int nonInterval = 0; nonInterval < m_intervalGrid.size(); ++nonInterval)
      {
        currentGP[nonIntervalDim] = m_gridMin[nonIntervalDim] + nonInterval;
        for(unsigned int intervalIndex = 0; intervalIndex < m_intervalGrid[nonInterval].size(); ++intervalIndex)
        {
          currentGP[intervalDim] = m_gridMin[intervalDim] + m_intervalGrid[nonInterval][intervalIndex].viewportOffset;

          for(unsigned int offset = 0; offset < m_intervalGrid[nonInterval][intervalIndex].sizeOfInterval;
               ++offset, ++currentGP[intervalDim])
          {
            unsigned int indexIntoCellData = m_intervalGrid[nonInterval][intervalIndex].startingIndexOffset + offset;
            if (indexIntoCellData < m_cellData.size())
            {
              fillCell(viewport[currentGP], m_cellData[indexIntoCellData], currentGP);
            }
            else
              fprintf(stderr, "Error: Invalid index into cellDataArray  Index %d -- size Of Array: %d\n",
                          indexIntoCellData ,m_cellData.size());
          }
        }
      }
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy contents from interval grid to a viewport, only within specified viewport bounds
    /// We can probably make the first loop much faster.
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
    typename FillCellFunction>
    bool toViewportWithBounds(Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                              FillCellFunction& fillCell, WorldPoint& worldMin, WorldPoint& worldMax) const {
      typedef Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings> ThisViewport;
      typedef typename ThisViewport::GridPoint GridPoint;

      GridPoint gridMin;
      GridPoint gridMax;
      this->worldToGrid(worldMin, gridMin);
      this->worldToGrid(worldMax, gridMax);

      viewport.spanBounds(gridMin, gridMax);

      GridPoint currentGP;
      for(unsigned int nonInterval = 0; nonInterval < m_intervalGrid.size(); ++nonInterval)
      {
        currentGP[nonIntervalDim] = m_gridMin[nonIntervalDim] + nonInterval;
        if( (currentGP[nonIntervalDim] < gridMin[nonIntervalDim]) || (currentGP[nonIntervalDim] > gridMax[nonIntervalDim]) ) { continue; }

        for(unsigned int intervalIndex = 0; intervalIndex < m_intervalGrid[nonInterval].size(); ++intervalIndex)
        {
          currentGP[intervalDim] = m_gridMin[intervalDim] + m_intervalGrid[nonInterval][intervalIndex].viewportOffset;

          for(unsigned int offset = 0; offset < m_intervalGrid[nonInterval][intervalIndex].sizeOfInterval;
                ++offset, ++currentGP[intervalDim])
          {
            if( (currentGP[intervalDim] < gridMin[intervalDim]) || (currentGP[intervalDim] > gridMax[intervalDim]) ) { continue; }

            unsigned int indexIntoCellData = offset + m_intervalGrid[nonInterval][intervalIndex].startingIndexOffset;
            if (indexIntoCellData < m_cellData.size())
            {
              fillCell(viewport[currentGP],  m_cellData[indexIntoCellData], currentGP);
            }
            else
            {
              fprintf(stderr, "Error: Invalid index into cellDataArray  Index %d -- size Of Array: %d\n",
                          indexIntoCellData ,m_cellData.size());
            }
          }
        }
      }
      return true;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy data to a fixed viewport (of assumed same cell size) from an interval grid
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
      typename FillCellFunction>
    bool toFixedViewport(Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                         FillCellFunction& fillCell) const {
      typedef Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings> ThisViewport;
      typedef typename ThisViewport::GridPoint GridPoint;

      GridPoint currentGP;
      for(unsigned int nonInterval = 0; nonInterval < m_intervalGrid.size(); ++nonInterval)
      {
        currentGP[nonIntervalDim] = m_gridMin[nonIntervalDim] + nonInterval;
        for(unsigned int intervalIndex = 0; intervalIndex < m_intervalGrid[nonInterval].size(); ++intervalIndex)
        {
          currentGP[intervalDim] = m_gridMin[intervalDim] + m_intervalGrid[nonInterval][intervalIndex].viewportOffset;

          for(unsigned int offset = 0; offset < m_intervalGrid[nonInterval][intervalIndex].sizeOfInterval;
               ++offset, ++currentGP[intervalDim])
          {
            unsigned int indexIntoCellData = offset + m_intervalGrid[nonInterval][intervalIndex].startingIndexOffset;
            if (indexIntoCellData < m_cellData.size())
            {
              fillCell(viewport[currentGP],  m_cellData[indexIntoCellData], currentGP);
            }
            else
            {
              fprintf(stderr, "Error: Invalid index into cellDataArray  Index %d -- size Of Array: %d\n",
                          indexIntoCellData ,m_cellData.size());
            }
          }
        }
      }
      return true;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy contents from interval grid to a viewport, only within viewport bounds
    /// This avoids searching through content that's not in the viewport
    /// We can probably make the first loop much faster. Clear map before copying data.
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
      typename FillCellFunction>
    bool toFixedViewportWithBounds(Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                         FillCellFunction& fillCell) const {
      typedef Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings> ThisViewport;
      typedef typename ThisViewport::GridPoint GridPoint;

      GridPoint gridMin = viewport.getViewportMin();
      GridPoint gridMax = viewport.getViewportMax();

      GridPoint currentGP;
      for(unsigned int nonInterval = 0; nonInterval < m_intervalGrid.size(); ++nonInterval)
      {
        currentGP[nonIntervalDim] = m_gridMin[nonIntervalDim] + nonInterval;

        if( (currentGP[nonIntervalDim] < gridMin[nonIntervalDim]) || (currentGP[nonIntervalDim] > gridMax[nonIntervalDim]) ) { continue; }

        for(unsigned int intervalIndex = 0; intervalIndex < m_intervalGrid[nonInterval].size(); ++intervalIndex)
        {
          currentGP[intervalDim] = m_gridMin[intervalDim] + m_intervalGrid[nonInterval][intervalIndex].viewportOffset;


          for(unsigned int cellIndex = 0; cellIndex < m_intervalGrid[nonInterval][intervalIndex].sizeOfInterval;
               ++cellIndex, ++currentGP[intervalDim])
          {
            if( (currentGP[intervalDim] < gridMin[intervalDim]) || (currentGP[intervalDim] > gridMax[intervalDim]) ) { continue; }

            unsigned int indexIntoCellData = m_intervalGrid[nonInterval][intervalIndex].startingIndexOffset + cellIndex;
            if (indexIntoCellData < m_cellData.size())
            {
              fillCell(viewport[currentGP], m_cellData[indexIntoCellData], currentGP);
            }
            else
            {
              fprintf(stderr, "Error: Invalid index into cellDataArray  Index %d -- size Of Array: %d\n",
                          indexIntoCellData ,m_cellData.size());
            }
          }
        }
      }
      return true;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Size of interval grid
    ///
    /// @return Size in bytes
    ///////////////////////////////////////////////////////////////////////////////
    double size() const
    {
      double totalMemForGridBytes = 0;

      for (unsigned int ii = 0; ii < m_intervalGrid.size(); ++ii)
      {
        for (unsigned int jj = 0; jj < m_intervalGrid[ii].size(); ++jj)
        {
          totalMemForGridBytes += sizeof(m_intervalGrid[ii][jj].viewportOffset);
          totalMemForGridBytes += sizeof(m_intervalGrid[ii][jj].startingIndexOffset);
          totalMemForGridBytes += sizeof(m_intervalGrid[ii][jj].sizeOfInterval);
        }
      }

      // add in the overall cell data array
      totalMemForGridBytes += sizeof(IntervalCell) * m_cellData.size();

      return totalMemForGridBytes;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Serialize
    ///////////////////////////////////////////////////////////////////////////////

    // Load Serialization for Interval Class
    template<class Archive>
    void load(Archive& ar, unsigned int version)
    {
      switch(version)
      {
        case 0:
        {
          ar >> m_gridMin.x() >> m_gridMin.y() >> m_gridMax.x() >> m_gridMax.y() >> m_intervalGrid;
          break;
        }
        case 1:
        {
          ar >> m_gridMin.x() >> m_gridMin.y() >> m_gridMax.x() >> m_gridMax.y() >> m_intervalGrid;
          unsigned int numCells = 0;
          ar >> numCells;
          m_cellData.clear();
          m_cellData.resize(numCells);
          ar >> boost::serialization::make_binary_object(boost::serialization::detail::get_data(m_cellData),
                                                         numCells * sizeof(IntervalCell));
          break;
        }
        default:
        {
          std::cerr << "Unknown IntervalGrid version "<< version <<"\n";
          break;
        }
      }
    }
    // Save Serialization for Interval Class
    template<class Archive>
    void save(Archive& ar, unsigned int version) const
    {
      switch(version)
      {
        case 0:
        {
          ar << m_gridMin.x() << m_gridMin.y() << m_gridMax.x() << m_gridMax.y() << m_intervalGrid;
          break;
        }
        case 1:
        {
          ar << m_gridMin.x() << m_gridMin.y() << m_gridMax.x() << m_gridMax.y() << m_intervalGrid;
          unsigned int numCells = m_cellData.size();
          ar << numCells;
          ar << boost::serialization::make_binary_object(boost::serialization::detail::get_data(m_cellData),
                                                         numCells * sizeof(IntervalCell));
          break;
        }
        default:
        {
          std::cerr << "Unknown IntervalGrid version "<< version <<"\n";
          break;
        }
      }
    }

    BOOST_SERIALIZATION_SPLIT_MEMBER();

  GridPoint getGridMin() const {
    return m_gridMin;
  }

  GridPoint getGridMax() const {
    return m_gridMax;
  }

  private:
    GridPoint m_gridMin;
    GridPoint m_gridMax;
    IntervalGridType m_intervalGrid;
    std::vector<IntervalCell> m_cellData;  ///< Vector of all the cells.  (Intervals contain references to indices into THIS vector)
};

template<typename IntervalCell, typename GridType = GeoGrid2D >
class DualIntervalGrid
{
  public:
    typedef typename GridType::GridPoint GridPoint;
    typedef typename GridType::WorldPoint WorldPoint;
    typedef typename GridPoint::ValueType GridPointValue;
    typedef std::pair<const IntervalCell*,GridPointValue> IndexedCell;

    std::vector<IndexedCell> findXOverlap(const GridPointValue& yValue, const GridPointValue& xStart,
                                          unsigned int xSize){
      return m_xGrid.findOverlap(yValue,xStart,xSize);
    }
    std::vector<IndexedCell> findYOverlap(const GridPointValue& xValue, const GridPointValue& yStart,
                                          unsigned int ySize){
      return m_yGrid.findOverlap(xValue,yStart,ySize);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Access Dual interval grid using a grid point
    ///////////////////////////////////////////////////////////////////////////////
    const IntervalCell* lookUp(const GridPoint& query) const {
      return m_xGrid.lookUp(query);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get non-constant cell pointers for both x and y interval grids
    /// @param[in] query The coordinate to query
    /// @param[out] pXGridCell A pointer to the cell in the x interval grid (will be NULL if query point is invalid)
    /// @param[out] pYGridCell A pointer to the cell in the y interval grid (will be NULL if query point is invalid)
    ///////////////////////////////////////////////////////////////////////////////
    void lookUp(const GridPoint& query, IntervalCell*& pXGridCell, IntervalCell*& pYGridCell) {
      pXGridCell = m_xGrid.lookUp(query);
      pYGridCell = m_yGrid.lookUp(query);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy contents to dual interval grid from a viewport
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
      typename HasDataFunction>
    void fromViewport(const Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                      HasDataFunction& hasData) {
      m_xGrid.fromViewport(viewport,hasData);
      m_yGrid.fromViewport(viewport,hasData);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy contents from dual interval grid to a viewport
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
      typename FillCellFunction>
    void toViewport(Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                    FillCellFunction& fillCell) const {
      m_xGrid.toViewport(viewport,fillCell);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy contents from dual interval grid to a viewport, only within specified viewport bounds
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
    typename FillCellFunction>
    void toViewportWithBounds(Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                    FillCellFunction& fillCell, GeoGrid2D::WorldPoint& worldMin, GeoGrid2D::WorldPoint& worldMax) const {
      m_xGrid.toViewportWithBounds(viewport,fillCell,worldMin,worldMax);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy contents from dual interval grid to a fixed viewport
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
      typename FillCellFunction>
    void toFixedViewport(Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                    FillCellFunction& fillCell) const {
      m_xGrid.toFixedViewport(viewport,fillCell);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy contents from dual interval grid to a fixed viewport, only within viewport bounds
    /// This avoids searching through content that's not in the viewport
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
      typename FillCellFunction>
    void toFixedViewportWithBounds(Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                    FillCellFunction& fillCell) const {
      m_xGrid.toFixedViewportWithBounds(viewport,fillCell);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy contents from dual interval grid to a fixed viewport
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
      typename FillCellFunction>
    void scrollViewport(Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                        const WorldPoint& newCenter,
                        FillCellFunction& fillCell) const {
      GridPoint gridPointCenter;
      this->worldToGrid(newCenter, gridPointCenter);
      this->scrollViewport(viewport, gridPointCenter, fillCell);
    }


    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Copy contents from dual interval grid to a fixed viewport
    ///////////////////////////////////////////////////////////////////////////////
    template<typename Cell, typename ScrollSettings, typename IndexingSettings, typename StorageSettings,
      typename FillCellFunction>
    void scrollViewport(Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings>& viewport,
                        const GridPoint& newCenter,
                        FillCellFunction& fillCell) {
      typedef Viewport<Cell,GridType,ScrollSettings,IndexingSettings,StorageSettings> ThisViewport;
      typedef typename ThisViewport::MemoryIndex MemoryIndex;

      GridPoint delta = newCenter - viewport.getViewportCenter();
      GridPoint oldMin = viewport.getViewportMin();
      GridPoint oldMax = viewport.getViewportMax();
      GridPoint newMin = viewport.getViewportMin()+delta;
      GridPoint newMax = viewport.getViewportMax()+delta;

      if (delta.x() != 0 || delta.y() != 0) // make sure we moved - otherwise, don't do anything
      {
        // check to see if it's a huge jump --> in which case, update all cells
        SizeType<2> dimSize = viewport.getViewportSize();
        if ( (static_cast<unsigned int>(abs(delta.x())) > dimSize[0]) ||
             (static_cast<unsigned int>(abs(delta.y())) > dimSize[1]) )
        {
          //when jumping a huge distance, the viewport may have old data that won't be overwritten
          for (MemoryIndex mi(0); mi < viewport.getNumCells(); ++mi)
          {
            viewport[mi].clear();
          }

          viewport.dragViewportCenter(newCenter);
          toFixedViewportWithBounds(viewport, fillCell);
        }
        else
        {
          Cell dummyCell;
          scrollViewportCenter(viewport,newCenter,dummyCell);
          //points along top or bottom of map
          GridPoint gridStart;
          GridPoint gridEnd;
          if(delta.x() > 0)
          {
            gridStart.x() = oldMax.x();
            gridEnd.x() = newMax.x();
          }
          else {
            gridStart.x() = newMin.x();
            gridEnd.x() = oldMin.x();
          }
          if(delta.y() > 0)
          {
            gridStart.y() = oldMax.y() ;
            gridEnd.y() = newMax.y();
          }
          else {
            gridStart.y() = newMin.y();
            gridEnd.y() = oldMin.y();
          }

          unsigned int viewportYSize = newMax.y() - newMin.y() + 1;
          unsigned int viewportXSize = newMax.x() - newMin.x() + 1;

          GridPoint gridPoint = gridStart;
          //points along top or bottom of map
          std::vector<IndexedCell> overlapCells;

          for (gridPoint.y() = gridStart.y();gridPoint.y() <= gridEnd.y(); ++gridPoint.y())
          {
            overlapCells = findXOverlap(gridPoint.y(), newMin.x(), viewportXSize);
            for (unsigned int ii = 0; ii < overlapCells.size(); ++ii)
            {
              GridPoint thisPoint(overlapCells[ii].second,gridPoint.y());
              fillCell(viewport[thisPoint], (*overlapCells[ii].first), thisPoint);
            }
          }

          //points along left or right side of map
          gridPoint.y() = gridStart.y();
          for (gridPoint.x() = gridStart.x();gridPoint.x() <= gridEnd.x(); ++gridPoint.x())
          {
            overlapCells = findYOverlap(gridPoint.x(), newMin.y(), viewportYSize);
            for (unsigned int ii = 0; ii < overlapCells.size(); ++ii)
            {
              GridPoint thisPoint(gridPoint.x(),overlapCells[ii].second);
              fillCell(viewport[thisPoint], (*overlapCells[ii].first), thisPoint);
            }
          }
        }
      }
    }


    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Size of dual interval grid
    ///
    /// @return Size in bytes
    ///////////////////////////////////////////////////////////////////////////////
    double size() const
    {
      double totalMemForLaneBytes = 0;
      totalMemForLaneBytes = m_xGrid.size();
      totalMemForLaneBytes += m_yGrid.size();

      return totalMemForLaneBytes;
    }

/*      for(IntervalGrid<IntervalCell, 0, GridType>::IntervalGridType::const_iterator iSetIter = m_xGrid.begin();
           iSetIter != m_xGrid.end(); ++iSetIter)
      {
        for(IntervalGrid<IntervalCell, 0, GridType>::IntervalSet::const_iterator intervalIter = (*iSetIter)->begin();
             intervalIter != (*iSetIter)->end(); ++intervalIter)
        {
          totalMemForLaneBytes += sizeof((*intervalIter->viewportOffset));
          totalMemForLaneBytes += sizeof(IntervalCell) * ((*intervalIter)->cells.count());
        }
      }

      for(IntervalGrid<IntervalCell, 1, GridType>::IntervalGridType::const_iterator iSetIter = m_yGrid.begin();
           iSetIter != m_yGrid.end(); ++iSetIter)
      {
        for(IntervalGrid<IntervalCell, 1, GridType>::IntervalSet::const_iterator intervalIter = (*iSetIter)->begin();
             intervalIter != (*iSetIter)->end(); ++intervalIter)
        {
          totalMemForLaneBytes += sizeof((*intervalIter->viewportOffset));
          totalMemForLaneBytes += sizeof(IntervalCell) * ((*intervalIter)->cells.count());
        }
      }

      return totalMemForLaneBytes;
*/

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Serialize
    ///////////////////////////////////////////////////////////////////////////////
    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
      switch(version)
      {
        case 0:
        {
          ar & m_xGrid & m_yGrid;
          break;
        }
        default:
        {
          std::cerr << "Unknown DualIntervalGrid version\n";
          break;
        }
      }
    }

  GridPoint getMapMin() const {
    return m_xGrid.getGridMin();
  }

  GridPoint getMapMax() const {
    return m_xGrid.getGridMax();
  }

  private:
    IntervalGrid<IntervalCell, 0, GridType> m_xGrid;
    IntervalGrid<IntervalCell, 1, GridType> m_yGrid;
};

  }
}

// Boost Versioning for IntervalGrid Class
namespace boost {
namespace serialization {
    template<typename IntervalCell, unsigned int Dim>
    struct version< nrec::spatial::IntervalGrid<IntervalCell,Dim> >
    {
      typedef mpl::int_<1> type; //<-- Increment version here
      typedef mpl::integral_c_tag tag;
        BOOST_STATIC_CONSTANT(unsigned int, value = version::type::value);
    };
  }
}
#endif


