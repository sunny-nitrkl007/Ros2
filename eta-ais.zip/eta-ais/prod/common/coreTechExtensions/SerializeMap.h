///////////////////////////////////////////////////////////////////////////////
/// @file      SerializeMap.h
/// @author    Michael Bode (bode@rec.ri.cmu.edu)
/// @date      April 4, 2013
/// @brief     Serialization routines for nrec::spatial
///
/// @attention Copyright (C) 2013
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef nrec_gridMap_serialize_h
#define nrec_gridMap_serialize_h

#include <boost/serialization/split_free.hpp>
#include <boost/serialization/version.hpp>

#include "spatial/gridMap/GeoGridMaps.h"
#include "spatial/gridMap/StandardGridMaps.h"

namespace boost
{
  namespace serialization
  {


    template<class Archive, class MapType2D>
    void save2DMap(Archive &ar, const MapType2D& map2D)
    {
      ar << map2D.getCellSize().x() << map2D.getCellSize().y();
      ar << map2D.getViewportSize().x() << map2D.getViewportSize().y();
      ar << map2D.getViewportMin().x() << map2D.getViewportMin().y();
      for(typename MapType2D::MemoryIndex mi(0); mi < map2D.getNumCells(); ++mi)
      {
        ar << map2D[mi];
      }
    }

    template<class Archive, class MapType2D>
    void load2DMap(Archive &ar, MapType2D& map2D)
    {
      typename MapType2D::WorldPoint cellSize;
      nrec::spatial::SizeType<2> viewportSize;
      typename MapType2D::GridPoint gridMin;
      ar >> cellSize.x() >> cellSize.y();
      ar >> viewportSize.x() >> viewportSize.y();
      ar >> gridMin.x() >> gridMin.y();
      map2D.setCellSize(cellSize);
      map2D.resize(viewportSize);
      map2D.dragViewportMin(gridMin);
      for(typename MapType2D::MemoryIndex mi(0); mi < map2D.getNumCells(); ++mi)
      {
        ar >> map2D[mi];
      }
    }


    template<class Archive, class Cell>
    void save(Archive &ar, const nrec::spatial::GeoMap2D<Cell>& geoMap2D, unsigned int version)
    {
      save2DMap(ar, geoMap2D);
    }
    template<class Archive, class Cell>
    void load(Archive &ar, nrec::spatial::GeoMap2D<Cell>& geoMap2D, unsigned int version)
    {
      load2DMap(ar, geoMap2D);
    }

    template<class Archive, class Cell>
    void save(Archive &ar, const nrec::spatial::StdMap2D<Cell>& stdMap2D, unsigned int version)
    {
      save2DMap(ar, stdMap2D);
    }
    template<class Archive, class Cell>
    void load(Archive &ar, nrec::spatial::StdMap2D<Cell>& stdMap2D, unsigned int version)
    {
      load2DMap(ar, stdMap2D);
    }



    template<class Archive, class MapType3D>
    void save3DMap(Archive &ar, const MapType3D& map3D)
    {
      ar << map3D.getCellSize().x() << map3D.getCellSize().y() << map3D.getCellSize().z();
      ar << map3D.getViewportSize().x() << map3D.getViewportSize().y() << map3D.getViewportSize().z();
      ar << map3D.getViewportMin().x() << map3D.getViewportMin().y() << map3D.getViewportMin().z();
      for(typename MapType3D::MemoryIndex mi(0); mi < map3D.getNumCells(); ++mi)
      {
        ar << map3D[mi];
      }
    }

    template<class Archive, class MapType3D>
    void load3DMap(Archive &ar, MapType3D& map3D)
    {
      typename MapType3D::WorldPoint cellSize;
      nrec::spatial::SizeType<3> viewportSize;
      typename MapType3D::GridPoint gridMin;
      ar >> cellSize.x() >> cellSize.y() >> cellSize.z();
      ar >> viewportSize.x() >> viewportSize.y() >> viewportSize.z();
      ar >> gridMin.x() >> gridMin.y() >> gridMin.z();
      map3D.setCellSize(cellSize);
      map3D.resize(viewportSize);
      map3D.dragViewportMin(gridMin);
      for(typename MapType3D::MemoryIndex mi(0); mi < map3D.getNumCells(); ++mi)
      {
        ar >> map3D[mi];
      }
    }


    template<class Archive, class Cell>
    void save(Archive &ar, const nrec::spatial::GeoMap3D<Cell>& geoMap3D, unsigned int version)
    {
      save3DMap(ar, geoMap3D);
    }
    template<class Archive, class Cell>
    void load(Archive &ar, nrec::spatial::GeoMap3D<Cell>& geoMap3D, unsigned int version)
    {
      load3DMap(ar, geoMap3D);
    }

    template<class Archive, class Cell>
    void save(Archive &ar, const nrec::spatial::StdMap3D<Cell>& stdMap3D, unsigned int version)
    {
      save3DMap(ar, stdMap3D);
    }
    template<class Archive, class Cell>
    void load(Archive &ar, nrec::spatial::StdMap3D<Cell>& stdMap3D, unsigned int version)
    {
      load3DMap(ar, stdMap3D);
    }


  }
}

#endif
