///////////////////////////////////////////////////////////////////////////////
/// @file      GridMapToPPM.h
/// @author    bode
/// @date      5/22/2013
/// @brief
///
/// @attention Copyright (C)
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////


#ifndef  GridMapToPPM_h
#define  GridMapToPPM_h


#include <fstream>
#include "spatial/gridMap/GeoGridMaps.h"


namespace nrec
{
  namespace spatial
  {

template<typename Viewport, typename Colorizer>
bool gridMapToPPM(const Viewport& viewport, const std::string& fileName, Colorizer coloringFunction) {
  // open file - return false if error occurs
  std::ofstream outFile(fileName.c_str());
  if(outFile.fail()) {
    std::cerr << "Unable to open " << fileName << "\n";
    return false;
	}
	// write out the start of the ppm header
  SizeType<Viewport::NDim> dimSizes = viewport.getViewportSize();
	outFile << "P6\n" << dimSizes.x() << " " << dimSizes.y() << "\n";
	// write out a comment that has the lower minimim map grid coordinat and cell resolution information
  typename Viewport::GridPoint gridMin = viewport.getViewportMin();
  typename Viewport::WorldPoint cellSize = viewport.getCellSize();
	outFile << "# Viewport Min Corner: " << gridMin.x() << " " << gridMin.y() <<  "\n";
	// write out a comment that has the cell resolution
	outFile << "# Cell Size: " << cellSize.x() << " " << cellSize.y() << "\n";
	// write out the end of the ppm header
	outFile << "255\n";
	// for each cell, call the coloring function
	unsigned char r=0,g=0,b=0;
	typename Viewport::ViewportPoint viewportMax(dimSizes.x()-1, dimSizes.y()-1);
	typename Viewport::ViewportPoint thisPoint;

	for (thisPoint.y() = viewportMax.y(); thisPoint.y() >= 0; --thisPoint.y()) {
    for (thisPoint.x() = 0; thisPoint.x() <= viewportMax.x(); ++thisPoint.x()){

	    coloringFunction(viewport[thisPoint], r, g, b);
	    outFile.write(reinterpret_cast<char*>(&r),1);
	    outFile.write(reinterpret_cast<char*>(&g),1);
	    outFile.write(reinterpret_cast<char*>(&b),1);
	  }
	}

	outFile.close();
	return true;
}

  }
}

#endif

