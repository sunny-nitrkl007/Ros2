///////////////////////////////////////////////////////////////////////////////
/// @file      RayTraceBoundsCheckAll.h
/// @author    bode
/// @date      01/27/2011
/// @brief     Raytracing that checks to see if a cell is in the viewport
///            before calling the tracing functions
///
/// Note: this version of ray trace will always trace the whole ray, at every
///       cell, the bounds check will be performed prior to accessing the cell.
///       cells that are not in the viewport are skipped, but the trace continues
///
/// @attention Copyright (C) 2011
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////

#ifndef RayTraceBoundsCheckAll_h
#define RayTraceBoundsCheckAll_h   //!< Include Guard

#include "../spatial/gridMap/viewport/Viewport.h"
#include "../spatial/gridMap/rayTracing/RayTrace.h"
namespace nrec
{
  namespace spatial
  {

//#include "common/spatial/rayTracing/RayTrace.h"

///////////////////////////////////////////////////////////////////////////////
/// @brief Raytracing that terminates when the ray leaves the viewport
/// @return true if the ray tracing terminated early, false otherwise
/// @param viewport the viewport to perform the tracing on
/// @param start the start location of the ray
/// @param end the end location of the ray
/// @param startFun the function to be called on the cell where the ray originates
/// @param midFun the function to be called on all cells in the beam interior
/// @param endFun the function to be called on the cell where the ray terminates
///////////////////////////////////////////////////////////////////////////////
template<typename Cell, typename Grid, typename ScrollSettings,
  typename IndexingSettings, typename StoragePolicy,
  typename StartFunction, typename MiddleFunction, typename EndFunction,
  bool FastCornerCheck>
bool rayTraceBoundsCheckAllBase(Viewport<Cell, Grid, ScrollSettings, IndexingSettings,
                  StoragePolicy>& viewport,
                  const typename Grid::WorldPoint& start,
                  const typename Grid::WorldPoint& end, StartFunction& startFun,
                  MiddleFunction& midFun, EndFunction& endFun) {

  typedef Viewport<Cell, Grid, Scrolling,
    IndexingSettings, StoragePolicy> View;  //!< Viewport Type
  typedef typename View::WorldPoint WorldPoint; //!< World Point Type
  typedef typename View::GridPoint GridPoint; //!< Grid Point Type
  typedef typename View::ViewportPoint ViewportPoint; //!< Viewport Point Type

  WorldPoint vect = end - start;
  GridPoint gridStart = viewport.worldToGrid(start);
  WorldPoint cellSize = viewport.getCellSize();
  GridPoint step;
  WorldPoint tDelta, tMax;

  RayTraceInit<View, Grid::NDim>::initialize(start,vect,cellSize,gridStart,step,tDelta,tMax);

  ViewportPoint v = viewport.gridToViewport(gridStart);
  ViewportPoint oldCell = v;
  double t;
  double tOld = 1.0;
  bool status = true;
  RayAdvancer<View, Grid::NDim, FastCornerCheck>::advanceRay(step,tDelta,tMax,v,t);
  if(t > 1.0){
    t = 1.0;
    if(viewport.inViewport(oldCell)) {
      status = startFun(t, viewport[oldCell]);
    }
  } else {
    if(viewport.inViewport(oldCell)) {
      status = startFun(t, viewport[oldCell]);
    }
    while (status) {
      tOld = t;
      oldCell = v;
      RayAdvancer<View, Grid::NDim, FastCornerCheck>::advanceRay(step,tDelta,tMax,v,t);
      if(t < 1.0) {
        if(viewport.inViewport(oldCell)) {
          status = midFun(tOld, t, viewport[oldCell]);
        }
      } else {
        break;
      }
    }
  }
  if(!status) return false;
  if(viewport.inViewport(oldCell)) {
    return endFun(tOld, viewport[oldCell]);
  }
  return true;
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Trace a ray through the viewport
/// @return true if the ray tracing terminated early, false otherwise
/// @param viewport the viewport to perform the tracing on
/// @param start the start location of the ray
/// @param end the end location of the ray
/// @param startFun the function to be called on the cell where the ray originates
/// @param midFun the function to be called on all cells in the beam interior
/// @param endFun the function to be called on the cell where the ray terminates
///
/// @note rayTracing does perform checks to see if the beam start and end
///   points are within the viewport.
/// @note In this version of ray tracing constrains the tracing to movement
///   in one direction at a time.  Therefore, if the ray passes diagonally
///   through the corner of a cell more than two cells are traced.  In the 2D
///   case with a ray crossing both +x and +y boundaries simultaneously, the
///   tracing would pass through the current cell (cx,cy), a 4 connected
///   neighbor i.e. (cx+1,cy) and the diagonal cell (cx+1,cy+1).
///////////////////////////////////////////////////////////////////////////////
template<typename Cell, typename Grid, typename ScrollSettings,
  typename IndexingSettings, typename StoragePolicy,
  typename StartFunction, typename MiddleFunction, typename EndFunction>
bool rayTraceBoundsCheckAll(Viewport<Cell, Grid, ScrollSettings, IndexingSettings,
              StoragePolicy>& viewport,
              const typename Grid::WorldPoint& start,
              const typename Grid::WorldPoint& end, StartFunction& startFun,
              MiddleFunction& midFun, EndFunction& endFun) {
  return rayTraceBoundsCheckAllBase<Cell,Grid,ScrollSettings,IndexingSettings,
    StoragePolicy,StartFunction,MiddleFunction,EndFunction,true>(
      viewport,start,end,startFun,midFun,endFun);
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Trace a ray through the viewport
/// @return true if the ray tracing terminated early, false otherwise
/// @param viewport the viewport to perform the tracing on
/// @param start the start location of the ray
/// @param end the end location of the ray
/// @param startFun the function to be called on the cell where the ray originates
/// @param midFun the function to be called on all cells in the beam interior
/// @param endFun the function to be called on the cell where the ray terminates
///
/// @note rayTracing does perform checks to see if the beam start and end
///   points are within the viewport.
/// @note In this version of ray tracing, if the ray passes diagonally through
///   the corner of a cell, only the two cells that share the corner and
///   contain the ray are traced.  This version of ray tracing is two connected
///   for corner crossings.
///////////////////////////////////////////////////////////////////////////////
template<typename Cell, typename Grid, typename ScrollSettings,
  typename IndexingSettings, typename StoragePolicy,
  typename StartFunction, typename MiddleFunction, typename EndFunction>
bool rayTraceExactCornersBoundsCheckAll(Viewport<Cell, Grid, ScrollSettings, IndexingSettings,
                          StoragePolicy>& viewport,
                          const typename Grid::WorldPoint& start,
                          const typename Grid::WorldPoint& end, StartFunction& startFun,
                          MiddleFunction& midFun, EndFunction& endFun) {
  return rayTraceBoundsCheckAllBase<Cell,Grid,ScrollSettings,IndexingSettings,
    StoragePolicy,StartFunction,MiddleFunction,EndFunction,false>(
      viewport,start,end,startFun,midFun,endFun);
}



  } // namespace spatial
} // namespace nrec

#endif
