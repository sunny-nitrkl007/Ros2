///////////////////////////////////////////////////////////////////////////////
/// @file      serialize.h
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      June 13, 2008
/// @brief     Serialization routines for nrec::geometry
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef nrec_geometry_serialize_h
#define nrec_geometry_serialize_h

#include <boost/serialization/split_free.hpp>
#include <boost/serialization/version.hpp>
#include <boost/serialization/vector.hpp>
#include <boost/serialization/nvp.hpp>

#include "geometry/primitives/Point3D.h"
#include "geometry/primitives/Vector2D.h"
#include "geometry/primitives/Vector3D.h"
#include "geometry/primitives/Angle.h"
#include "geometry/primitives/Segment2D.h"
#include "geometry/primitives/Polygon2D.h"
#include "geometry/primitives/Box2D.h"
#include "geometry/primitives/Line2D.h"
#include "geometry/poses/ISOPose3D.h"
#include "geometry/poses/Pose3D.h"
#include "geometry/poses/Pose2D.h"
#include "geometry/rotations/AxisAngle.h"
#include "geometry/rotations/EulerAngles.h"
#include "geometry/rotations/Quaternion.h"
#include "geometry/rotations/RMatrix2D.h"
#include "geometry/rotations/RMatrix3D.h"
#include "geometry/transforms/HTransform2D.h"
#include "geometry/transforms/HTransform3D.h"
#include "geometry/transforms/QTransform.h"
#include "geometry/interval/Interval.h"
#include "geometry/interval/IntervalSet.h"

namespace boost
{
  namespace serialization
  {
    /**
     * @brief Function to serialize Vector2D
     */
    template<class Archive, class T>
    void serialize(Archive &ar, nrec::geometry::Vector2D<T> &r, unsigned int version)
    {
      ar & boost::serialization::make_nvp("x",r.x());
      ar & boost::serialization::make_nvp("y",r.y());
    }

    /**
     * @brief Function to serialize Vector3D
     */
    template<class Archive, class T>
    void serialize(Archive &ar, nrec::geometry::Vector3D<T> &r, unsigned int version)
    {
      ar & r.x() & r.y() & r.z();
    }

    /**
     * @brief Function to serialize Pose2D
     */
    template<class Archive, class T>
    void serialize(Archive &ar, nrec::geometry::Pose2D<T> &r, unsigned int version)
    {
      ar & boost::serialization::make_nvp("x",r.x());
      ar & boost::serialization::make_nvp("y",r.y());
      ar & boost::serialization::make_nvp("orientation",r.orientation());
    }

    /**
     * @brief Function to serialize ISOPose3D
     */
    template<class Archive, class T>
    void serialize(Archive &ar, nrec::geometry::ISOPose3D<T> &r, unsigned int version)
    {
      ar & r.x() & r.y() & r.z();
      ar & r.rot1() & r.rot2() & r.rot3();
    }

    /**
     * @brief Function to serialize Pose3D
     */
    template<class Archive, class T, int AngleOrder>
    void serialize(Archive &ar, nrec::geometry::Pose3D<T, AngleOrder> &r, unsigned int version)
    {
      ar & r.x() & r.y() & r.z();
      ar & r.rot1() & r.rot2() & r.rot3();
    }

    /**
     * @brief Functions to serialize Angle
     */
    template<class Archive, class T>
    void save(Archive & ar, const nrec::geometry::Angle<T> &r, unsigned int version)
    {
      T val = r.getRadians();
      ar << boost::serialization::make_nvp("Angle_rad",val);
    }
    template<class Archive, class T>
    void load(Archive & ar, nrec::geometry::Angle<T> &r, unsigned int version)
    {
      T angle;
      ar >> boost::serialization::make_nvp("Angle_rad",angle);
      r.setRadians(angle);
    }

    /**
     * @brief Function to serialize Segment2D
     */
    template<class Archive, class T>
    void serialize(Archive &ar, nrec::geometry::Segment2D<T> &s, unsigned int version)
    {
      ar & s.p1() & s.p2();
    }

    /**
     * @brief Functions to serialize AxisAngle
     */
    template<class Archive, class T>
    void save(Archive &ar, const nrec::geometry::AxisAngle<T> &a, unsigned int version)
    {
      ar << a.getAxis() << a.angle();
    }
    template<class Archive, class T>
    void load(Archive &ar, nrec::geometry::AxisAngle<T> &a, unsigned int version)
    {
      nrec::geometry::Vector3D<T> axis;
      ar >> axis;
      a.setAxis(axis);
      ar >> a.angle();
    }

    /**
     * @brief Function to serialize EulerAngles
     */
    template<class Archive, class T, int AngleOrder>
    void serialize(Archive &ar, nrec::geometry::EulerAngles<T, AngleOrder> &a, unsigned int version)
    {
      ar & a.rot1() & a.rot2() & a.rot3();
    }

    /**
     * @brief Function to serialize Quaternion
     */
    template<class Archive, class T>
    void serialize(Archive &ar, nrec::geometry::Quaternion<T> &q, unsigned int version)
    {
      ar & q.w() & q.x() & q.y() & q.z();
    }

    /**
     * @brief Functions to serialize RMatrix2D
     */
    template<class Archive, class T>
    void save(Archive &ar, const nrec::geometry::RMatrix2D<T> &m, unsigned int version)
    {
      nrec::geometry::Vector2D<T> xAxis = m.getXAxis();
      nrec::geometry::Vector2D<T> yAxis = m.getYAxis();
      ar << xAxis;
      ar << yAxis;
    }

    template<class Archive, class T>
    void load(Archive &ar, nrec::geometry::RMatrix2D<T> &m, unsigned int version)
    {
      nrec::geometry::Vector2D<T> xAxis;
      nrec::geometry::Vector2D<T> yAxis;
      ar >> xAxis >> yAxis;
      m.setXAxis(xAxis);
      m.setYAxis(yAxis);
    }

    /**
     * @brief Functions to serialize RMatrix3D
     */
    template<class Archive, class T>
    void save(Archive &ar, const nrec::geometry::RMatrix3D<T> &m, unsigned int version)
    {
      nrec::geometry::Vector3D<T> xAxis = m.getXAxis();
      nrec::geometry::Vector3D<T> yAxis = m.getYAxis();
      nrec::geometry::Vector3D<T> zAxis = m.getZAxis();
      ar << xAxis;
      ar << yAxis;
      ar << zAxis;
    }
    template<class Archive, class T>
    void load(Archive &ar, nrec::geometry::RMatrix3D<T> &m, unsigned int version)
    {
      nrec::geometry::Vector3D<T> xAxis;
      nrec::geometry::Vector3D<T> yAxis;
      nrec::geometry::Vector3D<T> zAxis;
      ar >> xAxis >> yAxis >> zAxis;
      m.setXAxis(xAxis);
      m.setYAxis(yAxis);
      m.setZAxis(zAxis);
    }

    /**
     * Functions to serialize HTransform2D
     */
    template<class Archive, class T>
    void save(Archive &ar, const nrec::geometry::HTransform2D<T> &t, unsigned int version)
    {
      ar << t.getRotation() << t.getTranslation();
    }
    template<class Archive, class T>
    void load(Archive &ar, nrec::geometry::HTransform2D<T> &t, unsigned int version)
    {
      nrec::geometry::RMatrix2D<T> rot;
      nrec::geometry::Vector2D<T> trans;
      ar >> rot >> trans;
      t.setRotation(rot);
      t.setTranslation(trans);
    }

    /**
     * @brief Functions to serialize HTransform3D
     */
    template<class Archive, class T>
    void save(Archive &ar, const nrec::geometry::HTransform3D<T> &t, unsigned int version)
    {
      ar << t.getRotation() << t.getTranslation();
    }
    template<class Archive, class T>
    void load(Archive &ar, nrec::geometry::HTransform3D<T> &t, unsigned int version)
    {
      nrec::geometry::RMatrix3D<T> rot;
      nrec::geometry::Vector3D<T> trans;
      ar >> rot >> trans;
      t.setRotation(rot);
      t.setTranslation(trans);
    }

    /**
     * @brief Functions to serialize QTransform
     */
    template<class Archive, class T>
    void save(Archive &ar, const nrec::geometry::QTransform<T> &t, unsigned int version)
    {
      ar << t.getRotation() << t.getTranslation();
    }
    template<class Archive, class T>
    void load(Archive &ar, nrec::geometry::QTransform<T> &t, unsigned int version)
    {
      nrec::geometry::Quaternion<T> rot;
      nrec::geometry::Vector3D<T> trans;
      ar >> rot >> trans;
      t.setRotation(rot);
      t.setTranslation(trans);
    }


    /**
     * @brief Functions to serialize Box2D
     */
    template<class Archive, class T>
    void save(Archive &ar, const nrec::geometry::Box2D<T> &box, unsigned int version)
    {
      nrec::geometry::Vector2D<T> cMin = box.getMinCorner();
      nrec::geometry::Vector2D<T> cMax = box.getMaxCorner();
      ar << cMin << cMax;
    }
    template<class Archive, class T>
    void load(Archive &ar, nrec::geometry::Box2D<T> &box, unsigned int version)
    {
      nrec::geometry::Vector2D<T> cMin,cMax;
      ar >> cMin;
      ar >> cMax;
      box.setDiagonalCorners(cMin,cMax);
    }


    /**
     * @brief Functions to serialize Polygon2D
     */
    template<class Archive, class T>
    void save(Archive &ar, const nrec::geometry::Polygon2D<T> &p, unsigned int version)
    {
      unsigned int pSize = p.size();
      ar << pSize;
      for (unsigned int ii = 0; ii < pSize; ii++)
      {
        ar << p[ii];
      }
    }
    template<class Archive, class T>
    void load(Archive &ar, nrec::geometry::Polygon2D<T> &p, unsigned int version)
    {
      unsigned int pSize;
      ar >> pSize;
      p.resize(pSize);
      for (unsigned int ii = 0; ii < pSize; ii++)
      {
        ar >> p[ii];
      }
    }

    /**
     * @brief Functions to serialize Interval
     * */
    template<class Archive, class T>
    void save(Archive &ar, const nrec::geometry::Interval<T> &i, unsigned int version)
    {
      T lowVal(i.low());
      T highVal(i.high());
      ar << lowVal;
      ar << highVal;
    }
    template<class Archive, class T>
    void load(Archive &ar, nrec::geometry::Interval<T> &i, unsigned int version)
    {
      T lowVal;
      T highVal;
      ar >> lowVal;
      ar >> highVal;
      i.low(lowVal);
      i.high(highVal);
    }

    /**
     * @brief Functions to serialize IntervalSet
     * */
    template<class Archive, class T>
    void save(Archive &ar, const nrec::geometry::IntervalSet<T> &i, unsigned int version)
    {
      unsigned int iSize = i.intervalCount();
      ar << iSize;
      for (typename nrec::geometry::IntervalSet<T>::IntervalSetCIterator citer = i.begin(); citer != i.end(); ++citer)
      {
        ar << *citer;
      }
    }
    template<class Archive, class T>
    void load(Archive &ar, nrec::geometry::IntervalSet<T> &i, unsigned int version)
    {
      i.clear();
      unsigned int iSize;
      ar >> iSize;
      for (unsigned int ii = 0; ii < iSize; ++ii)
      {
        typename nrec::geometry::Interval<T> tmp;
        ar >> tmp;
        i.unionWith(tmp);
      }
    }

    /**
     * @brief Functions to serialize Line2D
     */
    template<class Archive, class T>
    void save(Archive & ar, const nrec::geometry::Line2D<T> &r, unsigned int version)
    {
      nrec::geometry::Vector2D<T> referencePoint = r.getReferencePoint();
      nrec::geometry::Vector2D<T> directionVector = r.getDirectionVector();

      ar << referencePoint;
      ar << directionVector;
    }
    template<class Archive, class T>
    void load(Archive & ar, nrec::geometry::Line2D<T> &r, unsigned int version)
    {
      nrec::geometry::Vector2D<T> referencePoint, directionVector;
      ar >> referencePoint;
      ar >> directionVector;
      r.setReferencePoint(referencePoint);
      r.setDirectionVector(directionVector);
    }
  } // namespace serialization
} // namespace boost

BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::Angle_f);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::Angle_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::Angle_ld);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::AxisAngle_f);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::AxisAngle_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::AxisAngle_ld);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::RMatrix2D_f);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::RMatrix2D_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::RMatrix2D_ld);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::RMatrix3D_f);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::RMatrix3D_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::RMatrix3D_ld);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::HTransform2D_f);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::HTransform2D_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::HTransform2D_ld);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::HTransform3D_f);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::HTransform3D_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::HTransform3D_ld);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::QTransform_f);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::QTransform_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::QTransform_ld);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::Box2D_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::Polygon2D_f);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::Polygon2D_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::Polygon2D_ld);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::Interval_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::IntervalSet_c);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::IntervalSet_s);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::IntervalSet_i);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::IntervalSet_f);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::IntervalSet_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::IntervalSet_ld);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::Line2D_f);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::Line2D_d);
BOOST_SERIALIZATION_SPLIT_FREE(nrec::geometry::Line2D_ld);

#endif
