
#include "geometry/primitives/Polygon2D.h"
namespace nrec
{
  namespace geometry
  {
    
/*!
 * Returns true if the polygon has a clockwise winding
 * \param poly the polygon to check the winding direction of
 * \return true if the polygon has a clockwise winding, false otherwise 
 * \relatesalso Polygon2D
 */
template <typename T>
bool clockwiseWinding(const Polygon2D<T>& poly) {
  return signedArea(poly) < 0.0;
}

/*!
 * Returns true if the polygon has a counter clockwise winding
 * \param poly the polygon to check the winding direction of
 * \return true if the polygon has a counter clockwise winding, false otherwise 
 * \relatesalso Polygon2D
 */
template <typename T>
bool counterClockwiseWinding(const Polygon2D<T>& poly) {
  return signedArea(poly) > 0.0;
}
  }
}
