/******************************************************************************
**
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%
*** %% COPYRIGHT (C) 2001-2010 CATERPILLAR INC. ALL RIGHTS RESERVED.
*** %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
**
*** FILE:
***     autonomy_diagnostics_config.c
***
*** DESCRIPTION:
***     Autonomy diagnostic configurations.
***
******************************************************************************/

/******************************************************************************
***
***    External function prototypes, data, & symbols
***    -- #Include's --
***
******************************************************************************/

#ifndef   AUTONOMY_DIAGNOSTICS_CONFIG_H_
#include "autonomy_diagnostics_config.h"
#endif

/******************************************************************************
***
***    Constants defined for this file
***    -- #Define's --
***
******************************************************************************/

/******************************************************************************
***
***    Data types defined for this file
***    -- Struct's, Typedef's, Enum's --
***
******************************************************************************/

/******************************************************************************
***
***    File scope functions defined for this file
***    -- Function Prototypes --
***
******************************************************************************/

/******************************************************************************
***
***    File scope symbols defined for this file
***    -- Symbols --
***
******************************************************************************/

/******************************************************************************
***
***    Global data symbols defined in this file
***    -- Global Symbols --
***
******************************************************************************/
/* Diag Handle and Config for Product ID not Received */
/* maximum allowed description ->             "xxxxxxxxxxxxxxxxxxxx" (20 chars) */
const char     prod_id_not_recd_diag_text[] = "Product ID not Recd";

/*
** Product ID not Received (Level I) Diagnostic Configuration (Event System)
**     Event System configuration for one specific diagnostic.
*/
static scl_obd_es_test_config_t const app_diagcfg_prod_id_not_recd_lv2_es =
{
                          /*Fault Class                         [Diagnostic]*/
     SCL_OBD_ES_CLASS_DIAG,
     SCL_OBD_ES_GRP_NONE, /*Readiness Group                            [N/A]*/
                          /*Persistent Id                                   */
     SCL_OBD_PERSISTENT_ID_CDL_DIAG_WCI
     (
       PROD_ID_CID,
       FMIIUA,
       WARN_LEVEL2
     ),
                          /*Persistent Priority                             */
     SCL_CI_ES_WCI_TO_PP(WARN_LEVEL2, SCL_OBD_ES_CLASS_DIAG),
     1,                   /*Security                                  [none]*/
                          /*Flags                                           */
     (
       SCL_OBD_ES_TST_CFG_CONT_MON          | /*Continuous Monitor                */
       SCL_OBD_ES_TST_CFG_PERSISTENT_ACTIVE | /*Use Persistent Data For Initialize*/
       SCL_OBD_ES_TST_CFG_PERSISTENT        | /*Persistently Save Data            */
       SCL_OBD_ES_TST_CFG_AUTO_CLEAR_SHM    | /*Automatically Clear Old Codes     */
       SCL_OBD_ES_TST_CFG_STORE_CONFIRM       /*Show History Data Externally      */
     ),
                          /*Debounce Times (Should Always Be 0)             */
     (oel_second_u32_l20_t)( 0.0*(1UL<<20) ), /*Active   Delay Time [  0.0s]*/
     (oel_second_u32_l20_t)( 0.0*(1UL<<20) ), /*Confirm  Delay Time [  0.0s]*/
     (oel_second_u32_l20_t)( 0.0*(1UL<<20) ), /*Inactive Delay Time [  0.0s]*/
     0x00000000,          /*Snapshot Id                                [N/A]*/
                          /*Freeze Frame Priority                      [N/A]*/
     SCL_OBD_ES_FF_PRIORITY_NORMAL
};

/*
** Product ID not Received  (Level II) Diagnostic Configuration (Data Link)
**     Data Link configuration for one specific diagnostic.
*/
static scl_eddt_fault_config_t  const app_diagcfg_prod_id_not_recd_lv2_dl =
{
                          /*Flex Text Description                           */
     prod_id_not_recd_diag_text,
                          /*Event Type                  [Maintenance & Data]*/
     SCL_EDDT_EVENT_TYPE_MAINT_AND_OP,
     FALSE,               /*Histogram Available                         [no]*/
                          /*CID                                             */
     PROD_ID_CID,
                          /*Warning Category Indicator                      */
     WARN_LEVEL2,
     FMIIUA,              /*Failure Mode Indicator                          */
     0,                   /*PID Associated With Event                  [N/A]*/
     FALSE,               /*Enable DSI On PID Associated With Event?   [N/A]*/
};

/*Product ID not Received (Level I) Diagnostic Configuration
**     This structure is used to provide the diagnostic configuration to
**     initialize one specific diagnostic.
*/
scl_ci_es_fault_cfg_eddt_t      app_diagcfg_prod_id_not_recd_lv2 =
SCL_CI_ES_FAULT_CFG_EDDT
(
                          /*Event System Configuration                      */
     &app_diagcfg_prod_id_not_recd_lv2_es,
                          /*Data Link Configuration                         */
     &app_diagcfg_prod_id_not_recd_lv2_dl
);


/* Diag Handle and Config for Robot File Missing */
/* maximum allowed description ->             "xxxxxxxxxxxxxxxxxxxx" (20 chars) */
const char     robot_file_missing_diag_text[] = "Robot File Missing";

/*
** Robot File Missing (Level I) Diagnostic Configuration (Event System)
**     Event System configuration for one specific diagnostic.
*/
static scl_obd_es_test_config_t const app_diagcfg_robot_file_missing_lv2_es =
{
                          /*Fault Class                         [Diagnostic]*/
     SCL_OBD_ES_CLASS_DIAG,
     SCL_OBD_ES_GRP_NONE, /*Readiness Group                            [N/A]*/
                          /*Persistent Id                                   */
     SCL_OBD_PERSISTENT_ID_CDL_DIAG_WCI
     (
       PROD_ID_CID,
       FMIEII,
       WARN_LEVEL2
     ),
                          /*Persistent Priority                             */
     SCL_CI_ES_WCI_TO_PP(WARN_LEVEL2, SCL_OBD_ES_CLASS_DIAG),
     1,                   /*Security                                  [none]*/
                          /*Flags                                           */
     (
       SCL_OBD_ES_TST_CFG_CONT_MON          | /*Continuous Monitor                */
       SCL_OBD_ES_TST_CFG_PERSISTENT_ACTIVE | /*Use Persistent Data For Initialize*/
       SCL_OBD_ES_TST_CFG_PERSISTENT        | /*Persistently Save Data            */
       SCL_OBD_ES_TST_CFG_AUTO_CLEAR_SHM    | /*Automatically Clear Old Codes     */
       SCL_OBD_ES_TST_CFG_STORE_CONFIRM       /*Show History Data Externally      */
     ),
                          /*Debounce Times (Should Always Be 0)             */
     (oel_second_u32_l20_t)( 0.0*(1UL<<20) ), /*Active   Delay Time [  0.0s]*/
     (oel_second_u32_l20_t)( 0.0*(1UL<<20) ), /*Confirm  Delay Time [  0.0s]*/
     (oel_second_u32_l20_t)( 0.0*(1UL<<20) ), /*Inactive Delay Time [  0.0s]*/
     0x00000000,          /*Snapshot Id                                [N/A]*/
                          /*Freeze Frame Priority                      [N/A]*/
     SCL_OBD_ES_FF_PRIORITY_NORMAL
};

/*
** Robot File Missing  (Level II) Diagnostic Configuration (Data Link)
**     Data Link configuration for one specific diagnostic.
*/
static scl_eddt_fault_config_t  const app_diagcfg_robot_file_missing_lv2_dl =
{
                          /*Flex Text Description                           */
     robot_file_missing_diag_text,
                          /*Event Type                  [Maintenance & Data]*/
     SCL_EDDT_EVENT_TYPE_MAINT_AND_OP,
     FALSE,               /*Histogram Available                         [no]*/
                          /*CID                                             */
     PROD_ID_CID,
                          /*Warning Category Indicator                      */
     WARN_LEVEL2,
     FMIEII,              /*Failure Mode Indicator                          */
     0,                   /*PID Associated With Event                  [N/A]*/
     FALSE,               /*Enable DSI On PID Associated With Event?   [N/A]*/
};

/*Robot File Missing (Level I) Diagnostic Configuration
**     This structure is used to provide the diagnostic configuration to
**     initialize one specific diagnostic.
*/
scl_ci_es_fault_cfg_eddt_t      app_diagcfg_robot_file_missing_lv2 =
SCL_CI_ES_FAULT_CFG_EDDT
(
                          /*Event System Configuration                      */
     &app_diagcfg_robot_file_missing_lv2_es,
                          /*Data Link Configuration                         */
     &app_diagcfg_robot_file_missing_lv2_dl
);
