/******************************************************************************
**
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*** %%
*** %% COPYRIGHT (C) 2010-2010 CATERPILLAR INC. ALL RIGHTS RESERVED.
*** %%
*** %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
**
*** FILE:
***     autonomy_diagnostics_config.h
***
*** DESCRIPTION:
***     This is the definition include file for the module.  All of the 
***     contents in this file are intended for other tasks/modules to use.
***
***     IMPORTANT NOTE:  All global variables should be considered read-only
***                      by any external module that accesses them.
***                      It is forbidden for any routines besides those
***                      local to this module to alter these variables.
***
******************************************************************************/

#ifndef AUTONOMY_DIAGNOSTICS_CONFIG_H_
#define AUTONOMY_DIAGNOSTICS_CONFIG_H_

/*****************************************************************************
***
***    External function prototypes, data, & symbols
***    -- nested #Include's --
***
*****************************************************************************/

#ifndef   STD_TYPES_H_
#include <std_types.h>
#endif

#ifndef   SCL_CI_ES_H
#include <scl_ci_es.h>
#endif

#ifndef   CATDLLIB_FID_DEF_H_
#include <catdllib_fid_def.h>
#endif

#ifndef   AUTONOMY_DEV_IDS_H_
#include "autonomy_dev_ids.h"  /* for development ids */
#endif

/*****************************************************************************
***
***    Constants defined in this file
***    -- #Define's --
***
*****************************************************************************/

#define APP_AUTONOMY_DIAG_SCL_OBD_MAX_FAULTS  2
#define PROD_ID_CID                    967
/*****************************************************************************
***
***    Data types defined in this file
***    -- Struct's, Typedef's, Enum's --
***
*****************************************************************************/
extern scl_ci_es_fault_cfg_eddt_t    app_diagcfg_prod_id_not_recd_lv2;
extern scl_ci_es_fault_cfg_eddt_t    app_diagcfg_robot_file_missing_lv2;
/*****************************************************************************
***
***    Functions prototyped in this file
***    -- Function Prototypes --
***
*****************************************************************************/

/*****************************************************************************
***
***    Data declared in this file
***    -- Global Symbols --
***
*****************************************************************************/

#endif /* AUTONOMY_DIAGNOSTICS_CONFIG_H_ */
