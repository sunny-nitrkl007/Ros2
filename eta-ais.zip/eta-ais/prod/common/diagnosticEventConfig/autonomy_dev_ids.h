/*******************************************************************************
** @attention COPYRIGHT (C) 2010-2010 CATERPILLAR INC. ALL RIGHTS RESERVED.
**
** @file    autonomy_dev_ids.h
**
** @brief   This is the header file for development IDs.
*******************************************************************************/
#ifndef AUTONOMY_DEV_IDS_H_
#define AUTONOMY_DEV_IDS_H_

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/

// Development CIDs (for autonomy, start with 11001 so we stay away from MCM dev CIDs)
#define DEV_CID_UNUSED_11001                   11001
#define DEV_CID_UNUSED_11002                   11002
#define DEV_CID_UNUSED_11003                   11003
#define DEV_CID_UNUSED_11004                   11004
#define DEV_CID_UNUSED_11005                   11005

#define DEV_HIGH_FRONT_IMU_TEMP_EID             1974
#define DEV_LOW_FRONT_IMU_TEMP_EID              1975
#define DEV_EID_BASE_MACHINE_SPEED_ERROR        1976 //Delete after use b/c this EID is typically used by MCM
#define DEV_EID_UNUSED_9950                     9950
#define DEV_EID_UNUSED_9951                     9951
#define DEV_EID_UNUSED_9952                     9952
#define DEV_EID_UNUSED_9953                     9953
#define DEV_EID_UNUSED_9954                     9954
#define DEV_EID_UNUSED_9955                     9955
#define DEV_EID_UNUSED_9958                     9958
#define DEV_EID_UNUSED_9959                     9959
#define DEV_EID_UNUSED_9960                     9960
#define DEV_EID_UNUSED_9961                     9961
#define DEV_EID_UNUSED_9962                     9962
#define DEV_EID_UNUSED_9963                     9963
#define DEV_EID_VEH_NOT_OBEYING_COMMAND         9964
#define DEV_EID_UNUSED_9965                     9965
#define DEV_EID_UNUSED_9966                     9966
#define DEV_EID_PROGRESS_MONITOR_STOP           9967

#define DEV_EID_UNUSED_10110                   10110
#define DEV_EID_UNUSED_10111                   10111
#define DEV_EID_RESTART_REQUIRED               10112
#define DEV_EID_UNUSED_10113                   10113
#define DEV_EID_UNUSED_10114                   10114

#endif /* AUTONOMY_DEV_IDS_H_ */
