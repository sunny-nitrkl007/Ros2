///////////////////////////////////////////////////////////////////////////////
/// @file      MachinePowerOff
/// @author    krishvm
/// @date      7/30/2015
/// @brief     Autonomy Condition for MachinePowerOff
///                                                                            
/// @attention Copyright (C) 2012                                              
/// @attention National Robotics Engineering Center                            
/// @attention Carnegie Mellon University                                      
/// @attention All rights reserved                                             
///////////////////////////////////////////////////////////////////////////////
#ifndef MachinePowerOff_h
#define MachinePowerOff_h

#include <string>
#include "autonomyConditions/AutonomyCondition.h"

class MachinePowerOff : public AutonomyCondition
{
public:

  static std::string getConditionTypeString() {return "MachinePowerOff";}
  static const unsigned int activationDebounce_ms = 0;
  static const unsigned int deactivationDebounce_ms = 0;
  static const unsigned int timeToLive_ms = 86400000;

  MachinePowerOff(/*insert any needed arguments for message string*/):
    AutonomyCondition(getConditionTypeString(),
                      "/* insert condition message here*/",
                      activationDebounce_ms,
                      deactivationDebounce_ms,
                      timeToLive_ms)
  {}
};

#endif
