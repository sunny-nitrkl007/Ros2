/**
 * @file      ImageLoader.h 
 * @author    Joseph Manojlovich (jmanoj@rec.ri.cmu.edu)
 * @date      01/21/2009
 * @brief     Classes that load georectified images from disk
 *  
 * @attention Copyright (c) 2009
 * @attention National Robotics Engineering Center 
 * @attention Carnegie Mellon University 
 * @attention Carnegie Mellon Proprietary 
 * @attention All rights reserved 
 */

#ifndef _ImageLoader_h_
#define _ImageLoader_h_

#include <string>
#include <gdal/gdal_priv.h>
#include <gdal/gdal.h>
#include "ais/log/Logger.h"
#include "ImageStore.h"

namespace imaging
{
  class GeoImageLoader
  {
  public:
    virtual bool loadImage(std::string filename, GeoImageStore& store, std::string& errorMessage) = 0;
    virtual bool isImageLoaded() = 0;
    unsigned int nXSize_, nYSize_;
    unsigned int pixelsize;
    unsigned int nLineSpace;
    unsigned int layerCount;
    
  protected:
    bool fileLoadReady_;
    std::string fileToLoad_; //< These variables store flags to delay the delete and load.
    
  private:
    
  };
  
  class GDALImageLoader : public GeoImageLoader
  {
  public:
    GDALImageLoader();
    virtual bool loadImage(std::string filename, GeoImageStore& store, std::string& errorMessage);
    virtual bool isImageLoaded();
    double getGeoTransform(int which);
    ~GDALImageLoader();
    
  protected:
    GDALDataset *poDataset_;
    GDALRasterBand *poBand_;
    GDALDriver *poDriver_;
    
    void printImageDataset();
    void printRasterBand();
    
  private:
    
  };
}

#endif

