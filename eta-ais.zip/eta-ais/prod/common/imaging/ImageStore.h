/**
 * @file      ImageStore.h 
 * @author    Joseph Manojlovich (jmanoj@rec.ri.cmu.edu)
 * @date      01/21/2009
 * @brief     Class that displays georectified images and cost 
 *            maps
 *  
 * @attention Copyright (c) 2009
 * @attention National Robotics Engineering Center 
 * @attention Carnegie Mellon University 
 * @attention Carnegie Mellon Proprietary 
 * @attention All rights reserved 
 */

#ifndef _ImageStore_h_
#define _ImageStore_h_

#include "geometry/primitives/Point3D.h"
#include <vector>
#include <GL/gl.h>
#include <GL/glut.h>
#include <gdal/gdal_priv.h>
#include <gdal/gdal.h>
#include "ais/log/Logger.h"

namespace imaging
{
  /*
   * @brief An imageBlock stores a chunk of image data starting at the
   * pixel (startx,starty) and extending for sizex and sizey pixels in
   * those directions. 0,0 is the top left corner.  data is an array
   * of unsigned chars containing the pixel values.
   */
  struct ImageBlock
  {
    /**
       Starting x location in GL coordinates
     */
    int startx;

    /**
       Starting y location in GL coordinates
    */
    int starty;

    /**
       Width of texture in GL coordinates
    */
    int sizex;

    /**
       Height of texture in GL coordinates
    */
    int sizey;

    /**
       Texture data itself
    */
    unsigned char *data;

    /**
       GL texture reference number, used to render the texture, and
       later deallocate it
    */
    GLuint texturenum;
  };

  /**
   * @brief Abstract base class for storage and display of raster 
   *        data
   */
  class GeoImageStore
  {
  public:
    /**
       Default constructor
     */
    GeoImageStore();

    /**
       Draw the image store

       @param offset 
       @param alphaValue Transparency, 0 is fully transparent, 1.0 is fully opaque
       @param z Height of texture, in world coordinates
    */
    virtual void display(nrec::geometry::Point3D_d offset, float alphaValue = 1.0, double z = 0.0) = 0;

    /**
       Public accessor for determining if image data has been copied
       to the image store.

       @return True if the image data was copied, false otherwise
    */
    virtual bool isImageLoaded() = 0;

    /**
       Delete all image data
     */
    virtual void deallocateImagery() = 0;
    
    /**
       Get the boundaries of the image, in world coordinates

       @param eastingStart Left most x coordinate of image
       @param eastingEnd Right most x coordinate of image
       @param northingStart Bottom most y coordinate of image
       @param northingEnd Top most y coordinate of image
       @return True if data is valid (image has been loaded), false
       otherwise
     */
    virtual bool getBounds(double& eastingStart, double& eastingEnd, double& northingStart, double& northingEnd) = 0;

    /**
       Get the size of the pixels

       @param pixelSizeX Pixel width
       @param pixelSizeY Pixel height
       @return True if data is valid (image has been loaded), false
       otherwise
     */
    virtual bool getPixelSize(double& pixelSizeX, double& pixelSizeY) = 0;      

    /**
       Convenience method to get the greatest common divisor of two
       integers

       @param i Integer one
       @param j Integer two
       @return Greatest common divisor of parameters
     */
    static unsigned int gcd(unsigned int i, unsigned int j);

    /** 
        Length of the x axis 
    */
    int nXSize_;

    /** 
        Length of the x axis 
    */
    int nYSize_;

    /** 
        Used for working with images that may only have dimensions
        based on powers of two. Without this, a stairstep effect will
        occur for certain image types.
     */
    int nLineSpace;

    /** 
        Geographic transforms

        adfGeoTransform[0] Easting of origin
        adfGeoTransform[1] Pixel width
        adfGeoTransform[2] Rotation, 0 if image is north up
        adfGeoTransform[3] Northing of origin
        adfGeoTransform[4] Rotation, 0 if image is north up
        adfGeoTransform[5] Pixel height
    */
    double adfGeoTransform[6];

    /**
       Number of layers

       Used to determine if grayscale or RGB
    */
    unsigned int layerCount;

    /**
       Image pixel values

       RGB order
     */
    unsigned char *imageData[4];   

    /**
       If true, attempt to load textures from imageData into GL
       textures
     */
    bool fileLoadReady_;   

    /**
       Used by ImageLoader to indicate that image pixels have been
       copied into imageData
     */
    bool imageLoaded_;

    pthread_mutex_t mutex;
    
  protected:
    /**
       Convenience method, used to "round up" argument to next power
       of two

       @param number Number to round up
       @return Next power of two larger than argument
     */
    int nextPowerOfTwo(int number);

    /**
       Convenience method, used to "round down" argument to previous
       power of two

       @param number Number to round down
       @return Previous power of two smaller than argument
    */
    int lowerPowerOfTwo(int number);

    
  private:
      
  };
  
  /**
     Implementation class of GeoImageStore, that uses OpenGL textures
     to store and draw imagery
  */
  class GLTextureImageStore : public GeoImageStore
  {
  public:
    /**
       Draw the image store

       @param offset 
       @param alphaValue
       @param z Height of texture, in world coordinates
    */
    virtual void display(nrec::geometry::Point3D_d offset, float alphaValue = 1.0, double z = 0.0);

    /**
       Delete all image data

       This will delete all of the allocated GL textures
     */    
    virtual void deallocateImagery();

    /**
       Default constructor
    */
    GLTextureImageStore();

    /**
       Default destructor
    */
    ~GLTextureImageStore();

    /**
       Public accessor for determining if image data has been copied
       to the image store.

       @return True if the image data was copied, false otherwise
    */    
    virtual bool isImageLoaded() { return imageLoaded_; }

    /**
       Get the boundaries of the image, in world coordinates

       @param eastingStart Left most x coordinate of image
       @param eastingEnd Right most x coordinate of image
       @param northingStart Bottom most y coordinate of image
       @param northingEnd Top most y coordinate of image
       @return True if data is valid (image has been loaded), false
       otherwise
     */
    virtual bool getBounds(double& eastingStart, double& eastingEnd, double& northingStart, double& northingEnd) 
    {
      eastingStart = adfGeoTransform[0];
      northingStart = adfGeoTransform[3];
      eastingEnd = eastingStart + adfGeoTransform[1] * nXSize_;
      northingEnd = northingStart + adfGeoTransform[5] * nYSize_;
      return true;
    }

    /**
       Get the size of the pixels

       @param pixelSizeX Pixel width
       @param pixelSizeY Pixel height
       @return True if data is valid (image has been loaded), false
       otherwise
     */
    virtual bool getPixelSize(double& pixelSizeX, double& pixelSizeY)
    {
      pixelSizeX = adfGeoTransform[1];
      pixelSizeY = adfGeoTransform[5];
      return true;
    }
    
  protected:

    void deallocateImageryCore();

    /**
       Turns the data in the imageBlocks_ structure into usable OpenGL
       textures.
     */
    void setupImageTextures();

    /**
       Turns the data in imageData_ into a usable OpenGL texture.
     */
    void setupGLTexture(unsigned char *data, int xsize, int ysize, GLuint *texNumPtr);

    /**
       Method that actually draws the GL textures
     */
    void drawImagery(nrec::geometry::Point3D_d offset, float alphaValue, double z);

    /**
       Method to split image into blocks and store as GL textures
     */
    void loadTextures();
    
    /**
       Width and height of GL textures

       Too small, and too many textures will be created, hurting
       performance. Too large, and the textures will be too larget to
       fix on the video card.
     */
    static const int textureSize = 2048;

    /**
       Array of GL textures
     */
    std::vector<ImageBlock> imageBlocks_;

    /**
       Used to determine whether to convert image data into GL textures
     */
    bool glTextureReady_;

    /**
       Textures must be deleted in the display thread, but image
       loading is driven by threads
     */
    bool glTexturesUndeleted_;
    
  private:
    
  };
}

#endif

