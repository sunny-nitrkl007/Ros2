#ifndef _ShutdownRequestInterfaceTypes_h_
#define _ShutdownRequestInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "ShutdownRequest.h"

typedef interfaces::baseTypes::InputInterface<ShutdownRequest> ShutdownRequestInput;
typedef interfaces::baseTypes::OutputInterface<ShutdownRequest> ShutdownRequestOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<ShutdownRequestInput>()
  {
    return "ShutdownRequestInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<ShutdownRequestOutput>()
  {
    return "ShutdownRequestOutput";
  }
}

#endif
