/*******************************************************************************
** @attention COPYRIGHT (C) 2011 CATERPILLAR INC. ALL RIGHTS RESERVED.
**
** @file    ShutdownRequest.h
**
** @author  Miroslaw Kolesiak
** @date    September 09, 2011
**
** @brief   This is the interface definition for ShutdownRequest.
*******************************************************************************/
#ifndef SHUTDOWNREQUEST_H
#define SHUTDOWNREQUEST_H
#include <ais/interfaces/traits/csvable.h>
#include <ais/serialization/Datum.h>
#include <std_types.h>
#include <catdllib_fid_def.h>

class ShutdownRequestStorage : public csvable
{
public:
    ShutdownRequestStorage( ): m_request( 0 ), m_keyswitchState( UNKNOWN1U + FMIDNR ) { }
    ShutdownRequestStorage( int request, unsigned_8 keyswitchState ):
        m_request( request ),
        m_keyswitchState( keyswitchState ) { }

    void setShutdownIsRequested( const bool request ) {m_request = request;};
    bool getShutdownIsRequested() const {return m_request;};
    
    void setKeyswitchState( const unsigned_8 state ) {m_keyswitchState = state;};
    unsigned_8 getKeyswitchState() const {return m_keyswitchState;};

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Output data in CSV format
    /// @param out - CsvOutStream to dump data
    ///////////////////////////////////////////////////////////////////////////////
    void toCsv(CsvOutStream& out) const
    {
        out("ShutdownRequest", m_request);
        out("KeyswitchState", static_cast<int>(m_keyswitchState));
    }
    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Serialize function for ExampleTypeStorage (use boost serialization)
    /// @param ar - archive to store serialization
    /// @param version - version of serialization
    ///////////////////////////////////////////////////////////////////////////////
    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
        ar & m_request;
        if(version >= 1)
        {
            ar & m_keyswitchState;
        }
    }

private:
    // Shutdown requested 
    //  TRUE  - shutdown has been requested
    //  FALSE - shutdown has not been requested
    //
    bool m_request;

    // Keyswitch State
    //  TRUE  - Keyswitch on
    //  FALSE - Keyswitch off
    //
    // Will be set to DSI value if unknown or faulted.
    unsigned_8 m_keyswitchState;
};


typedef Datum<ShutdownRequestStorage> ShutdownRequest;

BOOST_CLASS_VERSION(ShutdownRequestStorage, 1)

#endif

