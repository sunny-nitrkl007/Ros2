// Auto-generated: DO NOT MODIFY
#include "channel.h"
#include <ais/PluginProcessor/PluginDefine.h>

SimpleCommsClientStatusChannelInput::SimpleCommsClientStatusChannelInput():
    m_channel(NULL)
{
}
SimpleCommsClientStatusChannelInput::~SimpleCommsClientStatusChannelInput()
{
    // call cleanup, just in case
    if(m_channel != NULL)
    {
        LOG_INFO("Destroying still-connected interface on channel '%s'",m_channel->getChannelName().c_str());
        cleanup();
    }
}
bool SimpleCommsClientStatusChannelInput::initialize(const ConfigSection &cs)
{
    // CRB: sad that we do nontrivial work in the constructor, but we would have to work out
    // a way to get the config section to/through the initialize() method instead
    // note: the channel config must point at "SimpleCommsStats"... sad that we have to replicate that...
    ConfigSection channelConfig;
    if (cs.get( std::string("channel"), channelConfig ))
    {
        interfaces::Channel *basicChannel = interfaces::ChannelFactory::createChannel(channelConfig, &newData_, interfaces::Read);
        if(basicChannel != NULL)
        {
            m_channel = dynamic_cast<SimpleCommsChannel*>(basicChannel);
            if(m_channel == NULL)
            {
                LOG_ERROR("Channel configured in '%s' is not a SimpleCommsChannel: this makes no sense for the SimpleCommsStats message!",
                          cs.getName().c_str());
                interfaces::ChannelFactory::releaseChannel(basicChannel);
            }
        } // else failed to create
    }
    else
    {
        LOG_ERROR( "No channel config available for '%s'", cs.getName().c_str() );
        return false;
    }

    if(m_channel == NULL)
    {
        LOG_ERROR( "Failed to create underlying channel on construction, cannot connect!" );
        return false;
    }
    return(m_channel->connect( ) == interfaces::CS_Success);
}
void SimpleCommsClientStatusChannelInput::cleanup( void )
{
    if (m_channel != NULL)
    {
        m_channel->disconnect( );
        interfaces::Channel *basicChannel = m_channel;
        interfaces::ChannelFactory::releaseChannel(basicChannel);
        m_channel = NULL;
    }
}
bool SimpleCommsClientStatusChannelInput::get(SimpleCommsClientStatus &status)
{
    std::string payload;
    if(m_channel != NULL)
    {
        if(m_channel->read(payload) == interfaces::CS_NewData)
        {
            // attempt to validate
            const SimpleComms::ClientStatsMessage *csm = SimpleComms::ClientStatsMessage::validateBuffer(payload.c_str(),payload.size());
            if(csm != NULL)
            {
                // force null termination on client name, just in case this is bogus data
                const_cast<char &>(csm->client[sizeof(csm->client) - 1]) = 0;
                status.clientName = csm->client;
                // harvest transmissionTime from the message information structure
                status.transmissionTime = m_channel->getLastMessageInfo().sendMsgTime;
                status.bytesSent    = csm->bytesSent;
                status.messagesSent = csm->messagesSent;
                status.bytesRead    = csm->bytesRead;
                status.messagesRead = csm->messagesRead;
                status.channelTraffic.resize(csm->numTrafficEntries);
                for(uint32_t ii = 0; ii < csm->numTrafficEntries; ++ii)
                {
                    status.channelTraffic[ii] = csm->channelTrafficInfo[ii];
                    // force some more null termination, just in case...
                    const_cast<char &>(status.channelTraffic[ii].origin[sizeof(status.channelTraffic[ii].origin) - 1]) = 0;
                    const_cast<char &>(status.channelTraffic[ii].channel[sizeof(status.channelTraffic[ii].channel) - 1]) = 0;
                }
                return true;
            } // else invalid buffer
        } // else no new data
    } // else no channel
    return false;
}
bool SimpleCommsClientStatusChannelInput::getQueueProperties (unsigned long &currentDepth, unsigned long &maxDepth, unsigned long &droppedPackets) 
{
  return m_channel->getQueueProperties(currentDepth, maxDepth, droppedPackets);
}
RegisterPlugin(SimpleCommsClientStatus.Channel.Input, interfaces::Interface, SimpleCommsClientStatusChannelInput)
