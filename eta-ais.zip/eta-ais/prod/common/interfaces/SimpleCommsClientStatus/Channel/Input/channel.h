// Auto-generated: DO NOT MODIFY

#ifndef SimpleCommsClientStatus_Channel_Input_H
#define SimpleCommsClientStatus_Channel_Input_H

#include <interfaces/SimpleCommsClientStatus/InterfaceTypes.h>
#include <ais/interfaces/baseTypes/ChannelFactory.h>
#include <ais/task/channelBuilders/SimpleCommsChannel.h>

////////////////////////////////////////////////////////////////////////////////
/// @brief We use a channel, but not boost, so we must do things slightly different here
////////////////////////////////////////////////////////////////////////////////
class SimpleCommsClientStatusChannelInput : public SimpleCommsClientStatusInput
{
  public:
    // constructor satisfies the pattern in autogen_channel.h
    SimpleCommsClientStatusChannelInput();
    virtual ~SimpleCommsClientStatusChannelInput();

    // from IDbObject
    virtual bool initialize(const ConfigSection &cs);
    virtual void cleanup();

    // from InputInterface
    virtual bool get(SimpleCommsClientStatus &status);

    virtual bool getQueueProperties (unsigned long &currentDepth, unsigned long &maxDepth, unsigned long &droppedPackets) ;


  private:
    NewDataCondition *m_newDataCondition;
    SimpleCommsChannel *m_channel;
};

#endif

