///////////////////////////////////////////////////////////////////////////////
/// @file      SimpleCommsStatus/Type.h
/// @author    Christopher R. Baker <cbaker@rec.ri.cmu.edu>
/// @date      07/05/2011
///
/// @attention Copyright (C) 2011
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////

#ifndef SimpleCommsClientStatus_Type_h
#define SimpleCommsClientStatus_Type_h

#include <ais/interfaces/traits/csvable.h>
#include <ais/time/TimeStamp.h>
#include <ais/comms/StatsMessages.h>
#include <string>
#include <vector>

////////////////////////////////////////////////////////////////////////////////
/// @brief Comms Statistics from any/all tasks in the system
///
/// This is a special payload that is more friendly than the SimpleComms::ClientStats message structure, but can only be
/// "read" by tasks, not "written".
///
/// @note: this is NOT a Datum!
////////////////////////////////////////////////////////////////////////////////
class SimpleCommsClientStatus : public csvable // remove this inheritance if you don't implement "toCsv" below
{
  public:

    ////////////////////////////////////////////////////////////////////////////////
    /// @brief Default Constructor
    ///
    /// All message classes must have a default/unit constructor to play nice with the
    /// the comms system.  This constructor should initialize all members to a known
    /// default state.
    ///
    /// The usefulness of more advanced constructors is limited by the superposition
    /// of the Datum<> template below, so it is not typically worth defining others
    ///
    ////////////////////////////////////////////////////////////////////////////////
    SimpleCommsClientStatus( ):
        transmissionTime(),
        clientName(),
        bytesSent(),
        messagesSent(),
        channelTraffic()
        { }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Output data in CSV format
    /// @param out - output stream
    ///
    /// @note this implements the "csvable" type trait
    ///////////////////////////////////////////////////////////////////////////////
    virtual void toCsv(CsvOutStream& out) const
    {
        // CsvOutStream defines a template functor that allows you to succinctly describe your output
        out("transmissionTime",transmissionTime.toDouble());
        out("clientName",clientName);
        out("bytesSent",bytesSent);
        out("messagesSent",messagesSent);
        out("channelCount",channelTraffic.size());
    }

    // member data
    TimeStamp transmissionTime;
    std::string clientName;
    unsigned long bytesSent;
    unsigned long messagesSent;
    unsigned long bytesRead;
    unsigned long messagesRead;
    typedef std::vector<SimpleComms::ChannelOriginTotals> ChannelTrafficList;
    ChannelTrafficList channelTraffic;
};

#endif // SimpleCommsClientStatusType_h
