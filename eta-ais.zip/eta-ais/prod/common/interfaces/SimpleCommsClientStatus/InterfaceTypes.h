#ifndef _SimpleCommsClientStatusInterfaceTypes_h_
#define _SimpleCommsClientStatusInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "Type.h"

typedef interfaces::baseTypes::InputInterface<SimpleCommsClientStatus> SimpleCommsClientStatusInput;
typedef interfaces::baseTypes::OutputInterface<SimpleCommsClientStatus> SimpleCommsClientStatusOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<SimpleCommsClientStatusInput>()
  {
    return "SimpleCommsClientStatusInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<SimpleCommsClientStatusOutput>()
  {
    return "SimpleCommsClientStatusOutput";
  }
}

#endif
