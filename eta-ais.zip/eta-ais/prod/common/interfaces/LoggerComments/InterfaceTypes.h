#ifndef _LoggerCommentsInterfaceTypes_h_
#define _LoggerCommentsInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "LoggerComments.h"

typedef interfaces::baseTypes::InputInterface<LoggerComments> LoggerCommentsInput;
typedef interfaces::baseTypes::OutputInterface<LoggerComments> LoggerCommentsOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<LoggerCommentsInput>()
  {
    return "LoggerCommentsInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<LoggerCommentsOutput>()
  {
    return "LoggerCommentsOutput";
  }
}

#endif
