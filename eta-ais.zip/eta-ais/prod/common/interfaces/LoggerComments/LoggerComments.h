///////////////////////////////////////////////////////////////////////////////
/// @file      LoggerComments.h
/// @author    jderence
/// @date      7/3/2008
/// @brief     
///
/// 
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef _LoggerComments_h_
#define _LoggerComments_h_

#include <ais/interfaces/traits/csvable.h>

#include <coreTechExtensions/serialize.h>
#include <geometry/poses/ISOPose3D.h>
#include <geometry/primitives/Vector2D.h>

#include <ais/serialization/Datum.h>
#include <ais/time/GetTime.h>

#include <string.h>

struct LoggerCommentsStorage : public csvable
{
  enum CommentType { COMMENT = 1,START_EVENT_COMMENT = 2,STOP_EVENT_COMMENT= 3 };

  LoggerCommentsStorage() : commentType(COMMENT), annotation("") {};
  
  // -- Helper functions --
  void createComment(const CommentType type,
                     const std::string& inAnnotation)
  {
    commentType = type;
    timestamp = localhostNow();
    annotation = inAnnotation;
    nrec::geometry::ISOPose3D<double> blankPoint;
    location = blankPoint;
  };


  void createComment(const CommentType type,
                     const std::string& inAnnotation, 
                     const nrec::geometry::ISOPose3D<double> inLocation)
  {
    commentType = type;
    timestamp = localhostNow();
    annotation = inAnnotation;
    location = inLocation;
  };


  void createComment(const CommentType type,
                     const std::string& inAnnotation, 
                     const nrec::geometry::ISOPose3D<double> inLocation,
                     const nrec::geometry::Vector2D<double> inClickPoint)
  {
    commentType = type;
    timestamp = localhostNow();
    annotation = inAnnotation;
    location = inLocation;
    clickPoint = inClickPoint;
  };


  // Accessors
  nrec::geometry::ISOPose3D<double> getLocation() const { return location; };
  std::string getAnnotation() const { return annotation; };
  CommentType getCommentType() const { return commentType; };
  TimeStamp getTimestamp() const { return timestamp; };
  nrec::geometry::Vector2D<double> getClickPoint() const { return clickPoint; };
//TimeStamp getEventTime() const { return eventTime; };

  // to string
  std::string commentToString(CommentType type)
  {
    std::string result;
    switch(type)
    {
    case COMMENT:
      result = "COMMENT";break;
    case START_EVENT_COMMENT:
      result = "START EVENT COMMENT";break;
    case STOP_EVENT_COMMENT:
      result = "STOP EVENT COMMENT"; break;
    default:  result = ""; break;
    }// end switch
    return result;
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Boost Serialization function for LoggerComments
  /// @param ar 
  /// @param version 
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    ar & timestamp;
    ar & commentType;
    ar & annotation;
    ar & location;
    
    if (version > 0)
    {
      ar & clickPoint;
    }
    else
    {
      clickPoint = nrec::geometry::Vector2D<double>(0, 0);
    }

//  if (version > 1)
//  {
//    ar & eventTime;
//  }
//  else
//  {
//    eventTime = TimeStamp();
//  }

  };
  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Output data in CSV format
  /// @param out - out stream to dump data
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const 
  {
    out("Timestamp",timestamp.toDouble());
    out("CommentType",commentType);
    out("Annotation",annotation);
    out("LocationX",location.x());
    out("LocationY",location.y());
    out("LocationZ",location.z());
    out("LocationRollDeg",location.roll().getDegrees());
    out("LocationPitchDeg",location.pitch().getDegrees());
    out("LocationYawDeg",location.yaw().getDegrees());
    out("ClickPointX",clickPoint.x());
    out("ClickPointY",clickPoint.y());
  };

  //-- members --
  CommentType commentType;  ///< Type of comment message - COMMENT or POSE_TAGGED_COMMENT
  std::string annotation; ///< Text string of operator comments on system performance
  TimeStamp timestamp;    ///< Time at which the event described in the annotation occurred.
  nrec::geometry::ISOPose3D<double> location; ///< XY UTM coordinates of the event of interest (only valid
                                              ///< for POSE_TAGGED_COMMENT types
  nrec::geometry::Vector2D<double> clickPoint;  ///< Point referenced by user
//TimeStamp eventTime;
};
//#include "LoggerComments_inl.h"

typedef Datum<LoggerCommentsStorage> LoggerComments;
BOOST_CLASS_VERSION(LoggerCommentsStorage, 1)

#endif
