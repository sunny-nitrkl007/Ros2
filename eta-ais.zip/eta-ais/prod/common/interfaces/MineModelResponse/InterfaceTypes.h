#ifndef _MineModelResponseInterfaceTypes_h_
#define _MineModelResponseInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "MineModelResponse.h"

typedef interfaces::baseTypes::InputInterface<MineModelResponse> MineModelResponseInput;
typedef interfaces::baseTypes::OutputInterface<MineModelResponse> MineModelResponseOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<MineModelResponseInput>()
  {
    return "MineModelResponseInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<MineModelResponseOutput>()
  {
    return "MineModelResponseOutput";
  }
}

#endif
