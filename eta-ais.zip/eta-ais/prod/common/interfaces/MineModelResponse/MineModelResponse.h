///////////////////////////////////////////////////////////////////////////////
/// @file      MineModelResponse.h
/// @author    rBhatia
/// @date      07/27/2011
/// @brief     A response message sent from the AssignmentManager to the OBI
/// for Mine model updates
///
/// This messages indicates whether or not a MineModel has been accepted and
/// if it was rejected, the reason why.
///
/// @attention Copyright (C) 2011
/// @attention Caterpillar Inc
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef MineModelResponse_h
#define MineModelResponse_h

#include "geometry/poses/ISOPose3D.h"
#include "mineModel/MineModelElement.h" // for element ID object
#include "ais/time/GetTime.h"

class MineModelResponseStorage : public csvable
{
  public:
    MineModelResponseStorage(): m_mineModelUpdateTime(TimeStamp(-1,0)),m_responseElements()
    { }

    enum MineModelResponseCode{
      MineModelAccepted = 0,
      LaneHasInsufficientDataPoints,
      LeftAndRightBoundariesAreReversed,
      PathPointsContainIntersections,
      UnableToGenerateCorrespondences,
      LaneCurvatureViolatesLimit,
      LaneHasDuplicatedDataPoints,
      RightAndInteriorBoundariesAreReversed,
      LeftAndInteriorBoundariesAreReversed,
      InteriorLineOutsideOfLaneBoundaries,
      LaneIsTooShort,
      LaneIsTooLong,
      LaneContainsTooManyPoints,
      InteriorPointsAreOutOfOrder,
      LaneHasUnknownElevations,
      LaneInterfaceSkewed,
      CorrespondenceSkewed,
      NumberOfCodes
    };

    typedef std::pair<MineModelResponseCode, mineModel::MineModelElement> MineModelResponseElement;

    void clearResponses() { m_responseElements.clear(); }
    void addResponseElement (MineModelResponseCode code, mineModel::MineModelElement element)
    {
      MineModelResponseElement thisResponse;
      thisResponse.first = code;
      thisResponse.second = element;
      m_responseElements.push_back(thisResponse);
    }
    void setCodeToAccepted()
    {
      clearResponses();
      mineModel::MineModelElement element;
      element.elementId().id() = 0;                //dummy element. Is this needed?
      element.elementId().version() = 0;
      element.elementId().type() = 0x01;
      addResponseElement(MineModelAccepted, element);
    }
    std::vector<MineModelResponseElement> getResponses() {return m_responseElements;}
    unsigned int getNumOfResponses() { return m_responseElements.size(); }

    TimeStamp getMinemodelUpdateTime() const {return m_mineModelUpdateTime;}
    void setMineModelUpdateTime(TimeStamp originationTime) { m_mineModelUpdateTime = originationTime; }

    std::string getMessageString(MineModelResponseElement responseElement) const
    {
      switch (responseElement.first)
      {
        case MineModelAccepted:
          return std::string("Mine model accepted");
          break;
        case LaneHasInsufficientDataPoints:
          return std::string("Lane does not have data points in either the left boundary, right boundary or travel path");
          break;
        case LeftAndRightBoundariesAreReversed:
          return std::string("Left boundary is to the right of the right boundary");
          break;
        case PathPointsContainIntersections:
          return std::string("Lane point lists contain intersections between left boundary, right boundary and/or travel path");
          break;
        case UnableToGenerateCorrespondences:
          return std::string("Unable to generate all correspondences due to given geometry");
          break;
        case LaneCurvatureViolatesLimit:
          return std::string("Lane curvature violates the curvature limit");
          break;
        case LaneHasDuplicatedDataPoints:
          return std::string("Lane points contain duplicates");
          break;
        case RightAndInteriorBoundariesAreReversed:
          return std::string("Right boundary is to the left of the interior line");
          break;
        case LeftAndInteriorBoundariesAreReversed:
          return std::string("Left boundary is to the right of the interior line");
          break;
        case InteriorLineOutsideOfLaneBoundaries:
          return std::string("Interior line is outside of lane boundaries");
          break;
        case LaneIsTooShort:
          return std::string("Lane does not span the minimum required distance");
          break;
        case LaneIsTooLong:
          return std::string("Lane is longer than the maximum allowed distance");
          break;
        case LaneContainsTooManyPoints:
          return std::string("Lane contains more points than allowed");
          break;
        case InteriorPointsAreOutOfOrder:
          return std::string("Lane contains one or more interior point is out of order");
          break;
        case LaneHasUnknownElevations:
          return std::string("Autonomous lane has unknown elevations");
          break;
        case LaneInterfaceSkewed:
          return std::string("Autonomous lane has a skewed interface");
          break;
        case CorrespondenceSkewed:
          return std::string("Autonomous lane has a skewed correspondence");
          break;
        default:
          return std::string("Invalid response code");
          break;
      }
    }
    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Print VehicleState structure out in CSV format
    /// @param out - output stream
    ///////////////////////////////////////////////////////////////////////////////
    void toCsv(CsvOutStream& out) const
    {
      out("MineModelUpdateTime", m_mineModelUpdateTime.toDouble());
    }

  private:
    TimeStamp m_mineModelUpdateTime;
    std::vector <MineModelResponseElement> m_responseElements;//pair include the rejection code and the element being rejected

    friend class boost::serialization::access;
    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
      ar & m_responseElements;
      ar & m_mineModelUpdateTime;
    }
};

typedef Datum<MineModelResponseStorage> MineModelResponse;

BOOST_CLASS_VERSION(MineModelResponseStorage, 0)


#endif
