#ifndef _SnapshotBridgeStatusInterfaceTypes_h_
#define _SnapshotBridgeStatusInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "SnapshotBridgeStatus.h"

typedef interfaces::baseTypes::InputInterface<SnapshotBridgeStatus> SnapshotBridgeStatusInput;
typedef interfaces::baseTypes::OutputInterface<SnapshotBridgeStatus> SnapshotBridgeStatusOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<SnapshotBridgeStatusInput>()
  {
    return "SnapshotBridgeStatusInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<SnapshotBridgeStatusOutput>()
  {
    return "SnapshotBridgeStatusOutput";
  }
}

#endif
