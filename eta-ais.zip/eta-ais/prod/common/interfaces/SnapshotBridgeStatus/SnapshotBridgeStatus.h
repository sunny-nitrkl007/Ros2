//////////////////////////////////////////////////////////////////////////////
/// @file      SnapshotBridgeStatus.h
/// @author    dtascion
/// @date      10/18/2012
/// @brief     The snapshot bridge periodically publishes its state to the OCS.
///
/// 
///
/// @attention Copyright (C) 2012
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef SnapshotBridgeStatus_h
#define SnapshotBridgeStatus_h

#include <string>
#include "ais/interfaces/traits/csvable.h"

///@brief Message from the AutonomySnapshotBridge with details on the current state of logging.
struct SnapshotBridgeStatusStorage : public csvable
{
  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Constructor to initialize state of objects
  ///////////////////////////////////////////////////////////////////////////////
  SnapshotBridgeStatusStorage() : mode(UNKNOWN), activeSnapshotTitle() {}

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Enumeration stating the different modes of the SnapshotBridge
  ///////////////////////////////////////////////////////////////////////////////
  enum SnapshotBridgeMode {
    IDLE, TAKING_SNAPSHOT, SNAPSHOT_CREATION_FAILING, UNKNOWN
  };
  static std::string snapshotBridgeModeToString(const SnapshotBridgeMode mode)
  {
    switch(mode)
    {
      case IDLE:                       return "Idle"; break;
      case TAKING_SNAPSHOT:            return "Taking Snapshot"; break;
      case SNAPSHOT_CREATION_FAILING:  return "Trying, but snapshot creation failed"; break;
      default:                         return "Unknown";
    }
  };

  ///
  /// The mode that the snapshot bridge is currently in.
  ///
  SnapshotBridgeMode mode;

  ///
  /// The title of the snapshot being actively recorded right now.
  ///
  std::string activeSnapshotTitle;

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Boost Serialization function for SnapshotBridgeStatus
  /// @param ar - boost archive
  /// @param version - version of the class type 
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    ar & mode;

    if(version > 1)
    {
        ar & activeSnapshotTitle;
    }
  };

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Print SnapshotBridgeStatus structure out in CSV format 
  /// @param out - output stream
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const
  {
  }
};

typedef Datum<SnapshotBridgeStatusStorage> SnapshotBridgeStatus;
BOOST_CLASS_VERSION(SnapshotBridgeStatusStorage, 2)

#endif
