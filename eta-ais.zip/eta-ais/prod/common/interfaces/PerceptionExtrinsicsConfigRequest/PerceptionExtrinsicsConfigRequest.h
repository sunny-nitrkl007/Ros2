///////////////////////////////////////////////////////////////////////////////
/// @file      PerceptionExtrinsicsConfigRequest.h
/// @author    bode
/// @date      4/11/2013
/// @brief     Interface for requesting extrinsics config information
///
/// @attention Copyright (C) 2013
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef PerceptionExtrinsicsConfigRequest_h
#define PerceptionExtrinsicsConfigRequest_h

#include <string>
#include <ais/serialization/Datum.h> // For Boost serialization
#include "ais/log/Logger.h"

class PerceptionExtrinsicsConfigRequestStorage
{
public:
  PerceptionExtrinsicsConfigRequestStorage():m_requestingModuleName("Unknown"){ }

  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    switch(version)
    {
      case 0:
      {
        ar & m_requestingModuleName;
        break;
      }
    default:
      {
        LOG_ERROR("Version %d not supported for type PerceptionExtrinsicsConfigRequest", version);
        break;
      }
    }

  }
  std::string m_requestingModuleName;
};

typedef Datum<PerceptionExtrinsicsConfigRequestStorage> PerceptionExtrinsicsConfigRequest;

BOOST_CLASS_VERSION(PerceptionExtrinsicsConfigRequestStorage, 0);

#endif

