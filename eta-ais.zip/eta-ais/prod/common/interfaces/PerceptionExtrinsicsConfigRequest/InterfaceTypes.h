#ifndef _PerceptionExtrinsicsConfigRequestInterfaceTypes_h_
#define _PerceptionExtrinsicsConfigRequestInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "PerceptionExtrinsicsConfigRequest.h"

typedef interfaces::baseTypes::InputInterface<PerceptionExtrinsicsConfigRequest> PerceptionExtrinsicsConfigRequestInput;
typedef interfaces::baseTypes::OutputInterface<PerceptionExtrinsicsConfigRequest> PerceptionExtrinsicsConfigRequestOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<PerceptionExtrinsicsConfigRequestInput>()
  {
    return "PerceptionExtrinsicsConfigRequestInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<PerceptionExtrinsicsConfigRequestOutput>()
  {
    return "PerceptionExtrinsicsConfigRequestOutput";
  }
}

#endif
