#ifndef _ChannelToLogInterfaceTypes_h_
#define _ChannelToLogInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "ChannelToLog.h"

typedef interfaces::baseTypes::InputInterface<ChannelToLog> ChannelToLogInput;
typedef interfaces::baseTypes::OutputInterface<ChannelToLog> ChannelToLogOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<ChannelToLogInput>()
  {
    return "ChannelToLogInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<ChannelToLogOutput>()
  {
    return "ChannelToLogOutput";
  }
}

#endif
