///////////////////////////////////////////////////////////////////////////////
/// @file      ChannelToLog.h
/// @author    jderence
/// @date      8/3/2009
/// @brief     List of strings naming the channels to log.  This datum is intended
/// to only be sent by CDC to the AutonomyLogger
///
/// @attention Copyright (C) 2009
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef ChannelToLog_h
#define ChannelToLog_h

#include <ais/serialization/Datum.h>
#include <vector>
#include <string>
#include <boost/serialization/vector.hpp>
  
///////////////////////////////////////////////////////////////////////////////
/// @brief List of strings naming the channels to log.
///////////////////////////////////////////////////////////////////////////////
struct ChannelToLogStorage 
{
  typedef std::vector<std::string> ChannelList;
  typedef std::vector<std::string>::iterator ChannelListIterator;

  ChannelList m_table;  ///< List of strings containing Channel Names

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Boost serialization method, used to save and restore from archive
  /// @param [in,out] ar Boost archive used to store datum
  /// @param version Archive version of this type
  ///////////////////////////////////////////////////////////////////////////////
  template<class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    ar & m_table;
  }
};

typedef Datum<ChannelToLogStorage> ChannelToLog;

BOOST_CLASS_VERSION(ChannelToLogStorage, 0);

#endif
