///////////////////////////////////////////////////////////////////////////////
/// @file      ActiveDiagnostics.h
/// @author    Matt Johnson
/// @date      5/6/2014
/// @brief     Interface to convey active diagnostics
///
///
/// @attention COPYRIGHT (C) 2014 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////
#ifndef _ActiveDiagnostics_h_
#define _ActiveDiagnostics_h_

#include "ais/interfaces/traits/csvable.h"

#include <ais/serialization/Datum.h> // For Boost serialization

#include <boost/serialization/vector.hpp>

#include <vector>

typedef unsigned char byte;
typedef unsigned short ushort;

struct Diagnostic
{
public:
  Diagnostic(byte i, ushort c, byte f, byte w, std::string desc = "", uint16_t sub = 0xffff):
    id(i),
    cid(c),
    fmi(f),
    wci(w),
    description(desc),
    subsystem(sub)
  {}

  Diagnostic():
    id(),
    cid(),
    fmi(),
    wci(),
    description(""),
    subsystem(0xffff)
    {}


  unsigned char id;
  unsigned short cid;
  unsigned char fmi;
  unsigned char wci;
  std::string description;
  uint16_t subsystem;

  std::string getDiagStr() const
  {
    std::stringstream ss;
    ss << static_cast<int>(id) << "-" << static_cast<int>(cid) << "-" << static_cast<int>(fmi) << "-" << static_cast<int>(wci);
    return ss.str();
  }

  std::string getDiagDescStr() const
  {
    std::stringstream ss;
    ss << static_cast<int>(id) << "-" << static_cast<int>(cid) << "-" << static_cast<int>(fmi) << "-" << static_cast<int>(wci);
    ss << " " << description;
    return ss.str();
  }

  std::string getPrettyStr() const
  {
    std::stringstream ss;
    if(fmi == 255)
      ss << static_cast<int>(id) << "-E" << static_cast<int>(cid) << "(" << static_cast<int>(wci) << ")";
    else
      ss << static_cast<int>(id) << "-" << static_cast<int>(cid) << "-" << static_cast<int>(fmi) << "(" << static_cast<int>(wci) << ")";
    ss << " " << description;
    return ss.str();
  }

  bool operator==(const Diagnostic& rhs) const {
      return id == rhs.id && cid == rhs.cid && fmi == rhs.fmi && wci == rhs.wci;
  }

//  friend class boost::serialization::access;
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    ar & id & cid & fmi & wci & description & subsystem;
  }

  void toCsv(std::string prefix, CsvOutStream & out) const
  {
    out("", prefix + getPrettyStr());
  }
};

BOOST_CLASS_VERSION(Diagnostic, 1);


class ActiveDiagnosticsStorage : public csvable
{  
public:  
     ActiveDiagnosticsStorage() : m_activeDiagnostics(), dnsname("") { }

     std::vector<Diagnostic> m_activeDiagnostics;
     typedef std::vector<Diagnostic>::const_iterator DiagIter;
     std::string dnsname;

     template <class Archive>
     void serialize(Archive &ar, unsigned int version)
     {
       ar & dnsname & m_activeDiagnostics;
     }

     void toCsv(CsvOutStream & out) const
     {
       out( "dns name", dnsname );
       out( "numActiveDiags", m_activeDiagnostics.size() );

       std::vector<Diagnostic>::const_iterator it;
       for(it = m_activeDiagnostics.begin(); it != m_activeDiagnostics.end(); ++it)
       {
         it->toCsv("",out);
       }
     }

 private:  
     /* Add Fields Here */
};  

typedef Datum<ActiveDiagnosticsStorage> ActiveDiagnostics;

BOOST_CLASS_VERSION(ActiveDiagnosticsStorage, 1);
#endif

