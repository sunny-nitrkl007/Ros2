#ifndef _ActiveDiagnosticsInterfaceTypes_h_
#define _ActiveDiagnosticsInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "ActiveDiagnostics.h"

typedef interfaces::baseTypes::InputInterface<ActiveDiagnostics> ActiveDiagnosticsInput;
typedef interfaces::baseTypes::OutputInterface<ActiveDiagnostics> ActiveDiagnosticsOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<ActiveDiagnosticsInput>()
  {
    return "ActiveDiagnosticsInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<ActiveDiagnosticsOutput>()
  {
    return "ActiveDiagnosticsOutput";
  }
}

#endif
