///////////////////////////////////////////////////////////////////////////////
/// @file      MCIVehicleCommand.h
/// @author    J Kieser
/// @date      1/1/2011
/// @brief     Vehicle commands sent to the base machine.
///
/// @attention COPYRIGHT (C) 2011 CATERPILLAR INC. ALL RIGHTS RESERVED.
/// 
///////////////////////////////////////////////////////////////////////////////
#ifndef MCIVehicleCommand_h
#define MCIVehicleCommand_h
#include "ais/interfaces/traits/csvable.h"
#include <ais/serialization/Datum.h>

class MCIVehicleCommandStorage : public csvable 
{
public:
  MCIVehicleCommandStorage(double velocity = 0.0, 
                           double acceleration = 0.0,
                           double deceleration = 0.0,
                           bool setParkingBrake = true,
                           double estGrade = 0.0,
                           double decelScale = 1.0,
                           double absAggressionFactor_pct = 100.0,
                           bool highRimpullAreaState = false):
    m_velocity(velocity),
    m_acceleration(acceleration),
    m_deceleration(deceleration),
    m_setParkingBrake(setParkingBrake),
    m_commandSource( CS_UNKNOWN ),
    m_estimatedGrade_pct(estGrade),
    m_decelScale(decelScale),
    m_absAggressionFactor_pct(absAggressionFactor_pct),
    m_highRimpullAreaState(highRimpullAreaState)
    {}

  enum CommandSource
  {
    CS_INTELLIGENT_DRIVER = 0,
    CS_SCRIPT_EXECUTION,
    CS_PATH_TIMEOUT,
    CS_PARK_BRAKE,
    CS_START_OF_MOTION_DELAY,
    CS_UNKNOWN, //Should always be last in list
  };

  static std::string commandSourceStr( const CommandSource& cs )
  {
    switch (cs)
    {
      case CS_INTELLIGENT_DRIVER:     return std::string("INTELLIGENT_DRIVER");
      case CS_SCRIPT_EXECUTION:         return std::string("SCRIPT_EXECUTION");
      case CS_PATH_TIMEOUT:           return std::string("PATH_TIMEOUT");
      case CS_PARK_BRAKE:             return std::string("PARK_BRAKE");
      case CS_START_OF_MOTION_DELAY:  return std::string("START_OF_MOTION_DELAY");
      case CS_UNKNOWN:                return std::string("UNKNOWN");
      
    }
    return std::string("UNKNOWN");
  }

  // get/set Velocity
  void setVelocity(double v) {m_velocity = v;}
  double getVelocity() const {return m_velocity;}

  // get/set Acceleration
  void setAcceleration(double a) {m_acceleration = a;}
  double getAcceleration() const {return m_acceleration;}

  // get/set Deceleration
  void setDeceleration(double d) {m_deceleration = d;}
  double getDeceleration() const {return m_deceleration;}

  // get/set parkingbrake
  void setParkingBrakeState(bool brake) { m_setParkingBrake = brake;}
  bool getParkingBrakeState() const {return m_setParkingBrake;}

  void setCommandSource(CommandSource cs) { m_commandSource = cs; }
  CommandSource getCommandSource() const { return m_commandSource; }

  // get/set grade
  void setGrade(double g) {m_estimatedGrade_pct = g;}
  double getGrade() const {return m_estimatedGrade_pct;}

  // get/set scale factor
  void setScale(double s) {m_decelScale = s;}
  double getScale() const {return m_decelScale;}

  // get/set ABS aggression factor
  void setAbsAggressionFactor(double absaggfact) { m_absAggressionFactor_pct = absaggfact;}
  double getAbsAggressionFactor() const {return m_absAggressionFactor_pct;}

  // get/set high rimpull area state
  void setHighRimpullAreaState(bool hraf) { m_highRimpullAreaState = hraf;}
  bool getHighRimpullAreaState() const {return m_highRimpullAreaState;}


  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Serialize function for MCIVehicleCommandStorage (use boost serialization)
  /// @param ar - archive to store serialization
  /// @param version - version of serialization
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    ar & m_velocity;
    ar & m_acceleration;
    ar & m_deceleration;
    ar & m_setParkingBrake;
    if ( version >= 1)
      ar & m_commandSource;
    if ( version >= 2)
      ar & m_estimatedGrade_pct & m_decelScale;
    if (version >= 3)
    	ar & m_absAggressionFactor_pct;
    if (version >= 4)
      ar & m_highRimpullAreaState;
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Output data in CSV format
  /// @param out - out stream to dump data
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const 
  {
    out("Velocity",     m_velocity);
    out("Acceleration", m_acceleration);
    out("Deceleration", m_deceleration);
    out("ParkingBrake", m_setParkingBrake);
    out("CommandSource", commandSourceStr( m_commandSource ));
    out("EstimatedGrade", m_estimatedGrade_pct);
    out("DecelScale", m_decelScale);
    out("AbsAggressionFactor" , m_absAggressionFactor_pct);
    out("HighRimpullAreaFlag" , m_highRimpullAreaState);
  }

private:
  double          m_velocity;        ///< Desired Speed - meters/sec
  double          m_acceleration;    ///< Desired Acceleration - meters/sec^2
  double          m_deceleration;    ///< Desired Deceleration - meters/sec^2
  bool            m_setParkingBrake; ///< Desired State of parking brake (true = engage, false = release)
  CommandSource   m_commandSource;   ///< Source of command
  double          m_estimatedGrade_pct; ///<Estimated Grade based on pitch - Percent, negative is traveling downhill, positive uphill (direction independent)
  double          m_decelScale;      ///< Scale factor applied to deceleration based on loaded state, pitch, and commanded deceleration (0-1.0)
  double			  m_absAggressionFactor_pct; ///< ABS Aggression Factor - % (100% max decel, 0% max stability)
  bool       m_highRimpullAreaState; ///< High Rimpull Area State
};

typedef Datum<MCIVehicleCommandStorage> MCIVehicleCommand;

BOOST_CLASS_VERSION(MCIVehicleCommandStorage, 4)

#endif
