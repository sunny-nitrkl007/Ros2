#ifndef _MCIVehicleCommandInterfaceTypes_h_
#define _MCIVehicleCommandInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "MCIVehicleCommand.h"

typedef interfaces::baseTypes::InputInterface<MCIVehicleCommand> MCIVehicleCommandInput;
typedef interfaces::baseTypes::OutputInterface<MCIVehicleCommand> MCIVehicleCommandOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<MCIVehicleCommandInput>()
  {
    return "MCIVehicleCommandInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<MCIVehicleCommandOutput>()
  {
    return "MCIVehicleCommandOutput";
  }
}

#endif
