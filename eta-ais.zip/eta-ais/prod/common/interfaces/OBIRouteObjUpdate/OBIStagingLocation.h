///////////////////////////////////////////////////////////////////////////////
/// @file      OBIStagingLocation.h
/// @author    J Struble
/// @date      2/13/2009
/// @brief     Combination of a vehicle reference location and staging point
///
/// @attention COPYRIGHT (C) 2008 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////
#ifndef  OBIStagingLocation_h
#define  OBIStagingLocation_h

#include <boost/operators.hpp>

#include "OBIStagingPoint.h"
#include "ais/interfaces/traits/TextWritable.h"

struct OBIStagingLocation : boost::equality_comparable<OBIStagingLocation>, public TextWritable
{
public:

  //Note:  This needs to match the SpotReference_t::referenceID_enum in tmacMsgs/UserDefinedTypes.h
  typedef enum
  {
    REF_ORIGIN = 0,         //Intended to be the origin used in the vehicleState, not sure why the office would ever want to use this
    REF_CNTR_FRONTBMPR,
    REF_CNTR_LOADCENTER,
    REF_CNTR_REARAXLE,
    REF_CNTR_REARTRAY,
    REF_HIGHWALL_BUMP_OPT,  //NFND...  Kept for legacy
    REF_HIGHWALL_BUMP_REQ,  //NFND...  Kept for legacy
    REF_HEXLOAD_BUMP_OPT,   //NFND...  Kept for legacy
  } machineReference_t;

  OBIStagingLocation():
    machineReference( REF_CNTR_REARAXLE ) { }

  machineReference_t          machineReference;
  OBIStagingPoint             stagingPoint;

  static std::string machineRefToString(const machineReference_t& ref)
  {
    switch(ref)
    {
    case(REF_ORIGIN):
      return "ORIGIN";
    case REF_CNTR_FRONTBMPR:
      return "CENTER OF FRONT BUMPER";
    case REF_CNTR_LOADCENTER:
      return "CENTER OF LOAD CENTER";
    case REF_CNTR_REARAXLE:
      return "CENTER OF REAR AXLE";
    case REF_CNTR_REARTRAY:
      return "CENTER OF REAR TRAY";
    case REF_HIGHWALL_BUMP_OPT:
      return "HIGHWALL BUMP OPTIONAL";
    case REF_HIGHWALL_BUMP_REQ:
      return "HIGHWALL BUMP REQUIRED";
    case REF_HEXLOAD_BUMP_OPT:
      return "HEXLOAD BUMP OPTIONAL";
    default:
      return "INVALD";
    }
  }

  template <class Archive>
    void serialize(Archive &ar, unsigned int version)
  {
    ar & machineReference & stagingPoint;
  }
  ///////////////////////////////////////////////////////////////////////////////
  /// @brief returns true if two staging locations are equal (staging point and reference both match)
  /// @return true if two staging locations are equal
  /// @param rhs the staging location to compare to this location
  ///////////////////////////////////////////////////////////////////////////////
  bool operator==(const OBIStagingLocation& rhs) const
  {
    return (this->machineReference == rhs.machineReference) &&
      (this->stagingPoint == rhs.stagingPoint);
  }

  void toStream(std::stringstream& out) const
  {
    out << "Reference:" << machineRefToString(machineReference) << "\n";
    stagingPoint.toStream(out);
  }

};


#endif
