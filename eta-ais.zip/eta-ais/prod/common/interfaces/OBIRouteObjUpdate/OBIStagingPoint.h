///////////////////////////////////////////////////////////////////////////////
/// @file      OBIStagingPoint.h
/// @author    J Struble
/// @date      2/13/2009
/// @brief     An x,y location and heading with a position and heading tolerance
///
/// @attention COPYRIGHT (C) 2008 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////
#ifndef  OBIStagingPoint_h
#define  OBIStagingPoint_h

#include <boost/operators.hpp>

#include "geometry/primitives/Point2D.h"
#include "geometry/primitives/Angle.h"
#include "ais/interfaces/traits/TextWritable.h"


struct OBIStagingPoint : boost::equality_comparable<OBIStagingPoint>, public TextWritable
{
public:
  nrec::geometry::Point2D_d   location;
  nrec::geometry::Angle_d     heading;
  double                      positionTolerance_m;
  nrec::geometry::Angle_d     headingTolerance;

  template <class Archive>
    void serialize(Archive &ar, unsigned int version)
  {
    ar & location & heading & positionTolerance_m & headingTolerance;
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief returns true if two staging points are equal
  /// @return true if two staging points are equal
  /// @param rhs the staging point to compare to this point
  ///////////////////////////////////////////////////////////////////////////////
  bool operator==(const OBIStagingPoint& rhs) const
  {
    return (this->location == rhs.location) && (this->heading.getRadians() == rhs.heading.getRadians()) &&
      (this->positionTolerance_m == rhs.positionTolerance_m) &&
      (this->headingTolerance.getRadians() == rhs.headingTolerance.getRadians());
  }

  void toStream(std::stringstream& out) const
  {
    out << "Location:" << location << "\n";
    out << " Heading:" << heading << "\n";
    out << " Pos Tol:" << positionTolerance_m << "\n";
    out << " Pos Tol:" << headingTolerance << "\n";
  }
};

#endif

