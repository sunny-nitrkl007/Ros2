///////////////////////////////////////////////////////////////////////////////
/// @file      MCMStatus.h
/// @author    jderence
/// @date      6/11/2008
/// @brief     Stucture of status message from MCM
///
///
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef _MCMStatus_h_
#define _MCMStatus_h_
#include <ais/interfaces/traits/csvable.h>
#include <interfaces/traits/Jsonable.h>
#include <ais/serialization/Datum.h>
#include <mcmInterpreter/McmDefinitions.h>
#include "BaseMachineFailureReasons.h"
#include "util/BasicDataWithStatusIndicator.h"


/// @brief Structure that is a complilation of the basic vehicle status from the MCM
class MCMStatusStorage : public csvable, public Jsonable
{
public:

   // Feature status enum
   typedef enum
   {
     FEATURE_STATUS_INACTIVE = 0,
     FEATURE_STATUS_ACTIVE,
     FEATURE_STATUS_UNKNOWN
   } FeatureStatusType;

  MCMStatusStorage()
  : m_mode(UNKNOWN_OP_MODE),
    m_curvature(0.0),
    m_estimatedSteeringAngle(0.0),
    m_leftFrontWheelSpeed(0.0),
    m_rightFrontWheelSpeed(0.0),
    m_leftRearWheelSpeed(0.0),
    m_rightRearWheelSpeed(0.0),
    m_leftFrontWheelSpeedOk(false),
    m_rightFrontWheelSpeedOk(false),
    m_leftRearWheelSpeedOk(false),
    m_rightRearWheelSpeedOk(false),

    m_GndSpeedTOS_legacy(0.0),  // this will be eliminated in a future release
    m_gndSpeedTOS(),            // this is the new groundSpeedTOS that has data status embeedded in it
    m_GndSpeedLeftAxle(0.0),
    m_GndSpeedRightAxle(0.0),
    m_GndSpeedEstAcc(0.0),
    m_GndSpeedEstDec(0.0),
    m_GndSpeedEstOk( false ),

    m_ProtocolVersion(0),
    m_MachineOwnership(0),

    m_MSVCab(MODE_SWITCH_UNAVAILABLE), m_MSVBmp(MODE_SWITCH_UNAVAILABLE),
    m_AStopStatus(0),

    m_steeringMode(),
    m_brakeMode(),
    m_transThrottleMode(),
    m_chassisMode(),

    m_BMOkToEnterAutoMode(0x03),
    m_BMOkToEnterManualMode(0x03),
    m_BMOkToContAutoOperation(0x03),
    m_BMTravelControlStatus(0x03),
    m_BMMachSteeringControlStatus(0x03),
    m_BMImplementControlStatus(0x03),

    m_truckParams(),

    m_frontLeftStrutPressure( 0.0),
    m_frontRightStrutPressure(0.0),
    m_frontStrutPressureDataStatus(0),
    m_rearLeftStrutPressure(  0.0),
    m_rearRightStrutPressure( 0.0),
    m_rearStrutPressureDataStatus(0),
    m_TotalOperatingHours(0.0),
    m_machineSerialNumber("        "),  // 8 spaces
    m_AbsStatus(FEATURE_STATUS_UNKNOWN), // set to invalid value per $159
    m_TcsStatus(FEATURE_STATUS_UNKNOWN), // set to invalid value per $159
    m_BMOkForAutoOperation(0),
    m_BMOkToEnterAutoNoRunMode(0),
    m_BMOkToEnterManualArmedMode(0),
    m_BMOkToEnterAutoArmedMode(0),
    m_topeStatus(TOPE_STATUS_UNKNOWN),
    m_throttleCmd(0.0),
    m_mcmStoppingReasons(0),
    m_mcmStoppingReasonUpdateTime(0.0)
  {
  };

  MCMStatusStorage(
      const int& mode,
      const double& k,
      const double& EstStrAng,
      const double& LFspeed,
      const double& RFspeed,
      const double& LRspeed,
      const double& RRspeed,
      const bool& LFspeedOk,
      const bool& RFspeedOk,
      const bool& LRspeedOk,
      const bool& RRspeedOk,
      const unsigned char& ver,
      const unsigned char& mo,
      const unsigned char& msvCab,
      const unsigned char& msvBmp,
      const unsigned char& AStop,
      const double& GSpdTOS_legacy,
      const double&  gndSpdTos,
      const double& GSpdLtAxle,
      const double& GSpdRtAxle,
      const double& GSpdEstAcc,
      const double& GSpdEstDec,
      const bool& GSpdEstOk,
      const SubsystemStatus& sMode,
      const SubsystemStatus& bMode,
      const SubsystemStatus& tMode,
      const SubsystemStatus& cMode,
      const unsigned char& EnterAutoMode,
      const unsigned char& EnterManualMode,
      const unsigned char& ContAutoOperation,
      const unsigned char& TravelCtrlStatus,
      const unsigned char& MachStrCtrlStatus,
      const unsigned char& ImplementCtrlStatus,
      const TruckBodyParameters& tParams,
      const double& LFpress,
      const double& RFpress,
      const unsigned int& fStrutPressStatus,
      const double& LRpress,
      const double& RRpress,
      const unsigned int& rStrutPressStatus,
      const double& TotOperatingHrs,
      const std::string& msn,
      const FeatureStatusType &abs,
      const FeatureStatusType &tcs,
      const unsigned char& AutoOperationStatus,
      const unsigned char& EnterAutoNoRunMode,
      const unsigned char& EnterManualArmedMode,
      const unsigned char& EnterAutoArmedMode,
      const TopeStatusEnum&  topeStatus,
      const double& throttleCmd,
      const unsigned_8& mcmStoppingReasons,
      const TimeStamp& mcmStoppingReasonUpdateTime
  )
  : m_mode(mode),
    m_curvature(k),
    m_estimatedSteeringAngle(EstStrAng),
    m_leftFrontWheelSpeed(LFspeed),
    m_rightFrontWheelSpeed(RFspeed),
    m_leftRearWheelSpeed(LRspeed),
    m_rightRearWheelSpeed(RRspeed),
    m_leftFrontWheelSpeedOk(LFspeedOk),
    m_rightFrontWheelSpeedOk(RFspeedOk),
    m_leftRearWheelSpeedOk(LRspeedOk),
    m_rightRearWheelSpeedOk(RRspeedOk),

    m_GndSpeedTOS_legacy(GSpdTOS_legacy),
    m_gndSpeedTOS(FMIDNR, gndSpdTos),
    m_GndSpeedLeftAxle(GSpdLtAxle),
    m_GndSpeedRightAxle(GSpdRtAxle),
    m_GndSpeedEstAcc(GSpdEstAcc),
    m_GndSpeedEstDec(GSpdEstDec),
    m_GndSpeedEstOk(GSpdEstOk),

    m_ProtocolVersion(ver),
    m_MachineOwnership(mo),

    m_MSVCab(msvCab), m_MSVBmp(msvBmp),
    m_AStopStatus(AStop),

    m_steeringMode(sMode),
    m_brakeMode(bMode),
    m_transThrottleMode(tMode),
    m_chassisMode(cMode),

    m_BMOkToEnterAutoMode(EnterAutoMode),
    m_BMOkToEnterManualMode(EnterManualMode),
    m_BMOkToContAutoOperation(ContAutoOperation),
    m_BMTravelControlStatus(TravelCtrlStatus),
    m_BMMachSteeringControlStatus(MachStrCtrlStatus),
    m_BMImplementControlStatus(ImplementCtrlStatus),

    m_truckParams(tParams),

    m_frontLeftStrutPressure( LFpress),
    m_frontRightStrutPressure(RFpress),
    m_frontStrutPressureDataStatus(fStrutPressStatus),
    m_rearLeftStrutPressure(  LRpress),
    m_rearRightStrutPressure( RRpress),
    m_rearStrutPressureDataStatus(rStrutPressStatus),
    m_TotalOperatingHours(TotOperatingHrs),
    m_machineSerialNumber(msn),
    m_AbsStatus(abs),
    m_TcsStatus(tcs),
    m_BMOkForAutoOperation(AutoOperationStatus),
    m_BMOkToEnterAutoNoRunMode(EnterAutoNoRunMode),
    m_BMOkToEnterManualArmedMode(EnterManualArmedMode),
    m_BMOkToEnterAutoArmedMode(EnterAutoArmedMode),
    m_topeStatus(topeStatus),
    m_throttleCmd(throttleCmd),
    m_mcmStoppingReasons(mcmStoppingReasons),
    m_mcmStoppingReasonUpdateTime(mcmStoppingReasonUpdateTime)
  {
  };

  // get/set mode
  void setMode(const int& m) {m_mode = m; };
  int getMode() const { return m_mode; };

  // get/set Curvature
  void setCurvature(const double& k) {m_curvature = k; };
  double getCurvature() const { return m_curvature; };

  // get/set Estimate Steering Angle
  void setEstSteerAngle(const double &EstStrAng) {m_estimatedSteeringAngle = EstStrAng; };
  double getEstSteerAngle() const { return m_estimatedSteeringAngle; };

  // get / set Ground Speed TOS Value
  void setGndSpeedTOS (const double &GSpdTOS) { m_gndSpeedTOS.value = GSpdTOS; };
  double getGndSpeedTOS () const { return m_gndSpeedTOS.value ; } ;

  // get / set Ground Speed Left Axle
  void setGndSpeedLeftAxle (const double &GSpdLtAxle) { m_GndSpeedLeftAxle = GSpdLtAxle; };
  double getGndSpeedLeftAxle () const { return m_GndSpeedLeftAxle ; } ;

  // get / set Ground Speed Right Axle
  void setGndSpeedRightAxle (const double &GSpdRtAxle) { m_GndSpeedRightAxle = GSpdRtAxle; };
  double getGndSpeedRightAxle () const { return m_GndSpeedRightAxle ; } ;

  // get / set Ground Speed Estimated during acceleration
  void setGndSpeedEstAcc (const double &GSpdEst) { m_GndSpeedEstAcc = GSpdEst; };
  double getGndSpeedEstAcc () const { return m_GndSpeedEstAcc ; } ;

  // get / set Ground Speed Estimated during deceleration
  void setGndSpeedEstDec (const double &GSpdEst) { m_GndSpeedEstDec = GSpdEst; };
  double getGndSpeedEstDec () const { return m_GndSpeedEstDec ; } ;

  // get Ground Speed Estimate (average of Acc and Dec)
  double getGndSpeedEst () const { return (m_GndSpeedEstAcc + m_GndSpeedEstDec)/2; } ;

  // get/set ground speed estimate is OK (not a DSI when received)
  void setGndSpeedEstOk( const bool &GSpdEstOk ) { m_GndSpeedEstOk = GSpdEstOk; };
  bool getGndSpeedEstOk () const { return m_GndSpeedEstOk; };

  // get/set left front wheel speed
  void setLeftFrontWheelSpeed(const double& s) { m_leftFrontWheelSpeed = s; };
  double getLeftFrontWheelSpeed() const  {return m_leftFrontWheelSpeed;};

  // get/set right front wheel speed
  void setRightFrontWheelSpeed(const double& s) { m_rightFrontWheelSpeed = s; };
  double getRightFrontWheelSpeed() const {return m_rightFrontWheelSpeed;};

  // get/set left rear wheel speed
  void setLeftRearWheelSpeed(const double& s) {m_leftRearWheelSpeed = s; };
  double getLeftRearWheelSpeed() const { return m_leftRearWheelSpeed; };

  // get/set right rear wheel speed
  void setRightRearWheelSpeed(const double& s) {m_rightRearWheelSpeed = s; };
  double getRightRearWheelSpeed() const { return m_rightRearWheelSpeed; };

  // get/set left front wheel speed
  void setLeftFrontWheelSpeedOk(const bool& ok) { m_leftFrontWheelSpeedOk = ok; };
  bool getLeftFrontWheelSpeedOk() const  {return m_leftFrontWheelSpeedOk;};

  // get/set right front wheel speed
  void setRightFrontWheelSpeedOk(const bool& ok) { m_rightFrontWheelSpeedOk = ok; };
  bool getRightFrontWheelSpeedOk() const  {return m_rightFrontWheelSpeedOk;};

  // get/set left rear wheel speed
  void setLeftRearWheelSpeedOk(const bool& ok) { m_leftRearWheelSpeedOk = ok; };
  bool getLeftRearWheelSpeedOk() const  {return m_leftRearWheelSpeedOk;};

  // get/set right rear wheel speed
  void setRightRearWheelSpeedOk(const bool& ok) { m_rightRearWheelSpeedOk = ok; };
  bool getRightRearWheelSpeedOk() const  {return m_rightRearWheelSpeedOk;};

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief This function calculates a speed estimate from available wheel speeds
  ///
  /// @param speedEstimate_mps(out) - speed estimate output
  /// @return - true if a speed could be calculated
  ///////////////////////////////////////////////////////////////////////////////
  bool getWheelSpeedEstimate(double& speedEstimate_mps) const
  {
    bool lfwsOk = getLeftFrontWheelSpeedOk();
    bool rfwsOk = getRightFrontWheelSpeedOk();
    bool lrwsOk = getLeftRearWheelSpeedOk();
    bool rrwsOk = getRightRearWheelSpeedOk();
    unsigned int numGoodWheelSpeeds = lfwsOk + rfwsOk + lrwsOk + rrwsOk;

    if( numGoodWheelSpeeds == 0 )
    {
      return false;
    }

    double signTOS = (getGndSpeedTOS() >= 0) ? (1.0) : (-1.0);
    double lfws = getLeftFrontWheelSpeed();
    double rfws = getRightFrontWheelSpeed();
    double lrws = getLeftRearWheelSpeed();
    double rrws = getRightRearWheelSpeed();

    // at least one wheel speed is good
    if(lrwsOk && rrwsOk)
    {
      // use average of rear wheel speeds
      speedEstimate_mps = signTOS * fabs((lrws + rrws) / 2.0);
    }
    else if(lfwsOk && rfwsOk)
    {
      // use average of front wheel speeds
      speedEstimate_mps = signTOS * fabs((lfws + rfws) / 2.0);
    }
    else
    {
      // use the average of any remaining good wheel speeds
      speedEstimate_mps = signTOS * fabs(
          ( (lfwsOk * lfws) + (rfwsOk * rfws) + (lrwsOk * lrws) + (rrwsOk * rrws) )
          / static_cast<double>(numGoodWheelSpeeds) );
    }

    return true;
  }

  // get/set protocol version
  void setProtocolVersion(const unsigned char& ver) { m_ProtocolVersion = ver; };
  unsigned char getProtocolVersion() const { return m_ProtocolVersion; };

  // get/set Cab Mode Switch Value
  void setMSVCab(const unsigned char& msvCab) { m_MSVCab = msvCab; };
  unsigned char getMSVcab() const { return m_MSVCab; };

  // get/set Bumper Mode Switch Value
  void setMSVBmp(const unsigned char& msvBmp) { m_MSVBmp = msvBmp; };
  unsigned char getMSVBmp() const { return m_MSVBmp; };

  // get/set A Stop Status
  void setAStopStatus(const unsigned char& AStop) { m_AStopStatus = AStop; };
  unsigned char getAStopStatus() const { return m_AStopStatus; };

  // get / set BM Ok To Enter Auto Mode.
  void setBMAutoMode(const unsigned char& EnterAutoMode) {m_BMOkToEnterAutoMode = EnterAutoMode;};
  unsigned char getBMAutoMode() const { return m_BMOkToEnterAutoMode; };

  // get / set BM Ok To Enter Manual Mode.
  void setBMManualMode(const unsigned char& EnterManualMode) {m_BMOkToEnterManualMode = EnterManualMode;};
  unsigned char getBMManualMode() const { return m_BMOkToEnterManualMode; };

  // get / set BM Ok To Continue Auto Mode.
  void setBMContAutoOperation(const unsigned char& ContAutoOperation) {m_BMOkToContAutoOperation = ContAutoOperation;};
  unsigned char getBMContAutoOperation() const { return m_BMOkToContAutoOperation; };

  // get / set BM Travel Control Status
  void setBMTravelCtrlStatus(const unsigned char& TravelCtrlStatus) {m_BMTravelControlStatus = TravelCtrlStatus;};
  unsigned char getBMTravelCtrlStatus() const { return m_BMTravelControlStatus; };

  // get / set BM Machine Steer Control Status
  void setBMMachSteerCtrlStatus(const unsigned char& MachStrCtrlStatus) {m_BMMachSteeringControlStatus = MachStrCtrlStatus;};
  unsigned char getBMMachSteerCtrlStatus() const { return m_BMMachSteeringControlStatus; };

  // get / set BM Implement Control Status
  void setBMImpCtrlStatus(const unsigned char& ImplementCtrlStatus) {m_BMImplementControlStatus = ImplementCtrlStatus;};
  unsigned char getBMImpCtrlStatus() const { return m_BMImplementControlStatus; };

  // get/set operating hours
  void setTotalOperatingHours(const double& t) { m_TotalOperatingHours = t; };
  double getTotalOperatingHours() const  {return m_TotalOperatingHours;};

  // get/set Machine Serial Number
  void setMachineSerialNumber(const std::string& msn) {m_machineSerialNumber = msn; };
  std::string getMachineSerialNumber() const  { return m_machineSerialNumber; };

  // get / set BM Ok for Autonomous operation.
  void setBMAutoOperationStatus(const unsigned char& AutoOperationStatus) {m_BMOkForAutoOperation = AutoOperationStatus;};
  unsigned char getBMAutoOperationStatus() const { return m_BMOkForAutoOperation; };

  // get / set BM Ok To Enter Auto Armed Mode.
  void setBMAutoArmedMode(const unsigned char& EnterAutoArmedMode) {m_BMOkToEnterAutoArmedMode = EnterAutoArmedMode;};
  unsigned char getBMAutoArmedMode() const { return m_BMOkToEnterAutoArmedMode; };

  // get / set BM Ok To Enter Auto No Run Mode.
  void setBMAutoNoRunMode(const unsigned char& EnterAutoNoRunMode) {m_BMOkToEnterAutoNoRunMode = EnterAutoNoRunMode;};
  unsigned char getBMAutoNoRunMode() const { return m_BMOkToEnterAutoNoRunMode; };

  // get / set BM Ok To Enter Manual Mode.
  void setBMManualArmedMode(const unsigned char& EnterManualArmedMode) {m_BMOkToEnterManualArmedMode = EnterManualArmedMode;};
  unsigned char getBMManualArmedMode() const { return m_BMOkToEnterManualArmedMode; };

  // get/set ABS status (set values per $159, get values per FeatureStatusType)
  void setABSStatus(const unsigned_8& status) { m_AbsStatus = status; };
  FeatureStatusType getABSStatus() const       
  {
     //    Valid Values:
     //    $00 = ABS Disabled
     //    $01 = ABS Enabled but Not Active
     //    $02 = ABS Enabled and Active
     //    $03 = Not Used
     //    $04 = Not Used
     //    $05 = Not Used
     //    $06 = ABS Feature Status is set to Error
     //    $07 = ABS Feature Status is set to Not available
     //    $08-DF = Not Used

     FeatureStatusType temp;
     switch( m_AbsStatus ) 
     {
     case 0x00:
     case 0x01:
     case 0x07:
        temp = FEATURE_STATUS_INACTIVE;
        break;

     case 0x02:
        temp = FEATURE_STATUS_ACTIVE;
        break;

     default:
        temp = FEATURE_STATUS_UNKNOWN;
        break;
     }

     return temp;
  };

  // get/set TCS status (set values per $159, get values per FeatureStatusType)
  void setTCSStatus(const unsigned_8& status) { m_TcsStatus = status; };
  FeatureStatusType getTCSStatus() const
  {
     //    Valid Values:
     //    $00 = TCS in OFF Mode
     //    $01 = TCS in Test Mode
     //    $02 = TCS in Normal or Aggressive Mode.
     //    $03 = Not Used
     //    $04 = Not Used
     //    $05 = Not Used
     //    $06 = TCS Feature Status is set to Error
     //    $07 = TCS Feature Status is set to Not available
     //    $08-DF = Not Used

     FeatureStatusType temp;
     switch( m_TcsStatus ) 
     {
     case 0x00:
     case 0x01:
     case 0x07:
        temp = FEATURE_STATUS_INACTIVE;
        break;

     case 0x02:
        temp = FEATURE_STATUS_ACTIVE;
        break;

     default:
        temp = FEATURE_STATUS_UNKNOWN;
        break;
     }

     return temp;
  };

  void setTopeStatus(const TopeStatusEnum& status) { m_topeStatus = status; };
  TopeStatusEnum getTopeStatus() const { return m_topeStatus; };

  // get / set Strut Pressures
  void setLeftFrontStrut (const double &LFpress) { m_frontLeftStrutPressure = LFpress; };
  double getLeftFrontStrut () const { return m_frontLeftStrutPressure ; } ;

  void setRightFrontStrut (const double &RFpress) { m_frontRightStrutPressure = RFpress; };
  double getRightFrontStrut () const { return m_frontRightStrutPressure ; } ;

  void setLeftRearStrut (const double &LRpress) { m_rearLeftStrutPressure = LRpress; };
  double getLeftRearStrut () const { return m_rearLeftStrutPressure ; } ;

  void setRightRearStrut (const double &RRpress) { m_rearRightStrutPressure = RRpress; };
  double getRightRearStrut () const { return m_rearRightStrutPressure ; } ;

  void setFrontStrutPressDataStatus (const unsigned int &fStrutPressStatus) { m_frontStrutPressureDataStatus = fStrutPressStatus; };
  unsigned int getFrontStrutPressDataStatus () const { return m_frontStrutPressureDataStatus ; } ;

  void setRearStrutPressDataStatus (const unsigned int &rStrutPressStatus) { m_rearStrutPressureDataStatus = rStrutPressStatus; };
  unsigned int getRearStrutPressDataStatus () const { return m_rearStrutPressureDataStatus ; } ;

  // Determine if vehicle is stopped based on TOS speed
  static constexpr double tosSpeedToleranceForStoppedVehicle = 0.2;
  bool isStopped() const
  {
    return fabs(getGndSpeedTOS()) < tosSpeedToleranceForStoppedVehicle;
  }

  // Get/Set Throttle command
  void setThrottleCmd(const double &throttleCmd) {m_throttleCmd = throttleCmd;};
  double getThrottleCmd() const {return m_throttleCmd;};

  void setMcmStoppingReasons(const unsigned_8 &mcmStoppingReasons) {m_mcmStoppingReasons = mcmStoppingReasons;};
  unsigned_8 getMcmStoppingReasons() const {return m_mcmStoppingReasons;};

  void setMcmStoppingReasonsUpdateTime(const TimeStamp &mcmStoppingReasonUpdateTime) {m_mcmStoppingReasonUpdateTime = mcmStoppingReasonUpdateTime;};
  TimeStamp getMcmStoppingReasonsUpdateTime() const {return m_mcmStoppingReasonUpdateTime;};

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Serialize function for MCMStatusStorage (use boost serialization)
  /// @param ar - archive to store serialization
  /// @param version - version of serialization
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    ar & m_mode;
    ar & m_curvature;
    ar & m_leftFrontWheelSpeed;
    ar & m_rightFrontWheelSpeed;
    ar & m_leftRearWheelSpeed;
    ar & m_rightRearWheelSpeed;

    // version 1
    if( version == 1 )
    {
      ar & m_ProtocolVersion;
      ar & m_MachineOwnership;

      ar & m_steeringMode;
      ar & m_brakeMode;
      ar & m_transThrottleMode;
      ar & m_chassisMode;

      ar & m_truckParams;

      ar & m_frontLeftStrutPressure;
      ar & m_frontRightStrutPressure;
      ar & m_rearLeftStrutPressure;
      ar & m_rearRightStrutPressure;
    }

    // version 2 and up
    if( version >= 2 )
    {
      ar & m_ProtocolVersion;

      ar & m_steeringMode;
      ar & m_brakeMode;
      ar & m_transThrottleMode;
      ar & m_chassisMode;

      ar & m_truckParams;

      ar & m_frontLeftStrutPressure;
      ar & m_frontRightStrutPressure;
      ar & m_rearLeftStrutPressure;
      ar & m_rearRightStrutPressure;

      ar & m_MSVCab;
      ar & m_MSVBmp;
      ar & m_AStopStatus;
    }
    if(version >= 3)
    {
       unsigned char tempOverallStatus;
       
       ar & m_estimatedSteeringAngle;
       ar & m_GndSpeedTOS_legacy;
       ar & m_GndSpeedLeftAxle;
       ar & m_GndSpeedRightAxle;
       ar & tempOverallStatus;
       ar & m_BMOkToEnterAutoMode;
       ar & m_BMOkToEnterManualMode;
       ar & m_BMOkToContAutoOperation;
       ar & m_BMTravelControlStatus;
       ar & m_BMMachSteeringControlStatus;
       ar & m_BMImplementControlStatus;
    }
    if(version >= 4)
    {
       ar & m_TotalOperatingHours;
    }
    if(version >= 5)
    {
       ar & m_machineSerialNumber;
    }
    if(version >= 6)
    {
       ar & m_AbsStatus;
       ar & m_TcsStatus;
    }
    if(version >= 7)
    {
      ar & m_bmFailureReasons;
    }
    if(version >= 8)
    {
       ar & m_BMOkForAutoOperation;
       ar & m_BMOkToEnterAutoNoRunMode;
       ar & m_BMOkToEnterManualArmedMode;
       ar & m_BMOkToEnterAutoArmedMode;
    }
    if(version >= 9)
    {
      ar & m_topeStatus;
    }
    if(version >= 10)
    {
      ar & m_GndSpeedEstAcc;
    }
    if(version >= 11)
    {
      ar & m_GndSpeedEstDec;
    }
    if(version >= 12)
    {
      ar & m_GndSpeedEstOk;
    }
    if(version >= 13)
    {
      ar & m_frontStrutPressureDataStatus & m_rearStrutPressureDataStatus;
    }

    if(version >= 14)
    {
      ar & m_throttleCmd;
    }

    if (version >= 15 )
    {
      ar & m_gndSpeedTOS;
    } else
    {
      m_gndSpeedTOS.value = m_GndSpeedTOS_legacy;
      m_gndSpeedTOS.status = 0;
    }

    if(version >= 16)
    {
      ar & m_mcmStoppingReasons;
    }

    if(version >= 17)
    {
      ar & m_mcmStoppingReasonUpdateTime;
    }

    if(version >= 18)
    {
      ar & m_leftFrontWheelSpeedOk;
      ar & m_rightFrontWheelSpeedOk;
      ar & m_leftRearWheelSpeedOk;
      ar & m_rightRearWheelSpeedOk;
    }

  };


  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Output data in CSV format
  /// @param out - out stream to dump data
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const
  {
    out("Mode",m_mode);
    out("Curvature",m_curvature);
    out("EstimatedSteeringAngle",m_estimatedSteeringAngle);
    out("LeftFrontWheelSpeed",m_leftFrontWheelSpeed);
    out("RightFrontWheelSpeed",m_rightFrontWheelSpeed);
    out("LeftRearWheelSpeed",m_leftRearWheelSpeed);
    out("RightRearWheelSpeed",m_rightRearWheelSpeed);

    out("ProtocolVersion",static_cast<int>(m_ProtocolVersion));
    out("MachineOwnership",static_cast<int>(m_MachineOwnership));
    out("Cab Switch Value",static_cast<int>(m_MSVCab));
    out("Bumper Switch Value",static_cast<int>(m_MSVBmp));
    out("m_AStopStatus",static_cast<int>(m_AStopStatus));

    // Current Speed
    out("Ground Speed TOS", m_gndSpeedTOS.value);
    out("Ground Speed Left Axle", m_GndSpeedLeftAxle);
    out("Ground Speed Right Axle", m_GndSpeedRightAxle);
    out("Ground Speed Estimated Acc", m_GndSpeedEstAcc);
    out("Ground Speed Estimated Dec", m_GndSpeedEstDec);
    out("Ground Speed Estimated Ok", m_GndSpeedEstOk);

    // steering
    out("steeringMode",m_steeringMode.mode);
    out("steeringComm",m_steeringMode.communicationOk);
    out("steeringAutoRdy",m_steeringMode.readyTransitionToAuto);
    out("steeringAutoEn",m_steeringMode.autonomousEnabled);
    out("steeringError",m_steeringMode.isError);

    // brake
    out("brakeMode",m_brakeMode.mode);
    out("brakeComm",m_brakeMode.communicationOk);
    out("brakeAutoRdy",m_brakeMode.readyTransitionToAuto);
    out("brakeAutoEn",m_brakeMode.autonomousEnabled);
    out("brakeError",m_brakeMode.isError);

    // transThrottle
    out("transThrottleMode",m_transThrottleMode.mode);
    out("transThrottleComm",m_transThrottleMode.communicationOk);
    out("transThrottleAutoRdy",m_transThrottleMode.readyTransitionToAuto);
    out("transThrottleAutoEn",m_transThrottleMode.autonomousEnabled);
    out("transThrottleError",m_transThrottleMode.isError);

    // chassis
    out("chassisMode",m_chassisMode.mode);
    out("chassisComm",m_chassisMode.communicationOk);
    out("chassisAutoRdy",m_chassisMode.readyTransitionToAuto);
    out("chassisAutoEn",m_chassisMode.autonomousEnabled);
    out("chassisError",m_chassisMode.isError);

    out("truckBodyState",m_truckParams.bodyState);
    out("bodyRaisePosition",m_truckParams.bodyRaisePosition);
    out("gearState",m_truckParams.gearState.value);
    out("engineRpm",m_truckParams.engineRpm);
    out("payloadInTons",m_truckParams.payloadInTons);
    out("truckPayload_tonnes",m_truckParams.truckPayload_tonnes);
    out("truckPayloadTargetWeight_tonnes",m_truckParams.truckPayloadTargetWeight_tonnes);
    // if we have a good status, then output whether the relay is On/Off
    if (m_truckParams.fireSupRelaySts.status == 0)
    {
      out("FireSupressionRelay", m_truckParams.fireSupRelaySts.value);
    } else // else output (0xE0 + dsi correspoding to the fault)
    {
      unsigned int output = UNKNOWN1U + m_truckParams.fireSupRelaySts.status;
      out("FireSupressionRelay", output);
    }
    out("FireSupressionStatus", static_cast<int> (m_truckParams.fireSupSts));
    out("EngineRunningStatus", static_cast<int> (m_truckParams.engRunSts));

    out("frontLeftStrutPressure",m_frontLeftStrutPressure);
    out("frontRightStrutPressure",m_frontRightStrutPressure);
    out("frontStrutPressureDataStatus", m_frontStrutPressureDataStatus);
    out("rearLeftStrutPressure",m_rearLeftStrutPressure);
    out("rearRightStrutPressure",m_rearRightStrutPressure);
    out("rearStrutPressureDataStatus", m_rearStrutPressureDataStatus);

    /* Base Machine Mode Status */
    out("BMOkToEnterAutoMode" , static_cast<int>(m_BMOkToEnterAutoMode));
    out("BMOkToEnterManualMode" , static_cast<int> (m_BMOkToEnterManualMode));
    out("BMOkToContAutoOperation", static_cast<int> (m_BMOkToContAutoOperation));
    out("BMTravelControlStatus" , static_cast<int> (m_BMTravelControlStatus));
    out("BMMachSteeringControlStatus",static_cast<int> (m_BMMachSteeringControlStatus));
    out("BMImplementControlStatus",static_cast<int> (m_BMImplementControlStatus));

    out("Total Op Hrs",m_TotalOperatingHours);
    out("MachineSerialNumber", m_machineSerialNumber);

    // Base Machine Feature status
    out("ABS Status", static_cast<int>(m_AbsStatus));
    out("TCS Status", static_cast<int>(m_TcsStatus));

    //Base Machine Failure Reasons
    m_bmFailureReasons.toCsv( out );

    out("BMOkForAutoOperation", static_cast<int>(m_BMOkForAutoOperation));
    out("BMOkToEnterAutoNoRunMode",static_cast<int>(m_BMOkToEnterAutoNoRunMode));
    out("BMOkToEnterManualArmedMode",static_cast<int>(m_BMOkToEnterManualArmedMode));
    out("BMOkToEnterAutoArmedMode",static_cast<int>(m_BMOkToEnterAutoArmedMode));
    out("TopeStatus",static_cast<int>(m_topeStatus));
    out("Throttle Cmd", m_throttleCmd);
    out("mcmStoppingReasons", static_cast<int>(m_mcmStoppingReasons));
    out("mcmStoppingReasonUpdateTime", m_mcmStoppingReasonUpdateTime.toDouble());
  };

  virtual void jsonSerialize( JsonIosAbstractBase& json )
  {
      json("Mode",m_mode);
      json("Curvature",m_curvature);
      json("EstimatedSteeringAngle",m_estimatedSteeringAngle);
      json("LeftFrontWheelSpeed", m_leftFrontWheelSpeed);
      json("RightFrontWheelSpeed", m_rightFrontWheelSpeed);
      json("LeftRearWheelSpeed", m_leftRearWheelSpeed);
      json("RightRearWheelSpeed", m_rightRearWheelSpeed);
      json("GroundSpeedTOS", m_gndSpeedTOS.value);
      json("TruckBodyState", m_truckParams.bodyState);
      json("BodyRaisePosition", m_truckParams.bodyRaisePosition);
      json("GearState", m_truckParams.gearState.value);
      json("EngineRpm",m_truckParams.engineRpm);
      json("TotalMachineWeight", m_truckParams.payloadInTons);
      json("Payload", m_truckParams.truckPayload_tonnes);
      json("TargetPayload", m_truckParams.truckPayloadTargetWeight_tonnes);
      json("FrontLeftStrutPressure", m_frontLeftStrutPressure);
      json("FrontRightStrutPressure", m_frontRightStrutPressure);
      json("RearLeftStrutPressure", m_rearLeftStrutPressure);
      json("RearRightStrutPressure", m_rearRightStrutPressure);
      json("TotalOperatingHours", m_TotalOperatingHours);
      json("MachineSerialNumber",  m_machineSerialNumber);
  }

//private:
  int m_mode;                      ///< Overall System Mode
  double m_curvature;              ///< Vehicle Curvature - 1/meters
  double m_estimatedSteeringAngle; ///< degree / bit
  double m_leftFrontWheelSpeed;    ///< Front Left Wheel Speed - meters/sec
  double m_rightFrontWheelSpeed;   ///< Front Right Wheel Speed - meters/sec
  double m_leftRearWheelSpeed;     ///< Rear Left Wheel Speed - meters/sec
  double m_rightRearWheelSpeed;    ///< Rear Right Wheel Speed - meters/sec
  bool m_leftFrontWheelSpeedOk;    ///< Front Left Wheel Speed Status
  bool m_rightFrontWheelSpeedOk;    ///< Front Right Wheel Speed Status
  bool m_leftRearWheelSpeedOk;    ///< Rear Left Wheel Speed Status
  bool m_rightRearWheelSpeedOk;    ///< Rear Right Wheel Speed Status

  double m_GndSpeedTOS_legacy;     // Will be removed in a future release
  // New groundSpeedTOS with data status included
  // if m_gndSpeedTos.status is zero, then m_gndSpeedTos.value is good
  // if m_gndSpeedTos.status is non zero, then m_gndSpeedTos.value should not be used
  BasicDataWithStatusIndicator<double> m_gndSpeedTOS;
  double m_GndSpeedLeftAxle;
  double m_GndSpeedRightAxle;
  double m_GndSpeedEstAcc;
  double m_GndSpeedEstDec;
  bool   m_GndSpeedEstOk;

  unsigned char m_ProtocolVersion; ///< Protocol version between MCM and autonomy layer

  /*
  // Machine Ownership info   (NOTE: This member is now obsolete)
  //
  // This parameter indicates whether the machine is assigned to a particular
  // user or not.
  //
  // Valid Values:
  //    0 = not assigned to a user
  //    1 =     assigned to a user
  */
  unsigned char m_MachineOwnership;

  enum modeSwitchEnum
  {
    MODE_SWITCH_MANUAL = 0,
    MODE_SWITCH_AUTO,
    MODE_SWITCH_ERROR,
    MODE_SWITCH_UNAVAILABLE
  };

  static std::string modeSwitchEnumToString(unsigned char switchState)
  {
    std::string tmpStr;
    switch(switchState)
    {
      case MODE_SWITCH_MANUAL:
        tmpStr = "Manual";
        break;
      case MODE_SWITCH_AUTO:
        tmpStr = "Auto";
        break;
      case MODE_SWITCH_ERROR:
        tmpStr = "Error";
        break;
      case MODE_SWITCH_UNAVAILABLE:
        tmpStr = "Unavailable";
        break;
      default:
        tmpStr = "Unavailable";
        break;
     }

    return tmpStr;
  }

  // Mode Switch Value
  unsigned char m_MSVCab;
  unsigned char m_MSVBmp;

  // A Stop
  unsigned char m_AStopStatus;

  //overall
  SubsystemStatus m_steeringMode;
  SubsystemStatus m_brakeMode;
  SubsystemStatus m_transThrottleMode;
  SubsystemStatus m_chassisMode;

  /*Base Machine Mode and Status */
  unsigned char  m_BMOkToEnterAutoMode;
  unsigned char  m_BMOkToEnterManualMode;
  unsigned char  m_BMOkToContAutoOperation;
  unsigned char  m_BMTravelControlStatus;
  unsigned char  m_BMMachSteeringControlStatus;
  unsigned char  m_BMImplementControlStatus;

  //TruckBodyParameters
  TruckBodyParameters m_truckParams;

  // Strut pressures (units are kPa)
  double m_frontLeftStrutPressure;
  double m_frontRightStrutPressure;
  unsigned int m_frontStrutPressureDataStatus;
  double m_rearLeftStrutPressure;
  double m_rearRightStrutPressure;
  unsigned int m_rearStrutPressureDataStatus;

  //Service Hour data
  double m_TotalOperatingHours;

  // Machine Serial Number
  std::string m_machineSerialNumber;

  unsigned_8 m_AbsStatus;        ///< ABS status (valid values per $159)
  unsigned_8 m_TcsStatus;        ///< TCS status (valid values per $159)

  // Base Machine Failure Reasons
  // (Used for mode change and assignment rejection)
  BaseMachineFailureReasons m_bmFailureReasons;
  unsigned char  m_BMOkForAutoOperation;
  unsigned char  m_BMOkToEnterAutoNoRunMode;
  unsigned char  m_BMOkToEnterManualArmedMode;
  unsigned char  m_BMOkToEnterAutoArmedMode;
  
  TopeStatusEnum m_topeStatus;
  
  // Throttle cmd from Speed Control in the MCM
  double	m_throttleCmd;

  unsigned_8 m_mcmStoppingReasons;
  TimeStamp m_mcmStoppingReasonUpdateTime;
};

typedef Datum<MCMStatusStorage> MCMStatus;

BOOST_CLASS_VERSION(MCMStatusStorage, 18)

#endif /* End of MCMStatus */

