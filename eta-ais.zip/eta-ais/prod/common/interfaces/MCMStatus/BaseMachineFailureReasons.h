#ifndef BASEMACHINEFAILUREREASONS_H_
#define BASEMACHINEFAILUREREASONS_H_

#include <ais/serialization/Datum.h> // For Boost serialization
#include <boost/serialization/set.hpp>
#include <set>
#include <std_types.h>

class BaseMachineFailureReasons: public csvable
{
  public:
    BaseMachineFailureReasons() { }
    ~BaseMachineFailureReasons() { }
    
    bool operator==( const BaseMachineFailureReasons& rhs ) const
    { 
      return ( (m_failureReasons == rhs.m_failureReasons) ); 
    }    
      
    enum FailureReasonType
    {
      ALL_CHECKS_OK = 0,
      PARK_BRAKE_NOT_APPLIED,
      SERVICE_BRAKE_PEDAL_PRESSED,
      SECONDARY_BRAKE_PEDAL_PRESSED,
      RETARDER_LEVER_ENGAGED,
      MACHINE_TOS_NONZERO,
      THROTTLE_PEDAL_PRESSED,
      SHIFT_LEVER_NOT_NEUTRAL,
      MACHINE_LOCKOUT_ACTIVE,
      HOIST_CONTROL_NOT_HOLD_OR_FLOAT,
      EVENT_DIAG_STOP_TRUCK,
      OPERATOR_LADDER_NOT_RAISED,
      BRAKE_ACCUMULATOR_NOT_CHARGED,
      ENGINE_NOT_RUNNING,
      REASON_NOT_AVAILABLE,
      SECONDARY_STEERING_TEST_IN_PROGRESS,
      STEERING_SOL_CAL_IN_PROGRESS,
      SECONDARY_STEERING_TEST_BYPASS_ACTIVE,
      TRANSMISSION_GEAR_NOT_NEUTRAL,
      CAB_MODE_SWITCH_USE_REQUIRED,
    };

    //A set doesn't allow duplicates
    std::set<unsigned_16>  m_failureReasons;
    typedef std::set<unsigned_16>::iterator failureIt;
    typedef std::set<unsigned_16>::const_iterator failureConstIt;

    void addFailureReason( unsigned_16 failureReason )
    {
      m_failureReasons.insert( failureReason );
    }

    bool allReasonsOk() const
    {
      if ( m_failureReasons.size() == 1 )
      {
        failureIt it = m_failureReasons.find( ALL_CHECKS_OK );
        if ( it != m_failureReasons.end() )
          return true;
      }
      return false;
    }    
    
    bool failureReasonActive( unsigned_16 failureReason ) const
    {
      return ( m_failureReasons.count( failureReason ) > 0 );
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Serialize function for MCMStatusStorage (use boost serialization)
    /// @param ar - archive to store serialization
    /// @param version - version of serialization
    ///////////////////////////////////////////////////////////////////////////////
    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
      ar & m_failureReasons;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Output data in CSV format
    /// @param out - out stream to dump data
    ///////////////////////////////////////////////////////////////////////////////
    void toCsv(CsvOutStream& out) const
    {
      out("NumFailureReasons", m_failureReasons.size());
      out("AllReasonsOk", allReasonsOk());
      unsigned_32 reasonMask = 0;
      for (failureIt it = m_failureReasons.begin(); it != m_failureReasons.end(); ++it)
      {
        if ( *it < 32 )
          reasonMask |= ( 0x0001 << *it );
      }
      out("FailureReasonMask", reasonMask);
    }

    std::string getFailureReasonString() const
    {
      std::string reasonList;
      if ( m_failureReasons.empty() )      
      {
        reasonList = "Failure Reasons Not Received";
      } else
      {
        for (failureIt it = m_failureReasons.begin(); it != m_failureReasons.end(); ++it)
        {
          if ( *it != 0 )
            reasonList = reasonList + ", ";
          reasonList = reasonList + getFailureReasonString(*it);
        }
      }
      return reasonList;
    }

    static std::string getFailureReasonString( const unsigned_16& failureReason )
    {
      switch ( failureReason )
      {
        case ALL_CHECKS_OK:                       return std::string("All Checks OK");
        case PARK_BRAKE_NOT_APPLIED:              return std::string("Park Brake Not Applied");
        case SERVICE_BRAKE_PEDAL_PRESSED:         return std::string("Service Brake Pedal Pressed");
        case SECONDARY_BRAKE_PEDAL_PRESSED:       return std::string("Secondary Brake Pedal Pressed");
        case RETARDER_LEVER_ENGAGED:              return std::string("Retarder Lever Engaged");
        case MACHINE_TOS_NONZERO:                 return std::string("Machine Speed Not Zero");
        case THROTTLE_PEDAL_PRESSED:              return std::string("Throttle Pedal Pressed");
        case SHIFT_LEVER_NOT_NEUTRAL:             return std::string("Shift Lever Not Neutral");
        case MACHINE_LOCKOUT_ACTIVE:              return std::string("Machine Lockout Active");
        case HOIST_CONTROL_NOT_HOLD_OR_FLOAT:     return std::string("Hoist Control Not Hold or Float");
        case EVENT_DIAG_STOP_TRUCK:               return std::string("Event or Diagnostic Stop Truck Active");
        case OPERATOR_LADDER_NOT_RAISED:          return std::string("Operator Ladder Not Raised");
        case BRAKE_ACCUMULATOR_NOT_CHARGED:       return std::string("Brake Accumulator Not Charged");
        case ENGINE_NOT_RUNNING:                  return std::string("Engine Not Running");
        case REASON_NOT_AVAILABLE:                return std::string("Reason Not Available");
        case SECONDARY_STEERING_TEST_IN_PROGRESS: return std::string("Secondary Steering Test In Progress");
        case STEERING_SOL_CAL_IN_PROGRESS:        return std::string("Steering Solenoid Cal In Progress");
        case TRANSMISSION_GEAR_NOT_NEUTRAL:       return std::string("Transmission Gear Not Neutral");
        case CAB_MODE_SWITCH_USE_REQUIRED:        return std::string("Cab Mode Switch Use Required to go to Manual");
      }
      return std::string("Reason Unknown");
    }

};


#endif /*BASEMACHINEFAILUREREASONS_H_*/
