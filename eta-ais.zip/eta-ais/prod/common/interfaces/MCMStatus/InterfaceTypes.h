#ifndef _MCMStatusInterfaceTypes_h_
#define _MCMStatusInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "MCMStatus.h"

typedef interfaces::baseTypes::InputInterface<MCMStatus> MCMStatusInput;
typedef interfaces::baseTypes::OutputInterface<MCMStatus> MCMStatusOutput;
typedef interfaces::baseTypes::InputInterface<MCMStatus> MCMStatusDeviceInput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<MCMStatusInput>()
  {
    return "MCMStatusInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<MCMStatusOutput>()
  {
    return "MCMStatusOutput";
  }
}

#endif
