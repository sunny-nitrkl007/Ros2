#ifndef _SubSystemHealthInterfaceTypes_h_
#define _SubSystemHealthInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "SubSystemHealth.h"

typedef interfaces::baseTypes::InputInterface<SubSystemHealth> SubSystemHealthInput;
typedef interfaces::baseTypes::OutputInterface<SubSystemHealth> SubSystemHealthOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<SubSystemHealthInput>()
  {
    return "SubSystemHealthInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<SubSystemHealthOutput>()
  {
    return "SubSystemHealthOutput";
  }
}

#endif
