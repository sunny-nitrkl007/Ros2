/*******************************************************************************
** @attention COPYRIGHT (C) 2008-2009 CATERPILLAR INC. ALL RIGHTS RESERVED.
**
** @file    SubSystemHealth.h
**
** @brief   This is the MCM interface for SubSystemHealth.
** @brief   autonomy ECMs.
*******************************************************************************/

#ifndef SubSystemHealth_h_
#define SubSystemHealth_h_

#include <ais/interfaces/traits/csvable.h>
#include <ais/serialization/Datum.h>
#include <mcmInterpreter/McmDefinitions.h>
#include <std_types.h>  /* for unsigned_16 etc */

class SubSystemHealthStorage : public csvable
{

public:

   SubSystemHealthStorage():
      m_PrimaryBrakeRecmdAction(0),
      m_SecondaryBrakeRecmdAction(0),
      m_BrakeChargingRecmdAction(0),
      m_MachineCoolingRecmdAction(0),
      m_RearAxleRecmdAction(0),
      m_HoistRecmdAction(0),
      m_TireMonitorRecmdAction(0),
      m_SteeringChargingRecmdAction(0),
      
      m_PrimarySteeringRecmdAction(0),
      m_SecondarySteeringRecmdAction(0),
      m_PrimaryPowerTrainRecmdAction(0),
      m_SecondaryPowerTrainRecmdAction(0),
      m_PrimaryEngineRecmdAction(0),
      m_SecondaryEngineRecmdAction(0),
      m_AutoLubeRecmdAction(0),
      m_PayloadRecmdAction(0),
      
      m_MachineCtrlRecmdAction(0),
      m_AstopRecmdAction(0),
      m_ElectRecmdAction(0),
      m_McmStoppingReasons(0),

      m_PositioningRecmdAction(0), 
      m_OffboardCommRecmdAction(0),
      m_PlanningRecmdAction(0),    
      m_ObjectDetectRecmdAction(0),
      m_OnboardCommRecmdAction(0) { };

   SubSystemHealthStorage(unsigned_8 &status_1,
                          unsigned_8 &status_2,
                          unsigned_8 &status_3,
                          unsigned_8 &status_4):

      m_PrimaryBrakeRecmdAction(status_1),
      m_SecondaryBrakeRecmdAction(status_1),
      m_BrakeChargingRecmdAction(status_1),
      m_MachineCoolingRecmdAction(status_1),
      m_RearAxleRecmdAction(status_1),
      m_HoistRecmdAction(status_1),
      m_TireMonitorRecmdAction(status_1),
      m_SteeringChargingRecmdAction(status_1),
      
      m_PrimarySteeringRecmdAction(status_2),
      m_SecondarySteeringRecmdAction(status_2),
      m_PrimaryPowerTrainRecmdAction(status_2),
      m_SecondaryPowerTrainRecmdAction(status_2),
      m_PrimaryEngineRecmdAction(status_2),
      m_SecondaryEngineRecmdAction(status_2),
      m_AutoLubeRecmdAction(status_2),
      m_PayloadRecmdAction(status_2),
      
      m_MachineCtrlRecmdAction(status_3), 
      m_AstopRecmdAction(status_3), 
      m_ElectRecmdAction(status_3), 
      m_McmStoppingReasons(status_3),

      m_PositioningRecmdAction(status_4),    
      m_OffboardCommRecmdAction(status_4),   
      m_PlanningRecmdAction(status_4),       
      m_ObjectDetectRecmdAction(status_4),   
      m_OnboardCommRecmdAction(status_4) { };

   // get/set functions - SubSystem Health Status 3
   void setMachineCtrlRecmdAction(const unsigned_8 &status_3) {m_MachineCtrlRecmdAction = status_3; };
   unsigned_8 getMachineCtrlRecmdAction() const { return m_MachineCtrlRecmdAction; };

   void setAstopRecmdAction(const unsigned_8 &status_3) {m_AstopRecmdAction = status_3; };
   unsigned_8 getAstopRecmdAction() const { return m_AstopRecmdAction; };
   
   void setElectRecmdAction(const unsigned_8 &status_3) {m_ElectRecmdAction = status_3; };
   unsigned_8 getElectRecmdAction() const { return m_ElectRecmdAction; };
 
   void setMcmStoppingReasons(const unsigned_8 &status_3) {m_McmStoppingReasons = status_3; };
   unsigned_8 getMcmStoppingReasons() const { return m_McmStoppingReasons; };

  // get/set functions - SubSystem Health Status 2
   void setPrimarySteeringRecmdAction(const unsigned_8 &status_2) {m_PrimarySteeringRecmdAction = status_2; };
   unsigned_8 getPrimarySteeringRecmdAction() const { return m_PrimarySteeringRecmdAction; };
   
   void setSecondarySteeringRecmdAction(const unsigned_8 &status_2) {m_SecondarySteeringRecmdAction = status_2; };
   unsigned_8 getSecondarySteeringRecmdAction() const { return m_SecondarySteeringRecmdAction; };
   
   void setPrimaryPowerTrainRecmdAction(const unsigned_8 &status_2) {m_PrimaryPowerTrainRecmdAction = status_2; };
   unsigned_8 getPrimaryPowerTrainRecmdAction() const { return m_PrimaryPowerTrainRecmdAction; };
   
   void setSecondaryPowerTrainRecmdAction(const unsigned_8 &status_2) {m_SecondaryPowerTrainRecmdAction = status_2; };
   unsigned_8 getSecondaryPowerTrainRecmdAction() const { return m_SecondaryPowerTrainRecmdAction; };
   
   void setPrimaryEngineRecmdAction(const unsigned_8 &status_2) {m_PrimaryEngineRecmdAction = status_2; };
   unsigned_8 getPrimaryEngineRecmdAction() const { return m_PrimaryEngineRecmdAction; };
   
   void setSecondaryEngineRecmdAction(const unsigned_8 &status_2) {m_SecondaryEngineRecmdAction = status_2; };
   unsigned_8 getSecondaryEngineRecmdAction() const { return m_SecondaryEngineRecmdAction; };
   
   void setAutoLubeRecmdAction(const unsigned_8 &status_2) {m_AutoLubeRecmdAction = status_2; };
   unsigned_8 getAutoLubeRecmdAction() const { return m_AutoLubeRecmdAction; };
   
   void setPayloadRecmdAction(const unsigned_8 &status_2) {m_PayloadRecmdAction = status_2; };
   unsigned_8 getPayloadRecmdAction() const { return m_PayloadRecmdAction; };
   
   // get/set functions - SubSystem Health Status 1
   void setPrimaryBrakeRecmdAction(const unsigned_8 &status_1) {m_PrimaryBrakeRecmdAction = status_1; };
   unsigned_8 getPrimaryBrakeRecmdAction() const { return m_PrimaryBrakeRecmdAction; };
   
   void setSecondaryBrakeRecmdAction(const unsigned_8 &status_1) {m_SecondaryBrakeRecmdAction = status_1; };
   unsigned_8 getSecondaryBrakeRecmdAction() const { return m_SecondaryBrakeRecmdAction; };
   
   void setBrakeChargingRecmdAction(const unsigned_8 &status_1) {m_BrakeChargingRecmdAction = status_1; };
   unsigned_8 getBrakeChargingRecmdAction() const { return m_BrakeChargingRecmdAction; };
   
   void setMachineCoolingRecmdAction(const unsigned_8 &status_1) {m_MachineCoolingRecmdAction = status_1; };
   unsigned_8 getMachineCoolingRecmdAction() const { return m_MachineCoolingRecmdAction; };
   
   void setRearAxleRecmdAction(const unsigned_8 &status_1) {m_RearAxleRecmdAction = status_1; };
   unsigned_8 getRearAxleRecmdAction() const { return m_RearAxleRecmdAction; };
   
   void setHoistRecmdAction(const unsigned_8 &status_1) {m_HoistRecmdAction = status_1; };
   unsigned_8 getHoistRecmdAction() const { return m_HoistRecmdAction; };
   
   void setTireMonitorRecmdAction(const unsigned_8 &status_1) {m_TireMonitorRecmdAction = status_1; };
   unsigned_8 getTireMonitorRecmdAction() const { return m_TireMonitorRecmdAction; };
   
   void setSteeringChargingRecmdAction(const unsigned_8 &status_1) {m_SteeringChargingRecmdAction = status_1; };
   unsigned_8 getSteeringChargingRecmdAction() const { return m_SteeringChargingRecmdAction; };

   // get/set functions - Auto SubSystem Health Status 4
   void setPositioningRecmdAction(const unsigned_8 &status_4) {m_PositioningRecmdAction = status_4; };
   unsigned_8 getPositioningRecmdAction() const { return m_PositioningRecmdAction; };

   void setOffboardCommRecmdAction(const unsigned_8 &status_4) {m_OffboardCommRecmdAction = status_4; };
   unsigned_8 getOffboardCommRecmdAction() const { return m_OffboardCommRecmdAction; };
   
   void setPlanningRecmdAction(const unsigned_8 &status_4) {m_PlanningRecmdAction = status_4; };
   unsigned_8 getPlanningRecmdAction() const { return m_PlanningRecmdAction; };
   
   void setObjectDetectRecmdAction(const unsigned_8 &status_4) {m_ObjectDetectRecmdAction = status_4; };
   unsigned_8 getObjectDetectRecmdAction() const { return m_ObjectDetectRecmdAction; };
   
   void setOnboardCommRecmdAction(const unsigned_8 &status_4) {m_OnboardCommRecmdAction = status_4; };
   unsigned_8 getOnboardCommRecmdAction() const { return m_OnboardCommRecmdAction; };

   ///////////////////////////////////////////////////////////////////////////////
   /// @brief Output data in CSV format
   /// @param out - out stream to dump data
   ///////////////////////////////////////////////////////////////////////////////
   void toCsv(CsvOutStream& out) const
   {
      /* Subsystem Health Status 1*/
      out("m_PrimaryBrakeRecmdAction",         static_cast<int>( m_PrimaryBrakeRecmdAction ));
      out("m_SecondaryBrakeRecmdAction",       static_cast<int>( m_SecondaryBrakeRecmdAction ));
      out("m_BrakeChargingRecmdAction",        static_cast<int>( m_BrakeChargingRecmdAction ));
      out("m_MachineCoolingRecmdAction",       static_cast<int>( m_MachineCoolingRecmdAction ));
      out("m_RearAxleRecmdAction",             static_cast<int>( m_RearAxleRecmdAction ));
      out("m_HoistRecmdAction",                static_cast<int>( m_HoistRecmdAction ));
      out("m_TireMonitorRecmdAction",          static_cast<int>( m_TireMonitorRecmdAction ));
      out("m_SteeringChargingRecmdAction",     static_cast<int>( m_SteeringChargingRecmdAction ));
      
      /* Subsystem Health Status 1*/
      out("m_PrimarySteeringRecmdAction",      static_cast<int>( m_PrimarySteeringRecmdAction ));
      out("m_SecondarySteeringRecmdAction",    static_cast<int>( m_SecondarySteeringRecmdAction ));
      out("m_PrimaryPowerTrainRecmdAction",    static_cast<int>( m_PrimaryPowerTrainRecmdAction ));
      out("m_SecondaryPowerTrainRecmdAction",  static_cast<int>( m_SecondaryPowerTrainRecmdAction ));
      out("m_PrimaryEngineRecmdAction",        static_cast<int>( m_PrimaryEngineRecmdAction ));
      out("m_SecondaryEngineRecmdAction",      static_cast<int>( m_SecondaryEngineRecmdAction ));
      out("m_AutoLubeRecmdAction",             static_cast<int>( m_AutoLubeRecmdAction ));
      out("m_PayloadRecmdAction",              static_cast<int>( m_PayloadRecmdAction ));
      
      /* Subsystem Health Status 3 */
      out("m_MachineCtrlRecmdAction",          static_cast<int>( m_MachineCtrlRecmdAction ));
      out("m_AstopRecmdAction",                static_cast<int>( m_AstopRecmdAction ));
      out("m_ElectRecmdAction",                static_cast<int>( m_ElectRecmdAction ));
      out("m_McmStoppingReasons",              static_cast<int>( m_McmStoppingReasons ));

      /* Autonomy Subsystem Health Status */
      out("m_PositioningRecmdAction",          static_cast<int>( m_PositioningRecmdAction ));
      out("m_OffboardCommRecmdAction",         static_cast<int>( m_OffboardCommRecmdAction ));
      out("m_PlanningRecmdAction",             static_cast<int>( m_PlanningRecmdAction ));
      out("m_ObjectDetectRecmdAction",         static_cast<int>( m_ObjectDetectRecmdAction ));
      out("m_OnboardCommRecmdAction",          static_cast<int>( m_OnboardCommRecmdAction ));
   }

private:

   ///////////////////////////////////////////////////////////////////////////////
   /// @brief Serialize function
   /// @param ar - archive to store serialization
   /// @param version - version of serialization
   ///////////////////////////////////////////////////////////////////////////////
   friend class boost::serialization::access;
   template <class Archive>
   void serialize(Archive &ar, unsigned int version)
   {
      /* Subsystem Health Status 1*/
      ar & m_PrimaryBrakeRecmdAction;
      ar & m_SecondaryBrakeRecmdAction;
      ar & m_BrakeChargingRecmdAction;
      ar & m_MachineCoolingRecmdAction;
      ar & m_RearAxleRecmdAction;
      ar & m_HoistRecmdAction;
      ar & m_TireMonitorRecmdAction;
      ar & m_SteeringChargingRecmdAction;
      
      /* Subsystem Health Status 2*/
      ar & m_PrimarySteeringRecmdAction;
      ar & m_SecondarySteeringRecmdAction;
      ar & m_PrimaryPowerTrainRecmdAction;
      ar & m_SecondaryPowerTrainRecmdAction;
      ar & m_PrimaryEngineRecmdAction;
      ar & m_SecondaryEngineRecmdAction;
      ar & m_AutoLubeRecmdAction;
      ar & m_PayloadRecmdAction;
      
      /* Subsystem Health Status 3*/
      ar & m_MachineCtrlRecmdAction;

      if (version >= 1 ) 
      {
         /* Autonomy Subsystem Health Status */
         ar & m_PositioningRecmdAction;  
         ar & m_OffboardCommRecmdAction; 
         ar & m_PlanningRecmdAction;     
         ar & m_ObjectDetectRecmdAction; 
         ar & m_OnboardCommRecmdAction;  
      }

      if (version >= 2 ) 
      {
         ar & m_AstopRecmdAction;
      }
      else
      {
         m_AstopRecmdAction = 0;
      }
      if (version >= 3 ) 
      {
         ar & m_ElectRecmdAction;
      }
      else
      {
         m_ElectRecmdAction = 0;
      }
      if (version >= 4 )
      {
         ar & m_McmStoppingReasons;
      }
      else
      {
        m_McmStoppingReasons = 0;
      }

   }
   
   /* 
   // The subsystem health recommended actions are all defined per the 
   // following. 
   //  
   // Data Range:      $00 to $DF
   // Data Status IDs: $E0-$FF
   // Valid Values:    
   //      $00 = No Recommended Action
   //      $01 = Failed but Functional, Continue Operation
   //      $02 = Failed and Non-Functional, Continue Operation
   //      $03 = Limit Machine Speed
   //      $04 = Stop Machine Safely
   //      $05 = Stop Machine Safely/Shutdown Engine
   //   $06-DF = Not Used 
   */ 

   /* Subsystem Health Status 1*/
   unsigned_8 m_PrimaryBrakeRecmdAction;
   unsigned_8 m_SecondaryBrakeRecmdAction;
   unsigned_8 m_BrakeChargingRecmdAction;
   unsigned_8 m_MachineCoolingRecmdAction;
   unsigned_8 m_RearAxleRecmdAction;
   unsigned_8 m_HoistRecmdAction;
   unsigned_8 m_TireMonitorRecmdAction;
   unsigned_8 m_SteeringChargingRecmdAction;

   /* Subsystem Health Status 2*/   
   unsigned_8 m_PrimarySteeringRecmdAction;
   unsigned_8 m_SecondarySteeringRecmdAction;
   unsigned_8 m_PrimaryPowerTrainRecmdAction;
   unsigned_8 m_SecondaryPowerTrainRecmdAction;
   unsigned_8 m_PrimaryEngineRecmdAction;
   unsigned_8 m_SecondaryEngineRecmdAction;
   unsigned_8 m_AutoLubeRecmdAction;
   unsigned_8 m_PayloadRecmdAction;

   /* Subsystem Health Status 3*/
   unsigned_8 m_MachineCtrlRecmdAction;
   unsigned_8 m_AstopRecmdAction;
   unsigned_8 m_ElectRecmdAction;
   unsigned_8 m_McmStoppingReasons;

   /* Autonomy Subsystem Health Status */
   unsigned_8 m_PositioningRecmdAction;  
   unsigned_8 m_OffboardCommRecmdAction; 
   unsigned_8 m_PlanningRecmdAction;     
   unsigned_8 m_ObjectDetectRecmdAction; 
   unsigned_8 m_OnboardCommRecmdAction;  
};

typedef Datum<SubSystemHealthStorage> SubSystemHealth;

BOOST_CLASS_VERSION(SubSystemHealthStorage, 4)

#endif /* End of SubSystemHealth_h_*/
