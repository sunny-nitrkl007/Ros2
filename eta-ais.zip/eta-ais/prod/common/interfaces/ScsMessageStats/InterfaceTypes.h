#ifndef _ScsMessageStatsInterfaceTypes_h_
#define _ScsMessageStatsInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "ScsMessageStats.h"

typedef interfaces::baseTypes::InputInterface<ScsMessageStats> ScsMessageStatsInput;
typedef interfaces::baseTypes::OutputInterface<ScsMessageStats> ScsMessageStatsOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<ScsMessageStatsInput>()
  {
    return "ScsMessageStatsInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<ScsMessageStatsOutput>()
  {
    return "ScsMessageStatsOutput";
  }
}

#endif
