///////////////////////////////////////////////////////////////////////////////
/// @file      ScsMessageStats.h
/// @author    J Struble
/// @date      7/28/2009
/// @brief     Interface to package and log Scs Message Statistics
///
///
/// @attention COPYRIGHT (C) 2015 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////
#ifndef SCSMESSAGESTATS_H_
#define SCSMESSAGESTATS_H_

#include "interfaces/SimpleCommsClientStatus/Type.h"
#include "ais/interfaces/traits/csvable.h"
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/vector.hpp>


//Non-intrusive serialization of the SimpleCommsClientStatus channel, since it does not implement
//the serialize method on it's own
namespace boost {
namespace serialization {

template<class Archive>
void serialize( Archive &ar, SimpleCommsClientStatus &t, unsigned int file_version )
{
    ar & t.transmissionTime & t.clientName & t.bytesSent & t.messagesSent & t.bytesRead & t.messagesRead & t.channelTraffic;
}

} // namespace serialization
} // namespace boost

class ScsMessageStatsStorage : public csvable
{
  public:
    ScsMessageStatsStorage():
      m_stats( )
    {}

    SimpleCommsClientStatus m_stats;

    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
      ar & m_stats;
    }

    void toCsv(CsvOutStream& out) const
    {
      m_stats.toCsv(out);
    }


};

BOOST_CLASS_VERSION(ScsMessageStatsStorage, 0);

typedef Datum<ScsMessageStatsStorage> ScsMessageStats;


#endif //SCSMESSAGESTATS_H_
