#ifndef _ExampleInterfaceTypes_h_
#define _ExampleInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "Type.h"

typedef interfaces::baseTypes::InputInterface<ExampleType> ExampleInput;
typedef interfaces::baseTypes::OutputInterface<ExampleType> ExampleOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<ExampleInput>()
  {
    return "ExampleInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<ExampleOutput>()
  {
    return "ExampleOutput";
  }
}

#endif
