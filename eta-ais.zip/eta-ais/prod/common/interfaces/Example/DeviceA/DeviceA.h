///////////////////////////////////////////////////////////////////////////////
/// @file      Example/DeviceA/DeviceA.h
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      May 16, 2008
/// @brief     Example interface, used for testing only.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef EXAMPLE_DEVICEA
#define EXAMPLE_DEVICEA

#include <interfaces/Example/Type.h>
#include <ais/interfaces/baseTypes/InputInterface.h>

class ExampleDeviceA: public interfaces::baseTypes::InputInterface<ExampleType>
{
public:
        ExampleDeviceA(ConfigSection &cs);
        virtual ~ExampleDeviceA();

        virtual bool initialize();
        virtual void cleanup();

        virtual bool get(ExampleType &val);
};

PluginInterfaceDbRegistration( Example.DeviceA, ExampleDeviceA )

#endif
