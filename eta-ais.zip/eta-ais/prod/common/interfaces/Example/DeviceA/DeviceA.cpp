///////////////////////////////////////////////////////////////////////////////
/// @file      ./Example/DeviceA/DeviceA.cc
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      May 16, 2008
/// @brief     Example interface.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#include "DeviceA.h"

ExampleDeviceA::ExampleDeviceA(ConfigSection &cs)
    : interfaces::baseTypes::InputInterface<ExampleType>(cs)
{
}

ExampleDeviceA::~ExampleDeviceA()
{
}

bool ExampleDeviceA::get(ExampleType &val)
{
    static ExampleType type;
    val = type;
    return true;
}

bool ExampleDeviceA::initialize()
{
    return true;
}

void ExampleDeviceA::cleanup()
{
}

