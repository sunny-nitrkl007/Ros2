///////////////////////////////////////////////////////////////////////////////
/// @file      Example/Type.h
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      May 16, 2008
/// @brief     A simple type for testing.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef EXAMPLE_TYPE_H
#define EXAMPLE_TYPE_H
#include <ais/interfaces/traits/csvable.h>

#include <ais/serialization/Datum.h>

class ExampleTypeStorage: public csvable
{
public:
    ExampleTypeStorage( ): example( -1 ) { }
    ExampleTypeStorage( int seed ): example( seed ) { }
    int example;
 
    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Output data in CSV format
    /// @param out - out stream to dump data
    ///////////////////////////////////////////////////////////////////////////////
    void toCsv(CsvOutStream& out) const
    {
    	out("example",example);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Serialize function for ExampleTypeStorage (use boost serialization)
    /// @param ar - archive to store serialization
    /// @param version - version of serialization
    ///////////////////////////////////////////////////////////////////////////////
    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
        ar & example;
    }


};

typedef Datum<ExampleTypeStorage> ExampleType;

#endif
