#ifndef _MCMVehicleCommandInterfaceTypes_h_
#define _MCMVehicleCommandInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "MCMVehicleCommand.h"

typedef interfaces::baseTypes::InputInterface<MCMVehicleCommand> McmVehicleCommandInput;
typedef interfaces::baseTypes::OutputInterface<MCMVehicleCommand> McmVehicleCommandOutput;
typedef interfaces::baseTypes::OutputInterface<MCMVehicleCommand> MCMVehicleCommandDeviceOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<McmVehicleCommandInput>()
  {
    return "McmVehicleCommandInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<McmVehicleCommandOutput>()
  {
    return "McmVehicleCommandOutput";
  }
}

#endif
