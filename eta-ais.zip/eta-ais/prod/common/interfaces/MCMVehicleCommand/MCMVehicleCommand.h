///////////////////////////////////////////////////////////////////////////////
/// @file      MCMVehicleCommand.h
/// @author    jderence
/// @date      5/29/2008
/// @brief     Driving command stucture to send to the MCM
///
/// 
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef MCMVehicleCommand_h
#define MCMVehicleCommand_h
#include "ais/interfaces/traits/csvable.h"
#include <ais/serialization/Datum.h>

/// @brief Structure of the command that the MCM requires to implement a driving command
class MCMVehicleCommandStorage : public csvable {
public:
  MCMVehicleCommandStorage(double velocity = 0.0, double acceleration = 0.0,
                           double deceleration = 0.0,double curvature = 0.0,
                           double rateOfK = 0.0, bool setParkingBrake = true,
                           char autoEnable = 0, char machineAction = 0):
    m_velocity(velocity),
    m_acceleration(acceleration),
    m_deceleration(deceleration),
    m_curvature(curvature),
    m_rateOfK(rateOfK),
    m_setParkingBrake(setParkingBrake), 
    m_autoEnable(autoEnable),
    m_machineAction(machineAction) {}

  // get/set Velocity
  void setVelocity(double v) {m_velocity = v;}
  double getVelocity() const {return m_velocity;}

  // get/set accel
  void setAcceleration(double a) {m_acceleration = a;}
  double getAcceleration() const {return m_acceleration;}

  // get/set Deceleration
  void setDeceleration(double d) {m_deceleration = d;}
  double getDeceleration() const {return m_deceleration;}

  // get/set Curvature
  void setCurvature(double k) {m_curvature = k;}
  double getCurvature() const {return m_curvature;}

  // get/set RateOfK
  void setRateOfK(double kdot) {m_rateOfK = kdot;}
  double getRateOfK() const {return m_rateOfK;}

  // get/set parkingbrake
  void setParkingBrakeState(bool brake) { m_setParkingBrake = brake;}
  bool getParkingBrakeState() const {return m_setParkingBrake;}

  // get/set AutoEnable
  void setAutoEnable(char autoEnable) { m_autoEnable = autoEnable;}
  char getAutoEnable() const {return m_autoEnable;}

  // get/set MachineAction
  void setMachineAction(char machineAction) { m_machineAction = machineAction;}
  char getMachineAction() const {return m_machineAction;}

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Serialize function for MCMVehicleCommandStorage (use boost serialization)
  /// @param ar - archive to store serialization
  /// @param version - version of serialization
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    ar & m_velocity;
    ar & m_acceleration;
    ar & m_deceleration;
    ar & m_curvature;
    ar & m_rateOfK;
    ar & m_setParkingBrake;

    if( version >= 1 ) 
    {
      ar & m_autoEnable;
      ar & m_machineAction;
    }
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Output data in CSV format
  /// @param out - out stream to dump data
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const 
  {
    out("Velocity", m_velocity);
    out("Acceleration", m_acceleration);
    out("Deceleration", m_deceleration);
    out("Curvature", m_curvature);
    out("RateOfK",m_rateOfK);
    out("ParkingBrake",m_setParkingBrake);

    out("autoEnable", static_cast<int>(m_autoEnable));
    out("machineAction", static_cast<int>(m_machineAction)); 
  }


private:
  double m_velocity;        ///< Desired Speed - meters/sec
  double m_acceleration;    ///< Desired Acceleration - meters/sec^2
  double m_deceleration;    ///< Desired Deceleration - meters/sec^2
  double m_curvature;       ///< Desired Curvature - 1/meters
  double m_rateOfK;         ///< Desired Rate of Curvature - degrees/sec
  bool   m_setParkingBrake; ///< Desired State of parking brake (true = engange, false = release)

  char m_autoEnable;
  char m_machineAction;

};

typedef Datum<MCMVehicleCommandStorage> MCMVehicleCommand;

BOOST_CLASS_VERSION(MCMVehicleCommandStorage, 1)

#endif
