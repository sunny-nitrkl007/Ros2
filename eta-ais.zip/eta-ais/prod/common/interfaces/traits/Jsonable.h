/////////////////////////////////////////////////////////////////	
/// @file      Jsonable.h
/// @author    J Struble
/// @date      Dec 10, 2015
/// @brief     A class trait with the purpose of returning a JSON
///            representation of the datum
///
/// @attention COPYRIGHT (C) 2015 CATERPILLAR INC. ALL RIGHTS RESERVED.
/////////////////////////////////////////////////////////////////
#ifndef JSONABLE_H_
#define JSONABLE_H_

#include <jhm2/jsonCommon/JsonIosBase.h>

class Jsonable
{
public:
  Jsonable() {}
  virtual ~Jsonable() {}

  virtual void jsonSerialize( JsonIosAbstractBase& json )=0;

};

#endif /* JSONABLE_H_ */
