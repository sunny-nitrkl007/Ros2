///////////////////////////////////////////////////////////////////////////////
/// @file      ApplanixConfigSettingsRequest.h
/// @author    jderence
/// @date      5/14/2010
/// @brief     Simple message to request Applanix Configuration Settings Report
///
/// @attention Copyright (C) 2010
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef ApplanixConfigSettingsRequest_h
#define ApplanixConfigSettingsRequest_h

#include <ais/serialization/Datum.h>
#include <ais/interfaces/traits/csvable.h>

struct ApplanixConfigSettingsRequestStorage
{
  ApplanixConfigSettingsRequestStorage() : m_source("") { };

  std::string m_source; ///< string denoting channel name of the source

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Function to serialize data
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version) {
        ar & m_source;
  };

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Output data in CSV format
  /// @param out - out stream to dump data
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const 
  {
    out("Source",m_source);
  }
};
typedef Datum<ApplanixConfigSettingsRequestStorage> ApplanixConfigSettingsRequest;
#endif
