#ifndef _ApplanixConfigSettingsRequestInterfaceTypes_h_
#define _ApplanixConfigSettingsRequestInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "ApplanixConfigSettingsRequest.h"

typedef interfaces::baseTypes::InputInterface<ApplanixConfigSettingsRequest> ApplanixConfigSettingsRequestInput;
typedef interfaces::baseTypes::OutputInterface<ApplanixConfigSettingsRequest> ApplanixConfigSettingsRequestOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<ApplanixConfigSettingsRequestInput>()
  {
    return "ApplanixConfigSettingsRequestInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<ApplanixConfigSettingsRequestOutput>()
  {
    return "ApplanixConfigSettingsRequestOutput";
  }
}

#endif
