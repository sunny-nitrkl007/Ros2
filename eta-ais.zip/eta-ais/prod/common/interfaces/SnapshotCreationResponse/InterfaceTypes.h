#ifndef _SnapshotCreationResponseInterfaceTypes_h_
#define _SnapshotCreationResponseInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "SnapshotCreationResponse.h"

typedef interfaces::baseTypes::InputInterface<SnapshotCreationResponse> SnapshotCreationResponseInput;
typedef interfaces::baseTypes::OutputInterface<SnapshotCreationResponse> SnapshotCreationResponseOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<SnapshotCreationResponseInput>()
  {
    return "SnapshotCreationResponseInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<SnapshotCreationResponseOutput>()
  {
    return "SnapshotCreationResponseOutput";
  }
}

#endif
