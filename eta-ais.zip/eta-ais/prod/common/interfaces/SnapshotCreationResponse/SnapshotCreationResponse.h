//////////////////////////////////////////////////////////////////////////////
/// @file      SnapshotCreationResponse.h
/// @author    dtascion
/// @date      10/18/2012
/// @brief     The snapshot bridge periodically publishes its state to the OCS.
///
/// 
///
/// @attention Copyright (C) 2012
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef SnapshotCreationResponse_h
#define SnapshotCreationResponse_h

#include <string>
#include <vector>
#include <boost/serialization/vector.hpp>
#include "ais/interfaces/traits/csvable.h"

///@brief Message from the ProductionLogger explaining if a snapshot was created
///       or not.
struct SnapshotCreationResponseStorage : public csvable
{
  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Constructor to initialize state of objects
  ///////////////////////////////////////////////////////////////////////////////
  SnapshotCreationResponseStorage() {}

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Status enumeration for the success or failure of this snapshot.
  /// Important to note about the time range partially out of bounds -- it tests
  /// against lower cases, but it also checks the maximum (high end of time) as
  /// well. This means that if data hasn't been written to disk for a bit, and
  /// you create a snapshot, you will most likely get a warning.
  ///////////////////////////////////////////////////////////////////////////////
  enum SnapshotCreationStatus {
     SNAPSHOT_STATUS_SUCCESS = 0,
     SNAPSHOT_STATUS_WARNING_TIME_RANGE_PARTIALLY_OUT_OF_BOUNDS,
     SNAPSHOT_STATUS_FAILURE_OUT_OF_SNAPSHOT_SPACE,
     SNAPSHOT_STATUS_FAILURE_TIME_RANGE_TOTALLY_OUT_OF_BOUNDS,
     SNAPSHOT_STATUS_FAILURE_DISK_ERROR
  };

  static std::string snapshotCreationStatusToString(const SnapshotCreationStatus status)
  {
    switch(status)
    {
      case SNAPSHOT_STATUS_SUCCESS:                                    return "Success"; break;
      case SNAPSHOT_STATUS_WARNING_TIME_RANGE_PARTIALLY_OUT_OF_BOUNDS: return "Supplied time range partially out of bounds"; break;
      case SNAPSHOT_STATUS_FAILURE_OUT_OF_SNAPSHOT_SPACE:              return "Out of disk space for snapshots"; break;
      case SNAPSHOT_STATUS_FAILURE_TIME_RANGE_TOTALLY_OUT_OF_BOUNDS:   return "Supplied time range totally out of bounds"; break;
      case SNAPSHOT_STATUS_FAILURE_DISK_ERROR:                         return "Cannot write, disk error or unmounted"; break;
      default:                                                         return "Unknown";
    }
  };

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Returns true if this was a success response, false otherwise.
  ///////////////////////////////////////////////////////////////////////////////
  bool isStatusSuccessful(SnapshotCreationStatus status) const
  {
      return (
               status == SNAPSHOT_STATUS_SUCCESS ||
               status == SNAPSHOT_STATUS_WARNING_TIME_RANGE_PARTIALLY_OUT_OF_BOUNDS
             );
  }

  std::string guid;                 ///< Globally unique identifier associated with this snapshot.
  SnapshotCreationStatus status;    ///< Status code from the enumeration above.
  long snapshotSpaceRemaining_mb;   ///< Amount of disk space for snapshots still available.

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Boost Serialization function for SnapshotCreationResponse
  /// @param ar - boost archive
  /// @param version - version of the class type 
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    ar & status;
    ar & snapshotSpaceRemaining_mb;

    if(version > 1)
    {
        ar & guid;
    }
  };

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Print SnapshotCreationResponse structure out in CSV format 
  /// @param out - output stream
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const
  {
  }
};

typedef Datum<SnapshotCreationResponseStorage> SnapshotCreationResponse;
BOOST_CLASS_VERSION(SnapshotCreationResponseStorage, 2)

#endif
