///////////////////////////////////////////////////////////////////////////////
/// @file      PerceptionExtrinsicsConfig.h
/// @author    bode
/// @date      4/11/2013
/// @brief     The config information about the perception transforms in the system
///
/// @attention Copyright (C) 2013
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef  PerceptionExtrinsicsConfig_h
#define  PerceptionExtrinsicsConfig_h

#include <vector>
#include <string>
#include <boost/serialization/vector.hpp>
#include "ais/log/Logger.h"
#include <ais/serialization/Datum.h>
#include "transformNetwork/frameConnection.h"
#include "ais/interfaces/traits/TextWritable.h"
#include "ais/time/ConvertTime.h"

namespace boost
{
  namespace serialization
  {
    /**
     * @brief Function to serialize frame connections
     */
    template<class Archive>
    void serialize(Archive &ar, FrameConnection& connection, unsigned int version)
    {
      ar & connection.srcFrame;
      ar & connection.destFrame;
      ar & connection.precomputations;
      ar & connection.transformEntries;
    }
  }
}

class PerceptionExtrinsicsConfigStorage: public TextWritable
{
public:

  std::vector<std::string> m_globalConstants;
  std::vector<FrameConnection> m_frameConnections;
  TimeStamp m_calibrationTimeStamp;
  std::string m_calibrationRobotName;
  std::string m_sensorConfigurationName;

  template<class Archive>
  void serialize(Archive & ar, const unsigned int version)
  {
    switch(version)
    {
      case 0:
      {
        ar & m_globalConstants;
        std::vector<std::string> connections;
        std::vector<std::string> srcFrames; //indexed by connection
        std::vector<std::string> destFrames; //indexed by connection
        std::vector<std::vector<std::string> > precomputations;  //indexed by connection
        std::vector<std::vector<std::string> > transformEntries; //indexed by connection
        ar & connections;
        ar & srcFrames;
        ar & destFrames;
        ar & precomputations;
        ar & transformEntries;
        for(unsigned int ci = 0; ci < connections.size(); ++ci)
        {
          FrameConnection fc;
          fc.srcFrame = srcFrames[ci];
          fc.destFrame = destFrames[ci];
          fc.precomputations = precomputations[ci];
          fc.transformEntries = transformEntries[ci];
          m_frameConnections.push_back(fc);
        }
        m_calibrationTimeStamp.fromDouble(0.0);
        m_calibrationRobotName = "UNKNOWN";
        m_sensorConfigurationName = "ALPHA";
        break;

      }
      case 1:
      {
        ar & m_globalConstants;
        ar & m_frameConnections;
        m_calibrationTimeStamp.fromDouble(0.0);
        m_calibrationRobotName = "UNKNOWN";
        m_sensorConfigurationName = "ALPHA";
        break;
      }
      case 2:
      {
        ar & m_globalConstants;
        ar & m_frameConnections;
        ar & m_calibrationTimeStamp;
        m_calibrationRobotName = "UNKNOWN";
        m_sensorConfigurationName = "ALPHA";
        break;
      }
      case 3:
      {
        ar & m_globalConstants;
        ar & m_frameConnections;
        ar & m_calibrationTimeStamp;
        ar & m_calibrationRobotName;
        ar & m_sensorConfigurationName;
        break;
      }
    default:
      {
        LOG_ERROR("Version %d not supported for type PerceptionExtrinsicsConfig", version);
        break;
      }
    }
  }

  virtual void toStream(std::stringstream& out) const
  {
    out << "Calibration Date: " << convertGPSToGMTString(m_calibrationTimeStamp) << " - " << m_calibrationTimeStamp << "\n";
    out << "Calibration Robot: " << m_calibrationRobotName << "\n";
    out << "Sensor Configuration: " << m_sensorConfigurationName << "\n";
    out << "Global Constants:\n";
    for(unsigned int gi = 0; gi < m_globalConstants.size(); ++gi)
    {
      out << m_globalConstants[gi] << "\n";
    }
    out << "\n";
    for(unsigned int ci = 0; ci < m_frameConnections.size(); ++ci)
    {
      const FrameConnection& connection = m_frameConnections[ci];
      out << "Connection[" << ci << "]:\n";
      out << " Source: " << connection.srcFrame << "\n";
      out << " Dest  : " << connection.destFrame << "\n";
      out << " Precomputations:\n";
      for(unsigned int pi = 0; pi < connection.precomputations.size(); ++pi)
      {
        out << "  [" << pi << "]:" << connection.precomputations[pi] << "\n";
      }
      out << "Transform Entries:\n";
      for(unsigned int ti = 0; ti < connection.transformEntries.size(); ++ti)
      {
        out << "  [" << ti << "]:" << connection.transformEntries[ti] << "\n";
      }
      out << "\n";
    }

  }
};

typedef Datum<PerceptionExtrinsicsConfigStorage> PerceptionExtrinsicsConfig;
BOOST_CLASS_VERSION(PerceptionExtrinsicsConfigStorage, 3);


#endif

