#ifndef _PerceptionExtrinsicsConfigInterfaceTypes_h_
#define _PerceptionExtrinsicsConfigInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "PerceptionExtrinsicsConfig.h"

typedef interfaces::baseTypes::InputInterface<PerceptionExtrinsicsConfig> PerceptionExtrinsicsConfigInput;
typedef interfaces::baseTypes::OutputInterface<PerceptionExtrinsicsConfig> PerceptionExtrinsicsConfigOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<PerceptionExtrinsicsConfigInput>()
  {
    return "PerceptionExtrinsicsConfigInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<PerceptionExtrinsicsConfigOutput>()
  {
    return "PerceptionExtrinsicsConfigOutput";
  }
}

#endif
