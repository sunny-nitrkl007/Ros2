#ifndef _TimeSyncStatisticsInterfaceTypes_h_
#define _TimeSyncStatisticsInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "TimeSyncStatistics.h"

typedef interfaces::baseTypes::InputInterface<TimeSyncStatistics> TimeSyncStatisticsInput;
typedef interfaces::baseTypes::OutputInterface<TimeSyncStatistics> TimeSyncStatisticsOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<TimeSyncStatisticsInput>()
  {
    return "TimeSyncStatisticsInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<TimeSyncStatisticsOutput>()
  {
    return "TimeSyncStatisticsOutput";
  }
}

#endif
