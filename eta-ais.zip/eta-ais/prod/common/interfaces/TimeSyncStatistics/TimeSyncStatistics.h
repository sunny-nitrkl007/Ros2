//////////////////////////////////////////////////////////////////////////////
/// @file      TimeSyncStatistics.h
/// @author    dtascion
/// @date      10/18/2012
/// @brief     The time sync objects periodically publishes its state.
///  Update:  Wrap the hub::timesync::statistics
/// 
///
/// @attention Copyright (C) 2012
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef TimeSyncStatistics_h
#define TimeSyncStatistics_h

#include <ais/serialization/Datum.h>
#include "ais/time/TimeStamp.h"
#include "ais/log/Logger.h"
#include <string>
#include "ais/interfaces/traits/csvable.h"
#include "hub/timesync/statistics.hh"
#include "hub/timesync/time_estimator.hh"


#include <boost/serialization/split_member.hpp>

struct HubTimeSyncTimeHistory
{

  hub::timesync::time_pair_list timePairs;

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Boost Serialization function for HubTimeClientStatsWrapper
  /// @param ar - boost archive
  /// @param version - version of the class type 
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    boost::serialization::split_member(ar, *this, version);
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Handles encoding a message.
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void save(Archive &ar, unsigned int version) const
  {
    // save the size of the list
    unsigned int count = timePairs.size();
    ar << count;

    // add each element's structure to the archive
    hub_const_iterate_over(iterator, timePairs, hub::timesync::time_pair_list)
    {
        const hub::timesync::time_pair &pair = *iterator;

        /// ARGH!  Need a split get / set serialize because the hub::timesync::monotonic timestamp doesn't have a serialize function
        double localTime = pair.local_timestamp.get_as_seconds() ;
        ar << localTime;

        double remoteTime = pair.remote_timestamp.get_as_seconds() ;
        ar << remoteTime;

        ar << pair.remote_latency;
    }
  };

    ///////////////////////////////////////////////////////////////////////////////
  /// @brief Handles decoding a message.
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void load(Archive &ar, unsigned int version)
  {
    timePairs.clear();  // clear out list

    // read in the size of the list
    unsigned int count; 
    ar >> count;

    // add each element's structure to the archive
    for (unsigned int ii = 0; ii < count; ++ii)
    {
      hub::timesync::time_pair pair;

      double localTime;
      ar >> localTime;
      pair.local_timestamp.set_as_seconds(localTime) ;

      double remoteTime;
      ar >> remoteTime;
      pair.remote_timestamp.set_as_seconds(remoteTime) ;

      ar >> (pair.remote_latency) ;

      timePairs.push_back( pair );
    }
  }

};


struct HubTimeClientStatsWrapper
{
  hub::timesync::time_client_statistics clientStatistics;

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Boost Serialization function for HubTimeClientStatsWrapper
  /// @param ar - boost archive
  /// @param version - version of the class type 
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    boost::serialization::split_member(ar, *this, version);
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Handles encoding a message.
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void save(Archive &ar, unsigned int version) const
  {
    // time_model_statistics
    ar << clientStatistics.time_model.raw_offset;
    ar << clientStatistics.time_model.remote_offset;
    ar << clientStatistics.time_model.drift;
    ar << clientStatistics.time_model.drift_standard_deviation ;
    ar << clientStatistics.time_model.model_certainty;
    ar << clientStatistics.time_model.model_error;
    ar << clientStatistics.time_model.model_age;
    ar << clientStatistics.time_model.synchronization_latency;
    ar << clientStatistics.time_model.synchronized;
    ar << clientStatistics.time_model.stratum;
    ar << clientStatistics.time_model.client_capabilities;

    //time_estimator_statistics
    ar << clientStatistics.time_estimator.oldest_time_pair_age;
    ar << clientStatistics.time_estimator.time_pair_count;
    ar << clientStatistics.time_estimator.local_clock_time_jumps;
    ar << clientStatistics.time_estimator.remote_clock_time_jumps;

    // network_statistics
    ar << clientStatistics.network_client.transmitted_udp_packets;
    ar << clientStatistics.network_client.received_udp_packets;
    ar << clientStatistics.network_client.dropped_udp_packets;
    ar << clientStatistics.network_client.missed_udp_packets;
    ar << clientStatistics.network_client.socket_initialization_attempts;
    ar << clientStatistics.network_client.socket_initialization_failures;

    // serial_irq_event_statistics
    ar << clientStatistics.pulse_client.received_pulse_events;
    ar << clientStatistics.pulse_client.missed_pulse_events;
    ar << clientStatistics.pulse_client.dropped_pulse_events;
    ar << clientStatistics.pulse_client.received_time_at_pulse_messages;
    ar << clientStatistics.pulse_client.missed_time_at_pulse_messages;
    ar << clientStatistics.pulse_client.dropped_time_at_pulse_messages;
    ar << clientStatistics.pulse_client.time_at_pulse_message_delay;
    ar << clientStatistics.pulse_client.hardware_uptime;

    /// ARGH!  Need a split get / set serialize because the hub::timesync::monotonic timestamp doesn't have a serialize function
    double latest_received_pulse_timestamp_seconds = clientStatistics.pulse_client.latest_received_pulse_timestamp.get_as_seconds();
    ar << latest_received_pulse_timestamp_seconds;


    ar << clientStatistics.pulse_client.device_initialization_attempts;
    ar << clientStatistics.pulse_client.device_initialization_failures;
    ar << clientStatistics.pulse_client.message_provider_initialization_attempts;
    ar << clientStatistics.pulse_client.message_provider_initialization_failures;

    // walltime_adjustment_statistics
    // we don't care about walltime_adjustment_statistics

    // model_output_statistics
    ar << clientStatistics.model_output.successful_model_update_count;
    ar << clientStatistics.model_output.failed_model_update_count;
  }


  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Handles decoding a message.
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void load(Archive &ar, unsigned int version)
  {
    // time_model_statistics
    ar >> clientStatistics.time_model.raw_offset;
    ar >> clientStatistics.time_model.remote_offset;
    ar >> clientStatistics.time_model.drift;
    ar >> clientStatistics.time_model.drift_standard_deviation ;
    ar >> clientStatistics.time_model.model_certainty;
    ar >> clientStatistics.time_model.model_error;
    ar >> clientStatistics.time_model.model_age;
    ar >> clientStatistics.time_model.synchronization_latency;
    ar >> clientStatistics.time_model.synchronized;
    ar >> clientStatistics.time_model.stratum;
    ar >> clientStatistics.time_model.client_capabilities;

    //time_estimator_statistics
    ar >> clientStatistics.time_estimator.oldest_time_pair_age;
    ar >> clientStatistics.time_estimator.time_pair_count;
    ar >> clientStatistics.time_estimator.local_clock_time_jumps;
    ar >> clientStatistics.time_estimator.remote_clock_time_jumps;

    // network_statistics
    ar >> clientStatistics.network_client.transmitted_udp_packets;
    ar >> clientStatistics.network_client.received_udp_packets;
    ar >> clientStatistics.network_client.dropped_udp_packets;
    ar >> clientStatistics.network_client.missed_udp_packets;
    ar >> clientStatistics.network_client.socket_initialization_attempts;
    ar >> clientStatistics.network_client.socket_initialization_failures;

    // serial_irq_event_statistics
    ar >> clientStatistics.pulse_client.received_pulse_events;
    ar >> clientStatistics.pulse_client.missed_pulse_events;
    ar >> clientStatistics.pulse_client.dropped_pulse_events;
    ar >> clientStatistics.pulse_client.received_time_at_pulse_messages;
    ar >> clientStatistics.pulse_client.missed_time_at_pulse_messages;
    ar >> clientStatistics.pulse_client.dropped_time_at_pulse_messages;
    ar >> clientStatistics.pulse_client.time_at_pulse_message_delay;
    ar >> clientStatistics.pulse_client.hardware_uptime;

    /// ARGH!  Need a split get / set serialize because the hub::timesync::monotonic timestamp doesn't have a serialize function
    double latest_received_pulse_timestamp_seconds = 0;
    ar >> latest_received_pulse_timestamp_seconds;
    clientStatistics.pulse_client.latest_received_pulse_timestamp.set_as_seconds(latest_received_pulse_timestamp_seconds);

    ar >> clientStatistics.pulse_client.device_initialization_attempts;
    ar >> clientStatistics.pulse_client.device_initialization_failures;
    ar >> clientStatistics.pulse_client.message_provider_initialization_attempts;
    ar >> clientStatistics.pulse_client.message_provider_initialization_failures;

    // walltime_adjustment_statistics
    // we don't care about walltime_adjustment_statistics

    // model_output_statistics
    ar >> clientStatistics.model_output.successful_model_update_count;
    ar >> clientStatistics.model_output.failed_model_update_count;
  }
};

struct HubTimeServerStatsWrapper
{
  hub::timesync::time_server_statistics serverStatistics;

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Boost Serialization function for HubTimeServerStatsWrapper
  /// @param ar - boost archive
  /// @param version - version of the class type 
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    // network_statistics
    ar & serverStatistics.network_server.transmitted_udp_packets;
    ar & serverStatistics.network_server.received_udp_packets;
    ar & serverStatistics.network_server.dropped_udp_packets;
    ar & serverStatistics.network_server.missed_udp_packets;
    ar & serverStatistics.network_server.socket_initialization_attempts;
    ar & serverStatistics.network_server.socket_initialization_failures;
    
  }
};

///@brief Status reporting from various TimeSync nodes.
struct TimeSyncStatisticsStorage : public csvable
{
  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Constructor to initialize state of objects
  ///////////////////////////////////////////////////////////////////////////////
  TimeSyncStatisticsStorage() {}

  enum TimeSyncType
  {
    TIME_SYNC_SERVICE,
    TIME_SYNC_SOURCE
  };

  /// Which node did this come from?
  std::string hostname;

  /// Type
  TimeSyncType type;

  /// Status, from TimeSyncSourceBase.h.
  unsigned int status;

  /// Current time estimate
  TimeStamp commonTime;

  /// Local time on the machine (non synchronized)
  TimeStamp localTime;

  //
  // Let's wrap the client and server statistics.
  //
  HubTimeClientStatsWrapper client;

  HubTimeServerStatsWrapper server;

  HubTimeSyncTimeHistory history;


  bool isSynchronized() const
  {
    return client.clientStatistics.time_model.synchronized;
  }

  bool isDirectlyHWSyncd() const
  {
    return (client.clientStatistics.time_model.stratum == hub::timesync::time_stratum_hardware);
  }

  bool isHWSyncd() const
  {
    return (client.clientStatistics.time_model.stratum <= hub::timesync::time_stratum_network_minimum);
  }
  

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Boost Serialization function for TimeSyncStatistics
  /// @param ar - boost archive
  /// @param version - version of the class type 
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    // local variables to help with the legacy member variables
    bool synchronized = false, hwSynchronized= false;
    double offset = 0, intercept = 0, drift = 0;
    unsigned int updateCount = 0, failureCount = 0;
    double initialUpdateTimeSeconds = 0,  lastUpdateTimeSeconds = 0;

    switch (version)
    {
    case 0:
      ar & hostname; 
      ar & type;
      ar & synchronized;
      ar & status;

      ar & commonTime;
      ar & localTime;

      ar & offset;
      ar & intercept;
      ar & drift;

      ar & updateCount;
      ar & failureCount;

      ar & initialUpdateTimeSeconds;
      ar & lastUpdateTimeSeconds;
      break;
    case 1:
      
      ar & hostname; 
      ar & type;
      ar & synchronized;
      ar & status;

      ar & commonTime;
      ar & localTime;

      ar & offset;
      ar & intercept;
      ar & drift;

      ar & updateCount;
      ar & failureCount;

      ar & initialUpdateTimeSeconds;
      ar & lastUpdateTimeSeconds;

       ar & hwSynchronized;
      break;
    case 2:
      ar & hostname; 
      ar & type;
      ar & status;
      ar & commonTime;
      ar & localTime;

      // time_model_statistics
      ar & client;
      ar & server;
      ar & history;

      break;
    default:
      LOG_FATAL("Cannot Serialize TimeSyncStatistics with version %d", version);
      break;
    }
  }; 

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Print TimeSyncStatistics structure out in CSV format 
  /// @param out - output stream
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const
  {
    out("Hostname", hostname);
    out("Status", status);

    out("CommonTime", commonTime);
    out("LocalTime", localTime);

    out("Offset", client.clientStatistics.time_model.raw_offset);
    out("Intercept", client.clientStatistics.time_model.remote_offset);
    out("Drift", client.clientStatistics.time_model.drift);

    out("UpdateCount", client.clientStatistics.model_output.successful_model_update_count);
    out("FailureCount", client.clientStatistics.model_output.failed_model_update_count);

    out("historyPairsCount", history.timePairs.size() );
    hub_const_iterate_over(iterator, history.timePairs, hub::timesync::time_pair_list)
    {
      const hub::timesync::time_pair &pair = *iterator;

      out( "pairs_localTime", pair.local_timestamp.get_as_seconds() );
      out( "pairs_remoteTime", pair.remote_timestamp.get_as_seconds() );
      out( "pairs_remote_latency", pair.remote_latency );
    }
  }
};

typedef Datum<TimeSyncStatisticsStorage> TimeSyncStatistics;
BOOST_CLASS_VERSION(TimeSyncStatisticsStorage, 2)

#endif
