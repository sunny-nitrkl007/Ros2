///////////////////////////////////////////////////////////////////////////////
/// @file      SpeedRegulationManager.h
/// @author    bode
/// @date      9/3/2009
/// @brief     Manages all the speed regulations that have been applied
///
/// 
///
/// @attention Copyright (C) 
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef SpeedRegulationManager_h
#define SpeedRegulationManager_h

#include <float.h>
#include "RegulateSpeed.h"

class SpeedRegulationManager
{
  public:

    typedef std::map<std::string, SpeedRegulationNumerics> Regulations;

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Check if regulations exist
    ///////////////////////////////////////////////////////////////////////////////
    bool regulationsExist() const {return !m_currentRegulations.empty();};

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief See if aggressive deceleration is violated based on speed only
    ///////////////////////////////////////////////////////////////////////////////
    bool isAggressiveDecelerationRegulationViolated(double speed) const
    {
      for(Regulations::const_iterator iter = begin(); iter != end(); ++iter)
      {
        if(iter->second.isAggressiveDeceleration() && iter->second.getSpeedLimit() < speed)
        {
          return true;
        }
      }
      return false;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get strictest regulation based on speed only and multiplied by derate percent
    ///////////////////////////////////////////////////////////////////////////////
    double getStrictestDeratedRegulation() const
    {
      double deratedValue = getStrictestRegulation()*(100.0 - getStrictestDeratePercent())/100.0;
      return deratedValue;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get strictest regulation based on speed only
    ///////////////////////////////////////////////////////////////////////////////
    double getStrictestRegulation() const
    {
      double strictestRegulation = DBL_MAX;
      for(Regulations::const_iterator iter = begin(); iter != end(); ++iter)
      {
        strictestRegulation = std::min(strictestRegulation, iter->second.getSpeedLimit());
      }
      return strictestRegulation;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get strictest regulation source based on speed only
    ///////////////////////////////////////////////////////////////////////////////
    std::string getStrictestRegulationSource() const
    {
      double strictestRegulation = DBL_MAX;
      std::string moduleName("Unknown");
      for(Regulations::const_iterator iter = begin(); iter != end(); ++iter)
      {
        if ( iter->second.getSpeedLimit() < strictestRegulation )
        {
          strictestRegulation = iter->second.getSpeedLimit();
          moduleName = iter->first;
        }
      }
      return moduleName;
    }   

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get strictest nominal regulation source based on speed only
    ///////////////////////////////////////////////////////////////////////////////
    double getStrictestNominalRegulation() const
    {
      double strictestRegulation = DBL_MAX;
      for(Regulations::const_iterator iter = begin(); iter != end(); ++iter)
      {
        if(iter->second.isNormalDeceleration())
        {
          strictestRegulation = std::min(strictestRegulation, iter->second.getSpeedLimit());
        }
      }
      return strictestRegulation;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get set of variable regulations (needed since deceleration rate must be determined)
    ///////////////////////////////////////////////////////////////////////////////
    Regulations getMediumRegulations() const
    {
      Regulations mediumRegulations;

      for(Regulations::const_iterator iter = begin(); iter != end(); ++iter)
      {
        if(iter->second.isMediumDeceleration())
        {
          mediumRegulations.insert(*iter);
          //mediumRegulations[iter->first] = iter->second;
        }
      }

      return mediumRegulations;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get strictest aggressive regulation source based on speed only
    ///////////////////////////////////////////////////////////////////////////////
    double getStrictestAggressiveRegulation() const
    {
      double strictestRegulation = DBL_MAX;
      for(Regulations::const_iterator iter = begin(); iter != end(); ++iter)
      {
        if(iter->second.isAggressiveDeceleration())
        {
          strictestRegulation = std::min(strictestRegulation, iter->second.getSpeedLimit());
        }
      }
      return strictestRegulation;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get strictest aggressive regulation source based on speed only
    ///////////////////////////////////////////////////////////////////////////////
    double getStrictestCriticalRegulation() const
    {
      double strictestRegulation = DBL_MAX;
      for(Regulations::const_iterator iter = begin(); iter != end(); ++iter)
      {
        if(iter->second.isCriticalDeceleration())
        {
          strictestRegulation = std::min(strictestRegulation, iter->second.getSpeedLimit());
        }
      }
      return strictestRegulation;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get strictest regulation based on derate only
    ///////////////////////////////////////////////////////////////////////////////
    double getStrictestDeratePercent() const
    {
      double strictestDerate = 0.0;
      for(Regulations::const_iterator iter = begin(); iter != end(); ++iter)
      {
        strictestDerate = std::max(strictestDerate, iter->second.getDeratePercent());
      }
      return strictestDerate;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Interpret new incoming message
    ///////////////////////////////////////////////////////////////////////////////
    void interpretNewRegulationMessage(const RegulateSpeed& newRegulation) 
    {
      if(newRegulation.isRegulationRemoval())
      {
        Regulations::iterator iter = m_currentRegulations.find(newRegulation.getRegulatingModuleName());
        if(iter != m_currentRegulations.end())
        {
          m_currentRegulations.erase(iter);
        }       
      }
      else
      {
        // add or replace the element in the map
        SpeedRegulationNumerics newReg = newRegulation.getSpeedRegulationNumerics();
        m_currentRegulations[newRegulation.getRegulatingModuleName()] = newReg;
      }      
    }

    Regulations::const_iterator begin() const {return m_currentRegulations.begin();} 
    Regulations::const_iterator end() const {return m_currentRegulations.end();} 

  private:
    friend class boost::serialization::access;

    Regulations m_currentRegulations;

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Original Regulation message from 2009 (Hukkeri: For log playback, change introduced on 12/19/2014, IM4.3)
    ///////////////////////////////////////////////////////////////////////////////
    struct Regulation
    {
        double speedLimit;
        double deratePercent;
        bool aggressiveDecel;

        template <class Archive>
        void serialize(Archive &ar, unsigned int version)
        {
            switch(version)
            {
              case 0:
              case 1:
              {
                ar & speedLimit & aggressiveDecel;
                deratePercent = 0.0;
                break;
              }
              case 2:
              {
                ar & speedLimit & deratePercent & aggressiveDecel;
                break;
              }
              default:
              {
                LOG_FATAL("Cannot Serialize SpeedRegulationManager::OldRegulation with version %d", version);
                break;
              }
            }
        }
    };

    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
        switch(version)
        {
          case 0:
          {
            typedef std::map<std::string, Regulation> OldRegulations;
            OldRegulations oldRegulations;

            ar & oldRegulations;

            //Copy oldRegulations into CurrentRegulations
            m_currentRegulations.clear();
            for(OldRegulations::const_iterator iter = oldRegulations.begin(); iter != oldRegulations.end(); ++iter)
            {
              SpeedRegulationNumerics::DecelerationType decelerationType =
                  iter->second.aggressiveDecel ? SpeedRegulationNumerics::AGGRESSIVE : SpeedRegulationNumerics::NOMINAL;

              SpeedRegulationNumerics numerics;
              numerics.setSpeedLimit(iter->second.speedLimit);
              numerics.setDeratePercent(iter->second.deratePercent);
              numerics.setDecelerationType(decelerationType);
              numerics.setDecelerationRate(0.6); //dummy value

              m_currentRegulations[iter->first] = numerics;
            }
            break;
          }
          case 1:
          {
            ar & m_currentRegulations;
            break;
          }
          default:
          {
            LOG_FATAL("Cannot Serialize SpeedRegulationManager::m_currentRegulations with version %d", version);
            break;
          }
        }

    }
};

BOOST_CLASS_VERSION(SpeedRegulationManager::Regulation, 2) //Hukkeri: Only needed for log playback (change introduced on 12/19/2014, IM4.3)
BOOST_CLASS_VERSION(SpeedRegulationManager, 1)

#endif
