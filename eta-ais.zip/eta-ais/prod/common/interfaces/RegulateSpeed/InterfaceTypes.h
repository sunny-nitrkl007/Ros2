#ifndef _RegulateSpeedInterfaceTypes_h_
#define _RegulateSpeedInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "RegulateSpeed.h"

typedef interfaces::baseTypes::InputInterface<RegulateSpeed> RegulateSpeedInput;
typedef interfaces::baseTypes::OutputInterface<RegulateSpeed> RegulateSpeedOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<RegulateSpeedInput>()
  {
    return "RegulateSpeedInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<RegulateSpeedOutput>()
  {
    return "RegulateSpeedOutput";
  }
}

#endif
