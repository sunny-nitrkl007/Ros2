///////////////////////////////////////////////////////////////////////////////
/// @file      RegulateSpeed.h
/// @author    bode
/// @date      9/3/2009
/// @brief     An interface to tell the planner to reduce speed
///
/// When the planning system receives a speed regulation it will limit the
/// velocity that is being commanded.  If multiple regulations are recieved
/// from the same module, newer regulations will replace older ones.
///
/// A regulation will remain in effect until it is removed by the module that
/// originally imposed it.
///
/// The regulated speed is the maximum velocity magnitude that the vehicle
/// will be allowed to command.  This regulation is in effect for both
/// forwards and reverse motion.
///
///
/// @attention Copyright (C)
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef RegulateSpeed_h
#define RegulateSpeed_h

#include <float.h>
#include "ais/util/stringUtils.h"
#include <ais/interfaces/traits/csvable.h>
#include <ais/serialization/Datum.h> // For Boost serialization
#include <ais/log/Logger.h>
#include <coreTechExtensions/serialize.h>
#include <ais/interfaces/traits/TextWritable.h>

static const double maximumSpeedRegulationValue = DBL_MAX;

class SpeedRegulationNumerics : public csvable, public TextWritable
{
  public:
    SpeedRegulationNumerics():
      speedLimit(maximumSpeedRegulationValue),
      deratePercent(0.0),
      decelerationType(NOMINAL),
      decelerationRate(0.6) { }

    enum DecelerationType
    {
      NOMINAL = 0,
      MEDIUM,
      AGGRESSIVE,
      CRITICAL //to request max possible braking
    };

    // Get methods
    double getSpeedLimit() const { return speedLimit; }
    double getDeratePercent() const { return deratePercent; }
    DecelerationType getDecelerationType() const { return decelerationType; }
    double getDecelerationRate() const { return decelerationRate; }

    bool isCriticalDeceleration() const { return decelerationType == CRITICAL; }
    bool isAggressiveDeceleration() const { return decelerationType == AGGRESSIVE; }
    bool isMediumDeceleration() const { return decelerationType == MEDIUM; }
    bool isNormalDeceleration() const { return decelerationType == NOMINAL; }

    static const double getMaximumSpeedRegulationValue() { return maximumSpeedRegulationValue; }

    // Set methods
    void setSpeedLimit(double v) { speedLimit = v; }
    void setDeratePercent(double p) { deratePercent = p; }
    void setDecelerationType(DecelerationType t) { decelerationType = t; }
    void setDecelerationRate(double r) { decelerationRate = r; }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get debug text
    ///////////////////////////////////////////////////////////////////////////////
    void getText(std::string& speedString, std::string& derateString, std::string& decelTypeString, std::string& decelRateString,
        unsigned int speedPrecision = 2, unsigned int deratePrecision = 2, unsigned int decelPrecision = 2) const
    {
      //Speed can be DBL_MAX when speed isn't limiting, but this is unusual text to display
      speedString = (getSpeedLimit() == maximumSpeedRegulationValue) ? "Inf" : stringUtils::typeToString(getSpeedLimit(), speedPrecision);

      //Derate string as a percent
      derateString = stringUtils::typeToString(getDeratePercent(), deratePrecision);

      //Deceleration type/rate should indicate the severity level, only display actual rate when medium type
      decelTypeString = "nom";
      decelRateString = "nom";
      if(getDecelerationType() == SpeedRegulationNumerics::MEDIUM)
      {
        decelTypeString = "med";
        decelRateString = stringUtils::typeToString(getDecelerationRate(),decelPrecision);
      }
      else if(getDecelerationType() == SpeedRegulationNumerics::AGGRESSIVE)
      {
        decelTypeString = "AGG";
        decelRateString = "AGG";
      }
      else if(getDecelerationType() == SpeedRegulationNumerics::CRITICAL)
      {
        decelTypeString = "CRI";
        decelRateString = "CRI";
      }
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Output data in CSV format
    /// @param out - out stream to dump data
    ///////////////////////////////////////////////////////////////////////////////
    void toCsv(CsvOutStream& out) const
    {
      out("RegulatedSpeedMagnitude", speedLimit);
      out("DerateRegulationPercent", deratePercent);
      out("DecelerationType", decelerationType);
      out("DecelerationRateIfMedium", decelerationRate);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Output data to stream
    /// @param out - out stream to dump data
    ///////////////////////////////////////////////////////////////////////////////
    void toStream(std::stringstream& out) const
    {
      std::string decelTypeString = "NOMINAL";
      if(decelerationType == MEDIUM)
      {
        decelTypeString = "MEDIUM";
      }
      else if(decelerationType == AGGRESSIVE)
      {
        decelTypeString = "AGGRESSIVE";
      } else if(decelerationType == CRITICAL)
      {
        decelTypeString = "CRITICAL";
      }
      out << "         Speed: " << speedLimit << "\n";
      out << "    Decel Type: " << decelTypeString << "\n";
      out << "    Decel Rate: " << decelerationRate << " m/s^2 (if variable only)" << "\n";
      out << "Derate Percent: " << deratePercent << "\n";
    }

  private:
    friend class boost::serialization::access;

    double speedLimit; ///< the maximum absolute value of speed that should be commanded
    double deratePercent; ///< 0 == no de-rate, 100 = full de-rate
    DecelerationType decelerationType; ///< the type of deceleration, nominal, aggressive, or inbetween (variable)
    double decelerationRate; ///< the deceleration rate desired if variable (otherwise it is ignored)

    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
        switch(version)
        {
          case 0:
          {
            ar & speedLimit & deratePercent & decelerationType & decelerationRate;

            break;
          }
          default:
          {
            LOG_FATAL("Cannot Serialize SpeedRegulationNumerics with version %d", version);
            break;
          }
        }
    }
};
BOOST_CLASS_VERSION(SpeedRegulationNumerics, 0);


class RegulateSpeedStorage : public csvable, public TextWritable
{
  public:
    RegulateSpeedStorage():
      m_regulationNumerics(),
      m_regulatingModuleName("Unknown") { }

    bool operator==(const RegulateSpeedStorage& rhs) const
    {
      return ( ( this->m_regulationNumerics.getSpeedLimit() == rhs.m_regulationNumerics.getSpeedLimit() ) &&
          ( this->m_regulationNumerics.getDeratePercent() == rhs.m_regulationNumerics.getDeratePercent() ) &&
          ( this->m_regulationNumerics.getDecelerationType() == rhs.m_regulationNumerics.getDecelerationType() ) &&
          ( this->m_regulationNumerics.getDecelerationRate() == rhs.m_regulationNumerics.getDecelerationRate() ) &&
          ( this->m_regulatingModuleName == rhs.m_regulatingModuleName ) );
    }

    void removeRegulation()
    {
      m_regulationNumerics.setSpeedLimit(maximumSpeedRegulationValue);
      m_regulationNumerics.setDeratePercent(0.0);
    }

    void setRegulatedSpeedMagnitude(double limit)
    {
      double speed = std::min(std::max(0.0,limit), maximumSpeedRegulationValue);
      m_regulationNumerics.setSpeedLimit(speed);
    }

    void setDeratePercentage(double limit)
    {
      double percent = std::min(std::max(0.0,limit),100.0);
      m_regulationNumerics.setDeratePercent(percent);
    }

    void setCriticalDeceleration()
    {
      m_regulationNumerics.setDecelerationType(SpeedRegulationNumerics::CRITICAL);
    }

    void setAggressiveDeceleration()
    {
      m_regulationNumerics.setDecelerationType(SpeedRegulationNumerics::AGGRESSIVE);
    }

    void setMediumDeceleration(double decel)
    {
      m_regulationNumerics.setDecelerationType(SpeedRegulationNumerics::MEDIUM);
      m_regulationNumerics.setDecelerationRate(decel);
    }

    void setNormalDeceleration()
    {
      m_regulationNumerics.setDecelerationType(SpeedRegulationNumerics::NOMINAL);
    }

    void setRegulatingModuleName(const std::string& regulatingModuleName)
    {
      m_regulatingModuleName = regulatingModuleName;
    }

    bool isSpeedRegulated() const
    {
      return m_regulationNumerics.getSpeedLimit() != maximumSpeedRegulationValue;
    }

    bool isDerateApplied() const
    {
      return m_regulationNumerics.getDeratePercent() != 0.0;
    }

    bool isRegulationRemoval() const
    {
      return !isSpeedRegulated() && !isDerateApplied();
    }

    double getRegulatedSpeedMagnitude() const
    {
      return m_regulationNumerics.getSpeedLimit();
    }

    double getDeratePercentage() const
    {
      return m_regulationNumerics.getDeratePercent();
    }

    bool isCriticalDeceleration() const
    {
      return m_regulationNumerics.getDecelerationType() == SpeedRegulationNumerics::CRITICAL;
    }

    bool isAggressiveDeceleration() const
    {
      return m_regulationNumerics.getDecelerationType() == SpeedRegulationNumerics::AGGRESSIVE;
    }

    bool isMediumDeceleration() const
    {
      return m_regulationNumerics.getDecelerationType() == SpeedRegulationNumerics::MEDIUM;
    }

    bool isNormalDeceleration() const
    {
      return m_regulationNumerics.getDecelerationType() == SpeedRegulationNumerics::NOMINAL;
    }

    SpeedRegulationNumerics::DecelerationType getDecelerationType() const
    {
      return m_regulationNumerics.getDecelerationType();
    }

    double getMediumDecelerationRate() const
    {
      return m_regulationNumerics.getDecelerationRate();
    }

    const std::string& getRegulatingModuleName() const
    {
      return m_regulatingModuleName;
    }

    const SpeedRegulationNumerics& getSpeedRegulationNumerics() const
    {
      return m_regulationNumerics;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Output data in CSV format
    /// @param out - out stream to dump data
    ///////////////////////////////////////////////////////////////////////////////
    void toCsv(CsvOutStream& out) const
    {
      out("RegulatingModuleName", m_regulatingModuleName);
      m_regulationNumerics.toCsv(out);
    }

    void toStream(std::stringstream& out) const
    {
      out << "  Regulated By: " << m_regulatingModuleName << "\n";
      m_regulationNumerics.toStream(out);
    }

  private:
    friend class boost::serialization::access;

    SpeedRegulationNumerics m_regulationNumerics;
    std::string m_regulatingModuleName; ///< the name of the module that is imposing the regulation

    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
        switch(version)
        {
          case 0:
          {
            double m_regulatedSpeedMagnitude(0); ///< the maximum absolute value of speed that should be commanded
            double m_derateRegulationPercent(0); ///< 0 == no de-rate, 100 = full de-rate
            bool m_aggressiveDeceleration(false);

            ar & m_regulatedSpeedMagnitude & m_aggressiveDeceleration & m_derateRegulationPercent & m_regulatingModuleName;

            SpeedRegulationNumerics::DecelerationType decelerationType =
                m_aggressiveDeceleration ? SpeedRegulationNumerics::AGGRESSIVE : SpeedRegulationNumerics::NOMINAL;

            m_regulationNumerics.setSpeedLimit(m_regulatedSpeedMagnitude);
            m_regulationNumerics.setDeratePercent(m_derateRegulationPercent);
            m_regulationNumerics.setDecelerationType(decelerationType);
            m_regulationNumerics.setDecelerationRate(0.6); //Dummy value
            break;
          }
          case 1:
          {
            ar & m_regulationNumerics & m_regulatingModuleName;

            break;
          }
          default:
          {
            LOG_FATAL("Cannot Serialize RegulateSpeedStorage with version %d", version);
            break;
          }
        }
    }

};

typedef Datum<RegulateSpeedStorage> RegulateSpeed;

BOOST_CLASS_VERSION(RegulateSpeedStorage, 1);

#endif
