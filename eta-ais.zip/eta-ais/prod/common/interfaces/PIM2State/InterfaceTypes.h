#ifndef _PIM2StateInterfaceTypes_h_
#define _PIM2StateInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "PIM2State.h"

typedef interfaces::baseTypes::InputInterface<PIM2State> PIM2StateInput;
typedef interfaces::baseTypes::OutputInterface<PIM2State> PIM2StateOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<PIM2StateInput>()
  {
    return "PIM2StateInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<PIM2StateOutput>()
  {
    return "PIM2StateOutput";
  }
}

#endif
