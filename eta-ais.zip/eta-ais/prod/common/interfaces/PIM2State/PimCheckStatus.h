///////////////////////////////////////////////////////////////////////////////
/// @file      PimCheckStatus.h
/// @author    J Struble
/// @date      2/28/2012
/// @brief     Status type for a PIM check
///
/// @attention COPYRIGHT (C) 2012 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////
#ifndef PIMCHECKSTATUS_H_
#define PIMCHECKSTATUS_H_

#include <util/undefXLib.h>

class PimCheckStatus
{
  public:
    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Constructor
    ///////////////////////////////////////////////////////////////////////////////  
    PimCheckStatus():
      m_status( FAULT ),
      m_inhibit( SEND_THIS_POSITION ),
      m_aggressive( true )
    { }
    ~PimCheckStatus() { }


    enum Status
    {
      NO_FAULT=0,
      FAULT,
      UNKNOWN,
      CHECK_DISABLED,
    };
    
    //These should be defined in increasing levels of bad.  Send is best, dead reckon is second best, inhibit is worst
    enum PositionInhibit
    {
      SEND_THIS_POSITION = 0,
      DEAD_RECKON_THIS_POSITION,
      INHIBIT_THIS_POSITION,
    };
  
    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Set the status
    ///
    /// @param stat - What to set it to
    ///////////////////////////////////////////////////////////////////////////////  
    void setStatus( const Status& stat ) { m_status = stat; }
    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get the status
    ///
    /// @return - What the current status is
    ///////////////////////////////////////////////////////////////////////////////    
    Status getStatus() const { return m_status; }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Set the position inhibit
    ///
    /// @param pi - What to set it to
    ///////////////////////////////////////////////////////////////////////////////
    void setPositionInhibit( const PositionInhibit& pi ) { m_inhibit = pi; }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get the position inhibit
    ///
    /// @return - What the current inhibit is
    ///////////////////////////////////////////////////////////////////////////////
    PositionInhibit getPositionInhibit() const { return m_inhibit; }    

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Is this check faulted (or unknown)
    ///
    /// @return - True if this check was faulted (or unknown
    ///////////////////////////////////////////////////////////////////////////////
    bool isFaulted() const
    {
      return ( ( m_status == FAULT ) || ( m_status == UNKNOWN ) );
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Is this check disabled
    ///
    /// @return - True if this check was disabled
    ///////////////////////////////////////////////////////////////////////////////
    bool isDisabled() const
    {
      return ( m_status == CHECK_DISABLED );
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get the status as a string
    ///
    /// @return - String status
    ///////////////////////////////////////////////////////////////////////////////
    std::string getStatusStr() const
    {
      switch (m_status)
      {
        case NO_FAULT: return "No Fault";
        case FAULT: return "FAULT";
        case UNKNOWN: return "Unknown";
        default: break;
      }
      return "UNKNOWN";
    } 

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get the position inhibit as a string
    ///
    /// @return - String inhibit
    ///////////////////////////////////////////////////////////////////////////////
    std::string getPosInhibitStr() const
    {
      switch (m_inhibit)
      {
        case SEND_THIS_POSITION: return "SendPos";
        case DEAD_RECKON_THIS_POSITION: return "DrPos";
        case INHIBIT_THIS_POSITION: return "InhibitPos";
        default: break;
      }
      return "UNKNOWN";
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Set the aggessive deceleration flag
    ///
    /// @param aggressive - What to set it to
    ///////////////////////////////////////////////////////////////////////////////
    void setAggressive( const bool& aggressive ) { m_aggressive = aggressive; }
    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Get the aggessive deceleration flag
    ///
    /// @return - What the flag is
    ///////////////////////////////////////////////////////////////////////////////
    bool isAggressive() const { return m_aggressive; }


    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
      ar & m_status & m_inhibit; 

      if( version >=1 )
      {
        ar & m_aggressive;
      }
    }
    
  private:
    Status          m_status;   //Current Status
    PositionInhibit m_inhibit;  //Current Inhibit
    bool            m_aggressive; // Whether or not an aggressive stop is required.
    
};

BOOST_CLASS_VERSION(PimCheckStatus, 1);

#endif /*PIMCHECKSTATUS_H_*/
