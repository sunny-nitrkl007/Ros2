///////////////////////////////////////////////////////////////////////////////
/// @file      PIM2State.h
/// @author    J Struble
/// @date      2/23/2012
/// @brief     Interface to send PIM Diagnostic Information
///
///
/// @attention COPYRIGHT (C) 2012 CATERPILLAR INC. ALL RIGHTS RESERVED.
///////////////////////////////////////////////////////////////////////////////
#ifndef PIM2STATE_H_
#define PIM2STATE_H_

#include <ais/serialization/Datum.h> // For Boost serialization
#include "ais/interfaces/traits/csvable.h"
#include "PimCheckStatus.h"
#include <ais/log/Logger.h>
#include <geometry/poses/Pose2D.h>
#include <coreTechExtensions/serialize.h>

class PIM2StateStorage : public csvable
{
  public:
    PIM2StateStorage():
      m_pimCheckStatus( ),
      m_aplxLastRxTime( 0 ),
      m_aplxSolutionLastRxTime( 0 ),
      m_bd960PriData( ),
      m_bd960SecData( ),
      m_gndSpeed_mps( 0 ),
      m_initialized( false ),
      m_initAccFailReason( 0 ),
      m_aplxNavState( NRS_IN_NAVIGATE ),
      m_navResetCount( 0 ),
      m_shiftDistance_m( 0 ),
      m_shiftThreshold_m( 0 ),
      m_longVelocity_mps( 0 ),
      m_laterVelocity_mps( 0 ),
      m_vertVelocity_mps( 0 ),
      m_maxVelocityReason( 0 ),
      m_residual( 0 ),
      m_wheelSlipActive( false ),
      m_leverArmOutOfTol( 0 ),
      m_bdToAplxAngle_deg( 0 ),
      m_bdHeading_deg( 0 ),
      m_attitudeValOverThresh( 0 ),
      m_antSeparationValue_m( 0 ),
      m_gamantSeparation_m( 0 ),
      m_antennaCheckBad( false ),
      m_pblCheckFailReason( 0 ),
      m_absImuUnavailableReason( 0 ),
      m_absImuYawRateBias( 0 ),
      m_absImuMovingAvgYawRate_degps( 0 ),
      m_applxMovingAvgYawRate_degps( 0 ),
      m_absImuToApplxYawRateDiff( 0 )
    {
    
    }

    //Overall status of the PIM checks
    typedef std::map<std::string, PimCheckStatus> PimStatusDb;
    PimStatusDb                 m_pimCheckStatus;

    //From ApplanixComms
    TimeStamp                   m_aplxLastRxTime;       // The Origination Time of the last Applanix State we got
    
    //From ApplanixSolutionAvailable
    TimeStamp                   m_aplxSolutionLastRxTime;       // The Origination Time of the last Applanix State we got



    //From Bd960ToApplanix Pos/Vel
    struct Bd960Data
    {
      Bd960Data(): m_lastRxTime(0), m_horDist_m(0), m_horThre_m(0), m_eleDist_m(0), m_eleThre_m(0) {}
      TimeStamp   m_lastRxTime;                        // The Transmission time of the last BD960Sec Message we got (From Bd960xxxComms)
      double      m_horDist_m;                         // Horizontal distance between the applanix and BD960 receiver
      double      m_horThre_m;                         // Horizontal dynamic threshold (3*rms + configured thresh)
      double      m_eleDist_m;                         // Elevation distance between the applanix and BD960 receiver
      double      m_eleThre_m;                         // Elevation threshold
      double      m_horVelDiff_mps;                    // Horizontal Velocity difference between Applanix and BD960
      double      m_verVelDiff_mps;                    // Vertical Velocity difference between Applanix and BD960
      bool        m_rmsBad;                            // RMS Greater than threshold
      bool        m_noPosition;                        // "No Position" reported
      bool        m_velocityNotValid;                  // Velocity not valid
      bool        m_modeNotRTK;                        // Mode is not RTK fixed or float
      nrec::geometry::Pose2D_d m_drPose;               // Dead Reckoned Pose 
      template <class Archive>
      void serialize(Archive &ar, unsigned int version)
      {
        switch (version)
        {
          case 0:
            ar & m_lastRxTime & m_horDist_m & m_horThre_m & m_eleDist_m & m_eleThre_m;
            ar & m_horVelDiff_mps & m_verVelDiff_mps & m_rmsBad & m_noPosition & m_velocityNotValid; 
          break;
          case 1:
            ar & m_lastRxTime & m_horDist_m & m_horThre_m & m_eleDist_m & m_eleThre_m;
            ar & m_horVelDiff_mps & m_verVelDiff_mps & m_rmsBad & m_noPosition & m_velocityNotValid;
            ar & m_drPose;
          break;
          case 2:
            ar & m_lastRxTime & m_horDist_m & m_horThre_m & m_eleDist_m & m_eleThre_m;
            ar & m_horVelDiff_mps & m_verVelDiff_mps & m_rmsBad & m_noPosition & m_velocityNotValid;
            ar & m_drPose & m_modeNotRTK;
          break;
          default:
            LOG_FATAL("Cannot Serialize PIM2State::Bd960Data with version %d", version);
            break;
        }
      }
      
      void toCsv(const std::string which, CsvOutStream& out) const
      {
        out( which+"LastRxTime", m_lastRxTime.toDouble() );
        out( which+"HorizDist", m_horDist_m );
        out( which+"HorizThresh", m_horThre_m );
        out( which+"ElevDist", m_eleDist_m );
        out( which+"ElevThresh", m_eleThre_m );
        out( which+"HorizVelDiff", m_horVelDiff_mps );
        out( which+"VertVelDiff", m_verVelDiff_mps );
        out( which+"RmsBad", m_rmsBad );
        out( which+"NoPosition", m_noPosition );
        out( which+"VelocityNotValid", m_velocityNotValid );
        out( which+"ModeNotRTK", m_modeNotRTK );
        out( which+"DrX", m_drPose.x() );
        out( which+"DrY", m_drPose.y() );        
        out( which+"DrHeading_deg", m_drPose.orientation().getDegrees() );
      }       
    };
    
    Bd960Data                   m_bd960PriData;
    Bd960Data                   m_bd960SecData;
    double                      m_gndSpeed_mps;         // TOS Ground speed used to disable multiple PIM checks
       
    //From InitialAccuracy    
    bool                        m_initialized;          // As determined by the initial accuracy check
    enum InitAccCheckFailReason
    {
      IACFR_APPLANIX_NOT_FIX_OR_FLOAT = 0,
      IACFR_BD9601_NOT_FIX,
      IACFG_APLX_TO_BD960_POS_HOR,
      IACFR_NAV_RESET_FAIL,
      IACFG_RESETTING_NAVIGATOR,
      IACFG_BD9601_NO_POSITION,
      IACFG_APLX_CONFIG_NOT_RECEIVED,
      IACFG_APLX_TO_BD960_POS_ELE,
      IACFR_BD960_TO_APLX_HEADING,
      IACFR_BD9602_NOT_FIX,
      IACFG_BD9602_NO_POSITION,
      IACFG_ABS_IMU_NOT_OK
    };    
    unsigned int                m_initAccFailReason;    // Masked Reason why the initial accuracy check has failed

    enum NavResetState
    {
      NRS_IN_NAVIGATE = 0,
      NRS_CMD_STANDBY,
      NRS_IN_STANDBY,
      NRS_CMD_NAVIGATE
    };
        
    NavResetState               m_aplxNavState;         // Current Commanded Navigation Mode to the Applanix
    unsigned int                m_navResetCount;        // Number of times a navigation reset has been attempted

    //From LowRms
    //(Nothing Here)               

    //From Max Pos Shift
    double                      m_shiftDistance_m;      // Distance this position has shifted from the last one
    double                      m_shiftThreshold_m;     // Current allowable shift
    
    //From Max Velocity
    double                      m_longVelocity_mps;     // Longitudinal Velocity
    double                      m_laterVelocity_mps;    // Lateral Velocity
    double                      m_vertVelocity_mps;     // Vertical Velocity
    
    enum MaxVelocityReasonMask
    {
      MVR_LONG_VEL_ERR = 0,
      MVR_LATER_VEL_ERR,
      MVR_VERT_VEL_ERR,  
    };       
    unsigned char               m_maxVelocityReason;

    //From NavigationAlg
    //(Nothing Here)

    //From PositionIntegrity
    double                      m_residual;             // As calculated by the position integrity check
    bool                        m_wheelSlipActive;      // Wheel slip has been above the threshold for the debounce time
    
    //From LeverArmVerify    
    enum LeverArmOutOfTol
    {
      REF_TO_IMU_VECTOR = 0,
      REF_TO_PRI_GNSS_VECTOR,
      IMU_WRT_REF_ANGLE,
      REF_WRT_VEH_ANGLE,
      GAMS_VECTOR,
      GAMS_ANT_SEPERATION,
      REF_TO_DMI_VECTOR,
      DMI_SCALE_FACTOR
    };
    
    unsigned int                m_leverArmOutOfTol;         //masked LeverArmOutOfTol reason saying which value set is out of tolerence           
    
    //From BD960 to Applanix Heading
    double                      m_bdToAplxAngle_deg;        //Difference between BD960 and Applanix Heading
    double                      m_bdHeading_deg;            //Heading computed from BD960s 
    
    //From MaxAttitudeRate
    enum AttitideOverThresh
    {
      DEB_ROLLRATE_BAD = 0,
      DEB_PITCHRATE_BAD,
      DEB_YAWRATE_BAD,
      DEB_YAWRATECALC_BAD,
      DEB_ROLL_BAD,
      DEB_PITCH_BAD,
      MAX_ROLLRATE_BAD,
      MAX_PITCHRATE_BAD,
      MAX_YAWRATE_BAD,
      MAX_YAWRATECALC_BAD,            
    };
    
    unsigned int                m_attitudeValOverThresh;    //masked LeverArmOutOfTol reason saying which value set is out of tolerence           
    
    //From AntennaSeparation
    double                      m_antSeparationValue_m;       //Calculated Antenna Separation value
    double                      m_gamantSeparation_m;         //Configured Antenna Separation value
    bool                        m_antennaCheckBad;            //Antenna Check status

    //From PBL Check
    enum PblCheckFailReason
    {
      PBL_TIMEOUT = 0,
      PBL_NOT_ACTIVE,
      PBL_APLX_NOT_OK,
      PBL_PBL_NOT_OK,
      PBL_HOR_ERROR_OVER_THRESH,
      PBL_HEADING_ERROR_OVER_THRESH,
      PBL_DISABLED,
    };
    unsigned int                m_pblCheckFailReason;             //masked PblCheckFailReason saying why the PBL check failed


    //From AbsImuUnavailable
    enum AbsImuUnavailReason
    {
      ABSIMU_NO_DATA_RECVD = 0,
      ABSIMU_NEWDATATIMEOUT,
      ABSIMU_FOMERROR,
      ABSIMU_MAXYAWRATE,
      ABSIMU_HIGHBIAS,
      ABSIMU_SPEEDESTIMATEERROR,
    };
    unsigned int                m_absImuUnavailableReason;        //masked AbsImuUnavailReason saying why its unavailable
    double                      m_absImuYawRateBias;              //computed bias from yaw rate while stopped

    //From AbsImuToApplxYawRate
    double m_absImuMovingAvgYawRate_degps;
    double m_applxMovingAvgYawRate_degps;
    double m_absImuToApplxYawRateDiff;

    PimCheckStatus getPimCheckStatus( const std::string& check ) const
    {
      PimStatusDb::const_iterator it;
      it = m_pimCheckStatus.find( check );
      if ( it == m_pimCheckStatus.end() )
      {
        PimCheckStatus unknownStatus;
        //Set the status to fault, if we don't have a check
        //that someone is looking for, this is bad.
        unknownStatus.setStatus( PimCheckStatus::FAULT );
        LOG_FATAL("PIM Check Status of %s does not exist.", check.c_str());
        return unknownStatus;
      }
      return it->second;
    }
    
    static bool pimChecksOk( const PimStatusDb& pimStatus )
    {
      bool checksOk = true;
      PimStatusDb::const_iterator it;
      for ( it = pimStatus.begin(); it != pimStatus.end(); ++it )
      {
        if ( it->second.isFaulted() )
          checksOk = false;
      }
      return checksOk;      
      
    }
    
    bool pimChecksOk() const
    {
      return pimChecksOk( m_pimCheckStatus );
    }

    bool pimOkToSendState() const
    {
      bool okToSend = true;
      PimStatusDb::const_iterator it;
      for ( it = m_pimCheckStatus.begin(); it != m_pimCheckStatus.end(); ++it )
      {
        if ( it->second.getPositionInhibit() != PimCheckStatus::SEND_THIS_POSITION )
          okToSend = false;
      }
      return okToSend;
    }

    PimCheckStatus::PositionInhibit getOverallPositionInhibit() const
    {
      PimCheckStatus::PositionInhibit posInh = PimCheckStatus::SEND_THIS_POSITION;
      PimStatusDb::const_iterator it;
      for ( it = m_pimCheckStatus.begin(); it != m_pimCheckStatus.end(); ++it )
      {
        if ( it->second.getPositionInhibit() > posInh )
          posInh = it->second.getPositionInhibit();
      }
      return posInh;
    }


    static bool useAggressiveDecel( const PimStatusDb& pimStatus )
    {
      bool aggressive = false;
      PimStatusDb::const_iterator it;
      for ( it = pimStatus.begin(); it != pimStatus.end(); ++it )
      {
        if ( it->second.isFaulted() && it->second.isAggressive() )
          aggressive = true;
      }
      return aggressive;

    }

    bool useAggressiveDecel() const
    {
      return useAggressiveDecel( m_pimCheckStatus );
    }

    static std::string navResetStateStr( const NavResetState& navRstState )
    {
      switch( navRstState )
      {
        case NRS_IN_NAVIGATE:
          return "Navigate";
        case NRS_CMD_STANDBY:
          return "CmdStandby";
        case NRS_IN_STANDBY:
          return "Standby";
        case NRS_CMD_NAVIGATE:
          return "CmdNavigate";
        default:
          break;
      }
      return "Unknown";
    }

    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
      unsigned char initAccFailReason_tmp=0;
      switch (version)
      {
        case 0:
          ar & m_pimCheckStatus & m_aplxLastRxTime; 
          ar & m_bd960PriData & m_bd960SecData & m_gndSpeed_mps;
          ar & m_initialized & initAccFailReason_tmp & m_aplxNavState & m_navResetCount;
          ar & m_shiftDistance_m & m_shiftThreshold_m;
          ar & m_longVelocity_mps & m_laterVelocity_mps & m_vertVelocity_mps & m_maxVelocityReason;
          ar & m_residual & m_wheelSlipActive;
          ar & m_leverArmOutOfTol;
          m_initAccFailReason = static_cast<unsigned int>(initAccFailReason_tmp);
          break;
        case 1:
          ar & m_pimCheckStatus & m_aplxLastRxTime; 
          ar & m_bd960PriData & m_bd960SecData & m_gndSpeed_mps;
          ar & m_initialized & initAccFailReason_tmp & m_aplxNavState & m_navResetCount;
          ar & m_shiftDistance_m & m_shiftThreshold_m;
          ar & m_longVelocity_mps & m_laterVelocity_mps & m_vertVelocity_mps & m_maxVelocityReason;
          ar & m_residual & m_wheelSlipActive;
          ar & m_leverArmOutOfTol;
          ar & m_bdToAplxAngle_deg & m_bdHeading_deg & m_attitudeValOverThresh;
          m_initAccFailReason = static_cast<unsigned int>(initAccFailReason_tmp);
          break;
        case 2:
          ar & m_pimCheckStatus & m_aplxLastRxTime;
          ar & m_bd960PriData & m_bd960SecData & m_gndSpeed_mps;
          ar & m_initialized & m_initAccFailReason & m_aplxNavState & m_navResetCount;
          ar & m_shiftDistance_m & m_shiftThreshold_m;
          ar & m_longVelocity_mps & m_laterVelocity_mps & m_vertVelocity_mps & m_maxVelocityReason;
          ar & m_residual & m_wheelSlipActive;
          ar & m_leverArmOutOfTol;
          ar & m_bdToAplxAngle_deg & m_bdHeading_deg & m_attitudeValOverThresh;      
          break;
        case 3:
          ar & m_pimCheckStatus & m_aplxLastRxTime;
          ar & m_bd960PriData & m_bd960SecData & m_gndSpeed_mps;
          ar & m_initialized & m_initAccFailReason & m_aplxNavState & m_navResetCount;
          ar & m_shiftDistance_m & m_shiftThreshold_m;
          ar & m_longVelocity_mps & m_laterVelocity_mps & m_vertVelocity_mps & m_maxVelocityReason;
          ar & m_residual & m_wheelSlipActive;
          ar & m_leverArmOutOfTol;
          ar & m_bdToAplxAngle_deg & m_bdHeading_deg & m_attitudeValOverThresh;
          ar & m_antSeparationValue_m & m_gamantSeparation_m & m_antennaCheckBad;
          break;
        case 4:
          ar & m_pimCheckStatus & m_aplxLastRxTime;
          ar & m_bd960PriData & m_bd960SecData & m_gndSpeed_mps;
          ar & m_initialized & m_initAccFailReason & m_aplxNavState & m_navResetCount;
          ar & m_shiftDistance_m & m_shiftThreshold_m;
          ar & m_longVelocity_mps & m_laterVelocity_mps & m_vertVelocity_mps & m_maxVelocityReason;
          ar & m_residual & m_wheelSlipActive;
          ar & m_leverArmOutOfTol;
          ar & m_bdToAplxAngle_deg & m_bdHeading_deg & m_attitudeValOverThresh;
          ar & m_antSeparationValue_m & m_gamantSeparation_m & m_antennaCheckBad;
          ar & m_pblCheckFailReason & m_absImuUnavailableReason & m_absImuYawRateBias;
          break;
        case 5:
          ar & m_pimCheckStatus & m_aplxLastRxTime;
          ar & m_bd960PriData & m_bd960SecData & m_gndSpeed_mps;
          ar & m_initialized & m_initAccFailReason & m_aplxNavState & m_navResetCount;
          ar & m_shiftDistance_m & m_shiftThreshold_m;
          ar & m_longVelocity_mps & m_laterVelocity_mps & m_vertVelocity_mps & m_maxVelocityReason;
          ar & m_residual & m_wheelSlipActive;
          ar & m_leverArmOutOfTol;
          ar & m_bdToAplxAngle_deg & m_bdHeading_deg & m_attitudeValOverThresh;
          ar & m_antSeparationValue_m & m_gamantSeparation_m & m_antennaCheckBad;
          ar & m_pblCheckFailReason & m_absImuUnavailableReason & m_absImuYawRateBias;
          ar & m_absImuMovingAvgYawRate_degps & m_applxMovingAvgYawRate_degps & m_absImuToApplxYawRateDiff;
          break;
        case 6:
          ar & m_pimCheckStatus & m_aplxLastRxTime;
          ar & m_bd960PriData & m_bd960SecData & m_gndSpeed_mps;
          ar & m_initialized & m_initAccFailReason & m_aplxNavState & m_navResetCount;
          ar & m_shiftDistance_m & m_shiftThreshold_m;
          ar & m_longVelocity_mps & m_laterVelocity_mps & m_vertVelocity_mps & m_maxVelocityReason;
          ar & m_residual & m_wheelSlipActive;
          ar & m_leverArmOutOfTol;
          ar & m_bdToAplxAngle_deg & m_bdHeading_deg & m_attitudeValOverThresh;
          ar & m_antSeparationValue_m & m_gamantSeparation_m & m_antennaCheckBad;
          ar & m_pblCheckFailReason & m_absImuUnavailableReason & m_absImuYawRateBias;
          ar & m_absImuMovingAvgYawRate_degps & m_applxMovingAvgYawRate_degps & m_absImuToApplxYawRateDiff;
          ar & m_aplxSolutionLastRxTime;
          break;
        default:
          LOG_FATAL("Cannot Serialize PIM2State with version %d", version);
          break;
      }
    }

    static void pimCheckStatus_toCsv( const PimStatusDb& stat, CsvOutStream& out )
    {
      PimStatusDb::const_iterator it;
      for ( it = stat.begin(); it != stat.end(); ++it )
      {       
        out( it->first+"Fault", static_cast<unsigned int>(it->second.getStatus()) );
        out( it->first+"Inhib", static_cast<unsigned int>(it->second.getPositionInhibit()) );  
      }
    }

    void toCsv(CsvOutStream& out) const
    {
      pimCheckStatus_toCsv( m_pimCheckStatus, out );
      out( "AplxLastRxTime", m_aplxLastRxTime.toDouble() );
      out( "AplxSolutionLastRxTime", m_aplxSolutionLastRxTime.toDouble() );
      m_bd960PriData.toCsv( "Pri", out );
      m_bd960SecData.toCsv( "Sec", out );
      out( "GroundSpeed", m_gndSpeed_mps );
      out( "Initialized", m_initialized );
      out( "InitialAccuracyFailReason", m_initAccFailReason );
      out( "AplxNavState", static_cast<unsigned int>( m_aplxNavState ) );
      out( "NavResetCount", m_navResetCount );
      out( "ShiftDistance", m_shiftDistance_m );
      out( "ShiftThreshold", m_shiftThreshold_m );
      out( "LongVelocity", m_longVelocity_mps );
      out( "LaterVelocity", m_laterVelocity_mps );
      out( "VertVelocity", m_vertVelocity_mps );
      out( "MaxVelocityReason", static_cast<unsigned int>( m_maxVelocityReason ) );
      out( "Residual", m_residual );
      out( "WheelSlipActive", m_wheelSlipActive );
      out( "LeverArmsOutOfTol", m_leverArmOutOfTol );
      out( "Bd960Heading", m_bdHeading_deg );
      out( "BdToAplxHeadingDiff", m_bdToAplxAngle_deg );
      out( "AttitudeValOverThresh", m_attitudeValOverThresh );
      out( "CurrentAntennaSeparation", m_antSeparationValue_m );
      out( "ConfiguredAntennaSeparation", m_gamantSeparation_m );
      out( "AntennaCheckFail", m_antennaCheckBad );
      out( "PBLFailReason", m_pblCheckFailReason );
      out( "AbsImuUnavailReason", m_absImuUnavailableReason );
      out( "AbsImuYawRateBias", m_absImuYawRateBias );
      out( "AbsImuMovingAvgYawRate_degps", m_absImuMovingAvgYawRate_degps );
      out( "ApplxMovingAvgYawRate_degps", m_applxMovingAvgYawRate_degps );
      out( "AbsImuToApplxYawRateDiff", m_absImuToApplxYawRateDiff );
    }

};

BOOST_CLASS_VERSION(PIM2StateStorage, 6);
BOOST_CLASS_VERSION(PIM2StateStorage::Bd960Data, 2);

typedef Datum<PIM2StateStorage> PIM2State;

#endif /*PIM2STATE_H_*/
