///////////////////////////////////////////////////////////////////////////////
/// @file      Wrapper.cpp
/// @author    Joseph Lisee <jlisee@nrec.ri.cmu.edu>
/// @date      Dec 16, 2013
/// @brief     Python wrapper for GPSTime
///
/// @attention Copyright (C) 2013
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////

// Project Includes
#include "interfaces/GPSTime/GPSTime.h"
#include <ais/serialization/python/SerializationUtil.h>

// Library Includes
#include <boost/python.hpp>

namespace py = boost::python;

BOOST_PYTHON_MODULE(_interface_GPSTime)
{
  py::enum_<GPSTimeStatus>("GPSTimeStatus")
    .value("GPS_TIME_STATUS_NOT_SYNCHRONIZED", GPS_TIME_STATUS_NOT_SYNCHRONIZED)
    .value("GPS_TIME_STATUS_SYNCHRONIZING", GPS_TIME_STATUS_SYNCHRONIZING)
    .value("GPS_TIME_STATUS_SYNCHRONIZED", GPS_TIME_STATUS_SYNCHRONIZED)
    .value("GPS_TIME_STATUS_USING_OLD_MODEL", GPS_TIME_STATUS_USING_OLD_MODEL)
    ;

  py::class_<GPSTime>("GPSTime")
    .def_readwrite("m_timeStamp", &GPSTime::m_timeStamp)
    .def_readwrite("m_PPSCount", &GPSTime::m_PPSCount)
    .def_readwrite("m_TimeSyncStatus", &GPSTime::m_TimeSyncStatus)

    NREC_BP_DATUM_REGISTER(GPSTime)
    ;
}
