///////////////////////////////////////////////////////////////////////////////
/// @file      GPSTime.h
/// @author    jderence
/// @date      2/5/2009
/// @brief     
///
/// 
///
/// @attention Copyright (C) 2009
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef _GPSTime_h_
#define _GPSTime_h_
#include <ais/interfaces/traits/csvable.h>
#include <ais/time/TimeStamp.h>
#include <ais/serialization/Datum.h>  // to allow type to be Datum<type>

enum GPSTimeStatus
{
  GPS_TIME_STATUS_NOT_SYNCHRONIZED = 0,
  GPS_TIME_STATUS_SYNCHRONIZING = 1,
  GPS_TIME_STATUS_SYNCHRONIZED = 2,
  GPS_TIME_STATUS_USING_OLD_MODEL = 3
};

struct GPSTimeStorage : public csvable
{
  TimeStamp m_timeStamp; ///< Time of the PPS from the primary GPS receiver
  unsigned long  m_PPSCount; ///< Number of PPS messages since power up and
                             /// initialization of GPS recievers
  unsigned short m_TimeSyncStatus; ///< Status of POS LV sync to the PPS time
                                   /// 0 - not synchronized
                                   /// 1 - Synchronizing
                                   /// 2 - fully synced
                                   /// 3 - using old offset

  /////////////////////////////////////////////////////////////////////////////
  /// @brief Print structure out in CSV format 
  /// @param out - output stream
  /////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream & out) const
  {
    // Timestamp (in seconds)
    out("PPSTimestamp", m_timeStamp.toDouble()); 
    out("PPSCount", m_PPSCount);
    out("SyncStatus", m_TimeSyncStatus);      
  }

  /////////////////////////////////////////////////////////////////////////////
  /// @brief Boost Serialization function 
  /// @param ar 
  /// @param version 
  /////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    ar & m_timeStamp;
    ar & m_PPSCount;
    ar & m_TimeSyncStatus;
  }
};
typedef Datum<GPSTimeStorage> GPSTime;

BOOST_CLASS_VERSION(GPSTimeStorage, 0)

#endif
