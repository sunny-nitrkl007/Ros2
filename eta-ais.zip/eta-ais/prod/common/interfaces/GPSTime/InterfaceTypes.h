#ifndef _GPSTimeInterfaceTypes_h_
#define _GPSTimeInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "GPSTime.h"

typedef interfaces::baseTypes::InputInterface<GPSTime> GPSTimeInput;
typedef interfaces::baseTypes::OutputInterface<GPSTime> GPSTimeOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<GPSTimeInput>()
  {
    return "GPSTimeInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<GPSTimeOutput>()
  {
    return "GPSTimeOutput";
  }
}

#endif
