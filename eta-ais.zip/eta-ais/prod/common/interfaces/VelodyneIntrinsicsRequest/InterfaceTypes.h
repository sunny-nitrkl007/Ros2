#ifndef _VelodyneIntrinsicsRequestInterfaceTypes_h_
#define _VelodyneIntrinsicsRequestInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "VelodyneIntrinsicsRequest.h"

typedef interfaces::baseTypes::InputInterface<VelodyneIntrinsicsRequest> VelodyneIntrinsicsRequestInput;
typedef interfaces::baseTypes::OutputInterface<VelodyneIntrinsicsRequest> VelodyneIntrinsicsRequestOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<VelodyneIntrinsicsRequestInput>()
  {
    return "VelodyneIntrinsicsRequestInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<VelodyneIntrinsicsRequestOutput>()
  {
    return "VelodyneIntrinsicsRequestOutput";
  }
}

#endif
