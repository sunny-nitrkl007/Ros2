///////////////////////////////////////////////////////////////////////////////
/// @file      VelodyneIntrinsicsRequest.h
/// @author    jderence  (jderence@rec.ri.cmu.edu)
/// @date      3/21/2013
/// @brief     
///
/// 
///
/// @attention Copyright (C) 2013
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef VelodyneIntrinsicsRequest_h_
#define VelodyneIntrinsicsRequest_h_

#include "ais/interfaces/traits/csvable.h"
#include "ais/interfaces/traits/TextWritable.h"
#include <ais/serialization/Datum.h> // For Boost serialization
#include "ais/log/Logger.h"

///////////////////////////////////////////////////////////////////////////////
/// @brief  Datum referencing a Request for VelodyneIntrinsicsMessage
///////////////////////////////////////////////////////////////////////////////
class VelodyneIntrinsicsRequestStorage : public csvable, public TextWritable
{
public:
  VelodyneIntrinsicsRequestStorage() :
      hostname("not set"),
      source("unknown")
  {};

  void setHost(const std::string& inHost)
  {
    hostname = inHost;
  }

  std::string getHost() const
  {
    return hostname;
  }

  void setSource(const std::string& inSource)
  {
    source = inSource;
  }

  std::string getSource() const
  {
    return source;
  }


  template<class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    /* Archive Fields Here */
    switch (version)
    {
    case 1:
      ar & hostname;
      break;
    case 2:
      ar & hostname;
      ar & source;   //<  Added source
      break;
    default:
      LOG_ERROR("Unknown version %d.  Cannot serialize VelodyneIntrinsicsRequest", version);
      break;
    }
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Print VelodynePacketGroup structure out in CSV format 
  /// @param out - output stream
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const
  {
    out("hostname", hostname.c_str()); 
    out("source", source.c_str()); 
  }

  /// @brief Print VelodynePacketGroup structure out in text format
  /// @param out - output stream
  ///////////////////////////////////////////////////////////////////////////////
  virtual void toStream(std::stringstream& out) const
  {
    // Identify the message type as Velodyne Packet Group
    out << "VelodyneIntrinsicsRequest" << std::endl;
    out << "Hostname: " << hostname.c_str() << std::endl;
    out << "Source: " << source.c_str()  << std::endl;
  }

private:
  /* Add Fields Here */
  std::string hostname; ///< Hostname of the process requesting the information
  std::string source;   ///< InstanceName of the Source Process requesting the information
};

typedef Datum<VelodyneIntrinsicsRequestStorage> VelodyneIntrinsicsRequest;

BOOST_CLASS_VERSION(VelodyneIntrinsicsRequestStorage, 2);
#endif

