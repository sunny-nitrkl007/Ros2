#ifndef _CPMDemoInterfaceTypes_h_
#define _CPMDemoInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "CPMDemo.h"

typedef interfaces::baseTypes::InputInterface<CPMDemo> CPMDemoInput;
typedef interfaces::baseTypes::OutputInterface<CPMDemo> CPMDemoOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<CPMDemoInput>()
  {
    return "CPMDemoInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<CPMDemoOutput>()
  {
    return "CPMDemoOutput";
  }
}

#endif
