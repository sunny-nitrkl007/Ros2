#include <ais/serialization/Datum.h> // For Boost serialization
#include <std_types.h> /* for unsigned_8 etc */
#include <ais/interfaces/traits/csvable.h>
#ifndef _CPMDemo_h_
#define _CPMDemo_h_
class CPMDemoStorage: public csvable
{  
public:  
     CPMDemoStorage():      	
        m_elevation(0),
      	m_easting_top(0),
      	m_easting_bottom(0),
      	m_northing_top(0),
      	m_northing_bottom(0) /* Initialize Fields Here */{ }

     void set_elevation(const int_32& m) { m_elevation = m; };
   int_32 get_elevation() const { return m_elevation; };

   void set_easting_top(const unsigned_8& m) { m_easting_top = m; };
   unsigned_8 get_easting_top() const { return m_easting_top; };

   void set_easting_bottom(const unsigned_32& m) { m_easting_bottom = m; };
   unsigned_32 get_easting_bottom() const { return m_easting_bottom; };

   void set_northing_top(const unsigned_8& m) { m_northing_top = m; };
   unsigned_8 get_northing_top() const { return m_northing_top; };

   void set_northing_bottom(const unsigned_32& m) { m_northing_bottom = m; };
   unsigned_32 get_northing_bottom() const { return m_northing_bottom; };


     template <class Archive>
     void serialize(Archive &ar, unsigned int version)
     {
      	ar & m_elevation;
      	ar & m_easting_top;
      	ar & m_easting_bottom;
      	ar & m_northing_top;
      	ar & m_northing_bottom;
     }

	void toCsv(CsvOutStream& out) const
	{

	}

 private:  
     /* Add Fields Here */

   int_32      m_elevation;
   unsigned_8  m_easting_top;
   unsigned_32 m_easting_bottom;
   unsigned_8  m_northing_top; 
   unsigned_32 m_northing_bottom; 
};  


typedef Datum<CPMDemoStorage> CPMDemo;

BOOST_CLASS_VERSION(CPMDemoStorage, 1);
#endif

