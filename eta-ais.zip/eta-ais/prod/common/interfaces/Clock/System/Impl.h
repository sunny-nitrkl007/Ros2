///////////////////////////////////////////////////////////////////////////////
/// @file      ./Clock/System/Impl.h
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      May 16, 2008
/// @brief     A wrapper around system time.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef _CLOCK_SYSTEM_IMPL_H_
#define _CLOCK_SYSTEM_IMPL_H_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <interfaces/Clock/Clock.h>

class ClockSystem : public Clock,
                    public interfaces::Interface
{
    public:
        ClockSystem();
        virtual ~ClockSystem();

        virtual bool initialize(const ConfigSection &cs);
        virtual void cleanup();

        virtual TimeStamp getCurrentTime();
};

#endif
