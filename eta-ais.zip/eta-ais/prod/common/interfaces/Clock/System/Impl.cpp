///////////////////////////////////////////////////////////////////////////////
/// @file      ./Clock/System/Impl.cc
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      May 16, 2008
/// @brief     System clock implementation file.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#include "Impl.h"
#include "ais/time/GetTime.h"

#include <ais/PluginProcessor/PluginDefine.h>

ClockSystem::ClockSystem()
{
}

ClockSystem::~ClockSystem()
{
}

bool ClockSystem::initialize(const ConfigSection &cs)
{
    return true;
}

void ClockSystem::cleanup()
{
}

TimeStamp ClockSystem::getCurrentTime()
{
  TimeStamp now;
  now = localhostNow();
  return now;
}

RegisterPlugin(Clock.System, interfaces::Interface, ClockSystem)
