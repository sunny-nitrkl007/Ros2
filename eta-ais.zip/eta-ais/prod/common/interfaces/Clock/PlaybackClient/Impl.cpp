///////////////////////////////////////////////////////////////////////////////
/// @file      ./Clock/PlaybackClient/Impl.cc
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      May 16, 2008
/// @brief     PlaybackClient implementation file.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#include "Impl.h"

#include <ais/time/GetTime.h>
#include <ais/PluginProcessor/PluginDefine.h>

ClockPlaybackClient::ClockPlaybackClient()
    : interfaces::ChannelInterface<PlaybackClockParams>(),
      interfaces::baseTypes::InputInterface<PlaybackClockParams>(),
      receivedParams_(false)
{
}

ClockPlaybackClient::~ClockPlaybackClient()
{
}

bool ClockPlaybackClient::initialize(const ConfigSection &cs)
{
  return ( interfaces::ChannelInterface<PlaybackClockParams>::initialize(cs, &(interfaces::baseTypes::InputInterface<PlaybackClockParams>::newData_), interfaces::Read) );
}

void ClockPlaybackClient::cleanup()
{
    interfaces::ChannelInterface<PlaybackClockParams>::cleanup();
}

TimeStamp ClockPlaybackClient::getCurrentTime()
{
    TimeStamp currentTime;
    
    if (get(latestParams_))
    {
        currentTime= localhostNow();
        return latestParams_.apply(currentTime);
    }

    return currentTime;
}

bool ClockPlaybackClient::get(PlaybackClockParams &val)
{
    {
        PlaybackClockParams newParams;
        while (interfaces::ChannelInterface<PlaybackClockParams>::read(newParams) == interfaces::CS_NewData)
        {
            latestParams_ = newParams;
            receivedParams_ = true;
        }
    }

    if (receivedParams_)
    {
        val = latestParams_;
    }

    return receivedParams_;
}

bool ClockPlaybackClient::getQueueProperties (unsigned long &currentDepth, unsigned long &maxDepth, unsigned long &droppedPackets)
{                                                 
  return interfaces::ChannelInterface<PlaybackClockParams>::getQueueProperties(currentDepth, maxDepth, droppedPackets);
}

RegisterPlugin(ClockPlaybackClient, interfaces::Interface, ClockPlaybackClient)
