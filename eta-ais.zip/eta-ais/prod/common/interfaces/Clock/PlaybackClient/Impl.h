///////////////////////////////////////////////////////////////////////////////
/// @file      ./Clock/PlaybackClient/Impl.h
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      May 16, 2008
/// @brief     Playback client clock interface.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef _CLOCK_PLAYBACK_CLIENT_IMPL_H_
#define _CLOCK_PLAYBACK_CLIENT_IMPL_H_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/ChannelInterface.h>
#include <interfaces/Clock/PlaybackClockParams.h>
#include <interfaces/Clock/Clock.h>

class ClockPlaybackClient : public Clock,
                            public interfaces::ChannelInterface<PlaybackClockParams>,
                            public interfaces::baseTypes::InputInterface<PlaybackClockParams>
{
    public:
        ClockPlaybackClient();
        virtual ~ClockPlaybackClient();

        virtual bool initialize(const ConfigSection &cs);
        virtual void cleanup();

        virtual TimeStamp getCurrentTime();

        virtual bool get(PlaybackClockParams &val);

        virtual bool getQueueProperties (unsigned long &currentDepth, unsigned long &maxDepth, unsigned long &droppedPackets);
        

    private:
        bool receivedParams_;
        PlaybackClockParams latestParams_;
};

#endif
