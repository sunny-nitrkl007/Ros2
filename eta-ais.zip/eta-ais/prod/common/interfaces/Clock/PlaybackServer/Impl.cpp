///////////////////////////////////////////////////////////////////////////////
/// @file      ./Clock/PlaybackServer/Impl.cc
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      May 16, 2008
/// @brief     Playback server implementation file.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#include "Impl.h"

#include <ais/PluginProcessor/PluginDefine.h>

ClockPlaybackServer::ClockPlaybackServer()
    : interfaces::baseTypes::OutputInterface<PlaybackClockParams>()
{
}

ClockPlaybackServer::~ClockPlaybackServer()
{
}

bool ClockPlaybackServer::initialize(const ConfigSection &cs)
{
    return ( interfaces::ChannelInterface<PlaybackClockParams>::initialize(cs, NULL, mode_) );
}

void ClockPlaybackServer::cleanup()
{
    interfaces::ChannelInterface<PlaybackClockParams>::cleanup();
}

bool ClockPlaybackServer::publish(const PlaybackClockParams &val)
{
    return ((interfaces::ChannelInterface<PlaybackClockParams>::write(val)) == interfaces::CS_Success);
}

bool ClockPlaybackServer::getQueueProperties (unsigned long &currentDepth, unsigned long &maxDepth, unsigned long &droppedPackets)
{                                                 
  return interfaces::ChannelInterface<PlaybackClockParams>::getQueueProperties(currentDepth, maxDepth, droppedPackets);
}

RegisterPlugin(ClockPlaybackServer, interfaces::Interface, ClockPlaybackServer)
