///////////////////////////////////////////////////////////////////////////////
/// @file      ./Clock/PlaybackServer/Impl.h
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      May 16, 2008
/// @brief     A PlaybackServer that publishes time from logs.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef _CLOCK_PLAYBACK_SERVER_IMPL_H_
#define _CLOCK_PLAYBACK_SERVER_IMPL_H_

#include <ais/interfaces/baseTypes/OutputInterface.h>
#include <ais/interfaces/baseTypes/ChannelInterface.h>
#include <interfaces/Clock/PlaybackClockParams.h>

class ClockPlaybackServer : public interfaces::baseTypes::OutputInterface<PlaybackClockParams>,
                            public interfaces::ChannelInterface<PlaybackClockParams>
{
    public:
        ClockPlaybackServer();
        virtual ~ClockPlaybackServer();

        virtual bool initialize(const ConfigSection &cs);
        virtual void cleanup();

        virtual bool publish(const PlaybackClockParams &val);
        virtual bool getQueueProperties (unsigned long &currentDepth, unsigned long &maxDepth, unsigned long &droppedPackets);

};

#endif
