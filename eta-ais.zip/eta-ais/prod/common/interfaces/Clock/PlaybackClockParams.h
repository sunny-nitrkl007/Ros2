///////////////////////////////////////////////////////////////////////////////
/// @file      ./Clock/PlaybackClockParams.h
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      May 16, 2008
/// @brief     Playback Clock Parameters.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef _CLOCK_PLAYBACK_PLAYBACKCLOCKPARAMS_H_
#define _CLOCK_PLAYBACK_PLAYBACKCLOCKPARAMS_H_

#include <algorithm>
#include <ais/time/TimeStamp.h>

#include <ais/serialization/Datum.h>

/**
 * @brief Parameters for transforming one time base into another
 */
struct PlaybackClockParamsStorage
{
    double offsetSeconds;///< Time between actual current time and the start of time in log
    TimeStamp baseTime;  ///< Start time in log
    double scaleFactor;  ///< (not really used yet except for "pause") Scale factor of zero means PAUSE
    TimeStamp stopTime;  ///< Log Stop time

    
    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Return the current time relative to the log time
    ///
    /// @return  Timestamp to play!
    /// 
    /// @param given - Current actual time (gettimeofday)
    /// 
    /// 
    ///////////////////////////////////////////////////////////////////////////////
    TimeStamp apply(const TimeStamp &given)
    {
      // desiredClock is the time in the reference frame (could be log start 
      // time + 10 sec for instance)
       TimeStamp desiredClock( given + offsetSeconds );

      // baseRelative is the number of seconds since the start of the file
      double baseRelative  = desiredClock.toDouble() - baseTime.toDouble();

      // Incorporate the scaleFactor (scaleFactor=0 for pause)
      const TimeStamp scaledClock( 
          baseTime + (baseRelative * (scaleFactor*1000))/1000 );

      // Stopped Clock is either the scaledClock or the last Time allowed
      const TimeStamp stoppedClock( ( (!stopTime.isZero() ) ?
                                      std::min(scaledClock, stopTime) :
                                      scaledClock) );
      return stoppedClock ;
    }

    friend bool operator==(const PlaybackClockParamsStorage &a, const PlaybackClockParamsStorage &b)
    {
        return (a.offsetSeconds == b.offsetSeconds) 
               && (a.baseTime   == b.baseTime) 
               && (a.scaleFactor== b.scaleFactor)
               && (a.stopTime   == b.stopTime);
    }

    friend bool operator!=(const PlaybackClockParamsStorage &a, const PlaybackClockParamsStorage &b)
    {
        return !(a == b);
    }

    template<class Archive>
    void serialize(Archive &ar, const unsigned int /* file_version */)
    {
        ar & offsetSeconds;
        ar & baseTime;
        ar & scaleFactor;
        ar & stopTime;
    }

};

typedef Datum<PlaybackClockParamsStorage> PlaybackClockParams;

#endif
