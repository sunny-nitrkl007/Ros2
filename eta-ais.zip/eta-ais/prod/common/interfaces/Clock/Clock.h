///////////////////////////////////////////////////////////////////////////////
/// @file      ./Clock/Clock.h
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      May 16, 2008
/// @brief     A Clock object.
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////
#ifndef CLOCK_H
#define CLOCK_H

#include <stdint.h>

#include <ais/time/TimeStamp.h>

class Clock
{
    public:
        virtual ~Clock() { };

        virtual TimeStamp getCurrentTime() = 0;
};

#endif
