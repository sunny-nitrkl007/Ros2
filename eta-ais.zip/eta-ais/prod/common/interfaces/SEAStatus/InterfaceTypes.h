#ifndef _SEAStatusInterfaceTypes_h_
#define _SEAStatusInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "SEAStatus.h"

typedef interfaces::baseTypes::InputInterface<SEAStatus> SEAStatusInput;
typedef interfaces::baseTypes::OutputInterface<SEAStatus> SEAStatusOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<SEAStatusInput>()
  {
    return "SEAStatusInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<SEAStatusOutput>()
  {
    return "SEAStatusOutput";
  }
}

#endif
