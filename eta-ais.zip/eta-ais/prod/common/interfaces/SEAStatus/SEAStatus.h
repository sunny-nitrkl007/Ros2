#include <ais/serialization/Datum.h> // For Boost serialization
#include "ais/interfaces/traits/csvable.h"
#include <boost/serialization/vector.hpp>

#include <vector>

#ifndef _SEAStatus_h_
#define _SEAStatus_h_

struct SEA
{
    public:
    uint16_t free_count;
    uint16_t reason_code;
    uint16_t status;

    template <class Archive>
    void serialize(Archive& ar, unsigned int version)
    {
        ar & free_count & reason_code & status;
    }

    void toCsv(std::string prefix, CsvOutStream & out) const
    {
      out( "free_count", free_count );
      out( "reason_code", reason_code );
      out( "status", status );
    }
};

class SEAStatusStorage: public csvable
{
public:
  SEAStatusStorage():
      m_seaList()
{ }
   std::vector<SEA> m_seaList;

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
      ar & m_seaList;
  }

  void toCsv(CsvOutStream& out) const
  {
      out( "numSEAs", m_seaList.size() );

      std::vector<SEA>::const_iterator it;

      for(it = m_seaList.begin(); it != m_seaList.end(); ++it)
      {
        it->toCsv("",out);
      }
  }

private:
  /* Add Fields Here */
};

typedef Datum<SEAStatusStorage> SEAStatus;

BOOST_CLASS_VERSION(SEAStatusStorage, 1);
#endif

