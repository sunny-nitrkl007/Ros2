///////////////////////////////////////////////////////////////////////////////
/// @file      Wrapper.cpp
/// @author    Joseph Lisee <jlisee@nrec.ri.cmu.edu>
/// @date      Dec 15, 2013
/// @brief     Python wrapper for VehicleState
///
/// @attention Copyright (C) 2013
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
///////////////////////////////////////////////////////////////////////////////

// Project Includes
#include "interfaces/VehicleState/VehicleState.h"
#include <ais/serialization/python/SerializationUtil.h>

// Library Includes
#include <boost/python.hpp>

namespace py = boost::python;

BOOST_PYTHON_MODULE(_interface_VehicleState)
{
  py::scope outer = py::class_<VehicleState>("VehicleState")
    .def_readwrite("pose", &VehicleState::pose)
    .def_readwrite("lpose", &VehicleState::lpose)
    .def_readwrite("cpose", &VehicleState::cpose)
    .def_readwrite("poseSTD", &VehicleState::poseSTD)
    .def_readwrite("acceleration", &VehicleState::acceleration)
    .def_readwrite("velocity", &VehicleState::velocity)
    .def_readwrite("velocitySTD", &VehicleState::velocitySTD)
    .def_readwrite("curvature_k", &VehicleState::curvature_k)
    .def_readwrite("curvatureSTD_k", &VehicleState::curvatureSTD_k)
    .def_readwrite("timeStamp", &VehicleState::timeStamp)
    .def_readwrite("utmPlane", &VehicleState::utmPlane)

    // Need a special wrapper for arrays
    //   see: http://stackoverflow.com/a/18902363/138948
    //double wheelSpeeds[NUMBER_OF_WHEELS];

    .def_readwrite("vehicleSpeed_mps", &VehicleState::vehicleSpeed_mps)
    .def_readwrite("combinedApplSpeed_mps", &VehicleState::combinedApplSpeed_mps)
    .def_readwrite("systemMode", &VehicleState::systemMode)
    .def_readwrite("baseMachineNavHealth", &VehicleState::baseMachineNavHealth)
    .def_readwrite("baseMachineDumpHealth", &VehicleState::baseMachineDumpHealth)
    .def_readwrite("m_pimStatusOK", &VehicleState::m_pimStatusOK)
    .def_readwrite("m_pimPositionOk", &VehicleState::m_pimPositionOk)
    .def_readwrite("vehicleLoaded", &VehicleState::vehicleLoaded)
    .def_readwrite("travelControlEnabled", &VehicleState::travelControlEnabled)
    .def_readwrite("bedPosition", &VehicleState::bedPosition)
    .def_readwrite("wheelSlip", &VehicleState::wheelSlip)

    // Methods
    .def("pimStatusOk", &VehicleState::pimStatusOk)
    .def("pimPositionOk", &VehicleState::pimPositionOk)
    .def("interpolate", &VehicleState::interpolate)
    .def("getAverageRearWheelSpeed", &VehicleState::getAverageRearWheelSpeed)
    .def("isStopped", &VehicleState::isStopped)
    .def("inAutoMode", &VehicleState::inAutoMode)
    .def("getVehicleFrameLongitudinalSpeed", &VehicleState::getVehicleFrameLongitudinalSpeed)
    .def("getVehicleFrameLateralSpeed", &VehicleState::getVehicleFrameLateralSpeed)
    .def("getFilteredGroundSpeed", &VehicleState::getFilteredGroundSpeed)

    // Static methods
    .def("modeIsAuto", &VehicleState::modeIsAuto)
    .staticmethod("modeIsAuto")

    // Static fields
    // These cause link errors because the constants are defined in the header
    // .def_readonly("wheelSpeedToleranceForStoppedVehicle",
    //               &VehicleState::wheelSpeedToleranceForStoppedVehicle)
    // .def_readonly("wheelSpeedToGPSVelocityCutOff",
    //               &VehicleState::wheelSpeedToGPSVelocityCutOff)
    // .def_readonly("wheelSpeedToGPSVelocityErrorThreshold",
    //               &VehicleState::wheelSpeedToGPSVelocityErrorThreshold)

    NREC_BP_DATUM_REGISTER(VehicleState)
    ;

  py::enum_<VehicleState::Wheels>("Wheels")
    .value("frontDriverSideWheel", VehicleState::frontDriverSideWheel)
    .value("frontPassengerSideWheel", VehicleState::frontPassengerSideWheel)
    .value("rearDriverSideWheel", VehicleState::rearDriverSideWheel)
    .value("rearPassengerSideWheel", VehicleState::rearPassengerSideWheel)
    .export_values()
    ;

  py::enum_<VehicleState::e_PimConfig>("e_PimConfig")
    .value("NO_PIM", VehicleState::NO_PIM)
    .value("PIM", VehicleState::PIM)
    .value("PIM2", VehicleState::PIM2)
    .export_values()
    ;
}
