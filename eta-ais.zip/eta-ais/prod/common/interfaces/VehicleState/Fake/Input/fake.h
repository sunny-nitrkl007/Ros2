   /////////////////////////////////////////////////////////////////
   /// @file      fake.h
   /// @author    Chris Urmson
   /// @date      11/24/2008
   /// @brief     Insert a brief description here
   ///
   /// @attention Copyright (C) 2008
   /// @attention National Robotics Engineering Center
   /// @attention Carnegie Mellon University
   /// @attention All rights reserved
   /// @attention Carnegie Mellon Proprietary
   /////////////////////////////////////////////////////////////////
#ifndef _FAKE_H_
#define _FAKE_H_

#include <interfaces/VehicleState/VehicleState.h>
#include <ais/interfaces/baseTypes/InputInterface.h>
class VehicleStateInputFake: public interfaces::baseTypes::InputInterface<VehicleState>
{
public:
  VehicleStateInputFake();
  virtual ~VehicleStateInputFake() {}
  virtual bool get(VehicleState &val);
  virtual bool initialize(const ConfigSection & cs);
  virtual void cleanup(void);
  virtual bool getQueueProperties (unsigned long &currentDepth, unsigned long &maxDepth, unsigned long &droppedPackets);

  static void * notifyThreadLauncher(void *);
  bool running_m;
protected:
  double x_m;
  double y_m;
  double z_m;
  double theta_m;
  pthread_t notifyThreadHandle_m;

  bool everyOther;

};



#endif //ifndef _FAKE_H_
