   /////////////////////////////////////////////////////////////////
   /// @file      fake.cpp
   /// @author    Chris Urmson
   /// @date      11/24/2008
   /// @brief     Insert a brief description here
   ///
   /// @attention Copyright (C) 2008
   /// @attention National Robotics Engineering Center
   /// @attention Carnegie Mellon University
   /// @attention All rights reserved
   /// @attention Carnegie Mellon Proprietary
   /////////////////////////////////////////////////////////////////
#ifndef _FAKE_CPP_
#define _FAKE_CPP_

#include <ais/PluginProcessor/PluginDefine.h>
#include "fake.h"

using namespace nrec::geometry;
using namespace std;

VehicleStateInputFake::VehicleStateInputFake()
{
}

bool VehicleStateInputFake::get(VehicleState &val)
{
  nrec::geometry::ISOPose3D<double> newPose;

  if(everyOther)
  {
    everyOther=0;
    return false;
  }
  Angle_d heading((Degree<double>(theta_m)));
  newPose.x() = x_m;
  newPose.y() = y_m;
  newPose.z() = z_m;
  newPose.rot1() = heading;
  everyOther=1;
                     
  val.cpose = newPose;

  val.systemMode = 2; // AUTO mode


//x_m += heading.cos() * 0.1;
//y_m += heading.sin() * 0.1;
//theta_m += 1.0;
  return true;
  
}

bool VehicleStateInputFake::initialize(const ConfigSection & cs)
{
  cs.get("x",x_m);
  cs.get("y",y_m);
  cs.get("z",z_m);
  cs.get("theta",theta_m);

  running_m=true;
  pthread_create(&notifyThreadHandle_m, 
                 NULL, 
                 notifyThreadLauncher, 
                 this);

  return true;
}
 
void * VehicleStateInputFake::notifyThreadLauncher(void *arg)
{
  VehicleStateInputFake * fvsi = (VehicleStateInputFake *)(arg);
  while (true == fvsi->running_m )
    {
      fvsi->notifyNewData();
      usleep(100000);
    }
  return NULL;
}


void VehicleStateInputFake::cleanup(void)
{
  running_m = false;
  pthread_join(notifyThreadHandle_m, NULL);
}

///////////////////////////////////////////////////////////////////////////////
/// @brief dummy function
///
/// @param currentDepth 
/// @param maxDepth 
/// @param droppedPackets 
/// 
/// 
/// @return  always true
/// 
///////////////////////////////////////////////////////////////////////////////
bool VehicleStateInputFake::getQueueProperties (unsigned long &currentDepth, unsigned long &maxDepth, unsigned long &droppedPackets)
{
  currentDepth = 0;
  maxDepth = 0;
  droppedPackets =0;
  return true;
}

RegisterPlugin(VehicleState.Fake.Input, interfaces::Interface, VehicleStateInputFake);



#endif //ifndef _FAKE_CPP_
