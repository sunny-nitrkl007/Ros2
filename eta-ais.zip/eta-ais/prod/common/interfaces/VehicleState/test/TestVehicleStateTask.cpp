
#include "TestVehicleStateTask.h"

#include <ais/time/GetTime.h>

using namespace task;

double TestVehicleStateTask::K = 0.0;

AbstractTaskCore* task::getTaskImplementation( )
{
    static TestVehicleStateTask thisTask( "TestVehicleStateTask" );
    return &thisTask;
}

TestVehicleStateTask::TestVehicleStateTask( const std::string& taskName ):
    Task( taskName ),
    m_vehCmdInput( NULL ),
    m_vehCmdOutput( NULL )
{
}

TestVehicleStateTask::~TestVehicleStateTask( )
{
}

bool TestVehicleStateTask::initialize( )
{
    LOG_INFO( "TestVehicleStateTask::initialize" );

    m_vehCmdInput = dynamic_cast<VehicleStateInput*>( InterfaceDb::fetch( "VehicleStateInput" ) );
    m_vehCmdOutput = dynamic_cast<VehicleStateOutput*>( InterfaceDb::fetch( "VehicleStateOutput" ) );

    if ( m_vehCmdInput )
    {
        m_vehCmdInput->addNewDataSlot( boost::bind( &TestVehicleStateTask::inputCallback, this ) );
    }
    return true;
}

void TestVehicleStateTask::inputCallback( )
{
    VehicleState type;
    if ( m_vehCmdInput->get( type ) )
    {
        LOG_FATAL( "Input got new Vehilc State");
    }
}

bool TestVehicleStateTask::executive( )
{
    LOG_INFO( "executive" );

    if ( m_vehCmdInput )
    {
      LOG_FATAL("SHOULD NOT GET HERE");
    }
    else if ( m_vehCmdOutput )
    {
        //LOG_FATAL( "task configured to write to output interface" );

        static VehicleState type;
        type.curvature_k += (K+=1.01);
        m_vehCmdOutput->publish( type );

        // measure cycle rate and print out rate every 100 cycles
        static int cn = 0;
        cn++;
        static TimeStamp ts;
        TimeStamp last = ts;
        ts= localhostNow();
        double cr = (ts - last).toDouble();
        if ( cn % 5 == 1)
        {
            printf( "cycle rate is %lf hertz\n", 1.0 / cr );
        }
    }
    else
    {
        LOG_ERROR( "no input or output interface defined" );
        return false;
    }

    return true;
}

void TestVehicleStateTask::cleanup( )
{
    LOG_INFO( "TestVehicleStateTask::cleanup" );
}


