///////////////////////////////////////////////////////////////////////////////
/// @file      TestVehicleStateTask.h
/// @author    jderence
/// @date      7/22/2008
/// @brief     Simple Task to test VehicleState Channels
///**Note: Task not thread safe for multi-threaded applications**
/// 
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef _TestVehicleStateTask_h_
#define _TestVehicleStateTask_h_

#include <ais/task/Task.h>

#include <interfaces/VehicleState/InterfaceTypes.h>

class TestVehicleStateTask : public task::Task
{
public:
    TestVehicleStateTask( const std::string& taskName );
    virtual ~TestVehicleStateTask( );

    virtual bool initialize( );
    virtual bool executive( );
    virtual void cleanup( );

private:
    void inputCallback( );
    VehicleStateInput* m_vehCmdInput;
    VehicleStateOutput* m_vehCmdOutput;

    static double K;
};
#endif
