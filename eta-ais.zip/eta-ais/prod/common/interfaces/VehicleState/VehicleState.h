///////////////////////////////////////////////////////////////////////////////
/// @file      VehicleState.h
/// @author    Bryan Salesky (bsalesky@rec.ri.cmu.edu)
/// @date      June 13, 2008
/// @brief     VehicleState data structure
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
/// @attention Carnegie Mellon Proprietary
/// @attention Originally developed by Tartan Racing
///////////////////////////////////////////////////////////////////////////////
#ifndef VehicleState_h
#define VehicleState_h

#include "ais/util/stringUtils.h"
#include "coreTechExtensions/serialize.h"
#include "geometry/poses/ISOPose3D.h"
#include "geometry/primitives/Point3D.h"
#include "ais/time/TimeStamp.h"
#include <ais/serialization/Datum.h>
#include "util/Interpolate.h"
#include "mcmInterpreter/McmDefinitions.h"  // For System Mode
#include "PIM/PIMParam.h"  // needed for legacy versions
#include "ais/log/Logger.h"
#include "ais/interfaces/traits/csvable.h"
#include "ais/interfaces/traits/TextWritable.h"
#include "interfaces/traits/Jsonable.h"
#include "interfaces/PIM2State/PIM2State.h" // needed for legacy versions
#include "util/BasicDataWithStatusIndicator.h" // needed for storing data with status embedded in it

/**
 * @brief VehicleState describes the state of the vehicle 
 *  
 * The VehicleState class describes the state of our vehicle.  It is 
 * smooth AND global.
 *  
 * Local pose was added for perception. Perception will initially use only local Z and still requires global pose
 *  
 * The state includes:
 * - easting, northing, altitude (x, y, z, resp) in meters
 * - roll, pitch, yaw in radians
 * - error in estimate of easting, northing, altitude, roll, pitch, and yaw
 * - commanded curvature
 * - actual curvature
 * - error in estimate of actual curvature
 * - time of validity
 */
struct VehicleStateStorage : public csvable, public TextWritable, public Jsonable
{
    enum Wheels {
        frontDriverSideWheel = 0,
        frontPassengerSideWheel,
        rearDriverSideWheel,
        rearPassengerSideWheel,
        NUMBER_OF_WHEELS // keep as last element
    };

    // Pim Configuration - needed for legacy
    enum e_PimConfig
    {
      NO_PIM,
      PIM,
      PIM2,
    };

    VehicleStateStorage()
        : pose(),
          lpose(),
          cpose(),
          poseSTD(),
          acceleration(),
          velocity(),
          velocitySTD(),
          curvature_k(0),
          curvatureSTD_k(0),
          utmPlane(0),
          vehicleSpeed_mps(0),
          combinedApplSpeed_mps(0),
          systemMode(MANUAL_OP_MODE),
          baseMachineNavHealth(0),
          baseMachineDumpHealth(0),
          m_pimStatusOK(false),
		  m_pimPositionOk(false),
          vehicleLoaded(false),
          travelControlEnabled(true),
          bedPosition(0),
          wheelSlip(0)

    {
        for ( int ii = 0; ii < NUMBER_OF_WHEELS; ii++ )
        { wheelSpeeds[ii] = 0.0; }
    }

    nrec::geometry::ISOPose3D<double> pose;		///< x - north, y - east, z - altitude, r, p, y  (rot1 is yaw, rot2 is pitch, rot3 is roll); still needed for perception
    nrec::geometry::ISOPose3D<double> lpose;	        ///< Local pose for perception; perception will continue to use parts of global pose
    nrec::geometry::ISOPose3D<double> cpose;	        ///< Control pose for planning
    nrec::geometry::ISOPose3D<double> poseSTD;		///< error in position estimate
    
    nrec::geometry::Point3D_d acceleration;	///< linear acceleration of the vehicle
    
    nrec::geometry::ISOPose3D<double> velocity;     ///< linear and rotational speeds of the vehicle
    nrec::geometry::ISOPose3D<double> velocitySTD;  ///< error in the velocity estimate
    
    double curvature_k;	    ///< Curvature of the vehicle derived from steering
    double curvatureSTD_k;  ///< Standard deviation of curvature estimate
    TimeStamp timeStamp;    ///< GPS Time at which this pose is valid, seconds since epoch, UTC
    int utmPlane;           ///< UTM plane to reference easting and northing to
    double wheelSpeeds[NUMBER_OF_WHEELS];
    double vehicleSpeed_mps;  ///< This variable replaces the confusing DMI wheel speed variable.
                              ///< Vehicle speed is the veclocity along the X axis of the vehicle
                              ///< at the control point.  It is generally derived from the DMI
                              ///< if it is available, otherwise it is the projection of GPS
                              ///< derived velocity along the X axis of the vehicle at the control point

    // Note: if m_gndSpeedTos.status is non zero, then m_gndSpeedTos.value should NOT be used
    BasicDataWithStatusIndicator<double> baseMachineGndSpeedTOS; // ground speed TOS provided by the Transmission ECM with DSI included
                                                             // if m_gndSpeedTos.status is zero, then m_gndSpeedTos.value is good

    double combinedApplSpeed_mps; // square root of sum of component velocity squares from Applanix

    unsigned int systemMode;

    /* Base machine health
    //
    // These contain a summary of the status of the various base truck 
    // subsystems.  The goal for summarizing these subsystem status values is 
    // to simplify the subsystem status interface to the rest of the autonomy 
    // system.  In general, we want to know if we can drive the truck around 
    // (ie navigation status) and we also need to know if we can dump the 
    // body (ie dump status).
    // 
    // The base truck subsystems are summarized as follows:
    //
    // Navigation Status (Health)
    //
    //   Subsystem        Why it is important
    //   ----------------------------------------------------------------------
    //   statusInBrake    (we need to stop)
    //   statusInEngine   (we need to control engine speed)
    //   statusInSteerPri (we need to steer)
    //   statusInSteerSec (we need to steer)
    //   statusInTrans    (we need to control the trans gear)
    //
    // Dump Status (Health)
    //
    //   Subsystem        Why it is important
    //   ----------------------------------------------------------------------
    //   statusInBrake    (we need to apply brakes before dumping the load)
    //   statusInChassis  (we need a healthy dump system before dumping the load)
    //   statusInEngine   (we need to control engine speed to effectively dump the load)
    //   statusInTrans    (we need to go to neutral before dumping the load)
    //
    // Valid values to use for subsystem status
    //   enum StatusVal {
    //       STATUS_OK = 0,
    //       STATUS_NOT_OK,
    //       STATUS_UNKNOWN,
    //   };
    */
    int baseMachineNavHealth;
    int baseMachineDumpHealth;


    bool m_pimStatusOK;
    bool pimStatusOk() const
    {
      return m_pimStatusOK;
    }
    bool m_pimPositionOk;
    bool pimPositionOk() const
    {
      return m_pimPositionOk;
    }

    bool vehicleLoaded;
    bool travelControlEnabled;
    double bedPosition;    ///< this is a percent 5 for 5%; 100 is all the way up (comes from MCMStatus.m_truckParams.bodyRaisePosition)
    
    double wheelSlip; // absolute value of difference between Applanix speed and TOS speed from base truck
        
    // nothing like inlining hundreds of lines of code :)
    inline void interpolate(const VehicleStateStorage& before,
                            const VehicleStateStorage& after,
                            const double& scale)
    {
      // Pose
      pose = nrec::geometry::interpolateISOPose3d(before.pose, after.pose, scale);
      // Local Pose
      lpose = nrec::geometry::interpolateISOPose3d(before.lpose, after.lpose, scale);
      // Control Pose
      cpose = nrec::geometry::interpolateISOPose3d(before.cpose, after.cpose, scale);
      // PoseSTD
      poseSTD = nrec::geometry::interpolateISOPose3d(before.poseSTD, after.poseSTD, scale);
      // velocity
      velocity = nrec::geometry::interpolateISOPose3d(before.velocity, after.velocity, scale);
      // velocitySTD
      velocitySTD = nrec::geometry::interpolateISOPose3d(before.velocitySTD, after.velocitySTD, scale);
      // acceleration
      acceleration = nrec::interpolateValue(before.acceleration, after.acceleration,  scale);
      // curvature
      curvature_k = nrec::interpolateValue(before.curvature_k, after.curvature_k, scale);
      // curvatureSTD
      curvatureSTD_k = nrec::interpolateValue(before.curvatureSTD_k, after.curvatureSTD_k, scale);
      // Wheel speeds
      for ( int ii = 0; ii < VehicleStateStorage::NUMBER_OF_WHEELS; ii++ ) { 
        wheelSpeeds[ii] = nrec::interpolateValue(before.wheelSpeeds[ii], after.wheelSpeeds[ii], scale);
      }
      // wheel speed
      vehicleSpeed_mps = nrec::interpolateValue(before.vehicleSpeed_mps, after.vehicleSpeed_mps, scale);

      // ground speed TOS: interplate only if the before and after statuses are good
      // otherwise use the last value
      if ((before.baseMachineGndSpeedTOS.status == 0) && (after.baseMachineGndSpeedTOS.status == 0))
      {
        baseMachineGndSpeedTOS.status = 0;
        baseMachineGndSpeedTOS.value = nrec::interpolateValue(before.baseMachineGndSpeedTOS.value, after.baseMachineGndSpeedTOS.value, scale);
      }
      else
        baseMachineGndSpeedTOS = before.baseMachineGndSpeedTOS;

      // Bed position
      bedPosition = nrec::interpolateValue(before.bedPosition, after.bedPosition, scale);
      // Combined Applanix Speed
      combinedApplSpeed_mps = nrec::interpolateValue(before.combinedApplSpeed_mps, after.combinedApplSpeed_mps, scale);
      // Wheel Slip
      wheelSlip = nrec::interpolateValue(before.wheelSlip, after.wheelSlip, scale);
      // Bed Position
      bedPosition = nrec::interpolateValue(before.bedPosition, after.bedPosition, scale);

      // just set these states to the values in the "after" vehicleState
      baseMachineNavHealth  = after.baseMachineNavHealth;
      baseMachineDumpHealth = after.baseMachineDumpHealth;
      utmPlane              = after.utmPlane;
      systemMode            = after.systemMode;
      vehicleLoaded         = after.vehicleLoaded;
      travelControlEnabled  = after.travelControlEnabled;
      m_pimStatusOK      = after.m_pimStatusOK;

    }
    
    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Returns the average rear wheel speed of the vehicle
    ///////////////////////////////////////////////////////////////////////////////
    double getAverageRearWheelSpeed() const
    {
      return vehicleSpeed_mps;
    }

    static constexpr double wheelSpeedToleranceForStoppedVehicle = 0.2;
    bool isStopped() const
    {
      return fabs(getAverageRearWheelSpeed()) < 
        wheelSpeedToleranceForStoppedVehicle;
    }

    static bool modeIsAuto( const unsigned int& mode )
    {
      if ( ( mode == AUTO_RUN_OP_MODE ) ||
           ( mode == A_STOP_OP_MODE ) ||
           ( mode == AUTO_RUN_NO_MVMT_OP_MODE ) )
      {
        return true;
      }
      return false;
    }      

    bool inAutoMode() const
    {
      return modeIsAuto( systemMode );
    }
    
    bool inManualMode() const
    {
      if (systemMode == MANUAL_OP_MODE)
        return true;
      else
        return false;
    }
    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Returns the Longitudinal Speed in vehicle frame using Applanix velocities
    ///////////////////////////////////////////////////////////////////////////////
    double getVehicleFrameLongitudinalSpeed() const
    {
      nrec::geometry::Angle<double> heading;
  
      heading = cpose.yaw(); 
      nrec::geometry::Vector2D_d longVector( cos(heading), sin(heading) ); 
      nrec::geometry::Vector2D_d velVector( velocity.x(), velocity.y() );
      
      double gpsLongitudinalVelocity = nrec::geometry::dot<double>(velVector,longVector); 
      return gpsLongitudinalVelocity;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Returns the Lateral Speed in vehicle frame using Applanix velocities
    ///////////////////////////////////////////////////////////////////////////////
    double getVehicleFrameLateralSpeed() const
    {
      nrec::geometry::Angle<double> side;
  
      side.setRadians( cpose.yaw().getRadians() + M_PI/2 ); //angle pointing to the left of the vehicle
      nrec::geometry::Vector2D_d latVector( cos(side), sin(side) );
      nrec::geometry::Vector2D_d velVector( velocity.x(), velocity.y() );
      
      double gpsLateralVelocity = nrec::geometry::dot<double>(velVector,latVector); 
      return gpsLateralVelocity;
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Returns the filtered ground speed of the vehicle
    /// 
    /// Using the ground speed of the vehicle as the wheelspeed is accurate nearly all of the time. The
    /// exception from this is during a hard brake event, where the wheels may lock up or almost
    /// lock up.  This can occur with or without ABS present or active. getAverageRearWheelSpeed will report 
    /// a much lower velocity than the velocity of the body.  Use of getAverageRearWheelSpeed has been well 
    /// tested, and is a good measure of our control action of commanded speed.  The planning system 
    /// needs to know the ground speed of the vehicle for the planning horizon and forward prediction.
    /// 
    /// To account for a hard brake event, report a ground speed that is the maximum of wheel speed
    /// and gps velocity if the difference is larger than a percent threshold. This assumes that there is
    /// nearly a 1:1 mapping between wheelSpeed (state-feedback speed) and gps velcoity, which is true.
    /// 
    /// Use of gps velocity over wheelspeed during a hard brake event under dead-reckoning is also valid.
    /// GPS velocity northing and easting are unchanged in VehicleState by PIM (copied from Applanix State). Because
    /// Applanix's effective estimate of GPS velocity during high uncertainty and its validity during PIM 
    /// dead-reckoning, it is still useful for comparison.  Although the longitudinal component will start
    /// to degrade because we dead-reckon controlpose.yaw, it is still valid for quite a while and is more accurate than
    /// wheelspeed during a hard braking event.
    ///////////////////////////////////////////////////////////////////////////////
    static constexpr double wheelSpeedToGPSVelocityCutOff = 2.0; //Only calculate when gps velocity is above this to avoid deceptively large percent errors
    static constexpr double wheelSpeedToGPSVelocityErrorThreshold = 0.15; //wheelspeed is allowed to be a maximum of 15% error under gps velocity
    double getFilteredGroundSpeed() const
    {
      double groundSpeed = getAverageRearWheelSpeed();
      double gpsLongitudinalVelocity = getVehicleFrameLongitudinalSpeed();

      if(std::abs(gpsLongitudinalVelocity) > wheelSpeedToGPSVelocityCutOff)
      {
        double percentError = std::abs((groundSpeed - gpsLongitudinalVelocity)/gpsLongitudinalVelocity);
        if( (percentError > wheelSpeedToGPSVelocityErrorThreshold) && 
            (std::abs(gpsLongitudinalVelocity) > std::abs(groundSpeed)) 
          ) 
        {
          groundSpeed = gpsLongitudinalVelocity;
        }
      }
      return groundSpeed;
    }


    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Returns an filtered ground speed of the vehicle's frame
    ///
    /// This is an alternative ground speed that can be used to provide
    /// a smoother ground speed than the average of the rear wheel speeds.  Simply this
    /// speed depends heavily on the vehicle frame longitudinal speed and little on the
    /// average of the rear wheel speed.  This provides a smoother speed that filters out the
    /// backlash observed when using the ave. rear wheel speeds.  This smoother ground
    /// speed is desired for things like path prediction in engineering controls.  Having a
    /// ground speed oscillation due to the backlash may cause some chatter of the controls.
    /// Using the arbitrated machine speed smooths out these oscilations during gear changes.
    ///
    /// This get method arbitrates between the Vehcile frame longitudianl speed and the average
    /// of the rear wheel speeds depending on the average rear wheel speeds.  The vehicle
    /// frame longitudinal speed is used anytime the average rear wheel speed is greater than
    /// gpsVelocityToWheelSpeedCutOff meter/second.
    ///////////////////////////////////////////////////////////////////////////////
    static constexpr double gpsVelocityToWheelSpeedCutOff = 1.0; //Only calculate when average wheels speeds are above this to avoid inaccurate long speeds close to zero
    double getFilteredLongitudinalSpeed() const
    {
      double groundSpeed = getAverageRearWheelSpeed();
      double gpsLongitudinalVelocity = getVehicleFrameLongitudinalSpeed();
      if(std::abs(groundSpeed)>gpsVelocityToWheelSpeedCutOff)
      {
        groundSpeed = gpsLongitudinalVelocity;
      }
      return groundSpeed;
    }


    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Print VehicleState structure out in CSV format (note: Rotations in degrees)
    /// @param out - output stream
    ///////////////////////////////////////////////////////////////////////////////
    void toCsv(CsvOutStream& out) const
    {
      // Timestamp (in seconds)
      out("GpsTimestamp", timeStamp.toDouble()); 

      // Pose
      out("PoseX", pose.x());
      out("PoseY", pose.y());      
      out("PoseZ", pose.z());
      out("PoseRollDeg", pose.roll().getDegrees());
      out("PosePitchDeg", pose.pitch().getDegrees());
      out("PoseYawDeg", pose.yaw().getDegrees());

      // Pose STD
      out("PoseSTDX", poseSTD.x());
      out("PoseSTDY", poseSTD.y());      
      out("PoseSTDZ", poseSTD.z());
      out("PoseSTDRollDeg", poseSTD.roll().getDegrees());
      out("PoseSTDPitchDeg", poseSTD.pitch().getDegrees());
      out("PoseSTDYawDeg", poseSTD.yaw().getDegrees());

      // UTM plane
      out("UTMPlane", utmPlane);

      // Acceleration
      out("AccelerationX", acceleration.x());
      out("AccelerationY", acceleration.y());
      out("AccelerationZ", acceleration.z());

      // Velocity
      out("VelocityEasting", velocity.x());
      out("VelocityNorthing", velocity.y());
      out("VelocityUp", velocity.z());
      
      // velocitySTD
      out("VelocitySTDEasting", velocitySTD.x());
      out("VelocitySTDNorthing", velocitySTD.y());
      out("VelocitySTDUp", velocitySTD.z());

      // WheelSpeedMPS, curvature
      out("VehicleSpeed_mps", vehicleSpeed_mps);
      out("Curvature", curvature_k);

      // BaseMachine ground speed TOS
      out("BaseMachineGndSpeedTOS_Status", baseMachineGndSpeedTOS.status );
      out("BaseMachineGndSpeedTOS_Mps", baseMachineGndSpeedTOS.value);

      // wheel speeds
      for (int i = 0; i < NUMBER_OF_WHEELS; i++) {
        out("WheelSpeed" + stringUtils::typeToString(i), wheelSpeeds[i]);
      }

      // SubsystemOpMode
      out("SystemMode", systemMode);

      // Subsystem health
      out("baseMachineNavHealth", baseMachineNavHealth);
      out("baseMachineDumpHealth", baseMachineDumpHealth);

      out("vehicleLoaded", vehicleLoaded);
      out("travelControlEnabled", travelControlEnabled);
      out("bedPosition", bedPosition);

      // Local Pose
      out("LocalPoseX", lpose.x());
      out("LocalPoseY", lpose.y());      
      out("LocalPoseZ", lpose.z());
      out("LocalPoseRollDeg", lpose.roll().getDegrees());
      out("LocalPosePitchDeg", lpose.pitch().getDegrees());
      out("LocalPoseYawDeg", lpose.yaw().getDegrees());

      // Control Pose
      out("ControlPoseX", cpose.x());
      out("ControlPoseY", cpose.y());      
      out("ControlPoseZ", cpose.z());
      out("ControlPoseRollDeg", cpose.roll().getDegrees());
      out("ControlPosePitchDeg", cpose.pitch().getDegrees());
      out("ControlPoseYawDeg", cpose.yaw().getDegrees());

      // Roll, Pitch, Yaw rates
      out("RollRate", velocity.roll().getDegrees());
      out("PitchRate", velocity.pitch().getDegrees());
      out("YawRate", velocity.yaw().getDegrees());

      // Vehicle frame velocities and Filtered Ground Speed
      out("VehicleFrameLongitudinalSpeed", getVehicleFrameLongitudinalSpeed());
      out("VehicleFrameLateralSpeed", getVehicleFrameLateralSpeed());
      out("FilteredGroundSpeed", getFilteredGroundSpeed());
      out("FilteredFrameLongitudinalSpeed", getFilteredLongitudinalSpeed());

      // Wheel Slip related parameters
      out("combinedApplSpeed_mps", combinedApplSpeed_mps);
      out("wheelSlip", wheelSlip);
      
      //PIM2
      out("PimStatusOK",  pimStatusOk());
      out("PimPositionOk", pimPositionOk());

    }// end toCSv

    virtual void toStream(std::stringstream& out) const
    {
      out << "This vehicle's speed is " << vehicleSpeed_mps;
    }

    virtual void jsonSerialize( JsonIosAbstractBase& json )
    {
      json("GpsTime", timeStamp);
      json("CPose", cpose);
      json("PoseStd", poseSTD);
      json("Velocity", velocity);
      json("VehicleSpeed", vehicleSpeed_mps);
      json("Curvature", curvature_k);
    }

  private:
    friend class boost::serialization::access;

    ///////////////////////////////////////////////////////////////////////////////
    /// @brief Boost Serialization function for VehicleState
    /// @param ar 
    /// @param version 
    ///////////////////////////////////////////////////////////////////////////////
    template <class Archive>
    void serialize(Archive &ar, unsigned int version)
    {
      switch (version)
      {                       
        case 0:
          ar & pose & poseSTD;
          ar & acceleration;
          ar & velocity & velocitySTD;
          ar & curvature_k & curvatureSTD_k;
          ar & timeStamp & utmPlane;
          ar & wheelSpeeds;
          vehicleSpeed_mps = 0;
          systemMode = 0;
          baseMachineNavHealth = 0;
          baseMachineDumpHealth = 0;
          lpose = pose;
          cpose = pose;
          vehicleLoaded = false;
          travelControlEnabled = true;
          bedPosition = 0.0;
          wheelSlip = 0.0;
          combinedApplSpeed_mps = 0.0;
          break;
        case 1: //Adds vehicleSpeed_mps
          ar & pose & poseSTD;
          ar & acceleration;
          ar & velocity & velocitySTD;
          ar & curvature_k & curvatureSTD_k;
          ar & timeStamp & utmPlane;
          ar & wheelSpeeds;
          ar & vehicleSpeed_mps;
          systemMode = 0;
          baseMachineNavHealth = 0;
          baseMachineDumpHealth = 0;          
          lpose = pose;
          cpose = pose;
          vehicleLoaded = false;
          travelControlEnabled = true;
          bedPosition = 0.0;
          wheelSlip = 0.0;
          combinedApplSpeed_mps = 0.0;
          break;
        case 2: //Adds systemMode
          ar & pose & poseSTD;
          ar & acceleration;
          ar & velocity & velocitySTD;
          ar & curvature_k & curvatureSTD_k;
          ar & timeStamp & utmPlane;
          ar & wheelSpeeds;
          ar & vehicleSpeed_mps;
          ar & systemMode;
          baseMachineNavHealth = 0;
          baseMachineDumpHealth = 0;          
          lpose = pose;
          cpose = pose;
          vehicleLoaded = false;
          travelControlEnabled = true;
          bedPosition = 0.0;
          wheelSlip = 0.0;
          combinedApplSpeed_mps = 0.0;
          break;
        case 3: //Adds base machine health status
          ar & pose & poseSTD;
          ar & acceleration;
          ar & velocity & velocitySTD;
          ar & curvature_k & curvatureSTD_k;
          ar & timeStamp & utmPlane;
          ar & wheelSpeeds;
          ar & vehicleSpeed_mps;
          ar & systemMode;
          ar & baseMachineNavHealth;
          ar & baseMachineDumpHealth;
          lpose = pose;
          cpose = pose;
          vehicleLoaded = false;
          travelControlEnabled = true;
          bedPosition = 0.0;
          wheelSlip = 0.0;
          combinedApplSpeed_mps = 0.0;
          break;
        case 4: //Adds local and control poses
          ar & pose & poseSTD;
          ar & acceleration;
          ar & velocity & velocitySTD;
          ar & curvature_k & curvatureSTD_k;
          ar & timeStamp & utmPlane;
          ar & wheelSpeeds;
          ar & vehicleSpeed_mps;
          ar & systemMode;
          ar & baseMachineNavHealth;
          ar & baseMachineDumpHealth;
          ar & lpose;
          ar & cpose;
          vehicleLoaded = false;
          travelControlEnabled = true;
          bedPosition = 0.0;
          wheelSlip = 0.0;
          combinedApplSpeed_mps = 0.0;
          break;
        case 5: //Adds vehicleLoaded and travelControlEnabled
          ar & pose & poseSTD;
          ar & acceleration;
          ar & velocity & velocitySTD;
          ar & curvature_k & curvatureSTD_k;
          ar & timeStamp & utmPlane;
          ar & wheelSpeeds;
          ar & vehicleSpeed_mps;
          ar & systemMode;
          ar & baseMachineNavHealth;
          ar & baseMachineDumpHealth;
          ar & lpose;
          ar & cpose;
          ar & vehicleLoaded;
          ar & travelControlEnabled;
          bedPosition = 0.0;
          wheelSlip = 0.0;
          combinedApplSpeed_mps = 0.0;
          break;
      case 6: //Adds Pim State
          {
            PIMState pimState;  // read in and discarded
            ar & pose & poseSTD;
            ar & acceleration;
            ar & velocity & velocitySTD;
            ar & curvature_k & curvatureSTD_k;
            ar & timeStamp & utmPlane;
            ar & wheelSpeeds;
            ar & vehicleSpeed_mps;
            ar & systemMode;
            ar & baseMachineNavHealth;
            ar & baseMachineDumpHealth;
            ar & lpose;
            ar & cpose;
            ar & vehicleLoaded;
            ar & travelControlEnabled;        
            ar & pimState;
            bedPosition = 0.0;
            wheelSlip = 0.0;
            combinedApplSpeed_mps = 0.0;
          }
          break;
        case 7: //Adds Bed Position
          {
            PIMState pimState;  // read in and discarded
            ar & pose & poseSTD;
            ar & acceleration;
            ar & velocity & velocitySTD;
            ar & curvature_k & curvatureSTD_k;
            ar & timeStamp & utmPlane;
            ar & wheelSpeeds;
            ar & vehicleSpeed_mps;
            ar & systemMode;
            ar & baseMachineNavHealth;
            ar & baseMachineDumpHealth;
            ar & lpose;
            ar & cpose;
            ar & vehicleLoaded;
            ar & travelControlEnabled;        
            ar & pimState;
            ar & bedPosition;
            wheelSlip = 0.0;
            combinedApplSpeed_mps = 0.0;
          }
          break;
        case 8: //Adds wheel slip and combined applanix speed
          {
            PIMState pimState;  // read in and discarded
            ar & pose & poseSTD;
            ar & acceleration;
            ar & velocity & velocitySTD;
            ar & curvature_k & curvatureSTD_k;
            ar & timeStamp & utmPlane;
            ar & wheelSpeeds;
            ar & vehicleSpeed_mps;
            ar & systemMode;
            ar & baseMachineNavHealth;
            ar & baseMachineDumpHealth;
            ar & lpose;
            ar & cpose;
            ar & vehicleLoaded;
            ar & travelControlEnabled;        
            ar & pimState;
            ar & bedPosition;
            ar & wheelSlip;
            ar & combinedApplSpeed_mps;
          }
          break;
        case 9: //Removes old PIM state, and adds PIM2 status
          {
            PIM2State::PimStatusDb pim2Status;  // read in and discarded
            ar & pose & poseSTD;
            ar & acceleration;
            ar & velocity & velocitySTD;
            ar & curvature_k & curvatureSTD_k;
            ar & timeStamp & utmPlane;
            ar & wheelSpeeds;
            ar & vehicleSpeed_mps;
            ar & systemMode;
            ar & baseMachineNavHealth;
            ar & baseMachineDumpHealth;
            ar & lpose;
            ar & cpose;
            ar & vehicleLoaded;
            ar & travelControlEnabled;        
            ar & bedPosition;
            ar & wheelSlip;
            ar & combinedApplSpeed_mps;
            ar & pim2Status;
          }
          break;
        case 10: // Removes PIM2 status and replaces it with single status flag
          ar & pose & poseSTD;
          ar & acceleration;
          ar & velocity & velocitySTD;
          ar & curvature_k & curvatureSTD_k;
          ar & timeStamp & utmPlane;
          ar & wheelSpeeds;
          ar & vehicleSpeed_mps;
          ar & systemMode;
          ar & baseMachineNavHealth;
          ar & baseMachineDumpHealth;
          ar & lpose;
          ar & cpose;
          ar & vehicleLoaded;
          ar & travelControlEnabled;        
          ar & bedPosition;
          ar & wheelSlip;
          ar & combinedApplSpeed_mps;
          ar & m_pimStatusOK;
          break;
        case 11:// Add's an additional PIM Status Flag
          ar & pose & poseSTD;
          ar & acceleration;
          ar & velocity & velocitySTD;
          ar & curvature_k & curvatureSTD_k;
          ar & timeStamp & utmPlane;
          ar & wheelSpeeds;
          ar & vehicleSpeed_mps;
          ar & systemMode;
          ar & baseMachineNavHealth;
          ar & baseMachineDumpHealth;
          ar & lpose;
          ar & cpose;
          ar & vehicleLoaded;
          ar & travelControlEnabled;
          ar & bedPosition;
          ar & wheelSlip;
          ar & combinedApplSpeed_mps;
          ar & m_pimStatusOK;
          ar & m_pimPositionOk;
          break;
        case 12:// Add's baseMachineGndSpeedTOS
          ar & pose & poseSTD;
          ar & acceleration;
          ar & velocity & velocitySTD;
          ar & curvature_k & curvatureSTD_k;
          ar & timeStamp & utmPlane;
          ar & wheelSpeeds;
          ar & vehicleSpeed_mps;
          ar & systemMode;
          ar & baseMachineNavHealth;
          ar & baseMachineDumpHealth;
          ar & lpose;
          ar & cpose;
          ar & vehicleLoaded;
          ar & travelControlEnabled;
          ar & bedPosition;
          ar & wheelSlip;
          ar & combinedApplSpeed_mps;
          ar & m_pimStatusOK;
          ar & m_pimPositionOk;
          ar & baseMachineGndSpeedTOS;
          break;
        default:
          LOG_FATAL("Cannot Serialize VehicleState with version %d", version);
          break;                   
      }            
    }
};

typedef Datum<VehicleStateStorage> VehicleState;

BOOST_CLASS_VERSION(VehicleStateStorage, 12)



///////////////////////////////////////////////////////////////////////////////
/// @brief Struct to hold conversions
///////////////////////////////////////////////////////////////////////////////
struct VehicleStateConversion
{
  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Copy over the data from vehicle state excluding PIM data
  /// @param VehicleState& 
  /// @return trimmedVehicleState
  /// 
  /// The pim objects can cause expensive operations if put into a vector (in
  /// multiple places in the planning system) because it would be akin to a:
  /// std::vector< std::map< std::string, PimCheckStatus> >.  Thus an operation
  /// of a sort or an erase would probably mean expensive copy operations.
  /// 
  /// Make a copy of the vehicle state w/o copying PIM data. This means that essentially
  /// the map object is empty.
  /// 
  /// Since this is a separate object, there is interest in the planning system to 
  /// translate velocity to the control point (versus at the IMU). Thus operations
  /// to get gps speed at the control point would be more accurate. Keep v.x and
  /// v.y pointing in global coordinate frame
  /// 
  /// FIXME in IM3.1, so that stateEstimator adds a 'cvelocity' field so that planning
  /// can transition to use of that.
  ///////////////////////////////////////////////////////////////////////////////
  VehicleState getPlanningVehicleState(const VehicleState& rawState, bool mapVelocityToControlPose = false)
  {
    VehicleState state;
  
    state = rawState;
  
    //Translate velocity to control pose. This moves the data to the control point however
    // maintains the directions in the GLOBAL coordinate frame. This is different than just
    // a translation as the rotational velocities change the velocity at the control point
    // of which a homogenous transform doesn't satisfy.
    if(mapVelocityToControlPose)
    {
      nrec::geometry::Vector2D<double> r(state.cpose.x()-state.pose.x(), state.cpose.y()-state.pose.y());
      double normR = nrec::geometry::lengthL2<double>(r);
  
      if(normR > nrec::geometry::Defaults<double>::getTolerance())
      {
        //Equations:
        // r is the norm of the difference between the control pose and imu pose ('normR' here)
        // x = r cos(t)
        // y = r sin(t)
        // x_dot = r_dot cos(t) - r sin(t) t_dot
        // y_dot = r_dot sin(t) + r cos(t) t_dot
        // 
        //Since r_dot = 0
        // x_dot = -r sin(t) t_dot
        // y_dot =  r cos(t) t_dot
        // 
        // t is the 'global' angle of r, t = atan2(r.y(), r.x())
        // sin(t) = opp/hyp = r.y() / r
        // cos(t) = adj/hyp = r.x() / r
        // 
        //Simplified:
        // x_dot = -r * (r.y() / r) * t_dot = -r.y()*t_dot
        // y_dot =  r * (r.x() / r) * t_dot =  r.x()*t_dot
  
        const double& yawRate = state.velocity.yaw().getRadians();
        state.velocity.x() += -r.y()*yawRate;
        state.velocity.y() +=  r.x()*yawRate;
      }
    }
  
    return state;
  }

};

#endif
