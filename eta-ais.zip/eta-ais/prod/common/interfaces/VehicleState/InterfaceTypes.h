#ifndef _VehicleStateInterfaceTypes_h_
#define _VehicleStateInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "VehicleState.h"

typedef interfaces::baseTypes::InputInterface<VehicleState> VehicleStateInput;
typedef interfaces::baseTypes::OutputInterface<VehicleState> VehicleStateOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<VehicleStateInput>()
  {
    return "VehicleStateInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<VehicleStateOutput>()
  {
    return "VehicleStateOutput";
  }
}

#endif
