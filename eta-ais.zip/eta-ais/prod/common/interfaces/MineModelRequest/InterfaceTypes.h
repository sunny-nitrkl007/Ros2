#ifndef _MineModelRequestInterfaceTypes_h_
#define _MineModelRequestInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "MineModelRequest.h"

typedef interfaces::baseTypes::InputInterface<MineModelRequest> MineModelRequestInput;
typedef interfaces::baseTypes::OutputInterface<MineModelRequest> MineModelRequestOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<MineModelRequestInput>()
  {
    return "MineModelRequestInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<MineModelRequestOutput>()
  {
    return "MineModelRequestOutput";
  }
}

#endif
