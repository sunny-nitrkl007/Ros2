///////////////////////////////////////////////////////////////////////////////
/// @file      MineModelRequest.h
/// @author    jderence
/// @date      3/9/2009
/// @brief     
///
/// 
///
/// @attention Copyright (C) 2009
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef _MineModelRequest_h_
#define _MineModelRequest_h_

#include <ais/serialization/Datum.h>
#include "ais/interfaces/traits/csvable.h"
#include "ais/interfaces/traits/TextWritable.h"

struct MineModelRequestStorage : public csvable, public TextWritable
{
  MineModelRequestStorage() : m_source("") { };

  std::string m_source; ///< string denoting channel name of the source

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Function to serialize data
  ///
  /// @param ar 
  /// @param version 
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version) {
        ar & m_source;
  };

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Output data in CSV format
  /// @param out - out stream to dump data
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const 
  {
    out("Source",m_source);
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief TextWritable trait
  /// @param out - out stream to dump data
  ///////////////////////////////////////////////////////////////////////////////
    virtual void toStream(std::stringstream& out) const
    {
      out << "MineModel requsted by " << m_source;
    }
};
typedef Datum<MineModelRequestStorage> MineModelRequest;
#endif
