#ifndef _SnapshotCreationRequestInterfaceTypes_h_
#define _SnapshotCreationRequestInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "SnapshotCreationRequest.h"

typedef interfaces::baseTypes::InputInterface<SnapshotCreationRequest> SnapshotCreationRequestInput;
typedef interfaces::baseTypes::OutputInterface<SnapshotCreationRequest> SnapshotCreationRequestOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<SnapshotCreationRequestInput>()
  {
    return "SnapshotCreationRequestInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<SnapshotCreationRequestOutput>()
  {
    return "SnapshotCreationRequestOutput";
  }
}

#endif
