//////////////////////////////////////////////////////////////////////////////
/// @file      SnapshotAssociatedFile.h
/// @author    dtascion
/// @date      01/14/2013
/// @brief     Part of the SnapshotCreationRequest, used for attaching files
///            to a snapshot.
///
/// @attention Copyright (C) 2013
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef SnapshotAssociatedFile_h
#define SnapshotAssociatedFile_h

#include <string>
#include <vector>
#include <boost/serialization/vector.hpp>

///////////////////////////////////////////////////////////////////////////////
/// @brief This is used as part of SnapshotCreationRequest. It allows some
/// requestor to associated a file, already located on the hard drive, to a
/// snapshot.
///////////////////////////////////////////////////////////////////////////////
struct SnapshotAssociatedFile
{
  /// This is the path of the file (relative to the snapshots file) you with to copy
  std::string sourcePath;

  /// This is the name the file should have once it has been copied.
  std::string destinationPath;

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Convenience constructor.
  ///////////////////////////////////////////////////////////////////////////////
  SnapshotAssociatedFile() {}

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Convenience constructor.
  ///////////////////////////////////////////////////////////////////////////////
  SnapshotAssociatedFile(std::string sourcePath, std::string destinationPath) : sourcePath(sourcePath),
                                                                                destinationPath(destinationPath)
  {
  }

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Boost Serialization function for SnapshotCreationRequest
  /// @param ar - boost archive
  /// @param version - version of the class type
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    ar & sourcePath;
    ar & destinationPath;
  };
};

BOOST_CLASS_VERSION(SnapshotAssociatedFile, 1)

#endif
