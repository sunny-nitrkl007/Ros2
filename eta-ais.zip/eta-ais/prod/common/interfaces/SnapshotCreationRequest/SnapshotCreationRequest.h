//////////////////////////////////////////////////////////////////////////////
/// @file      SnapshotCreationRequest.h
/// @author    dtascion
/// @date      10/18/2012
/// @brief     The snapshot bridge periodically publishes its state to the OCS.
///
/// 
///
/// @attention Copyright (C) 2012
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef SnapshotCreationRequest_h
#define SnapshotCreationRequest_h

#include <string>
#include <vector>
#include <boost/serialization/vector.hpp>
#include "ais/interfaces/traits/csvable.h"
#include <ais/serialization/Datum.h>

#include "SnapshotAssociatedFile.h"

///@brief Message from the AutonomySnapshotBridge with details on the current state of logging.
struct SnapshotCreationRequestStorage : public csvable
{
  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Constructor to initialize state of objects
  ///////////////////////////////////////////////////////////////////////////////
  SnapshotCreationRequestStorage() {}

  TimeStamp startTime;     ///< Start time for the snapshot.
  TimeStamp endTime;       ///< End time for the snapshot.
  std::string title;       ///< Title for the snapshot.
  std::string comments;    ///< Any extra comments.
  std::string source;      ///< Source of this snapshot (Minestar, OCS, etc).

  /// For NREC use only, this allows attaching files on the local hard drive to a snapshot,
  /// allowing them to be copied to a destination drive.
  std::vector<SnapshotAssociatedFile> associatedFiles;

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Boost Serialization function for SnapshotCreationRequest
  /// @param ar - boost archive
  /// @param version - version of the class type 
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    ar & startTime;
    ar & endTime;
    ar & title;
    ar & comments;
    ar & source;

    if(version > 1)
    {
      ar & associatedFiles;
    }
  };

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Print SnapshotCreationRequest structure out in CSV format 
  /// @param out - output stream
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const
  {
  }
};

typedef Datum<SnapshotCreationRequestStorage> SnapshotCreationRequest;
BOOST_CLASS_VERSION(SnapshotCreationRequestStorage, 2)

#endif
