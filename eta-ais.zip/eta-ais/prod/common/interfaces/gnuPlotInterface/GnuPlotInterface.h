///////////////////////////////////////////////////////////////////////////////
/// @file      GnuPlotInterface.h
/// @author    jderence
/// @date      12/22/2008
/// @brief     Wrapper around gnuplot process via pipes.
/// - Uses std::string library rather than char*.  
/// - Uses boost filesystem library
/// - Uses std::vector rather than unbound arrays
/// http://ndevilla.free.fr/gnuplot/
///
/// 
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef GnuPlotInterface_h
#define GnuPlotInterface_h

#include <vector>
#include <string>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <boost/filesystem.hpp>

#include <errno.h>
#include <iostream>
#include <iomanip>


static const unsigned int MICRO_TO_MILLI = 1000;

/// @brief Wrapper around gnuplot
class GnuPlotInterface
{
  public:
    GnuPlotInterface(const std::string& title = "", 
                     const std::string& style = "lines");
    ~GnuPlotInterface();

    bool init();
    std::string createTempFile(std::ofstream &file);

    bool isValid();
    bool isValidProgramPath();
    bool setProgramPath(std::string &path);


    void cmd(const std::string &command);

    enum GnuPlotJpegSize
    {
      SMALL,
      MEDIUM,
      LARGE,
      XLARGE,
      XXLARGE
    };
    void saveToJpeg(const std::string &filename = "plot_output", const int& size = 1);
    void saveToPng(const std::string &filename = "plot_output", const int& size = 1);
    void saveToPng(const std::string &filename, const size_t width, const size_t height);


    // label helpers
    void setXAxisLabel(const std::string &label = "x") { setAxisLabel("x",label); };
    void setYAxisLabel(const std::string &label = "y") { setAxisLabel("y",label); };
    void setZAxisLabel(const std::string &label = "z") { setAxisLabel("z",label); };
    void setPlotTitle(const std::string& title = "");

    // format axis helpers
    void formatXAxis(const std::string & format = "%d") { formatAxis("x",format); }; 
    void formatYAxis(const std::string & format = "%d") { formatAxis("y",format); }; 
    void formatZAxis(const std::string & format = "%d") { formatAxis("z",format); }; 

    // helpers
    void setStyle(const std::string& style = "lines");
    void clearPlots() { cmd("clear"); m_nPlots = 0; };
    void resetPlots() { cmd("reset"); removeTempFiles(); };
    void setGrid();

    template <typename T> 
    struct DataPlotType
    {
      std::vector<T> data;
      std::string    label;
      std::string    format;
    };

    template <typename T> 
    struct SetDataPlotType
    {
      std::vector<T> X_data;
      std::vector<T> Y_data;
      std::string    label;
      std::string    format;
    };

    // Plotting functions
    template <typename T> 
      bool plotX(std::vector<T>& x, 
                 const std::string &title = "",
                 const std::string &xlabel= "X",
                 const std::string &ylabel= "Y");

    // array sizes must match
    template <typename T, typename U> 
      bool plotXvsY(std::vector<T>& x, std::vector<U>& y,
                    const std::string &title = "",
                    const std::string &xlabel= "X",
                    const std::string &ylabel= "Y",
                    const std::string &extra="",
                    const std::string &extraStyle="palette");

    template <typename T, typename U, typename V> 
      bool plotXvsYcolor(std::vector<T>& x, 
                         std::vector<U>& y,
                         std::vector<V>& color,
                         const std::string &title = "",
                         const std::string &xlabel= "X",
                         const std::string &ylabel= "Y",
                         bool showColorBox = true);

    template <typename T1, typename T2> 
      bool plotXmanyY(std::vector<T1>& x, std::vector< DataPlotType<T2> >& ys,
                      const std::string &title = "",
                      const std::string &xlabel= "X",
                      const std::string &ylabel= "Y");


    template <typename T1, typename T2> 
      bool addLabelsToPlot(std::vector<T1>&x, 
                           std::vector<T2>&y, 
                           std::vector<std::string>& label);

    template <typename T> 
      bool plotMultiXY(std::vector< SetDataPlotType<T> >& setData,
                      const std::string &title = "",
                      const std::string &xlabel= "X",
                      const std::string &ylabel= "Y");

    template <typename T, typename U, typename V>
      bool plotHeatMap(std::vector<T>& x, std::vector<U>& y, std::vector<V>& z,
                       size_t rowSize,
                       const std::string &title = "",
                       const std::string &xlabel= "X",
                       const std::string &ylabel= "Y");

  protected:
    bool plotData(const std::string& plotCmd, const std::string& name,
                  const std::string& title,
                  const std::string& extra = "",
                  const std::string& extraStyle = "");

  private:
    static const unsigned int MAX_TEMP_FILES = 100;
    FILE * m_gnuPipe;  ///< Pipe to gnuplot process
    std::vector<std::string> m_tempFilesList; ///< List of the names of the temporary files to delete
    int m_nPlots;      ///< Number of active plots
    std::string m_style;   ///< current plotting style selected
    std::string m_gnuplotProgramPath;  ///< path to gnuplot program (defaults to "/usr/bin")
    std::string m_gnuplotProgramName;  ///< path to gnuplot program (defaults to "gnuplot")

    // helpers
    void setAxisLabel(const std::string axis, const std::string &label);
    void formatAxis(const std::string axis, const std::string & format);

    // array
    void removeTempFiles();
};

///////////////////////////////////////////////////////////////////////////////
/// @brief Plot the data along X axis
///
/// @param x - vector data of type <T>
/// @param title - Title of plot
/// @param xlabel - label for x-axis
/// @param ylabel - label for y-axis
/// 
/// Writes x data to temporary file.  Plots the data from temporary file in 
/// gnuplot with the preset style.  All vectors must be of the same size.
///////////////////////////////////////////////////////////////////////////////
template <typename T>
bool GnuPlotInterface::plotX(std::vector<T>& x, 
                             const std::string &title,
                             const std::string &xlabel,
                             const std::string &ylabel)
{
  if ( !isValid() )
  {
    return false;
  }

  if (x.size() == 0)
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Nothing in vector to plot - %s\n", title.c_str());
    return false;
  }

  setXAxisLabel(xlabel);
  setYAxisLabel(ylabel);

  std::ofstream temp_file;
  std::string name = createTempFile(temp_file);
  if (name == "")
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Couldn't create temporary file\n");
    return false;
  }

  // write data to temp file
  for (unsigned int i = 0; i < x.size(); i++)
  {
    temp_file << x[i] << std::endl;
  }
  temp_file.flush();
  temp_file.close();

  // Plot data and set title
  return plotData("plot", name, title);
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Plot the X vs Y data
///
/// @param x - vector data of type <T>
/// @param y - vector data of type <U>
/// @param title - Title of plot
/// @param xlabel - label for x-axis
/// @param ylabel - label for y-axis
/// 
/// Writes x and y data to temporary file.  Plots the data from temporary file in 
/// gnuplot with the preset style.  All vectors must be of the same size.
///////////////////////////////////////////////////////////////////////////////
template <typename T, typename U> 
bool GnuPlotInterface::plotXvsY(std::vector<T>& x, std::vector<U>& y,
                                const std::string &title,
                                const std::string &xlabel,
                                const std::string &ylabel,
                                const std::string &extra,
                                const std::string &extraStyle)
{
  if ( !isValid() )
    return false;

  if (x.size() != y.size())
  {
    fprintf(stderr, "ERROR GnuPlotInterface - X and Y array sizes do not match\n");
    return false;
  }
  if (x.size() == 0) 
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Nothing in vector to plot- %s\n", title.c_str());
    return false;
  }

  setXAxisLabel(xlabel);
  setYAxisLabel(ylabel);

  std::ofstream temp_file;
  std::string name = createTempFile(temp_file);
 
  if (name == "")
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Couldn't create temporary file\n");
    return false;
  }

  // write data to temp file
  for (unsigned int i = 0; i < x.size(); i++)
  {
    temp_file << x[i] << " "<< y[i] << std::endl;
  }
  temp_file.flush();
  temp_file.close();

  // Plot data and set title
  return plotData("plot", name, title, extra, extraStyle);
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Plot the X vs Y data using a third vector to specify the color 
/// of the data.  
///
/// @param x - vector data of type <T>
/// @param y - vector data of type <U>
/// @param color - vector data of type <V> specifying color of plot data
/// @param title - Title of plot
/// @param xlabel - label for x-axis
/// @param ylabel - label for y-axis
/// 
/// Writes x,y, and color data to temporary file.  Plots the x, y data from 
/// temporary file and uses the color data as the palette color.  All vectors
/// must be of the same size.
///////////////////////////////////////////////////////////////////////////////
template <typename T, typename U, typename V> 
bool GnuPlotInterface::plotXvsYcolor(std::vector<T>& x, 
                                     std::vector<U>& y, 
                                     std::vector<V>& color,
                                     const std::string &title,
                                     const std::string &xlabel,
                                     const std::string &ylabel,
                                     bool showColorBox)
{
  if ( !isValid() )
    return false;

  if (x.size() != y.size() || x.size() != color.size())
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Array sizes do not match\n");
    return false;
  }
  if (x.size() == 0) 
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Nothing in vector to plot- %s\n", title.c_str());
    return false;
  }

  setXAxisLabel(xlabel);
  setYAxisLabel(ylabel);

  std::ofstream temp_file;
  std::string name = createTempFile(temp_file);
 
  if (name == "")
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Couldn't create temporary file\n");
    return false;
  }

  // write data to temp file
  for (unsigned int i = 0; i < x.size(); i++)
  {
    temp_file << x[i] << " "<< y[i] << " " << color[i] << std::endl;
  }
  temp_file.flush();
  temp_file.close();

  // send command to gnuplot
  cmd("set pm3d map");
  cmd("set format z \"\"");
  if (showColorBox)
  {
    cmd("set colorbox horiz user origin .25,.05 size .5,.015"); 
  }
  else
  {
    cmd("unset colorbox");
    cmd("unset key");
  }

  // Plot data and set title
  return plotData("splot", name, title, "using 1:2:3", "palette");
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Plot X vs Y1, Y2,..YN data.
///
/// @param x - vector data of type <T>
/// @param ys - vector of DataPlotTypes of type <U> (this vector contains
/// many different Y data sets to chart on the same plot)
/// @param title - Title of plot
/// @param xlabel - label for x-axis
/// @param ylabel - label for y-axis
/// 
/// Writes x,y1,y2..yN to temporary file.  Plots the x,y1,y2..yN data from 
/// temporary file and labels each y data set.  All vectors must be of 
/// the same size.
///////////////////////////////////////////////////////////////////////////////
template <typename T, typename U> 
bool GnuPlotInterface::plotXmanyY(std::vector<T>& x, 
                                  std::vector< DataPlotType<U> > & ys,
                                  const std::string &title,
                                  const std::string &xlabel,
                                  const std::string &ylabel)
{
  if ( !isValid() )
    return false;

  unsigned int array_size = x.size();
  if (array_size == 0) 
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Nothing in vector to plot- %s\n", title.c_str());
    return false;
  }

  for (unsigned int j = 0; j < ys.size(); j++)
  {
    if (array_size != ys[j].data.size())
    {
      fprintf(stderr, "ERROR GnuPlotInterface - Vector Sizes do not match\n");
      return false;
    }
  }

  setXAxisLabel(xlabel);
  setYAxisLabel(ylabel);

  std::ofstream temp_file;
  std::string name = createTempFile(temp_file);

  if (name == "")
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Couldn't create temporary file\n");
    return false;
  }

  // write data to temp file
  for (unsigned int i = 0; i < x.size(); i++)
  {
    temp_file << x[i] ;
    for (unsigned int j = 0; j < ys.size(); j++)
    {
      temp_file << " " << ys[j].data[i];
    }
    temp_file << std::endl;
  }
  temp_file.flush();
  temp_file.close();

  // make sure it wrote the file
  if (!boost::filesystem::exists(boost::filesystem::path(name)))
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Couldn't write to temporary file\n");
    return false;
  }

    double sleep = 500.0;
  // send command to gnuplot
  std::ostringstream msg;
  if (m_nPlots > 0)
  {
    msg << "replot ";
    sleep=1000.0;
  }
  else
    msg << "plot ";

  for (unsigned int j = 0; j < ys.size() ; j++)
  {
    msg <<"\"" << name << "\" using 1:" << (j + 2) 
        << " with " << m_style << " title '" << ys[j].label << "'";
    if ( (j + 1) < ys.size() )
    {
      msg << ", ";
    }
  }
  
  cmd(msg.str());
  usleep( sleep * MICRO_TO_MILLI );
  return true;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Plot the X vs Y data using a third vector to specify labels with
/// each XY data point.  
///
/// @param x - vector data of type <T>
/// @param y - vector data of type <U>
/// @param label - string vector data specifying the label for the data point
/// 
/// Writes x,y, and label data to temporary file.  Plots the x vs y data from 
/// temporary file and uses the third colum data as the label.  All vectors
/// must be of the same size.
///////////////////////////////////////////////////////////////////////////////

template <typename T1, typename T2> 
bool GnuPlotInterface::addLabelsToPlot(std::vector<T1>&x, 
                                       std::vector<T2>&y, 
                                       std::vector<std::string>& label)
{
 if ( !isValid() )
    return false;

  unsigned int array_size = x.size();
  if (array_size == 0) 
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Nothing in vector to plot\n");
    return false;
  }
  if (array_size != y.size() || array_size != label.size())
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Vector Sizes do not match\n");
    return false;
  }

  std::ofstream temp_file;
  std::string name = createTempFile(temp_file);

  if (name == "")
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Couldn't create temporary file\n");
    return false;
  }

  // write data to temp file
  for (unsigned int i = 0; i < x.size(); i++)
  {
    temp_file << x[i] << " " << y[i] << " \"" << label[i].c_str() << "\""<< std::endl;
  }
  temp_file.flush();
  temp_file.close();

  // Plot our data
  plotData("plot", name, "",
           "using 1:2:3 with labels left offset 1,0 point pt 13 lt 9 notitle");

  return true;
}

template <typename T> 
bool GnuPlotInterface::plotMultiXY(std::vector< SetDataPlotType<T> >& setData,
                                  const std::string &title,
                                  const std::string &xlabel,
                                  const std::string &ylabel)
{
  if ( !isValid() )
    return false;

  // make sure there are the same number of x,y elements for each Setdata
  for (unsigned int jj = 0; jj < setData.size(); ++jj)
  {
    if (setData[jj].X_data.size() != setData[jj].Y_data.size())
    {
      fprintf(stderr, "ERROR GnuPlotInterface - Set Data Vector Sizes do not match\n");
      return false;
    }
  }

  setXAxisLabel(xlabel);
  setYAxisLabel(ylabel);
  setGrid();
 
  // create a temp file for each SetData type and store temp file name in inputFiles
  std::vector< std::string > inputFiles;
  for (unsigned int jj = 0; jj < setData.size(); ++jj)
  {

    std::ofstream temp_file;
    std::string name = createTempFile(temp_file);
    if (name == "")
    {
      fprintf(stderr, "ERROR GnuPlotInterface - Couldn't create temporary file\n");
      return false;
    }

    // write data to temp file
    for (unsigned int ii = 0; ii < setData[jj].X_data.size(); ++ii)
    {
      temp_file << setData[jj].X_data[ii] << " " << setData[jj].Y_data[ii] << std::endl;
    }
    temp_file.flush();
    temp_file.close();

    // make sure it wrote the file
    if (!boost::filesystem::exists(boost::filesystem::path(name)))
    {
      fprintf(stderr, "ERROR GnuPlotInterface - Couldn't write to temporary file\n");
      return false;
    }
    inputFiles.push_back(name);
  }
 

  double sleep = 500.0;

  // send command to gnuplot
  std::ostringstream msg;
  if (m_nPlots > 0)
  {
    msg << "replot ";
    sleep=1000.0;
  }
  else
    msg << "plot ";


  for (unsigned int numFile = 0; numFile < inputFiles.size(); ++numFile)
  {
    msg << "\"" << inputFiles[numFile] << "\" using 1:2 with " << m_style << " title '" << setData[numFile].label <<"'";

    if ( (numFile + 1) < inputFiles.size())
    {
      msg << ", ";
    }
  }

  cmd(msg.str());
  usleep( sleep * MICRO_TO_MILLI );
  return true;
}

template <typename T, typename U, typename V>
bool GnuPlotInterface::plotHeatMap(std::vector<T>& x, std::vector<U>& y,
                                   std::vector<V>& z,
                                   size_t rowSize,
                                   const std::string &title,
                                   const std::string &xlabel,
                                   const std::string &ylabel)
{
  if ( !isValid() )
    return false;

  if (x.size() != y.size())
  {
    fprintf(stderr, "ERROR GnuPlotInterface - X and Y array sizes do not match\n");
    return false;
  }
  if (x.size() != z.size())
  {
    fprintf(stderr, "ERROR GnuPlotInterface - X and Z array sizes do not match\n");
    return false;
  }
  if (x.size() == 0)
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Nothing in vector to plot- %s\n", title.c_str());
    return false;
  }

  setXAxisLabel(xlabel);
  setYAxisLabel(ylabel);

  std::ofstream temp_file;
  std::string name = createTempFile(temp_file);

  if (name == "")
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Couldn't create temporary file\n");
    return false;
  }

  // write data to temp file
  size_t counter = 0;
  for (unsigned int i = 0; i < x.size(); i++)
  {
    // Put a blank line after each row
    if (counter >= rowSize)
    {
      temp_file << std::endl;
      counter = 0;
    }

    temp_file << x[i] << " " << y[i] << " " << z[i] << std::endl;

    counter++;
  }
  temp_file.flush();
  temp_file.close();

  // Plot data and set title
  return plotData("plot", name, title);
}

#endif
