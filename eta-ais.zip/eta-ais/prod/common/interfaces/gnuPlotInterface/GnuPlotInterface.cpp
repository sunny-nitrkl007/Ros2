///////////////////////////////////////////////////////////////////////////////
/// @file      GnuPlotInterface.cpp
/// @author    jderence
/// @date      12/22/2008
/// @brief     Implementation of GnuPlotInterface: wrapper around gnuplot
///
/// 
///
/// @attention Copyright (C) 2008
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////


#include "GnuPlotInterface.h"
#include "ais/log/Logger.h"
#include <errno.h>

using namespace std;

///////////////////////////////////////////////////////////////////////////////
/// @brief Constructor for GnuPlotInterface.  Calls intialize to set up the pipe
/// to gnuplot.  
///
/// @param title - title for plot session
/// @param style - plot style
/// 
/// 
///////////////////////////////////////////////////////////////////////////////
GnuPlotInterface::GnuPlotInterface(const string& title, 
                                   const string& style)
: m_gnuPipe(NULL),
  m_nPlots(0),
  m_style(style),
  m_gnuplotProgramPath("/usr/bin/"),
  m_gnuplotProgramName("gnuplot")
{
  init();
  setPlotTitle(title);
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Destructor:  Close pipe, remove any temporary files
///////////////////////////////////////////////////////////////////////////////
GnuPlotInterface::~GnuPlotInterface()
{
  // clean up temporary files when deleted!
  removeTempFiles();

  // close the pipe to gnuplot process
  if (m_gnuPipe)
    pclose(m_gnuPipe);
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Delete any tempoary files 
///////////////////////////////////////////////////////////////////////////////
void GnuPlotInterface::removeTempFiles()
{
  // clean up temporary files
  for (unsigned int i = 0; i < m_tempFilesList.size(); i++)
  {
    remove( m_tempFilesList.at(i).c_str() );
  }
  m_tempFilesList.clear();
  m_nPlots = 0;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Initialize.  Create a pipe to gnuplot process
/// @return  true if sucessfully created plot
///////////////////////////////////////////////////////////////////////////////
bool GnuPlotInterface::init()
{
  // make sure program path is valid
  if (!isValidProgramPath())
  {
    m_gnuPipe = NULL;
    fprintf(stderr, "ERROR GnuPlotInterface::init()  Invalid path to program %s\n",
            (m_gnuplotProgramPath + m_gnuplotProgramName).c_str());
    return false;
  }

  // open pipe.
  m_gnuPipe = popen((m_gnuplotProgramPath + m_gnuplotProgramName).c_str(), "w");
  if (!m_gnuPipe)
  {
    int errsv = errno;
    m_gnuPipe = NULL;
    fprintf(stderr, "ERROR GnuPlotInterface::init()  COULD NOT OPEN PIPE TO GNUPLOT.  errno=%d %s\n", errsv, strerror(errsv));
    return false;
  }

  cmd("set output");
  cmd("set terminal jpeg");
  // Pipe to process is open!
  return true;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Create a temporary file to output the data needed for plotting.
/// Uses mkstemp to create a string of random characters.  
///
/// @return  - string denoting temporary file name.  
/// 
/// @param file - ofstream to use as file
///////////////////////////////////////////////////////////////////////////////
string GnuPlotInterface::createTempFile(ofstream &file)
{
  if (m_tempFilesList.size() == MAX_TEMP_FILES)
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Reached Max number of temporary files!11\n");
    return "";
  }

  char name[] = "/tmp/gnuplot_i_XXXXXX";
  int fd = mkstemp(name);
  if (fd == -1)
  {
    fprintf(stderr, "ERROR GnuPlotInterface -Could not modify temporary file\n");
    return "";
  }

  //Now that the file exist, we can close it can open as an ofstream
  close(fd);
  file.open(name);
  if (!file.is_open())
  {
    fprintf(stderr, "ERROR GnuPlotInterface -Could not open temporary file\n");
    return "";
  }

  file << setprecision(16);

  // debug
  //fprintf(stderr,"Temp file is '%s'\n", name);

  // save it in our temp file list so we can remove it later
  m_tempFilesList.push_back(name);
  return name;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Use boost::filesystem function to verify path is valid
///
/// @return  true if path exists and is a regular file
///////////////////////////////////////////////////////////////////////////////
bool GnuPlotInterface::isValidProgramPath()
{
  boost::filesystem::path dir_path(m_gnuplotProgramPath);
  boost::filesystem::path file_path((m_gnuplotProgramPath + m_gnuplotProgramName));

  return ( boost::filesystem::exists(dir_path) &&
           boost::filesystem::is_regular(file_path));
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Set the appropriate program path to find gnuplot.
///
/// @return  true if path exists
/// 
/// @param path - path defining directory location for gnuplot process
///////////////////////////////////////////////////////////////////////////////
bool GnuPlotInterface::setProgramPath(string &path)
{
  boost::filesystem::path dir_path(path);
  bool ok = boost::filesystem::exists(dir_path);

  if (ok)
  {
    m_gnuplotProgramPath = path;
    return true;
  }

  return false;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Checks for a valid pipe to gnuplot process
///
/// @return  false is pipe is null
/// 
/// 
///////////////////////////////////////////////////////////////////////////////
bool GnuPlotInterface::isValid()
{
  if (! m_gnuPipe )
  {
    fprintf(stderr,"ERROR GnuPlotInterface - No pipe open to gnuplot process!");
    return false;
  }
  return true;
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Send a command to gnuplot process.  This function is the main way
/// of interacting with the pipe.  
///
/// @param msg - command message in string format.
/// 
/// 
///////////////////////////////////////////////////////////////////////////////
void GnuPlotInterface::cmd(const string &msg)
{
  // get out if pipe not open
  if ( !isValid() )
    return;

  // add terminating character.
  fputs( (msg + "\n").c_str(), m_gnuPipe);
  fflush(m_gnuPipe);

  LOG_DEBUG_S("CMD: " << msg);

  // if cmdstr contains plot m_nplots++
  if (msg.find("plot") != string::npos)
    m_nPlots++;  // need to keep track of how many plots to determine if we call "replot"
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Save the next plot command as a jpeg image.
///
/// @param filename - File name for jpeg image
/// @param size - desired size of jpeg image
///////////////////////////////////////////////////////////////////////////////
void GnuPlotInterface::saveToJpeg(const string &filename, const int& size)
{
  switch ((GnuPlotJpegSize)size)
  {
    case SMALL:  
      cmd("set terminal jpeg medium size 640,480 nocrop "); break;
    case MEDIUM: 
      cmd("set terminal jpeg medium size 800,600 nocrop "); break;
    case LARGE: 
      cmd("set terminal jpeg medium size 1024,768 nocrop "); break;
    case XLARGE: 
      cmd("set terminal jpeg medium size 1600,1200 nocrop "); break;
    case XXLARGE:
      cmd("set terminal jpeg medium size 3200,2400 nocrop "); break;
    default:
      cmd("set terminal jpeg medium size 800,600 nocrop "); break;
  }
  
  ostringstream msg;;
  msg << "set output \"" << filename << ".jpeg\" ";
  cmd(msg.str());
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Save the next plot command as a png image.
///
/// @param filename - File name for png image
/// @param size - desired size of png image
///////////////////////////////////////////////////////////////////////////////
void GnuPlotInterface::saveToPng(const string &filename, const int& size)
{
  switch ((GnuPlotJpegSize)size)
  {
    case SMALL:  
      saveToPng(filename, 640, 480); break;
    case MEDIUM: 
      saveToPng(filename, 800, 600); break;
    case LARGE: 
      saveToPng(filename, 1024, 768); break;
    case XLARGE: 
      saveToPng(filename, 1600, 1200); break;
    case XXLARGE:
      saveToPng(filename, 3200, 2400); break;
    default:
      saveToPng(filename, 800, 600); break;
  }
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Save the next plot command as a png image.
///
/// @param filename - File name for png image
/// @param size - desired size of png image
///////////////////////////////////////////////////////////////////////////////
void GnuPlotInterface::saveToPng(const string &filename,
                                 const size_t width, const size_t height)
{
  ostringstream term;

  term << "set terminal png medium size " << width << "," << height
       << " nocrop ";
  cmd(term.str());

  ostringstream msg;
  msg << "set output \"" << filename << ".png\" ";
  cmd(msg.str());
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Helper function to set the style of the plot.  The input style
/// must contain one of the keywords for gnuplot style or the function will
/// default to "lines" style
///
/// @param style - input style command as string 
///////////////////////////////////////////////////////////////////////////////
void GnuPlotInterface::setStyle(const string& style) 
{ 
  if (style.find("boxerrorbars") != string::npos ||
      style.find("boxes") != string::npos ||
      style.find("dots") != string::npos ||
      style.find("errorbars") != string::npos ||
      style.find("image") != string::npos ||
      style.find("impulses") != string::npos ||
      style.find("lines") != string::npos ||
      style.find("linespoints") != string::npos ||
      style.find("points") != string::npos ||
      style.find("steps") != string::npos)
  {
    m_style = style; 
  }
  else
  {
    fprintf(stderr,
            "ERROR GnuPlotInterface -setStyle - Unknown style '%s' using 'lines'\n",
            style.c_str());
  }
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Format the axis
///
/// @param axis - axis to set (example:  x, y, z)
/// @param format - style to format axis (example:  %.3f, %d
/// 
/// 
///////////////////////////////////////////////////////////////////////////////
void GnuPlotInterface::formatAxis(const string axis, const string & format)
{
  ostringstream msg;;
  msg << "set format "<< axis << "\"" << format << "\" ";
  cmd(msg.str());
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Set the string label for the axis
///
/// @param axis - axis label to set (example:  x, y,z)
/// @param label - string to set axis label
///////////////////////////////////////////////////////////////////////////////
void GnuPlotInterface::setAxisLabel(const string axis, const string &label)
{
  ostringstream msg;
  msg << "set "<< axis << "label \"" << label <<"\" ";
  cmd(msg.str());
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Set the Plot's Title
///
/// @param title - value to set title
///////////////////////////////////////////////////////////////////////////////
void GnuPlotInterface::setPlotTitle(const string& title)
{
  ostringstream msg;
  msg << "set title \""<< title <<"\" ";
  cmd(msg.str());
}


///////////////////////////////////////////////////////////////////////////////
/// @brief Set the grid
///////////////////////////////////////////////////////////////////////////////
void GnuPlotInterface::setGrid()
{
  ostringstream msg;
  msg << "set grid ";
  cmd(msg.str());
}

///////////////////////////////////////////////////////////////////////////////
/// @brief Plot the given data with the given command.
///
/// @param plotCmd - command to use for plotting ("plot", or "splot")
/// @param dataFile - the data file to plot
/// @param title - the title of the plot (make "" to skip)
/// @param extra - extra commands inserted after the file is loaded and before
///                the title.
///////////////////////////////////////////////////////////////////////////////
bool GnuPlotInterface::plotData(const std::string& plotCmd,
                                const std::string& dataFile,
                                const std::string& title,
                                const std::string& extra,
                                const std::string& extraStyle)
{
  // make sure it wrote the file
  if (!boost::filesystem::exists(boost::filesystem::path(dataFile)))
  {
    fprintf(stderr, "ERROR GnuPlotInterface - Couldn't write to temporary "
            "file: \"%s\"\n", dataFile.c_str());
    return false;
  }

  double sleep = 500.0;
  // send command to gnuplot
  std::ostringstream msg;
  if (m_nPlots > 0)
  {
    msg << "replot ";
    sleep=1000.0;
  }
  else
    msg << plotCmd << " ";

  msg <<"\"" << dataFile << "\" " << extra << " ";

  if (title != "")
    msg << "title \"" << title << "\" ";

  msg << "with " << m_style <<  " " << extraStyle;
  cmd(msg.str());
  usleep( sleep * MICRO_TO_MILLI );
  return true;
}
