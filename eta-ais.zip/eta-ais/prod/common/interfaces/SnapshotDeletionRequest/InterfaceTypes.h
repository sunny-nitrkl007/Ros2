#ifndef _SnapshotDeletionRequestInterfaceTypes_h_
#define _SnapshotDeletionRequestInterfaceTypes_h_

#include <ais/interfaces/baseTypes/InputInterface.h>
#include <ais/interfaces/baseTypes/OutputInterface.h>
#include "SnapshotDeletionRequest.h"

typedef interfaces::baseTypes::InputInterface<SnapshotDeletionRequest> SnapshotDeletionRequestInput;
typedef interfaces::baseTypes::OutputInterface<SnapshotDeletionRequest> SnapshotDeletionRequestOutput;

namespace interfaces
{
  template<>
  inline std::string getDefaultInterfaceName<SnapshotDeletionRequestInput>()
  {
    return "SnapshotDeletionRequestInput";
  }

  template<>
  inline std::string getDefaultInterfaceName<SnapshotDeletionRequestOutput>()
  {
    return "SnapshotDeletionRequestOutput";
  }
}

#endif
