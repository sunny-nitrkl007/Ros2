//////////////////////////////////////////////////////////////////////////////
/// @file      SnapshotDeletionRequest.h
/// @author    dtascion
/// @date      10/18/2012
/// @brief     The snapshot bridge periodically publishes its state to the OCS.
///
/// 
///
/// @attention Copyright (C) 2012
/// @attention National Robotics Engineering Center
/// @attention Carnegie Mellon University
/// @attention All rights reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef SnapshotDeletionRequest_h
#define SnapshotDeletionRequest_h

#include <string>
#include <vector>
#include <boost/serialization/vector.hpp>
#include "ais/interfaces/traits/csvable.h"

///@brief Message from the AutonomySnapshotBridge with details on the current state of logging.
struct SnapshotDeletionRequestStorage : public csvable
{
  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Constructor to initialize state of objects
  ///////////////////////////////////////////////////////////////////////////////
  SnapshotDeletionRequestStorage(): startTime(), endTime(), title(""), snapshot_guid(""){}

  TimeStamp startTime;      ///< Start time for the snapshot.
  TimeStamp endTime;        ///< End time for the snapshot.
  std::string title;        ///< Title for the snapshot.
                            ///
  std::string snapshot_guid;///< Globally unique identifier to identify which snapshot to remove.  
                            ///  This is an OPTIONAL setting that will override the startTime+endTime+title fields above

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Boost Serialization function for SnapshotDeletionRequest
  /// @param ar - boost archive
  /// @param version - version of the class type 
  ///////////////////////////////////////////////////////////////////////////////
  template <class Archive>
  void serialize(Archive &ar, unsigned int version)
  {
    switch (version)
    {
    case 1:
      ar& startTime; 
      ar & endTime;
      ar & title;

    case 2:  
      ar& startTime; 
      ar & endTime;
      ar & title;
      ar & snapshot_guid;  // added in the optional GUID Field
    }


  };

  ///////////////////////////////////////////////////////////////////////////////
  /// @brief Print SnapshotDeletionRequest structure out in CSV format 
  /// @param out - output stream
  ///////////////////////////////////////////////////////////////////////////////
  void toCsv(CsvOutStream& out) const
  {
  }
};

typedef Datum<SnapshotDeletionRequestStorage> SnapshotDeletionRequest;
BOOST_CLASS_VERSION(SnapshotDeletionRequestStorage, 2)

#endif
