#!/bin/sh
#
# file:   changeCatEnvToHere.sh
# author: Herbert Moskovchenko
# date:   2017/06/07
#
# Copyright (C) 2017
#
# Change enviornment variables to here ($PWD) or to parent directory of launchSystem script.
# Assumes run-time environment directory structure is in place at current location.
#
# Just source this file to set the environment variables properly for this scope.
# hint:  it's easier if you add this to your .bashrc: alias here="source . changeCatEnvToHere.sh"
# then you can just type "here" in your terminal!
#

if [[ -d "${LAUNCHSYSTEM_PARENT_DIR}" ]]; then
    export CAT_DIR=${LAUNCHSYSTEM_PARENT_DIR}
else
    export CAT_DIR=$PWD
fi

export CAT_CONFIG_DIR=${CAT_DIR}/config
export LD_LIBRARY_PATH=${CAT_DIR}/lib

echo    "My home directory is    ${HOME}"
echo    "My directory is         ${CAT_DIR}"
echo    "My CONFIG_DIR is        ${CAT_CONFIG_DIR}"
echo    "My LIBRARY_PATH is      ${LD_LIBRARY_PATH}"
