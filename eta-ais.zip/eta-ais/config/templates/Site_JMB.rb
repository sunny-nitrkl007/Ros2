###################################################################
#  Site_JMB.rb : All Site information local to JMB, PA, USA
###################################################################

puts "Loading Site_JMB configuration..."
# NOTE: Assumes IPAddressMap has already been loaded.

SiteLocation = {
  # Position information
    #Must configure either localCoordSystem file or utmZone, but not both
    "conversionType" => 0,  #0 = localCoordSys File, 1 = UTM Conversion
    "localCoordSystem" => "/coordSystem/Site_JMB.dc",  # Local Coordinate System configuration
                                                         # (referenced from CAT_DIR, and requires leading "/" )
    "useMappingFrame" => true,  # specifies whether to scale orientations and velocities to the local frame.
    "utmZone" => 51,            # UTM configuration -- # Jimblebar  (NOT USED IF IN LOCAL COORD)

  # *** Minestar communication settings ***
  #From TmacServer -- TmacHostConfig-----------
    #Set to true to allow incoming messages not originating from the hosts configured here
    "AllowNewHosts" => false,
  	
    "NumberOfHosts" => 2,
    "000_HostIp" => "10.113.92.12", 
    "000_HostPort" => 16020, # port for MineStar
    "000_HostName" => "Minestar_Unicast",
    
    "001_HostIp" => "10.113.92.12", 
    "001_HostPort" => 13000,
    "001_HostName" => "Minestar_Multicast", 
  #END From TmacServer -- TmacHostConfig-----------
  #From TmacServer -- TmacServerConfig -----------
    "NumberOfServers" => 3,
  
    ## UDP Unicast Receiver
    "000_ServerIP" => "INADDR_ANY",
    "000_ServerPort" => 10001, # port for MineStar Unicasst UDP
    "000_ServerName" => "AmtUnicast",
    "000_ConnectionType" => "UDP",
  
    ## UDP Multicast Receiver
    "001_ServerIP" => "INADDR_ANY",
    "001_MulticastGroup" => "239.239.75.255", # MineStar Multicast UDP group,
    "001_ServerPort" => 13000, # MineStar Multicast UDP
    "001_ServerName" => "AmtMulticast",
    "001_ConnectionType" => "UDP",
  
    ## TCP Receiver
    "002_ServerIP" => "INADDR_ANY",
    "002_ServerPort" => 20001, # port for MineStar TCP
    "002_ServerName" => "AmtTcp",
    "002_ConnectionType" => "TCP",
    "002_NumberConnections" => 1,
  #END From TmacServer -- TmacServerConfig -----------


  # Directory containing default M* mwf files for the site
  "defaultMwfStorageLocation" => "/mineModel/",

  # Background maps for OCS
# "BackgroundRasterMapPath" => ENV['CAT_DIR'] + "/imagery/JMB/JMB.tif" ,  # no map yet

  # Calibration Pole points
  # Pole position surveyed, averaged, corrected, and entered into site file 30Jun2013 by Matt Holmes
  # Correction was necessary due to differences between rover base station and AHPT base station
  "poleEasting_m" => 54429.5675,
  "poleNorthing_m" => 211507.92,
  "poleAltitude_m" => 521.44975,
}


