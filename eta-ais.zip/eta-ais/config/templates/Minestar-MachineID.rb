#
# File = Minestar-MachineID.rb
#
# This is a template.
# Copy it to $HOME/etc and modify MachineID accordingly.
#
# Tahoe40 = 9
# Tahoe43 = 10
#
RobotConfiguration = {
  "MachineID" => 9,
}
