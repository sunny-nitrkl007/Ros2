###################################################################
#  Site_FMG.rb : All Site information local to FMG, PA, USA
###################################################################

puts "Loading Site_FMG configuration..."
# NOTE: Assumes IPAddressMap has already been loaded.

SiteLocation = {
#**********************************************************#
#**** EDIT THE SITE POSITION SETUP INFORMATION BELOW ******#
#**********************************************************#
	
	#******* EDIT THIS PER  SITE *******#
	#******* localCoordSystem **********#
	#Local Coordinate System configuration
	#Referenced from CAT_DIR, and requires leading "/"
	"localCoordSystem" => "/../etc/filename.dc",  

	#******* DEFAULT OK ****************#
    #******* converstionType ***********#
	#******* Must be set to 0 **********#
	#0 = localCoordSys File, 1 = UTM Conversion
	#Should always be set to 0 to ensure a localCoordSystem is used. 
    "conversionType" => 0,  	
                                                         
	#******* DEFAULT OK ****************#
	#******* useMappingFrame ***********#
	#Specifies whether to scale orientations and velocities to the local frame 
	#This should always be set to true
	"useMappingFrame" => true,  

	#********** DEFAULT OK *************#    
	#*********** utmZone ***************#
	#LEGACY -- NOT USED
	#NOT USED IF IN LOCAL COORD
	"utmZone" => 51,            

	
#******************************************************************#
#*** EDIT THE MINESTAR COMMS TMAC HOST GENERAL SETTINGS BELOW *****#
#******************************************************************#
    
	#************* DEFAULT OK ****************#
	#*********** AllowNewHosts ***************#
    #Set to true to allow incoming messages not originating from the hosts configured here
	#This should always be set to false
    "AllowNewHosts" => false, 					
  	
	#************* DEFAULT OK ****************#
	#*********** NumberOfHosts ***************#
	#This should always be set to 2
    "NumberOfHosts" => 2, 

	
#**********************************************************************#
#*** EDIT THE MINESTAR COMMS TMAC HOST UNICAST SETTINGS BELOW *********#
#**********************************************************************#	
	
	#************* DEFAULT OK ****************#
	#*********** 000_HostName ****************#
	#This should always be set to Minestar_Unicast
	"000_HostName" => "Minestar_Unicast",	
	
	#********* EDIT THIS PER  SITE ***********#
	#*********** 000_HostIp ******************#
	#This is the MineStar Server IP Address
    "000_HostIp" => "172.30.45.108", 			
    					
	#********* EDIT THIS PER  SITE ***********#					
	#*********** 000_HostPort ****************#
	#This is the MineStar TMAC Port
	"000_HostPort" => 16020, 
	

#**********************************************************************#
#*** EDIT THE MINESTAR COMMS TMAC HOST MULTICAST SETTINGS BELOW *******#
#**********************************************************************#	
	
	#************* DEFAULT OK ****************#
	#*********** 001_HostName ****************#
	#this should always be set to MineStar_Multicast
    "001_HostName" => "Minestar_Multicast", 

	#********* EDIT THIS PER SITE ************#
	#*********** 001_HostIp ******************#
	#This is the same as 000_HostIp and also 
	#the MineStar server IP Address
    "001_HostIp" => "172.30.45.108", 

	#************* DEFAULT OK ****************#
	#*********** 0001_HostPort ***************#
	#the MineStar server Multicast Port, there is no option to change this in MineStar
    "001_HostPort" => 13000,
	

#******************************************************************#
#*** EDIT THE MINESTAR COMMS TMAC SERVER GENERAL SETTINGS BELOW ***#
#******************************************************************#
  
	#************* DEFAULT OK ******************#
	#*********** NumberOfServers ***************#
	"NumberOfServers" => 3,
 
#******************************************************************#
#*** EDIT THE TRUCK TMAC SERVER UNICAST SETTINGS BELOW ************#
#******************************************************************# 

    #************* DEFAULT OK ******************#
	#*********** 000_ServerName*****************#
	#This should always be set to the AmtUnicast
    "000_ServerName" => "AmtUnicast",
	
	#************* DEFAULT OK ******************#
	#*********** 000_ConnectionType ************#
	#This should always be set to the UDP
    "000_ConnectionType" => "UDP",
	
	#************* DEFAULT OK ******************#
	#*********** 000_ServerIP ******************#
	#This should always be set to the INADDR_ANY
    "000_ServerIP" => "INADDR_ANY",
	
	#************** DEFAULT OK ***************#
	#*********** 000_ServerPort **************#
    #port for MineStar Unicasst UDP
	"000_ServerPort" => 10001, 
	
#********************************************************************#
#*** EDIT THE TRUCK TMAC SERVER MULTICAST SETTINGS BELOW ************#
#********************************************************************# 

	#************* DEFAULT OK ******************#
	#*********** 001_ServerName ****************#
	#This should always be set to the AmtUnicast
	"001_ServerName" => "AmtMulticast",
	
	#************* DEFAULT OK ******************#
	#*********** 001_ConnectionType ************#
	#This should always be set to the UDP
    "001_ConnectionType" => "UDP",

	#************* DEFAULT OK ******************#
	#*********** 001_ServerIP ******************#
	#This should always be set to the INADDR_ANY
	"001_ServerIP" => "INADDR_ANY",
	
	#********* EDIT THIS PER SITE ************#
	#*********** 001_MulticastGroup **********#	
	# MineStar Mulicast UDP group,
    "001_MulticastGroup" => "224.100.100.100", 
	
	#********* EDIT THIS PER SITE ************#
	#*********** 001_ServerPort **************#
	#the truck server Multicast Port, there is no option to change this in MineStar
    # MineStar Mulicast UDP port
	"001_ServerPort" => 13001, 
    

  
#********************************************************************#
#*** EDIT THE TRUCK TMAC SERVER TCP SETTINGS BELOW ******************#
#********************************************************************#   
  	
	#************* DEFAULT OK ******************#
	#*********** 002_ServerName ****************#
	#This should always be set to AmtTcp		
	"002_ServerName" => "AmtTcp",
	
	#************* DEFAULT OK ******************#
	#*********** 002_ConnectionType ************#
	#This should always be set to TCP
    "002_ConnectionType" => "TCP",  
	
	#************* DEFAULT OK ******************#
	#*********** 002_ServerIP ******************#
	#TCP Receiver
	#This should always be set to the INADDR_ANY
    "002_ServerIP" => "INADDR_ANY",
	
	#************* DEFAULT OK ******************#
	#*********** 002_NumberConnections *********#
	#This should always be set to 1	
    "002_NumberConnections" => 1,
	
	#************* DEFAULT OK ******************#
	#*********** 002_ServerPort ****************#
	#Port for MineStar TCP
	#This should always be set to 20001	
    "002_ServerPort" => 20001, 
    
	
	
#********************************************************************#
#************ EDIT THE TRUCK DEFAULT MWF FILE LOCATION **************#
#********************************************************************# 
  # Directory containing default M* mwf files for the site
  "defaultMwfStorageLocation" => "/config/engineering/mineModels/FMG/",

#********************************************************************#
#**** (Optional) EDIT THE TRUCK PERCEPTION CALIBRATION DISTANCE *****#
#********************************************************************#   
  # Perception Calibration Settings
  # Distance (m) from the center of the starting ellipse to the calibration pole for
  # each data collection path.
  "distanceFromStartingEllipseCenterToPole_m" => 70.0,
  
#********************************************************************#
#**** (Optional) EDIT THE TRUCK PERCEPTION CALIBRATION ROTATION *****#
#********************************************************************#   
  # The path rotation (deg) with respect to the calibration pole, where positive values result
  # in a CCW rotation and negative values result in a CW rotation. By default (0 deg), the legs 
  # of the calibration path lie in the cardinal directions.
  "pathRotation_Deg" => 0.0,    
  
#********************************************************************#
#************ EDIT THE TRUCK CALIBRATION POLE LOCATION **************#
#********************************************************************# 
  # Calibration Pole points     ###  No calibration pole point yet ###
  "poleEasting_m" => 603190.55,
  "poleNorthing_m" => 4479198.76,
  "poleAltitude_m" => 267.32,

#********************************************************************#
#***** EDIT THE LOCATION FOR THE OCS BACKGROUND MAP *****************#
#********************************************************************# 
# Background maps for OCS
# "BackgroundRasterMapPath" => ENV['CAT_DIR'] + "/imagery/FMG/FMG.tif" ,  # no map yet

  
  }


