MetaData = 
{
  "Robot" => "RBT00396",
  "CalibrationTimeStamp" => 1150552829.361591,
  "CalibrationTimeDate" => "06/21/2016 14:00:12",
}

GamsInstallationParameters = 
{
  "GamsAntSeparationValue_m" => 2.000000,
  "GamsVectorXValue_m" => 0.000000,
  "GamsVectorYValue_m" => 2.004000,
  "GamsVectorZValue_m" => 0.000000,
  "maximumHeadingErrorRmsForCalibration" => 0.000000,
  "headingCorrection" => 0.000000,
  "baselineVectorStandardDeviation" => 0.100000,
}
