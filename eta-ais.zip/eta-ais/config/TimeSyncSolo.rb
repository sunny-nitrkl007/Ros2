require "commonLoad.rb"
# TimeSyncSolo.rb
################################################
# In this configuration, the timeSync task will attempt to connect to the
# serial port for PPS input and listen for GPS time messages in order to
# properly set the TimeSyncModel.
################################################


load "commonTaskParams.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
  "GPSTimeInput" => InterfaceDefs::GPSTimeInput,
 "AutonomyConditionMessageOutput" => InterfaceDefs::AutonomyConditionMessageOutput,
  "TimeSyncStatisticsOutput" => InterfaceDefs::TimeSyncStatisticsOutput,
    "LoggerCommentsOutput" => InterfaceDefs::LoggerCommentsOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "error",
  "cycleRate_hz" => 1,  # cycle every second
  "requireGPSTimeSynchronizationOnStart" => false, # ALLOW this process to start without synchronization

#Source of timesync
  "timeSyncSourceFromHardware" => true,
  "ppsSerialPort" => "/dev/serial_irq",

#Service role for timesync
  "serviceRoleIsMaster" => false,    # no service role to play

} )

Execution = {
  "executableName" => "timeSyncObject",
}


