###################################################################
#  Site_L8.rb : All Site information local to Tuscon, AZ USA
###################################################################

puts "Loading Site configuration for Minestar 172.20.225.85 ..."
# NOTE: Assumes IPAddressMap has already been loaded.

SiteLocation = 
{
  #From TmacServer -- TmacHostConfig-----------
    #Set to true to allow incoming messages not originating from the hosts configured here
    "AllowNewHosts" => true,
  	
    "NumberOfHosts" => 2,
    "000_HostIp" => "172.20.20.20", 
    "000_HostPort" => 16020, # port for MineStar
    "000_HostName" => "Minestar_Unicast",
    
    "001_HostIp" => "172.20.20.20", 
    "001_HostPort" => 13000,
    "001_HostName" => "Minestar_Multicast", 
  #END From TmacServer -- TmacHostConfig-----------

  #From TmacServer -- TmacServerConfig -----------
    "NumberOfServers" => 3,
  
    ## UDP Unicast Receiver
    "000_ServerIP" => "INADDR_ANY",
    "000_ServerPort" => 3801, # port for MineStar Unicasst UDP
    "000_ServerName" => "AmtUnicast",
    "000_ConnectionType" => "UDP",
  
    ## UDP Multicast Receiver
    "001_ServerIP" => "INADDR_ANY",
    "001_MulticastGroup" => "224.100.100.100", # MineStar Mulicast UDP group,
    "001_ServerPort" => 13000, # MineStar Mulicast UDP
    "001_ServerName" => "AmtMulticast",
    "001_ConnectionType" => "UDP",
  
    ## TCP Receiver
    "002_ServerIP" => "INADDR_ANY",
    "002_ServerPort" => 20001, # port for MineStar TCP
    "002_ServerName" => "AmtTcp",
    "002_ConnectionType" => "TCP",
    "002_NumberConnections" => 1,
  #END From TmacServer -- TmacServerConfig -----------
}

