########################################################################################
#
#  File = ApplicationTable.rb
#
#  This script provides a mapping from a machine serial number to
#  1) machine name which is an identifier used to select a set of configuration data
#  2) scenario path - a path relative to $CAT_CONFIG_DIR 
#
#  Each MSN has format ABC12345 with ABC called prefix and 12345 called index.
#
#  Sections in this script are MSN prefixes with each section having at least one range.

########################################################################################

FDB = {
#   key     min,     max,   machineName,      scenarioPath 
#  -----   -----    -----   ------------      ---------------
   "00"=>["00000", "99999", "793FDB_00",      "production"],
}

SSP = {
#   key     min,     max,   machineName,      scenarioPath 
#  -----   -----    -----   ------------      ---------------
   "00"=>["00000", "00116", "793SSP_00",      "production"],
   "01"=>["00117", "00117", "793SSP_01",      "production/auxiliaryApplanix"],
   "02"=>["00118", "99999", "793SSP_00",      "production"],
}

RBT = {
#   key     min,     max,   machineName,      scenarioPath 
#  -----   -----    -----   ------------      ---------------
   "00"=>["00000", "00110", "793SSP_00",      "production"],
   "01"=>["00111", "00111", "793SSP_01",      "production/auxiliaryApplanix"],
   "02"=>["00112", "00121", "793SSP_00",      "production"],
   "03"=>["00122", "00122", "793SSP_01",      "production/auxiliaryApplanix"],
   "04"=>["00123", "99999", "793SSP_00",      "production"],
}

LAJ = {
#   key     min,     max,   machineName,      scenarioPath 
#  -----   -----    -----   ------------      ---------------
   "00"=>["00000", "99999", "797LAJ_00",      "production"],
}

AT7 = {
#   key     min,     max,   machineName,      scenarioPath 
#  -----   -----    -----   ------------      ---------------
   "00"=>["00000", "00460", "797LAJ_00",      "production"],
   "01"=>["00461", "00461", "797LAJ_00",      "production/dataTruck"], # LAJ00461 converted to AT700461 (Kearl data truck)
   "02"=>["00462", "99999", "797LAJ_00",      "production"],
}

TAH = {
#   key     min,     max,   machineName,      scenarioPath 
#  -----   -----    -----   ------------      ---------------
   "00"=>["00001", "00045",  "TahoeRoofMount","production"],
} 

SIL = {
#   key     min,     max,   machineName,      scenarioPath 
#  -----   -----    -----   ------------      ---------------
   "00"=>["00100", "00179",  "Tahoe",         "engineering/SIL"], 		# ACTT SILs 
   "01"=>["00180", "00199",  "793SSP_00",     "engineering/Brisbane/01Sim"], 	# D-Space SILs
   "02"=>["00200", "00299",  "793SSP_00",     "engineering/SIL/Scalability"], 	# Scalability SILs
   "03"=>["00300", "00325",  "793SSP_00",     "engineering/SIL"], 		# TPG SILs
   "04"=>["00080", "00090",  "793SSP_00",     "engineering/SIL/Brisbane"], 	# Brisbane SILs
   "05"=>["00326", "00399",  "793SSP_00",     "engineering/SIL/Regression"], 	# Regression SILs

}
