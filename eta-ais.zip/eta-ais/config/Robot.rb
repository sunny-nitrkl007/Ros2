###################################################################
#
#  Robot.rb : Read in the assigned site from robot (copied from $HOME/etc/robot)
# and load the associate Robot_XX.rb configuration file.
#
#  Robot specific information
#    - Vehicle Dimensions
#    - Transform Network
#    - Model parameters
#
#
#  NOTE:  Declaring "RobotType" and "Machine_name" as global variables so they can be 
#         referenced in other ruby config files
#
###################################################################
require "commonLoad.rb"

robotFile = ENV["CAT_CONFIG_DIR"].to_s + "/robot"
puts "===== Robot file " + robotFile 

# First check to see if the robot file exists and if it contains a 
# valid serial number
if( FileTest.exists?(robotFile) )
    # Read in the robot type
    file = File.new(robotFile , "r")
    RobotType = file.gets.chomp

    puts " machine serial number is '" + RobotType + "' without the quotes"

    binDir = ENV["CAT_DIR"].to_s + "/bin/"
    Machine_name = `#{binDir}convertMsnToMachName --msn #{RobotType} --terse`

    puts "Machine name is: " + Machine_name
    puts "End of machine name"
else
    puts "===== Robot file " + robotFile + " does not exist."
    puts "===== Most likely this is a brandNew computer. "
    Machine_name = "MSNNOTAVAIL"
end

if( (Machine_name == "MSNINVALID") or (Machine_name == "MSNUNSUPPORTED") or (Machine_name == "MSNNOTAVAIL") ) 
    puts "===== Retrieved MSN is either invalid or unsupported or unavailable. "
    puts "===== Simply load any application configuration to acquire a valid MSN. "
    puts "===== Note that an Unknown scenario will be loaded to limit system functionality. "
    Machine_name = "793FDB_00"
end

fileName = "Robot_" + Machine_name + ".rb"
puts "File name is:" + fileName
load fileName
