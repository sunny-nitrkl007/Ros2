require "socket"


module Machines

  # Get the Spoofed name if set
  thisHostname = CommonTaskParams::Parameters["spoofDnsName"];

  realHostname = Socket.gethostname

  print "Host name is:", thisHostname,"\n"

  # if not spoofed, grab the real hostname
  if thisHostname == nil
    thisHostname = realHostname
  end

  print "Host name is:", thisHostname,"\n"

  onBoardComputers = ["A6N2","A5N2"] #list of Autonomy Computers

  # Modify Machine Mapping based on hostname
  case thisHostname

  # Mapping for defined onBoardComputers
    when *onBoardComputers then
    puts "---------Using Machine configuration for ON BOARD computers!"
        MachineMap = {
        "one"   => "A6N2",
        "two"   => "tbd2",
        "three" => "tbd3",
        "four"  => "tbd4",
        "five"  => "A5N2",
        "ocs"   => "ocs",
      }
      MachineMap.default = thisHostname;

    when "local"
      puts "CONFIG: Using machine map for 'local'\n"
      MachineMap = {
        "one"   => thisHostname,
        "two"   => thisHostname,
        "three" => thisHostname,
        "four"  => thisHostname,
        "five"  => thisHostname,
        "ocs"   => thisHostname,
      }
      MachineMap.default = thisHostname;

    when "ocs"
        puts "---------Using OCS Machine configuration!"

        MachineMap = {
          "one"   => "A6N2",
          "two"   => "tbd2",
          "three" => "tbd3",
          "four"  => "tbd4",
          "five"  => "A5N2",
          "ocs"   => realHostname,
        }
        MachineMap.default = realHostname;

      else
        puts "---------Using Default Machine configuration!"

      MachineMap = {
        "one"   => thisHostname,
        "two"   => thisHostname,
        "three" => thisHostname,
        "four"  => thisHostname,
        "five"  => thisHostname,
        "ocs"   => thisHostname,
      }
      MachineMap.default = thisHostname;
   end
end
