require "commonLoad.rb"
#common DeterministicTask interfaces.  
load "commonAutonomyTask.rb"  # load AutonomyTask Interfaces
load "DataTypeTable.rb"  # must know the list of recurring datums to create interfaces properly

# Interfaces related to AutonomyTasks
CommonTaskParams::Interfaces.update( {

  "DatumBookmarkOutput" => InterfaceDefs::DatumBookmarkOutput, 

  # These interfaces are used for playback
  "PlaybackDeterministicCommandInput" => InterfaceDefs::PlaybackDeterministicCommandInput,
  "DeterministicTaskInfoOutput" => InterfaceDefs::DeterministicTaskInfoOutput,

} )

