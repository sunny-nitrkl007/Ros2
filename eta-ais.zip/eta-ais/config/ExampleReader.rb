require "commonLoad"
load "commonTaskParams.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
   "ExampleInput" => InterfaceDefs::ExampleInput,
   "ExampleInput2" => InterfaceDefs::ExampleInput2,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "cycleRate_hz" => 10,
} )

Execution = {
  "executableName" => "exampleReader",
}

