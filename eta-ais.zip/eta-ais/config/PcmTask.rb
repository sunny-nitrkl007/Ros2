# this is needed for Ruby 1.9.2 and later
d = "."
$LOAD_PATH.unshift(d) unless $LOAD_PATH.include?(d)
d = ENV[ 'CAT_DIR' ] + "/usr/lib/ruby/1.8"
$LOAD_PATH.unshift(d) unless $LOAD_PATH.include?(d)
d = ENV[ 'CAT_DIR' ] + "/usr/lib/ruby/1.8/x86_64-linux/"
$LOAD_PATH.unshift(d) unless $LOAD_PATH.include?(d)
d = ENV[ 'CAT_DIR' ] + "/usr/lib/ruby/1.8/arm-linux-uclibcgnueabi/"
$LOAD_PATH.unshift(d) unless $LOAD_PATH.include?(d)


require 'pp'
require "commonLoad.rb"
load "commonAutonomyTask.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
    "PcmStatusOutput" => InterfaceDefs::PcmStatusOutput,
    "PcmCommandInput" => InterfaceDefs::PcmCommandInput,
    #"PcmCommandOutput" => InterfaceDefs::PcmCommandOutput,
    "FileGlobInput"   => InterfaceDefs::ZFileGlobInput,
    "FileGlobSendOutFilesOutput"=> InterfaceDefs::ZFileGlobSendOutFilesOutput,
    
    #"FileGlobSendOutFilesInput"=> InterfaceDefs::ZFileGlobSendOutFilesInput,
    #"LoggerStatusInput"=> InterfaceDefs::LoggerStatusInput,
    #"LogStopInput"     => InterfaceDefs::LogStopInput,
    "ProcessHealthInput" => InterfaceDefs::ProcessHealthInput,
    "SystemHardwareHealthRequestInput" => InterfaceDefs::SystemHardwareHealthRequestInput,
    "SystemHardwareHealthOutput" => InterfaceDefs::SystemHardwareHealthOutput,
    "CalibrationResultGlobInput" => InterfaceDefs::ZFileGlobCalibrationResultInput,
#   "CoreDumpInfoOutput" => InterfaceDefs::CoreDumpInfoOutput,  # don't include for developer testing - we want the core file
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "requireGPSTimeSynchronizationOnStart" => false, # PCM is not required to start synchronized
  "cycleRate_hz" => 1,
  "loggerThreshold" => "info",
  "workingDirectory" => ENV[ 'HOME' ] + "/tmp/outputFiles",  # location of where to dump .out files
  "maxRestarts" => 3,  # increase value to set the number of times for a process to restart (warn: -1 will restart forever!)
  "toSaveConfigDirectory" => false,  # boolean on whether to save configuration

  "checkHardwareHealthTime_sec" => 60, # how often to check system hardware health
  "checkProcessInfo_sec" => 30, # how often to check process health ~30seconds
  "diskSpaceRemainingThreshold_percentage" => 5.0, # threshold before throwing OCS error on remaining disk space
  "diskSpaceCheckLocation" => ENV[ 'HOME' ], # Location to check for remaining disk space
  "temperatureThreshold_C" => 95, # The threshold at which the PCM will report an OCS alert
  "maxOutputFileSize_bytes" =>  1048576, # 1 MB -- the max threshold for the output file size
  "truncateOutputFile" => false,  # enable/disable truncating output file size (ENABLED by default)
  "stalledProcessTimer_s" => 5.0,  # Number of seconds to wait before declaring a process as "stalled"
  "lowMemoryThreshold" => 0.10,  # Ratio of available memory at which the low memory autonomy condition is triggered. 0.10 = 10%
  "autoStart" => true,  
   # Comm with MCM Parms 
  "HostName"  => IPAddressMap.fetch("mcm"), #MCM IP Address
  "UDPRxPort" => IPAddressMap.fetch("mcmRxPort"),
  "UDPTxPort" => IPAddressMap.fetch("mcmTxPort"),  

  # 
  # PCM shutdown operation and configs: ref. to doc/KeySwitchOnlyShutdown.pptx
  #
  "ShutdownRequestUnknownTimeOut_sec" => 1,   # maximum time for waiting before sending request to stop child processs
  "waitBeforeKill_s"                  => 120, # maximum time that pcm will wait for its child processes to nicely shutdown before sending signal to kill them
  "PrePowerDownTimeOut_sec"           => 1,   # time that pcm will wait before releasing keyswitch override

} )

SystemParametersA5N6 = {
  "batteryVoltageFilePath" => "/proc/acpi/ecu_battery/voltage",
}

SystemParametersA6N2 = {
  "batteryVoltageFilePath" => "/sys/class/tty/ttyS2/adc/batt_mon",
}

load "Machines.rb"
loadInstanceAuxFile("PcmTask.rb")

pp Interfaces
