require "commonLoad.rb"
load "MachineOCS-base.rb"

Parameters.update({
  "loggerThreshold" => "notice",
  "SaveView" => "OCSView.txt",
  "LoadView" => "OCSView.txt",
  "requireGPSTimeSynchronizationOnStart" => false,
  "scheduler"=>"SCHED_OTHER",
})


Execution = {
  "executableName" => "machineOCS",
  "preCommands" => "",
  "postCommands" => "",
  "defaultMachine" => "default",
  "stalledProcessTimer_s" => 30.0, 
}


Interfaces.update( {
  "ActiveDiagnosticsInput" => InterfaceDefs::ActiveDiagnosticsInput,
  "AutonomyConditionMessageInput" => InterfaceDefs::AutonomyConditionMessageInput,
  "CameraImageInput" => InterfaceDefs::OCSCameraImageInput,
  "ClockPlaybackServer" => InterfaceDefs::ClockPlaybackServer,
  "CameraStatsInput" => InterfaceDefs::CameraStatsInput,
  "DiagnosticStatusInput" => InterfaceDefs::DiagnosticStatusInput,
  "FullSizeCameraImageInput" => InterfaceDefs::CameraImageInput,
  "LoggerStatusInput" => InterfaceDefs::LoggerStatusInput,
  "LogStartOutput" => InterfaceDefs::LogStartOutput,
  "LogStopOutput" => InterfaceDefs::LogStopOutput,
  "LogResumeOutput" => InterfaceDefs::LogResumeOutput,
  "LogPauseOutput" => InterfaceDefs::LogPauseOutput,
  "LoggerCommentsOutput" => InterfaceDefs::LoggerCommentsOutput,
  "PcmCommandOutput" => InterfaceDefs::PcmCommandOutput,
  "PcmStatusInput" => InterfaceDefs::PcmStatusInput,
  "ProcessHealthInput" => InterfaceDefs::ProcessHealthForDisplayInput, #ProcessHealthPlugin
  "PlaybackLogCommandsOutput" => InterfaceDefs::PlaybackLogCommandsOutput,
  "PlaybackLogCommandsInput" => InterfaceDefs::PlaybackLogCommandsInput,
  "PlaybackLogOpenOutput" => InterfaceDefs::PlaybackLogOpenOutput,
  "PlaybackLogDetailsInput" => InterfaceDefs::PlaybackLogDetailsInput,
  "PlaybackLogStatusInput" => InterfaceDefs::PlaybackLogStatusInput,
  "ScsMessageStatsInput" => InterfaceDefs::ScsMessageStatsInput,
  "SimpleCommsClientStatusInput" => InterfaceDefs::SimpleCommsClientStatusInput,
  "SnapshotBridgeStatusInput" => InterfaceDefs::SnapshotBridgeStatusInput,
  "SnapshotCreationRequestOutput" => InterfaceDefs::SnapshotCreationRequestOutput,
  "SnapshotCreationResponseInput" => InterfaceDefs::SnapshotCreationResponseInput,
  "SnapshotDeletionRequestOutput" => InterfaceDefs::SnapshotDeletionRequestOutput,
  "SubSystemHealthInput" => InterfaceDefs::SubSystemHealthInput,
  "SubSystemHealthOutput" => InterfaceDefs::SubSystemHealthOutput,
  "SyslogBridgeStatusInput" => InterfaceDefs::SyslogBridgeStatusInput,
  "SystemHardwareHealthInput" => InterfaceDefs::SystemHardwareHealthInput,
  "TimeSyncStatisticsInput" => InterfaceDefs::TimeSyncStatisticsInput,
  "TextWritableRequestOutput" => InterfaceDefs::TextWritableRequestOutput,
  "TextWritableResponseInput" => InterfaceDefs::TextWritableResponseInput,
  "VehicleStateInput" => InterfaceDefs::VehicleStateInput,

  # Add new interface definitions here
} )

ActiveWidgets = generateActiveWidgets(Parameters);

