module InterfaceDefs

OCSCameraImageInput = {
    "interface" => "CameraImage.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "OCSCameraImage.Channel",
    }
}

OCSCameraImageOutput = {
    "interface" => "CameraImage.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "OCSCameraImage.Channel",
        "compression" => "passthrough",
    }
}

CameraImageInput = createBasicInputInterface("CameraImage")
CameraImageOutput = createBasicOutputInterface("CameraImage")

CameraStatsInput = createBasicInputInterface("CameraStats")
CameraStatsInput["channel"]["queueSize"] = 10;
CameraStatsOutput = createBasicOutputInterface("CameraStats")

CameraHealthInput = createBasicInputInterface("CameraHealth")
CameraHealthOutput = createBasicOutputInterface("CameraHealth")

EventDiagnosticDataInput = createBasicInputInterface("EventDiagnosticData")
EventDiagnosticDataOutput = createBasicOutputInterface("EventDiagnosticData")

FMSActiveEventsInput = {
    "interface" => "EventDiagnosticData.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSActiveEvents.Channel",
    }
}

FMSActiveEventsOutput = {
    "interface" => "EventDiagnosticData.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSActiveEvents.Channel",
    }
}

FMSActiveDiagnosticsInput = {
    "interface" => "EventDiagnosticData.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSActiveDiagnostics.Channel",
    }
}

FMSActiveDiagnosticsOutput = {
    "interface" => "EventDiagnosticData.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSActiveDiagnostics.Channel",
    }
}

FMSLoggedEventsInput = {
    "interface" => "EventDiagnosticData.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSLoggedEvents.Channel",
    }
}

FMSLoggedEventsOutput = {
    "interface" => "EventDiagnosticData.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSLoggedEvents.Channel",
    }
}

FMSLoggedDiagnosticsInput = {
    "interface" => "EventDiagnosticData.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSLoggedDiagnostics.Channel",
    }
}

FMSLoggedDiagnosticsOutput = {
    "interface" => "EventDiagnosticData.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSLoggedDiagnostics.Channel",
    }
}

#Fault Management ADS Base Machine

FMSBaseMachineActiveEventsInput = {
    "interface" => "EventDiagnosticData.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSBaseMachineActiveEvents.Channel",
    }
}

FMSBaseMachineActiveEventsOutput = {
    "interface" => "EventDiagnosticData.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSBaseMachineActiveEvents.Channel",
    }
}

FMSBaseMachineActiveDiagnosticsInput = {
    "interface" => "EventDiagnosticData.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSBaseMachineActiveDiagnostics.Channel",
    }
}

FMSBaseMachineActiveDiagnosticsOutput = {
    "interface" => "EventDiagnosticData.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSBaseMachineActiveDiagnostics.Channel",
    }
}

FMSBaseMachineLoggedEventsInput = {
    "interface" => "EventDiagnosticData.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSBaseMachineLoggedEvents.Channel",
    }
}

FMSBaseMachineLoggedEventsOutput = {
    "interface" => "EventDiagnosticData.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSBaseMachineLoggedEvents.Channel",
    }
}

FMSBaseMachineLoggedDiagnosticsInput = {
    "interface" => "EventDiagnosticData.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSBaseMachineLoggedDiagnostics.Channel",
    }
}

FMSBaseMachineLoggedDiagnosticsOutput = {
    "interface" => "EventDiagnosticData.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FMSBaseMachineLoggedDiagnostics.Channel",
    }
}
ShmClockOutput = createBasicOutputInterface("ShmClock")
ShmClockInput = createBasicInputInterface("ShmClock")
end
