# Short Cut Key definitions.  Advised to use "Ctrl" + "Letter" for shortcut definiton
# Available special keys:  CTRL, ALT, SHIFT (note:  these ONLY refer to the keys on the LEFT side of the keyboard)
#   Notes:
#   --> Quick Comment Events already use Ctrl+Shift+[0-9/a-c] (see CommentLoggerPlugin::quickCommentButtons)
#   --> HOME button is already defined as a shortcut
#   --> ALT + 'r' is defined as "RESET CAMERA VIEW"
Widgets::ShortcutKeys =
{
"1" => {
    "plugin" => "ActiveDiagnosticsPlugin",
    "shortcutkeys" => ["CTRL", "d"]    # CTRL + d
    },
"2" => { 
    "plugin" => "AutoLoggerPlugin",
    "shortcutkeys" => ["CTRL", "l"]    #  CTRL + l
    },

"3" => { 
    "plugin" => "HardwareHealthPlugin",
    "shortcutkeys" => ["CTRL", "h"]    #  CTRL + h
    },
"4" => { 
    "plugin" => "PlaybackLogPlugin",
    "shortcutkeys" => ["CTRL", "p"]    #  CTRL + p
    },

# Enter new Shortcuts above (comma-separated)
# Remember to update the totalShortCuts when adding/removing shortcuts
"totalShortCuts" => 4,  # defines the Number of Shortcuts 
    
}

