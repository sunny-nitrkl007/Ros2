module Widgets

load "MachineOCS_shortcutKeys.rb"  # load in your custom OCS shortcuts

  # Widget Categories.  In order to clean up the OCS display, we can file the plugin widgets into
  #  their appropriate category.  These categories will be visible at the top level view.  Under each
  #  category, will be a listing of all of the plugin widgets that have been assigned into that category.
  # Users may specify categories as needed.  There two reserved values for category assignments: 0,99.  
  # See the note below.
  WidgetCategory =
  {
  "1" => "Infrastructure",   

  # Enter new Categories above (comma-separated)
      # Remember to update the totalCategories when adding/removing categories
    "totalCategories" => 1,

  # Notes:  Some Category assignments are have special meaning
  #  0 - reserved.  Set the Category to 0 to have the plugin visible outside of category filing.
  # 99 - reserved.  Set the Category to 99 to have the plugin visible in all the categories.
  }

  # All Plugin Widgets in Pathfinder system
  AllWidgets = {
    "ActiveDiagnosticsPlugin" =>
    {
      "interface" => "ActiveDiagnosticsPlugin",
      "displayName" => "Active Diagnostics",
      "category" => 1, 
    },

     "AutoLoggerPlugin" =>
    {
      "interface" => "AutoLoggerPlugin",
      "displayName" => "Autonomy Logger",     
      "defaultUser" => "pf",

      ### Strings for Quick Comment buttons on Autonomy Logger.  MAX NUMBER = 18!!!!  
      ### They will appear in a 6x3 grid of buttons in the order they are listed below
      "quickCommentButtons" => [  
        "0:  Rock",
        "1:  Haul_Truck",
        "2:  Dust",
        "3:  Human",
        "4:  Rut",
        "5:  Down Grade",
        "6:  Up Grade",
        "7:  Berm",
        "8:  HighWall",
        "9:  Light Truck",
        "a:  Dozer",
        "b:  Water Truck",
        "c:  Water",
        ],
        "category" => 99, #all categories!
    },

    "AutonomyConditionsPlugin" =>
    {
      "interface" => "AutonomyConditionsPlugin",
      "displayName" => "Autonomy Conditions",
      "category" => 1, #infra
    },

    "BasicCameras" =>
    {
      "interface" => "BasicCameras",
      "category" => 1, #infrastructure
    },

   "BCameraPlugin" =>
   {
     "interface" => "BCameraPlugin",
     "displayName" => "BCameras",
     "category" => 1, # infrastructure
    },

    "DiagnosticStatusPlugin" =>
    {
      "interface" => "DiagnosticStatusPlugin",
      "displayName" => "Diagnostic Status",
      "category" => 1, #infra
    },

    "HardwareHealthPlugin" =>
    {
      "interface" => "HardwareHealthPlugin",
      "displayName" => "System Hardware Health",
      "category" => 1, #infra
    },

    "PcmStatusPlugin" =>
    {
      "interface" => "PcmStatusPlugin",
      "displayName" => "PCM Status",
      "category" => 1, #infra
    },

    "PlaybackLogPlugin" =>
    {
      "interface" => "PlaybackLogPlugin",
      "displayName" => "Log Playback",
      "restoreConfig" => false,
      "TimeJumpSeconds" => {
        "totalValues" => 16,
        "value1" => {
          "text"=> "+10 min",
          "value" => 600.0,
          },
        "value2" => {
          "text"=> "+5  min",
          "value" => 300.0,
          },
        "value3" => {
          "text"=> "+1  min",
          "value" => 60.0,
          },
        "value4" => {
          "text"=> "+30 sec",
          "value" => 30.0,
          },
        "value5" => {
          "text"=> "+10 sec",
          "value" => 10.0,
          },
        "value6" => {
          "text"=> "+1  sec",
          "value" => 1.0,
          },
        "value7" => {
          "text"=> "+500 ms",
          "value" => 0.5,
          },
        "value8" => {
          "text"=> "+100 ms",
          "value" => 0.1,
          },
        "value9" => {
          "text"=> "-100 ms",
          "value" => -0.1,
          },
        "value10" => {
          "text"=> "-500 ms",
          "value" => -0.5,
          },
        "value11" => {
          "text"=> "-1  sec",
          "value" => -1.0,
          },
        "value12" => {
          "text"=> "-10 sec",
          "value" => -10.0,
          },
        "value13" => {
          "text"=> "-30 sec",
          "value" => -30.0,
          },
        "value14" => {
          "text"=> "-1  min",
          "value" => -60.0,
          },
        "value15" => {
          "text"=> "-5  min",
          "value" => -300.0,
          },
        "value16" => {
          "text"=> "-10 min",
          "value" => -600.0,
          },
        },
        "category" => 99, #simulation
    },

    "PluggableGLMainDisplay" =>
    {
      "interface" => "PluggableGLMainDisplay",
      "category" => 1, #infrastructure
    },

    "ProcessHealthPlugin" =>
    {
      "interface" => "ProcessHealthPlugin",
      "displayName" => "Process Health",
      "category" => 1, # infrastructure
    },

   "ScsCommsStatusPlugin" =>
    {
      "interface" => "ScsCommsStatusPlugin",
      "displayName" => "SCS Comms Status",
      "category" => 1, #infra
      "useLoggedData" => false,
    },

    "SyslogBridgeStatusPlugin" =>
    {
      "interface" => "SyslogBridgeStatusPlugin",
      "displayName" => "Syslog Bridge Status",
      "category" => 1, #infrastructure
    },

    "TimeSyncStatisticsPlugin" =>
    {
      "interface" => "TimeSyncStatisticsPlugin",
      "displayName" => "Time Sync Statistics",
      "category" => 1, # infrastructure
    },

    # Add new plugin definitions above this line
  }
end

# If there's an auxiliary file, load it
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/widgets_aux.rb"))
    puts "-----CONFIG: Updating widgets.rb with mods from widgets_aux.rb"
    load "widgets_aux.rb"
end

# If there's an auxiliary file, load it
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/widgets_aux_markers.rb"))
    puts "-----CONFIG: Updating widgets.rb with mods from widgets_aux_markers.rb"
    load "widgets_aux_markers.rb"
end
