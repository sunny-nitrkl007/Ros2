require "commonLoad.rb"
# TimeSync configuration file
load "commonAutonomyTask.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
  "TimeSyncStatisticsOutput" => InterfaceDefs::TimeSyncStatisticsOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "requireGPSTimeSynchronizationOnStart" => false, 
  "usePPSSignal"  => false,

  "masterAddress" => IPAddressMap.fetch("auto2"), #Auto 2 IP address
  "timeSyncPort"  => IPAddressMap.fetch("autoTimeSyncPort"), # Auto time sync port
  "cycleRate_hz"  => -1,

} )

Execution = {
  "executableName" => "timeSync"
}

