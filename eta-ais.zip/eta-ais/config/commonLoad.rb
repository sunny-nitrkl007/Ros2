############################################################################
# J. Derence
# 5/1/2013
# Override ruby load() in order to maintain an array of all the sub files loaded.
############################################################################

###################
# Module to store the list of loaded files 
#  It's necessary to store the list in a module in order for gain accessibility across various ruby files/modules
###################
module LoadedFilesList
  ListOfLoadedRubyFiles = {
    # Store the array within a hash table
    "LoadedRubyFiles" => [ __FILE__, 'robot', 'site', 'ApplicationTable.rb' ]  # Force the initial values to be this file (__FILE__, robot, site)
  }

end

###################
# Override ruby's Kernel Module::load.  We want to track all of the loaded files within @listOfLoadedFiles.
###################
module Kernel
    alias _load load  # override _load

    # Our version of load(file)
    def load (path, wrap=false)
      LoadedFilesList::ListOfLoadedRubyFiles["LoadedRubyFiles"] << path
    
      _load(path,wrap)
    end

end

###################
# Override ruby's require function.  If a file is required, be sure to add it into @listOfLoadedFiles
# Reference:  http://stackoverflow.com/questions/7190015/how-do-i-get-a-list-of-files-that-have-been-required-in-ruby
###################
alias :orig_require :require
def require s
  if orig_require(s)
    LoadedFilesList::ListOfLoadedRubyFiles["LoadedRubyFiles"] << s 
  end
end


###################
# Load any MachineType specific information
###################
def loadInstanceRobotFile( filename, machineType )

    instanceName = File.basename(filename, ".*" )
    subRobot_File = ENV["CAT_CONFIG_DIR"].to_s + "/" + instanceName + "_" + machineType + ".rb"
    if(FileTest.exists?(subRobot_File))
      puts "-----CONFIG:  Updating" + instanceName + " with mods from " + subRobot_File
      load subRobot_File
    end

end

###################
# Load any MachineType specific information
###################
def loadInstanceAuxFile( filename )

    instanceName = File.basename(filename, ".*" )
    subAux_File = ENV["CAT_CONFIG_DIR"].to_s + "/" + instanceName + "_aux.rb"
    if(FileTest.exists?(subAux_File ))
      puts "-----CONFIG:  Updating" + instanceName + " with mods from " + subAux_File 
      load subAux_File 
    end

end


