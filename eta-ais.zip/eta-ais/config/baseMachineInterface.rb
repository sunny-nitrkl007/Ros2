require "commonLoad.rb"
load "commonAutonomyTask.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
   "MachineSNOutput" => InterfaceDefs::MachineSNOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "requireGPSTimeSynchronizationOnStart" => false,
  "loggerThreshold" => "notice", # "fatal", "error", "warn", "notice", "info", "debug",
  "cycleRate_hz" => 250,

  # Valid values:
  #     0 - can0 or CAN1 or CAN A
  #     1 - can1 or CAN2 or CAN B

  "TOS_CAN_port" => 0,

  # J1939 SID of Master ECM
  "ID_Master" => 0x1C,

  # Debounce Time for Auto conditions/Diags/Events
  "BMI_ENG_CAN_A_Loss_Comm_I2A_s" => 0.0,
  "BMI_ENG_CAN_A_Loss_Comm_A2I_s" => 0.0,
   
  "Server_address" => "127.0.0.1:50051",

  "CDA_publish_freq" => 10,

} )


Execution = {
  "executableName" => "baseMachineInterface",
}

# If there's an auxiliary file, load it
loadInstanceAuxFile( File.basename( __FILE__ ) )
