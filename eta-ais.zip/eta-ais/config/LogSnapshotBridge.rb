require "commonLoad.rb"
load "commonAutonomyTask.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
    "SnapshotBridgeStatusOutput" => InterfaceDefs::SnapshotBridgeStatusOutput,
    "SnapshotCreationRequestOutput" => InterfaceDefs::SnapshotCreationRequestOutput,
    "SnapshotCreationResponseInput" => InterfaceDefs::SnapshotCreationResponseInput,
    "LogStartInput" => InterfaceDefs::LogStartInput,
    "LogStopInput" => InterfaceDefs::LogStopInput
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "fatal",
  
  # The rate that we publish snapshot status and (potentially) Minestar snapshot
  # requests at.
  "cycleRate_hz" => 1,   

} )

Execution = {
  "executableName" => "logSnapshotBridge",
}

