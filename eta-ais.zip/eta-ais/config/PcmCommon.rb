load "commonTaskParams.rb"
load "Machines.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
    "PcmStatusOutput" => InterfaceDefs::PcmStatusOutput,
    "PcmCommandInput" => InterfaceDefs::PcmCommandInput,
    "FileGlobInput"   => InterfaceDefs::ZFileGlobInput,
    "ProcessHealthInput" => InterfaceDefs::ProcessHealthInput,
    "SystemHardwareHealthRequestInput" => InterfaceDefs::SystemHardwareHealthRequestInput,
    "SystemHardwareHealthOutput" => InterfaceDefs::SystemHardwareHealthOutput,
    "ShutdownRequestInput" => InterfaceDefs::ShutdownRequestInput,
    "ShutdownStateOutput"  => InterfaceDefs::ShutdownStateOutput,
    "KeyswitchInput"       => InterfaceDefs::KeyswitchInputGPIO,
    "KSOOutput"            => InterfaceDefs::KSOOutputGPIO,
    "VehicleStateInput"    => InterfaceDefs::VehicleStateInput,
    "CalibrationResultGlobInput" => InterfaceDefs::ZFileGlobCalibrationResultInput,
    "CoreDumpInfoOutput" => InterfaceDefs::CoreDumpInfoOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "requireGPSTimeSynchronizationOnStart" => false, # PCM is not required to start synchronized
  "cycleRate_hz" => 1,
  "loggerThreshold" => "warn",
  "workingDirectory" => ENV[ 'HOME' ] + "/outputFiles",
  "maxRestarts" => -1, # infinite number of restarts!
  "waitBeforeKill_s" => 6,

  "checkHardwareHealthTime_sec" => 60, # how often to check system hardware health
  "checkProcessInfo_sec" => 30, # how often to check process health ~30seconds
  "diskSpaceRemainingThreshold_percentage" => 15.0, # threshold before throwing OCS error on remaining disk space
  "diskSpaceRemainingHysteresis_percentage" => 5.0, # Hysteresis to reset the ECM Out of space condition. This is relative to diskSpaceRemainingThreshold_percentage.
  "diskSpaceCheckLocation" => ENV[ 'HOME' ], # Location to check for remaining disk space
  "temperatureThreshold_C" => 95, # The threshold at which the PCM will report an OCS alert
  "maxOutputFileSize_bytes" =>  1048576, # 1 MB -- the max threshold for the output file size
  "truncateOutputFile" => true,  # enable/disable truncating output file size (ENABLED by default)
  "stalledProcessTimer_s" => 5.0,  # Number of seconds to wait before declaring a process as "stalled"
  "lowMemoryThreshold" => 0.10,  # Ratio of available memory at which the low memory autonomy condition is triggered. 0.10 = 10%

   # Comm with MCM Parms 
  "HostName"  => IPAddressMap.fetch("mcm"), #MCM IP Address
  "UDPRxPort" => IPAddressMap.fetch("mcmRxPort"),
  "UDPTxPort" => IPAddressMap.fetch("mcmTxPort"),  
} )

