#
# PcmOne is just inherits from PcmCommon.rb
#

load "PcmCommon.rb"
