require "commonLoad.rb"
# TimeSpoofMaster.rb
################################################
# In this configuration, the timeSync task will simply use the local clock for
# the time Model, but will set the model so it LOOKS like the system is sync'd to GPS time.
#
# It will also serve as "master" time module and service the UDP port
# for any incoming time sync requests
################################################

load "commonAutonomyTask.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "warn",
  "cycleRate_hz" => 1,  # cycle every second
  "requireGPSTimeSynchronizationOnStart" => false, # ALLOW this process to start without synchronization

#Source of timesync
  "timeSyncSourceFromHardware" => true,  # pretend to be HW
  "spoofGPSInput" => true,

#Service role for timesync
  "serviceRoleIsMaster" => true,    # act as master and service UDP port
  "timeSyncPort" => IPAddressMap.fetch("autoTimeSyncPort"), # Auto time sync port

} )

Execution = {
  "executableName" => "timeSyncObject",
}

