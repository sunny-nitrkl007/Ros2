require "commonLoad"
load "commonTaskParams.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
   "ExampleOutput" => InterfaceDefs::ExampleOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "cycleRate_hz" => 10,
} )

Execution = {
  "executableName" => "exampleWriter",
}

