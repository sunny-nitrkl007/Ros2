require "commonLoad.rb"
load "commonAutonomyTask.rb"
load "widgets.rb"

Interfaces = CommonTaskParams::Interfaces.dup;

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update({
  "cycleRate_hz" => 20,
  "loggerThreshold" => "warn",
  "Control Level" => 1,
  "Main Display" => "PluggableGLMainDisplay",
  "DefaultCamera" => "Right Camera",
  "Theme" => "none", # "none" - This is the default look-n-feel which resembles old Windows (95/98/Me/NT/2000) and old GTK/KDE
                     # "plastic" - This scheme is inspired by the Aqua user interface on Mac OS X
                     # "gtk+" - This scheme is inspired by the Red Hat Bluecurve theme
  "requireGPSTimeSynchronizationOnStart" => false,
  # only widgets that match this list will be loaded when the ocs is
  # in safe mode
  "SafeModeWhiteList" => [
    "AutoLoggerPlugin",
    "BasicCameras",
    "PlaybackLogPlugin",
    "ProcessHealthPlugin",
  ],

  "Tabs" =>      [
      "ActiveDiagnosticsPlugin",
      "AutoLoggerPlugin",
      "AutonomyConditionsPlugin",
      "BCameraPlugin",
      "DiagnosticStatusPlugin",
      "HardwareHealthPlugin",
      "PcmStatusPlugin",
      "PlaybackLogPlugin",
      "ProcessHealthPlugin",
      "ScsCommsStatusPlugin",
      "SyslogBridgeStatusPlugin",
      "TimeSyncStatisticsPlugin",
      #Add new widget plugins here
	  ],

  "Drawables" => [
      "BasicCameras",
      "AutoLoggerPlugin",
      #Add new drawable plugins here
        ],
})


#You should not have to touch anything below this line. So don't bother, unless you really mean it.
def generateActiveWidgets(parameters)
    #get all widgets
    key = [];
    if(parameters.has_key?("Main Display") && parameters["Main Display"] != nil)
        key = [parameters["Main Display"]];
    end
    if(parameters.has_key?("Toolbar") && parameters["Toolbar"] != nil)
        key.push(parameters["Toolbar"])
    end
    if(parameters.has_key?("Tabs") && parameters["Tabs"] != nil)
        key.concat(parameters["Tabs"]);
    end
    if(parameters.has_key?("Drawables") && parameters["Drawables"] != nil)
        key.concat(parameters["Drawables"]);
    end
    if(parameters.has_key?("Playback Bar") && parameters["Playback Bar"] != nil)
        key.push(parameters["Playback Bar"]);
    end
    if(parameters.has_key?("Status Display") && parameters["Status Display"] != nil)
        key.push(parameters["Status Display"]);
    end
    key.compact!;

    activeWidgets = Hash.new;
    list = Array.new();
    key.each{ |ii|
        widget = Widgets::AllWidgets[ii];
        list = [ii];
        if(widget == nil)
            puts "Error: Cannot find " + ii + " in AllWidgets!\n";
            return;
        end

        if(widget.has_key?("Widgets"))
            key.concat(widget["Widgets"]);
        end

        # add interfaces required by widgets
        # note: this can get dangerous and probably should have stronger checking to avoid collisions
        if(widget.has_key?("Interfaces"))
            Interfaces.update(widget["Interfaces"])
        end

        list.each{ |jj|
            if(activeWidgets.has_key?(jj))
                list.delete(jj);
            end
        }
        activeWidgets.update(collectWidgets(Widgets::AllWidgets, list));

    }
    return activeWidgets;
end

def collectWidgets(allHash, subList)
    widgetList = Hash.new;
    subList.each {|ii|
        #this widget exists
        if(allHash.has_key?(ii))
            widgetList[ii] = allHash[ii];
        else
            puts "Widget #{ii} not found.";
        end
    }
    return widgetList;
end

# If there's an auxiliary file, load it
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/MachineOCS-engineering.rb"))
    puts "-----CONFIG: Updating MachineOCS-base.rb with mods from MachineOCS-engineering.rb"
    load "MachineOCS-engineering.rb"
end

# If there's an auxiliary file, load it
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/MachineOCS-base_aux.rb"))
    puts "-----CONFIG: Updating MachineOCS-base.rb with mods from MachineOCS-base_aux.rb"
    load "MachineOCS-base_aux.rb"
end

