require "commonLoad.rb"
#PlaybackLog.rb for PlaybackLogTest
load "commonTaskParams.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
  "PlaybackLogCommandsInput" => InterfaceDefs::PlaybackLogCommandsInput,
  "PlaybackLogCommandsOutput" => InterfaceDefs::PlaybackLogCommandsOutput,
  "PlaybackLogOpenInput" => InterfaceDefs::PlaybackLogOpenInput,
  "PlaybackLogDetailsOutput" => InterfaceDefs::PlaybackLogDetailsOutput,
  "Clock" => InterfaceDefs::ClockPlaybackClient,
  "PlaybackLogStatusOutput" => InterfaceDefs::PlaybackLogStatusOutput,
  "TextWritableRequestInput" => InterfaceDefs::TextWritableRequestInput,
  "TextWritableResponseOutput" => InterfaceDefs::TextWritableResponseOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "error",
  "cycleRate_hz" => 0,
  "readInputLogfileFromConfig" => 0, # Enter 1 to read from config file
  "disableRangeCheck" => 1, # Enter 1 to play logs with any date and split id

  # List specifying the types that should NOT be played at all during any point of Log Playback
  # This list will override any settings from the OCS playback list
  "DoNotPlayChannelTypes" => [
                           "LogStart.Channel",
                           "LogStop.Channel",
                            "TimeSyncStatistics.Channel",
                            ],
} )

Execution = {
  "executableName" => "playbackLog",
}

LogInputFile = {
  #Enter the FULL directory path (don't forget to include the starting and ending "/")
  "directorypath" => ENV[ 'HOME' ] + "/mylog/",

  #Enter the base name of the log file.  Do not include the file name extension!
  "filename" => "mylog",

  #Enter the file name extension .indx
  "extension" => ".indx",
}

loadInstanceAuxFile("PlaybackLog.rb")
