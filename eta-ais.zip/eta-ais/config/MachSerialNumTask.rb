require "commonLoad.rb"
load "commonTaskParams.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
   "MachineSNInput" => InterfaceDefs::MachineSNInput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
   "loggerThreshold" => "warn", # fatal, alert, error, warn, info, debug
   "cycleRate_hz" => 1,
} )

Execution = {
   "executableName" => "machSerialNumTask",
}
