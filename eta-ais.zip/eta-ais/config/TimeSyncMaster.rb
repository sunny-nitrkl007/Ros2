require "commonLoad.rb"
# TimeSyncMaster.rb
################################################
# In this configuration, the timeSync task will attempt to connect to the
# serial port for PPS input and listen for GPS time messages in order to
# properly set the TimeSyncModel.
# It will also serve as "master" time module and service the UDP port
# for any incoming time sync requests
################################################

load "commonTaskParams.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
  "GPSTimeInput" => InterfaceDefs::GPSTimeInput,
  "TimeSyncStatisticsOutput" => InterfaceDefs::TimeSyncStatisticsOutput,
  "AutonomyConditionMessageOutput" => InterfaceDefs::AutonomyConditionMessageOutput,
  "LoggerCommentsOutput" => InterfaceDefs::LoggerCommentsOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "error",
  "cycleRate_hz" => 1,  # cycle every second
  "requireGPSTimeSynchronizationOnStart" => false, # ALLOW this process to start without synchronization

#Source of timesync
  "timeSyncSourceFromHardware" => true,
  "ppsSerialPort" => "/dev/serial_irq",

#Service role for timesync
  "serviceRoleIsMaster" => true,    # act as master and service UDP port
  "timeSyncPort" => IPAddressMap.fetch("autoTimeSyncPort"), # Auto time sync port
} )

Execution = {
  "executableName" => "timeSyncObject",
}



