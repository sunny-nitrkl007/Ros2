require "commonLoad.rb"
module CommonTaskParams


require "Logger.rb"
load "CANFilters.rb"
load "IPAddresses.rb"
load "interfaces.rb"

Interfaces = {
    "ProcessHealthOutput" => InterfaceDefs::ProcessHealthOutput,
    "RemoteLoggerTextOutput" => InterfaceDefs::ZRemoteLoggerTextOutput,
    "AdjustLogLevelInput" => InterfaceDefs::AdjustLogLevelInput,
    "Clock" => InterfaceDefs::ClockSystem,
    "AutonomyConditionMessageOutput" => InterfaceDefs::AutonomyConditionMessageOutput,
}

Parameters = {
    "loggerThreshold" => "error",
    "heartbeatRate" => 1.0,
    "CommSystem" => "SimpleComms",
    "requireGPSTimeSynchronizationOnStart" => true,  # Wait for the TimeSyncModel to be fully synchronized before starting task
    "scheduler" => "SCHED_RR",
    "schedulerPriority"=>1,    #Make sure every Autonomy task is above normal priority linux tasks
}

end

