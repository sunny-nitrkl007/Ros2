#############################
# DataTypeTable.rb holds a list of data types to be recorded by the AutonomyLogger
#
# To add a new datum to be logged, please enter the datum name under DataTypes["Types"] list and
# add the detailed enty information below in a hash table.  Be sure to specifiy the
# monitorSequenceNumber = false if there are multiple sources for the datum.
#
# Datum Log Channel Values:
# DataTypeName = {
#  "channel" => {
#    "type" => "SimpleComms",      # < IPC Medium -- Pathfinder uses "SimpleComms"
#    "queueSize" => 1000,          # < Large "queueSize" so the autonomyLogger doesn't drop any datums
#    "name" => "Example.Channel",  # < Datum CHannel name.  Usually "DataTypeName.Channel"
#  },
#  "monitorSequenceNumber" => true,# < Flag indicating whether or not autonomyLogger should monitor the sequence of these datums
#                                      Only set this to false if there are multiple sources of the datum
# }
#
# There is a function provided to set up the default settings for a Datum Log Channel: createLogChannel
# Example Usage:
#   AutonomyRoute = createLogChannel("AutonomyRoute")
#
#############################

DataTypes = {
    "Types" => [
                "ProcessHealth",
                "VehicleState",
                "LogStart",    # do not remove this type -- required by AutonomyLogger
                "LogStop",     # do not remove this type -- required by AutonomyLogger
                "LogPause",    # do not remove this type -- required by AutonomyLogger
                "LogResume",   # do not remove this type -- required by AutonomyLogger
                "LoggerStatus",
                "LoggerComments",
                "SubSystemHealth",
                "GPSTime",
                "SystemHardwareHealth",
                "PcmStatus",
                "AutonomyConditionMessage",
                "SubSystemRecommendedAction",
                "VersionInfo",
                "TextWritableRequest",
                "TextWritableResponse",
                "BaseCANLoggerDataA",
                "BaseCANLoggerDataB",
                "BaseCANRawCcpDataA",
                "BaseCANRawCcpDataB",
                "BaseCANRawEddtData",
                "BaseMachineLoggerStatus",
                "EddtStatistics",
                "BaseCanCcpData",
                "TimeSyncStatistics",
                "PerceptionExtrinsicsConfig",
                "PerceptionExtrinsicsConfigRequest",
                "AllProcessStatus",
                "CoreDumpInfo",
                "SyslogBridgeStatus",
                "ShutdownRequest",
                "ShutdownState",
                "ActiveDiagnostics",
                "EventReactions",
                "EventReactionsRequest",
                "AllHostDmesg",
                "VersionInfoRequest",
                "SurveyStart",
                "SurveyStop",
                #"SurveyData",
                "NetworkReport",
                "ScsMessageStats",
                "AutoLoggerSnapshotList",
                "SiteConfig",
                "RegulateSpeed",
                "Example",
                "ZRemoteLoggerText",
                "SEAStatus",

 		]

}

###############################
# Default Log Channel definition
#   name => "<DataType>.Channel",
#   Type = "SimpleComms"
###############################
Example = {
  "channel" => {
    "type" => "SimpleComms",
    "queueSize" => 1000,          # < Large "queueSize" so the autonomyLogger doesn't drop any datums
    "name" => "Example.Channel",
    "unixPath" => "scs",          # < without an explicit refernce to "unixPath", the default value will be scs
  },
  "monitorSequenceNumber" => true,# < flag indicating whether or not autonomyLogger should monitor the sequence of these datums
                                  #   Only set this to false if there are multiple sources of the datum
}

###############################
# Create Log Channel helper function
#   name => "<DataType>.Channel",
#   Type = "SimpleComms"
#   QueueSize = 1000
#   NOTE:  Assumes "unixPath" => "scs",
###############################
def createLogChannel(typeName)
    out = Hash.new
    # dup gets us a shallow copy, but the "channel" field will point to the same underlying hash
    out = Example.dup
    # check for and deep-copy the channel hash as well
    if Example.has_key?("channel")
        out["channel"] = Example["channel"].dup
        out["channel"]["name"] = "#{ typeName }.Channel"
    end

    return out
end


# All the Channel Config Sections
TextWritableResponse = createLogChannel("TextWritableResponse") 
TextWritableRequest = createLogChannel("TextWritableRequest") 

ProcessHealth = createLogChannel("ProcessHealth") 
ProcessHealth["monitorSequenceNumber"] = false; 

ApplanixState = createLogChannel("Applanix")
VehicleState = createLogChannel("VehicleState") 

LoggerStatus = createLogChannel("LoggerStatus") 

LoggerComments = createLogChannel("LoggerComments") 
LoggerComments["monitorSequenceNumber"] = false; 

TimeSyncStatistics = createLogChannel("TimeSyncStatistics") 
TimeSyncStatistics["monitorSequenceNumber"] = false; 

LogStop = createLogChannel("LogStop") 
LogStart = createLogChannel("LogStart") 
LogPause= createLogChannel("LogPause")
LogResume= createLogChannel("LogResume")

#----------------------------
SubSystemHealth = createLogChannel("SubSystemHealth")
SubSystemHealth["monitorSequenceNumber"] = false;

SubSystemRecommendedAction = createLogChannel("SubSystemRecommendedAction")
SubSystemRecommendedAction["monitorSequenceNumber"] = false;

GPSTime = createLogChannel("GPSTime")

PerceptionExtrinsicsConfig = createLogChannel("PerceptionExtrinsicsConfig")
PerceptionExtrinsicsConfig["recurring"] = true;

PerceptionExtrinsicsConfigRequest = createLogChannel("PerceptionExtrinsicsConfigRequest")

SystemHardwareHealth = createLogChannel("SystemHardwareHealth")
SystemHardwareHealth["monitorSequenceNumber"] = false;

PcmStatus = createLogChannel("PcmStatus")
PcmStatus["monitorSequenceNumber"] = false;

AutoLoggerSnapshotList = createLogChannel("AutoLoggerSnapshotList")

VersionInfo = createLogChannel("VersionInfo")

BaseCANLoggerDataA = createLogChannel("BaseCANLoggerDataA")
BaseCANLoggerDataB = createLogChannel("BaseCANLoggerDataB")
BaseCANRawCcpDataA = createLogChannel("BaseCANRawCcpDataA")
BaseCANRawCcpDataB = createLogChannel("BaseCANRawCcpDataB")
BaseMachineLoggerStatus = createLogChannel("BaseMachineLoggerStatus")

SyslogBridgeStatus = createLogChannel("SyslogBridgeStatus")

AutonomyConditionMessage= createLogChannel("AutonomyConditionMessage")
AutonomyConditionMessage["monitorSequenceNumber"] = false;

BaseCanCcpData = createLogChannel("BaseCanCcpData")

AllProcessStatus= createLogChannel("AllProcessStatus")

CoreDumpInfo = createLogChannel("CoreDumpInfo")

ShutdownRequest = createLogChannel("ShutdownRequest")
ShutdownState   = createLogChannel("ShutdownState")

BaseCANRawEddtData = createLogChannel("BaseCANRawEddtData")
EddtStatistics = createLogChannel("EddtStatistics")

ActiveDiagnostics = createLogChannel("ActiveDiagnostics")

EventReactions = createLogChannel("EventReactions")
EventReactionsRequest = createLogChannel("EventReactionsRequest")

VersionInfoRequest = createLogChannel("VersionInfoRequest")

SurveyStart = createLogChannel("SurveyStart")
SurveyStop = createLogChannel("SurveyStop")
SurveyData = createLogChannel("SurveyData")
SurveyData["channel"]["unixPath"] = "lowPri";

NetworkReport = createLogChannel("NetworkReport")

ScsMessageStats = createLogChannel("ScsMessageStats")

AllHostDmesg = createLogChannel("AllHostDmesg")
AllHostDmesg["recurring"] = true;

SiteConfig = createLogChannel("SiteConfig")

RegulateSpeed = createLogChannel("RegulateSpeed")

Example = createLogChannel("Example")

ZRemoteLoggerText = createLogChannel("ZRemoteLoggerText")
ZRemoteLoggerText["monitorSequenceNumber"] = false;
ZRemoteLoggerText["channel"]["name"] = "RemoteLoggerText.ZChannel";

SEAStatus = createLogChannel("SEAStatus")

# If there's a aux machine common data type table, load it
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/DataTypeTable_MachineCommon.rb"))
    puts "-----CONFIG: Updating DataTypeTable.rb with mods from DataTypeTable_MachineCommon.rb"
    load "DataTypeTable_MachineCommon.rb"
end
