require "commonLoad.rb"
load "commonAutonomyTask.rb"
require "IPAddresses.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
  "CameraImageOutput" => InterfaceDefs::CameraImageOutput,          # logger interface
  "OCSCameraImageOutput" => InterfaceDefs::OCSCameraImageOutput,    # OCS interface
  "CameraStatsOutput" => InterfaceDefs::CameraStatsOutput,
} )


Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "warn",
  "cycleRate_hz" => 10.0, # frame capture and logging rate
  "numCameras" => 2,
  "imgWidth" => 1280,
  "imgHeight" => 800,
  "maxImageBytes" => 2000000,
  #B Camera pushes the video stream to the configured port. Input only the port number below.
  "URLs" => [
              "25000",
	      "26000"
            ] 
} )

Execution = {
  "executableName" => "BCameraInterface"
}
