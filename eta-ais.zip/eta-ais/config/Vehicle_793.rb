
VehicleDimensions = {
  #793 Dimensions
  #Updated Dimensions Representing FMG 793F Trucks
  #Values came from RM892 Truck Model, using 40.00 R57 XDR E4 Tires
  "controlPointToFrontEdge_m" => 10.0004,
  "controlPointToRearEdge_m" => 4.257,
  "controlPointToLeftEdge_m" => 4.149,
  "controlPointToRightEdge_m" => 4.149,
  "controlPointToLoadCenter_m" => 1.420,
  "vehicleHeight_m" => 6.935, #This is the height to the top of the GPS Antennas, the measurement to the top of the bed is 6.741m
  "vehicleWheelbase_m" => 5.90,
  "vehicleFrontTrackWidth_m" => 5.599,
  "vehicleRearTrackWidth_m" => 4.958,
  "tireRadius_m" => 1.707,
  "tireFrontWidth_m" => 1.270,
  "tireRearWidth_m" => 2.642,
  "nominalLanePadding_m" => 3.11,       #3.11m is the lane padding corresponding to 1.75x truck width
  "bumpSearchDistance_m" => 3,
} 

truckMaximumForwardSpeed_mps = 16.7;
truckMaximumReverseSpeed_mps = 3.0;
truckMaximumDecelEmpty_mpss = 4.5; 	
truckMaximumDecelLoaded_mpss = 2.5;
VehicleCapabilities = {
  "maximumAcceleration_mpsps" => 0.545,
  "maximumDeceleration_mpsps" => truckMaximumDecelLoaded_mpss,     # this is for a loaded truck
  "maximumForwardSpeed_mps" => truckMaximumForwardSpeed_mps,
  "maximumReverseSpeed_mps" => truckMaximumReverseSpeed_mps,    # maximum magnitude of backward velocity
  "minimumTurningRadius_m" => 10.18,      # radius corresponding to the tightest curvature achievable
  "maximumAllowableGrade" => 0.20,        # magnitude of maximum allowed grade as percentage between 0.0 and 1.0
  "maximumAllowableBank" => 0.15,         # magnitude of maximum allowed bank as percentage between 0.0 and 1.0
  "velocityControlLatency_s" => 0.6626,   # temporarily here so that it can be accessed by the path tracker, must match model parameters
                                          # T 0.74285, LD 0.5824, #previous was 0.5246 sec,
  "steeringControlLatency_s" => 0.99,     # must also change model latency
  "trackerPathCycleTime_s" => 0.25,       # the path publish cycle time to the embedded pathtracker from the intelligent driver
  "trackerPoseCycleTime_s" => 0.05,       # the pose publish cycle time in the embedded pathtracker which is as fast as it cycles (20Hz)
  "trackerLatency_s" => 0.05,             # the expected latency from the autonomy layer down to the embedded pathtracker (50 ms mean, 100 ms max)
  "trackerNoPathTimeout_s" => 0.50,       # the timeout before the vehicle hits the brakes if the tracker does not receive a path update

  # Limit Type |  Fwd L/R (m)  |  Rev L/R (m)    Updated 4/25/2013
  # -----------|---------------|--------------- 
  # LDP        | 12.47 / 15.12 | 11.00 / 11.00
  # TravelPath | 12.47 / 15.12 | 10.68 / 10.68
  # Tracker    | 11.97 / 14.62 | 10.18 / 10.18
  # HFOV       | 11.47 / 14.12 |  n/a  /  n/a
  # Allowable  | 11.34 / 13.74 | 10.00 / 10.00   90% LDP
  # Vehicle    | 10.18 / 10.18 | 10.18 / 10.18

  # Used for travel path planning/validation, should be 50cm higher than tracker
  "allowableMinimumRadiusFwdLeft" => 12.47,
  "allowableMinimumRadiusFwdRight" => 15.12,
  "allowableMinimumRadiusRevLeft" => 10.68,
  "allowableMinimumRadiusRevRight" => 10.68,

  "TahoeMode" => false,  # boolean indicating if this vehicle is a Tahoe
    
  # Introducing the concept of different MT/LD decel limits (03/28/2016)
  # Note that the drive command settings, speed control settings, etc do not use this yet
  # Currently this does not affect the vehicle model/stability settings and other modules that use critical/aggressive decel
  # In IM4.5, this will only be used by the ID to set max decel depending on speed limit source.
  "decelLimit_mpss" => [truckMaximumDecelEmpty_mpss, truckMaximumDecelLoaded_mpss],    # MT, LD; decel limits (m/s^2) for empty and loaded state
}

AdaptivePursuitSettings = {
  "lookAheadSpeedSlope" => 2.0,           # slope of lookahead function (as function of velocity)
  "lookAheadSpeedBase_m" => 7.5,          # lookahead distance when velocity is zero
  "maximumLookAheadDistance_m" => 150.0,  # maximum distance the lookahead can grow to
}

truckMinVehicleSpeedMagnitude_mps = 0.75; # smallest maximum velocity that can be commanded (mps) - anything less will be commanded as zero

DriveCommandSettings = {
  "commandMinVelocity" => -truckMaximumReverseSpeed_mps, # minimum velocity that can be commanded (mps)
  "commandMaxVelocity" => truckMaximumForwardSpeed_mps, # maximum velocity that can be commanded (mps)
  "smallestVelocityMagnitude" => truckMinVehicleSpeedMagnitude_mps, # smallest maximum velocity that can be commanded (mps) - anything less will be commanded as zero
  "commandMinFwdCurvature" => -0.0982,    # was 0.0684 = 1/14.62, minimum curvature that can be commanded (1/m)
  "commandMaxFwdCurvature" =>  0.0982,    # was 0.0835 = 1/11.97, maximum curvature that can be commanded (1/m)
  "commandMinRevCurvature" => -0.0982,    # 0.0982 = 1/10.18, minimum curvature that can be commanded (1/m)
  "commandMaxRevCurvature" =>  0.0982,    # 0.0982 = 1/10.18, maximum curvature that can be commanded (1/m)
  "commandMinAcceleration" => 0.1,        # the minimum acceleration rate that can be commanded (mpss)
  "commandAcceleration" => 0.6,           # the maximum acceleration rate that can be commanded (mpss). This is what is typically commanded.
  "commandNominalDeceleration" => 0.6,    # the deceleration rate that will be commanded in gentle stopping situations (mpss)
  "commandAggressiveDeceleration" => truckMaximumDecelLoaded_mpss, # the deceleration rate that will be commanded in aggressive stopping situations (mpss)
                                          # note: the commanded deceleration will always be between the nominal and aggressive limits 
  "commandRateOfK" => 1.0,                # the rate of curvature change that will always be commanded (1/m)/s
  "maximumEmptyLateralAcceleration_mpsps" =>  3.0,
  "maximumLoadedLateralAcceleration_mpsps" => 1.8,
}

truckQueuingDistance_m = 30.0;
criticalDistanceToStopBeforeEndOfLane_m = 30.0;

#description of all parameters used to bring the vehicle to a stop.
StoppingLocationSettings = {

  "distanceToStopBeforeLaneEnds_m" => criticalDistanceToStopBeforeEndOfLane_m, # How close to the end of the lane should we stop when staging point is not provided
  "bodyExtensionPastEndOfLane_m" => 2.0, # This is how much the lane is 'extended' if we allow body extensions for a particular lane

  # these parameters are for all non-staging point stopping conditions (end of lane, queueing behind obstacle/vehicle)
  "acceptableProximityToStop_m" => 2.0, # if the vehicle reaches a stop some slight distance before the stopping point, do not bother accelerating to reach the exact stopping point
                                        # this "double stop" symptom has been observed when queuing for obstacles
  "queueingHysteresis_m" => 5.0, # Once stopped for an obstacle or queueing for a vehicle, this padding is added to create hysteresis, so that if position uncertainty
                                 # moves the queueing location ahead, the vehicle will remain stopped until the vehicle has moved this distance forward. This works
                                 # together with acceptableProximityToStop (as acceptableProximityToStop itself does not create hysteresis) 

  # these parameters are for stopping at the end of a lane or at a staging point
  "crawlDistance_m" => 7.0,

  # this is a stopping buffer when it is not stopping for site awareness, obstacles, or staging points
  "stopPadding_m" => 1.0,

  # these parameters are specific for stopping at staging points
  "positionToleranceMultiplierForSoftStop" => [ 0.0, 0.00, 0.0, 0.25 ], # [MT-slope | MT-base | LD-slope | LD-base] 
                                                                      # slope in units of meters/meter, base in units of meters BEFORE staging point (i.e. if slope set to 0.5, would provide 0.5*tolerance padding)
  "positionToleranceMultiplierForHardStop" => [ 0.5, 0.00, 0.5, 0.00 ], # [MT-slope | MT-base | LD-slope | LD-base] 
                                                                      # slope in units of meters/meter, base in units of meters AFTER staging point (i.e. if slope set to 0.5, would provide 0.5*tolerance padding)

  # these parameters control distance keeping
  "siteAwarenessCriticalQueuingMargin_m" => 2.0,

  # these parameters control stopping for an obstacle
  "obstacleCriticalQueuingMargin_m" => 2.0,

  # these parameters pad stopping for end of lane, obstacles, and site awareness objects (not staging points). Set to zero to essentially "disable"
  "positionUncertaintyRmsStoppingBuffer_m" => 0.0,    #this gets multiplied by the sigmaMultiplier as defined in the intelligent driver, resulting in the total padding.
                                                      #this is equivalent to the max uncertainty considered in poseStandardDeviations
}

nominalDeceleration_mpss = 0.6;
nominalDecelerationMax_mpss = 0.9; # Increased the nominalDecelerationMax_mpss from 0.65 to 0.9 for IM4.5 due to MCM speed control changes that make our braking less aggressive
aggressiveDeceleration_mpss = 2.0;
criticalDeceleration_mpss = 2.5;

# descriptions of all of these parameters can be found in the powerpoint
# presentation titled "Revised Speed Control"
SpeedControlSettings = {

  # these decelerations are used to obey MM and RGA speed limits
  "pathConstraintDesiredDeceleration_mpss" => nominalDeceleration_mpss,
  "pathConstraintMaximumDeceleration_mpss" => nominalDecelerationMax_mpss,

  # these parameters are for stopping at the end of a lane or at a staging point
  "stoppingDesiredDeceleration_mpss" => nominalDeceleration_mpss,
  "stoppingMaximumNominalDeceleration_mpss" => nominalDecelerationMax_mpss,
  "stoppingCriticalDeceleration_mpss" => criticalDeceleration_mpss,
  "crawlSpeed_mps" => 1.25, #1.5,

  # these parameters control distance keeping
  "siteAwarenessDistanceKeepingDesiredDeceleration_mpss" => nominalDeceleration_mpss,
  "siteAwarenessQueuingMinDeceleration_mpss" => nominalDecelerationMax_mpss, # use a slightly larger decerleraion to tighten up following distance
  "siteAwarenessQueuingAggressiveDeceleration_mpss" => aggressiveDeceleration_mpss,

  # these parametes control decelerating to meet external regulations
  "speedRegulationNominalDeceleration_mpss" => nominalDeceleration_mpss,
  "speedRegulationAggressiveDeceleration_mpss" => aggressiveDeceleration_mpss,
  "speedRegulationCriticalDeceleration_mpss" => criticalDeceleration_mpss,
  
  # these parameters are used for simulating delays
  "minVehicleSpeedMagnitude_mps" => truckMinVehicleSpeedMagnitude_mps,
  "maxVehicleForwardSpeedMagnitude_mps" => truckMaximumForwardSpeed_mps,
  "maxVehicleReverseSpeedMagnitude_mps" => truckMaximumReverseSpeed_mps,

  # these parameters are used for reacting to visibility reductions
  "visibilityTargetDeceleration_mpss" => aggressiveDeceleration_mpss,
  "visibilityMaxDeceleration_mpss" => nominalDecelerationMax_mpss,

  # these parameters are for decelerating for the staging point crawl speed (these may be less than nominal decel)
  "stagingPointCrawlDesiredDeceleration_mpss" => 0.60,
  "stagingPointCrawlMaximumDeceleration_mpss" => 0.90,

  # these parameters are used for reacting to bump signals
  "bumpSignalTargetDeceleration_mpss" => aggressiveDeceleration_mpss,
  "bumpSignalMaxDeceleration_mpss" => aggressiveDeceleration_mpss,

  # tolerances for smart speed control
  "lookAheadTime_sec" => 1.0,        #look ahead delta once it reaches the nominal command speed
  "accelerationTime_sec" => 5.0,     #maximum time for acceleration to cap look ahead
  "higherSpeedTolerance_mps" => 0.0, #from 0.50 ~ 1.00, disable smart speed control by making this very large
  "lowerSpeedTolerance_mps" => 0.0,  #from 0.00 ~ 0.25
  "activationSpeed_mps" => 3.5,      #above crawl Speed
  "enableSmartControl" => true,      #to enable smart speed control. Set to false to behave as baseline

  # whether or not to scale decelerations to correct for aggressive decelerations of unloaded machines
  "EnableDecelScaling" => false,

  # Enable stopping constraint due to visibility range
  "enableVisibilityConstraintFix" => true,
}

PositionReport2_OutgoingMessageHandler = {
  "followerDecelerationRate_mpsps" => nominalDecelerationMax_mpss,
  "allowedLatency_sec" => 1.5,
  "queueingDistance_m" => truckQueuingDistance_m,

  "NormalTxRate_sec" => 1,
  "NormalTxDistanceTravelled_m" => 10,
  "NoCommsTxRate_sec" => 1,
  "NoPr2UntilPositionAccuracyLessThan_m" => 50,

#  For a positioning fault, Reported accuracy in PR2 (m) = MIN(Last Know Good RMS + 3 + vehicleSpeedToMaxDistanceSlope * VehicleSpeed (last known), 99.0m)
  "VehicleMaxStoppingDistance_m" => 99,                         # 99m is the max stopping distance, used to report position accuracy 
  "VehicleSpeedCorrespondingToMaxStoppingDistance_mps" => 12.6, # 12.6 m/s is the lowest speed that corresponds to the max stopping distance of 99m
								# speeds from 0 to 12.6m/s will have stopping distances that will vary lineary between 0 to 99m
}

StabilitySettings = {
  "commandLimitScalar" => [1.0, 1.0],    # MT, LD; speed scaling for empty and loaded state separately
  "mapFileName" => "/calibration/StabilityMap_793_v4r.dat",  # v4r does not reduce downhill speeds in reverse
  "mapFileMD5Sum" => "09db7d27a9d7529d34c349e2ef32a24d",     # for v4q "ec7cb35fbeaf03b6dcd6cf85ed328430"
  
  "curvatureThresholds" => [0.0, 0.0002, 0.1, 100, 0.01], # [offset | base | slope | maxDistance | zerovalue] for curvatures
  "gradeThresholds" => [0.03, 0.005, 0.1, 100, 0.01],     # [offset | base | slope | maxDistance | zerovalue] for grade
  "segmentDurations_sec" => [0.1, 6.0],                # minimum time spent in [step | hill]
  "accelerationScalings" => [1.0, 1.0],                # [MT | LD] multiplier to accelerations, increasing may generate faster speed plan but may not be as feasible
  "decelerationScalings" => [1.0, 1.0],                # [MT | LD] multiplier to decelerations, increasing may generate faster speed plan but may not be as feasible
  "tractionBooleanCoefficients" => [0.2, 0.5],         # [Wet | Dry] 0.20 is indicative of very wet clay or partial ice conditions (only used for metric calculation, not for speeds)
                                                       #             0.50 is conservative for dry clay roads (only used for metric calculation, not for speeds) 
  "usePerceptionLimits" => true,               # set to false to ignore perception field-of-view limits on turns (will not affect implications of stopping range due to perception range)
  "perceptionRange_m" => 87.0,                 # to be removed when ready (35 m poor range, 80+ normal range)
  "actuationDelay_sec" => 1.42,                # latency between when an obstacle comes into sensing range and when the brakes are applied  
  "geometryScaling" => [1.0, 1.0, 0.0, 1.0],   # [curvature | grade | bank | heading ] used for calculating geometry. Increasing this reduces choppiness (pre-filter) but removes detail
  "filterFactor" => [3.0, 3.0, 1.0],           # [curvature | grade | bank ] used for filtering geometry. Increasing this makes curves/grades seem less sharp.  

  "useExtendedCurvatureFilter" => true,        # if true, this will additionally filter using a variable window width for curvature
  "curvatureVariableValueFilter" =>  [ 0.002, 0.01, 0.02, 0.03, 0.04, 0.06, 0.08, 0.10, 0.2 ], #relationship between curvature and window size. Must be at least size 2. This is for curvature
  "curvatureVariableWindowFilter" => [ 0.000, 4.92, 3.22, 1.50, 0.40, 0.18, 0.15, 0.13, 0.1 ], #relationship between curvature and window size. Must be at least size 2. This is for window size
  "curvatureFilterThreshold" => 0.02,          # noise threshold used in the variable window filter
  "curvatureRefilterFactor" => 0.5,            # refiltering done on variable window filter solution, fixed window factor

  "useExtendedGradeFilter" => false,           # (NOT TESTED ON HAUL TRUCK, leave as false) if true, this will additionally filter using a variable window width for grade
  "gradeVariableValueFilter" =>      [0.00, 0.03, 0.10, 0.15], #relationship between grade and window size. Must be at least size 2. This is for grade
  "gradeVariableWindowFilter" =>     [0.10, 0.10, 0.10, 0.10], #relationship between grade and window size. Must be at least size 2. This is for window size
  "gradeFilterThreshold" => 0.005,             # noise threshold used in the variable window filter
  "gradeRefilterFactor" => 0.5,                # refiltering done on variable window filter solution, fixed window factor

  "constantizers" => [1, 1, 0],                # [constantize | minimizeCurvature | minimizeGrade ] 1 = true; without this, curves and grades don't get grouped into constant segments
  "useNoiseAllowance" => true,                 # true means 'impulses' in grade or curvature will be reentered into the filtered values. Leave as true.
  "slewRateScaling" => 0.5,                    # scale the maximum slew rate so as to not push for maximum slew rate
  "distanceBeforeTurn_m" => [5.0, 5.0],        # [MT | LD] This is the distance the vehicle should slow down before executing a turn
  "distanceAfterTurn_m" =>  [0.0, 0.0],        # [MT | LD] This is the distance the vehicle should slow down after executing a turn
  "distanceBeforeUphill_m" =>   [ 0.0,  0.0],  # [MT | LD] This is the distance the vehicle should slow down before an uphill climb
  "distanceAfterUphill_m" =>    [ 0.0,  0.0],  # [MT | LD] This is the distance the vehicle should slow down after  an uphill climb
  "distanceBeforeDownhill_m" => [12.0, 12.0],  # [MT | LD] This is the distance the vehicle should slow down before an downhill descent
  "distanceAfterDownhill_m" =>  [ 0.0,  0.0],  # [MT | LD] This is the distance the vehicle should slow down after  an downhill descent
    
  "margins_m" => [0.20, 1.50, 0.00, -3.00, 0.20, 2.00, 0.00, -3.00], # [ zeroSpeed-Sim | fullSpeed-Sim | nominalDecel-Sim | aggressiveDecel-Sim | zeroSpeed-Path | fullSpeed-Path | nominalDecel-Path | aggressiveDecel-Path ] NEGATIVE means outside of lane boundary  
  "usePointUpsampling" => true,                # true will tell the RGA to upsample the path at the desired sample rate
  "upsamplingLength_m" => 1.00,                # minimum distance used in RGA upsampling
  "gradeLengthParameters" => [0.01, 900, 1800, 200, 0.05], # gradeLength parameters [ gradeThreshold | nearlyContinuous | equivalentContinuous | partialGradeLength | partialGrade ]
  "bankParameters" => [0.01, 0.030, 0.001, 0.164, 0.10],   # bank parameters [ bankThreshold | minimum bank required out of turn | minimum bank required into turn | maximum noisy bank | actual maximum bank ]
  "curvatureModeParameters" => [0, 0, 30],     # [curvatureMode(0=Diff,1=Menger,2=LS) | autoAdjust | autoAdjustParameter] 

  "enforceNonValidatedGrade" => true,          # When true, will ensure that safeguarding is used until lane is validated
  "nonValidatedGradeParameters" => [1.0, 1.0, -0.14, 3.00], # [updateGradeIfExceeded | applySpeedDerate | nonValidatedGrade | deratedSpeed ]    
                                               # updateGradeIfExceeded: when not validated, if 1.0 then will modify the grade only if abs(grade) exceeds abs(specified grade limit), if 0.0, it always modifies the grade
                                               # applySpeedDerate: when not validated, if 1.0 and grade was modified, then apply a derated speed limit (unless the stability limit is lower)
                                               # nonValidatedGrade: grade to set as a worst case grade to consider. This is always negative
                                               # deratedSpeed: derated speed to use

  "useOverlap" => true,                        # When true, this will use precomputed overlap data in order to make calculates about our route more accurate
  "futureGradeLimit" => [-0.20, 0.20],         # [ downhill | uphill ] The minimum/maximum amount of grade allowed detected from future grade/bank channel
  "futureBankLimit" => [-0.15, 0.15],          # [ left | right ] The minimum/maximum amount of bank allowed detected from future grade/bank channel
}


BodyCapabilities = {
# Used by MachineStateManager to determine the nominal settings/thresholds for this type of vehicle
  "lsmEmptyTruckWeight"  => 166,     # tonnes (metric tons)
  "lsmNominalPayloadWeight" => 217,  # tonnes (metric tons)
  "lsmBodyDownPercThold" =>  5.0,   # percent, 5 for 5%
  "lsmIgnoreMCMPayloadValue" => false,

# Used by ObiMineModel to determine the default Machine dimensions
  # This is the default bounding box to use, these are referenced from the vehicle's origin at 0 heading
  "NumberOfBoundingBoxPoints" => 4,
  # "pointNum" => [x_m, y_m]
    "00" => [-3.772, -3.840],
    "01" => [ 9.090, -3.840],
    "02" => [ 9.090, 3.840],
    "03" => [-3.772, 3.840],
}

# Used by MstarGeoClientConfig & OBIAssignmentPlugin to determine speed limit for SpecialAreas in OBIRouteObj 
Powertrain_Info = {
              "gearArray" => [-1.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0],
  "runoutSpeed_mps_Array" => [3.55,0.0,3.55,4.80,6.56,8.85,12.00,16.20,16.20,16.20],
}
 





# If there's an auxiliary file, load it
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/Vehicle_aux.rb"))
    puts "-----CONFIG: Updating Vehicle_xx.rb with mods from Vehicle_aux.rb"
    load "Vehicle_aux.rb"
end
