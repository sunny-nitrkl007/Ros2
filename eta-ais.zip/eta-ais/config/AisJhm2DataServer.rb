require "commonLoad.rb"
load "commonAutonomyTask.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
    "CPMDemoInput" => InterfaceDefs::CPMDemoInput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "cycleRate_hz" => 5,
#  "requireGPSTimeSynchronizationOnStart" => true, #added by Joshua
  "loggerThreshold" => "debug",  
} )

ScsRxTimeouts = {
  "CPMDemoInput_rxTimeout_sec"                  => 5.0,    # GPS1 rate is ?? sec
}

Execution = {
  "executableName" => "aisJhm2DataServer",
}

