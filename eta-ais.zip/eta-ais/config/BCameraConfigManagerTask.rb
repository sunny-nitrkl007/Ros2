require "commonLoad"
load "commonAutonomyTask.rb"

#when running this task initially, camera would be in 192.168.100.10 and camera would be sending messages to host 192.168.100.1. So we will need to change our ip address to 192.168.100.1
Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
      "loggerThreshold" => "warn",
      "cycleRate_hz" => 1, 
      "requireGPSTimeSynchronizationOnStart" => false,

      "CameraIP" => "165.26.79.50", #192.168.100.10 is the factory default ip adddress of the B-Cam. This will need to change, if new ip is configured.

      "VideoStreamHostUdpPort" => 25000, #port in which the camera communicates to the host for video frames and config responses.
      
      "NewVideoStreamHostUdpPort" => 25000,
      "NewCameraIP" => "165.26.79.50",
      "NewCameraSubnet" => "255.255.255.0",
      "NewHostIP" => "165.26.79.7",

      #once the task execution is complete, CameraIP would be changed to NewCameraIP and VideoStreamHostUdpPort would be changed to NewVideoStreamHostUdpPort
      #the above parameters CameraIP and VideoStreamHostUdpPort will need be modified inorder to perform any future configurations.

      #Valid values for camera configuration parameters
      #0x01: Image Mirroring enabled
      #0x02: Image Mirroring disabled
      #0x01: Auto Exposure enabled
      #0x02: Auto Exposure disabled
      #0x01: Auto White Balance enabled
      #0x02: Auto White Balance disabled
      #0x01: Auto Black Reference enabled
      #0x02: Auto Black Reference disabled
      #0x01: Resolution 1280 x 800
      #0x02: Resolution 1280 x 720
      #0x03: Resolution 800 x 480
      #0x04: Resolution 1024 x 768
      #0x01: Image Orientation 0°
      #0x02: Image Orientation 180°
      #0x01: Data rate 80Mbps
      #0x02: Data rate 60Mbps
      #0x03: Data rate 30Mbps
      #Gain
      #0x01: Default (0%)
      #0x02 – 0xCA 0% to 200%
      #Brightness
      #0x01: Default (100%)
      #0x02 – 0xCA 0% to 200%
      #Contrast
      #0x01: Default (100%)
      #0x02 – 0xCA 0% to 200%
      #Saturation
      #0x01: Default (100%)
      #0x02 – 0xCA 0% to 200%
      #Gamma Correction
      #0x01: Default 100 %
      #0x02: Value 2 (90%)
      #0x03: Value 3 (110%)
      #HDR
      #0x01 : HDR enabled
      #0x02 : HDR disabled

     #Camera Configuration 

     "DistortionCorrection" => 1,
     "ImageMirroring" => 1,
     "AutoExposure" => 1,
     "AutoWhiteBalance" => 1,
     "AutoBlackReference" => 1,
     "Resolution" => 1, 
     "ImageOrientation" => 1,
     "DataRate" => 1,
     "Gain" => 1,
     "Brightness" => 1,
     "Contrast" => 1,
     "Saturation" => 1,
     "GammaCorrection" => 1,
     "HDR" => 1

} )

Execution = {
    "executableName" => "bCameraConfigManager",
}

