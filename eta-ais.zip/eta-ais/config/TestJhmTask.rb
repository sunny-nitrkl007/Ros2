require "commonLoad.rb"
load "commonAutonomyTask.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
   "CPMDemoOutput" => InterfaceDefs::CPMDemoOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "fatal", # "fatal", "error", "warn", "notice", "info", "debug",
  "cycleRate_hz" => 2,
} )

Execution = {
  "executableName" => "TestJhmTask",
}

