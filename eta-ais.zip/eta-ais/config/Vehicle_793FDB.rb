# This is a vehicle file specific to 793 trucks with serial number
# prefix of *FDB* (793D series).  The first thing we do is load the
# common 793 machine specific data which is contained in file
# Vehicle_793.rb file.  Then we load the config parameters that are 
# specific to 793FDB machines which are D-series trucks.

#  Load common data
load "Vehicle_793.rb"

BodyCapabilities.update({
  "lsmEmptyTruckWeight"  => 185,     # tonnes (metric tons)
})


#  FDB specific vehicle data
ModelSpecificData = {
  "lsmUsingTotalTruckWeightPID" => true,
}

#Load PIM2 Data
#load "PIM2Config_793FDB.rb" # PIM2Configuration now loaded by StateEstimator2_MachineType.rb
