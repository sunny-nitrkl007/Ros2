# this file declares all messaging interfaces for the system, starting with the core functionality
# and branching out into separate files for sensor- and project-specific interface definitions

require 'CANFilters.rb'
require 'IPAddresses.rb'

# clean old cruft to suppress warnings
if defined?(InterfaceDefs)
    Object.send(:remove_const, :InterfaceDefs)
end

module InterfaceDefs

    # This is the compression used for datums we specific want to compress. This
    # is compression is also used by the RangeImageLogger.
    DefaultCompression = "lz4"

    # Make a true deep-copy of an interface: ruby's built-in clone/dup methods are shallow-copy only, so:
    #
    # Bar = Foo.dup
    # Bar["channel"]["queueSize"] = 5
    #
    # ...will, somewhat unexpectedly modify Foo["channel"]["queueSize"] as well
    def InterfaceDefs.deepCopy(interfaceInstance)
        # dup gets us a shallow copy, but the "channel" field will point to the same underlying hash
        out = interfaceInstance.dup

        # check for and deep-copy the channel hash as well
        if interfaceInstance.has_key?("channel")
            out["channel"] = interfaceInstance["channel"].dup
        end

        return out
    end

    # the basic pattern is to describe an input and an output as follows:
    ExampleOutput = {
        # this describes the shared library for converting raw payloads into message classes (libExample.Channel.Output.so)
        "interface" => "Example.Channel.Output",

        # this describes the desired mechanism for transporting the raw payloads
        "channel" => {
            "type" => "SimpleComms",      # most of our interfaces use the "SimpleComms" (aka "scs") transport
            "queueSize" => 1,             # most channel types support some queuing of messages
            "name" => "Example.Channel",  # this is the semantic name of the payload (akin to ROS "topics")
            "unixPath" => "scs",        # without an explicit refernce to "unixPath", the default value will be scs
            "compression" => "passthrough", # use no compression
        }
    }

    # the counterpart mostly matches, except...
    ExampleInput = {
        "interface" => "Example.Channel.Input", # < "Input" instead of "Output"
        "channel" => {
            "type" => "SimpleComms",
            "queueSize" => 1,                   # < Larger "queueSize" is typical for inputs, but we mostly
                                                #   want only latest information (queue size of 1)
            "name" => "Example.Channel",
            ##"unixPath" => "scs",        # without an explicit refernce to "unixPath", the default value will be scs
            #"compression" => "passthrough",     # not used to read & de-serialize datums
        }
    }

    ###############################
    # Create Input Interface
    #   Type = "SimpleComms"
    #   QueueSize = 1
    ###############################
    def InterfaceDefs.createBasicInputInterface(nameOfInterface)
        inputChannel = Hash.new
        # dup gets us a shallow copy, but the "channel" field will point to the same underlying hash
        inputChannel = deepCopy(ExampleInput)
        # check for and deep-copy the channel hash as well
        if inputChannel.has_key?("interface")
            inputChannel["interface"] = "#{ nameOfInterface }.Channel.Input"
        end

        if inputChannel.has_key?("channel")
            inputChannel["channel"]["name"] = "#{ nameOfInterface }.Channel"
        end

        return inputChannel
    end

    ###############################
    # Create Output Interface
    #   Type = "SimpleComms"
    #   QueueSize = 1
    ###############################
    def InterfaceDefs.createBasicOutputInterface(nameOfInterface)
        outputChannel = Hash.new
        # dup gets us a shallow copy, but the "channel" field will point to the same underlying hash
        outputChannel = deepCopy(ExampleOutput)
        # check for and deep-copy the channel hash as well
        if outputChannel.has_key?("interface")
            outputChannel["interface"] = "#{ nameOfInterface }.Channel.Output"
        end

        if outputChannel.has_key?("channel")
            outputChannel["channel"]["name"] = "#{ nameOfInterface }.Channel"
        end

        return outputChannel
    end

###########
VehicleStateOutput = createBasicOutputInterface("VehicleState")
VehicleStateInput = createBasicInputInterface("VehicleState")

##ID has its own VehicleState interface so it can have a larger queue size than the default VehicleState input
VehicleStateForIntelligentDriverOutput = createBasicOutputInterface("VehicleState")
VehicleStateForIntelligentDriverOutput["channel"]["queueSize"] = 5;
VehicleStateForIntelligentDriverInput = createBasicInputInterface("VehicleState")
VehicleStateForIntelligentDriverInput["channel"]["queueSize"] = 5;

# We really don't want to lose any data so, and these aren't
# that big, so queue 2 seconds worth (at 100 Hz)
VehicleStateInputForRangeInterface = createBasicInputInterface("VehicleState")
VehicleStateInputForRangeInterface["channel"]["queueSize"] = 2 * 100;


SimVehicleStateOutput = createBasicOutputInterface("VehicleState")
SimVehicleStateOutput["channel"]["name"] = "SimVehicleState.Channel";
SimVehicleStateInput = createBasicInputInterface("VehicleState")
SimVehicleStateInput["channel"]["name"] = "SimVehicleState.Channel";

FileGlobOutput = createBasicOutputInterface("FileGlob")
FileGlobInput = createBasicInputInterface("FileGlob")

ZFileGlobOutput = createBasicOutputInterface("FileGlob")
ZFileGlobOutput["channel"]["name"] = "FileGlob.ZChannel";
ZFileGlobOutput["channel"]["compression"] = DefaultCompression;
ZFileGlobInput = createBasicInputInterface("FileGlob")
ZFileGlobInput["channel"]["name"] = "FileGlob.ZChannel";

# Applanix log fragments
ZApplanixLogFragmentOutput = createBasicOutputInterface("ApplanixLogFragment")
ZApplanixLogFragmentOutput["channel"]["name"] = "ApplanixLogFragment.ZChannel";
ZApplanixLogFragmentOutput["channel"]["compression"] = DefaultCompression;
ZApplanixLogFragmentInput = createBasicInputInterface("ApplanixLogFragment")
ZApplanixLogFragmentInput["channel"]["name"] = "ApplanixLogFragment.ZChannel";

ApplanixLoggerStatusOutput = createBasicOutputInterface("ApplanixLoggerStatus")
ApplanixLoggerStatusInput = createBasicInputInterface("ApplanixLoggerStatus")

# Auxiliary Applanix log fragments
ZAuxiliaryApplanixLogFragmentOutput = createBasicOutputInterface("ApplanixLogFragment")
ZAuxiliaryApplanixLogFragmentOutput["channel"]["name"] = "AuxiliaryApplanixLogFragment.ZChannel";
ZAuxiliaryApplanixLogFragmentOutput["channel"]["compression"] = DefaultCompression;
ZAuxiliaryApplanixLogFragmentInput = createBasicInputInterface("ApplanixLogFragment")
ZAuxiliaryApplanixLogFragmentInput["channel"]["name"] = "AuxiliaryApplanixLogFragment.ZChannel";

AuxiliaryApplanixLoggerStatusOutput = createBasicOutputInterface("ApplanixLoggerStatus")
AuxiliaryApplanixLoggerStatusOutput["channel"]["name"] = "AuxiliaryApplanixLoggerStatus.Channel";
AuxiliaryApplanixLoggerStatusInput = createBasicInputInterface("ApplanixLoggerStatus")
AuxiliaryApplanixLoggerStatusInput["channel"]["name"] = "AuxiliaryApplanixLoggerStatus.Channel";

# VelodyneSweep
VelodyneSweepInput = createBasicInputInterface("VelodyneSweep")
VelodyneSweepInput["channel"]["queueSize"] = 20;
VelodyneSweepOutput = createBasicOutputInterface("VelodyneSweep")

ZVelodyneSweepOutput = createBasicOutputInterface("VelodyneSweep")
ZVelodyneSweepOutput["channel"]["name"] = "VelodyneSweep.ZChannel";
ZVelodyneSweepOutput["channel"]["compression"] = DefaultCompression;

ZVelodyneSweepInput = createBasicInputInterface("VelodyneSweep")
ZVelodyneSweepInput["channel"]["name"] = "VelodyneSweep.ZChannel";
ZVelodyneSweepInput["channel"]["queueSize"] = 20;
  
# PcapData
ZPcapDataOutput = createBasicOutputInterface("PcapData")
ZPcapDataOutput["channel"]["name"] = "PcapData.ZChannel";
ZPcapDataOutput["channel"]["compression"] = DefaultCompression;
ZPcapDataInput = createBasicInputInterface("PcapData")
ZPcapDataInput["channel"]["name"] = "PcapData.ZChannel";

################
# PBL Data Types
KVHInertialDataOutput = createBasicOutputInterface("KVHInertialData")
SanityCheckerReportOutput = createBasicOutputInterface("SanityCheckerReport")
SanityCheckerDiagnosticOutput = createBasicOutputInterface("SanityCheckerDiagnostic")
SanityCheckerDebugOutput = createBasicOutputInterface("SanityCheckerDebug")

SanityCheckerReportInput = createBasicInputInterface("SanityCheckerReport")
SanityCheckerDiagnosticInput = createBasicInputInterface("SanityCheckerDiagnostic")
SanityCheckerDebugInput = createBasicInputInterface("SanityCheckerDebug")

PBLStateInput  = createBasicInputInterface("PBLState");
PBLStateOutput = createBasicOutputInterface("PBLState");
PBLStateDebugInput = createBasicInputInterface("PBLState");
  PBLStateDebugInput["channel"]["name"] = "PBLStateDebug.Channel";
PBLStateDebugOutput = createBasicOutputInterface("PBLState");
  PBLStateDebugOutput["channel"]["name"] = "PBLStateDebug.Channel";

PBLFilterStateInput  = createBasicInputInterface("PBLFilterState");
PBLFilterStateOutput = createBasicOutputInterface("PBLFilterState");
PBLTargetStatisticsInput = createBasicInputInterface("PBLTargetStatistics")
PBLTargetStatisticsOutput = createBasicOutputInterface("PBLTargetStatistics")

FilterInputLogInput = createBasicInputInterface("FilterInputLog")
FilterInputLogOutput = createBasicOutputInterface("FilterInputLog");

TargetHealthReportInput = createBasicInputInterface("TargetHealthReport");
TargetHealthReportOutput = createBasicOutputInterface("TargetHealthReport");

FutureGradeAndBankInput = createBasicInputInterface("FutureGradeAndBank");
FutureGradeAndBankOutput = createBasicOutputInterface("FutureGradeAndBank");

################

PcmCommandOutput = createBasicOutputInterface("PcmCommand")
PcmCommandInput = createBasicInputInterface("PcmCommand")
PcmCommandInput["channel"]["queueSize"] = 10;

PcmStatusOutput = createBasicOutputInterface("PcmStatus")
PcmStatusInput = createBasicInputInterface("PcmStatus")
PcmStatusInput["channel"]["queueSize"] = 10;

ProcessHealthOutput = createBasicOutputInterface("ProcessHealth")
ProcessHealthOutput["channel"]["queueSize"] = 100;
ProcessHealthInput = createBasicInputInterface("ProcessHealth")
ProcessHealthInput["channel"]["queueSize"] = 100;
ProcessHealthForDisplayInput = createBasicInputInterface("ProcessHealth")
ProcessHealthForDisplayInput["channel"]["queueSize"] = 30;

ExampleOutputAltDomain = {
    "interface" => "Example.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "Example.Channel",
        "unixPath" => "alt",  #< this is equivalent to setting SCS_PATH=alt.  you must have an instance of scs --unixPath=alt to connect!
        "compression" => "passthrough",
    }
}

ExampleInputAltDomain = {
    "interface" => "Example.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 2,
        "name" => "Example.Channel",
        "unixPath" => "alt",  #< this is equivalent to setting SCS_PATH=alt.  you must have an instance of scs --unixPath=alt to connect!
    }
}

ExampleInput2 = ExampleInput.dup;

ClockSystem = {
    "interface" => "Clock.System",
}

ClockPlaybackServer = {
    "interface" => "ClockPlaybackServer", #"Clock.PlaybackServer",
   "channel" => {
       "type" => "SimpleComms",
       "priority" => 1,
       "queueSize" => 1,
       "name" => "Clock.Playback",
       "compression" => "passthrough",
   }
}

ClockPlaybackClient = {
    "interface" => "ClockPlaybackClient",#"Clock.PlaybackClient",
   "channel" => {
       "type" => "SimpleComms",
       "priority" => 1,
       "queueSize" => 1,
       "name" => "Clock.Playback",
   }
}


MCMVehicleCommandOutput = createBasicOutputInterface("MCMVehicleCommand")
MCMVehicleCommandInput = createBasicInputInterface("MCMVehicleCommand")

MCIVehicleCommandOutput = createBasicOutputInterface("MCIVehicleCommand")
MCIVehicleCommandInput = createBasicInputInterface("MCIVehicleCommand")

MCMScriptVehicleCommandOutput = createBasicOutputInterface("MCMScriptVehicleCommand")
MCMScriptVehicleCommandInput = createBasicInputInterface("MCMScriptVehicleCommand")

ApplanixStateOutput = createBasicOutputInterface("Applanix")
ApplanixStateInput = createBasicInputInterface("Applanix")

#These are for PIM testing, and will not ever be sent by the online system
ApplanixState2Input = {
    "interface" => "Applanix.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "ApplanixState2.Channel",
    }
}

ApplanixState2Output = {
    "interface" => "Applanix.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "ApplanixState2.Channel",
        "compression" => "passthrough",
    }
}


MCMStatusOutput = createBasicOutputInterface("MCMStatus")
MCMStatusInput = createBasicInputInterface("MCMStatus")

ApplanixStatePOSLV220Input = {
    "interface" => "Applanix.POSLV220",
    "useDMISpeed" => true,
    # [ b, a ] = butter(2, 10 / 100)
    "dmiFilterB" => [ 0.020083, 0.040167, 0.020083 ],
    "dmiFilterA" => [ 1.00000, -1.56102, 0.64135 ],

    #Must configure either localCoordSystem file or
    #utmZone, but not both
    #"conversionType" => 1,  #0 = localCoordSys File, 1 = UTM Conversion

    # Local Coordinate System configuration
    # (referenced from CAT_DIR, and requires leading "/" )
    #"localCoordSystem" => "/coordSystem/actt_local.dc",
    #"localCoordSystem" => "/coordSystem/NAVAJO_cal_scs900.dc",
    #"localCoordSystem" => "/coordSystem/TPG_CS09.dc",

    #"useMappingFrame" => true,

    # UTM configuration
    #   "utmZone" => AuxInterface::WorldLocation["UtmZone"],
    #"utmZone" => 17, # Pittsburgh,PA
    #"utmZone" => 16, # Peoria,Il
    #"utmZone" => 12, # Safford,AZ
      
      
    "useUDP" => true, # whether or not applanix is configured to send UDP packets on the data port
    "applanixIP" => IPAddressMap.fetch("applanix"), ## used when data port is configured for TCP
    "dataPortRecvAddress" => IPAddressMap.fetch("auto2"), # used when data port is configured for UDP 
    "dispPortRecvAddress" => IPAddressMap.fetch("broadcastAddress"), # display port receive address
}

AuxiliaryApplanixStatePOSLV220Input = ApplanixStatePOSLV220Input.dup;
AuxiliaryApplanixStatePOSLV220Input["useUDP"] = false;
AuxiliaryApplanixStatePOSLV220Input["applanixIP"] = IPAddressMap.fetch("auxiliaryApplanix_eth2");
AuxiliaryApplanixStatePOSLV220Input["dataPortRecvAddress"] = IPAddressMap.fetch("broadcastAddress_eth2");
AuxiliaryApplanixStatePOSLV220Input["dispPortRecvAddress"] = IPAddressMap.fetch("broadcastAddress_eth2");

AuxiliaryApplanixStateInput = {
  "interface" => "Applanix.Channel.Input",
  "channel" => {
      "type" => "SimpleComms",
      "queueSize" => 1,
      "name" => "AuxiliaryApplanixState.Channel",
    }
}

AuxiliaryApplanixStateOutput = {
    "interface" => "Applanix.Channel.Output",
  "channel" => {
      "type" => "SimpleComms",
      "queueSize" => 1,
      "name" => "AuxiliaryApplanixState.Channel",
      "unixPath" => "scs",
      "compression" => "passthrough",
    }
}

# GenericDebug1 used for PIM Debug data
GenericDebug1Input = createBasicInputInterface("GenericDebug1")
GenericDebug1Input["interface"] = "GenericDebug.Channel.Input";
GenericDebug1Output = createBasicOutputInterface("GenericDebug1")
GenericDebug1Output["interface"] = "GenericDebug.Channel.Output";

# GenericDebug2 used for MCI Debug data
GenericDebug2Input = createBasicInputInterface("GenericDebug2")
GenericDebug2Input["interface"] = "GenericDebug.Channel.Input";
GenericDebug2Output = createBasicOutputInterface("GenericDebug2")
GenericDebug2Output["interface"] = "GenericDebug.Channel.Output";


MCMBodyCommandInput = createBasicInputInterface("MCMBodyCommand")
MCMBodyCommandOutput = createBasicOutputInterface("MCMBodyCommand")

FakeVehicleStateInput = {
    "interface" => "VehicleState.Fake.Input",
    # Gascola Site coordinates
    "x" => 603117.2,
    "y" => 4479092.3,
    "z" => 250.0,
    "theta" => 50.0,
}

SnapshotCreationRequestOutput = createBasicOutputInterface("SnapshotCreationRequest")
SnapshotCreationRequestOutput["channel"]["queueSize"] = 10
SnapshotCreationRequestInput = createBasicInputInterface("SnapshotCreationRequest")
SnapshotCreationRequestInput["channel"]["queueSize"] = 10

SnapshotCreationResponseOutput = createBasicOutputInterface("SnapshotCreationResponse")
SnapshotCreationResponseInput = createBasicInputInterface("SnapshotCreationResponse")

SnapshotDeletionRequestOutput = createBasicOutputInterface("SnapshotDeletionRequest")
SnapshotDeletionRequestOutput["channel"]["queueSize"] = 50

SnapshotDeletionRequestInput = createBasicInputInterface("SnapshotDeletionRequest")
SnapshotDeletionRequestInput["channel"]["queueSize"] = 50

SnapshotBridgeStatusOutput = createBasicOutputInterface("SnapshotBridgeStatus")
SnapshotBridgeStatusInput = createBasicInputInterface("SnapshotBridgeStatus")

LoggerStatusOutput = createBasicOutputInterface("LoggerStatus")
LoggerStatusInput = createBasicInputInterface("LoggerStatus")

# applx logger
ApplxLoggerStatusOutput = createBasicOutputInterface("ApplxLoggerStatus")
ApplxLoggerStatusOutput["interface"] = "LoggerStatus.Channel.Output";
ApplxLoggerStatusInput = createBasicInputInterface("ApplxLoggerStatus")
ApplxLoggerStatusInput["interface"] = "LoggerStatus.Channel.Input";

SyslogBridgeStatusOutput = createBasicOutputInterface("SyslogBridgeStatus")
SyslogBridgeStatusInput = createBasicInputInterface("SyslogBridgeStatus")

LoggerCommentsOutput = createBasicOutputInterface("LoggerComments")
LoggerCommentsInput = createBasicInputInterface("LoggerComments")

LogStopOutput = createBasicOutputInterface("LogStop")
LogStopInput  = createBasicInputInterface("LogStop")

LogStartOutput = createBasicOutputInterface("LogStart")
LogStartInput = createBasicInputInterface("LogStart")

LogPauseOutput = createBasicOutputInterface("LogPause")
LogPauseInput = createBasicInputInterface("LogPause")

LogResumeOutput = createBasicOutputInterface("LogResume")
LogResumeInput = createBasicInputInterface("LogResume")

PlaybackLogCommandsOutput = createBasicOutputInterface("PlaybackLogCommands")
PlaybackLogCommandsInput = createBasicInputInterface("PlaybackLogCommands")

PlaybackLogOpenOutput= createBasicOutputInterface("PlaybackLogOpen")
PlaybackLogOpenInput = createBasicInputInterface("PlaybackLogOpen")

MS990PoseInput = createBasicInputInterface("MS990Pose")
MS990PoseOutput = createBasicOutputInterface("MS990Pose")

BD950PositionInput = createBasicInputInterface("BD950Position")
BD950PositionOutput = createBasicOutputInterface("BD950Position")

BD950Position1Input = {
    "interface" => "BD950Position.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "BD950Position1.Channel",
    }
}

BD950Position1Output = {
    "interface" => "BD950Position.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "BD950Position1.Channel",
        "compression" => "passthrough",
    }
}

BD950Position2Input = {
    "interface" => "BD950Position.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "BD950Position2.Channel",
    }
}

BD950Position2Output = {
    "interface" => "BD950Position.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "BD950Position2.Channel",
        "compression" => "passthrough",
    }
}

BD950Position3Input = {
    "interface" => "BD950Position.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "BD950Position3.Channel",
    }
}

BaseCANLoggerDataInput = createBasicInputInterface("BaseCANLoggerData")
BaseCANLoggerDataInput["channel"]["queueSize"] = 50;
BaseCANLoggerDataOutput = createBasicOutputInterface("BaseCANLoggerData")
BaseCANLoggerDataOutput["channel"]["queueSize"] = 50;

EddtStatisticsInput = createBasicInputInterface("EddtStatistics")
EddtStatisticsOutput = createBasicOutputInterface("EddtStatistics")

BaseCANLoggerDataAInput = {
    "interface" => "BaseCANLoggerData.Channel.Input",
    "channel" => {
      "type" => "SimpleComms",
      "priority" => 1,
      "queueSize" => 100,
      "name" => "BaseCANLoggerDataA.Channel",
    }
}

BaseCANLoggerDataAOutput = {
    "interface" => "BaseCANLoggerData.Channel.Output",
    "channel" => {
      "type" => "SimpleComms",
      "priority" => 1,
      "queueSize" => 100,
      "name" => "BaseCANLoggerDataA.Channel",
      "compression" => "passthrough",
    }
}

BaseCANLoggerDataBInput = {
    "interface" => "BaseCANLoggerData.Channel.Input",
    "channel" => {
      "type" => "SimpleComms",
      "priority" => 1,
      "queueSize" => 100,
      "name" => "BaseCANLoggerDataB.Channel",
    }
}

BaseCANLoggerDataBOutput = {
    "interface" => "BaseCANLoggerData.Channel.Output",
    "channel" => {
      "type" => "SimpleComms",
      "priority" => 1,
      "queueSize" => 100,
      "name" => "BaseCANLoggerDataB.Channel",
      "compression" => "passthrough",
    }
}

  BaseCANRawCcpDataAInput = {
      "interface" => "BaseCANLoggerData.Channel.Input",
      "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "BaseCANRawCcpDataA.Channel",
      }
  }

  BaseCANRawCcpDataAOutput = {
      "interface" => "BaseCANLoggerData.Channel.Output",
      "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "BaseCANRawCcpDataA.Channel",
        "compression" => "passthrough",
      }
  }

  BaseCANRawCcpDataBInput = {
      "interface" => "BaseCANLoggerData.Channel.Input",
      "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "BaseCANRawCcpDataB.Channel",
      }
  }

  BaseCANRawCcpDataBOutput = {
      "interface" => "BaseCANLoggerData.Channel.Output",
      "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "BaseCANRawCcpDataB.Channel",
        "compression" => "passthrough",
      }
  }

  BaseCANRawEddtDataInput = {
      "interface" => "BaseCANLoggerData.Channel.Input",
      "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "BaseCANRawEddtData.Channel",
      }
  }

  BaseCANRawEddtDataOutput = {
      "interface" => "BaseCANLoggerData.Channel.Output",
      "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "BaseCANRawEddtData.Channel",
        "compression" => "passthrough",
      }
  }

BaseMachineLoggerStatusOutput = createBasicOutputInterface("BaseMachineLoggerStatus")
BaseMachineLoggerStatusOutput["channel"]["queueSize"] = 10;
BaseMachineLoggerStatusInput = createBasicInputInterface("BaseMachineLoggerStatus")
BaseMachineLoggerStatusInput["channel"]["queueSize"] = 10;

ApplanixImuFaultOutput = createBasicOutputInterface("ApplanixImuFault")
ApplanixImuFaultInput = createBasicInputInterface("ApplanixImuFault")

ApplanixVersionInfoOutput = createBasicOutputInterface("ApplanixVersionInfo")
ApplanixVersionInfoInput = createBasicInputInterface("ApplanixVersionInfo")

ApplanixNavigationModeOutput = createBasicOutputInterface("ApplanixNavigationMode")
ApplanixNavigationModeInput = createBasicInputInterface("ApplanixNavigationMode")

BD950Position3Output = {
    "interface" => "BD950Position.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "BD950Position3.Channel",
        "compression" => "passthrough",
    }
}

TMACServerInput = createBasicInputInterface("TMACServer")
TMACServerInput["channel"]["queueSize"] = 10;
TMACServerOutput = createBasicOutputInterface("TMACServer")
TMACServerOutput["channel"]["queueSize"] = 10;

TMACClientInput = createBasicInputInterface("TMACClient")
TMACClientInput["channel"]["queueSize"] = 10;
TMACClientOutput = createBasicOutputInterface("TMACClient")
TMACClientOutput["channel"]["queueSize"] = 10;

RTKCorrectionsInput = createBasicInputInterface("RTKCorrections")
RTKCorrectionsOutput = createBasicOutputInterface("RTKCorrections")

TargetUpdateInput = createBasicInputInterface("TargetUpdate")
TargetUpdateOutput = createBasicOutputInterface("TargetUpdate")

PlaybackLogDetailsOutput = createBasicOutputInterface("PlaybackLogDetails")
PlaybackLogDetailsInput = createBasicInputInterface("PlaybackLogDetails")

IntelligentDriverStateOutput = createBasicOutputInterface("IntelligentDriverState")
IntelligentDriverStateOutput["channel"]["compression"] = DefaultCompression;
IntelligentDriverStateInput = createBasicInputInterface("IntelligentDriverState")

StopExecutionOutput = createBasicOutputInterface("StopExecution")
StopExecutionInput = createBasicInputInterface("StopExecution")

IntelligentDriverStatusOutput = createBasicOutputInterface("IntelligentDriverStatus")
IntelligentDriverStatusInput = createBasicInputInterface("IntelligentDriverStatus")

AutonomyRouteOutput = createBasicOutputInterface("AutonomyRoute")
AutonomyRouteInput = createBasicInputInterface("AutonomyRoute")

AutonomyScriptOutput = createBasicOutputInterface("AutonomyScript")
AutonomyScriptOutput["channel"]["queueSize"] = 10;

AutonomyScriptInput = createBasicInputInterface("AutonomyScript")
AutonomyScriptInput["channel"]["queueSize"] = 10;

AutonomyScriptStatusOutput = createBasicOutputInterface("AutonomyScriptStatus")
AutonomyScriptStatusOutput["channel"]["queueSize"] = 10;
AutonomyScriptStatusInput = createBasicInputInterface("AutonomyScriptStatus")
AutonomyScriptStatusInput["channel"]["queueSize"] = 10;

AutonomyMotionStatusOutput = createBasicOutputInterface("AutonomyMotionStatus")
AutonomyMotionStatusInput = createBasicInputInterface("AutonomyMotionStatus")

OBIRouteObjUpdateOutput = createBasicOutputInterface("OBIRouteObjUpdate")
OBIRouteObjUpdateOutput["channel"]["queueSize"] = 5;
OBIRouteObjUpdateInput = createBasicInputInterface("OBIRouteObjUpdate")
OBIRouteObjUpdateInput["channel"]["queueSize"] = 5;
  
OBIRouteObjWithSurfaceUpdateOutput = createBasicOutputInterface("OBIRouteObjWithSurfaceUpdate")
OBIRouteObjWithSurfaceUpdateOutput["channel"]["queueSize"] = 5;
OBIRouteObjWithSurfaceUpdateInput = createBasicInputInterface("OBIRouteObjWithSurfaceUpdate")
OBIRouteObjWithSurfaceUpdateInput["channel"]["queueSize"] = 5;


RegulateSpeedOutput = createBasicOutputInterface("RegulateSpeed")
RegulateSpeedOutput["channel"]["queueSize"] = 20;
RegulateSpeedInput = createBasicInputInterface("RegulateSpeed")
RegulateSpeedInput["channel"]["queueSize"] = 500;
  
RegulateAccelerationOutput = createBasicOutputInterface("RegulateAcceleration")
RegulateAccelerationOutput["channel"]["queueSize"] = 10;
RegulateAccelerationInput = createBasicInputInterface("RegulateAcceleration")
RegulateAccelerationInput["channel"]["queueSize"] = 10;

OBIDriveModeOutput = createBasicOutputInterface("OBIDriveMode")
OBIDriveModeInput = createBasicInputInterface("OBIDriveMode")

OBIMachineAwarenessOutput = createBasicOutputInterface("OBIMachineAwareness")
OBIMachineAwarenessInput = createBasicInputInterface("OBIMachineAwareness")

# Using an OBIMachine Awareness type to communicate true postions
# of obstacles for performance analysis
TruePositionOutput = {
    "interface" => "OBIMachineAwareness.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "TruePosition.Channel",
        "compression" => "passthrough",
    }
}

TruePositionInput = {
    "interface" => "OBIMachineAwareness.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "TruePosition.Channel",
    }
}

PathTrackerStateOutput = createBasicOutputInterface("PathTrackerState")
PathTrackerStateInput = createBasicInputInterface("PathTrackerState")

PathTrackerPathOutput = createBasicOutputInterface("PathTrackerPath")
PathTrackerPathInput = createBasicInputInterface("PathTrackerPath")

PathTrackerCommandOutput = createBasicOutputInterface("PathTrackerCommand")
PathTrackerCommandInput = createBasicInputInterface("PathTrackerCommand")

PathTrackerFeedbackOutputPri = {
    "interface" => "PathTrackerFeedback.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "PathTrackerFeedbackPri.Channel",
        "compression" => "passthrough",
    }
}

PathTrackerFeedbackInputPri = {
    "interface" => "PathTrackerFeedback.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "PathTrackerFeedbackPri.Channel",
    }
}

PathTrackerFeedbackOutputSec = {
    "interface" => "PathTrackerFeedback.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "PathTrackerFeedbackSec.Channel",
        "compression" => "passthrough",
    }
}

PathTrackerFeedbackInputSec = {
    "interface" => "PathTrackerFeedback.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "PathTrackerFeedbackSec.Channel",
    }
}

MineModelUpdateInput = createBasicInputInterface("MineModelUpdate")
MineModelUpdateOutput = createBasicOutputInterface("MineModelUpdate")
MineModelUpdateOutput["channel"]["compression"] = DefaultCompression;

GroundSurfaceOffsetInput = createBasicInputInterface("GroundSurfaceOffset")
GroundSurfaceOffsetOutput = createBasicOutputInterface("GroundSurfaceOffset")

GroundSurfaceUpdatesInput = createBasicInputInterface("GroundSurfaceUpdates")
GroundSurfaceUpdatesInput["channel"]["queueSize"] = 5;
GroundSurfaceUpdatesOutput = createBasicOutputInterface("GroundSurfaceUpdates")

MineModelErrorsInput = createBasicInputInterface("MineModelErrors")
MineModelErrorsOutput = createBasicOutputInterface("MineModelErrors")

PlaybackLogStatusOutput = createBasicOutputInterface("PlaybackLogStatus")
PlaybackLogStatusInput = createBasicInputInterface("PlaybackLogStatus")

OCSCameraImageInput = {
    "interface" => "CameraImage.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "OCSCameraImage.Channel",
    }
}

OCSCameraImageOutput = {
    "interface" => "CameraImage.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "OCSCameraImage.Channel",
        "compression" => "passthrough",
    }
}

CameraImageInput = createBasicInputInterface("CameraImage")
CameraImageOutput = createBasicOutputInterface("CameraImage")

CameraStatsInput = createBasicInputInterface("CameraStats")
CameraStatsInput["channel"]["queueSize"] = 10;
CameraStatsOutput = createBasicOutputInterface("CameraStats")

# CAN Interfaces
CanPacketOutput = createBasicOutputInterface("CANInput")
CanPacketInput = createBasicInputInterface("CANInput")
CanPacketInput["channel"]["queueSize"] = 2;


# Interface linkage to shared libraries talking directly to peak hardware
CanInputPeak = {
    "interface" => "CANInput.peak",
#   "dev" => "/dev/pcan41",
    "kiloBaud" => 500,
    "packetType" => "standard",
    "channel" => 1,
    # Other params here
}
CanOutputPeak = {
    "interface" => "CANOutput.peak",
#   "dev" => "/dev/pcan41",
    "kiloBaud" => 500,
    "packetType" => "standard",
    "channel" => 1,
    # Other params here
}
# -----------------------------------------------------------------------------------
# Channel interfaces that directly model pcan device file mappings

# First define device mappings

HardwareType = {
  "PCI" => 0,
  "ISA" => 8,
  "DongleSP" => 16,
  "DongleEPP" => 24,
  "USB" => 32,
  "PCCard" => 40,
}

# First a base interface that can be an input or output
CanPeak = {
    "interface" => "",
    "kiloBaud" => 500,
    "packetType" => "standard",
    "readTimeout" => -1.0, # any negative value is a blocking call
}

CanSocket = {
    "interface" => "",
}

CanSocketCh0 = CanSocket.dup;
CanSocketCh0.update( {
     "dev" => "can0",
     "readTimeout_msec" => 1.0,   # in milli seconds
     "enable_rxfilter" => false,   # true => enabled; false => disabled
} )

CanSocketCh1 = CanSocket.dup;
CanSocketCh1.update( {
     "dev" => "can1",
     "readTimeout_msec" => 1.0,   # in milli seconds
     "enable_rxfilter" => false,   # true => enabled; false => disabled
} )

CanSocketCh2 = CanSocket.dup;
CanSocketCh2.update( {
     "dev" => "can2",
     "readTimeout_msec" => 0.5,   # in milli seconds
     "enable_rxfilter" => true,   # true => enabled; false => disabled
     "rxFilter" => CANFilters.fetch("can2"),
} )

CanSocketCh3 = CanSocket.dup;
CanSocketCh3.update( {
     "dev" => "can3",
     "readTimeout_msec" => 0.5,   # in milli seconds
     "enable_rxfilter" => true,   # true => enabled; false => disabled
     "rxFilter" => CANFilters.fetch("can3"),
} )

CcpSocketCh2 = CanSocket.dup;
CcpSocketCh2.update( {
       "dev" => "can2",
       "readTimeout_msec" => 0.5,   # in milli seconds
       "enable_rxfilter" => true,   # true => enabled; false => disabled
       "rxFilter" => CANFilters.fetch("can2ccp"),
} )

CcpInputSocketCh2 = CcpSocketCh2.dup;
CcpInputSocketCh2.update( {"interface" => "CANInput.socket", })

CcpSocketCh3 = CanSocket.dup;
CcpSocketCh3.update( {
       "dev" => "can3",
       "readTimeout_msec" => 0.5,   # in milli seconds
       "enable_rxfilter" => true,   # true => enabled; false => disabled
       "rxFilter" => CANFilters.fetch("can3ccp"),
} )

EddtSocketCh2 = CanSocket.dup;
EddtSocketCh2.update( {
       "dev" => "can2",
       "readTimeout_msec" => 0.5,   # in milli seconds
       "enable_rxfilter" => true,   # true => enabled; false => disabled
       "rxFilter" => CANFilters.fetch("can2eddt"),
} )

EddtInputSocketCh2 = EddtSocketCh2.dup;
EddtInputSocketCh2.update( {"interface" => "CANInput.socket", })



CcpInputSocketCh3 = CcpSocketCh3.dup;
CcpInputSocketCh3.update( {"interface" => "CANInput.socket", })

CanInputSocketCh0 = CanSocketCh0.dup;
CanInputSocketCh0.update( {"interface" => "CANInput.socket", })
CanInputSocketCh1 = CanSocketCh1.dup;
CanInputSocketCh1.update( {"interface" => "CANInput.socket", })
CanInputSocketCh2 = CanSocketCh2.dup;
CanInputSocketCh2.update( {"interface" => "CANInput.socket", })
CanInputSocketCh3 = CanSocketCh3.dup;
CanInputSocketCh3.update( {"interface" => "CANInput.socket", })

CanOutputSocketCh0 = CanSocketCh0.dup;
CanOutputSocketCh0.update( {"interface" => "CANOutput.socket", })
CanOutputSocketCh1 = CanSocketCh1.dup;
CanOutputSocketCh1.update( {"interface" => "CANOutput.socket", })
CanOutputSocketCh2 = CanSocketCh2.dup;
CanOutputSocketCh2.update( {"interface" => "CANOutput.socket", })
CanOutputSocketCh3 = CanSocketCh3.dup;
CanOutputSocketCh3.update( {"interface" => "CANOutput.socket", })

# Just define 4 PCI and 4 PCCard interfaces for now, we don't expect more than 2
# cards of a given type per L3
CanPeakPCICh0 = CanPeak.dup;
CanPeakPCICh0.update( {"dev" => "/dev/pcan"+(HardwareType["PCI"]+0).to_s()} )
CanPeakPCICh1 = CanPeak.dup;
CanPeakPCICh1.update( {"dev" => "/dev/pcan"+(HardwareType["PCI"]+1).to_s()} )
CanPeakPCICh2 = CanPeak.dup;
CanPeakPCICh2.update( {"dev" => "/dev/pcan"+(HardwareType["PCI"]+2).to_s()} )
CanPeakPCICh3 = CanPeak.dup;
CanPeakPCICh3.update( {"dev" => "/dev/pcan"+(HardwareType["PCI"]+3).to_s()} )

CanPeakPCCardCh0 = CanPeak.dup;
CanPeakPCCardCh0.update( {"dev" => "/dev/pcan"+(HardwareType["PCCard"]+0).to_s()} )
CanPeakPCCardCh1 = CanPeak.dup;
CanPeakPCCardCh1.update( {"dev" => "/dev/pcan"+(HardwareType["PCCard"]+1).to_s()} )
CanPeakPCCardCh2 = CanPeak.dup;
CanPeakPCCardCh2.update( {"dev" => "/dev/pcan"+(HardwareType["PCCard"]+2).to_s()} )
CanPeakPCCardCh3 = CanPeak.dup;
CanPeakPCCardCh3.update( {"dev" => "/dev/pcan"+(HardwareType["PCCard"]+3).to_s()} )

# Now defined both input and output interfaces for each type
CanInputPeakPCICh0 = CanPeakPCICh0.dup;
CanInputPeakPCICh0.update( {
                             "interface" => "CANInput.peak",
                           })
CanOutputPeakPCICh0 = CanPeakPCICh0.dup;
CanOutputPeakPCICh0.update( {
                             "interface" => "CANOutput.peak",
                           })
CanInputPeakPCICh1 = CanPeakPCICh1.dup;
CanInputPeakPCICh1.update( {
                             "interface" => "CANInput.peak",
                           })
CanOutputPeakPCICh1 = CanPeakPCICh1.dup;
CanOutputPeakPCICh1.update( {
                             "interface" => "CANOutput.peak",
                           })
CanInputPeakPCICh2 = CanPeakPCICh2.dup;
CanInputPeakPCICh2.update( {
                             "interface" => "CANInput.peak",
                           })
CanOutputPeakPCICh2 = CanPeakPCICh2.dup;
CanOutputPeakPCICh2.update( {
                             "interface" => "CANOutput.peak",
                           })
CanInputPeakPCICh3 = CanPeakPCICh3.dup;
CanInputPeakPCICh3.update( {
                             "interface" => "CANInput.peak",
                           })
CanOutputPeakPCICh3 = CanPeakPCICh3.dup;
CanOutputPeakPCICh3.update( {
                             "interface" => "CANOutput.peak",
                           })

CanInputPeakPCCardCh0 = CanPeakPCCardCh0.dup;
CanInputPeakPCCardCh0.update( {
                             "interface" => "CANInput.peak",
                           })
CanOutputPeakPCCardCh0 = CanPeakPCCardCh0.dup;
CanOutputPeakPCCardCh0.update( {
                             "interface" => "CANOutput.peak",
                           })
CanInputPeakPCCardCh1 = CanPeakPCCardCh1.dup;
CanInputPeakPCCardCh1.update( {
                             "interface" => "CANInput.peak",
                           })
CanOutputPeakPCCardCh1 = CanPeakPCCardCh1.dup;
CanOutputPeakPCCardCh1.update( {
                             "interface" => "CANOutput.peak",
                           })
CanInputPeakPCCardCh2 = CanPeakPCCardCh2.dup;
CanInputPeakPCCardCh2.update( {
                             "interface" => "CANInput.peak",
                           })
CanOutputPeakPCCardCh2 = CanPeakPCCardCh2.dup;
CanOutputPeakPCCardCh2.update( {
                             "interface" => "CANOutput.peak",
                           })
CanInputPeakPCCardCh3 = CanPeakPCCardCh3.dup;
CanInputPeakPCCardCh3.update( {
                             "interface" => "CANInput.peak",
                           })
CanOutputPeakPCCardCh3 = CanPeakPCCardCh3.dup;
CanOutputPeakPCCardCh3.update( {
                             "interface" => "CANOutput.peak",
                           })
#-----------250 speed --> required for MCM
CanInputPeakPCICh0_250 = CanInputPeakPCICh0.dup;
CanInputPeakPCICh0_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanOutputPeakPCICh0_250 = CanOutputPeakPCICh0.dup;
CanOutputPeakPCICh0_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanInputPeakPCICh1_250 = CanInputPeakPCICh1.dup;
CanInputPeakPCICh1_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanOutputPeakPCICh1_250 = CanOutputPeakPCICh1.dup;
CanOutputPeakPCICh1_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanInputPeakPCICh2_250 = CanInputPeakPCICh2.dup;
CanInputPeakPCICh2_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanOutputPeakPCICh2_250 = CanOutputPeakPCICh2.dup;
CanOutputPeakPCICh2_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanInputPeakPCICh3_250 = CanInputPeakPCICh3.dup;
CanInputPeakPCICh3_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanOutputPeakPCICh3_250 = CanOutputPeakPCICh3.dup;
CanOutputPeakPCICh3_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanInputPeakPCCardCh0_250 = CanInputPeakPCCardCh0.dup;
CanInputPeakPCCardCh0_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanOutputPeakPCCardCh0_250 = CanOutputPeakPCCardCh0.dup;
CanOutputPeakPCCardCh0_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanInputPeakPCCardCh1_250 = CanInputPeakPCCardCh1.dup;
CanInputPeakPCCardCh1_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanOutputPeakPCCardCh1_250 = CanOutputPeakPCCardCh1.dup;
CanOutputPeakPCCardCh1_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanInputPeakPCCardCh2_250 = CanInputPeakPCCardCh2.dup;
CanInputPeakPCCardCh2_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanOutputPeakPCCardCh2_250 = CanOutputPeakPCCardCh2.dup;
CanOutputPeakPCCardCh2_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanInputPeakPCCardCh3_250 = CanInputPeakPCCardCh3.dup;
CanInputPeakPCCardCh3_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
CanOutputPeakPCCardCh3_250 = CanOutputPeakPCCardCh3.dup;
CanOutputPeakPCCardCh3_250.update( {
    "kiloBaud" => 250,
    "readTimeout" => 0.050, # 50 ms timeout ~ 20hz
})
#----------------------------------------------------------------------------------
CanInputPeakPCICh2_250_IMU = CanInputPeakPCICh2.dup;
CanInputPeakPCICh2_250_IMU.update( {
    "packetType" => "extended",
})
CanInputPeakPCICh3_250_TPM = CanInputPeakPCICh3.dup;
CanInputPeakPCICh3_250_TPM.update( {
    "packetType" => "extended",
})

# -----------------------------------------------------------------------------------
# Generic channel interfaces to be used by all 6 Radars post Jul 2009
CanInputPeakCh1 = CanInputPeak.dup;
CanInputPeakCh1.update( {
    "channel" => 1,
} )
CanInputPeakCh2 = CanInputPeak.dup;
CanInputPeakCh2.update( {
    "channel" => 2,
} )
CanOutputPeakCh1 = CanOutputPeak.dup;
CanOutputPeakCh1.update( {
    "channel" => 1,
} )
CanOutputPeakCh2 = CanOutputPeak.dup;
CanOutputPeakCh2.update( {
    "channel" => 2,
} )
# -----------------------------------------------------------------------------------
# Older 2 Radar Design pre Jul 2009
CanInputPeak_MidLowerRadar = CanInputPeak.dup;
CanInputPeak_MidLowerRadar.update( {
    "channel" => 1,
} )
CanOutputPeak_MidLowerRadar = CanOutputPeak.dup;
CanOutputPeak_MidLowerRadar.update( {
    "channel" => 1,
} )

CanInputPeak_MidUpperRadar = CanInputPeak.dup;
CanInputPeak_MidUpperRadar.update( {
    "channel" => 2,
} )
CanOutputPeak_MidUpperRadar = CanOutputPeak.dup;
CanOutputPeak_MidUpperRadar.update( {
    "channel" => 2,
} )
# -----------------------------------------------------------------------------------

# Interface linkage to shared libraries talking directly to esd hardware

CanInputESD = {
    "interface" => "CANInput.esd",
    # Other params here
}

CanOutputESD = {
    "interface" => "CANOutput.esd",
    # Other params here
}

VelodynePacketGroupInput = createBasicInputInterface("VelodynePacketGroup")
VelodynePacketGroupInput["channel"]["queueSize"] = 1000;
VelodynePacketGroupOutput = createBasicOutputInterface("VelodynePacketGroup")
VelodynePacketGroupOutput["channel"]["queueSize"] = 100;

# ------ These channels are local to the PBL computer -------
VelodynePacketGroupPBLInput = createBasicInputInterface("VelodynePacketGroup")
VelodynePacketGroupPBLInput["channel"]["queueSize"] = 1000;
VelodynePacketGroupPBLInput["channel"]["name"] = "VelodynePacketGroupPBL.Channel";

VelodynePacketGroupPBLOutput = createBasicOutputInterface("VelodynePacketGroup")
VelodynePacketGroupPBLOutput["channel"]["queueSize"] = 100;
VelodynePacketGroupPBLOutput["channel"]["name"] = "VelodynePacketGroupPBL.Channel";

#  ----- These channels are on the ALT scs network --------
VelodynePacketGroupALTInput = Hash.new
VelodynePacketGroupALTInput = deepCopy(VelodynePacketGroupInput)
VelodynePacketGroupALTInput["channel"]["unixPath"] = "alt";

VelodynePacketGroupALTOutput = Hash.new
VelodynePacketGroupALTOutput = deepCopy(VelodynePacketGroupOutput)
VelodynePacketGroupALTOutput["channel"]["unixPath"] = "alt";
#  --------------------

GPSTimeOutput = createBasicOutputInterface("GPSTime")
GPSTimeInput = createBasicInputInterface("GPSTime")

TimeSyncStatisticsOutput = createBasicOutputInterface("TimeSyncStatistics")
TimeSyncStatisticsOutput["channel"]["queueSize"] = 50;
TimeSyncStatisticsInput = createBasicInputInterface("TimeSyncStatistics")
TimeSyncStatisticsInput["channel"]["queueSize"] = 50;

RadarHealthOutput = createBasicOutputInterface("RadarHealth")
RadarHealthInput = createBasicInputInterface("RadarHealth")

RadarCommandOutput = createBasicOutputInterface("RadarCommand")
RadarCommandInput = createBasicInputInterface("RadarCommand")

FrontLeftLowerRadarHealthOutput = {
    "interface" => "RadarHealth.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftLowerRadarHealth.Channel",
        "compression" => "passthrough",
    }
}

FrontLeftLowerRadarHealthInput = {
    "interface" => "RadarHealth.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftLowerRadarHealth.Channel",
    }
}

FrontRightLowerRadarHealthOutput = {
    "interface" => "RadarHealth.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightLowerRadarHealth.Channel",
        "compression" => "passthrough",
    }
}

FrontRightLowerRadarHealthInput = {
    "interface" => "RadarHealth.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightLowerRadarHealth.Channel",
    }
}

FrontLeftUpperRadarHealthOutput = {
    "interface" => "RadarHealth.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftUpperRadarHealth.Channel",
        "compression" => "passthrough",
    }
}

FrontLeftUpperRadarHealthInput = {
    "interface" => "RadarHealth.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftUpperRadarHealth.Channel",
    }
}

FrontRightUpperRadarHealthOutput = {
    "interface" => "RadarHealth.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightUpperRadarHealth.Channel",
        "compression" => "passthrough",
    }
}

FrontRightUpperRadarHealthInput = {
    "interface" => "RadarHealth.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightUpperRadarHealth.Channel",
    }
}

FrontMidUpperRadarHealthOutput = {
    "interface" => "RadarHealth.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidUpperRadarHealth.Channel",
        "compression" => "passthrough",
    }
}

FrontMidUpperRadarHealthInput = {
    "interface" => "RadarHealth.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidUpperRadarHealth.Channel",
    }
}

FrontMidLowerRadarHealthOutput = {
    "interface" => "RadarHealth.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidLowerRadarHealth.Channel",
        "compression" => "passthrough",
    }
}

FrontMidLowerRadarHealthInput = {
    "interface" => "RadarHealth.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidLowerRadarHealth.Channel",
    }
}

RearRadarHealthInput = {
    "interface" => "RadarHealth.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "RearRadarHealth.Channel",
    }
}

RearRadarHealthOutput = {
    "interface" => "RadarHealth.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "RearRadarHealth.Channel",
        "compression" => "passthrough",
    }
}


#-------------------------------
FrontLeftLowerRadarCommandOutput = {
    "interface" => "RadarCommand.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftLowerRadarCommand.Channel",
        "compression" => "passthrough",
    }
}

FrontLeftLowerRadarCommandInput = {
    "interface" => "RadarCommand.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftLowerRadarCommand.Channel",
    }
}

FrontRightLowerRadarCommandOutput = {
    "interface" => "RadarCommand.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightLowerRadarCommand.Channel",
        "compression" => "passthrough",
    }
}

FrontRightLowerRadarCommandInput = {
    "interface" => "RadarCommand.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightLowerRadarCommand.Channel",
    }
}

FrontLeftUpperRadarCommandOutput = {
    "interface" => "RadarCommand.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftUpperRadarCommand.Channel",
        "compression" => "passthrough",
    }
}

FrontLeftUpperRadarCommandInput = {
    "interface" => "RadarCommand.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftUpperRadarCommand.Channel",
    }
}

FrontRightUpperRadarCommandOutput = {
    "interface" => "RadarCommand.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightUpperRadarCommand.Channel",
        "compression" => "passthrough",
    }
}

FrontRightUpperRadarCommandInput = {
    "interface" => "RadarCommand.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightUpperRadarCommand.Channel",
    }
}

FrontMidUpperRadarCommandOutput = {
    "interface" => "RadarCommand.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidUpperRadarCommand.Channel",
        "compression" => "passthrough",
    }
}

FrontMidUpperRadarCommandInput = {
    "interface" => "RadarCommand.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidUpperRadarCommand.Channel",
    }
}

FrontMidLowerRadarCommandOutput = {
    "interface" => "RadarCommand.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidLowerRadarCommand.Channel",
        "compression" => "passthrough",
    }
}

FrontMidLowerRadarCommandInput = {
    "interface" => "RadarCommand.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidLowerRadarCommand.Channel",
    }
}

RearRadarCommandInput = {
    "interface" => "RadarCommand.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "RearRadarCommand.Channel",
    }
}

RearRadarCommandOutput = {
    "interface" => "RadarCommand.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "RearRadarCommand.Channel",
        "compression" => "passthrough",
    }
}

#-------------------------------


FrontLeftLowerRadarTrackOutput = {
   "interface" => "RadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftLowerRadarTrack.Channel",
        "compression" => "passthrough",
    }
}

FrontLeftLowerRadarTrackInput = {
    "interface" => "RadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftLowerRadarTrack.Channel",
    }
}

FrontRightLowerRadarTrackOutput = {
    "interface" => "RadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightLowerRadarTrack.Channel",
        "compression" => "passthrough",
    }
}

FrontRightLowerRadarTrackInput = {
    "interface" => "RadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightLowerRadarTrack.Channel",
    }
}

FrontLeftUpperRadarTrackOutput = {
    "interface" => "RadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftUpperRadarTrack.Channel",
        "compression" => "passthrough",
    }
}

FrontLeftUpperRadarTrackInput = {
    "interface" => "RadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftUpperRadarTrack.Channel",
    }
}

FrontRightUpperRadarTrackOutput = {
    "interface" => "RadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightUpperRadarTrack.Channel",
        "compression" => "passthrough",
    }
}

FrontRightUpperRadarTrackInput = {
    "interface" => "RadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightUpperRadarTrack.Channel",
    }
}

FrontMidUpperRadarTrackOutput = {
    "interface" => "RadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidUpperRadarTrack.Channel",
        "compression" => "passthrough",
    }
}

FrontMidUpperRadarTrackInput = {
    "interface" => "RadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidUpperRadarTrack.Channel",
    }
}

FrontMidLowerRadarTrackOutput = {
    "interface" => "RadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidLowerRadarTrack.Channel",
        "compression" => "passthrough",
    }
}

FrontMidLowerRadarTrackInput = {
    "interface" => "RadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidLowerRadarTrack.Channel",
    }
}

RearRadarTrackOutput = {
    "interface" => "RadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "RearRadarTrack.Channel",
        "compression" => "passthrough",
    }
}

RearRadarTrackInput = {
    "interface" => "RadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "RearRadarTrack.Channel",
    }
}
#--------------
MineModelRequestInput = createBasicInputInterface("MineModelRequest")
MineModelRequestOutput = createBasicOutputInterface("MineModelRequest")

# ----------------------------------------------------------------------------------
FrontLeftLowerTaggedRadarTrackOutput = {
   "interface" => "TaggedRadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftLowerTaggedRadarTrack.Channel",
        "compression" => DefaultCompression,
    }
}

FrontLeftLowerTaggedRadarTrackInput = {
    "interface" => "TaggedRadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftLowerTaggedRadarTrack.Channel",
    }
}

FrontRightLowerTaggedRadarTrackOutput = {
    "interface" => "TaggedRadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightLowerTaggedRadarTrack.Channel",
        "compression" => DefaultCompression,
    }
}

FrontRightLowerTaggedRadarTrackInput = {
    "interface" => "TaggedRadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightLowerTaggedRadarTrack.Channel",
    }
}

FrontLeftUpperTaggedRadarTrackOutput = {
    "interface" => "TaggedRadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftUpperTaggedRadarTrack.Channel",
        "compression" => DefaultCompression,
    }
}

FrontLeftUpperTaggedRadarTrackInput = {
    "interface" => "TaggedRadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontLeftUpperTaggedRadarTrack.Channel",
    }
}

FrontRightUpperTaggedRadarTrackOutput = {
    "interface" => "TaggedRadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightUpperTaggedRadarTrack.Channel",
        "compression" => DefaultCompression,
    }
}

FrontRightUpperTaggedRadarTrackInput = {
    "interface" => "TaggedRadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontRightUpperTaggedRadarTrack.Channel",
    }
}

FrontMidUpperTaggedRadarTrackOutput = {
    "interface" => "TaggedRadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidUpperTaggedRadarTrack.Channel",
        "compression" => DefaultCompression,
    }
}

FrontMidUpperTaggedRadarTrackInput = {
    "interface" => "TaggedRadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidUpperTaggedRadarTrack.Channel",
    }
}

FrontMidLowerTaggedRadarTrackOutput = {
    "interface" => "TaggedRadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidLowerTaggedRadarTrack.Channel",
        "compression" => DefaultCompression,
    }
}

FrontMidLowerTaggedRadarTrackInput = {
    "interface" => "TaggedRadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FrontMidLowerTaggedRadarTrack.Channel",
    }
}

RearTaggedRadarTrackOutput = {
    "interface" => "TaggedRadarTrack.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "RearTaggedRadarTrack.Channel",
        "compression" => DefaultCompression,
    }
}

RearTaggedRadarTrackInput = {
    "interface" => "TaggedRadarTrack.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "RearTaggedRadarTrack.Channel",
    }
}

#-------------------------------

OcsAlertInput = createBasicInputInterface("OcsAlert")
OcsAlertOutput = createBasicOutputInterface("OcsAlert")

PerceivedObstacleInput= {
   "interface" => "PerceivedObstacle.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "ObstacleInput.Channel",
    }
}
PerceivedObstacleOutput= {
   "interface" => "PerceivedObstacle.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "PerceivedObstacleOutput.Channel",
        "compression" => "passthrough",
    }
}

FileGlobSendOutFilesOutput = {
    "interface" => "FileGlob.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FileGlobSendOutFiles.Channel",
    }
}
FileGlobSendOutFilesInput = {
    "interface" => "FileGlob.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 10,
        "name" => "FileGlobSendOutFiles.Channel",
    }
}
ZFileGlobSendOutFilesOutput = {
    "interface" => "FileGlob.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FileGlobSendOutFiles.ZChannel",
        "compression" => DefaultCompression,
    }
}
ZFileGlobSendOutFilesInput = {
    "interface" => "FileGlob.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 10,
        "name" => "FileGlobSendOutFiles.ZChannel",
    }
}

ZFileGlobCalibrationResultOutput = {
    "interface" => "FileGlob.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "FileGlobCalibrationResult.ZChannel",
        "compression" => DefaultCompression,
    }
}
ZFileGlobCalibrationResultInput = {
    "interface" => "FileGlob.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 10,
        "name" => "FileGlobCalibrationResult.ZChannel",
    }
}

ZRemoteLoggerTextOutput = {
    "interface" => "RemoteLoggerText.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "RemoteLoggerText.ZChannel",
        "compression" => DefaultCompression,
    }
}
ZRemoteLoggerTextInput = {
    "interface" => "RemoteLoggerText.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "RemoteLoggerText.ZChannel",
    }
}

GroundHeightEstimatorMapCellUpdateListOutput = createBasicOutputInterface("GroundHeightEstimatorMapCellUpdateList")
GroundHeightEstimatorMapCellUpdateListInput = createBasicInputInterface("GroundHeightEstimatorMapCellUpdateList")

GroundPlaneEstimateOutput = createBasicOutputInterface("GroundPlaneEstimation")
GroundPlaneEstimateInput = createBasicInputInterface("GroundPlaneEstimation")

ObstacleListInput = createBasicInputInterface("ObstacleList")
ObstacleListInput["channel"]["queueSize"] = 10;
ObstacleListOutput = createBasicOutputInterface("ObstacleList")


#Restore old CostMapUpdate but make it an ObstacleCellList behind the scenes
CostMapUpdateInput = createBasicInputInterface("ObstacleCellList")
CostMapUpdateInput["channel"]["queueSize"] = 10;
CostMapUpdateInput["channel"]["name"] = "CostMapUpdate.Channel"
CostMapUpdateOutput = createBasicOutputInterface("ObstacleCellList")
CostMapUpdateOutput["channel"]["name"] = "CostMapUpdate.Channel"


ObstacleCellListInput = createBasicInputInterface("ObstacleCellList")
ObstacleCellListInput["channel"]["queueSize"] = 10;
ObstacleCellListOutput = createBasicOutputInterface("ObstacleCellList")

AggregatedObstacleCellListInput = createBasicInputInterface("ObstacleCellList")
AggregatedObstacleCellListInput["channel"]["queueSize"] = 10;
AggregatedObstacleCellListInput["channel"]["name"] = "AggregatedObstacleCellList.Channel"
AggregatedObstacleCellListOutput = createBasicOutputInterface("ObstacleCellList")
AggregatedObstacleCellListOutput["channel"]["name"] = "AggregatedObstacleCellList.Channel"

FODObstacleCellListInput = createBasicInputInterface("ObstacleCellList")
FODObstacleCellListInput["channel"]["queueSize"] = 10;
FODObstacleCellListInput["channel"]["name"] = "FODObstacleCellList.Channel"
FODObstacleCellListOutput = createBasicOutputInterface("ObstacleCellList")
FODObstacleCellListOutput["channel"]["name"] = "FODObstacleCellList.Channel"

MODObstacleCellListInput = createBasicInputInterface("ObstacleCellList")
MODObstacleCellListInput["channel"]["queueSize"] = 10;
MODObstacleCellListInput["channel"]["name"] = "MODObstacleCellList.Channel"
MODObstacleCellListOutput = createBasicOutputInterface("ObstacleCellList")
MODObstacleCellListOutput["channel"]["name"] = "MODObstacleCellList.Channel"

RearCostMapUpdateInput = createBasicInputInterface("ObstacleCellList")
RearCostMapUpdateInput["channel"]["queueSize"] = 10;
RearCostMapUpdateInput["channel"]["name"] = "RearCostMapUpdate.Channel"
RearCostMapUpdateOutput = createBasicOutputInterface("ObstacleCellList")
RearCostMapUpdateOutput["channel"]["name"] = "RearCostMapUpdate.Channel"

MOD2ObstacleCellListInput = createBasicInputInterface("ObstacleCellList")
MOD2ObstacleCellListInput["channel"]["queueSize"] = 10;
MOD2ObstacleCellListInput["channel"]["name"] = "MOD2ObstacleCellList.Channel"
MOD2ObstacleCellListOutput = createBasicOutputInterface("ObstacleCellList")
MOD2ObstacleCellListOutput["channel"]["name"] = "MOD2ObstacleCellList.Channel"

CostMapRequestInput = createBasicInputInterface("CostMapRequest")
CostMapRequestInput["channel"]["queueSize"] = 10;
CostMapRequestOutput = createBasicOutputInterface("CostMapRequest")

VelodyneCommandInput = createBasicInputInterface("VelodyneCommand")
VelodyneCommandInput["channel"]["queueSize"] = 10;
VelodyneCommandOutput = createBasicOutputInterface("VelodyneCommand")

LaneMapUpdateInput = createBasicInputInterface("LaneMapUpdate")
LaneMapUpdateInput["channel"]["queueSize"] = 10;
LaneMapUpdateOutput = createBasicOutputInterface("LaneMapUpdate")

LaneMapRequestInput = createBasicInputInterface("LaneMapRequest")
LaneMapRequestInput["channel"]["queueSize"] = 10;
LaneMapRequestOutput = createBasicOutputInterface("LaneMapRequest")

MCMOfficeCommandOutput = createBasicOutputInterface("MCMOfficeCommand")
MCMOfficeCommandInput = createBasicInputInterface("MCMOfficeCommand")

CameraHealthInput = createBasicInputInterface("CameraHealth")
CameraHealthOutput = createBasicOutputInterface("CameraHealth")

VelodyneHealthInput = createBasicInputInterface("VelodyneHealth")
VelodyneHealthInput["channel"]["queueSize"] = 20;
VelodyneHealthOutput = createBasicOutputInterface("VelodyneHealth")

#velo_PBL health
VelodyneHealthPBLInput = createBasicInputInterface("VelodyneHealth")
VelodyneHealthPBLInput["channel"]["queueSize"] = 20;
VelodyneHealthPBLInput["channel"]["name"] = "VelodyneHealthPBL.Channel";
VelodyneHealthPBLOutput = createBasicOutputInterface("VelodyneHealth")
VelodyneHealthPBLOutput["channel"]["name"] = "VelodyneHealthPBL.Channel";
#velo_PBL health

ChannelToLogInput = createBasicInputInterface("ChannelToLog")
ChannelToLogOutput = createBasicOutputInterface("ChannelToLog")

SlopeMapUpdateInput = createBasicInputInterface("SlopeMapUpdate")
SlopeMapUpdateInput["channel"]["queueSize"] = 10;
SlopeMapUpdateOutput = createBasicOutputInterface("SlopeMapUpdate")

SubSystemHealthOutput = createBasicOutputInterface("SubSystemHealth")
SubSystemHealthInput = createBasicInputInterface("SubSystemHealth")

AssignmentManagerDebugInput = createBasicInputInterface("AssignmentManagerDebug")
AssignmentManagerDebugInput["channel"]["queueSize"] = 20;
AssignmentManagerDebugOutput = createBasicOutputInterface("AssignmentManagerDebug")

EngineeringControlsDebugInfoInput = createBasicInputInterface("EngineeringControlsDebugInfo")
EngineeringControlsDebugInfoInput["channel"]["unixPath"] = "lowPri";
EngineeringControlsDebugInfoOutput = createBasicOutputInterface("EngineeringControlsDebugInfo")
EngineeringControlsDebugInfoOutput["channel"]["unixPath"] = "lowPri";

SubSystemRecommendedActionOutput = createBasicOutputInterface("SubSystemRecommendedAction")
SubSystemRecommendedActionOutput["channel"]["queueSize"] = 10;

SubSystemRecommendedActionInput = createBasicInputInterface("SubSystemRecommendedAction")
SubSystemRecommendedActionInput["channel"]["queueSize"] = 10;

VehicleSimUpdateOutput = createBasicOutputInterface("VehicleSimUpdate")
VehicleSimUpdateInput = createBasicInputInterface("VehicleSimUpdate")

AssignmentResponseOutput = createBasicOutputInterface("AssignmentResponse")
AssignmentResponseOutput["channel"]["queueSize"] = 5;
AssignmentResponseInput = createBasicInputInterface("AssignmentResponse")
AssignmentResponseInput["channel"]["queueSize"] = 5;

AbsIMUDataInput = createBasicInputInterface("AbsIMUData")
AbsIMUDataInput["channel"]["queueSize"] = 10;
AbsIMUDataOutput = createBasicOutputInterface("AbsIMUData")
AbsIMUDataOutput["channel"]["queueSize"] = 10;

MCMAStopStatusOutput = createBasicOutputInterface("MCMAStopStatus")
MCMAStopStatusInput = createBasicInputInterface("MCMAStopStatus")
MCMAStopStatusInput["channel"]["queueSize"] = 10;

ObstacleSimulatorOutput = createBasicOutputInterface("ObstacleSimulator")
ObstacleSimulatorInput = createBasicInputInterface("ObstacleSimulator")

RadarNominationOutput = createBasicOutputInterface("RadarNomination")
RadarNominationOutput["channel"]["queueSize"] = 100;
RadarNominationInput = createBasicInputInterface("RadarNomination")
RadarNominationInput["channel"]["queueSize"] = 100;

# @todo Create unique interface type, for now just recycle RadarNomination
ObstacleAnalysisOutput = {
   "interface" => "RadarNomination.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "ObstacleAnalysis.Channel",
        "compression" => "passthrough",
    }
}

ObstacleAnalysisInput = {
   "interface" => "RadarNomination.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "ObstacleAnalysis.Channel",
    }
}

ExternalDisturbanceInput = createBasicInputInterface("ExternalDisturbance")
ExternalDisturbanceInput["channel"]["queueSize"] = 50; # Larger so that simulations can send/receive many in one cycle
ExternalDisturbanceOutput = createBasicOutputInterface("ExternalDisturbance")
ExternalDisturbanceOutput["channel"]["queueSize"] = 50; # Larger so that simulations can send/receive many in one cycle

MachineStateInput = createBasicInputInterface("MachineState")
MachineStateInput["channel"]["queueSize"] = 100;  # JMD -- Why is this queue size so high?
MachineStateOutput = createBasicOutputInterface("MachineState")
MachineStateOutput["channel"]["queueSize"] = 100;  # JMD -- Why is this queue size so high?

MachineCommandInput = createBasicInputInterface("MachineCommand")
MachineCommandInput["channel"]["queueSize"] = 100;
MachineCommandOutput = createBasicOutputInterface("MachineCommand")
MachineCommandOutput["channel"]["queueSize"] = 100;

OBIStatusInput = createBasicInputInterface("OBIStatus")
OBIStatusInput["channel"]["queueSize"] = 100;  # JMD -- Why is this queue size so high?
OBIStatusOutput = createBasicOutputInterface("OBIStatus")
OBIStatusOutput["channel"]["queueSize"] = 100;  # JMD -- Why is this queue size so high?

SystemHardwareHealthInput = createBasicInputInterface("SystemHardwareHealth")
SystemHardwareHealthInput["channel"]["queueSize"] = 100;
SystemHardwareHealthOutput = createBasicOutputInterface("SystemHardwareHealth")
SystemHardwareHealthOutput["channel"]["queueSize"] = 100

SystemHardwareHealthRequestInput = createBasicInputInterface("SystemHardwareHealthRequest")
SystemHardwareHealthRequestInput["channel"]["queueSize"] = 100;
SystemHardwareHealthRequestOutput = createBasicOutputInterface("SystemHardwareHealthRequest")
SystemHardwareHealthRequestOutput["channel"]["queueSize"] = 100


LibInfoDiagnosticsInput = {
    "interface" => "LibInfoDiagnostics.Channel.Input",
    "channel" => {
      "type" => "SimpleComms",
      "priority" => 1,
      "queueSize" => 100,
      "name" => "LibInfoDiagnostics.Channel",
    }
}

LibInfoDiagnosticsOutput = {
    "interface" => "LibInfoDiagnostics.Channel.Output",
    "channel" => {
      "type" => "SimpleComms",
      "priority" => 1,
      "queueSize" => 100,
      "name" => "LibInfoDiagnostics.Channel",
      "compression" => "passthrough",
    }
}

LibInfoEventsInput = {
    "interface" => "LibInfoDiagnostics.Channel.Input",
    "channel" => {
      "type" => "SimpleComms",
      "priority" => 1,
      "queueSize" => 100,
      "name" => "LibInfoEvents.Channel",
    }
}

LibInfoEventsOutput = {
    "interface" => "LibInfoDiagnostics.Channel.Output",
    "channel" => {
      "type" => "SimpleComms",
      "priority" => 1,
      "queueSize" => 100,
      "name" => "LibInfoEvents.Channel",
      "compression" => "passthrough",
    }
}


ApplanixConfigSettings2Input = createBasicInputInterface("ApplanixConfigSettings2")
ApplanixConfigSettings2Output = createBasicOutputInterface("ApplanixConfigSettings2")

ApplanixConfigSettingsRequestInput = createBasicInputInterface("ApplanixConfigSettingsRequest")
ApplanixConfigSettingsRequestOutput = createBasicOutputInterface("ApplanixConfigSettingsRequest")

PerceptionMapUpdateInput = {
    "interface" => "PerceptionMapUpdate.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 10,
        "name" => "PerceptionMapUpdate.Channel",
  }
}

PerceptionMapUpdateOutput = {
    "interface" => "PerceptionMapUpdate.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "PerceptionMapUpdate.Channel",
        "compression" => "passthrough",
  }
}

PerceptionMapRequestInput = {
    "interface" => "PerceptionMapRequest.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 10,
        "name" => "PerceptionMapRequest.Channel",
  }
}

PerceptionMapRequestOutput = {
    "interface" => "PerceptionMapRequest.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "PerceptionMapRequest.Channel",
        "compression" => "passthrough",
  }
}

AbridgedPerceptionMapUpdateInput = {
    "interface" => "AbridgedPerceptionMapUpdate.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 10,
        "name" => "AbridgedPerceptionMapUpdate.Channel",
  }
}

AbridgedPerceptionMapUpdateOutput = {
    "interface" => "AbridgedPerceptionMapUpdate.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "AbridgedPerceptionMapUpdate.Channel",
        "compression" => "passthrough",
  }
}

AbridgedPerceptionMapRequestInput = {
    "interface" => "AbridgedPerceptionMapRequest.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 10,
        "name" => "AbridgedPerceptionMapRequest.Channel",
  }
}

AbridgedPerceptionMapRequestOutput = {
    "interface" => "AbridgedPerceptionMapRequest.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "AbridgedPerceptionMapRequest.Channel",
        "compression" => "passthrough",
  }
}

AutonomyConditionInput = {
   "interface" => "AutonomyCondition.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "AutonomyCondition.Channel",
    }
}

AutonomyConditionOutput = {
   "interface" => "AutonomyCondition.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "AutonomyCondition.Channel",
        "compression" => "passthrough",
    }
}

FeatureVectorInput = createBasicInputInterface("FeatureVector")
FeatureVectorOutput = createBasicOutputInterface("FeatureVector")

FeatureVectorRequestInput = createBasicInputInterface("FeatureVectorRequest")
FeatureVectorRequestOutput = createBasicOutputInterface("FeatureVectorRequest")


ClearPerceptionMapCommandInput = createBasicInputInterface("ClearPerceptionMapCommand")
ClearPerceptionMapCommandOutput = createBasicOutputInterface("ClearPerceptionMapCommand")

DisablePerceptionStopInput = createBasicInputInterface("DisablePerceptionStop")
DisablePerceptionStopOutput = createBasicOutputInterface("DisablePerceptionStop")

PathTrackerConfigParametersInput = createBasicInputInterface("PathTrackerConfigParameters")
PathTrackerConfigParametersOutput = createBasicOutputInterface("PathTrackerConfigParameters")

PrimaryObstacleReportInput = createBasicInputInterface("PrimaryObstacleReport")
PrimaryObstacleReportOutput = createBasicOutputInterface("PrimaryObstacleReport")

VehicleObserverStatusInput = createBasicInputInterface("VehicleObserverStatus")
VehicleObserverStatusOutput = createBasicOutputInterface("VehicleObserverStatus")

VehicleObserverModeInput = createBasicInputInterface("VehicleObserverMode")
VehicleObserverModeOutput = createBasicOutputInterface("VehicleObserverMode")

VehicleObserverNotificationInput = createBasicInputInterface("VehicleObserverNotification")
VehicleObserverNotificationOutput = createBasicOutputInterface("VehicleObserverNotification")

PlanningCheckoutStatusInput = createBasicInputInterface("PlanningCheckoutStatus")
PlanningCheckoutStatusInput["channel"]["queueSize"] = 20;
PlanningCheckoutStatusOutput = createBasicOutputInterface("PlanningCheckoutStatus")

PlanningCheckoutModeInput = createBasicInputInterface("PlanningCheckoutMode")
PlanningCheckoutModeInput["channel"]["queueSize"] = 20;
PlanningCheckoutModeOutput = createBasicOutputInterface("PlanningCheckoutMode")

SecondaryBrakeRequestInput = createBasicInputInterface("SecondaryBrakeRequest")
SecondaryBrakeRequestOutput = createBasicOutputInterface("SecondaryBrakeRequest")

MCMAggressiveStopInput = createBasicInputInterface("MCMAggressiveStop")
MCMAggressiveStopOutput = createBasicOutputInterface("MCMAggressiveStop")

LibInfoDiagnostics1Output = {
    "interface" => "LibInfoDiagnostics.Channel.Output",
    "channel" => {
      "type" => "SimpleComms",
      "priority" => 1,
      "queueSize" => 100,
      "name" => "LibInfoDiagnostics1.Channel",
    }
}

LibInfoEvents1Output = {
    "interface" => "LibInfoDiagnostics.Channel.Output",
    "channel" => {
      "type" => "SimpleComms",
      "priority" => 1,
      "queueSize" => 100,
      "name" => "LibInfoEvents1.Channel",
      "compression" => "passthrough",
    }
}

ZVelodynePacketGroupInput = {
    "interface" => "VelodynePacketGroup.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1000,
        "name" => "VelodynePacketGroup.ZChannel",
    }
}

ZVelodynePacketGroupOutput = {
    "interface" => "VelodynePacketGroup.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 100,
        "name" => "VelodynePacketGroup.ZChannel",
        "compression" => DefaultCompression,
    }
}

AssignmentRequestInput = createBasicInputInterface("AssignmentRequest")
AssignmentRequestOutput = createBasicOutputInterface("AssignmentRequest")

AutonomyAssignmentMessageLatencyInput = createBasicInputInterface("AutonomyAssignmentMessageLatency")
AutonomyAssignmentMessageLatencyOutput = createBasicOutputInterface("AutonomyAssignmentMessageLatency")

VersionInfoInput = createBasicInputInterface("VersionInfo")
VersionInfoOutput = createBasicOutputInterface("VersionInfo")

ElevationInterfaceUpdateInput = createBasicInputInterface("ElevationInterfaceUpdate")
ElevationInterfaceUpdateOutput = createBasicOutputInterface("ElevationInterfaceUpdate")

ZElevationInterfaceUpdateInput = {
    "interface" => "ElevationInterfaceUpdate.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "ElevationInterfaceUpdate.ZChannel",
    }
}

ZElevationInterfaceUpdateOutput = {
    "interface" => "ElevationInterfaceUpdate.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "ElevationInterfaceUpdate.ZChannel",
        "compression" => DefaultCompression,
    }
}

ElevationInterfaceUpdateRequestInput = createBasicInputInterface("ElevationInterfaceUpdateRequest")
ElevationInterfaceUpdateRequestOutput = createBasicOutputInterface("ElevationInterfaceUpdateRequest")

MineModelResponseInput = createBasicInputInterface("MineModelResponse")
MineModelResponseOutput = createBasicOutputInterface("MineModelResponse")

DatumBookmarkInput = createBasicInputInterface("DatumBookmark")
DatumBookmarkInput["channel"]["queueSize"] = 100;
DatumBookmarkOutput = createBasicOutputInterface("DatumBookmark")

DeterministicPlaybackStatusInput = createBasicInputInterface("DeterministicPlaybackStatus")
DeterministicPlaybackStatusOutput = createBasicOutputInterface("DeterministicPlaybackStatus")

#DeterministicTaskStateInput = createBasicInputInterface("DeterministicTaskState")
ZDeterministicTaskStateInput = createBasicInputInterface("DeterministicTaskState")
ZDeterministicTaskStateInput["channel"]["name"] = "DeterministicTaskState.ZChannel";
ZDeterministicTaskStateInput["channel"]["unixPath"] = "lowPri";

#DeterministicTaskStateOutput = createBasicOutputInterface("DeterministicTaskState")
ZDeterministicTaskStateOutput = createBasicOutputInterface("DeterministicTaskState")
ZDeterministicTaskStateOutput["channel"]["name"] = "DeterministicTaskState.ZChannel";
ZDeterministicTaskStateOutput["channel"]["compression"] = DefaultCompression;
ZDeterministicTaskStateOutput["channel"]["unixPath"] = "lowPri";

BiplaneFittingInput = createBasicInputInterface("BiplaneFitting")
BiplaneFittingOutput = createBasicOutputInterface("BiplaneFitting")

PositioningUncertaintyOverrideInput = createBasicInputInterface("PositioningUncertaintyOverride")
PositioningUncertaintyOverrideOutput = createBasicOutputInterface("PositioningUncertaintyOverride")

SimMS990ProcOverrideInput = createBasicInputInterface("SimMS990ProcOverride")
SimMS990ProcOverrideOutput = createBasicOutputInterface("SimMS990ProcOverride")

SimMS990ProcOverride1Input = {
    "interface" => "SimMS990ProcOverride.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "SimMS990ProcOverride1.Channel",
    }
}

SimMS990ProcOverride1Output = {
    "interface" => "SimMS990ProcOverride.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "SimMS990ProcOverride1.Channel",
        "compression" => "passthrough",
    }
}

SimMS990ProcOverride2Input = {
    "interface" => "SimMS990ProcOverride.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "SimMS990ProcOverride2.Channel",
    }
}

SimMS990ProcOverride2Output = {
    "interface" => "SimMS990ProcOverride.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "SimMS990ProcOverride2.Channel",
        "compression" => "passthrough",
    }
}

ShutdownRequestInput = createBasicInputInterface("ShutdownRequest")
ShutdownRequestOutput = createBasicOutputInterface("ShutdownRequest")

ShutdownStateInput = createBasicInputInterface("ShutdownState")
ShutdownStateOutput = createBasicOutputInterface("ShutdownState")

KSOOutputGPIO = {
    "interface" => "KSO.GPIO.Output",
    "filename"  => "/dev/shm/AHS_GPIO/KeySwitchOverrideAHS",
}

KeyswitchInputGPIO = {
    "interface" => "Keyswitch.GPIO.Input",
    "filename"  => "/dev/shm/AHS_GPIO/KeySwitchStatus"
}

PlaybackDeterministicCommandInput = createBasicInputInterface("PlaybackDeterministicCommand")
PlaybackDeterministicCommandOutput = createBasicOutputInterface("PlaybackDeterministicCommand")

DeterministicTaskInfoInput = createBasicInputInterface("DeterministicTaskInfo")
DeterministicTaskInfoOutput= createBasicOutputInterface("DeterministicTaskInfo")

CellDataRequestInput = createBasicInputInterface("CellDataRequest")
CellDataRequestOutput = createBasicOutputInterface("CellDataRequest")
VelodyneCellDataResponseInput = createBasicInputInterface("VelodyneCellDataResponse")
VelodyneCellDataResponseOutput = createBasicOutputInterface("VelodyneCellDataResponse")
ODCellDataResponseInput = createBasicInputInterface("ODCellDataResponse")
ODCellDataResponseOutput = createBasicOutputInterface("ODCellDataResponse")
LOSCellDataResponseInput = createBasicInputInterface("LOSCellDataResponse")
LOSCellDataResponseOutput = createBasicOutputInterface("LOSCellDataResponse")

PerceptionVisibilityInput = {
    "interface" => "PerceptionVisibility.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "PerceptionVisibility.Channel",
    }
}

PerceptionVisibilityOutput = {
    "interface" => "PerceptionVisibility.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "PerceptionVisibility.Channel",
        "compression" => "passthrough",
    }
}

TextWritableRequestOutput = {
    "interface" => "TextWritableRequest.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "TextWritableRequest.Channel",
        "compression" => "passthrough",
    }
}

TextWritableRequestInput = {
    "interface" => "TextWritableRequest.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "TextWritableRequest.Channel",
    }
}

TextWritableResponseOutput = {
    "interface" => "TextWritableResponse.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "TextWritableResponse.Channel",
        "compression" => "passthrough",
    }
}

TextWritableResponseInput = {
    "interface" => "TextWritableResponse.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "TextWritableResponse.Channel",
    }
}

BumpSignalInput = {
    "interface" => "BumpSignal.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "BumpSignal.Channel",
    }
}

BumpSignalOutput = {
    "interface" => "BumpSignal.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "BumpSignal.Channel",
        "compression" => "passthrough",
    }
}

PermissionRequestInput = {
    "interface" => "PermissionRequest.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "PermissionRequest.Channel",
    }
}

PermissionRequestOutput = {
    "interface" => "PermissionRequest.Channel.Output",
    "channel" => {
        "type" => "SimpleComms",
        "priority" => 1,
        "queueSize" => 1,
        "name" => "PermissionRequest.Channel",
        "compression" => "passthrough",
    }
}

PingInput = createBasicInputInterface("Ping")
PingOutput = createBasicOutputInterface("Ping")

PIM2StateInput = createBasicInputInterface("PIM2State")
PIM2StateOutput = createBasicOutputInterface("PIM2State")

PositionDriftInput = createBasicInputInterface("PositionDrift")
PositionDriftInput["channel"]["queueSize"] = 10;
PositionDriftOutput = createBasicOutputInterface("PositionDrift")
PositionDriftOutput["channel"]["queueSize"] = 10;

CalibrationPolePositionInput = createBasicInputInterface("CalibrationPolePosition")
CalibrationPolePositionOutput = createBasicOutputInterface("CalibrationPolePosition")

FODStatusInput = createBasicInputInterface("FODStatus")
FODStatusOutput = createBasicOutputInterface("FODStatus")
FODConfigChangeInput = createBasicInputInterface("FODConfigChange")
FODConfigChangeOutput = createBasicOutputInterface("FODConfigChange")
FODCommandInput = createBasicInputInterface("FODCommand")
FODCommandOutput = createBasicOutputInterface("FODCommand")
FODMapUpdateInput = createBasicInputInterface("FODMapUpdate")
FODMapUpdateOutput = createBasicOutputInterface("FODMapUpdate")
FODMapCycleUpdateInput = createBasicInputInterface("FODMapCycleUpdate")
FODMapCycleUpdateOutput = createBasicOutputInterface("FODMapCycleUpdate")

DiagnosticStatusInput = createBasicInputInterface("DiagnosticStatus")
DiagnosticStatusOutput = createBasicOutputInterface("DiagnosticStatus")

ImuGroundSpeedInput = createBasicInputInterface("ImuGroundSpeed")
ImuGroundSpeedOutput = createBasicOutputInterface("ImuGroundSpeed")


ApplanixAmtOpModeCommandInput = createBasicInputInterface("ApplanixAmtOpModeCommand")
ApplanixAmtOpModeCommandOutput = createBasicOutputInterface("ApplanixAmtOpModeCommand")

AutonomyConditionMessageInput = createBasicInputInterface("AutonomyConditionMessage")
AutonomyConditionMessageInput["channel"]["queueSize"] = 100; # larger queue since there could be many conditions from multiple sources
AutonomyConditionMessageOutput = createBasicOutputInterface("AutonomyConditionMessage")

# VelodyneIntrinsicsMessage
VelodyneIntrinsicsMessageInput = createBasicInputInterface("VelodyneIntrinsicsMessage")
VelodyneIntrinsicsMessageOutput = createBasicOutputInterface("VelodyneIntrinsicsMessage")

# VelodyneIntrinsicsRequest
VelodyneIntrinsicsRequestInput = createBasicInputInterface("VelodyneIntrinsicsRequest")
VelodyneIntrinsicsRequestOutput = createBasicOutputInterface("VelodyneIntrinsicsRequest")

# RangeImageChecksum
RangeImageChecksumInput = createBasicInputInterface("RangeImageChecksum")
RangeImageChecksumInput["channel"]["queueSize"] = 200
RangeImageChecksumOutput = createBasicOutputInterface("RangeImageChecksum")

SimpleCommsClientStatusInput = {
    "interface" => "SimpleCommsClientStatus.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "queueSize" => 50, # these data are bursty: every task in the system sends them at ~1 Hz
        "name" => "SimpleCommsStats",  # note: must be the same as SIMPLECOMMS_STATS_CHANNEL in comms/Constants.h
    }
}

SimpleCommsClientStatusAltInput = {
    "interface" => "SimpleCommsClientStatus.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "queueSize" => 50, # these data are bursty: every task in the system sends them at ~1 Hz
        "name" => "SimpleCommsStats",  # note: must be the same as SIMPLECOMMS_STATS_CHANNEL in comms/Constants.h
        "unixPath" => "alt",
    }
}

SimpleCommsClientStatusLowPriInput = {
    "interface" => "SimpleCommsClientStatus.Channel.Input",
    "channel" => {
        "type" => "SimpleComms",
        "queueSize" => 50, # these data are bursty: every task in the system sends them at ~1 Hz
        "name" => "SimpleCommsStats",  # note: must be the same as SIMPLECOMMS_STATS_CHANNEL in comms/Constants.h
        "unixPath" => "lowPri",
    }
}

ScsMessageStatsInput = createBasicInputInterface("ScsMessageStats")
ScsMessageStatsOutput = createBasicOutputInterface("ScsMessageStats")

PrepareToMoveInput = createBasicInputInterface("PrepareToMove")
PrepareToMoveOutput = createBasicOutputInterface("PrepareToMove")

MCMSpeedCommandInput = createBasicInputInterface("MCMSpeedCommand")
MCMSpeedCommandOutput = createBasicOutputInterface("MCMSpeedCommand")

EnableBermDetectionInput = createBasicInputInterface("EnableBermDetection")
EnableBermDetectionOutput = createBasicOutputInterface("EnableBermDetection")

BermDetectionStatusInput = createBasicInputInterface("BermDetectionStatus")
BermDetectionStatusOutput = createBasicOutputInterface("BermDetectionStatus")

AssignmentMessageInput = createBasicInputInterface("AssignmentMessage")
AssignmentMessageInput["channel"]["unixPath"] = "lowPri"
AssignmentMessageOutput = createBasicOutputInterface("AssignmentMessage")
AssignmentMessageOutput["channel"]["unixPath"] = "lowPri"

AdjustLogLevelInput = createBasicInputInterface("AdjustLogLevel")
AdjustLogLevelOutput = createBasicOutputInterface("AdjustLogLevel")

BaseCanCcpDataInput = createBasicInputInterface("BaseCanCcpData")
BaseCanCcpDataInput["channel"]["queueSize"] = 50;
BaseCanCcpDataOutput = createBasicOutputInterface("BaseCanCcpData")
BaseCanCcpDataOutput["channel"]["queueSize"] = 50;

RGAInspectorDataInput = createBasicInputInterface("RGAInspectorData")
RGAInspectorDataOutput = createBasicOutputInterface("RGAInspectorData")

LineOfSightMapUpdateInput = createBasicInputInterface("LineOfSightMapUpdate")
LineOfSightMapUpdateOutput = createBasicOutputInterface("LineOfSightMapUpdate")

LineOfSightRangeInput= createBasicInputInterface("LineOfSightRange")
LineOfSightRangeOutput= createBasicOutputInterface("LineOfSightRange")

CommandRadarInput = createBasicInputInterface("CommandRadar")
CommandRadarOutput = createBasicOutputInterface("CommandRadar")

PerceptionExtrinsicsConfigInput = createBasicInputInterface("PerceptionExtrinsicsConfig")
PerceptionExtrinsicsConfigOutput = createBasicOutputInterface("PerceptionExtrinsicsConfig")

PerceptionExtrinsicsConfigRequestInput = createBasicInputInterface("PerceptionExtrinsicsConfigRequest")
PerceptionExtrinsicsConfigRequestOutput = createBasicOutputInterface("PerceptionExtrinsicsConfigRequest")

AllProcessStatusInput = createBasicInputInterface("AllProcessStatus")
AllProcessStatusOutput = createBasicOutputInterface("AllProcessStatus")

TmacStatisticsInput = createBasicInputInterface("TmacStatistics")
TmacStatisticsOutput = createBasicOutputInterface("TmacStatistics")

MovingObstacleDetectionControlInput = createBasicInputInterface("MovingObstacleDetectionControl")
MovingObstacleDetectionControlOutput = createBasicOutputInterface("MovingObstacleDetectionControl")
MovingObstacleDetectionDiagnosticsInput = createBasicInputInterface("MovingObstacleDetectionDiagnostics")
MovingObstacleDetectionDiagnosticsOutput = createBasicOutputInterface("MovingObstacleDetectionDiagnostics")
MovingObstacleListInput = createBasicInputInterface("MovingObstacleList")
MovingObstacleListOutput = createBasicOutputInterface("MovingObstacleList")
LadarObjectListInput = createBasicInputInterface("LadarObjectList")
LadarObjectListOutput = createBasicOutputInterface("LadarObjectList")

ZGroundSurfaceInput = createBasicInputInterface("GroundSurface")
ZGroundSurfaceInput["channel"]["name"] = "GroundSurface.ZChannel";
ZGroundSurfaceInput["channel"]["unixPath"] = "lowPri";
ZGroundSurfaceOutput = createBasicOutputInterface("GroundSurface")
ZGroundSurfaceOutput["channel"]["name"] = "GroundSurface.ZChannel";
ZGroundSurfaceOutput["channel"]["compression"] = DefaultCompression;
ZGroundSurfaceOutput["channel"]["unixPath"] = "lowPri";

GroundSurfaceRequestInput = createBasicInputInterface("GroundSurfaceRequest")
GroundSurfaceRequestOutput = createBasicOutputInterface("GroundSurfaceRequest")

AutonomousCabinetCoolingParametersInput = createBasicInputInterface("AutonomousCabinetCoolingParameters")
AutonomousCabinetCoolingParametersOutput = createBasicOutputInterface("AutonomousCabinetCoolingParameters")

StrutPressureSensorInputsInput = createBasicInputInterface("StrutPressureSensorInputs")
StrutPressureSensorInputsOutput = createBasicOutputInterface("StrutPressureSensorInputs")

CoreDumpInfoInput = createBasicInputInterface("CoreDumpInfo")
CoreDumpInfoOutput = createBasicOutputInterface("CoreDumpInfo")

ZSystemConfigGlobInput = createBasicInputInterface("SystemConfigGlob")
ZSystemConfigGlobOutput = createBasicOutputInterface("SystemConfigGlob")
ZSystemConfigGlobInput["channel"]["name"] = "SystemConfigGlob.ZChannel";
ZSystemConfigGlobOutput["channel"]["name"] = "SystemConfigGlob.ZChannel";
ZSystemConfigGlobOutput["channel"]["compression"] = DefaultCompression;

SystemConfigGlobRequestInput = createBasicInputInterface("SystemConfigGlobRequest")
SystemConfigGlobRequestOutput = createBasicOutputInterface("SystemConfigGlobRequest")

SimOBIRouteObjUpdateInput = createBasicInputInterface("SimOBIRouteObjUpdate")
SimOBIRouteObjUpdateOutput = createBasicOutputInterface("SimOBIRouteObjUpdate")

ApplanixDispPortStateInput = createBasicInputInterface("ApplanixDispPortState")
ApplanixDispPortStateOutput = createBasicOutputInterface("ApplanixDispPortState")

LocalElevationMapInput = createBasicInputInterface("LocalElevationMap")
LocalElevationMapOutput = createBasicOutputInterface("LocalElevationMap")

WcsRequestStatusInput = createBasicInputInterface("WcsRequestStatus")
WcsRequestStatusOutput = createBasicOutputInterface("WcsRequestStatus")

WcsResponseDataInput = createBasicInputInterface("WcsResponseData")
WcsResponseDataOutput = createBasicOutputInterface("WcsResponseData")

Bd960AltPoseInput = createBasicInputInterface("Bd960AltPose")
Bd960AltPoseOutput = createBasicOutputInterface("Bd960AltPose")

SimIntelligentDriverInput = createBasicInputInterface("SimIntelligentDriver")
SimIntelligentDriverOutput = createBasicOutputInterface("SimIntelligentDriver")

ModelAnalysisResultsInput = createBasicInputInterface("ModelAnalysisResults")
ModelAnalysisResultsOutput = createBasicOutputInterface("ModelAnalysisResults")

ModelUpdateInput = createBasicInputInterface("ModelUpdate")
ModelUpdateOutput = createBasicOutputInterface("ModelUpdate")

ActiveDiagnosticsInput =  createBasicInputInterface("ActiveDiagnostics")
ActiveDiagnosticsOutput = createBasicOutputInterface("ActiveDiagnostics")

EventReactionsInput =  createBasicInputInterface("EventReactions")
EventReactionsOutput = createBasicOutputInterface("EventReactions")

EventReactionsRequestInput =  createBasicInputInterface("EventReactionsRequest")
EventReactionsRequestOutput = createBasicOutputInterface("EventReactionsRequest")

SystemStartDmesgInput =  createBasicInputInterface("SystemStartDmesg")
SystemStartDmesgInput["channel"]["queueSize"] = 50;
SystemStartDmesgOutput = createBasicOutputInterface("SystemStartDmesg")

AllHostDmesgInput =  createBasicInputInterface("AllHostDmesg")
AllHostDmesgOutput = createBasicOutputInterface("AllHostDmesg")

SystemStartDmesgRequestInput =  createBasicInputInterface("SystemStartDmesgRequest")
SystemStartDmesgRequestOutput = createBasicOutputInterface("SystemStartDmesgRequest")

SyslogListInput =  createBasicInputInterface("SyslogList")
SyslogListOutput = createBasicOutputInterface("SyslogList")

VersionInfoRequestInput =  createBasicInputInterface("VersionInfoRequest")
VersionInfoRequestOutput = createBasicOutputInterface("VersionInfoRequest")

SurveyStartInput =  createBasicInputInterface("SurveyStart")
SurveyStartOutput = createBasicOutputInterface("SurveyStart")

SurveyStopInput =  createBasicInputInterface("SurveyStop")
SurveyStopOutput = createBasicOutputInterface("SurveyStop")

SurveyDataInput =  createBasicInputInterface("SurveyData")
SurveyDataInput["channel"]["unixPath"] = "lowPri";
SurveyDataOutput = createBasicOutputInterface("SurveyData")
SurveyDataOutput["channel"]["unixPath"] = "lowPri";

StopDrivingRequestInput =  createBasicInputInterface("StopDrivingRequest")
StopDrivingRequestInput["channel"]["queueSize"] = 200;
StopDrivingRequestOutput = createBasicOutputInterface("StopDrivingRequest")
StopDrivingRequestOutput["channel"]["queueSize"] = 200;

MstarGeoClientStatusInput =  createBasicInputInterface("MstarGeoClientStatus")
MstarGeoClientStatusInput["channel"]["unixPath"] = "lowPri";
MstarGeoClientStatusInput["channel"]["queueSize"] = 10;
  
MstarGeoClientStatusOutput = createBasicOutputInterface("MstarGeoClientStatus")
MstarGeoClientStatusOutput["channel"]["compression"] = DefaultCompression;
MstarGeoClientStatusOutput["channel"]["unixPath"] = "lowPri";
MstarGeoClientStatusOutput["channel"]["queueSize"] = 10;

NetworkReportInput = createBasicInputInterface("NetworkReport")
NetworkReportOutput = createBasicOutputInterface("NetworkReport")

CPMDemoInput = createBasicInputInterface("CPMDemo")
CPMDemoOutput = createBasicOutputInterface("CPMDemo")

AutoLoggerSnapshotListInput =  createBasicInputInterface("AutoLoggerSnapshotList")
AutoLoggerSnapshotListOutput = createBasicOutputInterface("AutoLoggerSnapshotList")

StatisticGroundSimControlInput = createBasicInputInterface("StatisticGroundSimControl")
StatisticGroundSimControlOutput = createBasicOutputInterface("StatisticGroundSimControl")

GAMSCalibrationModeInput = createBasicInputInterface("GAMSCalibrationMode")
GAMSCalibrationModeOutput = createBasicOutputInterface("GAMSCalibrationMode")

SiteConfigInput = createBasicInputInterface("SiteConfig")
SiteConfigInput["channel"]["queueSize"] = 10;
SiteConfigOutput = createBasicOutputInterface("SiteConfig")
SiteConfigOutput["channel"]["queueSize"] = 10;
SiteConfigRequestInput = createBasicInputInterface("SiteConfigRequest")
SiteConfigRequestOutput = createBasicOutputInterface("SiteConfigRequest")


MachineSNOutput = createBasicOutputInterface("MachineSN")
MachineSNInput = createBasicInputInterface("MachineSN")

SEAStatusOutput = createBasicOutputInterface("SEAStatus")
SEAStatusInput = createBasicInputInterface("SEAStatus")
# ----------------------------------------------------------------------------------
end

# If there's an auxiliary file, load it
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/interfaces_aux.rb"))
    puts "-----CONFIG: Updating interfaces.rb with mods from interfaces_aux.rb"
    load "interfaces_aux.rb"
end

# If interfacesMacom.rb exists then add interface definitions defined there
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/interfacesMacom.rb"))
  puts "Adding definitions in "+ENV["CAT_CONFIG_DIR"].to_s + "/interfacesMacom.rb to InterfaceDefs"
  load "interfacesMacom.rb"
end

# If interfacesDelphi.rb exists then add interface definitions defined there
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/interfacesDelphi.rb"))
  puts "Adding definitions in "+ENV["CAT_CONFIG_DIR"].to_s + "/interfacesDelphi.rb to InterfaceDefs"
  load "interfacesDelphi.rb"
end

# If interfacesMacom.rb exists then add interface definitions defined there
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/interfacesLux.rb"))
  puts "Adding definitions in "+ENV["CAT_CONFIG_DIR"].to_s + "/interfacesLux.rb to InterfaceDefs"
  load "interfacesLux.rb"
end

# If interfaces_MachineCommon.rb exists then add interface definitions defined there
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/interfaces_MachineCommon.rb"))
    puts "-----CONFIG: Updating interfaces.rb with mods from interfaces_MachineCommon.rb"
    load "interfaces_MachineCommon.rb"
end

