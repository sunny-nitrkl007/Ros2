load "commonAutonomyTask.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
    "SyslogBridgeStatusOutput" => InterfaceDefs::SyslogBridgeStatusOutput,
    "SystemStartDmesgOutput" => InterfaceDefs::SystemStartDmesgOutput, 
    "SyslogListOutput" => InterfaceDefs::SyslogListOutput,
    
    # this instance will aggregate, so it requires extra interfaces
    "SystemStartDmesgRequestOutput" => InterfaceDefs::SystemStartDmesgRequestOutput,
    "SystemStartDmesgInput" => InterfaceDefs::SystemStartDmesgInput,  
    "AllHostDmesgOutput" => InterfaceDefs::AllHostDmesgOutput,  
    "SyslogListInput" => InterfaceDefs::SyslogListInput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "warn",

  #"requireGPSTimeSynchronizationOnStart" => false,

  # The port to listen for syslog messages on (rsyslog
  # must be configured to send to this port)
  "listenerPort" => 10514,  # rsyslog set to 127.0.0.1:10514  (ahs-u1204-2013-10-07-v1)

  # The rate that we publish state information to the OCS
  "cycleRate_hz" => 1,   
  
  # This flag indicates that this instance should aggregate all of the SystemStartDmesg input and write out as one datum
  "aggregateDmesg" => true,

  # Suppress the syslog messages if they exceed this data rate.
  "suppressionLimit_hz" => 20,  # set to 0 to not suppress
} )

Execution = {
  "executableName" => "syslogBridge",
}

