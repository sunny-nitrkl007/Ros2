require "commonAutonomyTask.rb"
Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
   "ShmClockInput"   => InterfaceDefs::ShmClockInput,
} )
Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
   "requireGPSTimeSynchronizationOnStart" => false, # ALLOW this process to start without synchronization
   "loggerThreshold" => "error",
   "cycleRate_hz" => 10,

  # CAN port assigned to primary and secondary GPS receivers
  # Valid values:
  #     0 - can0 or CAN1 or CAN A
  #     1 - can1 or CAN2 or CAN B
  #
  "EDDT_CAN_port" => 0,

  # J1939 SID of Master ECM
  "ID_Master" => 0xCD,
} )

RTC_TZ = {
  "RTC_Security"  => 0, #0-> Non-Secure, 1->Secure
  "RTC_Type"      => 4, #0-> Standalone, 1->Distributed Client, 2-> Distributed Server, 3->PID client, 4-> PID server
  "RTC_Master"    => 0xF1, #Relevant for RTC_Type 1 or 3
}

NVM = { 
#   Key   BlockID         BlockSize  BlockIntegrity  File1                               
#  -----  ----------      ---------  --------------  -----------
   "00"=> ["0x00010000",  "1560",    "0",            "A6N5_Diagnostics_Events_Log.txt", ],
   "01"=> ["0x00000010",  "532",     "0",            "A6N5_Service_Clock_Primary.txt",  ],
   "02"=> ["0x00000011",  "532",     "0",            "A6N5_Service_Clock_Secondary.txt",],
   "03"=> ["0x00010001",  "25",      "0",            "A6N5_RTC_Time_Zone_Old.txt",      ],
   "09"=> ["0x00010003",  "25",      "0",            "A6N5_RTC_Time_Zone_New.txt",      ],
   "04"=> ["0x00010002",  "13",      "0",            "A6N5_RTC_Secure.txt",             ],
   "05"=> ["0x0001000a",  "8",       "0",            "A6N5_ProductID.txt",              ],

   "06"=> ["0x00010020",  "8",       "0",            "A6N5_SEA1.txt",                   ],
   "07"=> ["0x00010021",  "8",       "0",            "A6N5_SEA2.txt",                   ],
   "08"=> ["0x00010022",  "8",       "0",            "A6N5_SEA3.txt",                   ],

}

DeviceID_J1939 = {
  #Analysis  : 0x9601 0000 0600
  #Analysis  : 0x9601 0000 0F00<<
  #Autonomous: 0x6004 0000 2400

  "MID"        => 0x0196,
  "ST_chg_lvl" => 0x0000,
  "ST_app_num" => 0x000F,
}

SEA = { 
#   Key   ReasonCode  PermInstallPID  PermEnablePID  SecurityLvl  EncByte  EncBit  TempCounter  TempInstallPID  TempCounterPID  
#  -----  ----------  --------------  -------------  -----------  -------  ------  ----------   --------------  --------------
   "00"=> ["149",      "0xD10DA0",      "0xD10EE7",   "1",         "1",     "1",    "1",         "0xD10EE6",     "0xD01A48", ],
   "01"=> ["150",      "0xD10DA1",      "0xD114C4",   "0",         "1",     "2",    "0",         "0x000000",     "0x000000", ],
   "02"=> ["151",      "0xD10DA2",      "0xD114C5",   "2",         "1",     "3",    "1",         "0xD10EE7",     "0xD01A49", ],
   #"03"=> ["152",      "0xD10DA3",      "0xD114C6",   "0",         "1",     "4",    "0",         "0x000000",     "0x000000", ],
   #"04"=> ["153",      "0xD10DA4",      "0xD114C7",   "2",         "1",     "5",    "1",         "0xD10EE8",     "0xD01A4A", ],
   #"05"=> ["154",      "0xD10DA5",      "0xD114C8",   "0",         "1",     "6",    "0",         "0x000000",     "0x000000", ],
   #"06"=> ["155",      "0xD10DA6",      "0xD114C9",   "0",         "1",     "7",    "0",         "0x000000",     "0x000000", ],
   #"07"=> ["156",      "0xD10DA7",      "0xD114CA",   "2",         "1",     "8",    "1",         "0xD10EE9",     "0xD01A4B", ],
   #"08"=> ["157",      "0xD10DA8",      "0xD114CB",   "0",         "2",     "1",    "0",         "0x000000",     "0x000000", ],
   #"09"=> ["158",      "0xD10DA9",      "0xD114CC",   "2",         "2",     "2",    "1",         "0xD10EEA",     "0xD01A4C", ],
   #"10"=> ["159",      "0xD10DB0",      "0xD114CD",   "0",         "2",     "3",    "0",         "0x000000",     "0x000000", ],
}

# ECM J1939 Name
Ecm_J1939_Name = {
  "Industry_Group"          => 3,
  "Vehicle_System"          => 0,
  "Vehicle_System_Instance" => 0,
  "Function"                => 145,
  "Function_Instance"       => 3,
  "ECU_Instance"            => 0,
  "Manufacturer_Code"       => 8,
  "Identity_Number"         => 0x230813,
  "Preferred_Address"       => 0xEC,
}


Execution = {
  "executableName" => "testRTCTask",
}


