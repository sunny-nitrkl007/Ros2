require "commonLoad.rb"
load "commonTaskParams.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
    #"GenericDebug2Input"                => InterfaceDefs::GenericDebug2Input,
    #"GenericDebug2Output"               => InterfaceDefs::GenericDebug2Output,
    "MCMStatusOutput"                   => InterfaceDefs::MCMStatusOutput,
    #"RegulateSpeedInput"                => InterfaceDefs::RegulateSpeedInput,
    #"PathTrackerFeedbackInputPri"       => InterfaceDefs::PathTrackerFeedbackInputPri,
    #"PathTrackerFeedbackOutputPri"      => InterfaceDefs::PathTrackerFeedbackOutputPri,
    #"PathTrackerFeedbackInputSec"       => InterfaceDefs::PathTrackerFeedbackInputSec,
    #"PathTrackerFeedbackOutputSec"      => InterfaceDefs::PathTrackerFeedbackOutputSec,
    #"PositionInput"                     => InterfaceDefs::BD950Position1Input,
    #"LibInfoDiagnosticsOutput"          => InterfaceDefs::LibInfoDiagnosticsOutput,
    #"LibInfoEventsOutput"               => InterfaceDefs::LibInfoEventsOutput,
    #"PathTrackerConfigParametersOutput" => InterfaceDefs::PathTrackerConfigParametersOutput,
    #"ApplanixStateOutput"               => InterfaceDefs::ApplanixStateOutput,
    #"ApplanixAmtOpModeCommandOutput"    => InterfaceDefs::ApplanixAmtOpModeCommandOutput, 
    "ApplanixImuFaultOutput"            => InterfaceDefs::ApplanixImuFaultOutput,
    "ShutdownStateOutput"               => InterfaceDefs::ShutdownStateOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "error",
  "cycleRate_hz" => 1,
} )

Execution = {
  "executableName" => "inputOutputSimulator2",
}
