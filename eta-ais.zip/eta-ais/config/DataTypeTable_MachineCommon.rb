DataTypes["Types"].concat(
[
  
   "CameraImage",
   "CameraStats",
   "CameraHealth",
   "OCSCameraImage",

   "ShmClock",
])

CameraStats = createLogChannel("CameraStats")
CameraStats["monitorSequenceNumber"] = false;

CameraHealth = createLogChannel("CameraHealth")
CameraHealth["monitorSequenceNumber"] = false;

CameraImage = createLogChannel("CameraImage")
CameraImage["monitorSequenceNumber"] = false;

OCSCameraImage = createLogChannel("OCSCameraImage")
OCSCameraImage["monitorSequenceNumber"] = false;


ShmClock = createLogChannel("ShmClock")