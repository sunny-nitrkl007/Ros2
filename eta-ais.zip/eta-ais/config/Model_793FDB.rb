
ModelParameters = {
  "simulationResolution_s" => 0.02,
  "frontSteeringAngleBias_rad" =>  0.0,           #actual steering angle when state-feedback curvature says 0.0
  "rearSteeringAngleBias_rad" =>  0.0,            #steering angle of the rear axle/wheels w.r.t. the frame
  "steeringDeadband_rad" => [0.0, 0.0],           #[-0.006004, 0.003997],# [negative deadband | positive deadband ] minimum command-state feedback steering error needed for steering actuation
  "maximumPositiveSteeringAngle_rad" => 0.5251,   #36deg max steer, but can only do 10.18m turn due to scrub
  "maximumNegativeSteeringAngle_rad" => -0.5251,
  "startFromStopLatency_s" => 8.004,
  "loadBooleanEmptyPercentage" => 0.20,           #vehicle load flag = false will indicate its 20% loaded
  "loadBooleanLoadPercentage" => 1.10,            #vehicle load flag = true will indicate its 110% loaded
  "baseLatency_sec" => 0.00,

  "cgLocationX_m" => [3.373, 1.894],              #X (from rear axle)  MT: 3373 mm  LD: 1894 mm
  "cgLocationY_m" => [0.198, 0.056],              #Y (from rear axle)  MT: 198  mm  LD: 56   mm (gas tank shifts it left)
  "cgLocationZ_m" => [3.181, 4.694],              #Z (from ground)     MT: 3181 mm  LD: 4694 mm
  "cgLocationUncertaintyX_m" => [0.25, 0.50],
  "cgLocationUncertaintyY_m" => [0.25, 0.50],
  "cgLocationUncertaintyZ_m" => [0.25, 0.50],
  "roadUncertaintyRoll_deg"  => [1.00, 1.00],
  "roadUncertaintyPitch_deg" => [1.00, 1.00],

  "maximumModeledGrade" => 0.10,                  # magnitude of maximum modeled grade as percentage between 0.0 and 1.0
  "maximumModeledBank" => 0.10,                   # magnitude of maximum modeled bank as percentage between 0.0 and 1.0

  #Error is defined as follows: error = test - truth
  #  From the perspective of state2path: path is truth as it is what actually happens with that state feedback
  #  From the perspective of command2state: state is truth as it is what results from a command
  #  e.g. state2path: error  = state - path
  #  To derive the expected path value: path = state - error 
  #
  #The following is a nonlinear map:
  #    curvStateToPathErrorMap        x: curv_state y: fabs(vel_state)  = z: resultant curv_path_error 
  #    
  #  The maps can be considerably nonlinear. The error represents the difference between the simulated and actual path curvatures, i.e. error = simulated - actual
  #  Within the vehicle model, the desired actual path curvature can be computed as simulated curvature as an output of the steeringActuator model -= error
  #    
  #The following are bicubic functions:
  #    fwdAccelCommandToStateValueMap x: accel_cmd, y: grade      = z: resultant accel, in forward gear
  #    fwdDecelCommandToStateValueMap x: decel_cmd, y: grade      = z: resultant decel, in forward gear
  #    revAccelCommandToStateValueMap x: accel_cmd, y: grade      = z: resultant accel, in reverse gear
  #    revDecelCommandToStateValueMap x: decel_cmd, y: grade      = z: resultant decel, in reverse gear
  #    curvCommandToStateValueMap     x: curv_cmd   y: fabs(vel_state)  = z: resultant curv_state
  #   
  #  z = a0*x^3*y^3 + ... + a3*x^3*y^0 + b0*x^2*y^3 + ... + b3*x^2*y^0 + ... + c0*x^1*y^3 + ... + d3*x^0*y^0
  #  which has 32 coefficients if there are separate MT & LD values (793), or 16 coefficients if they are identical (Tahoe)
  #  Note: with curvCommandToStateValueMap, the last term is the cmd-state bias, such that a zero command results in some bias (i.e. flooring)
  #   
  #The following are cubic functions:
  #    velStateToPathErrorMap     x: vel_state                 = z: resultant speed
  #    velCommandToStateValueMap  x: vel_cmd                   = z: resultant wheelspeed vel_state
  #
  #  z = a0*x^3 + a1*x^2 + a2*x^1 + a3*x^0 for [4 MT-coefs | 4 LD-coefs] - FDB
  #  which has 8 coefficients if there are separate MT & LD values (793), or 4 coefficients if they are identical (Tahoe)
  #
  #The following are linear functions:
  #    slewRateFit                x: fabs(curv_state)          = z: slewRate_state
  #    brakeLatencyFit            x: fabs(vel_state)           = z: brake_latency 
  #    throttleLatencyFit         x: fabs(vel_state)           = z: throttle_latency
  #    steerLatencyFit            x: fabs(curv_state)          = z: steer_latency
  #  
  #  z = a0*x^1 + a1*x^0
  #  which has 4 coefficients if there are separate MT & LD values (793), or 2 coefficients if they are identical (Tahoe)
  #  Note: If the value only varies by load (slew rate), then only coefficient a1 is populated. For slew rate this would stand for slew_radps
  #  
  #The following are general polynomials:
  #    emptyRimPullFit            x: fabs(grade)               = z: max_speed
  #    loadedRimPullFit           x: fabs(grade)               = z: max_speed
  #  
  #  z = a0*x^n + a1*x^(n-1) + ... + an*x^0
  #  which has separate empty and loaded coefficients. n coefficients mean that it was fitted to an (n-1) order polynomial

  "curvStateToPathErrorMapName" => "/calibration/VehicleMapCurvatureError_793SSP_v2_StateToPath.dat", #"/calibration/VehicleErrorMapCurvature_793_v1.dat", 
  "curvStateToPathErrorMapMD5Sum" => "cad2d7fae7b0b418c534cf35fd6a494a", #"0cc3c3c2bffa9eddc6b2ccef3255ad17",
  "curvCommandToStateValueMap"  => [ 0.0, 0.51434, -0.056665, -2.1429, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0027032, -0.021705, 1.0123, 0.0, 0.0, 0.0, 0.0, 0.0, 0.33816, -0.096999, -1.626, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0031518, -0.025862, 1.0117, 0.0, 0.0, 0.0, 0.0 ], 
  "slewRateFit" => [ 0.0, 0.28969, 0.0, 0.2342 ], #older data had 0.225

  "velStateToPathErrorMap"      => [ 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 ],
  "velCommandToStateValueMap"   => [ 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0 ],
  "fwdAccelCommandToStateValueMap" => [0.000000,47.233165,-0.325387,-0.372888,0.000000,-55.789983,-2.741930,0.078779,0.000000,10.430701,0.316347,0.994204,0.000000,0.000000,0.000000,0.000000,0.000000,22.360861,1.234893,0.044298,0.000000,-4.998834,-4.036737,-0.573858,0.000000,-13.730633,-1.057930,1.098018,0.000000,0.000000,0.000000,0.000000],
  "fwdDecelCommandToStateValueMap" => [ 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.469713, -0.004472, 0.0 , -7.341532, -7.036762, 0.806792, 0.0, 0.0, 7.995696,0.564280,0.0,0.0,0.0,0.0,0.0, 0.0, 0.171412, -0.097736, 0.0, -5.158901, 1.958419, 1.114783, 0.0, 0.0, -1.691437, 0.139491],
  "revAccelCommandToStateValueMap" => [ 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.5916e-12, -2.8422e-14, 3.5527e-15, 0.0, 0.36378, 1.2207, 0.47574, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.51388, -0.029202, -0.0038987, 0.0, 3.6432, 0.5148, 0.39688 ],
  "revDecelCommandToStateValueMap" => [ 0.0, 0.0, 0.0, 0.0, 0.0, -3.2278, 3.5527e-15, -0.14901, 0.0, 10.3563, 2.8422e-14, 0.72158, 0.0, -6.5806, -3.0, 0.63598, 0.0, 0.0, 0.0, 0.0, 0.0, 8.4567, -0.18565, -0.16746, 0.0, -26.9613, 0.74259, 0.70118, 0.0, 10.4092, -3.6962, 0.53506 ],

  #Using 793F rimpull curves because it reflects higher speed near zero grade -- more conservative forward simulation
  "emptyRimPullFit"  => [ 63813861.0748, -93032621.6512, 55728499.5218, -17626482.2599, 3133653.8813, -305040.9007, 14411.5047, -309.7674, 18.7047 ], #793F performance handbook datasheet
  "loadedRimPullFit" => [ -122941995.8117, 174960144.3489, -103345446.712, 32679353.434, -5936014.7058, 613394.7393, -32614.318, 574.5147, 13.4008 ], #793F performance handbook datasheet

  #These are absolute values; sign conventions are taken care of in the software. 
  #  This is to account for suspension compliance when approximating ground geometry from body pitch/roll
  #  Although this is more complex than a linear relationship, a first order approximation is a decent starting point                                   
  "groundToBodyGradeRatio" => [ 0.887, 0.903 ],  # [ MT | LD ] after converting a pitch angle to a grade percent, multiply by this to get ground grade
                                                 # this is a fraction relating ground/body and should be less than 1
  "groundToBodyBankRatio" =>  [ 0.828, 0.942 ],  # [ MT | LD ] after converting a roll angle to a bank percent, multiply by this to get ground bank
                                                 # this is a fraction relating ground/body and should be less than 1

  "brakeLatencyFit"    => [ 0.0, 0.74285, 0.0, 0.7419 ],
  "throttleLatencyFit" => [ 0.0, 0.81721, 0.0, 1.2056 ],
  "steerLatencyFit"    => [ 0.0, 0.99000, 0.0, 0.9900 ],   #Also need to change pathtracker latency 

  #The following are the parameters for base machine parameters
  #The following is a nonlinear map:
  #    baseMachineCurvCommandToStateValueMap        x: fabs(angle_cmd) y: fabs(vel_state)  = z: resultant desired_angle_state 
  "useBaseMachineParameters" => false,                   # Set to true to use the base machine conversion, false to use kinematic conversions
  "baseMachineParameters" => [1.24, 1.28, 32000, 100],   # [ GainUnloaded | GainLoaded | curvatureGain | steeringAngleGain]
  "baseMachineCurvCommandToStateValueMapName" => "/calibration/VehicleMapBaseMachineSteeringAngleValue_793SSP_v2_CommandToStateTable1.dat", # Command To State Slip Table conversion
  "baseMachineCurvCommandToStateValueMapMD5Sum" => "db81e8c72b95db9f3dc5ea449263b73e", # Table2: "daf7fe4208a3eaafa023e06a165428fc", # MD5 for this map
}


# If there's an auxiliary file, load it
if(FileTest.exists?(ENV["CAT_CONFIG_DIR"].to_s + "/Model_aux.rb"))
    puts "-----CONFIG: Updating Model_xx.rb with mods from Model_aux.rb"
    load "Model_aux.rb"
end
