require "commonLoad.rb"
# TimeSpoofSlave.rb
################################################
# In this configuration, the timeSync task will open the UDP port and query the master for 
# the latest Time model.
################################################

load "commonTaskParams.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
 "AutonomyConditionMessageOutput" => InterfaceDefs::AutonomyConditionMessageOutput,
  "TimeSyncStatisticsOutput" => InterfaceDefs::TimeSyncStatisticsOutput,
    "LoggerCommentsOutput" => InterfaceDefs::LoggerCommentsOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "warn",
  "cycleRate_hz" => 1,  # cycle every second
  "requireGPSTimeSynchronizationOnStart" => false, # ALLOW this process to start without synchronization

#Source of timesync
  "timeSyncSourceFromHardware" => false,  # Use software to obtain model
  "masterAddress" => IPAddressMap.fetch("auto5"), # Address for master time sync computer
  "timeSyncPort" => IPAddressMap.fetch("sanityTimeSyncPort"), # Time sync UDP port

#Service role for timesync
  "serviceRoleIsMaster" => false,    # no service role

} )

Execution = {
  "executableName" => "timeSyncObject",
}

