# C.Baker 06/28/11
#
# A simple logger that prints time, file and line with a message in a manner that is visually consistent with
# the C++ Logger class.
#
# Note: there is no trace level here as with the C++ logger, and instead of the trace level, this logger inserts
# " CONFIG"

module Logger

  def Logger.log(msg)
    now = Time.new
    tt = now.getutc
    puts tt.strftime("%m/%d/%Y %H:%M:%S") + (".%03d" % (tt.usec / 1000)) + " | CONFIG | #{caller(0)[1]} | " + msg
  end

end
