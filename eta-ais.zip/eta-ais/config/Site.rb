###################################################################
#
#  Site.rb : Read in the assigned site from site (copied from $HOME/etc/site)
# and load the associated Site_XX.rb configuration file.
#
#  Site specific information
#    - Position information
#    - Turn Signal
#    - Stopping Distance
#    - Minestar communication settings
#    - Directory containing default M* mwf files for the site
#    - Background maps for OCS
#    - Calibration Pole points
###################################################################
require "commonLoad.rb"
siteFile = ENV["CAT_CONFIG_DIR"].to_s + "/site"
puts "===== Site file " + siteFile
SiteFileAvailable = {
  "UseSiteFile" => false,
}

if (SiteFileAvailable["UseSiteFile"] == false)
   load "MineStar_Defaults.rb"
elsif(FileTest.exists?(siteFile))
    # Read in the robot type
    file = File.new(siteFile, "r")
    siteLocation = file.gets.chomp

    puts " site location is '" + siteLocation + "' without the quotes"
    tempFile = ENV["CAT_CONFIG_DIR"].to_s + "/Site_" + siteLocation + ".rb"
#   tempFile = "Site_" + siteLocation + ".rb"

    if(FileTest.exists?(tempFile))
        load tempFile
    else
        load "Site_Invalid.rb"
    end

else
  # Invalid!!!
  load "Site_Invalid.rb"
end

