# this is needed for Ruby 1.9.2 and later
d = "."
$LOAD_PATH.unshift(d) unless $LOAD_PATH.include?(d)

require "commonLoad.rb"
load "commonTaskParams.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
    "PcmStatusInput" => InterfaceDefs::PcmStatusInput,
    "PcmCommandOutput" => InterfaceDefs::PcmCommandOutput,
    "FileGlobOutput" => InterfaceDefs::ZFileGlobOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "requireGPSTimeSynchronizationOnStart" => false, # PCMRemote is not required to start synchronized
  "cycleRate_hz" => 10,
  "loggerThreshold" => "error",
  "statusTimeoutInSeconds" => 5.0,
  "configStagingDirectory" => "/tmp/stage",
### These following two options are mutually exclusive
  "tabComplete" => true, ## completes the line when you hit tab (as with a Linux terminal)
  "autoComplete" => false ## completes the line automatically
###
} )

#Execution = {
#  "executableName" => "pcm",
#}

