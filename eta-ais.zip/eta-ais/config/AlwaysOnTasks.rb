#alwaysOnTasks

require "etc"
require "socket"
print "LOADING ALWAYS ON TASK FILE!"

# Discover the proper ethernet interfaces for the autonomy and velodyne networks
# Use "intf" variables as an argument, discarding newline and set up scs networks
autonomyIntf=`/sbin/ifconfig | grep -B 1 '165.26.79' | grep Link |cut -f1 -d' '`
print "After ifconfig autoInf: '", autonomyIntf, "'\n"

if (autonomyIntf == "")
  autonomyIntf="eth0"
  print "using autonomyIntf default ", autonomyIntf, "\n"
end

# Default SCS parameters
scsParameters = ["--advertisedIntf="+autonomyIntf.chomp,"--socketPriority=3", "--unicastSubscription"]

# Get the Spoofed name if set
spoofHostname = CommonTaskParams::Parameters["spoofDnsName"];

# if hostname is "A6N2", we are likely on an ECM and require tcp option
# or if the spoofed hostname is "ocs", then we are probably want
# to talk to a robot and need the tcp option
if ( (Socket.gethostname == "A6N2") || (Socket.gethostname == "A5N2") || (spoofHostname == "ocs") ) 
    scsParameters = ["--advertisedIntf="+autonomyIntf.chomp,"--loggerThreshold=warn","--tcp", "--udpDiscoveryPort=49600","--staleFragmentPruningThreshold=1000000", "--unicastSubscription"]
end

# Do not use scs with tcp if running in simulation mode on a single PC
simulationMode=ENV['AHS_RUNNING_ON_SINGLE_PC']
if (simulationMode == "TRUE")
  scsParameters = ["--socketPriority=3", "--unicastSubscription"]
end


# DEFINE THE ALWAYS ON AUXILIARY PROCESSES!
AuxiliaryProcesses.update({

  "scs" => {
      "machines" => [ Machines::MachineMap["one"],
                      Machines::MachineMap["two"],
                      Machines::MachineMap["three"],
                      Machines::MachineMap["four"],
                      Machines::MachineMap["five"],
                      Machines::MachineMap["ocs"],
                    ],
      "arguments" => scsParameters,
      "executableName" => ENV['CAT_DIR'] + "/bin/scs",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => true,
  },

  # Run MachSerialNumTask on multiple machines
  "MachSerialNumTask" => {
     "machines" => [ Machines::MachineMap["one"],
                     Machines::MachineMap["two"],
                     Machines::MachineMap["three"],
                     Machines::MachineMap["four"],
                     Machines::MachineMap["five"],
                     Machines::MachineMap["ocs"],
                  ],
     "arguments" => ["--instanceName=MachSerialNumTask"],
     "executableName" => ENV['CAT_DIR'] + "/bin/machSerialNumTask",
     "autoRestart" => true,
     "timeBetweenRestarts_s" => 2,
     "alwaysOn" => true,
  },
  
  # Run SiteConfigServerTask on multiple machines
  #"SiteConfigServerTask" => {
  #    "machines" => [ Machines::MachineMap["one"],
  #                    Machines::MachineMap["two"],
  #                    Machines::MachineMap["three"],
  #                    Machines::MachineMap["four"],
  #                    Machines::MachineMap["five"],
  #                    Machines::MachineMap["ocs"],
  #                  ],
  #    "arguments" => ["--instanceName=SiteConfigServerTask"],
  #    "executableName" => ENV['CAT_DIR'] + "/bin/siteConfigServerTask",
  #    "autoRestart" => true,
  #    "timeBetweenRestarts_s" => 2,
  #    "alwaysOn" => false,
  #    "launchOnStartup" => true,
  #},


} )
