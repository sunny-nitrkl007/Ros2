require "commonLoad"
load "commonTaskParams.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
   "ExampleInput" => InterfaceDefs::ExampleInput,
   "ExampleInput2" => InterfaceDefs::ExampleInput2,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "cycleRate_hz" => 10,
  "loggerThreshold" => "notice", # "fatal", "error", "warn", "notice", "info", "debug",
  "Server_address" => "127.0.0.1:50051",
  "CDA_publish_freq" => 10,
} )

Execution = {
  "executableName" => "pseudoHealthTask",
}

