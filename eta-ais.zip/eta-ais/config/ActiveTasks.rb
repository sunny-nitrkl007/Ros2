require "commonLoad.rb"
load "Machines.rb"

###################################################################
# Production ActiveTasks.rb file:  Contains all of the processes
# that will run on the live AHS vehicle.
###################################################################

#The key is the task's instance name, the value is the machine that task should be run on
#Since each item refers to a unique instance of a task in the distributed system, only one
#machine can be specified per instance
SystemTasks = {

  # A6N2
  "ProductionLogger"              => Machines::MachineMap["one"],
  "SyslogBridgeAggregator"        => Machines::MachineMap["one"],
   #OCS
  "MachineOCS"                    => Machines::MachineMap["ocs"],
  "LogSnapshotBridge"             => Machines::MachineMap["ocs"],
}

#Processes to run that are not a 'Task'
#These may be specified to run on multiple machines
AuxiliaryProcesses = {

  # Run AllProcessMonitor on multiple machines
  #"AllProcessMonitor" => {
  #    "machines" => [ 
  #                    Machines::MachineMap["one"],
  #                    Machines::MachineMap["two"],                      
  #                    Machines::MachineMap["three"],
  #                    Machines::MachineMap["four"],
  #                    Machines::MachineMap["five"],
  #                  ],
  #    "arguments" => ["--instanceName=AllProcessMonitor"],
  #    "executableName" => ENV['CAT_DIR'] + "/bin/allProcessMonitor",
  #    "autoRestart" => true,
  #    "timeBetweenRestarts_s" => 2,
  #    "alwaysOn" => false,
  #},

  # Run SysLogBridge on multiple machines
  "SysLogBridge" => {
      "machines" => [ 
                      Machines::MachineMap["ocs"],
                      # SyslogBridgeAggregator will run on "one"
                    ],
      "arguments" => ["--instanceName=SyslogBridge"],
      "executableName" => ENV['CAT_DIR'] + "/bin/syslogBridge",
      "autoRestart" => true,
      "timeBetweenRestarts_s" => 2,
      "alwaysOn" => false,
  },

}

load "AlwaysOnTasks.rb"  # Must include this to add in scs and other always-on tasks


