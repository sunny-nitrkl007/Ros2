require "commonLoad.rb"
# TimeSyncLog.rb
################################################
# In this configuration, the timeSync task will 
# sync to VehicleState from a playing log
################################################


load "commonTaskParams.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
  "VehicleStateInput" => InterfaceDefs::VehicleStateInput,
  "AutonomyConditionMessageOutput" => InterfaceDefs::AutonomyConditionMessageOutput,
  "TimeSyncStatisticsOutput" => InterfaceDefs::TimeSyncStatisticsOutput,
  "LoggerCommentsOutput" => InterfaceDefs::LoggerCommentsOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "error",
  "cycleRate_hz" => 1,  # cycle every second
  "requireGPSTimeSynchronizationOnStart" => false, # ALLOW this process to start without synchronization

  
  "modelAccuracyThreshold_s" => 0.5, # allow 500ms since syncing from vehicleState kinda stinks
  
  #Source of timesync
  "timeSyncSourceFromLog" => true,

#Service role for timesync
  "serviceRoleIsMaster" => false,    # no service role to play

} )

Execution = {
  "executableName" => "timeSyncObject",
}
