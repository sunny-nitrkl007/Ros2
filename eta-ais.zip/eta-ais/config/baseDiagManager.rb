require "commonLoad.rb"
# baseDiagManager
load "commonAutonomyTask.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
  "DiagnosticStatusInput" => InterfaceDefs::DiagnosticStatusInput,
 "AllEventDiagOutput" => InterfaceDefs::EventDiagnosticDataOutput,
 "FMSActiveEventsOutput" => InterfaceDefs::FMSActiveEventsOutput,
 "FMSActiveDiagnosticsOutput" => InterfaceDefs::FMSActiveDiagnosticsOutput,
 "FMSLoggedEventsOutput" => InterfaceDefs::FMSLoggedEventsOutput,
 "FMSLoggedDiagnosticsOutput" => InterfaceDefs::FMSLoggedDiagnosticsOutput,
 "FMSBaseMachineActiveEventsOutput" => InterfaceDefs::FMSBaseMachineActiveEventsOutput,
 "FMSBaseMachineActiveDiagnosticsOutput" => InterfaceDefs::FMSBaseMachineActiveDiagnosticsOutput,
 "FMSBaseMachineLoggedEventsOutput" => InterfaceDefs::FMSBaseMachineLoggedEventsOutput,
 "FMSBaseMachineLoggedDiagnosticsOutput" => InterfaceDefs::FMSBaseMachineLoggedDiagnosticsOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "debug",
  "cycleRate_hz" => 4,
  "requireGPSTimeSynchronizationOnStart" => false,
  # CAN port assigned to Machine ECMs
  # Valid values:
  #     0 - can0 or CAN1 or CAN A
  #     1 - can1 or CAN2 or CAN B
  #     2 - can2 or CAN3 or CAN C
  #     3 - can3 or CAN4 or CAN D
  # 
  "CAN_port" => 0,
  
  "InactiveToActiveDebounce_s" => 2.5,
  "ActiveToInactiveDebounce_s" => 1.5,
} )

# See robot specific file:  baseDiagManager_<robot name>.rb
MachineECMsSetup = 
{
  "Total_ECMs"  => 2, #Valid between 0-10
}

MachineECMs = 
{
  "0" => 0x41, #A5N6
  "1" => 0x1C, #A STOP
}

Execution = {
  "executableName" => "baseDiagManager"
}

