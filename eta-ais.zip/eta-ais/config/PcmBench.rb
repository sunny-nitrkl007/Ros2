require "commonLoad.rb"
load "commonAutonomyTask.rb"
load "Machines.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
    "PcmStatusOutput" => InterfaceDefs::PcmStatusOutput,
    "PcmCommandInput" => InterfaceDefs::PcmCommandInput,
    "FileGlobInput"   => InterfaceDefs::FileGlobInput,
    "FileGlobSendOutFilesOutput"=> InterfaceDefs::FileGlobSendOutFilesOutput,
    "LogStopInput"    => InterfaceDefs::LogStopInput,
    "FileGlobOutput"   => InterfaceDefs::FileGlobOutput,
   "PcmCommandOutput" => InterfaceDefs::PcmCommandOutput,
    #master pcm
    "FileGlobSendOutFilesInput"=> InterfaceDefs::FileGlobSendOutFilesInput,
    "LoggerStatusInput"=> InterfaceDefs::LoggerStatusInput,
    "LogStopInput"     => InterfaceDefs::LogStopInput,
    "ProcessHealthInput" => InterfaceDefs::ProcessHealthInput,
    "SystemHardwareHealthRequestInput" => InterfaceDefs::SystemHardwareHealthRequestInput,
    "SystemHardwareHealthOutput" => InterfaceDefs::SystemHardwareHealthOutput,
} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "requireGPSTimeSynchronizationOnStart" =>false, # PCM is not required to start synchronized
  "cycleRate_hz" => 1,
  "loggerThreshold" => "notice",
  "workingDirectory" => ENV[ 'HOME' ] + "/tmp/outputFiles",
  "maxRestarts" => 0,  # NEVER RESTART
  "waitBeforeKill_s" => 3,

  "checkHardwareHealthTime_sec" => 60, # how often to check system hardware health
  "checkProcessInfo_sec" => 30, # how often to check process health ~30seconds
  "diskSpaceRemainingThreshold_percentage" => 5.0, # threshold before throwing OCS error on remaining disk space
  "diskSpaceCheckLocation" => ENV[ 'HOME' ], # Location to check for remaining disk space
  "stalledProcessTimer_s" => 5.0,  # Number of seconds to wait before declaring a process as "stalled"
  "lowMemoryThreshold" => 0.10,  # Ratio of available memory at which the low memory autonomy condition is triggered. 0.10 = 10%
} )

