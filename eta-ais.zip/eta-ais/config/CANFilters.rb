###############################################################################
## CAN Message filter for reception                                          ##
## This is an acceptance filter. If CAN IDs not specified in the list        ##
## CAN messages will not be received. You can provide the list in            ## 
## range (From ID, To ID). To accept sigle ID, keep From and To IDs same     ##
##                                                                           ##
## Notes:-                                                                   ##
## 1) Ensure difference between From and To IDs not exceeding 0xFF           ##
## 2) Ensure no overlaps or duplicate filters added. This will cause         ##
##    duplicate reception of IDs                                             ##
## 3) Provide single IDs, if ranges causing duplicate reception              ##
###############################################################################

GC.start # Updates freelist in ruby heap

CANFilters = {
"can0"=> [#From ID      To ID
         ],
"can1"=> [#From ID      To ID
         ],
"can2"=> [#From ID      To ID
           0x60,        0x188,
           0x400,       0x425,
           0x500,       0x500,
           0x600,       0x601,
           0x700,       0x700,
           0x10F01A00,  0x10F01A00,
           0x10FDA200,  0x10FDA200,
           0x1888821C,  0x1888821C,
           0x18DFFF47,  0x18DFFF47,
           0x18DFFF80,  0x18DFFF80,
           0x18E8FF81,  0x18E8FF81,
           0x18EA47FE,  0x18EA47FE,
           0x18EAFFFE,  0x18EAFFFE,
           0x18EB2581,  0x18EB2581,
           0x18EC2581,  0x18EC2581,
           0x18EEFF03,  0x18EEFF03,
           0x18EEFF0B,  0x18EEFF0B,
           0x18EEFF13,  0x18EEFF1C,
           0x18EEFF25,  0x18EEFF25,
           0x18EEFF47,  0x18EEFF47,
           0x18EEFF94,  0x18EEFF94,
           0x18EEFF80,  0x18EEFF81,
           0x18EEFFF9,  0x18EEFFFA,
           0x18EF0313,  0x18EF0313,
           0x18EF0325,  0x18EF0325,
           0x18EF0B25,  0x18EF0B25,
           0x18EF1303,  0x18EF1325,
           0x18EF2503,  0x18EF2503,
           0x18EF2513,  0x18EF2513,
           0x18EF2547,  0x18EF2547,
           0x18EF251C,  0x18EF251C,
           0x18EF2580,  0x18EF2581,
           0x18EF250B,  0x18EF250B,
           0x18EF4725,  0x18EF4725,
           0x18EFFA25,  0x18EFFA25,
           0x18F00203,  0x18F00203,
           0x18FD6694,  0x18FD6694,
           0x18FDAA00,  0x18FDAA00,
           0x18FE6A00,  0x18FE6A00,
           0x18FE9A00,  0x18FE9A00,
           0x18FECA94,  0x18FECA94,
           0x18FEDB00,  0x18FEDB00,
           0x18FEF200,  0x18FEF200,
           0x18FEF794,  0x18FEF794,
           0x1CEBFF82,  0x1CEBFF82,
           0x1CECFF82,  0x1CECFF82,
           0x0C01030B,  0x0C01030B,
           0x0C88FF82,  0x0C88FF82,
           0x0CEAFF1C,  0x0CEAFF1C,
           0x0CEFFF25,  0x0CEFFF25,
           0x0CFD5200,  0x0CFD5200,
           0x0CF00300,  0x0CF00300,
           0x0CF03080,  0x0CF03083,  #AStop Rx msg from 0x80, 0x81, 0x82, 0x83, priority 3
           0x18F03080,  0x18F03083,  #AStop Rx msg from 0x80, 0x81, 0x82, 0x83, priority 6
           0x0C88FF80,  0x0C88FF83,  #AStop Beacon Response from 0x80, 0x81, 0x82, 0x83, priority 3
           0x1888801C,  0x1888801C,  #AStop Beacon Request from MCM to 0x80
           0x1888811C,  0x1888811C,  #AStop Beacon Request from MCM to 0x81
           0x1888821C,  0x1888821C,  #AStop Beacon Request from MCM to 0x82
           0x1888831C,  0x1888831C,  #AStop Beacon Request from MCM to 0x83
           0x0CF004FE,  0x0CF004FE,  #EEC1 from Engine
           0x18FEF4FE,	0x18FEF4FE,  #TIRE from TyreSense
           ],
"can3"=> [#From ID      To ID
           0x21,        0x2F,
           0x428,       0x42E,
           0x415,       0x415,
           0x1888811C,  0x1888811C,
           0x1890FF1C,  0x1890FF1C,
           0x18D84733,  0x18D84733,
           0x18D93347,  0x18D93347,
           0x18EA8AFE,  0x18EA8AFE,
           0x18FCE28A,  0x18FCE28A,
           0x18FECA33,  0x18FECA33,
           0x18FEF433,  0x18FEF433,
           0x1CEB4733,  0x1CEB4733,
           0x1CEBFF33,  0x1CEBFF81,
           0x1CEC3347,  0x1CEC3347,
           0x1CEC4733,  0x1CEC4733,
           0x1CECFF33,  0x1CECFF81,
           0x02010051,  0x02010057,
           0x02020051,  0x02020057,
           0x0C88FF81,  0x0C88FF81,
           0x0CEAFF1C,  0x0CEAFF1C,
           0x0CF03080,  0x0CF03083,  #AStop Rx msg from 0x80, 0x81, 0x82, 0x83, priority 3
           0x18F03080,  0x18F03083,  #AStop Rx msg from 0x80, 0x81, 0x82, 0x83, priority 6
           0x0C88FF80,  0x0C88FF83,  #AStop Beacon Response from 0x80, 0x81, 0x82, 0x83, priority 3
           0x1888801C,  0x1888801C,  #AStop Beacon Request from MCM to 0x80
           0x1888811C,  0x1888811C,  #AStop Beacon Request from MCM to 0x81
           0x1888821C,  0x1888821C,  #AStop Beacon Request from MCM to 0x82
           0x1888831C,  0x1888831C,  #AStop Beacon Request from MCM to 0x83
           0x18F029E2,  0x18F029E2,  #AbsIMU
           0x18F02DE2,  0x18F02DE2,  #AbsIMU
           0x18F02AE2,  0x18F02AE2,  #AbsIMU
           0x0CF029E2,  0x0CF029E2,  #AbsIMU
           0x0CF02DE2,  0x0CF02DE2,  #AbsIMU
           0x0CF02AE2,  0x0CF02AE2,  #AbsIMU
           ],
         
  "can2ccp" => [#From ID      To ID
                0x2020024,0x2020024, #Engine DTO
                0x2020093,0x2020093, #Base DTO
                0x2020096,0x2020096, #Steer DTO
               ],

  "can3ccp" => [#From ID      To ID
                0x2020027,0x2020027, #MCM DTO
                0x2020057,0x2020057, #Chassis DTO
                0x2020074,0x2020074, #Brake DTO
                0x2020051,0x2020051, #Trans DTO
               ],

  "can2eddt" => [#From ID      To ID
                0x0CEAFF1C,0x0CEAFF1C, #Request2 from MCM to All
                0x0CEF411C,0x0CEF411C, #Request2 from MCM to AutoLayer
                0x0CEFFF1C,0x0CEFFF1C, #Proprietary PGN from MCM to ALL
                0x18EF411C,0x18EF411C, #Proprietary PGN from MCM to AutoLayer

                0x0CEAFF44,0x0CEAFF44, #Request2 from MCM Slave to All
                0x0CEF4144,0x0CEF4144, #Request2 from MCM Slave to AutoLayer
                0x0CEFFF44,0x0CEFFF44, #Proprietary PGN from MCM Slave to ALL
                0x18EF4144,0x18EF4144, #Proprietary PGN from MCM Slave to AutoLayer

                0x0CEAFF03,0x0CEAFF03, #Request2 from Transmission to All
                0x0CEF4103,0x0CEF4103, #Request2 from Transmission to AutoLayer
                0x0CEFFF03,0x0CEFFF03, #Proprietary PGN from Transmission to ALL
                0x18EF4103,0x18EF4103, #Proprietary PGN from Transmission to AutoLayer

                0x0CEAFF47,0x0CEAFF47, #Request2 from Chassis to All
                0x0CEF4147,0x0CEF4147, #Request2 from Chassis to AutoLayer
                0x0CEFFF47,0x0CEFFF47, #Proprietary PGN from Chassis to ALL
                0x18EF4147,0x18EF4147, #Proprietary PGN from Chassis to AutoLayer

                0x0CEAFF11,0x0CEAFF11, #Request2 from Brake to All
                0x0CEF4111,0x0CEF4111, #Request2 from Brake to AutoLayer
                0x0CEFFF11,0x0CEFFF11, #Proprietary PGN from Brake to ALL
                0x18EF4111,0x18EF4111, #Proprietary PGN from Brake to AutoLayer
                
                0x0CEAFF0B,0x0CEAFF0B, #Request2 from Brake (797) to All
                0x0CEF410B,0x0CEF410B, #Request2 from Brake (797) to AutoLayer
                0x0CEFFF0B,0x0CEFFF0B, #Proprietary PGN from Brake (797) to ALL
                0x18EF410B,0x18EF410B, #Proprietary PGN from Brake (797) to AutoLayer

                0x0CEAFF13,0x0CEAFF13, #Request2 from Steering to All
                0x0CEF4113,0x0CEF4113, #Request2 from Steering to AutoLayer
                0x0CEFFF13,0x0CEFFF13, #Proprietary PGN from Steering to ALL
                0x18EF4113,0x18EF4113, #Proprietary PGN from Steering to AutoLayer


                0x0CEAFF25,0x0CEAFF25, #Request2 from vims main to All
                0x0CEF4125,0x0CEF4125, #Request2 from vims main to AutoLayer
                0x0CEFFF25,0x0CEFFF25, #Proprietary PGN from vims main to ALL
                0x18EF4125,0x18EF4125, #Proprietary PGN from vims main to AutoLayer
                0x18EEFF25,0x18EEFF25, #vims main to address claim response to auto2 pgn request


                0x0CEAFF80,0x0CEAFF80, #Request2 from vims app to All
                0x0CEF4180,0x0CEF4180, #Request2 from vims app to AutoLayer
                0x0CEFFF80,0x0CEFFF80, #Proprietary PGN from vims app to ALL
                0x18EF4180,0x18EF4180, #Proprietary PGN from vims app to AutoLayer
                0x18EEFF80,0x18EEFF80, #vims app to address claim response to auto2 pgn request

                0x0CEAFF81,0x0CEAFF81, #Request2 from vims extra to All
                0x0CEF4181,0x0CEF4181, #Request2 from vims extra to AutoLayer
                0x0CEFFF81,0x0CEFFF81, #Proprietary PGN from vims extra to ALL
                0x18EF4181,0x18EF4181, #Proprietary PGN from vims extra to AutoLayer
                0x18EEFF81,0x18EEFF81, #vims extra to address claim response to auto2 pgn request

                0x0CEAFF82,0x0CEAFF82, #Request2 from vims extra to All
                0x0CEF4182,0x0CEF4182, #Request2 from vims extra to AutoLayer
                0x0CEFFF82,0x0CEFFF82, #Proprietary PGN from vims extra to ALL
                0x18EF4182,0x18EF4182, #Proprietary PGN from vims extra to AutoLayer
                0x18EEFF82,0x18EEFF82, #vims extra to address claim response to auto2 pgn request

                0x0CEAFF83,0x0CEAFF83, #Request2 from vims extra to All
                0x0CEF4183,0x0CEF4183, #Request2 from vims extra to AutoLayer
                0x0CEFFF83,0x0CEFFF83, #Proprietary PGN from vims extra to ALL
                0x18EF4183,0x18EF4183, #Proprietary PGN from vims extra to AutoLayer
                0x18EEFF83,0x18EEFF83, #vims extra to address claim response to auto2 pgn request

                0x0CEAFF84,0x0CEAFF84, #Request2 from vims extra to All
                0x0CEF4184,0x0CEF4184, #Request2 from vims extra to AutoLayer
                0x0CEFFF84,0x0CEFFF84, #Proprietary PGN from vims extra to ALL
                0x18EF4184,0x18EF4184, #Proprietary PGN from vims extra to AutoLayer
                0x18EEFF84,0x18EEFF84, #vims extra to address claim response to auto2 pgn request

                0x0CEAFF85,0x0CEAFF85, #Request2 from vims extra to All
                0x0CEF4185,0x0CEF4185, #Request2 from vims extra to AutoLayer
                0x0CEFFF85,0x0CEFFF85, #Proprietary PGN from vims extra to ALL
                0x18EF4185,0x18EF4185, #Proprietary PGN from vims extra to AutoLayer
                0x18EEFF85,0x18EEFF85, #vims extra to address claim response to auto2 pgn request

                0x0CEAFF86,0x0CEAFF86, #Request2 from vims extra to All
                0x0CEF4186,0x0CEF4186, #Request2 from vims extra to AutoLayer
                0x0CEFFF86,0x0CEFFF86, #Proprietary PGN from vims extra to ALL
                0x18EF4186,0x18EF4186, #Proprietary PGN from vims extra to AutoLayer
                0x18EEFF86,0x18EEFF86, #vims extra to address claim response to auto2 pgn request




               ],
}

############# Example showing relationship between CANID and PGN ##############
##                                                                           ##
##    |<------------------------CAN ID (0x0CF004EE)------------------->|     ##
##    |----------------------------------------------------------------|     ##
##    |           0x0C              |    0xF0   |   0x04    |   0xEE   |     ##
##    |----------------------------------------------------------------|     ##
##    | 000  |   011    |  0  |  0  | 11110000  | 00000100  | 11101110 |     ##
##    |----------------------------------------------------------------|     ##
##    | ---  | Priority |  R  | DP  |    PF     |    PS     |    SA    |     ##
##    |----------------------------------------------------------------|     ##
##                      |<----------PGN (0x0F004)---------->|                ##
##                                                                           ##
## Priority(3 bits):                                                         ##
##    Defines Priority => 0-Highest, 7-Lowest                                ##
## R-Reserved(1 bit):                                                        ##
##    Reserved for Future use                                                ##
## DP-Data Page(1 bit):                                                      ##
##    Expands the No. of parameter groups that can be represented by the ID  ##
## PF-PDU Format(8 bits):                                                    ## 
##    Determines if the message is DEST Specific or a Broadcast Message      ##
##    -If the PF is between 0 and 239, the message is destination specific   ##
##      (PDU1) and the PS field contains the destination address.            ##
##    -If the PF is between 240 and 255, the message is a broadcast          ##
##      (PDU2) and the PS field contains a Group Extension.                  ##
##    -Group Extension expands the No. of possible Broadcast Parameter       ##
##      Groups represented by the ID.                                        ##
## PS-PDU Specific(8 bits)  :                                                ##
##    Destination Address / Group Extension                                  ##
## SA-Source Address(8 bits):                                                ##
##    Address of the transmitting device                                     ##
###############################################################################
