require "commonLoad.rb"
load "commonAutonomyTask.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update( {
    "MS990Input"                      => InterfaceDefs::MS990PoseInput,
    "BD950Input"                      => InterfaceDefs::BD950PositionInput,
    "RegulateSpeedInput"              => InterfaceDefs::RegulateSpeedInput,
    "TMACServerInput"                 => InterfaceDefs::TMACServerInput,
    "TMACClientOutput"                => InterfaceDefs::TMACClientOutput,
    "MCMStatusInput" 	              => InterfaceDefs::MCMStatusInput,
    "GPSTimeOutput"                   => InterfaceDefs::GPSTimeOutput,
    "VehicleStateOutput"              => InterfaceDefs::VehicleStateOutput,
    "MCMVehicleCommandOutput"         => InterfaceDefs::MCMVehicleCommandOutput,
    "MCMOfficeCommandOutput"          => InterfaceDefs::MCMOfficeCommandOutput,
    "MCMBodyCommandOutput"            => InterfaceDefs::MCMBodyCommandOutput,
    "MCMStatusInput"                  => InterfaceDefs::MCMStatusInput,
    "MCMStatusOutput"                 => InterfaceDefs::MCMStatusOutput,
    "SubSystemHealthInput"            => InterfaceDefs::SubSystemHealthInput,
    "SubSystemHealthOutput"           => InterfaceDefs::SubSystemHealthOutput,
    "SubSystemRecommendedActionInput" => InterfaceDefs::SubSystemRecommendedActionInput,
    "SubSystemRecommendedActionOutput" => InterfaceDefs::SubSystemRecommendedActionOutput,
    "VelodynePacketGroupOutput"       => InterfaceDefs::VelodynePacketGroupOutput,
    "MCMAStopStatusInput"             => InterfaceDefs::MCMAStopStatusInput,
    "MCMAStopStatusOutput"            => InterfaceDefs::MCMAStopStatusOutput,
    "BD950Position1Output"            => InterfaceDefs::BD950Position1Output,
    "BD950Position2Output"            => InterfaceDefs::BD950Position2Output,
    "BD950Position3Output"            => InterfaceDefs::BD950Position3Output,
    "ApplanixStateOutput"             => InterfaceDefs::ApplanixStateOutput,
    "OBIStatusOutput"                 => InterfaceDefs::OBIStatusOutput,
    "MachineStateInput"               => InterfaceDefs::MachineStateInput,
    "MachineStateOutput"              => InterfaceDefs::MachineStateOutput,
    "ApplanixStateInput"              => InterfaceDefs::ApplanixStateInput,
    "ApplanixStateOutput"             => InterfaceDefs::ApplanixStateOutput,
    "PathTrackerPathOutput"           => InterfaceDefs::PathTrackerPathOutput,
    "GenericDebug1Input"              => InterfaceDefs::GenericDebug1Input,
    "GenericDebug1Output"             => InterfaceDefs::GenericDebug1Output,
    "GenericDebug2Input"              => InterfaceDefs::GenericDebug2Input,
    "GenericDebug2Output"             => InterfaceDefs::GenericDebug2Output,
    "PathTrackerFeedbackInputPri"     => InterfaceDefs::PathTrackerFeedbackInputPri,
    "PathTrackerFeedbackOutputPri"    => InterfaceDefs::PathTrackerFeedbackOutputPri,
    "PathTrackerFeedbackInputSec"     => InterfaceDefs::PathTrackerFeedbackInputSec,
    "PathTrackerFeedbackOutputSec"    => InterfaceDefs::PathTrackerFeedbackOutputSec,
    "MCIVehicleCommandInput"          => InterfaceDefs::MCIVehicleCommandInput,
    "SystemHardwareHealthInput"       => InterfaceDefs::SystemHardwareHealthInput,
    "ShutdownStateInput"              => InterfaceDefs::ShutdownStateInput,
    "ApplanixAmtOpModeCommandOutput"  => InterfaceDefs::ApplanixAmtOpModeCommandOutput, 
    "MCIVehicleCommandOutput"         => InterfaceDefs::MCIVehicleCommandOutput,
    "SecondaryBrakeRequestOutput"     => InterfaceDefs::SecondaryBrakeRequestOutput,
    "NetworkReportInput"	      => InterfaceDefs::NetworkReportInput,
    "NetworkReportOutput"             => InterfaceDefs::NetworkReportOutput,
#    "AutonomousCabinetCoolingParametersInput" => InterfaceDefs::AutonomousCabinetCoolingParametersInput,
#    "AutonomousCabinetCoolingParametersOutput" => InterfaceDefs::AutonomousCabinetCoolingParametersOutput,

} )

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "fatal",
  "cycleRate_hz" => 1,
  "requireGPSTimeSynchronizationOnStart" => false,
} )

#
# Subsystem Health Data
#
# To simulate a DSI, use 0xE1.
#
SubSystemHealthData = {
   "setPrimaryBrakeRecmdAction"        => 0,    # ID = 0x0000
   "setSecondaryBrakeRecmdAction"      => 0,    # ID = 0x0001
   "setBrakeChargingRecmdAction"       => 0,    # ID = 0x0002
   "setMachineCoolingRecmdAction"      => 0,    # ID = 0x0003
   "setRearAxleRecmdAction"            => 0,    # ID = 0x0004
   "setHoistRecmdAction"               => 0,    # ID = 0x0005
   "setTireMonitorRecmdAction"         => 0,    # ID = 0x0006
   "setSteeringChargingRecmdAction"    => 0,    # ID = 0x0007
   "setPrimarySteeringRecmdAction"     => 0,    # ID = 0x0008
   "setSecondarySteeringRecmdAction"   => 0,    # ID = 0x0009
   "setPrimaryPowerTrainRecmdAction"   => 0,    # ID = 0x000A
   "setSecondaryPowerTrainRecmdAction" => 0,    # ID = 0x000B
   "setPrimaryEngineRecmdAction"       => 0,    # ID = 0x000C
   "setSecondaryEngineRecmdAction"     => 0,    # ID = 0x000D
   "setAutoLubeRecmdAction"            => 0xE1,    # ID = 0x000E
   "setPayloadRecmdAction"             => 0,    # ID = 0x000F
   "setMachineCtrlRecmdAction"         => 0,    # ID = 0x0012
   "setAstopRecmdAction"               => 4,    # ID = 0x0014
   "setObjectDetectRecmdAction"        => 0,    # ID = 0x0010 
   "setPositioningRecmdAction"         => 3,    # ID = 0x0011 
   "setOffboardCommRecmdAction"        => 3,    # ID = 0x0013 
   "setPlanningRecmdAction"            => 3,    # ID = 0x0015 
   "setOnboardCommRecmdAction"         => 0,    # ID = 0x0016 
   "setElectRecmdAction"               => 3,    # ID = 0x0017
}

MachineAstopTxData = {
   "num_tx" => 0,
   "id"     => 0x33,
   "status" => 1,
}


MachineStateTxData = {
   "loadState"    => 1,
   "loadPercent"  => 33,
}


MCMStatusTxData = {
    "OBILoadStatus"  => 1,  # 1 = unloaded, 2 = loaded, 0 = Unknown
    "PayloadWeight"  => 150,
    "BodyPosition"   => 0.00,
    "absStatus"      => 1, # 0 = Inactive, 1 = Active, 255 = Unknown
    "tcsStatus"      => 0, # 0 = Inactive, 1 = Active, 255 = Unknown
    "msn"            => "DEF12345",
}

ApplanixHealthData = {
    "INNSolMode"  => 0,
     "Pose.x" =>1.0,
     "Pose.y" =>2.0,
     "Pose.z" =>3.0,
     "Pose.roll" => 4.0,
     "Pose.pitch" => 5.0,
     "Pose.yaw" =>6.0,
     "PoseSTD.x" =>11.0,
     "PoseSTD.y" =>12.0,
     "PoseSTD.z" =>13.0,
     "PoseSTD.roll" => 14.0,
     "PoseSTD.pitch" => 15.0,
     "PoseSTD.yaw" =>16.0,
     "Acceleration.x" => 21.0,
     "Acceleration.y" => 22.0,
     "Acceleration.z" => 23.0,
     "Velocity.x"  => 31.0,
     "Velocity.y" => 32.0,
     "Velocity.z" => 33.0,
     "VelocitySTD.x"  => 41.0,
     "VelocitySTD.y" => 42.0,
     "VelocitySTD.z" => 43.0,
     "WheelSpeed" => 99.0,
     "TimeStamp" => 1.0,
     "UtmPlane" => 100,
     "NavMode" => 2
}


VehicleStateData = {
    "roll"   => 5.0,
    "pitch"  => 5.0,
}


Execution = {
  "executableName" => "inputOutputSimulator",
}
