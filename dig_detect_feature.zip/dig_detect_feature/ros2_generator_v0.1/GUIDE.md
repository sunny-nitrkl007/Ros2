# Guide.md

# ros2_generator Demo Testing From Scratch

## 1. Purpose

This document explains how to test the three demo applications from a fresh pull of the branch using Docker Jazzy deployment.

The three demo applications are:

```text
01_demo_simple_pubsub
02_demo_mesh_app
03_demo_advanced_automotive_app
```

The goal is to prove that `ros2_generator` can generate buildable ROS 2 workspaces and Docker deployment assets for:

```text
1. Basic pub/sub communication
2. Multi-application mesh communication
3. Advanced automotive-style boilerplate with topics, services, clients, parameters, and QoS
```

All tests in this document use Docker with:

```text
ROS_DISTRO=jazzy
```

Make sure to validate examples via pydantic module.

---

## 2. High-Level Demo Coverage

## 2.1 Demo 01: Simple Pub/Sub

Purpose:

```text
Minimal generated ROS 2 system.
Publisher and subscriber are in different applications.
No services.
No discovery server.
Runs on Docker Jazzy.
```

Applications:

```text
simple_talker_app
simple_listener_app
```

Main topic:

```text
/demo/simple_status
```

Features demonstrated:

```text
generated message
generated publisher
generated subscriber
generated parameters
Docker deployment
Docker Jazzy base image
```

---

## 2.2 Demo 02: Mesh App

Purpose:

```text
Known-good multi-application mesh example.
Uses discovery server.
Demonstrates topics and services across multiple generated applications.
Runs on Docker Jazzy.
```

Applications:

```text
perception_system
planning_system
safety_system
```

Core topics:

```text
/perception/obstacle_data
/planning/trajectory
/safety/emergency_brake
```

Core services:

```text
/perception/get_lane_info
/planning/request_path_update
/safety/check_risk
```

Features demonstrated:

```text
generated messages
generated services
generated publishers
generated subscribers
generated service servers
generated service clients
generated parameters
generated QoS usage
FastDDS discovery server
Docker deployment
Docker Jazzy base image
```

---

## 2.3 Demo 03: Advanced Automotive App

Purpose:

```text
Feature-rich automotive-style generated system.
Five generated applications.
Twenty-five generated topics.
Eight generated services.
No discovery server.
Runs on Docker Jazzy.
```

Applications:

```text
perception_app
localization_app
planning_app
control_app
safety_app
```

Important topics:

```text
/perception/detected_objects
/localization/pose
/planning/trajectory
/control/command
/safety/emergency_brake
```

Important services:

```text
/perception/get_object_details
/perception/reset
/localization/get_status
/planning/request_replan
/control/set_mode
/control/reset_controller
/safety/check_risk
/safety/clear_emergency
```

Features demonstrated:

```text
generated interfaces
generated publishers
generated subscribers
generated services
generated service servers
generated service clients
generated parameters
generated QoS profiles
Docker deployment
Docker Jazzy base image
larger automotive-style architecture
```

---

## 3. Prerequisites

## 3.1 Required Tools

The machine should have:

```text
Python 3
Docker
Docker Compose plugin
Internet access for first Docker image pull
```

Local ROS 2 installation is not required for the Docker runtime demo, because Docker uses the ROS image.

---

## 3.2 Docker Permission Setup

Check Docker:

```bash
docker ps
```

If Docker requires sudo, the generated scripts can use `sudo docker`. For smoother demo experience, add the user to the Docker group:

```bash
sudo usermod -aG docker $USER
newgrp docker
docker ps
```

If this still asks for sudo, log out and log back in, or reboot.

---

## 3.3 Tool root location

Go to the generator root:

```bash
cd ~/ros2_generator_v0.1
```

Verify examples exist:

```bash
ls examples
```

Expected examples:

```text
01_demo_simple_pubsub
02_demo_mesh_app
03_demo_advanced_automotive_app
```

---

## 4. Global Internal Validation Before Docker Testing

Run this before testing Docker:

```bash
for ex in 01_demo_simple_pubsub 02_demo_mesh_app 03_demo_advanced_automotive_app; do
  echo ""
  echo "================================================================================"
  echo "[VALIDATE] examples/$ex"
  echo "================================================================================"
  python3 -m generator.main inspect "examples/$ex"
  python3 -m generator.main validate "examples/$ex"
done
```

Expected result:

```text
[OK] Validation passed for: examples/01_demo_simple_pubsub
[OK] Validation passed for: examples/02_demo_mesh_app
[OK] Validation passed for: examples/03_demo_advanced_automotive_app
```

Warnings are acceptable if validation passes.

---

## 5. Important Docker Compose Check

For every generated Docker app, ensure `docker-compose.yml` contains a `build:` section.

This prevents Docker from trying to pull a generated image from Docker Hub.

Expected compose pattern:

```yaml
image: <example>_generated_ws:latest
build:
  context: ..
  dockerfile: docker_deployment/Dockerfile
  args:
    ROS_DISTRO: jazzy
```

Check with:

```bash
grep -n "image:" docker-compose.yml
grep -n "build:" docker-compose.yml
grep -n "dockerfile:" docker-compose.yml
grep -n "ROS_DISTRO" docker-compose.yml
```

Expected:

```text
image lines exist
build lines exist
dockerfile: docker_deployment/Dockerfile exists
ROS_DISTRO: jazzy exists
```

---


# 6. Demo 02: Mesh App Test

## 6.1 Generate Docker Jazzy Deployment

From `ros2_generator_v0.1` root:

```bash
cd ~/ros2_generator_v0.1

rm -rf output/demo_mesh_app

python3 -m generator.main generate \
  examples/02_demo_mesh_app \
  output/demo_mesh_app \
  --docker-dep \
  --ros-distro jazzy
```

---

## 6.2 Verify Docker Compose

```bash
cd output/demo_mesh_app/generated_ws/docker_deployment

grep -n "image:" docker-compose.yml
grep -n "build:" docker-compose.yml
grep -n "dockerfile:" docker-compose.yml
grep -n "ROS_DISTRO" docker-compose.yml
grep -n "discovery_server" docker-compose.yml
```

Expected:

```text
build section exists
ROS_DISTRO: jazzy exists
discovery_server exists
```

---

## 6.3 Clean Old Containers And Image

Check image name:

```bash
grep -n "image:" docker-compose.yml
```

Likely image:

```text
02_demo_mesh_app_generated_ws:latest
```

Clean:

```bash
./scripts/docker_down.sh || true

sudo docker ps -aq --filter ancestor=02_demo_mesh_app_generated_ws:latest | xargs -r sudo docker rm -f

sudo docker image rm -f 02_demo_mesh_app_generated_ws:latest || true
```

---

## 6.4 Build And Launch

```bash
FORCE_DOCKER_BUILD=1 ./scripts/docker_launch_ecu_terminals.sh
```

Expected terminal windows:

```text
discovery_server
perception_system
planning_system
safety_system
```

Expected runtime logs:

```text
DEMO NODE STARTED
DEMO PUBLISHER CREATED
DEMO SUBSCRIBER CREATED
DEMO SERVICE SERVER CREATED
DEMO SERVICE CLIENT CREATED
DEMO PUBLISH
DEMO SUBSCRIBE
```

---

## 6.5 Open Inspector

```bash
./scripts/docker_exec_shell.sh inspector
```

Inside inspector:

```bash
ros2 node list
ros2 topic list
ros2 service list
```

Expected nodes include perception/planning/safety nodes.

Expected topics:

```text
/perception/obstacle_data
/planning/trajectory
/safety/emergency_brake
```

Expected services:

```text
/perception/get_lane_info
/planning/request_path_update
/safety/check_risk
```

---

## 6.6 Test Topics

Inside inspector:

```bash
ros2 topic echo /perception/obstacle_data --once
ros2 topic echo /planning/trajectory --once
ros2 topic echo /safety/emergency_brake --once
```

Expected:

```text
Messages are printed for each topic.
```

---

## 6.7 Availabitily of Service 

List services:

```bash
ros2 service list
```

---

## 6.8 Test Parameters

List nodes:

```bash
ros2 node list
```

Example parameter checks:

```bash
ros2 param list /perception1_node
ros2 param get /perception1_node sensor_update_rate_hz
ros2 param set /perception1_node sensor_update_rate_hz 15.0
ros2 param get /perception1_node sensor_update_rate_hz
```

Planning parameter:

```bash
ros2 param list /planning1_node
ros2 param get /planning1_node planning_rate_hz
ros2 param set /planning1_node planning_rate_hz 8.0
ros2 param get /planning1_node planning_rate_hz
```

If node names differ, use the exact names from:

```bash
ros2 node list
```

---

## 6.9 Stop Mesh Demo

Exit inspector:

```bash
exit
```

Stop containers:

```bash
./scripts/docker_down.sh
```

---

# 7. Testing Details

## 7.1 Commands Used To Prove Features

Topic feature:

```bash
ros2 topic list
ros2 topic echo <topic> --once
```

Service feature:

```bash
ros2 service list
ros2 service type <service>
ros2 interface show <service_type>
```

Parameter feature:

```bash
ros2 param list <node>
ros2 param get <node> <parameter>
ros2 param set <node> <parameter> <value>
```

---

# 8. Important Demo Explanation Notes

## 8.1 What Is Real

The generator creates real ROS 2 artifacts:

```text
packages
CMakeLists.txt
package.xml
.msg files
.srv files
publishers
subscribers
service servers
service clients
parameters
QoS references
Dockerfile
docker-compose.yml
runtime scripts
```

## 8.2 What Is Demo/Sample Behavior

The generated runtime behavior is demo/sample behavior:

```text
sample published messages
basic subscriber callbacks
sample service responses
basic service client wiring
parameter declaration and exposure
```

## 8.3 What Production Teams Add Later

Application teams add domain logic:

```text
real perception algorithm
real localization algorithm
real planner
real controller
real safety decision logic
custom parameter validation
custom service response logic
production diagnostics
production deployment hardening
```

---
