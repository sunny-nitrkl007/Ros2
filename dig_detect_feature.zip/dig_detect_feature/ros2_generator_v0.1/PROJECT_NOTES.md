# Project Notes

## Current Strategy

The tool is intended to behave as a grammar-driven ROS2 application compiler.
The developer describes what the application is; shchema validator validates the examples; the generator produces infrastructure; the developer
adds business logic in designated regions.

## Current V1 Scope

- Yaml based rammar input
- Pydantic validation
- Custom `.msg` generation
- Custom `.srv` generation
- Publisher boilerplate
- Subscriber boilerplate
- Service server boilerplate
- Service client boilerplate
- Parameters
- QoS mapping
- Discovery-server config 
- Launch/build/config/test/report scaffolding

## Deferred Features

- Grammar-controlled callbacks
- Actions
- Lifecycle nodes
- Components
- Hardware topology deployment
- ECU flashing/deployment manifests
- Runtime supervision and diagnostics


## While changing distros

In case you builded default and tested it in docker, it will have humble and you decide
to switch then after rebuild docker image might be still there so it is essential to do below steps

cd output/mesh_app_jazzy/generated_ws/docker_deployment

docker compose down --remove-orphans || true
docker image rm <name of generated image>
docker image rm 01_demo_simple_pubsub_generated_ws:latest || true

FORCE_DOCKER_BUILD=1 ./scripts/docker_launch_ecu_terminals.sh