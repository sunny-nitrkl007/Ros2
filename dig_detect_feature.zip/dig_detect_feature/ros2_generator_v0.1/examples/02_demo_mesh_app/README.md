# 01_demo_simple_pubsub

This example contains the finalized grammar sample structure.

## Important V1 Note

The V1 generator will consume only the `general/` grammar for ROS2 boilerplate generation.
The `ecus/` and `topology/` folders are retained for folder completeness and future deployment-aware generation.
