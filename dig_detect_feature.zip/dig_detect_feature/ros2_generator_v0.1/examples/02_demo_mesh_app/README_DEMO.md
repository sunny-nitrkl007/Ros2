# 02 Demo Mesh App

Intent:
- existing known-good mesh example
- discovery server enabled
- perception/planning/safety split
- pub/sub and service interactions
