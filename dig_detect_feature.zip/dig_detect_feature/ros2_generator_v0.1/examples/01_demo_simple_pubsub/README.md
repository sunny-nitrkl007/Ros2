# 01 Demo Simple Pub/Sub

Minimal finalized YAML grammar example.

Intent:
- two applications
- publisher and subscriber are in different apps
- one custom topic
- no service server
- no service client
- no discovery server
