# 03 Demo Advanced Automotive App

Advanced automotive-style finalized YAML grammar.

Intent:
- 5 applications
- 5 main nodes
- 25 topics
- service servers and clients
- parameters
- QoS profiles
- no discovery server
