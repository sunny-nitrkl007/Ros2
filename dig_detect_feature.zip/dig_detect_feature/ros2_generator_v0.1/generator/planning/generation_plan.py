"""Generation plan paths.

This module keeps the historical PackagePlan shape used by existing generators while adding
custom output path behavior.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict

from generator.ir.models import WorkspaceIR


@dataclass(frozen=True)
class PackagePlan:
    """Planned package location relative to generated_ws/src."""

    name: str
    relative_path: Path
    package_root: Path

    # Compatibility aliases for any older/newer generator code.
    @property
    def path(self) -> Path:
        return self.package_root

    @property
    def root(self) -> Path:
        return self.package_root

    @property
    def absolute_path(self) -> Path:
        return self.package_root


@dataclass(frozen=True)
class GenerationPlan:
    """Filesystem layout for one generated ROS 2 workspace."""

    output_root: Path
    workspace_root: Path
    src_root: Path

    interface_package: PackagePlan
    bringup_package: PackagePlan
    application_packages: Dict[str, PackagePlan]

    test_root: Path
    local_deployment_root: Path
    docker_deployment_root: Path


def _resolve_output_root(ir: WorkspaceIR, output_dir: Path) -> Path:
    """Resolve output root.

    Backward-compatible default:
      output -> output/<example_name>

    Custom app output:
      output/mesh_app -> output/mesh_app
      /tmp/mesh_app   -> /tmp/mesh_app
    """
    output_dir = Path(output_dir)
    if output_dir.name == "output":
        return output_dir / ir.example_name
    return output_dir


def _pkg(src_root: Path, name: str) -> PackagePlan:
    relative_path = Path(name)
    return PackagePlan(
        name=name,
        relative_path=relative_path,
        package_root=src_root / relative_path,
    )


def build_generation_plan(ir: WorkspaceIR, output_dir: Path) -> GenerationPlan:
    output_root = _resolve_output_root(ir, output_dir)
    workspace_root = output_root / "generated_ws"
    src_root = workspace_root / "src"

    return GenerationPlan(
        output_root=output_root,
        workspace_root=workspace_root,
        src_root=src_root,
        interface_package=_pkg(src_root, "generated_interfaces"),
        bringup_package=_pkg(src_root, "generated_bringup"),
        application_packages={name: _pkg(src_root, name) for name in ir.applications.keys()},
        test_root=workspace_root / "test",
        local_deployment_root=workspace_root / "local_deployment",
        docker_deployment_root=workspace_root / "docker_deployment",
    )
