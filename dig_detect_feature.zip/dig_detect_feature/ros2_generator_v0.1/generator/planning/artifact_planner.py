"""
Artifact planner.

Purpose:
    Computes artifact names, C++ types, and include paths generated from IR models.
"""

from __future__ import annotations

from generator.ir.models import WorkspaceIR
from generator.utils.string_case import camel_to_snake, snake_to_camel


# --------------------------------------------------------------------------------------------------
# topic_msg_name
# --------------------------------------------------------------------------------------------------
# Converts a grammar topic name into a ROS2 message file/class name.
# Example: obstacle_data -> ObstacleData.
# --------------------------------------------------------------------------------------------------
def topic_msg_name(topic_name: str) -> str:
    """Return ROS2 message name for a topic."""
    # Convert finalized grammar snake_case topic name into PascalCase interface name.
    return snake_to_camel(topic_name)


# --------------------------------------------------------------------------------------------------
# service_srv_name
# --------------------------------------------------------------------------------------------------
# Converts a grammar service name into a ROS2 service file/class name.
# Example: get_lane_info -> GetLaneInfo.
# --------------------------------------------------------------------------------------------------
def service_srv_name(service_name: str) -> str:
    """Return ROS2 service name for a service."""
    # Convert finalized grammar snake_case service name into PascalCase interface name.
    return snake_to_camel(service_name)


# --------------------------------------------------------------------------------------------------
# topic_cpp_type
# --------------------------------------------------------------------------------------------------
# Returns the generated C++ type for a topic message.
# Example: obstacle_data -> generated_interfaces::msg::ObstacleData.
# --------------------------------------------------------------------------------------------------
def topic_cpp_type(topic_name: str) -> str:
    """Return generated C++ message type for a topic."""
    # Compose generated interface namespace and message class name.
    return f"generated_interfaces::msg::{topic_msg_name(topic_name)}"


# --------------------------------------------------------------------------------------------------
# service_cpp_type
# --------------------------------------------------------------------------------------------------
# Returns the generated C++ type for a service.
# Example: get_lane_info -> generated_interfaces::srv::GetLaneInfo.
# --------------------------------------------------------------------------------------------------
def service_cpp_type(service_name: str) -> str:
    """Return generated C++ service type for a service."""
    # Compose generated interface namespace and service class name.
    return f"generated_interfaces::srv::{service_srv_name(service_name)}"


# --------------------------------------------------------------------------------------------------
# topic_include_path
# --------------------------------------------------------------------------------------------------
# Returns C++ include path for generated topic message.
# Example: obstacle_data -> generated_interfaces/msg/obstacle_data.hpp.
# --------------------------------------------------------------------------------------------------
def topic_include_path(topic_name: str) -> str:
    """Return generated C++ include path for a topic message."""
    # ROS2 generated headers use snake_case file names.
    return f"generated_interfaces/msg/{camel_to_snake(topic_msg_name(topic_name))}.hpp"


# --------------------------------------------------------------------------------------------------
# service_include_path
# --------------------------------------------------------------------------------------------------
# Returns C++ include path for generated service.
# Example: get_lane_info -> generated_interfaces/srv/get_lane_info.hpp.
# --------------------------------------------------------------------------------------------------
def service_include_path(service_name: str) -> str:
    """Return generated C++ include path for a service."""
    # ROS2 generated service headers use snake_case file names.
    return f"generated_interfaces/srv/{camel_to_snake(service_srv_name(service_name))}.hpp"


# --------------------------------------------------------------------------------------------------
# node_class_name
# --------------------------------------------------------------------------------------------------
# Returns generated C++ class name for a node.
# Example: perception1_node -> Perception1Node.
# --------------------------------------------------------------------------------------------------
def node_class_name(node_name: str) -> str:
    """Return generated C++ class name for a node."""
    # Convert node snake_case to CamelCase class name.
    return snake_to_camel(node_name)


# --------------------------------------------------------------------------------------------------
# planned_interface_files
# --------------------------------------------------------------------------------------------------
# Returns the expected interface files for reporting/tests.
# This function does not write files; it only plans their names.
# --------------------------------------------------------------------------------------------------
def planned_interface_files(ir: WorkspaceIR) -> list[str]:
    """Return planned interface file paths relative to generated_interfaces."""
    # Add one .msg per topic and one .srv per service.
    files = [f"msg/{topic_msg_name(name)}.msg" for name in sorted(ir.topics)]
    files.extend(f"srv/{service_srv_name(name)}.srv" for name in sorted(ir.services))
    return files
