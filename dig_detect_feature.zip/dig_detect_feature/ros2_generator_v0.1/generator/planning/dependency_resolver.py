"""
Dependency resolver.

Purpose:
    Infers package dependencies from the WorkspaceIR. This patch focuses on interface package
    dependencies. Node/package dependency resolution will expand in later patches.
"""

from __future__ import annotations

from generator.ir.models import WorkspaceIR


# --------------------------------------------------------------------------------------------------
# resolve_interface_dependencies
# --------------------------------------------------------------------------------------------------
# Resolves dependencies needed by generated_interfaces package.
# Current finalized grammar uses primitive fields only, so rosidl_default_generators/runtime are enough.
# --------------------------------------------------------------------------------------------------
def resolve_interface_dependencies(ir: WorkspaceIR) -> list[str]:
    """Return dependencies for the generated_interfaces package."""
    # Interfaces require ROSIDL generation support when at least one msg or srv exists.
    if not ir.topics and not ir.services:
        return []

    # Keep dependencies minimal for primitive-only custom messages/services.
    return ["rosidl_default_generators", "rosidl_default_runtime"]


# --------------------------------------------------------------------------------------------------
# resolve_bringup_dependencies
# --------------------------------------------------------------------------------------------------
# Resolves dependencies for generated_bringup package.
# Bringup launch files depend on launch and launch_ros.
# --------------------------------------------------------------------------------------------------
def resolve_bringup_dependencies(_ir: WorkspaceIR) -> list[str]:
    """Return dependencies for generated_bringup package."""
    # These dependencies support Python launch files for generated systems.
    return ["ament_cmake", "launch", "launch_ros"]
