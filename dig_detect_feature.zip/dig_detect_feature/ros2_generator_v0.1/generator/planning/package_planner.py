"""
Package planner.

Purpose:
    Decides which ROS2 packages should be generated from WorkspaceIR.
"""

from __future__ import annotations

from pathlib import Path

from generator.ir.models import WorkspaceIR
from generator.planning.dependency_resolver import resolve_bringup_dependencies, resolve_interface_dependencies
from generator.planning.generation_plan import GenerationPlan, PackagePlan


# --------------------------------------------------------------------------------------------------
# _has_interfaces
# --------------------------------------------------------------------------------------------------
# Checks whether custom interface package is needed.
# Current generator creates custom interfaces for every topic/service contract present in grammar.
# --------------------------------------------------------------------------------------------------
def _has_interfaces(ir: WorkspaceIR) -> bool:
    """Return True when msg/srv generation is needed."""
    # Any topic creates a .msg and any service creates a .srv.
    return bool(ir.topics or ir.services)


# --------------------------------------------------------------------------------------------------
# build_generation_plan
# --------------------------------------------------------------------------------------------------
# Builds the complete generation plan from WorkspaceIR and output directory.
# Node packages are planned but not generated until the next patch.
# --------------------------------------------------------------------------------------------------
def build_generation_plan(ir: WorkspaceIR, output_dir: Path) -> GenerationPlan:
    """Build generation plan for one example."""
    # Resolve deterministic output workspace paths.
    output_root = Path(output_dir) / ir.example_name
    workspace_root = output_root / "generated_ws"
    src_root = workspace_root / "src"

    # Create interface package when topics/services exist.
    interface_package = None
    if _has_interfaces(ir):
        interface_package = PackagePlan(
            name="generated_interfaces",
            package_type="interfaces",
            relative_path=Path("generated_interfaces"),
            dependencies=resolve_interface_dependencies(ir),
        )

    # Bringup package is always planned because final generator will launch generated nodes.
    bringup_package = PackagePlan(
        name="generated_bringup",
        package_type="bringup",
        relative_path=Path("generated_bringup"),
        dependencies=resolve_bringup_dependencies(ir),
    )

    # Application packages are planned now; code generation will be implemented in next patch.
    application_packages = [
        PackagePlan(
            name=application.name,
            package_type="application",
            relative_path=Path(application.name),
            dependencies=["rclcpp", "generated_interfaces"] if interface_package else ["rclcpp"],
        )
        for application in ir.applications.values()
    ]

    # Discovery is enabled if at least one application references a profile.
    discovery_enabled = any(app.discovery_ref for app in ir.applications.values())

    return GenerationPlan(
        example_name=ir.example_name,
        output_root=output_root,
        workspace_root=workspace_root,
        src_root=src_root,
        interface_package=interface_package,
        bringup_package=bringup_package,
        application_packages=application_packages,
        discovery_enabled=discovery_enabled,
    )
