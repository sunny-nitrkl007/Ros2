"""
Generator-specific error types.

Purpose:
    Provides explicit exception classes so loader, validation, planning, and generation
    layers can report user-friendly errors without using generic exceptions everywhere.
"""

from __future__ import annotations


# --------------------------------------------------------------------------------------------------
# GeneratorError
# --------------------------------------------------------------------------------------------------
# Base exception for all generator failures.
# Catch this type at CLI boundaries to print clean errors for users.
# --------------------------------------------------------------------------------------------------
class GeneratorError(Exception):
    """Base class for all ros2_generator_v0.1 errors."""


# --------------------------------------------------------------------------------------------------
# GrammarLoadError
# --------------------------------------------------------------------------------------------------
# Raised when required grammar files are missing or malformed.
# This keeps file-loading failures separate from semantic validation failures.
# --------------------------------------------------------------------------------------------------
class GrammarLoadError(GeneratorError):
    """Raised when grammar files cannot be loaded."""


# --------------------------------------------------------------------------------------------------
# ValidationError
# --------------------------------------------------------------------------------------------------
# Raised when loaded grammar violates schema/reference/type rules.
# Future validator patches will raise this for detailed grammar issues.
# --------------------------------------------------------------------------------------------------
class ValidationError(GeneratorError):
    """Raised when grammar content fails validation."""
