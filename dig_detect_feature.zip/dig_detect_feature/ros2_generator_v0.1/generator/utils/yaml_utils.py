"""
YAML utility helpers.

Purpose:
    Provides safe and well-commented YAML loading helpers used by the grammar loader.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from generator.utils.errors import GrammarLoadError


# --------------------------------------------------------------------------------------------------
# load_yaml_file
# --------------------------------------------------------------------------------------------------
# Loads a required YAML file and returns a dictionary/list/value depending on file content.
# This function converts low-level YAML and file errors into GrammarLoadError for CLI readability.
# --------------------------------------------------------------------------------------------------
def load_yaml_file(path: Path) -> Any:
    """Load a required YAML file.

    Args:
        path: Absolute or relative path to the YAML file.

    Returns:
        Parsed YAML content. Empty files return an empty dictionary.

    Raises:
        GrammarLoadError: If the file does not exist or YAML parsing fails.
    """
    # Normalize the path so error messages are clear and consistent.
    path = Path(path)

    # Required files must exist at this point in V1 loader flow.
    if not path.exists():
        raise GrammarLoadError(f"Required YAML file not found: {path}")

    # Only regular files are valid YAML inputs.
    if not path.is_file():
        raise GrammarLoadError(f"Expected a YAML file but found non-file path: {path}")

    try:
        # Read as UTF-8 because grammar files are text YAML files.
        with path.open("r", encoding="utf-8") as stream:
            loaded = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        # Keep YAML parser details, but add filename context for the user.
        raise GrammarLoadError(f"Invalid YAML in {path}: {exc}") from exc
    except OSError as exc:
        # Convert OS errors into generator-specific load errors.
        raise GrammarLoadError(f"Could not read YAML file {path}: {exc}") from exc

    # Treat empty YAML as an empty mapping to keep downstream code simple.
    return {} if loaded is None else loaded


# --------------------------------------------------------------------------------------------------
# load_optional_yaml_file
# --------------------------------------------------------------------------------------------------
# Loads an optional YAML file and returns a default value if absent.
# This is useful for future optional grammar files while keeping V1 strict files explicit.
# --------------------------------------------------------------------------------------------------
def load_optional_yaml_file(path: Path, default: Any | None = None) -> Any:
    """Load an optional YAML file.

    Args:
        path: Path to the optional YAML file.
        default: Value returned when the file does not exist.

    Returns:
        Parsed YAML content or default.
    """
    # Normalize the path before checking existence.
    path = Path(path)

    # Return the caller-provided default if optional file is absent.
    if not path.exists():
        return {} if default is None else default

    # Reuse strict loader when the file exists.
    return load_yaml_file(path)
