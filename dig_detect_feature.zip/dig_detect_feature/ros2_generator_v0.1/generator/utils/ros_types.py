"""
ROS2 type utilities.

Purpose:
    Validates and converts finalized grammar field types for message/service generation.
"""

from __future__ import annotations

from generator.utils.errors import ValidationError

SUPPORTED_FIELD_TYPES = {
    "bool",
    "byte",
    "char",
    "float32",
    "float64",
    "int8",
    "uint8",
    "int16",
    "uint16",
    "int32",
    "uint32",
    "int64",
    "uint64",
    "string",
}

SUPPORTED_PARAMETER_TYPES = {
    "bool",
    "int32",
    "int64",
    "float32",
    "float64",
    "string",
}


# --------------------------------------------------------------------------------------------------
# normalize_array_type
# --------------------------------------------------------------------------------------------------
# Splits a grammar type into base type and array flag.
# Example: float32[] becomes (float32, True).
# --------------------------------------------------------------------------------------------------
def normalize_array_type(type_name: str) -> tuple[str, bool]:
    """Return base type and whether the field is an array."""
    # Strip whitespace to tolerate small grammar formatting differences.
    value = str(type_name).strip()

    # Detect unbounded array syntax used in ROS2 interface files.
    if value.endswith("[]"):
        return value[:-2], True

    return value, False


# --------------------------------------------------------------------------------------------------
# validate_field_type
# --------------------------------------------------------------------------------------------------
# Validates topic/service field types used in finalized grammar.
# Supports scalar primitives and unbounded arrays like float32[].
# --------------------------------------------------------------------------------------------------
def validate_field_type(type_name: str) -> None:
    """Validate a ROS2 message/service field type."""
    # Convert array type to base type before checking primitive support.
    base_type, _is_array = normalize_array_type(type_name)

    # Raise explicit validation error if unsupported.
    if base_type not in SUPPORTED_FIELD_TYPES:
        raise ValidationError(f"Unsupported ROS2 field type: {type_name}")


# --------------------------------------------------------------------------------------------------
# validate_parameter_type
# --------------------------------------------------------------------------------------------------
# Validates parameter types used in parameter_profiles.yaml.
# Parameters intentionally use a smaller set than message fields.
# --------------------------------------------------------------------------------------------------
def validate_parameter_type(type_name: str) -> None:
    """Validate a ROS2 parameter type."""
    # Parameters should not currently be arrays in V1 grammar.
    if str(type_name).strip() not in SUPPORTED_PARAMETER_TYPES:
        raise ValidationError(f"Unsupported parameter type: {type_name}")
