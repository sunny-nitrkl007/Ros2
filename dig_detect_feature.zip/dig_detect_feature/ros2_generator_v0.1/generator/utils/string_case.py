"""
String and naming utilities.

Purpose:
    Provides reusable naming helpers used by IR, validation, planning, and code generation.
"""

from __future__ import annotations

import re


# --------------------------------------------------------------------------------------------------
# is_valid_identifier
# --------------------------------------------------------------------------------------------------
# Checks whether a grammar name is safe as a simple identifier.
# This protects future generated C++ symbols from invalid grammar names.
# --------------------------------------------------------------------------------------------------
def is_valid_identifier(value: str) -> bool:
    """Return True if value is a simple identifier."""
    # Accept letters/underscore first, then letters/digits/underscore.
    return bool(re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", value or ""))


# --------------------------------------------------------------------------------------------------
# snake_to_camel
# --------------------------------------------------------------------------------------------------
# Converts snake_case into CamelCase for generated ROS2 interface and C++ class names.
# Example: obstacle_data -> ObstacleData.
# --------------------------------------------------------------------------------------------------
def snake_to_camel(value: str) -> str:
    """Convert snake_case to CamelCase."""
    # Split by underscores and capitalize non-empty words.
    return "".join(part.capitalize() for part in value.split("_") if part)


# --------------------------------------------------------------------------------------------------
# camel_to_snake
# --------------------------------------------------------------------------------------------------
# Converts CamelCase into snake_case for generated ROS2 C++ include paths.
# Example: ObstacleData -> obstacle_data.
# --------------------------------------------------------------------------------------------------
def camel_to_snake(value: str) -> str:
    """Convert CamelCase to snake_case."""
    # Add underscore between lower/digit and upper-case boundaries.
    first_pass = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", value)
    second_pass = re.sub("([a-z0-9])([A-Z])", r"\1_\2", first_pass)
    return second_pass.lower()
