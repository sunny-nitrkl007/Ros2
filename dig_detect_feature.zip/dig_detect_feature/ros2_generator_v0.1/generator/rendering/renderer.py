"""
Jinja2 template renderer.

Purpose:
    Provides a small rendering wrapper used by generators to emit deterministic files.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, StrictUndefined


# --------------------------------------------------------------------------------------------------
# TemplateRenderer
# --------------------------------------------------------------------------------------------------
# Wraps Jinja2 environment setup and file rendering.
# StrictUndefined catches missing template data early during development.
# --------------------------------------------------------------------------------------------------
class TemplateRenderer:
    """Jinja2-backed template renderer."""

    def __init__(self, template_root: Path) -> None:
        """Create renderer for a template root."""
        # Store template root and configure strict Jinja behavior.
        self.template_root = Path(template_root)
        self.environment = Environment(
            loader=FileSystemLoader(str(self.template_root)),
            undefined=StrictUndefined,
            trim_blocks=True,
            lstrip_blocks=True,
        )

    # --------------------------------------------------------------------------------------------------
    # render_to_file
    # --------------------------------------------------------------------------------------------------
    # Renders one template into an output file.
    # The parent directory is created automatically before writing.
    # --------------------------------------------------------------------------------------------------
    def render_to_file(self, template_name: str, output_path: Path, context: dict[str, Any]) -> None:
        """Render template to output file."""
        # Load template by path relative to template_root.
        template = self.environment.get_template(template_name)

        # Render using provided context.
        rendered = template.render(**context)

        # Create parent directory and write rendered text.
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(rendered, encoding="utf-8")
