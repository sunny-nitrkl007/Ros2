"""Core DDS/FastDDS configuration generator."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from generator.ir.models import DiscoveryProfileIR, WorkspaceIR
from generator.planning.generation_plan import GenerationPlan
from generator.rendering.renderer import TemplateRenderer


def primary_discovery_profile(ir: WorkspaceIR) -> DiscoveryProfileIR | None:
    """Return first discovery profile referenced by any application."""
    for application in ir.applications.values():
        if application.discovery_ref and application.discovery_ref in ir.discovery_profiles:
            return ir.discovery_profiles[application.discovery_ref]
    return None


def dds_config_path(plan: GenerationPlan) -> Path:
    """Return core FastDDS XML path."""
    return plan.workspace_root / "config" / "dds" / "fastdds_discovery.xml"


def dds_context(ir: WorkspaceIR, plan: GenerationPlan) -> dict[str, Any]:
    """Build DDS context used by XML and launch templates."""
    profile = primary_discovery_profile(ir)
    first_server = profile.discovery_servers[0] if profile and profile.discovery_servers else None
    server_value = f"{first_server.ip}:{first_server.port}" if first_server else ""
    return {
        "enabled": profile is not None,
        "domain_id": profile.domain_id if profile else 0,
        "mode": profile.mode if profile else "",
        "server": server_value,
        "servers": profile.discovery_servers if profile else [],
        "fastdds_xml_path": str(dds_config_path(plan)),
    }


def generate_core_dds_config(ir: WorkspaceIR, plan: GenerationPlan, renderer: TemplateRenderer) -> list[Path]:
    """Generate core DDS XML when discovery is referenced."""
    context = dds_context(ir, plan)
    if not context["enabled"]:
        return []
    path = dds_config_path(plan)
    renderer.render_to_file("config/fastdds_discovery.xml.j2", path, {"discovery": context})
    return [path]
