"""
C++ node generator.

Purpose:
    Builds node template contexts and renders generated C++ node headers/sources/main files.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from generator.ir.models import FieldIR, InteractionIR, NodeIR, ParameterIR, WorkspaceIR
from generator.planning.artifact_planner import (
    node_class_name,
    service_cpp_type,
    service_include_path,
    topic_cpp_type,
    topic_include_path,
)
from generator.rendering.renderer import TemplateRenderer


# --------------------------------------------------------------------------------------------------
# _cpp_param_type
# --------------------------------------------------------------------------------------------------
# Maps grammar parameter types to C++ template types for declare_parameter.
# This keeps generated parameter declarations readable and type-safe.
# --------------------------------------------------------------------------------------------------
def _cpp_param_type(type_name: str) -> str:
    """Return C++ type for a ROS2 parameter."""
    # Map finalized grammar type names to C++ types.
    return {
        "bool": "bool",
        "int32": "int64_t",
        "int64": "int64_t",
        "float32": "double",
        "float64": "double",
        "string": "std::string",
    }.get(type_name, "std::string")


# --------------------------------------------------------------------------------------------------
# _cpp_default_value
# --------------------------------------------------------------------------------------------------
# Converts a grammar parameter default into C++ literal syntax.
# This supports generated declare_parameter calls.
# --------------------------------------------------------------------------------------------------
def _cpp_default_value(parameter: ParameterIR) -> str:
    """Return C++ default literal for a parameter."""
    # Render booleans as lowercase C++ literals.
    if parameter.type == "bool":
        return "true" if bool(parameter.default) else "false"

    # Render strings as quoted values.
    if parameter.type == "string":
        return f"\"{parameter.default}\""

    # Numeric values can be stringified directly.
    return str(parameter.default)


# --------------------------------------------------------------------------------------------------
# _yaml_default_value
# --------------------------------------------------------------------------------------------------
# Converts parameter defaults into simple YAML literals for params.yaml.
# This supports generated config/params.yaml files.
# --------------------------------------------------------------------------------------------------
def _yaml_default_value(parameter: ParameterIR) -> str:
    """Return YAML default literal for a parameter."""
    # YAML booleans should be lowercase for consistency.
    if parameter.type == "bool":
        return "true" if bool(parameter.default) else "false"

    # Quote strings to avoid YAML ambiguity.
    if parameter.type == "string":
        return f"\"{parameter.default}\""

    # Numeric defaults can be emitted as-is.
    return str(parameter.default)


# --------------------------------------------------------------------------------------------------
# _make_parameter_context
# --------------------------------------------------------------------------------------------------
# Converts ParameterIR objects into template-friendly dictionaries.
# This separates template formatting from IR internals.
# --------------------------------------------------------------------------------------------------
def _make_parameter_context(parameter: ParameterIR) -> dict[str, Any]:
    """Build template context for one parameter."""
    # Return all values needed by C++ and YAML templates.
    return {
        "name": parameter.name,
        "type": parameter.type,
        "cpp_type": _cpp_param_type(parameter.type),
        "cpp_default": _cpp_default_value(parameter),
        "yaml_default": _yaml_default_value(parameter),
    }


# --------------------------------------------------------------------------------------------------
# _interaction_member_name
# --------------------------------------------------------------------------------------------------
# Creates a C++ member variable name for an interaction.
# This keeps generated symbols stable and traceable to grammar names.
# --------------------------------------------------------------------------------------------------
def _interaction_member_name(interaction: InteractionIR) -> str:
    """Return member variable name for an interaction."""
    # Add suffix based on endpoint kind to improve readability.
    suffix = {
        "publisher": "publisher_",
        "subscriber": "subscriber_",
        "service_server": "service_",
        "service_client": "client_",
    }[interaction.kind]
    return f"{interaction.name}_{suffix}"


# --------------------------------------------------------------------------------------------------
# _qos_var_name
# --------------------------------------------------------------------------------------------------
# Creates a local QoS variable name for code generation.
# This makes endpoint setup code easy to read.
# --------------------------------------------------------------------------------------------------
def _qos_var_name(interaction: InteractionIR) -> str:
    """Return local QoS variable name for an interaction."""
    # Prefix with qos_ and interaction name to avoid collisions.
    return f"qos_{interaction.name}"


# --------------------------------------------------------------------------------------------------
# _publisher_context
# --------------------------------------------------------------------------------------------------
# Builds template context for a publisher interaction.
# It resolves topic metadata and QoS metadata from WorkspaceIR.
# --------------------------------------------------------------------------------------------------
def _publisher_context(ir: WorkspaceIR, interaction: InteractionIR) -> dict[str, Any]:
    """Build context for one publisher."""
    # Resolve topic and QoS references already validated by validators.
    topic = ir.topics[interaction.reference_name]
    qos = ir.qos_profiles[interaction.qos_profile]
    return {
        "name": interaction.name,
        "topic_name": topic.name,
        "topic_path": topic.path,
        "qos_profile": interaction.qos_profile,
        "qos": qos,
        "qos_var": _qos_var_name(interaction),
        "cpp_type": topic_cpp_type(topic.name),
        "member_name": _interaction_member_name(interaction),
        "local_msg_var": f"msg_{interaction.name}",
        "fields": topic.fields,
    }


# --------------------------------------------------------------------------------------------------
# _subscriber_context
# --------------------------------------------------------------------------------------------------
# Builds template context for a subscriber interaction.
# It resolves topic metadata and QoS metadata from WorkspaceIR.
# --------------------------------------------------------------------------------------------------
def _subscriber_context(ir: WorkspaceIR, interaction: InteractionIR) -> dict[str, Any]:
    """Build context for one subscriber."""
    # Resolve topic and QoS references already validated by validators.
    topic = ir.topics[interaction.reference_name]
    qos = ir.qos_profiles[interaction.qos_profile]
    return {
        "name": interaction.name,
        "topic_name": topic.name,
        "topic_path": topic.path,
        "qos_profile": interaction.qos_profile,
        "qos": qos,
        "qos_var": _qos_var_name(interaction),
        "cpp_type": topic_cpp_type(topic.name),
        "member_name": _interaction_member_name(interaction),
        "fields": topic.fields,
    }


# --------------------------------------------------------------------------------------------------
# _service_server_context
# --------------------------------------------------------------------------------------------------
# Builds template context for a service server interaction.
# It resolves service metadata from WorkspaceIR.
# --------------------------------------------------------------------------------------------------
def _service_server_context(ir: WorkspaceIR, interaction: InteractionIR) -> dict[str, Any]:
    """Build context for one service server."""
    # Resolve service reference already validated by validators.
    service = ir.services[interaction.reference_name]
    return {
        "name": interaction.name,
        "service_name": service.name,
        "service_path": service.path,
        "qos_profile": interaction.qos_profile,
        "cpp_type": service_cpp_type(service.name),
        "member_name": _interaction_member_name(interaction),
        "request_fields": service.request_fields,
        "response_fields": service.response_fields,
    }


# --------------------------------------------------------------------------------------------------
# _service_client_context
# --------------------------------------------------------------------------------------------------
# Builds template context for a service client interaction.
# It resolves service metadata from WorkspaceIR.
# --------------------------------------------------------------------------------------------------
def _service_client_context(ir: WorkspaceIR, interaction: InteractionIR) -> dict[str, Any]:
    """Build context for one service client."""
    # Resolve service reference already validated by validators.
    service = ir.services[interaction.reference_name]
    return {
        "name": interaction.name,
        "service_name": service.name,
        "service_path": service.path,
        "qos_profile": interaction.qos_profile,
        "cpp_type": service_cpp_type(service.name),
        "member_name": _interaction_member_name(interaction),
        "request_fields": service.request_fields,
        "response_fields": service.response_fields,
    }


# --------------------------------------------------------------------------------------------------
# build_node_context
# --------------------------------------------------------------------------------------------------
# Builds a complete template context for one NodeIR.
# The context includes resolved interactions, includes, class name, and parameter metadata.
# --------------------------------------------------------------------------------------------------
def build_node_context(ir: WorkspaceIR, node: NodeIR, package_name: str) -> dict[str, Any]:
    """Build template context for one generated C++ node."""
    # Gather resolved interactions by kind.
    publishers = []
    subscribers = []
    service_servers = []
    service_clients = []
    include_paths: set[str] = set()

    for interaction_ref in node.interaction_refs:
        interaction = ir.interactions[interaction_ref]
        if interaction.kind == "publisher":
            publishers.append(_publisher_context(ir, interaction))
            include_paths.add(topic_include_path(interaction.reference_name))
        elif interaction.kind == "subscriber":
            subscribers.append(_subscriber_context(ir, interaction))
            include_paths.add(topic_include_path(interaction.reference_name))
        elif interaction.kind == "service_server":
            service_servers.append(_service_server_context(ir, interaction))
            include_paths.add(service_include_path(interaction.reference_name))
        elif interaction.kind == "service_client":
            service_clients.append(_service_client_context(ir, interaction))
            include_paths.add(service_include_path(interaction.reference_name))

    # Resolve parameters assigned by parameter_ref.
    parameters = []
    if node.parameter_ref and node.parameter_ref in ir.parameter_profiles:
        parameters = [_make_parameter_context(param) for param in ir.parameter_profiles[node.parameter_ref].parameters]

    # Create final template-friendly node dictionary.
    return {
        "name": node.name,
        "class_name": node_class_name(node.name),
        "parameter_ref": node.parameter_ref,
        "parameters": parameters,
        "publishers": publishers,
        "subscribers": subscribers,
        "service_servers": service_servers,
        "service_clients": service_clients,
        "include_paths": sorted(include_paths),
    }


# --------------------------------------------------------------------------------------------------
# generate_node_files
# --------------------------------------------------------------------------------------------------
# Renders C++ header, source, and main file for one generated node.
# Returns all created file paths so CLI/reporting can display them.
# --------------------------------------------------------------------------------------------------
def generate_node_files(
    ir: WorkspaceIR,
    node: NodeIR,
    package_root: Path,
    package_name: str,
    renderer: TemplateRenderer,
) -> list[Path]:
    """Generate C++ files for one node."""
    # Build full node context once and reuse across templates.
    node_context = build_node_context(ir, node, package_name)
    package_context = {"name": package_name, "cpp_namespace": package_name}
    context = {"node": node_context, "package": package_context}

    # Resolve output paths.
    header_path = package_root / "include" / package_name / f"{node.name}.hpp"
    source_path = package_root / "src" / f"{node.name}.cpp"
    main_path = package_root / "src" / f"{node.name}_main.cpp"

    # Render generated C++ artifacts.
    renderer.render_to_file("cpp/node.hpp.j2", header_path, context)
    renderer.render_to_file("cpp/node.cpp.j2", source_path, context)
    renderer.render_to_file("cpp/node_main.cpp.j2", main_path, context)

    return [header_path, source_path, main_path]
