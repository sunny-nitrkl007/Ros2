"""
Application package generator.

Purpose:
    Generates one ROS2 C++ application package per application in applications.yaml.
    Scalable default: one combined executable per application.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from generator.generation.node_generator import build_node_context, generate_node_files
from generator.ir.models import ApplicationIR, WorkspaceIR
from generator.rendering.renderer import TemplateRenderer


# --------------------------------------------------------------------------------------------------
# _application_nodes
# --------------------------------------------------------------------------------------------------
# Resolves NodeIR objects owned by one application.
# applications.yaml is the source of application-to-node grouping.
# --------------------------------------------------------------------------------------------------
def _application_nodes(ir: WorkspaceIR, application: ApplicationIR):
    """Return NodeIR list for one application."""
    # Preserve node order from applications.yaml for deterministic generated files.
    return [ir.nodes[node_name] for node_name in application.node_names]


# --------------------------------------------------------------------------------------------------
# _render_package_files
# --------------------------------------------------------------------------------------------------
# Renders CMakeLists.txt and package.xml for one combined-executable application package.
# --------------------------------------------------------------------------------------------------
def _render_package_files(
    package_root: Path,
    package_name: str,
    node_contexts: list[dict[str, Any]],
    renderer: TemplateRenderer,
) -> list[Path]:
    """Render package metadata files."""
    # Build shared context for package templates.
    context = {"package": {"name": package_name}, "nodes": node_contexts}

    cmake_path = package_root / "CMakeLists.txt"
    package_xml_path = package_root / "package.xml"
    renderer.render_to_file("package/app_CMakeLists.txt.j2", cmake_path, context)
    renderer.render_to_file("package/app_package.xml.j2", package_xml_path, context)
    return [cmake_path, package_xml_path]


# --------------------------------------------------------------------------------------------------
# _render_config_and_docs
# --------------------------------------------------------------------------------------------------
# Renders config/params.yaml and README.md for one application package.
# --------------------------------------------------------------------------------------------------
def _render_config_and_docs(
    package_root: Path,
    package_name: str,
    node_contexts: list[dict[str, Any]],
    renderer: TemplateRenderer,
) -> list[Path]:
    """Render config and documentation files."""
    # Build shared context for config/docs templates.
    context = {"package": {"name": package_name}, "nodes": node_contexts}

    params_path = package_root / "config" / "params.yaml"
    readme_path = package_root / "README.md"
    renderer.render_to_file("config/app_params.yaml.j2", params_path, context)
    renderer.render_to_file("docs/app_README.md.j2", readme_path, context)
    return [params_path, readme_path]


# --------------------------------------------------------------------------------------------------
# _render_combined_main
# --------------------------------------------------------------------------------------------------
# Renders combined_main.cpp containing all nodes for one application.
# --------------------------------------------------------------------------------------------------
def _render_combined_main(
    package_root: Path,
    package_name: str,
    node_contexts: list[dict[str, Any]],
    renderer: TemplateRenderer,
) -> Path:
    """Render combined main file for the application."""
    # Render one combined executable entrypoint per application package.
    combined_main = package_root / "src" / "combined_main.cpp"
    renderer.render_to_file(
        "cpp/combined_main.cpp.j2",
        combined_main,
        {"nodes": node_contexts, "package": {"name": package_name, "cpp_namespace": package_name}},
    )
    return combined_main


# --------------------------------------------------------------------------------------------------
# generate_application_package
# --------------------------------------------------------------------------------------------------
# Generates one application package with node classes and one combined executable.
# Returns created files for CLI/reporting.
# --------------------------------------------------------------------------------------------------
def generate_application_package(
    ir: WorkspaceIR,
    application: ApplicationIR,
    package_root: Path,
    renderer: TemplateRenderer,
) -> list[Path]:
    """Generate one ROS2 C++ application package."""
    # Ensure package root exists before rendering files.
    package_root.mkdir(parents=True, exist_ok=True)

    # Resolve physical node objects and template contexts.
    nodes = _application_nodes(ir, application)
    node_contexts = [build_node_context(ir, node, application.name) for node in nodes]

    # Generate node C++ files. Existing per-node main files may still be rendered by node_generator,
    # but combined CMake does not compile them. They remain useful for future single-node debug mode.
    created_files: list[Path] = []
    for node in nodes:
        created_files.extend(generate_node_files(ir, node, package_root, application.name, renderer))

    # Generate combined application main.
    created_files.append(_render_combined_main(package_root, application.name, node_contexts, renderer))

    # Generate package metadata, config, and docs.
    created_files.extend(_render_package_files(package_root, application.name, node_contexts, renderer))
    created_files.extend(_render_config_and_docs(package_root, application.name, node_contexts, renderer))

    return created_files
