"""Local ECU-style deployment helper generation."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from generator.generation.dds_generator import dds_context
from generator.ir.models import WorkspaceIR
from generator.planning.generation_plan import GenerationPlan
from generator.rendering.renderer import TemplateRenderer


def _local_root(plan: GenerationPlan) -> Path:
    return plan.workspace_root / "local_deployment"


def _ctx(ir: WorkspaceIR, plan: GenerationPlan) -> dict[str, Any]:
    discovery = dds_context(ir, plan)
    applications = list(ir.applications.values())
    return {
        "ir": ir,
        "applications": applications,
        "discovery": discovery,
        "expected_nodes": sorted(ir.nodes.keys()),
        "expected_topics": sorted(topic.path for topic in ir.topics.values()),
        "expected_services": sorted(service.path for service in ir.services.values()),
    }


def generate_local_deployment(ir: WorkspaceIR, plan: GenerationPlan, renderer: TemplateRenderer) -> list[Path]:
    root = _local_root(plan)
    ctx = _ctx(ir, plan)
    paths = {
        "build": root / "scripts" / "local_build.sh",
        "prepare": root / "scripts" / "local_prepare_ecu_demo.sh",
        "launch": root / "scripts" / "local_launch_ecu_terminals.sh",
        "manual": root / "scripts" / "local_print_ecu_commands.sh",
        "validate": root / "scripts" / "local_validate_running_ecus.sh",
        "down": root / "scripts" / "local_down.sh",
        "doc": root / "docs" / "LOCAL_RUNTIME.md",
    }
    templates = {
        "build": "local_deployment/local_build.sh.j2",
        "prepare": "local_deployment/local_prepare_ecu_demo.sh.j2",
        "launch": "local_deployment/local_launch_ecu_terminals.sh.j2",
        "manual": "local_deployment/local_print_ecu_commands.sh.j2",
        "validate": "local_deployment/local_validate_running_ecus.sh.j2",
        "down": "local_deployment/local_down.sh.j2",
        "doc": "local_deployment/LOCAL_RUNTIME.md.j2",
    }
    created: list[Path] = []
    for key, tmpl in templates.items():
        renderer.render_to_file(tmpl, paths[key], ctx)
        created.append(paths[key])
    for key, path in paths.items():
        if key != "doc":
            path.chmod(0o755)
    return created
