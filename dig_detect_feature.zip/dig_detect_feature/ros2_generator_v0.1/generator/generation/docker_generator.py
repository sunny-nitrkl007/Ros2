from __future__ import annotations
from pathlib import Path
from typing import Any
from generator.generation.dds_generator import dds_context
from generator.ir.models import WorkspaceIR
from generator.planning.generation_plan import GenerationPlan
from generator.rendering.renderer import TemplateRenderer


def _docker_root(plan: GenerationPlan) -> Path:
    return plan.workspace_root / "docker_deployment"


def _ctx(ir: WorkspaceIR, plan: GenerationPlan, ros_distro: str) -> dict[str, Any]:
    discovery = dds_context(ir, plan)
    applications = list(ir.applications.values())
    compose_project = ir.example_name.replace("-", "_")
    services: list[dict[str, str]] = []
    if discovery["enabled"]:
        services.append({"name": "discovery_server", "kind": "discovery"})
    for app in applications:
        services.append({"name": app.name.replace("-", "_"), "package": app.name, "kind": "app"})
    services.append({"name": "inspector", "kind": "inspector"})
    return {
        "ir": ir,
        "applications": applications,
        "services": services,
        "discovery": discovery,
        "ros_distro": ros_distro,
        "compose_project": compose_project,
        "image_name": f"{compose_project}_generated_ws:latest",
        "expected_topics": sorted(topic.path for topic in ir.topics.values()),
    }


def generate_docker_artifacts(ir: WorkspaceIR, plan: GenerationPlan, renderer: TemplateRenderer, ros_distro: str) -> list[Path]:
    root = _docker_root(plan)
    ctx = _ctx(ir, plan, ros_distro)
    paths = {
        "dockerfile": root / "Dockerfile",
        "compose": root / "docker-compose.yml",
        "entrypoint": root / "docker_entrypoint.sh",
        "cmdlib": root / "scripts" / "docker_cmd_lib.sh",
        "build": root / "scripts" / "docker_build.sh",
        "down": root / "scripts" / "docker_down.sh",
        "logs": root / "scripts" / "docker_logs.sh",
        "prepare": root / "scripts" / "docker_prepare_ecu_demo.sh",
        "print_cmds": root / "scripts" / "docker_print_ecu_commands.sh",
        "launch_ecu": root / "scripts" / "docker_launch_ecu_terminals.sh",
        "validate": root / "scripts" / "docker_validate_running_ecus.sh",
        "shell": root / "scripts" / "docker_exec_shell.sh",
        "doc": root / "docs" / "DOCKER_RUNTIME.md",
    }
    templates = {
        "dockerfile": "docker/Dockerfile.j2",
        "compose": "docker/docker-compose.yml.j2",
        "entrypoint": "docker/docker_entrypoint.sh.j2",
        "cmdlib": "docker/docker_cmd_lib.sh.j2",
        "build": "docker/docker_build.sh.j2",
        "down": "docker/docker_down.sh.j2",
        "logs": "docker/docker_logs.sh.j2",
        "prepare": "docker/docker_prepare_ecu_demo.sh.j2",
        "print_cmds": "docker/docker_print_ecu_commands.sh.j2",
        "launch_ecu": "docker/docker_launch_ecu_terminals.sh.j2",
        "validate": "docker/docker_validate_running_ecus.sh.j2",
        "shell": "docker/docker_exec_shell.sh.j2",
        "doc": "docker/DOCKER_RUNTIME.md.j2",
    }
    created: list[Path] = []
    for key, template in templates.items():
        renderer.render_to_file(template, paths[key], ctx)
        created.append(paths[key])
    for service in ctx["services"]:
        env_path = root / "env" / f"{service['name']}.env"
        renderer.render_to_file("docker/service.env.j2", env_path, {**ctx, "service": service})
        created.append(env_path)
    for key, path in paths.items():
        if key not in {"dockerfile", "compose", "doc"}:
            path.chmod(0o755)
    return created
