"""Bringup package generator for current baseline."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from generator.generation.dds_generator import dds_context
from generator.ir.models import WorkspaceIR
from generator.planning.generation_plan import GenerationPlan
from generator.rendering.renderer import TemplateRenderer


def _launch_nodes_context(ir: WorkspaceIR) -> list[dict[str, str]]:
    return [
        {
            "package_name": app.name,
            "executable_name": f"{app.name}_combined",
            "param_var": f"{app.name}_params".replace("-", "_"),
        }
        for app in ir.applications.values()
    ]


def _expected_nodes(ir: WorkspaceIR) -> list[str]:
    return sorted(ir.nodes.keys())


def _expected_topics(ir: WorkspaceIR) -> list[str]:
    return sorted(topic.path for topic in ir.topics.values())


def _expected_services(ir: WorkspaceIR) -> list[str]:
    return sorted(service.path for service in ir.services.values())


def _required_file_list(plan: GenerationPlan, files: list[Path]) -> list[str]:
    out = []
    for f in files:
        try:
            out.append(str(Path(f).relative_to(plan.workspace_root)))
        except ValueError:
            out.append(str(f))
    return sorted(set(out))


def _discovery_for_launch(ir: WorkspaceIR, plan: GenerationPlan, server_enabled: bool) -> dict[str, Any]:
    ctx = dict(dds_context(ir, plan))
    ctx["discovery_server_enabled"] = bool(server_enabled and ctx["enabled"])
    return ctx


def generate_bringup_package(ir: WorkspaceIR, plan: GenerationPlan, renderer: TemplateRenderer, created_so_far: list[Path]) -> list[Path]:
    package_root = plan.src_root / plan.bringup_package.relative_path
    package_root.mkdir(parents=True, exist_ok=True)

    launch_nodes = _launch_nodes_context(ir)
    expected_nodes = _expected_nodes(ir)
    expected_topics = _expected_topics(ir)
    expected_services = _expected_services(ir)
    local_discovery = _discovery_for_launch(ir, plan, False)
    server_discovery = _discovery_for_launch(ir, plan, True)
    app_names = [app.name for app in ir.applications.values()]
    package_names = (["generated_interfaces"] if plan.interface_package else []) + app_names + ["generated_bringup"]

    created: list[Path] = []

    cmake = package_root / "CMakeLists.txt"
    pkg = package_root / "package.xml"
    renderer.render_to_file("package/bringup_CMakeLists.txt.j2", cmake, {})
    renderer.render_to_file("package/bringup_package.xml.j2", pkg, {"application_package_names": app_names})
    created.extend([cmake, pkg])

    local_launch = package_root / "launch" / "system_launch.py"
    discovery_launch = package_root / "launch" / "system_discovery_launch.py"
    renderer.render_to_file("launch/system_launch.py.j2", local_launch, {"launch_nodes": launch_nodes, "discovery": local_discovery})
    renderer.render_to_file("launch/system_launch.py.j2", discovery_launch, {"launch_nodes": launch_nodes, "discovery": server_discovery})
    created.extend([local_launch, discovery_launch])

    readme = package_root / "README.md"
    renderer.render_to_file("docs/bringup_README.md.j2", readme, {"discovery": server_discovery})
    created.append(readme)

    runtime_doc = plan.workspace_root / "RUNTIME_TESTING.md"
    renderer.render_to_file("docs/runtime_testing.md.j2", runtime_doc, {
        "expected_nodes": expected_nodes,
        "expected_topics": expected_topics,
        "expected_services": expected_services,
        "discovery": server_discovery,
    })
    created.append(runtime_doc)

    workspace_readme = plan.workspace_root / "README.md"
    colcon_notes = plan.workspace_root / "COLCON_BUILD_NOTES.md"
    build_script = plan.workspace_root / "build.sh"
    run_script = plan.workspace_root / "run.sh"
    test_build_script = plan.workspace_root / "test_build.sh"
    runtime_smoke = plan.workspace_root / "runtime_smoke_test.sh"

    renderer.render_to_file("docs/workspace_README.md.j2", workspace_readme, {"packages": package_names})
    renderer.render_to_file("docs/colcon_build_notes.md.j2", colcon_notes, {})
    renderer.render_to_file("scripts/workspace_build.sh.j2", build_script, {})
    renderer.render_to_file("scripts/workspace_run.sh.j2", run_script, {})
    renderer.render_to_file("scripts/workspace_test_build.sh.j2", test_build_script, {})
    renderer.render_to_file("scripts/runtime_smoke_test.sh.j2", runtime_smoke, {
        "expected_nodes": expected_nodes,
        "expected_topics": expected_topics,
        "expected_services": expected_services,
    })
    for s in [build_script, run_script, test_build_script, runtime_smoke]:
        s.chmod(0o755)
    created.extend([workspace_readme, colcon_notes, build_script, run_script, test_build_script, runtime_smoke])

    test_path = plan.workspace_root / "test" / "test_generated_files.py"
    renderer.render_to_file("test/test_generated_files.py.j2", test_path, {"required_files": _required_file_list(plan, created_so_far + created + [test_path])})
    created.append(test_path)

    report = package_root / "generation_report.yaml"
    renderer.render_to_file("docs/generation_report.yaml.j2", report, {
        "ir": ir,
        "features": {"interfaces": bool(plan.interface_package), "application_packages": bool(plan.application_packages), "discovery_enabled": server_discovery["enabled"]},
        "counts": {"topics": len(ir.topics), "services": len(ir.services), "applications": len(ir.applications), "nodes": len(ir.nodes), "interactions": len(ir.interactions)},
        "packages": package_names,
        "created_files": _required_file_list(plan, created_so_far + created + [report]),
    })
    created.append(report)
    return created
