"""Workspace generator with independent optional deployment layers."""

from __future__ import annotations

from pathlib import Path

from generator.generation.bringup_generator import generate_bringup_package
from generator.generation.dds_generator import generate_core_dds_config
from generator.generation.docker_generator import generate_docker_artifacts
from generator.generation.interface_generator import generate_interface_package
from generator.generation.local_deployment_generator import generate_local_deployment
from generator.generation.options import GenerationOptions
from generator.generation.package_generator import generate_application_package
from generator.ir.models import WorkspaceIR
from generator.planning.generation_plan import build_generation_plan
from generator.rendering.renderer import TemplateRenderer


def generate_workspace(
    ir: WorkspaceIR,
    output_dir: Path,
    template_root: Path,
    options: GenerationOptions | None = None,
) -> list[Path]:
    options = options or GenerationOptions()
    plan = build_generation_plan(ir, output_dir)
    plan.src_root.mkdir(parents=True, exist_ok=True)
    renderer = TemplateRenderer(template_root)

    created: list[Path] = []
    created.extend(generate_core_dds_config(ir, plan, renderer))
    created.extend(generate_interface_package(ir, plan, renderer))

    for application in ir.applications.values():
        created.extend(generate_application_package(ir, application, plan.src_root / application.name, renderer))

    # Automation artifacts only. No local_deployment coupling.
    if options.with_auto_deps:
        created.extend(generate_bringup_package(ir, plan, renderer, created))

    # Local deployment completely independent from generated_bringup/root scripts.
    if options.local_dep:
        created.extend(generate_local_deployment(ir, plan, renderer))

    # Docker deployment completely independent.
    if options.docker_dep:
        created.extend(generate_docker_artifacts(ir, plan, renderer, options.ros_distro))

    return created
