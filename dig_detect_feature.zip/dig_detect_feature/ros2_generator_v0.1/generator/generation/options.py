"""Generation options for optional output layers."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class GenerationOptions:
    """Options controlling optional generator output layers."""

    with_auto_deps: bool = False
    local_dep: bool = False
    docker_dep: bool = False
    ros_distro: str = "humble"
