"""
Communication graph analysis.

Purpose:
    Summarizes publisher/subscriber and service client/server relationships from WorkspaceIR.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from generator.ir.models import WorkspaceIR


# --------------------------------------------------------------------------------------------------
# build_communication_graph_summary
# --------------------------------------------------------------------------------------------------
# Builds a simple graph summary grouped by topic and service names.
# This helps classify 1->N, N->1, N->N, and service relationships before generation.
# --------------------------------------------------------------------------------------------------
def build_communication_graph_summary(ir: WorkspaceIR) -> dict[str, Any]:
    """Build communication graph summary from interactions and node assignments."""
    # Reverse-map interaction name to owning node names.
    owners: dict[str, list[str]] = defaultdict(list)
    for node in ir.nodes.values():
        for interaction_ref in node.interaction_refs:
            owners[interaction_ref].append(node.name)

    # Group pub/sub endpoints by topic.
    topics: dict[str, dict[str, list[str]]] = defaultdict(lambda: {"publishers": [], "subscribers": []})
    services: dict[str, dict[str, list[str]]] = defaultdict(lambda: {"servers": [], "clients": []})

    for interaction in ir.interactions.values():
        owner_nodes = owners.get(interaction.name, [])
        if interaction.kind == "publisher":
            topics[interaction.reference_name]["publishers"].extend(owner_nodes)
        elif interaction.kind == "subscriber":
            topics[interaction.reference_name]["subscribers"].extend(owner_nodes)
        elif interaction.kind == "service_server":
            services[interaction.reference_name]["servers"].extend(owner_nodes)
        elif interaction.kind == "service_client":
            services[interaction.reference_name]["clients"].extend(owner_nodes)

    # Convert defaultdicts into regular dictionaries for stable printing/serialization.
    return {
        "topics": {name: dict(value) for name, value in topics.items()},
        "services": {name: dict(value) for name, value in services.items()},
    }
