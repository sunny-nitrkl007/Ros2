"""
ROS graph topology classifier.

Purpose:
    Classifies communication patterns using the communication graph summary.
"""

from __future__ import annotations

from typing import Any


# --------------------------------------------------------------------------------------------------
# classify_topic_pattern
# --------------------------------------------------------------------------------------------------
# Classifies one topic based on number of publisher and subscriber owner nodes.
# This classification is useful for reports and future generation tests.
# --------------------------------------------------------------------------------------------------
def classify_topic_pattern(publisher_count: int, subscriber_count: int) -> str:
    """Classify one pub/sub topic pattern."""
    # No publishers/subscribers means disconnected or unused contract.
    if publisher_count == 0 and subscriber_count == 0:
        return "unused_topic"
    if publisher_count == 1 and subscriber_count == 0:
        return "publisher_only"
    if publisher_count == 0 and subscriber_count == 1:
        return "subscriber_only"
    if publisher_count == 1 and subscriber_count == 1:
        return "one_to_one"
    if publisher_count == 1 and subscriber_count > 1:
        return "one_to_many"
    if publisher_count > 1 and subscriber_count == 1:
        return "many_to_one"
    if publisher_count > 1 and subscriber_count > 1:
        return "many_to_many"
    return "unknown"


# --------------------------------------------------------------------------------------------------
# classify_graph
# --------------------------------------------------------------------------------------------------
# Classifies all topic and service graph groups into readable labels.
# This will later feed generation reports and validations.
# --------------------------------------------------------------------------------------------------
def classify_graph(graph_summary: dict[str, Any]) -> dict[str, Any]:
    """Classify graph topic/service patterns."""
    topic_patterns: dict[str, str] = {}
    service_patterns: dict[str, str] = {}

    for topic_name, data in graph_summary.get("topics", {}).items():
        topic_patterns[topic_name] = classify_topic_pattern(
            len(data.get("publishers", [])),
            len(data.get("subscribers", [])),
        )

    for service_name, data in graph_summary.get("services", {}).items():
        servers = len(data.get("servers", []))
        clients = len(data.get("clients", []))
        if servers == 0 and clients > 0:
            service_patterns[service_name] = "client_only"
        elif servers > 0 and clients == 0:
            service_patterns[service_name] = "server_only"
        elif servers == 1 and clients == 1:
            service_patterns[service_name] = "one_client_one_server"
        elif servers == 1 and clients > 1:
            service_patterns[service_name] = "many_clients_one_server"
        elif servers > 1 and clients >= 1:
            service_patterns[service_name] = "multi_server_service_graph"
        else:
            service_patterns[service_name] = "unused_service"

    return {"topics": topic_patterns, "services": service_patterns}
