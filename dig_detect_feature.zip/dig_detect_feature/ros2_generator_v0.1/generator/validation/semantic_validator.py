"""
Semantic validation orchestration.

Purpose:
    Runs all validation layers over WorkspaceIR and returns warnings.
"""

from __future__ import annotations

from generator.ir.models import WorkspaceIR
from generator.validation.reference_validator import validate_references
from generator.validation.type_validator import validate_types


# --------------------------------------------------------------------------------------------------
# validate_workspace_ir
# --------------------------------------------------------------------------------------------------
# Runs type and reference validation for the workspace IR.
# Errors raise ValidationError from underlying validators; warnings are returned.
# --------------------------------------------------------------------------------------------------
def validate_workspace_ir(ir: WorkspaceIR) -> list[str]:
    """Validate the complete workspace IR and return warnings."""
    # Validate field and parameter types first because references may lead to generation later.
    warnings = []
    warnings.extend(validate_types(ir))

    # Validate cross references after types are known to be acceptable.
    warnings.extend(validate_references(ir))

    return warnings
