"""
Reference validation for finalized grammar IR.

Purpose:
    Ensures all cross-references between applications, nodes, interactions, topics, services,
    QoS profiles, parameters, and discovery profiles are valid.
"""

from __future__ import annotations

from generator.ir.models import WorkspaceIR
from generator.utils.errors import ValidationError


# --------------------------------------------------------------------------------------------------
# _ensure_unique_names
# --------------------------------------------------------------------------------------------------
# Ensures no dictionary key is empty.
# Duplicate detection happens naturally during IR build by dictionary overwrite; later patches may
# preserve source duplicates explicitly, but this check catches missing names now.
# --------------------------------------------------------------------------------------------------
def _ensure_no_empty_keys(ir: WorkspaceIR) -> None:
    """Validate that core IR dictionaries do not contain empty keys."""
    # Check every major dictionary because empty names break generation.
    for label, values in {
        "topic": ir.topics,
        "service": ir.services,
        "qos profile": ir.qos_profiles,
        "parameter profile": ir.parameter_profiles,
        "discovery profile": ir.discovery_profiles,
        "application": ir.applications,
        "interaction": ir.interactions,
        "node": ir.nodes,
    }.items():
        if "" in values:
            raise ValidationError(f"Found {label} with empty name")


# --------------------------------------------------------------------------------------------------
# validate_references
# --------------------------------------------------------------------------------------------------
# Validates all cross references in the workspace IR.
# Missing references are errors; unused profiles are warnings.
# --------------------------------------------------------------------------------------------------
def validate_references(ir: WorkspaceIR) -> list[str]:
    """Validate IR references and return non-fatal warnings."""
    warnings: list[str] = []
    _ensure_no_empty_keys(ir)

    # Validate applications reference existing nodes and discovery profiles.
    used_discovery_profiles: set[str] = set()
    for application in ir.applications.values():
        if application.discovery_ref:
            if application.discovery_ref not in ir.discovery_profiles:
                raise ValidationError(
                    f"Application {application.name} references missing discovery profile {application.discovery_ref}"
                )
            used_discovery_profiles.add(application.discovery_ref)

        for node_name in application.node_names:
            if node_name not in ir.nodes:
                raise ValidationError(f"Application {application.name} references missing node {node_name}")

    # Validate nodes reference existing parameter profiles and interactions.
    used_parameter_profiles: set[str] = set()
    used_interactions: set[str] = set()
    for node in ir.nodes.values():
        if node.parameter_ref:
            if node.parameter_ref not in ir.parameter_profiles:
                raise ValidationError(f"Node {node.name} references missing parameter profile {node.parameter_ref}")
            used_parameter_profiles.add(node.parameter_ref)

        for interaction_ref in node.interaction_refs:
            if interaction_ref not in ir.interactions:
                raise ValidationError(f"Node {node.name} references missing interaction {interaction_ref}")
            used_interactions.add(interaction_ref)

    # Validate interaction references depending on interaction type.
    used_qos_profiles: set[str] = set()
    for interaction in ir.interactions.values():
        if interaction.qos_profile not in ir.qos_profiles:
            raise ValidationError(
                f"Interaction {interaction.name} references missing QoS profile {interaction.qos_profile}"
            )
        used_qos_profiles.add(interaction.qos_profile)

        if interaction.kind in ("publisher", "subscriber"):
            if interaction.reference_name not in ir.topics:
                raise ValidationError(
                    f"{interaction.kind} interaction {interaction.name} references missing topic {interaction.reference_name}"
                )
        elif interaction.kind in ("service_server", "service_client"):
            if interaction.reference_name not in ir.services:
                raise ValidationError(
                    f"{interaction.kind} interaction {interaction.name} references missing service {interaction.reference_name}"
                )
        else:
            raise ValidationError(f"Interaction {interaction.name} has unsupported kind {interaction.kind}")

    # Warn about unused definitions that are legal but potentially noisy.
    for qos_name in sorted(set(ir.qos_profiles) - used_qos_profiles):
        warnings.append(f"QoS profile {qos_name} is defined but not used")

    for parameter_profile_name in sorted(set(ir.parameter_profiles) - used_parameter_profiles):
        warnings.append(f"Parameter profile {parameter_profile_name} is defined but not used")

    for discovery_name in sorted(set(ir.discovery_profiles) - used_discovery_profiles):
        warnings.append(f"Discovery profile {discovery_name} is defined but not used")

    for interaction_name in sorted(set(ir.interactions) - used_interactions):
        warnings.append(f"Interaction {interaction_name} is defined but not assigned to any node")

    return warnings
