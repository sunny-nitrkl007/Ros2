"""
Type validation for finalized grammar IR.

Purpose:
    Validates message/service field types and parameter types before generation.
"""

from __future__ import annotations

from generator.ir.models import WorkspaceIR
from generator.utils.ros_types import validate_field_type, validate_parameter_type
from generator.utils.errors import ValidationError


# --------------------------------------------------------------------------------------------------
# validate_types
# --------------------------------------------------------------------------------------------------
# Validates all field and parameter types in the workspace IR.
# This catches unsupported types before template rendering.
# --------------------------------------------------------------------------------------------------
def validate_types(ir: WorkspaceIR) -> list[str]:
    """Validate all ROS2 field and parameter types."""
    # Collect warnings for future use; type failures currently raise errors.
    warnings: list[str] = []

    # Validate all topic fields.
    for topic in ir.topics.values():
        for field in topic.fields:
            validate_field_type(field.type)
            if not field.name:
                raise ValidationError(f"Topic {topic.name} contains a field with empty name")

    # Validate service request/response fields.
    for service in ir.services.values():
        for field in service.request_fields + service.response_fields:
            validate_field_type(field.type)
            if not field.name:
                raise ValidationError(f"Service {service.name} contains a field with empty name")

    # Validate parameter types.
    for profile in ir.parameter_profiles.values():
        for parameter in profile.parameters:
            validate_parameter_type(parameter.type)
            if not parameter.name:
                raise ValidationError(f"Parameter profile {profile.name} contains a parameter with empty name")

    return warnings
