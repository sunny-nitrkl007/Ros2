"""Generator command entry point."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Any

from generator.analysis.communication_graph import build_communication_graph_summary
from generator.analysis.topology_classifier import classify_graph
from generator.generation.options import GenerationOptions
from generator.generation.workspace_generator import generate_workspace
from generator.grammar.loader import load_finalized_grammar, summarize_grammar_bundle
from generator.ir.builder import build_workspace_ir
from generator.ir.models import WorkspaceIR
from generator.utils.errors import GeneratorError
from generator.validation.semantic_validator import validate_workspace_ir


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ros2_generator_v0.1", description="Grammar-driven ROS2 boilerplate generator.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    inspect_parser = subparsers.add_parser("inspect", help="Load and summarize raw finalized grammar.")
    inspect_parser.add_argument("example_dir", type=Path)

    inspect_ir_parser = subparsers.add_parser("inspect-ir", help="Build and summarize normalized IR.")
    inspect_ir_parser.add_argument("example_dir", type=Path)

    validate_parser = subparsers.add_parser("validate", help="Build IR and validate references/types.")
    validate_parser.add_argument("example_dir", type=Path)

    generate_parser = subparsers.add_parser("generate", help="Generate ROS2 workspace artifacts.")
    generate_parser.add_argument("example_dir", type=Path)
    generate_parser.add_argument("output_dir", type=Path)

    generate_parser.set_defaults(with_auto_deps=False, local_dep=False, docker_dep=False)
    generate_parser.add_argument(
        "--with-auto-deps",
        "--auto-dep",
        "--auto_dep",
        dest="with_auto_deps",
        action="store_true",
        help="Generate generated_bringup and root automation scripts/docs/tests.",
    )
    generate_parser.add_argument(
        "--no-auto-deps",
        "--no-auto-dep",
        "--no_auto_deps",
        "--no_auto_dep",
        dest="with_auto_deps",
        action="store_false",
        help="Disable generated_bringup/root automation artifacts. This is the default.",
    )
    generate_parser.add_argument(
        "--local-dep",
        "--local_dep",
        dest="local_dep",
        action="store_true",
        help="Generate local_deployment scripts/docs only. Does not require generated_bringup.",
    )
    generate_parser.add_argument(
        "--no-local-dep",
        "--no_local_dep",
        dest="local_dep",
        action="store_false",
        help="Disable local_deployment artifacts. This is the default.",
    )
    generate_parser.add_argument(
        "--docker-dep",
        "--docker_dep",
        dest="docker_dep",
        action="store_true",
        help="Generate docker_deployment scripts/docs only.",
    )
    generate_parser.add_argument(
        "--no-docker-dep",
        "--no_docker_dep",
        dest="docker_dep",
        action="store_false",
        help="Disable docker_deployment artifacts. This is the default.",
    )
    generate_parser.add_argument(
        "--ros-distro",
        default=os.environ.get("ROS_DISTRO", "humble"),
        help="ROS distro used by Dockerfile. Defaults to ROS_DISTRO env or humble.",
    )

    return parser


def _print_inspect_summary(summary: dict[str, Any]) -> None:
    print("Finalized Grammar Inspect Summary")
    print("=================================")
    for key in [
        "example_root", "general_root", "topics", "services", "applications", "segment_files",
        "nodes_in_segments", "interaction_groups", "qos_profiles", "parameter_profiles",
        "discovery_profiles", "application_map_present", "ecus_dir_present", "topology_dir_present",
    ]:
        print(f"{key}: {summary.get(key)}")
    print(f"discovery_enabled_applications: {summary.get('discovery_enabled_applications', [])}")
    print("loaded_segment_files:")
    for segment_file in summary.get("loaded_segment_files", []):
        print(f"  - {segment_file}")


def _print_ir_summary(ir: WorkspaceIR) -> None:
    graph = build_communication_graph_summary(ir)
    classification = classify_graph(graph)
    print("Workspace IR Summary")
    print("====================")
    print(f"example_name: {ir.example_name}")
    print(f"topics: {len(ir.topics)}")
    print(f"services: {len(ir.services)}")
    print(f"applications: {len(ir.applications)}")
    print(f"nodes: {len(ir.nodes)}")
    print(f"interactions: {len(ir.interactions)}")
    print(f"qos_profiles: {len(ir.qos_profiles)}")
    print(f"parameter_profiles: {len(ir.parameter_profiles)}")
    print(f"discovery_profiles: {len(ir.discovery_profiles)}")
    print("topic_patterns:")
    for topic_name, pattern in sorted(classification["topics"].items()):
        print(f"  - {topic_name}: {pattern}")
    print("service_patterns:")
    for service_name, pattern in sorted(classification["services"].items()):
        print(f"  - {service_name}: {pattern}")


def _load_and_build_ir(example_dir: Path) -> WorkspaceIR:
    return build_workspace_ir(load_finalized_grammar(example_dir))


def _handle_inspect(example_dir: Path) -> int:
    bundle = load_finalized_grammar(example_dir)
    _print_inspect_summary(summarize_grammar_bundle(bundle))
    return 0


def _handle_inspect_ir(example_dir: Path) -> int:
    _print_ir_summary(_load_and_build_ir(example_dir))
    return 0


def _handle_validate(example_dir: Path) -> int:
    ir = _load_and_build_ir(example_dir)
    warnings = validate_workspace_ir(ir)
    print(f"[OK] Validation passed for: {example_dir}")
    if warnings:
        print("Warnings:")
        for warning in warnings:
            print(f"  - {warning}")
    else:
        print("Warnings: none")
    return 0


def _handle_generate(args: argparse.Namespace) -> int:
    ir = _load_and_build_ir(args.example_dir)
    warnings = validate_workspace_ir(ir)
    template_root = Path(__file__).resolve().parent / "templates"
    options = GenerationOptions(
        with_auto_deps=bool(args.with_auto_deps),
        local_dep=bool(args.local_dep),
        docker_dep=bool(args.docker_dep),
        ros_distro=str(args.ros_distro),
    )
    created_files = generate_workspace(ir, args.output_dir, template_root, options)

    print(f"[OK] Generation completed for: {args.example_dir}")
    print(f"options.with_auto_deps: {options.with_auto_deps}")
    print(f"options.local_dep: {options.local_dep}")
    print(f"options.docker_dep: {options.docker_dep}")
    print(f"options.ros_distro: {options.ros_distro}")
    print(f"created_files: {len(created_files)}")
    for path in sorted(created_files):
        print(f"  - {path}")

    if warnings:
        print("Warnings:")
        for warning in warnings:
            print(f"  - {warning}")
    else:
        print("Warnings: none")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "inspect":
            return _handle_inspect(args.example_dir)
        if args.command == "inspect-ir":
            return _handle_inspect_ir(args.example_dir)
        if args.command == "validate":
            return _handle_validate(args.example_dir)
        if args.command == "generate":
            return _handle_generate(args)
        parser.error(f"Unsupported command: {args.command}")
        return 2
    except GeneratorError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
