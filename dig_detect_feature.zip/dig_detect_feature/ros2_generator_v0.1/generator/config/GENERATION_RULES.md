# Generator Rule Log

This file records behavior decisions made during generator development.
When ambiguity appears in grammar interpretation, freeze the rule here before implementation.

## Rule 001 — V1 Grammar Consumption Scope

**Decision:** V1 consumes only the `general/` folder for ROS2 boilerplate generation.

Consumed files:

```text
general/Interfaces_data/topics_data.yaml
general/Interfaces_data/services_data.yaml
general/apps/applications.yaml
general/apps/segments/*.yaml
general/profiles/qos_profiles.yaml
general/profiles/parameter_profiles.yaml
general/profiles/discovery_profiles.yaml
```

Retained but ignored by V1 generation:

```text
application_map.yaml
ecus/
topology/
```

Reason:
Current generator scope is ROS2 application boilerplate, not hardware flashing or deployment-aware ECU mapping.

## Rule 002 — Discovery Server Enable/Disable

**Decision:** Discovery configuration generation is controlled by `application.discovery_ref`.

Enabled:

```yaml
application:
  - name: perception_system
    discovery_ref: standard_ecu
```

Disabled:

```yaml
application:
  - name: perception_system
    nodes:
      - perception1_node
```

or:

```yaml
application:
  - name: perception_system
    discovery_ref: null
```

Validation rule for later patch:
If `discovery_ref` is present and non-null, it must match a profile in `general/profiles/discovery_profiles.yaml`.

Generated artifacts when enabled:

```text
generated_bringup/config/fastdds_discovery.xml
generated_bringup/launch/system_launch.py entries/env setup
generation_report.yaml discovery section
```

Node business logic is not affected by discovery configuration.

## Rule 003 — Empty Topics or Services

**Decision:** `topic_data: []` and `service_data: []` are valid.

Reason:
Some valid examples are service-only or parameter-only. The loader must accept empty interface groups.

## Rule 004 — Segment Files

**Decision:** At least one segment YAML file must exist under `general/apps/segments/`.

Reason:
The segment layer maps interactions to nodes and is required to generate application packages.
For parameter-only nodes, the segment file can contain `interactions: []` and node entries with empty `interactions_ref`.

## Rule 005 — QoS Profile Ownership

**Decision:** QoS profiles are assigned per communication interaction endpoint, not per node.

Valid QoS references:

```text
publisher.qos_profile
subscriber.qos_profile
service_server.qos_profile
service_client.qos_profile
```

A node may use multiple QoS profiles because it may own multiple interactions.

Validation behavior:

- Missing referenced QoS profile: error
- Unused defined QoS profile: warning

Reason:
ROS2 QoS controls behavior of each publisher/subscriber/service endpoint. Node-level QoS would be too restrictive for industrial systems.

## Rule 013 — DDS Config Is Core Output

If any application uses `discovery_ref`, generator emits the core DDS configuration at:

```text
generated_ws/config/dds/fastdds_discovery.xml
```

This file is independent of `generated_bringup` and future `docker_deployment` outputs.
Runtime should reference it through:

```bash
FASTDDS_DEFAULT_PROFILES_FILE=<generated_ws>/config/dds/fastdds_discovery.xml
```

## Rule 014 — Automation Dependencies Are Optional

Default generation is equivalent to `--no-auto-deps` and emits only core runtime packages and core DDS config.
Use `--with-auto-deps` to generate generated_bringup, scripts, runtime smoke test, and runtime docs.

## Rule 015 — Docker Deployment Is Optional

Use `--docker-dep` to generate Docker deployment artifacts under:

```text
generated_ws/docker_deployment/
```

Docker deployment runs application combined executables directly with `ros2 run`, not generated_bringup launch files.

## Rule 016 — Discovery Server Introspection Requires Super Client

For FastDDS Discovery Server inspection terminals/containers, use:

```bash
ROS_SUPER_CLIENT=true
```

Application terminals/containers use `ROS_DISCOVERY_SERVER`; inspection terminals use both `ROS_DISCOVERY_SERVER` and `ROS_SUPER_CLIENT=true`.

## Rule 017 — Optional Deployment Layers Are Independent

The generator supports three independent optional layers:

```text
--with-auto-deps  -> generated_bringup + root automation scripts/docs/tests
--local-dep       -> local_deployment only
--docker-dep      -> docker_deployment only
```

Any cross-combination is valid:

```bash
--with-auto-deps --local-dep
--with-auto-deps --docker-dep
--local-dep --docker-dep
--with-auto-deps --local-dep --docker-dep
```

`--local-dep` must not depend on `generated_bringup`.
