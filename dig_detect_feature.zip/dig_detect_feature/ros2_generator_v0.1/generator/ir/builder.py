"""
IR builder for finalized grammar.

Purpose:
    Converts raw loaded GrammarBundle YAML into normalized WorkspaceIR objects.
"""

from __future__ import annotations

from typing import Any

from generator.grammar.raw_models import GrammarBundle
from generator.ir.models import (
    ApplicationIR,
    DiscoveryProfileIR,
    DiscoveryServerIR,
    FieldIR,
    InteractionIR,
    NodeIR,
    ParameterIR,
    ParameterProfileIR,
    QoSProfileIR,
    ServiceIR,
    TopicIR,
    WorkspaceIR,
)
from generator.utils.errors import ValidationError


# --------------------------------------------------------------------------------------------------
# _require_name
# --------------------------------------------------------------------------------------------------
# Extracts a required name field from one YAML item.
# This gives consistent errors when grammar entries are incomplete.
# --------------------------------------------------------------------------------------------------
def _require_name(item: dict[str, Any], context: str) -> str:
    """Return required name field from a grammar item."""
    # A missing or empty name cannot be referenced later.
    name = item.get("name") or item.get("topic_name") or item.get("service_name")
    if not name:
        raise ValidationError(f"Missing name in {context}: {item}")
    return str(name)


# --------------------------------------------------------------------------------------------------
# _build_fields
# --------------------------------------------------------------------------------------------------
# Converts a list of field dictionaries into FieldIR objects.
# Type validation happens in type_validator to keep builder focused on normalization.
# --------------------------------------------------------------------------------------------------
def _build_fields(field_items: list[dict[str, Any]] | None) -> list[FieldIR]:
    """Build FieldIR list from raw field items."""
    # Empty field list is allowed for future extensibility, but current examples use fields.
    fields: list[FieldIR] = []
    for field_item in field_items or []:
        fields.append(FieldIR(name=str(field_item.get("name", "")), type=str(field_item.get("type", ""))))
    return fields


# --------------------------------------------------------------------------------------------------
# _build_topics
# --------------------------------------------------------------------------------------------------
# Builds topic contracts from general/Interfaces_data/topics_data.yaml.
# Topic names are used by publisher/subscriber interactions.
# --------------------------------------------------------------------------------------------------
def _build_topics(raw: dict[str, Any]) -> dict[str, TopicIR]:
    """Build topic IR dictionary keyed by topic name."""
    topics: dict[str, TopicIR] = {}
    for item in raw.get("topic_data", []) or []:
        name = str(item.get("topic_name", ""))
        topics[name] = TopicIR(name=name, path=str(item.get("topic_path", "")), fields=_build_fields(item.get("structure", [])))
    return topics


# --------------------------------------------------------------------------------------------------
# _build_services
# --------------------------------------------------------------------------------------------------
# Builds service contracts from general/Interfaces_data/services_data.yaml.
# Service names are used by service server/client interactions.
# --------------------------------------------------------------------------------------------------
def _build_services(raw: dict[str, Any]) -> dict[str, ServiceIR]:
    """Build service IR dictionary keyed by service name."""
    services: dict[str, ServiceIR] = {}
    for item in raw.get("service_data", []) or []:
        name = str(item.get("service_name", ""))
        services[name] = ServiceIR(
            name=name,
            path=str(item.get("service_path", "")),
            request_fields=_build_fields(item.get("request_structure", [])),
            response_fields=_build_fields(item.get("response_structure", [])),
        )
    return services


# --------------------------------------------------------------------------------------------------
# _build_qos_profiles
# --------------------------------------------------------------------------------------------------
# Builds QoSProfileIR objects from qos_profiles.yaml.
# QoS references are validated later against interaction usage.
# --------------------------------------------------------------------------------------------------
def _build_qos_profiles(raw: dict[str, Any]) -> dict[str, QoSProfileIR]:
    """Build QoS profile dictionary keyed by profile name."""
    profiles: dict[str, QoSProfileIR] = {}
    for item in raw.get("qos_profiles", []) or []:
        name = str(item.get("name", ""))
        profiles[name] = QoSProfileIR(
            name=name,
            reliability=str(item.get("reliability", "")),
            durability=str(item.get("durability", "")),
            history_kind=str(item.get("history_kind", "")),
            history_depth=int(item.get("history_depth", 0)),
            deadline_ms=item.get("deadline_ms"),
            lifespan_ms=item.get("lifespan_ms"),
        )
    return profiles


# --------------------------------------------------------------------------------------------------
# _build_parameter_profiles
# --------------------------------------------------------------------------------------------------
# Builds reusable parameter profiles from parameter_profiles.yaml.
# Nodes reference these profiles through parameter_ref.
# --------------------------------------------------------------------------------------------------
def _build_parameter_profiles(raw: dict[str, Any]) -> dict[str, ParameterProfileIR]:
    """Build parameter profile dictionary keyed by profile name."""
    profiles: dict[str, ParameterProfileIR] = {}
    for item in raw.get("parameter_profiles", []) or []:
        params: list[ParameterIR] = []
        for param in item.get("parameters", []) or []:
            params.append(
                ParameterIR(
                    name=str(param.get("name", "")),
                    type=str(param.get("type", "")),
                    default=param.get("default"),
                    minimum=param.get("min"),
                    maximum=param.get("max"),
                    dynamic=bool(param.get("dynamic", False)),
                )
            )
        name = str(item.get("name", ""))
        profiles[name] = ParameterProfileIR(name=name, description=str(item.get("description", "")), parameters=params)
    return profiles


# --------------------------------------------------------------------------------------------------
# _build_discovery_profiles
# --------------------------------------------------------------------------------------------------
# Builds discovery profiles from discovery_profiles.yaml.
# Applications enable discovery by referencing these profiles.
# --------------------------------------------------------------------------------------------------
def _build_discovery_profiles(raw: dict[str, Any]) -> dict[str, DiscoveryProfileIR]:
    """Build discovery profile dictionary keyed by profile name."""
    profiles: dict[str, DiscoveryProfileIR] = {}
    for item in raw.get("discovery_profiles", []) or []:
        servers: list[DiscoveryServerIR] = []
        for server in item.get("discovery_servers", []) or []:
            servers.append(
                DiscoveryServerIR(
                    server_id=int(server.get("server_id", 0)),
                    ip=str(server.get("ip", "")),
                    port=int(server.get("port", 0)),
                )
            )
        name = str(item.get("name", ""))
        profiles[name] = DiscoveryProfileIR(
            name=name,
            domain_id=int(item.get("domain_id", 0)),
            mode=str(item.get("mode", "")),
            discovery_servers=servers,
        )
    return profiles


# --------------------------------------------------------------------------------------------------
# _build_applications
# --------------------------------------------------------------------------------------------------
# Builds ApplicationIR objects from applications.yaml.
# application.nodes will later be validated against nodes declared in segment files.
# --------------------------------------------------------------------------------------------------
def _build_applications(raw: dict[str, Any]) -> dict[str, ApplicationIR]:
    """Build application dictionary keyed by application name."""
    applications: dict[str, ApplicationIR] = {}
    for item in raw.get("application", []) or []:
        name = str(item.get("name", ""))
        discovery_ref = item.get("discovery_ref")
        applications[name] = ApplicationIR(
            name=name,
            discovery_ref=None if discovery_ref in (None, "") else str(discovery_ref),
            node_names=[str(node_name) for node_name in item.get("nodes", []) or []],
        )
    return applications


# --------------------------------------------------------------------------------------------------
# _build_interactions_and_nodes
# --------------------------------------------------------------------------------------------------
# Builds interactions and nodes from all segment YAML files.
# Interaction references are resolved later during reference validation.
# --------------------------------------------------------------------------------------------------
def _build_interactions_and_nodes(segments: dict[str, dict[str, Any]]) -> tuple[dict[str, InteractionIR], dict[str, NodeIR]]:
    """Build interaction and node dictionaries from segment files."""
    interactions: dict[str, InteractionIR] = {}
    nodes: dict[str, NodeIR] = {}

    for source_file, raw_segment_file in segments.items():
        # Build interaction entries under segments[].interactions[].
        for segment_entry in raw_segment_file.get("segments", []) or []:
            segment_name = str(segment_entry.get("name", ""))
            for interaction_group in segment_entry.get("interactions", []) or []:
                for kind, entries in interaction_group.items():
                    for entry in entries or []:
                        interaction_name = str(entry.get("name", ""))
                        reference_name = str(entry.get("topic_name") or entry.get("service_name") or "")
                        interactions[interaction_name] = InteractionIR(
                            name=interaction_name,
                            kind=str(kind),
                            reference_name=reference_name,
                            qos_profile=str(entry.get("qos_profile", "")),
                            segment_name=segment_name,
                            source_file=source_file,
                        )

        # Build node entries under top-level node key.
        for node_entry in raw_segment_file.get("node", []) or []:
            node_name = str(node_entry.get("name", ""))
            parameter_ref = node_entry.get("parameter_ref")
            nodes[node_name] = NodeIR(
                name=node_name,
                parameter_ref=None if parameter_ref in (None, "") else str(parameter_ref),
                interaction_refs=[str(ref) for ref in node_entry.get("interactions_ref", []) or []],
                segment_name="",
                source_file=source_file,
            )

    return interactions, nodes


# --------------------------------------------------------------------------------------------------
# build_workspace_ir
# --------------------------------------------------------------------------------------------------
# Converts raw GrammarBundle into WorkspaceIR.
# This is the main function used by validate/inspect-ir/generation flows.
# --------------------------------------------------------------------------------------------------
def build_workspace_ir(bundle: GrammarBundle) -> WorkspaceIR:
    """Build normalized WorkspaceIR from raw grammar bundle."""
    # Build each major IR domain independently to keep logic easy to test.
    topics = _build_topics(bundle.topics_data)
    services = _build_services(bundle.services_data)
    qos_profiles = _build_qos_profiles(bundle.qos_profiles)
    parameter_profiles = _build_parameter_profiles(bundle.parameter_profiles)
    discovery_profiles = _build_discovery_profiles(bundle.discovery_profiles)
    applications = _build_applications(bundle.applications)
    interactions, nodes = _build_interactions_and_nodes(bundle.segments)

    # Return immutable top-level workspace IR for downstream validation/planning.
    return WorkspaceIR(
        example_name=bundle.paths.example_root.name,
        topics=topics,
        services=services,
        qos_profiles=qos_profiles,
        parameter_profiles=parameter_profiles,
        discovery_profiles=discovery_profiles,
        applications=applications,
        interactions=interactions,
        nodes=nodes,
        segment_files=sorted(bundle.segments.keys()),
    )
