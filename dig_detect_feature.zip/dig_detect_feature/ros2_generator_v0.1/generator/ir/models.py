"""
Intermediate Representation models.

Purpose:
    Defines normalized, generator-friendly data structures derived from the finalized grammar.
    Templates and planners should consume these IR classes instead of raw YAML dictionaries.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

InteractionKind = Literal["publisher", "subscriber", "service_server", "service_client"]


# --------------------------------------------------------------------------------------------------
# FieldIR
# --------------------------------------------------------------------------------------------------
# Represents one field in a generated .msg or .srv interface.
# The type remains grammar-style at this layer and is validated by type_validator.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class FieldIR:
    """One message/service field."""

    name: str
    type: str


# --------------------------------------------------------------------------------------------------
# TopicIR
# --------------------------------------------------------------------------------------------------
# Represents one topic contract from topics_data.yaml.
# This object is later used to generate custom .msg files and endpoint bindings.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class TopicIR:
    """One topic interface contract."""

    name: str
    path: str
    fields: list[FieldIR]


# --------------------------------------------------------------------------------------------------
# ServiceIR
# --------------------------------------------------------------------------------------------------
# Represents one service contract from services_data.yaml.
# This object is later used to generate custom .srv files and server/client bindings.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ServiceIR:
    """One service interface contract."""

    name: str
    path: str
    request_fields: list[FieldIR]
    response_fields: list[FieldIR]


# --------------------------------------------------------------------------------------------------
# QoSProfileIR
# --------------------------------------------------------------------------------------------------
# Represents one QoS profile from qos_profiles.yaml.
# QoS is assigned per interaction endpoint, not per node.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class QoSProfileIR:
    """One named QoS profile."""

    name: str
    reliability: str
    durability: str
    history_kind: str
    history_depth: int
    deadline_ms: int | None = None
    lifespan_ms: int | None = None


# --------------------------------------------------------------------------------------------------
# ParameterIR
# --------------------------------------------------------------------------------------------------
# Represents one generated ROS2 parameter with optional validation metadata.
# Parameters belong to profiles, and nodes reference profiles by name.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ParameterIR:
    """One parameter definition."""

    name: str
    type: str
    default: object
    dynamic: bool = False
    minimum: object | None = None
    maximum: object | None = None


# --------------------------------------------------------------------------------------------------
# ParameterProfileIR
# --------------------------------------------------------------------------------------------------
# Represents a reusable parameter profile from parameter_profiles.yaml.
# Multiple nodes may reference the same profile.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ParameterProfileIR:
    """Named group of parameters."""

    name: str
    description: str
    parameters: list[ParameterIR]


# --------------------------------------------------------------------------------------------------
# DiscoveryServerIR
# --------------------------------------------------------------------------------------------------
# Represents one discovery server endpoint under a discovery profile.
# This is used for future FastDDS config generation.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DiscoveryServerIR:
    """One discovery server endpoint."""

    server_id: int
    ip: str
    port: int


# --------------------------------------------------------------------------------------------------
# DiscoveryProfileIR
# --------------------------------------------------------------------------------------------------
# Represents one discovery profile referenced by applications.yaml.
# If an application references this profile, discovery config generation is enabled.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DiscoveryProfileIR:
    """One discovery profile."""

    name: str
    domain_id: int
    mode: str
    discovery_servers: list[DiscoveryServerIR]


# --------------------------------------------------------------------------------------------------
# InteractionIR
# --------------------------------------------------------------------------------------------------
# Represents a publisher/subscriber/service server/service client interaction.
# reference_name points to a topic name for pub/sub and service name for server/client.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class InteractionIR:
    """One communication endpoint declared in a segment file."""

    name: str
    kind: InteractionKind
    reference_name: str
    qos_profile: str
    segment_name: str
    source_file: str


# --------------------------------------------------------------------------------------------------
# NodeIR
# --------------------------------------------------------------------------------------------------
# Represents one ROS2 node and its resolved interaction names.
# Interactions remain references here and are resolved during validation/planning.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class NodeIR:
    """One node entry from a segment file."""

    name: str
    parameter_ref: str | None
    interaction_refs: list[str]
    segment_name: str
    source_file: str


# --------------------------------------------------------------------------------------------------
# ApplicationIR
# --------------------------------------------------------------------------------------------------
# Represents one application block from applications.yaml.
# discovery_ref controls discovery config generation according to Rule 002.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ApplicationIR:
    """One application/system definition."""

    name: str
    discovery_ref: str | None
    node_names: list[str]


# --------------------------------------------------------------------------------------------------
# WorkspaceIR
# --------------------------------------------------------------------------------------------------
# Top-level IR object containing all loaded and normalized generator concepts.
# This becomes the source of truth for validation, planning, and generation.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class WorkspaceIR:
    """Complete normalized IR for one grammar example."""

    example_name: str
    topics: dict[str, TopicIR] = field(default_factory=dict)
    services: dict[str, ServiceIR] = field(default_factory=dict)
    qos_profiles: dict[str, QoSProfileIR] = field(default_factory=dict)
    parameter_profiles: dict[str, ParameterProfileIR] = field(default_factory=dict)
    discovery_profiles: dict[str, DiscoveryProfileIR] = field(default_factory=dict)
    applications: dict[str, ApplicationIR] = field(default_factory=dict)
    interactions: dict[str, InteractionIR] = field(default_factory=dict)
    nodes: dict[str, NodeIR] = field(default_factory=dict)
    segment_files: list[str] = field(default_factory=list)
