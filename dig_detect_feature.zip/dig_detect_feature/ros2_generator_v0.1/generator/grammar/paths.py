"""
Finalized grammar path constants.

Purpose:
    Centralizes expected input file names for the team-finalized grammar.
    V1 generation consumes only general/ while retaining awareness of optional future folders.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


# --------------------------------------------------------------------------------------------------
# GeneralGrammarPaths
# --------------------------------------------------------------------------------------------------
# Holds all V1-consumed file paths under an example grammar directory.
# The generator uses this object instead of hardcoding paths across modules.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class GeneralGrammarPaths:
    """Resolved finalized grammar paths for V1 general/ consumption."""

    example_root: Path
    general_root: Path
    topics_data: Path
    services_data: Path
    applications: Path
    segments_dir: Path
    qos_profiles: Path
    parameter_profiles: Path
    discovery_profiles: Path
    application_map: Path
    ecus_dir: Path
    topology_dir: Path


# --------------------------------------------------------------------------------------------------
# resolve_general_grammar_paths
# --------------------------------------------------------------------------------------------------
# Resolves all finalized grammar paths from an example root directory.
# This function does not load files; it only constructs canonical filesystem paths.
# --------------------------------------------------------------------------------------------------
def resolve_general_grammar_paths(example_root: Path) -> GeneralGrammarPaths:
    """Resolve expected finalized grammar paths from an example root.

    Args:
        example_root: Example directory such as examples/01_single_publisher.

    Returns:
        GeneralGrammarPaths with all expected V1 and future-reference paths.
    """
    # Convert to Path so callers may pass strings or Path values.
    example_root = Path(example_root)

    # The V1 generator consumes only this folder for ROS2 boilerplate generation.
    general_root = example_root / "general"

    # Return a single immutable object so downstream code remains explicit.
    return GeneralGrammarPaths(
        example_root=example_root,
        general_root=general_root,
        topics_data=general_root / "Interfaces_data" / "topics_data.yaml",
        services_data=general_root / "Interfaces_data" / "services_data.yaml",
        applications=general_root / "apps" / "applications.yaml",
        segments_dir=general_root / "apps" / "segments",
        qos_profiles=general_root / "profiles" / "qos_profiles.yaml",
        parameter_profiles=general_root / "profiles" / "parameter_profiles.yaml",
        discovery_profiles=general_root / "profiles" / "discovery_profiles.yaml",
        application_map=example_root / "application_map.yaml",
        ecus_dir=example_root / "ecus",
        topology_dir=example_root / "topology",
    )
