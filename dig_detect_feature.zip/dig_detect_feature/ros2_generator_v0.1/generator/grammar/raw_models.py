"""
Raw grammar data models.

Purpose:
    Stores loaded YAML content exactly close to source grammar before IR conversion.
    IR builder and validators will consume this bundle in later patches.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from generator.grammar.paths import GeneralGrammarPaths


# --------------------------------------------------------------------------------------------------
# GrammarBundle
# --------------------------------------------------------------------------------------------------
# Container for all YAML content loaded from one finalized grammar example.
# This is intentionally raw and does not enforce semantic correctness yet.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class GrammarBundle:
    """Raw loaded finalized grammar bundle."""

    paths: GeneralGrammarPaths
    topics_data: dict[str, Any]
    services_data: dict[str, Any]
    applications: dict[str, Any]
    segments: dict[str, dict[str, Any]]
    qos_profiles: dict[str, Any]
    parameter_profiles: dict[str, Any]
    discovery_profiles: dict[str, Any]

    # application_map/ecus/topology are intentionally not consumed by V1 generation.
    application_map_exists: bool
    ecus_dir_exists: bool
    topology_dir_exists: bool


# --------------------------------------------------------------------------------------------------
# LoadedSegmentFile
# --------------------------------------------------------------------------------------------------
# Small helper model for reporting segment file information.
# This is useful for inspect output and later diagnostics.
# --------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class LoadedSegmentFile:
    """Metadata about one loaded segment YAML file."""

    path: Path
    content: dict[str, Any]
