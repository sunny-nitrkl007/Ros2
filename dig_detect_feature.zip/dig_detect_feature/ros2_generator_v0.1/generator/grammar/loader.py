"""
Finalized grammar loader.

Purpose:
    Loads the team-finalized grammar from an example directory.
    V1 consumes only the general/ folder while recording whether application_map.yaml,
    ecus/, and topology/ are present for future deployment-aware generation.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from generator.grammar.paths import resolve_general_grammar_paths
from generator.grammar.raw_models import GrammarBundle
from generator.utils.errors import GrammarLoadError
from generator.utils.yaml_utils import load_yaml_file


# --------------------------------------------------------------------------------------------------
# _ensure_directory
# --------------------------------------------------------------------------------------------------
# Validates that a required directory exists before loading files from it.
# Keeping this check separate helps produce exact error messages for users.
# --------------------------------------------------------------------------------------------------
def _ensure_directory(path: Path, label: str) -> None:
    """Ensure a required directory exists."""
    # Missing directories mean the example does not follow finalized grammar structure.
    if not path.exists():
        raise GrammarLoadError(f"Missing required {label} directory: {path}")

    # If the path exists but is not a directory, loading cannot continue safely.
    if not path.is_dir():
        raise GrammarLoadError(f"Expected {label} to be a directory: {path}")


# --------------------------------------------------------------------------------------------------
# _load_segment_files
# --------------------------------------------------------------------------------------------------
# Loads all segment YAML files from general/apps/segments.
# The finalized grammar allows multiple segment files, one or more per application/system.
# --------------------------------------------------------------------------------------------------
def _load_segment_files(segments_dir: Path) -> dict[str, dict[str, Any]]:
    """Load all segment YAML files from the segments directory."""
    # Validate the directory before globbing for YAML files.
    _ensure_directory(segments_dir, "segments")

    # Gather YAML files in deterministic order for stable output and tests.
    segment_files = sorted(list(segments_dir.glob("*.yaml")) + list(segments_dir.glob("*.yml")))

    # A grammar without segment files cannot define node interactions for V1 generation.
    if not segment_files:
        raise GrammarLoadError(f"No segment YAML files found in: {segments_dir}")

    loaded_segments: dict[str, dict[str, Any]] = {}
    for segment_file in segment_files:
        # Load each segment file and key it by filename for traceability.
        loaded_segments[segment_file.name] = load_yaml_file(segment_file)

    return loaded_segments


# --------------------------------------------------------------------------------------------------
# load_finalized_grammar
# --------------------------------------------------------------------------------------------------
# Loads the finalized grammar files required for V1 generation.
# This function intentionally does not perform semantic validation; it only loads raw YAML safely.
# --------------------------------------------------------------------------------------------------
def load_finalized_grammar(example_root: Path) -> GrammarBundle:
    """Load finalized grammar from an example directory.

    Args:
        example_root: Path to one example directory under examples/.

    Returns:
        GrammarBundle containing raw YAML dictionaries and path metadata.

    Raises:
        GrammarLoadError: If required files or directories are missing/malformed.
    """
    # Normalize input so downstream path operations are consistent.
    example_root = Path(example_root)

    # The example root must exist and be a directory.
    _ensure_directory(example_root, "example root")

    # Resolve every expected path from the example root.
    paths = resolve_general_grammar_paths(example_root)

    # V1 strictly requires the general/ directory.
    _ensure_directory(paths.general_root, "general")

    # Load all required V1 YAML files.
    topics_data = load_yaml_file(paths.topics_data)
    services_data = load_yaml_file(paths.services_data)
    applications = load_yaml_file(paths.applications)
    qos_profiles = load_yaml_file(paths.qos_profiles)
    parameter_profiles = load_yaml_file(paths.parameter_profiles)
    discovery_profiles = load_yaml_file(paths.discovery_profiles)

    # Load one or more segment files.
    segments = _load_segment_files(paths.segments_dir)

    # Record optional/future folder presence without consuming them for V1 generation.
    return GrammarBundle(
        paths=paths,
        topics_data=topics_data,
        services_data=services_data,
        applications=applications,
        segments=segments,
        qos_profiles=qos_profiles,
        parameter_profiles=parameter_profiles,
        discovery_profiles=discovery_profiles,
        application_map_exists=paths.application_map.exists(),
        ecus_dir_exists=paths.ecus_dir.exists() and paths.ecus_dir.is_dir(),
        topology_dir_exists=paths.topology_dir.exists() and paths.topology_dir.is_dir(),
    )


# --------------------------------------------------------------------------------------------------
# summarize_grammar_bundle
# --------------------------------------------------------------------------------------------------
# Produces a compact summary of loaded raw grammar.
# This powers the inspect CLI and provides a useful smoke test before IR development.
# --------------------------------------------------------------------------------------------------
def summarize_grammar_bundle(bundle: GrammarBundle) -> dict[str, Any]:
    """Create a human-readable summary dictionary for a loaded grammar bundle."""
    # Extract top-level lists defensively. Schema validation will become stricter later.
    topic_items = bundle.topics_data.get("topic_data", []) if isinstance(bundle.topics_data, dict) else []
    service_items = bundle.services_data.get("service_data", []) if isinstance(bundle.services_data, dict) else []
    application_items = bundle.applications.get("application", []) if isinstance(bundle.applications, dict) else []
    qos_items = bundle.qos_profiles.get("qos_profiles", []) if isinstance(bundle.qos_profiles, dict) else []
    parameter_items = bundle.parameter_profiles.get("parameter_profiles", []) if isinstance(bundle.parameter_profiles, dict) else []
    discovery_items = bundle.discovery_profiles.get("discovery_profiles", []) if isinstance(bundle.discovery_profiles, dict) else []

    # Count segment-level node and interaction groups using raw YAML shape.
    segment_count = len(bundle.segments)
    node_count = 0
    interaction_group_count = 0
    for segment_data in bundle.segments.values():
        # Count nodes listed under top-level node key.
        if isinstance(segment_data, dict):
            node_count += len(segment_data.get("node", []) or [])
            for segment_entry in segment_data.get("segments", []) or []:
                if isinstance(segment_entry, dict):
                    interaction_group_count += len(segment_entry.get("interactions", []) or [])

    # Discovery is enabled if any application has a non-empty discovery_ref.
    discovery_enabled_apps = []
    for app in application_items or []:
        if isinstance(app, dict) and app.get("discovery_ref"):
            discovery_enabled_apps.append(app.get("name", "<unnamed>"))

    # Return a raw summary for CLI formatting and tests.
    return {
        "example_root": str(bundle.paths.example_root),
        "general_root": str(bundle.paths.general_root),
        "topics": len(topic_items or []),
        "services": len(service_items or []),
        "applications": len(application_items or []),
        "segment_files": segment_count,
        "nodes_in_segments": node_count,
        "interaction_groups": interaction_group_count,
        "qos_profiles": len(qos_items or []),
        "parameter_profiles": len(parameter_items or []),
        "discovery_profiles": len(discovery_items or []),
        "discovery_enabled_applications": discovery_enabled_apps,
        "application_map_present": bundle.application_map_exists,
        "ecus_dir_present": bundle.ecus_dir_exists,
        "topology_dir_present": bundle.topology_dir_exists,
        "loaded_segment_files": sorted(bundle.segments.keys()),
    }
