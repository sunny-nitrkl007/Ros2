# Actions Support

Status: Scaffolded for future versions.

## Purpose

This folder is reserved for future implementation. The current V1 generator focuses on the finalized
`general/` grammar and supports publishers, subscribers, service servers, service clients,
parameters, QoS, custom messages, custom services, and discovery-server configuration.

## Suggested Future Grammar

```yaml
actions:
  - name: navigate_to_pose
    action_name: /robot/navigate_to_pose
    action_type: generated_interfaces/action/NavigateToPose
    role: server
```

## Implementation Notes

Add ActionIR, action validation, action templates, action server/client generation, feedback/cancel/result handling.

## Developer Guidance

- Add IR models in `generator/ir/models.py` or a dedicated future IR file.
- Add semantic/reference validation under `generator/validation/`.
- Add generation planning under `generator/planning/`.
- Add templates under `generator/templates/future/`.
- Keep templates simple; put intelligence in loader, IR, validation, and planning layers.
