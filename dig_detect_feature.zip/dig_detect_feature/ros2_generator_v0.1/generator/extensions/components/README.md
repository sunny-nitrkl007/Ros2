# Component Node Support

Status: Scaffolded for future versions.

## Purpose

This folder is reserved for future implementation. The current V1 generator focuses on the finalized
`general/` grammar and supports publishers, subscribers, service servers, service clients,
parameters, QoS, custom messages, custom services, and discovery-server configuration.

## Suggested Future Grammar

```yaml
nodes:
  - name: perception_component
    node_type: component
    component:
      plugin_name: perception_system::PerceptionComponent
```

## Implementation Notes

Add rclcpp_components registration, pluginlib exports, component containers, and component launch files.

## Developer Guidance

- Add IR models in `generator/ir/models.py` or a dedicated future IR file.
- Add semantic/reference validation under `generator/validation/`.
- Add generation planning under `generator/planning/`.
- Add templates under `generator/templates/future/`.
- Keep templates simple; put intelligence in loader, IR, validation, and planning layers.
