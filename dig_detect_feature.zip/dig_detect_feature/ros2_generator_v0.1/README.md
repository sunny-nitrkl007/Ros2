# ROS2 Generator Tool

A scalable grammar-driven ROS2 boilerplate generator.

## Layer-1 Structure

```text
ros2_generator_v0.1/
├── examples
├── generator
├── GUIDE.md
├── output
├── PROJECT_NOTES.md
├── README.md
├── requirements.txt
├── ros2_schema
└── VERSION
```

## Current Scope

This version targets the structured yaml grammar and generates ROS2 infrastructure code for:

- publishers
- subscribers
- service servers
- service clients
- custom messages
- custom services
- parameters
- QoS profiles
- discovery-server configuration
- launch/build/config/test/report artifacts

## Setup schema

To set up the schema environment, navigate to the `ros2_schema/` directory and install the dependencies using Poetry:

```bash
cd ros2_schema/
```

#### Ensure you are using Python 3.12
```bash
poetry install
```

## Validating Examples

The `ros2_schema/examples/` directory contains various DDS configurations. You can validate these examples using the provided helper script:

## From the ros2_schema/ directory
```bash
poetry run python src/schema/sdk/helpers/validate_examples.py
```

## Usage Target

Go to tool root

```bash
python3 -m generator.main generate examples/01_demo_simple_pubsub output
```

Generated output target:

```text
output/<example_name>/generated_ws/
```

## Developer Business Logic

Generated C++ code contain clearly marked user regions:

```cpp
// ============================================================================
// USER BUSINESS LOGIC START
// Add custom business logic here.
// ============================================================================

// TODO(user): implement business logic.

// ============================================================================
// USER BUSINESS LOGIC END
// ============================================================================
```
# Tool Overview

## What Is ros2_generator?

`ros2_generator` is a ROS 2 workspace generator driven by finalized grammar input.

The tool generates ROS 2 packages, interfaces, C++ boilerplate, optional bringup scripts, optional local deployment scripts, and optional Docker deployment scripts.

## Input

The input is a finalized grammar example directory.

Example:

~~~~bash
examples/01_demo_simple_pubsub
~~~~

The grammar may describe:

~~~~text
applications
nodes
topics
services
parameters
QoS profiles
discovery profiles
communication interactions
application-to-node mappings
~~~~

## Output

The output is a generated ROS 2 workspace.

Example:

~~~~text
output/mesh_app/generated_ws
~~~~

Depending on the selected flags, the workspace may contain:

~~~~text
config/
src/
local_deployment/
docker_deployment/
build.sh
test_build.sh
run.sh
runtime_smoke_test.sh
~~~~

## Main Generated Components

### Interface Package

Generated under:

~~~~text
src/generated_interfaces/
~~~~

This package contains generated message and service definitions.

### Application Packages

Example generated packages:

~~~~text
src/perception_system/
src/planning_system/
src/safety_system/
~~~~

### Combined Executables

For ECU-style demos, each application receives a combined executable.

Example:

~~~~text
perception_system_combined
planning_system_combined
safety_system_combined
~~~~

These executables allow the demo to show each application as a single process or container.

## 5. Optional Generation Layers

### Automation / Bringup Layer

Enabled by:

~~~~bash
--with-auto-deps
~~~~

Adds generated bringup and root-level automation scripts.

### Local Deployment Layer

Enabled by:

~~~~bash
--local-dep
~~~~

Adds local deployment scripts.

### Docker Deployment Layer

Enabled by:

~~~~bash
--docker-dep
~~~~

Adds Docker deployment scripts.

## Design Principle

The current baseline keeps optional layers independent.

~~~~text
core generation
automation generation
local deployment generation
docker deployment generation
~~~~

This allows the user to generate exactly what is needed for a given scenario.

## Architecture overview 

To be viewed in Preview mode for diagram's visibility.

## 1. High-Level Generator Flow

```mermaid
flowchart LR
    A["Frontend<br/>YAML Grammar Loader"] --> B["Middle-End<br/>IR + Validation + Analysis"]
    B --> C["Planning<br/>Packages + Dependencies + Artifacts"]
    C --> D["Backends<br/>ROS 2 Code + Config + Deployment"]
    D --> E["Output<br/>Generated Workspace"]
```

## 2. ROS 2 Layered Runtime View

The generated code sits above the standard ROS 2 runtime stack.

```mermaid
flowchart TB
    A["Developer Business Logic<br/>perception / planning / control / safety"]
    B["Generated ROS 2 Skeleton API<br/>nodes, callbacks, user regions"]
    C["Generated Interfaces<br/>.msg / .srv types"]
    D["ROS 2 Client Library<br/>rclcpp, rosidl, launch"]
    E["RMW / DDS Middleware<br/>discovery, QoS, serialization, transport"]
    F["OS / Network / Deployment<br/>Linux, Docker, local runtime"]

    A --> B
    B --> C
    C --> D
    D --> E
    E --> F
```


## 3. Generated Publisher/Subscriber Runtime Path

```mermaid
flowchart LR
    A["Generated Publisher Node<br/>rclcpp::Node"] --> B["create_publisher&lt;Msg&gt;"]
    B --> C["publish(msg)"]
    C --> D["ROS 2 Topic"]
    D --> E["RMW / DDS<br/>Discovery + Transport"]
    E --> F["create_subscription&lt;Msg&gt;"]
    F --> G["Generated Subscriber Node<br/>callback skeleton"]
```

## 4. Generated Publisher/Subscriber Runtime Path

```mermaid
flowchart LR
    A["Generated Publisher Node<br/>rclcpp::Node"] --> B["create_publisher&lt;Msg&gt;"]
    B --> C["publish(msg)"]
    C --> D["ROS 2 Topic"]
    D --> E["RMW / DDS<br/>Discovery + Transport"]
    E --> F["create_subscription&lt;Msg&gt;"]
    F --> G["Generated Subscriber Node<br/>callback skeleton"]
```
## 5. Generated Service Runtime Path

```mermaid
flowchart LR
    A["Generated Service Client"] --> B["create_client&lt;Srv&gt;"]
    B --> C["async_send_request()"]
    C --> D["ROS 2 Service Graph"]
    D --> E["create_service&lt;Srv&gt;"]
    E --> F["Generated Service Server Callback"]
    F --> G["Typed Service Response"]
```
## 6. Discovery Server Flow

```mermaid
flowchart TD
    DS["Fast DDS Discovery Server"]

    P["perception_system<br/>ROS 2 participant"]
    PL["planning_system<br/>ROS 2 participant"]
    S["safety_system<br/>ROS 2 participant"]
    I["inspector<br/>ROS 2 participant"]

    P -->|"registers discovery info"| DS
    PL -->|"registers discovery info"| DS
    S -->|"registers discovery info"| DS
    I -->|"registers discovery info"| DS

    DS -->|"shares matching endpoint info"| P
    DS -->|"shares matching endpoint info"| PL
    DS -->|"shares matching endpoint info"| S
    DS -->|"shares matching endpoint info"| I

    P -. "actual topic/service data uses DDS/RMW" .-> PL
    PL -. "actual topic/service data uses DDS/RMW" .-> S
    S -. "actual topic/service data uses DDS/RMW" .-> P
```
