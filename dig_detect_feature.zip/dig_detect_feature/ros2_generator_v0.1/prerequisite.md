# ros2_generator Prerequisites and Setup

This guide lists the software required to validate the YAML grammar, run `ros2_generator`, build the generated workspace, and run the generated ROS 2 application.

## 1. Required Software

### Operating System

- Ubuntu 22.04 LTS is recommended for ROS 2 Humble.
- Ubuntu 24.04 LTS is recommended for ROS 2 Jazzy.

### Core Tools

- Git
- Python
- `pip` and Python virtual environments
- CMake and standard C/C++ build tools
- ROS 2 Humble Desktop or ROS Base
- `colcon` build tools
- Docker and Docker Compose plugin, if Docker deployment is used

### Required Python Packages

The generator and schema tooling use the following main packages:

- `jinja2` — renders generated source and configuration files
- `PyYAML` — reads YAML grammar files
- `pydantic` — validates typed configuration models
- `pydantic-yaml` — connects YAML input with Pydantic models
- `pydantic-extra-types` — provides additional validated types
- `rich` — formatted command-line output
- `typer` and `click` — command-line interface support
- `prettytable` — tabular terminal output
- `semver` — semantic-version handling
- `platformdirs` and `filelock` — platform paths and safe file operations

> Install dependencies from the repository-provided `requirements.txt`

## 2. Install System Packages

```bash
sudo apt update
sudo apt install -y \
  git \
  python3 \
  python3-pip \
  build-essential \
  cmake \
  curl
```

Verify:

```bash
git --version
python3 --version
pip3 --version
cmake --version
```

## 3. Install ROS 2 Humble/Jazzy whichever is relevant

Install ROS 2 Humble/Jazzy using the approved project or official ROS 2 installation procedure.

After installation, source ROS 2:

```bash
source /opt/ros/humble/setup.bash

or 

source /opt/ros/jazzy/setup.bash
```

Install common build tools:

```bash
sudo apt install -y \
  python3-colcon-common-extensions \
  python3-rosdep
```

Initialize `rosdep` once:

```bash
sudo rosdep init
rosdep update
```

Verify:

```bash
ros2 --help
colcon --help
```

> Add `source /opt/ros/humble/setup.bash` to `~/.bashrc` if ROS 2 should be sourced automatically in every terminal.

### Preferred installation

If the repository contains `requirements.txt`:

```bash
pip install -r requirements.txt
```

If the repository uses `pyproject.toml` and Poetry:

```bash
pip install poetry
poetry install
```

### Manual minimum installation

Use this only when no repository dependency file is available:

```bash
pip install \
  jinja2 \
  PyYAML \
  pydantic \
  pydantic-yaml \
  pydantic-extra-types \
  rich \
  typer \
  click \
  prettytable \
  semver \
  platformdirs \
  filelock
```

Verify imports:

```bash
python -c "import jinja2, yaml, pydantic; print('Python dependencies OK')"
```

