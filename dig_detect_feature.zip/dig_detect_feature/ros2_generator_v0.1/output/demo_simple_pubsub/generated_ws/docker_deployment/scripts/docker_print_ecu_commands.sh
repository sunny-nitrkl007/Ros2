#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source ./scripts/docker_cmd_lib.sh
echo "Open separate Ubuntu/Linux terminals and run:"
echo ""
echo "# T1 discovery_server"
echo "cd '$PWD' && $DOCKER_CMD compose up --no-deps discovery_server"
echo ""
echo "# ECU terminal: simple_talker_app"
echo "cd '$PWD' && $DOCKER_CMD compose up --no-deps simple_talker_app"
echo ""
echo "# ECU terminal: simple_listener_app"
echo "cd '$PWD' && $DOCKER_CMD compose up --no-deps simple_listener_app"
echo ""
echo "# Optional inspector"
echo "cd '$PWD' && ./scripts/docker_exec_shell.sh inspector"