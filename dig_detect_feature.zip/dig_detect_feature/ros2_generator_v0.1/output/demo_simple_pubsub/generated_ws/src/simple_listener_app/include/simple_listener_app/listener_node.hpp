#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/simple_status.hpp"

namespace simple_listener_app
{

/**
 * @brief Generated ROS2 node class for `listener_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class ListenerNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit ListenerNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();


  /**
   * @brief Generated subscriber callback for `subscribe_simple_status`.
   */
  void on_subscribe_simple_status(generated_interfaces::msg::SimpleStatus::SharedPtr msg);



  rclcpp::Subscription<generated_interfaces::msg::SimpleStatus>::SharedPtr subscribe_simple_status_subscriber_;
};

}  // namespace simple_listener_app