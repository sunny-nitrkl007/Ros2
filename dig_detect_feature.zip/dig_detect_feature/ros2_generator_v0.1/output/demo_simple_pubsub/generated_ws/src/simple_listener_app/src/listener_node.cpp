#include "simple_listener_app/listener_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace simple_listener_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

ListenerNode::ListenerNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("listener_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: listener_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
}

void ListenerNode::declare_generated_parameters()
{
  this->declare_parameter<bool>("enable_debug_logging", true);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: enable_debug_logging");
}

void ListenerNode::setup_publishers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO PUBLISHERS: listener_node");
}

void ListenerNode::setup_subscribers()
{
  auto qos_subscribe_simple_status = make_qos(10, "reliable", "volatile");
  subscribe_simple_status_subscriber_ = this->create_subscription<generated_interfaces::msg::SimpleStatus>("/demo/simple_status", qos_subscribe_simple_status, std::bind(&ListenerNode::on_subscribe_simple_status, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_simple_status <- /demo/simple_status");
}

void ListenerNode::setup_service_servers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE SERVERS: listener_node");
}

void ListenerNode::setup_service_clients()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE CLIENTS: listener_node");
}


void ListenerNode::on_subscribe_simple_status(generated_interfaces::msg::SimpleStatus::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /demo/simple_status");
}



}  // namespace simple_listener_app