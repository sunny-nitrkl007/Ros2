#include "simple_talker_app/talker_node.hpp"

#include "rclcpp/rclcpp.hpp"

/**
 * @brief Starts executable for generated node `talker_node`.
 *
 * This main function is generated infrastructure and should normally not be edited.
 */
int main(int argc, char ** argv)
{
  // Initialize ROS2 runtime for this executable.
  rclcpp::init(argc, argv);

  // Create the generated node instance.
  auto node = std::make_shared<simple_talker_app::TalkerNode>();

  // Spin the node using the default single-threaded executor behavior.
  rclcpp::spin(node);

  // Shutdown ROS2 cleanly before exiting.
  rclcpp::shutdown();
  return 0;
}