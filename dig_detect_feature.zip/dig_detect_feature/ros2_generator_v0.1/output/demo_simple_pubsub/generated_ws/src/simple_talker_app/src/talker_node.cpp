#include "simple_talker_app/talker_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace simple_talker_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

TalkerNode::TalkerNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("talker_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: talker_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&TalkerNode::publish_generated_messages, this));
}

void TalkerNode::declare_generated_parameters()
{
  this->declare_parameter<bool>("publish_rate_hz", true);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: publish_rate_hz");
  this->declare_parameter<std::string>("frame_id", "demo_frame");
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: frame_id");
}

void TalkerNode::setup_publishers()
{
  auto qos_publish_simple_status = make_qos(10, "reliable", "volatile");
  publish_simple_status_publisher_ = this->create_publisher<generated_interfaces::msg::SimpleStatus>("/demo/simple_status", qos_publish_simple_status);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_simple_status -> /demo/simple_status");
}

void TalkerNode::setup_subscribers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SUBSCRIBERS: talker_node");
}

void TalkerNode::setup_service_servers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE SERVERS: talker_node");
}

void TalkerNode::setup_service_clients()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE CLIENTS: talker_node");
}

void TalkerNode::publish_generated_messages()
{
  auto msg_publish_simple_status = generated_interfaces::msg::SimpleStatus();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_simple_status
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_simple_status.sequence_id = 1;
  msg_publish_simple_status.status_text = "sample_status_text";
  msg_publish_simple_status.healthy = true;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_simple_status
  // ============================================================================

  publish_simple_status_publisher_->publish(msg_publish_simple_status);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /demo/simple_status");
}




}  // namespace simple_talker_app