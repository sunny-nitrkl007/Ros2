#include "rclcpp/rclcpp.hpp"
#include "simple_talker_app/talker_node.hpp"

/**
 * @brief Starts combined executable for application package `simple_talker_app`.
 *
 * This executable hosts all nodes owned by the application in one process using
 * a MultiThreadedExecutor. This is the scalable default for large systems.
 */
int main(int argc, char ** argv)
{
  // Initialize ROS2 runtime once for the combined application executable.
  rclcpp::init(argc, argv);

  // MultiThreadedExecutor allows callbacks across generated nodes to progress concurrently.
  rclcpp::executors::MultiThreadedExecutor executor;

  // Create and add generated node `talker_node` to the combined executor.
  auto talker_node = std::make_shared<simple_talker_app::TalkerNode>();
  executor.add_node(talker_node);

  // Spin all application nodes until shutdown.
  executor.spin();

  // Shutdown ROS2 cleanly before process exit.
  rclcpp::shutdown();
  return 0;
}