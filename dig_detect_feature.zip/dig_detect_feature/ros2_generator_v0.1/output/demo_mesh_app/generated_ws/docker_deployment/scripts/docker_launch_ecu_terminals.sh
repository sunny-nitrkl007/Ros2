#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source ./scripts/docker_cmd_lib.sh
./scripts/docker_prepare_ecu_demo.sh
open_terminal() {
  local title="$1"
  local cmd="$2"
  if command -v wt.exe >/dev/null 2>&1 && command -v wslpath >/dev/null 2>&1; then
    local win_pwd
    win_pwd="$(wslpath -w "$PWD" 2>/dev/null || true)"
    if [[ -n "$win_pwd" ]]; then
      wt.exe new-tab --title "$title" wsl.exe --cd "$win_pwd" bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
      wt.exe new-window --title "$title" wsl.exe --cd "$win_pwd" bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
    fi
  fi
  if command -v gnome-terminal >/dev/null 2>&1; then
    gnome-terminal --title="$title" -- bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
  fi
  if command -v xterm >/dev/null 2>&1; then
    xterm -T "$title" -e bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
  fi
  return 1
}
FAILED=0
echo "[INFO] Opening discovery_server terminal..."
open_terminal "T1 DDS Discovery Server" "cd '$PWD' && $DOCKER_CMD compose up --no-deps discovery_server" || FAILED=1
sleep 6
echo "[INFO] Opening ECU terminal for perception_system..."
open_terminal "ECU perception_system" "cd '$PWD' && $DOCKER_CMD compose up --no-deps perception_system" || FAILED=1
sleep 2
echo "[INFO] Opening ECU terminal for planning_system..."
open_terminal "ECU planning_system" "cd '$PWD' && $DOCKER_CMD compose up --no-deps planning_system" || FAILED=1
sleep 2
echo "[INFO] Opening ECU terminal for safety_system..."
open_terminal "ECU safety_system" "cd '$PWD' && $DOCKER_CMD compose up --no-deps safety_system" || FAILED=1
sleep 2
if [[ "$FAILED" == "1" ]]; then
  echo "[WARN] Auto launch failed. Manual commands:"
  ./scripts/docker_print_ecu_commands.sh
else
  echo "[OK] ECU terminal demo launched."
fi