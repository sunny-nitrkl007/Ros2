#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source ./scripts/docker_cmd_lib.sh
$DOCKER_CMD compose up -d inspector
sleep 8
$DOCKER_CMD compose exec inspector bash -lc "source /opt/ros/${ROS_DISTRO:-jazzy}/setup.bash && source /generated_ws/install/setup.bash && cd /generated_ws && ros2 daemon stop >/dev/null 2>&1 || true; sleep 2; ros2 daemon start >/dev/null 2>&1 || true; sleep 8; echo '[INFO] Nodes:'; ros2 node list; echo '[INFO] Topics:'; ros2 topic list; echo '[INFO] Services:'; ros2 service list; echo '[INFO] Echoing /perception/obstacle_data'; ros2 topic echo '/perception/obstacle_data' --once; echo '[INFO] Echoing /planning/trajectory'; ros2 topic echo '/planning/trajectory' --once; echo '[INFO] Echoing /safety/emergency_brake'; ros2 topic echo '/safety/emergency_brake' --once; echo '[OK] ECU Docker graph validation completed.'"