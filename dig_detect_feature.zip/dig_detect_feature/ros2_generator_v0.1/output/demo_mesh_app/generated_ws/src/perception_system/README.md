# perception_system

Generated ROS2 application package from finalized grammar.

## Nodes

- `perception1_node` -> `Perception1Node`
- `perception2_node` -> `Perception2Node`

## Developer Rule

Generated code contains infrastructure only. Add business logic only inside marked sections:

```cpp
// USER BUSINESS LOGIC START
// USER BUSINESS LOGIC END
```