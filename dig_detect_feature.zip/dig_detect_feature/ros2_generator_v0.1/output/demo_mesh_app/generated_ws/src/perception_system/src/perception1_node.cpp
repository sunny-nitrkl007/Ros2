#include "perception_system/perception1_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace perception_system
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

Perception1Node::Perception1Node(const rclcpp::NodeOptions & options)
: rclcpp::Node("perception1_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: perception1_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&Perception1Node::publish_generated_messages, this));
}

void Perception1Node::declare_generated_parameters()
{
  this->declare_parameter<double>("sensor_update_rate_hz", 20.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: sensor_update_rate_hz");
  this->declare_parameter<double>("obstacle_detection_range_m", 100.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: obstacle_detection_range_m");
  this->declare_parameter<bool>("enable_object_classification", true);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: enable_object_classification");
  this->declare_parameter<bool>("enable_debug_logging", false);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: enable_debug_logging");
}

void Perception1Node::setup_publishers()
{
  auto qos_pub_obstacle_data = make_qos(10, "RELIABLE", "VOLATILE");
  pub_obstacle_data_publisher_ = this->create_publisher<generated_interfaces::msg::ObstacleData>("/perception/obstacle_data", qos_pub_obstacle_data);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: pub_obstacle_data -> /perception/obstacle_data");
}

void Perception1Node::setup_subscribers()
{
  auto qos_sub_emergency_state = make_qos(10, "RELIABLE", "VOLATILE");
  sub_emergency_state_subscriber_ = this->create_subscription<generated_interfaces::msg::EmergencyBrake>("/safety/emergency_brake", qos_sub_emergency_state, std::bind(&Perception1Node::on_sub_emergency_state, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: sub_emergency_state <- /safety/emergency_brake");
}

void Perception1Node::setup_service_servers()
{
  server_get_lane_info_service_ = this->create_service<generated_interfaces::srv::GetLaneInfo>("/perception/get_lane_info", std::bind(&Perception1Node::handle_server_get_lane_info, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_get_lane_info -> /perception/get_lane_info");
}

void Perception1Node::setup_service_clients()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE CLIENTS: perception1_node");
}

void Perception1Node::publish_generated_messages()
{
  auto msg_pub_obstacle_data = generated_interfaces::msg::ObstacleData();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for pub_obstacle_data
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_pub_obstacle_data.id = 1;
  msg_pub_obstacle_data.distance = 2.0;
  msg_pub_obstacle_data.relative_velocity = 3.0;
  msg_pub_obstacle_data.object_type = "sample_object_type";
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for pub_obstacle_data
  // ============================================================================

  pub_obstacle_data_publisher_->publish(msg_pub_obstacle_data);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /perception/obstacle_data");
}

void Perception1Node::on_sub_emergency_state(generated_interfaces::msg::EmergencyBrake::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /safety/emergency_brake");
}

void Perception1Node::handle_server_get_lane_info(const std::shared_ptr<generated_interfaces::srv::GetLaneInfo::Request> request, std::shared_ptr<generated_interfaces::srv::GetLaneInfo::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /perception/get_lane_info");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_get_lane_info
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->lane_center_offset = 1.0;
  response->lane_width = 2.0;
  response->lane_type = "sample_lane_type";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_get_lane_info
  // ============================================================================
}


}  // namespace perception_system