#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/srv/request_path_update.hpp"

namespace perception_system
{

/**
 * @brief Generated ROS2 node class for `perception2_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class Perception2Node : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit Perception2Node(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();




  /**
   * @brief Generated helper that prepares an async request for `client_request_path_update`.
   */
  void send_client_request_path_update_request();

  rclcpp::Client<generated_interfaces::srv::RequestPathUpdate>::SharedPtr client_request_path_update_client_;
};

}  // namespace perception_system