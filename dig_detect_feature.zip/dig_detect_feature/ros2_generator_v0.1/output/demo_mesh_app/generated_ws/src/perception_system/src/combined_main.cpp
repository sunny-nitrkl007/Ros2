#include "rclcpp/rclcpp.hpp"
#include "perception_system/perception1_node.hpp"
#include "perception_system/perception2_node.hpp"

/**
 * @brief Starts combined executable for application package `perception_system`.
 *
 * This executable hosts all nodes owned by the application in one process using
 * a MultiThreadedExecutor. This is the scalable default for large systems.
 */
int main(int argc, char ** argv)
{
  // Initialize ROS2 runtime once for the combined application executable.
  rclcpp::init(argc, argv);

  // MultiThreadedExecutor allows callbacks across generated nodes to progress concurrently.
  rclcpp::executors::MultiThreadedExecutor executor;

  // Create and add generated node `perception1_node` to the combined executor.
  auto perception1_node = std::make_shared<perception_system::Perception1Node>();
  executor.add_node(perception1_node);
  // Create and add generated node `perception2_node` to the combined executor.
  auto perception2_node = std::make_shared<perception_system::Perception2Node>();
  executor.add_node(perception2_node);

  // Spin all application nodes until shutdown.
  executor.spin();

  // Shutdown ROS2 cleanly before process exit.
  rclcpp::shutdown();
  return 0;
}