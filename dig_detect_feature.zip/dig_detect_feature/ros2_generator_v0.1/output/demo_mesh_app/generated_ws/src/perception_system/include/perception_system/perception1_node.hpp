#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/emergency_brake.hpp"
#include "generated_interfaces/msg/obstacle_data.hpp"
#include "generated_interfaces/srv/get_lane_info.hpp"

namespace perception_system
{

/**
 * @brief Generated ROS2 node class for `perception1_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class Perception1Node : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit Perception1Node(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();

  /**
   * @brief Generated subscriber callback for `sub_emergency_state`.
   */
  void on_sub_emergency_state(generated_interfaces::msg::EmergencyBrake::SharedPtr msg);

  /**
   * @brief Generated service handler for `server_get_lane_info`.
   */
  void handle_server_get_lane_info(
    const std::shared_ptr<generated_interfaces::srv::GetLaneInfo::Request> request,
    std::shared_ptr<generated_interfaces::srv::GetLaneInfo::Response> response);


  rclcpp::Publisher<generated_interfaces::msg::ObstacleData>::SharedPtr pub_obstacle_data_publisher_;
  rclcpp::Subscription<generated_interfaces::msg::EmergencyBrake>::SharedPtr sub_emergency_state_subscriber_;
  rclcpp::Service<generated_interfaces::srv::GetLaneInfo>::SharedPtr server_get_lane_info_service_;
  rclcpp::TimerBase::SharedPtr publish_timer_;
};

}  // namespace perception_system