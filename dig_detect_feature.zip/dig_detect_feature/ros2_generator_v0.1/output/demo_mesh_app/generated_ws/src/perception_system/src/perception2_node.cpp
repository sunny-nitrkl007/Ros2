#include "perception_system/perception2_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace perception_system
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

Perception2Node::Perception2Node(const rclcpp::NodeOptions & options)
: rclcpp::Node("perception2_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: perception2_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
}

void Perception2Node::declare_generated_parameters()
{
  this->declare_parameter<double>("sensor_update_rate_hz", 20.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: sensor_update_rate_hz");
  this->declare_parameter<double>("obstacle_detection_range_m", 100.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: obstacle_detection_range_m");
  this->declare_parameter<bool>("enable_object_classification", true);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: enable_object_classification");
  this->declare_parameter<bool>("enable_debug_logging", false);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: enable_debug_logging");
}

void Perception2Node::setup_publishers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO PUBLISHERS: perception2_node");
}

void Perception2Node::setup_subscribers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SUBSCRIBERS: perception2_node");
}

void Perception2Node::setup_service_servers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE SERVERS: perception2_node");
}

void Perception2Node::setup_service_clients()
{
  client_request_path_update_client_ = this->create_client<generated_interfaces::srv::RequestPathUpdate>("/planning/request_path_update");
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT CREATED: client_request_path_update -> /planning/request_path_update");
}




void Perception2Node::send_client_request_path_update_request()
{
  auto request = std::make_shared<generated_interfaces::srv::RequestPathUpdate::Request>();
  if (client_request_path_update_client_->service_is_ready()) {
    RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT SEND: /planning/request_path_update");
    client_request_path_update_client_->async_send_request(request);
  }
}

}  // namespace perception_system