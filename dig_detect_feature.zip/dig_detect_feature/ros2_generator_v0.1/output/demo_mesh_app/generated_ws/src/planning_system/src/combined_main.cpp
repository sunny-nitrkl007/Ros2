#include "rclcpp/rclcpp.hpp"
#include "planning_system/planning1_node.hpp"
#include "planning_system/planning2_node.hpp"

/**
 * @brief Starts combined executable for application package `planning_system`.
 *
 * This executable hosts all nodes owned by the application in one process using
 * a MultiThreadedExecutor. This is the scalable default for large systems.
 */
int main(int argc, char ** argv)
{
  // Initialize ROS2 runtime once for the combined application executable.
  rclcpp::init(argc, argv);

  // MultiThreadedExecutor allows callbacks across generated nodes to progress concurrently.
  rclcpp::executors::MultiThreadedExecutor executor;

  // Create and add generated node `planning1_node` to the combined executor.
  auto planning1_node = std::make_shared<planning_system::Planning1Node>();
  executor.add_node(planning1_node);
  // Create and add generated node `planning2_node` to the combined executor.
  auto planning2_node = std::make_shared<planning_system::Planning2Node>();
  executor.add_node(planning2_node);

  // Spin all application nodes until shutdown.
  executor.spin();

  // Shutdown ROS2 cleanly before process exit.
  rclcpp::shutdown();
  return 0;
}