# planning_system

Generated ROS2 application package from finalized grammar.

## Nodes

- `planning1_node` -> `Planning1Node`
- `planning2_node` -> `Planning2Node`

## Developer Rule

Generated code contains infrastructure only. Add business logic only inside marked sections:

```cpp
// USER BUSINESS LOGIC START
// USER BUSINESS LOGIC END
```