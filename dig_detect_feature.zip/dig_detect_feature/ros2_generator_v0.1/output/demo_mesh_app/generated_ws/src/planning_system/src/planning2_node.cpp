#include "planning_system/planning2_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace planning_system
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

Planning2Node::Planning2Node(const rclcpp::NodeOptions & options)
: rclcpp::Node("planning2_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: planning2_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
}

void Planning2Node::declare_generated_parameters()
{
  this->declare_parameter<double>("planning_rate_hz", 10.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: planning_rate_hz");
  this->declare_parameter<double>("max_speed_mps", 30.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: max_speed_mps");
  this->declare_parameter<double>("safe_follow_distance_m", 10.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: safe_follow_distance_m");
}

void Planning2Node::setup_publishers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO PUBLISHERS: planning2_node");
}

void Planning2Node::setup_subscribers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SUBSCRIBERS: planning2_node");
}

void Planning2Node::setup_service_servers()
{
  server_request_path_update_service_ = this->create_service<generated_interfaces::srv::RequestPathUpdate>("/planning/request_path_update", std::bind(&Planning2Node::handle_server_request_path_update, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_request_path_update -> /planning/request_path_update");
}

void Planning2Node::setup_service_clients()
{
  client_get_lane_info_client_ = this->create_client<generated_interfaces::srv::GetLaneInfo>("/perception/get_lane_info");
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT CREATED: client_get_lane_info -> /perception/get_lane_info");
  client_check_risk_client_ = this->create_client<generated_interfaces::srv::CheckRisk>("/safety/check_risk");
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT CREATED: client_check_risk -> /safety/check_risk");
}



void Planning2Node::handle_server_request_path_update(const std::shared_ptr<generated_interfaces::srv::RequestPathUpdate::Request> request, std::shared_ptr<generated_interfaces::srv::RequestPathUpdate::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /planning/request_path_update");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_request_path_update
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->success = true;
  response->new_target_speed = 2.0;
  response->status_msg = "sample_status_msg";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_request_path_update
  // ============================================================================
}

void Planning2Node::send_client_get_lane_info_request()
{
  auto request = std::make_shared<generated_interfaces::srv::GetLaneInfo::Request>();
  if (client_get_lane_info_client_->service_is_ready()) {
    RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT SEND: /perception/get_lane_info");
    client_get_lane_info_client_->async_send_request(request);
  }
}
void Planning2Node::send_client_check_risk_request()
{
  auto request = std::make_shared<generated_interfaces::srv::CheckRisk::Request>();
  if (client_check_risk_client_->service_is_ready()) {
    RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT SEND: /safety/check_risk");
    client_check_risk_client_->async_send_request(request);
  }
}

}  // namespace planning_system