#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/emergency_brake.hpp"
#include "generated_interfaces/msg/obstacle_data.hpp"
#include "generated_interfaces/msg/trajectory.hpp"

namespace planning_system
{

/**
 * @brief Generated ROS2 node class for `planning1_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class Planning1Node : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit Planning1Node(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();

  /**
   * @brief Generated subscriber callback for `sub_obstacle_data`.
   */
  void on_sub_obstacle_data(generated_interfaces::msg::ObstacleData::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `sub_emergency_brake`.
   */
  void on_sub_emergency_brake(generated_interfaces::msg::EmergencyBrake::SharedPtr msg);



  rclcpp::Publisher<generated_interfaces::msg::Trajectory>::SharedPtr pub_trajectory_publisher_;
  rclcpp::Subscription<generated_interfaces::msg::ObstacleData>::SharedPtr sub_obstacle_data_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::EmergencyBrake>::SharedPtr sub_emergency_brake_subscriber_;
  rclcpp::TimerBase::SharedPtr publish_timer_;
};

}  // namespace planning_system