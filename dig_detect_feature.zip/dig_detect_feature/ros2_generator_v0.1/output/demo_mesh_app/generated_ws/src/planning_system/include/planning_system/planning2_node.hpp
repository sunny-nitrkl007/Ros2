#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/srv/check_risk.hpp"
#include "generated_interfaces/srv/get_lane_info.hpp"
#include "generated_interfaces/srv/request_path_update.hpp"

namespace planning_system
{

/**
 * @brief Generated ROS2 node class for `planning2_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class Planning2Node : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit Planning2Node(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();



  /**
   * @brief Generated service handler for `server_request_path_update`.
   */
  void handle_server_request_path_update(
    const std::shared_ptr<generated_interfaces::srv::RequestPathUpdate::Request> request,
    std::shared_ptr<generated_interfaces::srv::RequestPathUpdate::Response> response);

  /**
   * @brief Generated helper that prepares an async request for `client_get_lane_info`.
   */
  void send_client_get_lane_info_request();
  /**
   * @brief Generated helper that prepares an async request for `client_check_risk`.
   */
  void send_client_check_risk_request();

  rclcpp::Service<generated_interfaces::srv::RequestPathUpdate>::SharedPtr server_request_path_update_service_;
  rclcpp::Client<generated_interfaces::srv::GetLaneInfo>::SharedPtr client_get_lane_info_client_;
  rclcpp::Client<generated_interfaces::srv::CheckRisk>::SharedPtr client_check_risk_client_;
};

}  // namespace planning_system