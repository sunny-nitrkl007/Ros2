#include "planning_system/planning1_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace planning_system
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

Planning1Node::Planning1Node(const rclcpp::NodeOptions & options)
: rclcpp::Node("planning1_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: planning1_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&Planning1Node::publish_generated_messages, this));
}

void Planning1Node::declare_generated_parameters()
{
  this->declare_parameter<double>("planning_rate_hz", 10.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: planning_rate_hz");
  this->declare_parameter<double>("max_speed_mps", 30.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: max_speed_mps");
  this->declare_parameter<double>("safe_follow_distance_m", 10.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: safe_follow_distance_m");
}

void Planning1Node::setup_publishers()
{
  auto qos_pub_trajectory = make_qos(10, "RELIABLE", "VOLATILE");
  pub_trajectory_publisher_ = this->create_publisher<generated_interfaces::msg::Trajectory>("/planning/trajectory", qos_pub_trajectory);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: pub_trajectory -> /planning/trajectory");
}

void Planning1Node::setup_subscribers()
{
  auto qos_sub_obstacle_data = make_qos(10, "RELIABLE", "VOLATILE");
  sub_obstacle_data_subscriber_ = this->create_subscription<generated_interfaces::msg::ObstacleData>("/perception/obstacle_data", qos_sub_obstacle_data, std::bind(&Planning1Node::on_sub_obstacle_data, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: sub_obstacle_data <- /perception/obstacle_data");
  auto qos_sub_emergency_brake = make_qos(10, "RELIABLE", "VOLATILE");
  sub_emergency_brake_subscriber_ = this->create_subscription<generated_interfaces::msg::EmergencyBrake>("/safety/emergency_brake", qos_sub_emergency_brake, std::bind(&Planning1Node::on_sub_emergency_brake, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: sub_emergency_brake <- /safety/emergency_brake");
}

void Planning1Node::setup_service_servers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE SERVERS: planning1_node");
}

void Planning1Node::setup_service_clients()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE CLIENTS: planning1_node");
}

void Planning1Node::publish_generated_messages()
{
  auto msg_pub_trajectory = generated_interfaces::msg::Trajectory();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for pub_trajectory
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_pub_trajectory.x_points = {static_cast<float>(1.0)};
  msg_pub_trajectory.y_points = {static_cast<float>(2.0)};
  msg_pub_trajectory.target_speed = 3.0;
  msg_pub_trajectory.emergency_flag = true;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for pub_trajectory
  // ============================================================================

  pub_trajectory_publisher_->publish(msg_pub_trajectory);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /planning/trajectory");
}

void Planning1Node::on_sub_obstacle_data(generated_interfaces::msg::ObstacleData::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /perception/obstacle_data");
}
void Planning1Node::on_sub_emergency_brake(generated_interfaces::msg::EmergencyBrake::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /safety/emergency_brake");
}



}  // namespace planning_system