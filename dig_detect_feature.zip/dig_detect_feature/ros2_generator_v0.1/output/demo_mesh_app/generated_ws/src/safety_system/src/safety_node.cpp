#include "safety_system/safety_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace safety_system
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

SafetyNode::SafetyNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("safety_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: safety_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&SafetyNode::publish_generated_messages, this));
}

void SafetyNode::declare_generated_parameters()
{
  this->declare_parameter<double>("planning_rate_hz", 10.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: planning_rate_hz");
  this->declare_parameter<double>("max_speed_mps", 30.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: max_speed_mps");
  this->declare_parameter<double>("safe_follow_distance_m", 10.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: safe_follow_distance_m");
}

void SafetyNode::setup_publishers()
{
  auto qos_pub_emergency_brake = make_qos(10, "RELIABLE", "VOLATILE");
  pub_emergency_brake_publisher_ = this->create_publisher<generated_interfaces::msg::EmergencyBrake>("/safety/emergency_brake", qos_pub_emergency_brake);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: pub_emergency_brake -> /safety/emergency_brake");
}

void SafetyNode::setup_subscribers()
{
  auto qos_sub_obstacle_data = make_qos(10, "RELIABLE", "VOLATILE");
  sub_obstacle_data_subscriber_ = this->create_subscription<generated_interfaces::msg::ObstacleData>("/perception/obstacle_data", qos_sub_obstacle_data, std::bind(&SafetyNode::on_sub_obstacle_data, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: sub_obstacle_data <- /perception/obstacle_data");
  auto qos_sub_trajectory = make_qos(10, "RELIABLE", "VOLATILE");
  sub_trajectory_subscriber_ = this->create_subscription<generated_interfaces::msg::Trajectory>("/planning/trajectory", qos_sub_trajectory, std::bind(&SafetyNode::on_sub_trajectory, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: sub_trajectory <- /planning/trajectory");
}

void SafetyNode::setup_service_servers()
{
  server_check_risk_service_ = this->create_service<generated_interfaces::srv::CheckRisk>("/safety/check_risk", std::bind(&SafetyNode::handle_server_check_risk, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_check_risk -> /safety/check_risk");
}

void SafetyNode::setup_service_clients()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE CLIENTS: safety_node");
}

void SafetyNode::publish_generated_messages()
{
  auto msg_pub_emergency_brake = generated_interfaces::msg::EmergencyBrake();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for pub_emergency_brake
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_pub_emergency_brake.apply_brake = true;
  msg_pub_emergency_brake.brake_force = 2.0;
  msg_pub_emergency_brake.reason = "sample_reason";
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for pub_emergency_brake
  // ============================================================================

  pub_emergency_brake_publisher_->publish(msg_pub_emergency_brake);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /safety/emergency_brake");
}

void SafetyNode::on_sub_obstacle_data(generated_interfaces::msg::ObstacleData::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /perception/obstacle_data");
}
void SafetyNode::on_sub_trajectory(generated_interfaces::msg::Trajectory::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /planning/trajectory");
}

void SafetyNode::handle_server_check_risk(const std::shared_ptr<generated_interfaces::srv::CheckRisk::Request> request, std::shared_ptr<generated_interfaces::srv::CheckRisk::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /safety/check_risk");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_check_risk
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->risk_detected = true;
  response->collision_probability = 2.0;
  response->risk_level = "sample_risk_level";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_check_risk
  // ============================================================================
}


}  // namespace safety_system