#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/emergency_brake.hpp"
#include "generated_interfaces/msg/obstacle_data.hpp"
#include "generated_interfaces/msg/trajectory.hpp"
#include "generated_interfaces/srv/check_risk.hpp"

namespace safety_system
{

/**
 * @brief Generated ROS2 node class for `safety_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class SafetyNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit SafetyNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();

  /**
   * @brief Generated subscriber callback for `sub_obstacle_data`.
   */
  void on_sub_obstacle_data(generated_interfaces::msg::ObstacleData::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `sub_trajectory`.
   */
  void on_sub_trajectory(generated_interfaces::msg::Trajectory::SharedPtr msg);

  /**
   * @brief Generated service handler for `server_check_risk`.
   */
  void handle_server_check_risk(
    const std::shared_ptr<generated_interfaces::srv::CheckRisk::Request> request,
    std::shared_ptr<generated_interfaces::srv::CheckRisk::Response> response);


  rclcpp::Publisher<generated_interfaces::msg::EmergencyBrake>::SharedPtr pub_emergency_brake_publisher_;
  rclcpp::Subscription<generated_interfaces::msg::ObstacleData>::SharedPtr sub_obstacle_data_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::Trajectory>::SharedPtr sub_trajectory_subscriber_;
  rclcpp::Service<generated_interfaces::srv::CheckRisk>::SharedPtr server_check_risk_service_;
  rclcpp::TimerBase::SharedPtr publish_timer_;
};

}  // namespace safety_system