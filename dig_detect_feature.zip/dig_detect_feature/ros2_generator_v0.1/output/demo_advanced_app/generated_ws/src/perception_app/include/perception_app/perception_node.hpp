#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/camera_front_raw.hpp"
#include "generated_interfaces/msg/camera_rear_raw.hpp"
#include "generated_interfaces/msg/detected_objects.hpp"
#include "generated_interfaces/msg/free_space_grid.hpp"
#include "generated_interfaces/msg/imu_data.hpp"
#include "generated_interfaces/msg/lane_markings.hpp"
#include "generated_interfaces/msg/lidar_points.hpp"
#include "generated_interfaces/msg/perception_health.hpp"
#include "generated_interfaces/msg/radar_tracks.hpp"
#include "generated_interfaces/msg/traffic_signs.hpp"
#include "generated_interfaces/srv/get_localization_status.hpp"
#include "generated_interfaces/srv/get_object_details.hpp"
#include "generated_interfaces/srv/reset_perception.hpp"

namespace perception_app
{

/**
 * @brief Generated ROS2 node class for `perception_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class PerceptionNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit PerceptionNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();

  /**
   * @brief Generated subscriber callback for `subscribe_imu_data`.
   */
  void on_subscribe_imu_data(generated_interfaces::msg::ImuData::SharedPtr msg);

  /**
   * @brief Generated service handler for `server_get_object_details`.
   */
  void handle_server_get_object_details(
    const std::shared_ptr<generated_interfaces::srv::GetObjectDetails::Request> request,
    std::shared_ptr<generated_interfaces::srv::GetObjectDetails::Response> response);
  /**
   * @brief Generated service handler for `server_reset_perception`.
   */
  void handle_server_reset_perception(
    const std::shared_ptr<generated_interfaces::srv::ResetPerception::Request> request,
    std::shared_ptr<generated_interfaces::srv::ResetPerception::Response> response);

  /**
   * @brief Generated helper that prepares an async request for `client_get_localization_status`.
   */
  void send_client_get_localization_status_request();

  rclcpp::Publisher<generated_interfaces::msg::CameraFrontRaw>::SharedPtr publish_camera_front_raw_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::CameraRearRaw>::SharedPtr publish_camera_rear_raw_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::LidarPoints>::SharedPtr publish_lidar_points_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::RadarTracks>::SharedPtr publish_radar_tracks_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::DetectedObjects>::SharedPtr publish_detected_objects_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::LaneMarkings>::SharedPtr publish_lane_markings_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::TrafficSigns>::SharedPtr publish_traffic_signs_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::FreeSpaceGrid>::SharedPtr publish_free_space_grid_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::PerceptionHealth>::SharedPtr publish_perception_health_publisher_;
  rclcpp::Subscription<generated_interfaces::msg::ImuData>::SharedPtr subscribe_imu_data_subscriber_;
  rclcpp::Service<generated_interfaces::srv::GetObjectDetails>::SharedPtr server_get_object_details_service_;
  rclcpp::Service<generated_interfaces::srv::ResetPerception>::SharedPtr server_reset_perception_service_;
  rclcpp::Client<generated_interfaces::srv::GetLocalizationStatus>::SharedPtr client_get_localization_status_client_;
  rclcpp::TimerBase::SharedPtr publish_timer_;
};

}  // namespace perception_app