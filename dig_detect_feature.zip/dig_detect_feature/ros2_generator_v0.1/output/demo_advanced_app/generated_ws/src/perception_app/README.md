# perception_app

Generated ROS2 application package from finalized grammar.

## Nodes

- `perception_node` -> `PerceptionNode`

## Developer Rule

Generated code contains infrastructure only. Add business logic only inside marked sections:

```cpp
// USER BUSINESS LOGIC START
// USER BUSINESS LOGIC END
```