#include "perception_app/perception_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace perception_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

PerceptionNode::PerceptionNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("perception_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: perception_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&PerceptionNode::publish_generated_messages, this));
}

void PerceptionNode::declare_generated_parameters()
{
  this->declare_parameter<double>("camera_rate_hz", 20.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: camera_rate_hz");
  this->declare_parameter<bool>("object_confidence_threshold", true);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: object_confidence_threshold");
}

void PerceptionNode::setup_publishers()
{
  auto qos_publish_camera_front_raw = make_qos(5, "best_effort", "volatile");
  publish_camera_front_raw_publisher_ = this->create_publisher<generated_interfaces::msg::CameraFrontRaw>("/sensors/camera/front/raw", qos_publish_camera_front_raw);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_camera_front_raw -> /sensors/camera/front/raw");
  auto qos_publish_camera_rear_raw = make_qos(5, "best_effort", "volatile");
  publish_camera_rear_raw_publisher_ = this->create_publisher<generated_interfaces::msg::CameraRearRaw>("/sensors/camera/rear/raw", qos_publish_camera_rear_raw);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_camera_rear_raw -> /sensors/camera/rear/raw");
  auto qos_publish_lidar_points = make_qos(5, "best_effort", "volatile");
  publish_lidar_points_publisher_ = this->create_publisher<generated_interfaces::msg::LidarPoints>("/sensors/lidar/points", qos_publish_lidar_points);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_lidar_points -> /sensors/lidar/points");
  auto qos_publish_radar_tracks = make_qos(5, "best_effort", "volatile");
  publish_radar_tracks_publisher_ = this->create_publisher<generated_interfaces::msg::RadarTracks>("/sensors/radar/tracks", qos_publish_radar_tracks);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_radar_tracks -> /sensors/radar/tracks");
  auto qos_publish_detected_objects = make_qos(10, "reliable", "volatile");
  publish_detected_objects_publisher_ = this->create_publisher<generated_interfaces::msg::DetectedObjects>("/perception/detected_objects", qos_publish_detected_objects);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_detected_objects -> /perception/detected_objects");
  auto qos_publish_lane_markings = make_qos(10, "reliable", "volatile");
  publish_lane_markings_publisher_ = this->create_publisher<generated_interfaces::msg::LaneMarkings>("/perception/lane_markings", qos_publish_lane_markings);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_lane_markings -> /perception/lane_markings");
  auto qos_publish_traffic_signs = make_qos(10, "reliable", "volatile");
  publish_traffic_signs_publisher_ = this->create_publisher<generated_interfaces::msg::TrafficSigns>("/perception/traffic_signs", qos_publish_traffic_signs);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_traffic_signs -> /perception/traffic_signs");
  auto qos_publish_free_space_grid = make_qos(10, "reliable", "volatile");
  publish_free_space_grid_publisher_ = this->create_publisher<generated_interfaces::msg::FreeSpaceGrid>("/perception/free_space_grid", qos_publish_free_space_grid);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_free_space_grid -> /perception/free_space_grid");
  auto qos_publish_perception_health = make_qos(10, "reliable", "volatile");
  publish_perception_health_publisher_ = this->create_publisher<generated_interfaces::msg::PerceptionHealth>("/perception/health", qos_publish_perception_health);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_perception_health -> /perception/health");
}

void PerceptionNode::setup_subscribers()
{
  auto qos_subscribe_imu_data = make_qos(5, "best_effort", "volatile");
  subscribe_imu_data_subscriber_ = this->create_subscription<generated_interfaces::msg::ImuData>("/sensors/imu/data", qos_subscribe_imu_data, std::bind(&PerceptionNode::on_subscribe_imu_data, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_imu_data <- /sensors/imu/data");
}

void PerceptionNode::setup_service_servers()
{
  server_get_object_details_service_ = this->create_service<generated_interfaces::srv::GetObjectDetails>("/perception/get_object_details", std::bind(&PerceptionNode::handle_server_get_object_details, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_get_object_details -> /perception/get_object_details");
  server_reset_perception_service_ = this->create_service<generated_interfaces::srv::ResetPerception>("/perception/reset", std::bind(&PerceptionNode::handle_server_reset_perception, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_reset_perception -> /perception/reset");
}

void PerceptionNode::setup_service_clients()
{
  client_get_localization_status_client_ = this->create_client<generated_interfaces::srv::GetLocalizationStatus>("/localization/get_status");
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT CREATED: client_get_localization_status -> /localization/get_status");
}

void PerceptionNode::publish_generated_messages()
{
  auto msg_publish_camera_front_raw = generated_interfaces::msg::CameraFrontRaw();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_camera_front_raw
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_camera_front_raw.stamp_sec = 1;
  msg_publish_camera_front_raw.source = "sample_source";
  msg_publish_camera_front_raw.valid = true;
  msg_publish_camera_front_raw.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_camera_front_raw
  // ============================================================================

  publish_camera_front_raw_publisher_->publish(msg_publish_camera_front_raw);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /sensors/camera/front/raw");
  auto msg_publish_camera_rear_raw = generated_interfaces::msg::CameraRearRaw();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_camera_rear_raw
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_camera_rear_raw.stamp_sec = 1;
  msg_publish_camera_rear_raw.source = "sample_source";
  msg_publish_camera_rear_raw.valid = true;
  msg_publish_camera_rear_raw.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_camera_rear_raw
  // ============================================================================

  publish_camera_rear_raw_publisher_->publish(msg_publish_camera_rear_raw);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /sensors/camera/rear/raw");
  auto msg_publish_lidar_points = generated_interfaces::msg::LidarPoints();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_lidar_points
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_lidar_points.stamp_sec = 1;
  msg_publish_lidar_points.source = "sample_source";
  msg_publish_lidar_points.valid = true;
  msg_publish_lidar_points.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_lidar_points
  // ============================================================================

  publish_lidar_points_publisher_->publish(msg_publish_lidar_points);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /sensors/lidar/points");
  auto msg_publish_radar_tracks = generated_interfaces::msg::RadarTracks();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_radar_tracks
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_radar_tracks.stamp_sec = 1;
  msg_publish_radar_tracks.source = "sample_source";
  msg_publish_radar_tracks.valid = true;
  msg_publish_radar_tracks.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_radar_tracks
  // ============================================================================

  publish_radar_tracks_publisher_->publish(msg_publish_radar_tracks);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /sensors/radar/tracks");
  auto msg_publish_detected_objects = generated_interfaces::msg::DetectedObjects();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_detected_objects
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_detected_objects.stamp_sec = 1;
  msg_publish_detected_objects.source = "sample_source";
  msg_publish_detected_objects.valid = true;
  msg_publish_detected_objects.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_detected_objects
  // ============================================================================

  publish_detected_objects_publisher_->publish(msg_publish_detected_objects);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /perception/detected_objects");
  auto msg_publish_lane_markings = generated_interfaces::msg::LaneMarkings();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_lane_markings
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_lane_markings.stamp_sec = 1;
  msg_publish_lane_markings.source = "sample_source";
  msg_publish_lane_markings.valid = true;
  msg_publish_lane_markings.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_lane_markings
  // ============================================================================

  publish_lane_markings_publisher_->publish(msg_publish_lane_markings);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /perception/lane_markings");
  auto msg_publish_traffic_signs = generated_interfaces::msg::TrafficSigns();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_traffic_signs
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_traffic_signs.stamp_sec = 1;
  msg_publish_traffic_signs.source = "sample_source";
  msg_publish_traffic_signs.valid = true;
  msg_publish_traffic_signs.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_traffic_signs
  // ============================================================================

  publish_traffic_signs_publisher_->publish(msg_publish_traffic_signs);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /perception/traffic_signs");
  auto msg_publish_free_space_grid = generated_interfaces::msg::FreeSpaceGrid();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_free_space_grid
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_free_space_grid.stamp_sec = 1;
  msg_publish_free_space_grid.source = "sample_source";
  msg_publish_free_space_grid.valid = true;
  msg_publish_free_space_grid.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_free_space_grid
  // ============================================================================

  publish_free_space_grid_publisher_->publish(msg_publish_free_space_grid);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /perception/free_space_grid");
  auto msg_publish_perception_health = generated_interfaces::msg::PerceptionHealth();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_perception_health
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_perception_health.stamp_sec = 1;
  msg_publish_perception_health.source = "sample_source";
  msg_publish_perception_health.valid = true;
  msg_publish_perception_health.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_perception_health
  // ============================================================================

  publish_perception_health_publisher_->publish(msg_publish_perception_health);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /perception/health");
}

void PerceptionNode::on_subscribe_imu_data(generated_interfaces::msg::ImuData::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /sensors/imu/data");
}

void PerceptionNode::handle_server_get_object_details(const std::shared_ptr<generated_interfaces::srv::GetObjectDetails::Request> request, std::shared_ptr<generated_interfaces::srv::GetObjectDetails::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /perception/get_object_details");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_get_object_details
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->accepted = true;
  response->message = "sample_message";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_get_object_details
  // ============================================================================
}
void PerceptionNode::handle_server_reset_perception(const std::shared_ptr<generated_interfaces::srv::ResetPerception::Request> request, std::shared_ptr<generated_interfaces::srv::ResetPerception::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /perception/reset");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_reset_perception
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->accepted = true;
  response->message = "sample_message";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_reset_perception
  // ============================================================================
}

void PerceptionNode::send_client_get_localization_status_request()
{
  auto request = std::make_shared<generated_interfaces::srv::GetLocalizationStatus::Request>();
  if (client_get_localization_status_client_->service_is_ready()) {
    RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT SEND: /localization/get_status");
    client_get_localization_status_client_->async_send_request(request);
  }
}

}  // namespace perception_app