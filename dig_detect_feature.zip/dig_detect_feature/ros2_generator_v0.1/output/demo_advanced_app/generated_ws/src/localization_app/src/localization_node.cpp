#include "localization_app/localization_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace localization_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

LocalizationNode::LocalizationNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("localization_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: localization_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&LocalizationNode::publish_generated_messages, this));
}

void LocalizationNode::declare_generated_parameters()
{
  this->declare_parameter<double>("pose_rate_hz", 20.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: pose_rate_hz");
  this->declare_parameter<std::string>("map_frame", "map");
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: map_frame");
}

void LocalizationNode::setup_publishers()
{
  auto qos_publish_imu_data = make_qos(5, "best_effort", "volatile");
  publish_imu_data_publisher_ = this->create_publisher<generated_interfaces::msg::ImuData>("/sensors/imu/data", qos_publish_imu_data);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_imu_data -> /sensors/imu/data");
  auto qos_publish_vehicle_pose = make_qos(10, "reliable", "volatile");
  publish_vehicle_pose_publisher_ = this->create_publisher<generated_interfaces::msg::VehiclePose>("/localization/pose", qos_publish_vehicle_pose);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_vehicle_pose -> /localization/pose");
  auto qos_publish_vehicle_velocity = make_qos(10, "reliable", "volatile");
  publish_vehicle_velocity_publisher_ = this->create_publisher<generated_interfaces::msg::VehicleVelocity>("/localization/velocity", qos_publish_vehicle_velocity);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_vehicle_velocity -> /localization/velocity");
  auto qos_publish_map_match_status = make_qos(10, "reliable", "volatile");
  publish_map_match_status_publisher_ = this->create_publisher<generated_interfaces::msg::MapMatchStatus>("/localization/map_match_status", qos_publish_map_match_status);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_map_match_status -> /localization/map_match_status");
  auto qos_publish_localization_health = make_qos(10, "reliable", "volatile");
  publish_localization_health_publisher_ = this->create_publisher<generated_interfaces::msg::LocalizationHealth>("/localization/health", qos_publish_localization_health);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_localization_health -> /localization/health");
  auto qos_publish_ego_state = make_qos(10, "reliable", "volatile");
  publish_ego_state_publisher_ = this->create_publisher<generated_interfaces::msg::EgoState>("/vehicle/ego_state", qos_publish_ego_state);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_ego_state -> /vehicle/ego_state");
}

void LocalizationNode::setup_subscribers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SUBSCRIBERS: localization_node");
}

void LocalizationNode::setup_service_servers()
{
  server_get_localization_status_service_ = this->create_service<generated_interfaces::srv::GetLocalizationStatus>("/localization/get_status", std::bind(&LocalizationNode::handle_server_get_localization_status, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_get_localization_status -> /localization/get_status");
}

void LocalizationNode::setup_service_clients()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE CLIENTS: localization_node");
}

void LocalizationNode::publish_generated_messages()
{
  auto msg_publish_imu_data = generated_interfaces::msg::ImuData();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_imu_data
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_imu_data.stamp_sec = 1;
  msg_publish_imu_data.source = "sample_source";
  msg_publish_imu_data.valid = true;
  msg_publish_imu_data.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_imu_data
  // ============================================================================

  publish_imu_data_publisher_->publish(msg_publish_imu_data);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /sensors/imu/data");
  auto msg_publish_vehicle_pose = generated_interfaces::msg::VehiclePose();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_vehicle_pose
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_vehicle_pose.stamp_sec = 1;
  msg_publish_vehicle_pose.source = "sample_source";
  msg_publish_vehicle_pose.valid = true;
  msg_publish_vehicle_pose.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_vehicle_pose
  // ============================================================================

  publish_vehicle_pose_publisher_->publish(msg_publish_vehicle_pose);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /localization/pose");
  auto msg_publish_vehicle_velocity = generated_interfaces::msg::VehicleVelocity();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_vehicle_velocity
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_vehicle_velocity.stamp_sec = 1;
  msg_publish_vehicle_velocity.source = "sample_source";
  msg_publish_vehicle_velocity.valid = true;
  msg_publish_vehicle_velocity.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_vehicle_velocity
  // ============================================================================

  publish_vehicle_velocity_publisher_->publish(msg_publish_vehicle_velocity);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /localization/velocity");
  auto msg_publish_map_match_status = generated_interfaces::msg::MapMatchStatus();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_map_match_status
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_map_match_status.stamp_sec = 1;
  msg_publish_map_match_status.source = "sample_source";
  msg_publish_map_match_status.valid = true;
  msg_publish_map_match_status.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_map_match_status
  // ============================================================================

  publish_map_match_status_publisher_->publish(msg_publish_map_match_status);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /localization/map_match_status");
  auto msg_publish_localization_health = generated_interfaces::msg::LocalizationHealth();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_localization_health
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_localization_health.stamp_sec = 1;
  msg_publish_localization_health.source = "sample_source";
  msg_publish_localization_health.valid = true;
  msg_publish_localization_health.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_localization_health
  // ============================================================================

  publish_localization_health_publisher_->publish(msg_publish_localization_health);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /localization/health");
  auto msg_publish_ego_state = generated_interfaces::msg::EgoState();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_ego_state
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_ego_state.stamp_sec = 1;
  msg_publish_ego_state.source = "sample_source";
  msg_publish_ego_state.valid = true;
  msg_publish_ego_state.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_ego_state
  // ============================================================================

  publish_ego_state_publisher_->publish(msg_publish_ego_state);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /vehicle/ego_state");
}


void LocalizationNode::handle_server_get_localization_status(const std::shared_ptr<generated_interfaces::srv::GetLocalizationStatus::Request> request, std::shared_ptr<generated_interfaces::srv::GetLocalizationStatus::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /localization/get_status");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_get_localization_status
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->accepted = true;
  response->message = "sample_message";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_get_localization_status
  // ============================================================================
}


}  // namespace localization_app