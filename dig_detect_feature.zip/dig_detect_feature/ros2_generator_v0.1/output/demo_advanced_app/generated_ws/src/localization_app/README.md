# localization_app

Generated ROS2 application package from finalized grammar.

## Nodes

- `localization_node` -> `LocalizationNode`

## Developer Rule

Generated code contains infrastructure only. Add business logic only inside marked sections:

```cpp
// USER BUSINESS LOGIC START
// USER BUSINESS LOGIC END
```