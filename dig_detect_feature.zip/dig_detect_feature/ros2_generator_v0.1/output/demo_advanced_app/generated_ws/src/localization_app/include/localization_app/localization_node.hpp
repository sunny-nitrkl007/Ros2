#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/ego_state.hpp"
#include "generated_interfaces/msg/imu_data.hpp"
#include "generated_interfaces/msg/localization_health.hpp"
#include "generated_interfaces/msg/map_match_status.hpp"
#include "generated_interfaces/msg/vehicle_pose.hpp"
#include "generated_interfaces/msg/vehicle_velocity.hpp"
#include "generated_interfaces/srv/get_localization_status.hpp"

namespace localization_app
{

/**
 * @brief Generated ROS2 node class for `localization_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class LocalizationNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit LocalizationNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();


  /**
   * @brief Generated service handler for `server_get_localization_status`.
   */
  void handle_server_get_localization_status(
    const std::shared_ptr<generated_interfaces::srv::GetLocalizationStatus::Request> request,
    std::shared_ptr<generated_interfaces::srv::GetLocalizationStatus::Response> response);


  rclcpp::Publisher<generated_interfaces::msg::ImuData>::SharedPtr publish_imu_data_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::VehiclePose>::SharedPtr publish_vehicle_pose_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::VehicleVelocity>::SharedPtr publish_vehicle_velocity_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::MapMatchStatus>::SharedPtr publish_map_match_status_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::LocalizationHealth>::SharedPtr publish_localization_health_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::EgoState>::SharedPtr publish_ego_state_publisher_;
  rclcpp::Service<generated_interfaces::srv::GetLocalizationStatus>::SharedPtr server_get_localization_status_service_;
  rclcpp::TimerBase::SharedPtr publish_timer_;
};

}  // namespace localization_app