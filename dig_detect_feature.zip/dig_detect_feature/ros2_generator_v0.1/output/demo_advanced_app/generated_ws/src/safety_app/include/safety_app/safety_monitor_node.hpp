#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/actuator_feedback.hpp"
#include "generated_interfaces/msg/control_cmd.hpp"
#include "generated_interfaces/msg/control_health.hpp"
#include "generated_interfaces/msg/detected_objects.hpp"
#include "generated_interfaces/msg/emergency_brake.hpp"
#include "generated_interfaces/msg/localization_health.hpp"
#include "generated_interfaces/msg/perception_health.hpp"
#include "generated_interfaces/msg/planning_health.hpp"
#include "generated_interfaces/msg/safety_state.hpp"
#include "generated_interfaces/msg/trajectory.hpp"
#include "generated_interfaces/srv/check_safety_risk.hpp"
#include "generated_interfaces/srv/clear_emergency.hpp"
#include "generated_interfaces/srv/reset_controller.hpp"
#include "generated_interfaces/srv/reset_perception.hpp"

namespace safety_app
{

/**
 * @brief Generated ROS2 node class for `safety_monitor_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class SafetyMonitorNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit SafetyMonitorNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();

  /**
   * @brief Generated subscriber callback for `subscribe_detected_objects_safety`.
   */
  void on_subscribe_detected_objects_safety(generated_interfaces::msg::DetectedObjects::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_trajectory_safety`.
   */
  void on_subscribe_trajectory_safety(generated_interfaces::msg::Trajectory::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_control_cmd`.
   */
  void on_subscribe_control_cmd(generated_interfaces::msg::ControlCmd::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_actuator_feedback`.
   */
  void on_subscribe_actuator_feedback(generated_interfaces::msg::ActuatorFeedback::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_perception_health`.
   */
  void on_subscribe_perception_health(generated_interfaces::msg::PerceptionHealth::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_localization_health`.
   */
  void on_subscribe_localization_health(generated_interfaces::msg::LocalizationHealth::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_planning_health`.
   */
  void on_subscribe_planning_health(generated_interfaces::msg::PlanningHealth::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_control_health`.
   */
  void on_subscribe_control_health(generated_interfaces::msg::ControlHealth::SharedPtr msg);

  /**
   * @brief Generated service handler for `server_check_safety_risk`.
   */
  void handle_server_check_safety_risk(
    const std::shared_ptr<generated_interfaces::srv::CheckSafetyRisk::Request> request,
    std::shared_ptr<generated_interfaces::srv::CheckSafetyRisk::Response> response);
  /**
   * @brief Generated service handler for `server_clear_emergency`.
   */
  void handle_server_clear_emergency(
    const std::shared_ptr<generated_interfaces::srv::ClearEmergency::Request> request,
    std::shared_ptr<generated_interfaces::srv::ClearEmergency::Response> response);

  /**
   * @brief Generated helper that prepares an async request for `client_reset_controller`.
   */
  void send_client_reset_controller_request();
  /**
   * @brief Generated helper that prepares an async request for `client_reset_perception`.
   */
  void send_client_reset_perception_request();

  rclcpp::Publisher<generated_interfaces::msg::SafetyState>::SharedPtr publish_safety_state_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::EmergencyBrake>::SharedPtr publish_emergency_brake_publisher_;
  rclcpp::Subscription<generated_interfaces::msg::DetectedObjects>::SharedPtr subscribe_detected_objects_safety_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::Trajectory>::SharedPtr subscribe_trajectory_safety_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::ControlCmd>::SharedPtr subscribe_control_cmd_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::ActuatorFeedback>::SharedPtr subscribe_actuator_feedback_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::PerceptionHealth>::SharedPtr subscribe_perception_health_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::LocalizationHealth>::SharedPtr subscribe_localization_health_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::PlanningHealth>::SharedPtr subscribe_planning_health_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::ControlHealth>::SharedPtr subscribe_control_health_subscriber_;
  rclcpp::Service<generated_interfaces::srv::CheckSafetyRisk>::SharedPtr server_check_safety_risk_service_;
  rclcpp::Service<generated_interfaces::srv::ClearEmergency>::SharedPtr server_clear_emergency_service_;
  rclcpp::Client<generated_interfaces::srv::ResetController>::SharedPtr client_reset_controller_client_;
  rclcpp::Client<generated_interfaces::srv::ResetPerception>::SharedPtr client_reset_perception_client_;
  rclcpp::TimerBase::SharedPtr publish_timer_;
};

}  // namespace safety_app