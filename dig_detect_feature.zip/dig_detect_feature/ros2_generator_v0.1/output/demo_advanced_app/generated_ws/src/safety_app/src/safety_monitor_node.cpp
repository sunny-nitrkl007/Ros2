#include "safety_app/safety_monitor_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace safety_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

SafetyMonitorNode::SafetyMonitorNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("safety_monitor_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: safety_monitor_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&SafetyMonitorNode::publish_generated_messages, this));
}

void SafetyMonitorNode::declare_generated_parameters()
{
  this->declare_parameter<bool>("risk_threshold", true);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: risk_threshold");
  this->declare_parameter<bool>("enable_fail_safe", true);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: enable_fail_safe");
}

void SafetyMonitorNode::setup_publishers()
{
  auto qos_publish_safety_state = make_qos(10, "reliable", "volatile");
  publish_safety_state_publisher_ = this->create_publisher<generated_interfaces::msg::SafetyState>("/safety/state", qos_publish_safety_state);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_safety_state -> /safety/state");
  auto qos_publish_emergency_brake = make_qos(20, "reliable", "volatile");
  publish_emergency_brake_publisher_ = this->create_publisher<generated_interfaces::msg::EmergencyBrake>("/safety/emergency_brake", qos_publish_emergency_brake);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_emergency_brake -> /safety/emergency_brake");
}

void SafetyMonitorNode::setup_subscribers()
{
  auto qos_subscribe_detected_objects_safety = make_qos(10, "reliable", "volatile");
  subscribe_detected_objects_safety_subscriber_ = this->create_subscription<generated_interfaces::msg::DetectedObjects>("/perception/detected_objects", qos_subscribe_detected_objects_safety, std::bind(&SafetyMonitorNode::on_subscribe_detected_objects_safety, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_detected_objects_safety <- /perception/detected_objects");
  auto qos_subscribe_trajectory_safety = make_qos(10, "reliable", "volatile");
  subscribe_trajectory_safety_subscriber_ = this->create_subscription<generated_interfaces::msg::Trajectory>("/planning/trajectory", qos_subscribe_trajectory_safety, std::bind(&SafetyMonitorNode::on_subscribe_trajectory_safety, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_trajectory_safety <- /planning/trajectory");
  auto qos_subscribe_control_cmd = make_qos(20, "reliable", "volatile");
  subscribe_control_cmd_subscriber_ = this->create_subscription<generated_interfaces::msg::ControlCmd>("/control/command", qos_subscribe_control_cmd, std::bind(&SafetyMonitorNode::on_subscribe_control_cmd, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_control_cmd <- /control/command");
  auto qos_subscribe_actuator_feedback = make_qos(10, "reliable", "volatile");
  subscribe_actuator_feedback_subscriber_ = this->create_subscription<generated_interfaces::msg::ActuatorFeedback>("/control/actuator_feedback", qos_subscribe_actuator_feedback, std::bind(&SafetyMonitorNode::on_subscribe_actuator_feedback, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_actuator_feedback <- /control/actuator_feedback");
  auto qos_subscribe_perception_health = make_qos(10, "reliable", "volatile");
  subscribe_perception_health_subscriber_ = this->create_subscription<generated_interfaces::msg::PerceptionHealth>("/perception/health", qos_subscribe_perception_health, std::bind(&SafetyMonitorNode::on_subscribe_perception_health, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_perception_health <- /perception/health");
  auto qos_subscribe_localization_health = make_qos(10, "reliable", "volatile");
  subscribe_localization_health_subscriber_ = this->create_subscription<generated_interfaces::msg::LocalizationHealth>("/localization/health", qos_subscribe_localization_health, std::bind(&SafetyMonitorNode::on_subscribe_localization_health, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_localization_health <- /localization/health");
  auto qos_subscribe_planning_health = make_qos(10, "reliable", "volatile");
  subscribe_planning_health_subscriber_ = this->create_subscription<generated_interfaces::msg::PlanningHealth>("/planning/health", qos_subscribe_planning_health, std::bind(&SafetyMonitorNode::on_subscribe_planning_health, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_planning_health <- /planning/health");
  auto qos_subscribe_control_health = make_qos(10, "reliable", "volatile");
  subscribe_control_health_subscriber_ = this->create_subscription<generated_interfaces::msg::ControlHealth>("/control/health", qos_subscribe_control_health, std::bind(&SafetyMonitorNode::on_subscribe_control_health, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_control_health <- /control/health");
}

void SafetyMonitorNode::setup_service_servers()
{
  server_check_safety_risk_service_ = this->create_service<generated_interfaces::srv::CheckSafetyRisk>("/safety/check_risk", std::bind(&SafetyMonitorNode::handle_server_check_safety_risk, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_check_safety_risk -> /safety/check_risk");
  server_clear_emergency_service_ = this->create_service<generated_interfaces::srv::ClearEmergency>("/safety/clear_emergency", std::bind(&SafetyMonitorNode::handle_server_clear_emergency, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_clear_emergency -> /safety/clear_emergency");
}

void SafetyMonitorNode::setup_service_clients()
{
  client_reset_controller_client_ = this->create_client<generated_interfaces::srv::ResetController>("/control/reset_controller");
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT CREATED: client_reset_controller -> /control/reset_controller");
  client_reset_perception_client_ = this->create_client<generated_interfaces::srv::ResetPerception>("/perception/reset");
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT CREATED: client_reset_perception -> /perception/reset");
}

void SafetyMonitorNode::publish_generated_messages()
{
  auto msg_publish_safety_state = generated_interfaces::msg::SafetyState();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_safety_state
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_safety_state.stamp_sec = 1;
  msg_publish_safety_state.source = "sample_source";
  msg_publish_safety_state.valid = true;
  msg_publish_safety_state.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_safety_state
  // ============================================================================

  publish_safety_state_publisher_->publish(msg_publish_safety_state);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /safety/state");
  auto msg_publish_emergency_brake = generated_interfaces::msg::EmergencyBrake();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_emergency_brake
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_emergency_brake.stamp_sec = 1;
  msg_publish_emergency_brake.source = "sample_source";
  msg_publish_emergency_brake.valid = true;
  msg_publish_emergency_brake.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_emergency_brake
  // ============================================================================

  publish_emergency_brake_publisher_->publish(msg_publish_emergency_brake);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /safety/emergency_brake");
}

void SafetyMonitorNode::on_subscribe_detected_objects_safety(generated_interfaces::msg::DetectedObjects::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /perception/detected_objects");
}
void SafetyMonitorNode::on_subscribe_trajectory_safety(generated_interfaces::msg::Trajectory::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /planning/trajectory");
}
void SafetyMonitorNode::on_subscribe_control_cmd(generated_interfaces::msg::ControlCmd::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /control/command");
}
void SafetyMonitorNode::on_subscribe_actuator_feedback(generated_interfaces::msg::ActuatorFeedback::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /control/actuator_feedback");
}
void SafetyMonitorNode::on_subscribe_perception_health(generated_interfaces::msg::PerceptionHealth::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /perception/health");
}
void SafetyMonitorNode::on_subscribe_localization_health(generated_interfaces::msg::LocalizationHealth::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /localization/health");
}
void SafetyMonitorNode::on_subscribe_planning_health(generated_interfaces::msg::PlanningHealth::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /planning/health");
}
void SafetyMonitorNode::on_subscribe_control_health(generated_interfaces::msg::ControlHealth::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /control/health");
}

void SafetyMonitorNode::handle_server_check_safety_risk(const std::shared_ptr<generated_interfaces::srv::CheckSafetyRisk::Request> request, std::shared_ptr<generated_interfaces::srv::CheckSafetyRisk::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /safety/check_risk");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_check_safety_risk
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->accepted = true;
  response->message = "sample_message";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_check_safety_risk
  // ============================================================================
}
void SafetyMonitorNode::handle_server_clear_emergency(const std::shared_ptr<generated_interfaces::srv::ClearEmergency::Request> request, std::shared_ptr<generated_interfaces::srv::ClearEmergency::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /safety/clear_emergency");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_clear_emergency
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->accepted = true;
  response->message = "sample_message";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_clear_emergency
  // ============================================================================
}

void SafetyMonitorNode::send_client_reset_controller_request()
{
  auto request = std::make_shared<generated_interfaces::srv::ResetController::Request>();
  if (client_reset_controller_client_->service_is_ready()) {
    RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT SEND: /control/reset_controller");
    client_reset_controller_client_->async_send_request(request);
  }
}
void SafetyMonitorNode::send_client_reset_perception_request()
{
  auto request = std::make_shared<generated_interfaces::srv::ResetPerception::Request>();
  if (client_reset_perception_client_->service_is_ready()) {
    RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT SEND: /perception/reset");
    client_reset_perception_client_->async_send_request(request);
  }
}

}  // namespace safety_app