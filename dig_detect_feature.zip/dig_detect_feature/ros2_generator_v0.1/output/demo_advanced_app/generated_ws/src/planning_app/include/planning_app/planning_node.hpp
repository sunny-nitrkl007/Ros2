#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/behavior_plan.hpp"
#include "generated_interfaces/msg/detected_objects.hpp"
#include "generated_interfaces/msg/ego_state.hpp"
#include "generated_interfaces/msg/free_space_grid.hpp"
#include "generated_interfaces/msg/lane_markings.hpp"
#include "generated_interfaces/msg/planner_debug.hpp"
#include "generated_interfaces/msg/planning_health.hpp"
#include "generated_interfaces/msg/route_plan.hpp"
#include "generated_interfaces/msg/safety_state.hpp"
#include "generated_interfaces/msg/trajectory.hpp"
#include "generated_interfaces/msg/vehicle_pose.hpp"
#include "generated_interfaces/msg/vehicle_velocity.hpp"
#include "generated_interfaces/srv/check_safety_risk.hpp"
#include "generated_interfaces/srv/get_object_details.hpp"
#include "generated_interfaces/srv/request_replan.hpp"

namespace planning_app
{

/**
 * @brief Generated ROS2 node class for `planning_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class PlanningNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit PlanningNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();

  /**
   * @brief Generated subscriber callback for `subscribe_detected_objects`.
   */
  void on_subscribe_detected_objects(generated_interfaces::msg::DetectedObjects::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_lane_markings`.
   */
  void on_subscribe_lane_markings(generated_interfaces::msg::LaneMarkings::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_free_space_grid`.
   */
  void on_subscribe_free_space_grid(generated_interfaces::msg::FreeSpaceGrid::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_vehicle_pose`.
   */
  void on_subscribe_vehicle_pose(generated_interfaces::msg::VehiclePose::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_vehicle_velocity`.
   */
  void on_subscribe_vehicle_velocity(generated_interfaces::msg::VehicleVelocity::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_ego_state`.
   */
  void on_subscribe_ego_state(generated_interfaces::msg::EgoState::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_safety_state`.
   */
  void on_subscribe_safety_state(generated_interfaces::msg::SafetyState::SharedPtr msg);

  /**
   * @brief Generated service handler for `server_request_replan`.
   */
  void handle_server_request_replan(
    const std::shared_ptr<generated_interfaces::srv::RequestReplan::Request> request,
    std::shared_ptr<generated_interfaces::srv::RequestReplan::Response> response);

  /**
   * @brief Generated helper that prepares an async request for `client_get_object_details`.
   */
  void send_client_get_object_details_request();
  /**
   * @brief Generated helper that prepares an async request for `client_check_safety_risk`.
   */
  void send_client_check_safety_risk_request();

  rclcpp::Publisher<generated_interfaces::msg::RoutePlan>::SharedPtr publish_route_plan_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::BehaviorPlan>::SharedPtr publish_behavior_plan_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::Trajectory>::SharedPtr publish_trajectory_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::PlannerDebug>::SharedPtr publish_planner_debug_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::PlanningHealth>::SharedPtr publish_planning_health_publisher_;
  rclcpp::Subscription<generated_interfaces::msg::DetectedObjects>::SharedPtr subscribe_detected_objects_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::LaneMarkings>::SharedPtr subscribe_lane_markings_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::FreeSpaceGrid>::SharedPtr subscribe_free_space_grid_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::VehiclePose>::SharedPtr subscribe_vehicle_pose_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::VehicleVelocity>::SharedPtr subscribe_vehicle_velocity_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::EgoState>::SharedPtr subscribe_ego_state_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::SafetyState>::SharedPtr subscribe_safety_state_subscriber_;
  rclcpp::Service<generated_interfaces::srv::RequestReplan>::SharedPtr server_request_replan_service_;
  rclcpp::Client<generated_interfaces::srv::GetObjectDetails>::SharedPtr client_get_object_details_client_;
  rclcpp::Client<generated_interfaces::srv::CheckSafetyRisk>::SharedPtr client_check_safety_risk_client_;
  rclcpp::TimerBase::SharedPtr publish_timer_;
};

}  // namespace planning_app