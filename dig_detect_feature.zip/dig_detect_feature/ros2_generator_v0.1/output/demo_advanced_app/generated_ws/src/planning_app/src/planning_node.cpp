#include "planning_app/planning_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace planning_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

PlanningNode::PlanningNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("planning_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: planning_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&PlanningNode::publish_generated_messages, this));
}

void PlanningNode::declare_generated_parameters()
{
  this->declare_parameter<double>("planning_rate_hz", 20.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: planning_rate_hz");
  this->declare_parameter<bool>("max_horizon_m", true);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: max_horizon_m");
}

void PlanningNode::setup_publishers()
{
  auto qos_publish_route_plan = make_qos(10, "reliable", "volatile");
  publish_route_plan_publisher_ = this->create_publisher<generated_interfaces::msg::RoutePlan>("/planning/route_plan", qos_publish_route_plan);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_route_plan -> /planning/route_plan");
  auto qos_publish_behavior_plan = make_qos(10, "reliable", "volatile");
  publish_behavior_plan_publisher_ = this->create_publisher<generated_interfaces::msg::BehaviorPlan>("/planning/behavior_plan", qos_publish_behavior_plan);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_behavior_plan -> /planning/behavior_plan");
  auto qos_publish_trajectory = make_qos(20, "reliable", "volatile");
  publish_trajectory_publisher_ = this->create_publisher<generated_interfaces::msg::Trajectory>("/planning/trajectory", qos_publish_trajectory);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_trajectory -> /planning/trajectory");
  auto qos_publish_planner_debug = make_qos(3, "best_effort", "volatile");
  publish_planner_debug_publisher_ = this->create_publisher<generated_interfaces::msg::PlannerDebug>("/planning/debug", qos_publish_planner_debug);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_planner_debug -> /planning/debug");
  auto qos_publish_planning_health = make_qos(10, "reliable", "volatile");
  publish_planning_health_publisher_ = this->create_publisher<generated_interfaces::msg::PlanningHealth>("/planning/health", qos_publish_planning_health);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_planning_health -> /planning/health");
}

void PlanningNode::setup_subscribers()
{
  auto qos_subscribe_detected_objects = make_qos(10, "reliable", "volatile");
  subscribe_detected_objects_subscriber_ = this->create_subscription<generated_interfaces::msg::DetectedObjects>("/perception/detected_objects", qos_subscribe_detected_objects, std::bind(&PlanningNode::on_subscribe_detected_objects, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_detected_objects <- /perception/detected_objects");
  auto qos_subscribe_lane_markings = make_qos(10, "reliable", "volatile");
  subscribe_lane_markings_subscriber_ = this->create_subscription<generated_interfaces::msg::LaneMarkings>("/perception/lane_markings", qos_subscribe_lane_markings, std::bind(&PlanningNode::on_subscribe_lane_markings, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_lane_markings <- /perception/lane_markings");
  auto qos_subscribe_free_space_grid = make_qos(10, "reliable", "volatile");
  subscribe_free_space_grid_subscriber_ = this->create_subscription<generated_interfaces::msg::FreeSpaceGrid>("/perception/free_space_grid", qos_subscribe_free_space_grid, std::bind(&PlanningNode::on_subscribe_free_space_grid, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_free_space_grid <- /perception/free_space_grid");
  auto qos_subscribe_vehicle_pose = make_qos(10, "reliable", "volatile");
  subscribe_vehicle_pose_subscriber_ = this->create_subscription<generated_interfaces::msg::VehiclePose>("/localization/pose", qos_subscribe_vehicle_pose, std::bind(&PlanningNode::on_subscribe_vehicle_pose, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_vehicle_pose <- /localization/pose");
  auto qos_subscribe_vehicle_velocity = make_qos(10, "reliable", "volatile");
  subscribe_vehicle_velocity_subscriber_ = this->create_subscription<generated_interfaces::msg::VehicleVelocity>("/localization/velocity", qos_subscribe_vehicle_velocity, std::bind(&PlanningNode::on_subscribe_vehicle_velocity, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_vehicle_velocity <- /localization/velocity");
  auto qos_subscribe_ego_state = make_qos(10, "reliable", "volatile");
  subscribe_ego_state_subscriber_ = this->create_subscription<generated_interfaces::msg::EgoState>("/vehicle/ego_state", qos_subscribe_ego_state, std::bind(&PlanningNode::on_subscribe_ego_state, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_ego_state <- /vehicle/ego_state");
  auto qos_subscribe_safety_state = make_qos(10, "reliable", "volatile");
  subscribe_safety_state_subscriber_ = this->create_subscription<generated_interfaces::msg::SafetyState>("/safety/state", qos_subscribe_safety_state, std::bind(&PlanningNode::on_subscribe_safety_state, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_safety_state <- /safety/state");
}

void PlanningNode::setup_service_servers()
{
  server_request_replan_service_ = this->create_service<generated_interfaces::srv::RequestReplan>("/planning/request_replan", std::bind(&PlanningNode::handle_server_request_replan, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_request_replan -> /planning/request_replan");
}

void PlanningNode::setup_service_clients()
{
  client_get_object_details_client_ = this->create_client<generated_interfaces::srv::GetObjectDetails>("/perception/get_object_details");
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT CREATED: client_get_object_details -> /perception/get_object_details");
  client_check_safety_risk_client_ = this->create_client<generated_interfaces::srv::CheckSafetyRisk>("/safety/check_risk");
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT CREATED: client_check_safety_risk -> /safety/check_risk");
}

void PlanningNode::publish_generated_messages()
{
  auto msg_publish_route_plan = generated_interfaces::msg::RoutePlan();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_route_plan
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_route_plan.stamp_sec = 1;
  msg_publish_route_plan.source = "sample_source";
  msg_publish_route_plan.valid = true;
  msg_publish_route_plan.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_route_plan
  // ============================================================================

  publish_route_plan_publisher_->publish(msg_publish_route_plan);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /planning/route_plan");
  auto msg_publish_behavior_plan = generated_interfaces::msg::BehaviorPlan();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_behavior_plan
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_behavior_plan.stamp_sec = 1;
  msg_publish_behavior_plan.source = "sample_source";
  msg_publish_behavior_plan.valid = true;
  msg_publish_behavior_plan.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_behavior_plan
  // ============================================================================

  publish_behavior_plan_publisher_->publish(msg_publish_behavior_plan);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /planning/behavior_plan");
  auto msg_publish_trajectory = generated_interfaces::msg::Trajectory();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_trajectory
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_trajectory.stamp_sec = 1;
  msg_publish_trajectory.source = "sample_source";
  msg_publish_trajectory.valid = true;
  msg_publish_trajectory.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_trajectory
  // ============================================================================

  publish_trajectory_publisher_->publish(msg_publish_trajectory);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /planning/trajectory");
  auto msg_publish_planner_debug = generated_interfaces::msg::PlannerDebug();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_planner_debug
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_planner_debug.stamp_sec = 1;
  msg_publish_planner_debug.source = "sample_source";
  msg_publish_planner_debug.valid = true;
  msg_publish_planner_debug.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_planner_debug
  // ============================================================================

  publish_planner_debug_publisher_->publish(msg_publish_planner_debug);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /planning/debug");
  auto msg_publish_planning_health = generated_interfaces::msg::PlanningHealth();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_planning_health
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_planning_health.stamp_sec = 1;
  msg_publish_planning_health.source = "sample_source";
  msg_publish_planning_health.valid = true;
  msg_publish_planning_health.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_planning_health
  // ============================================================================

  publish_planning_health_publisher_->publish(msg_publish_planning_health);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /planning/health");
}

void PlanningNode::on_subscribe_detected_objects(generated_interfaces::msg::DetectedObjects::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /perception/detected_objects");
}
void PlanningNode::on_subscribe_lane_markings(generated_interfaces::msg::LaneMarkings::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /perception/lane_markings");
}
void PlanningNode::on_subscribe_free_space_grid(generated_interfaces::msg::FreeSpaceGrid::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /perception/free_space_grid");
}
void PlanningNode::on_subscribe_vehicle_pose(generated_interfaces::msg::VehiclePose::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /localization/pose");
}
void PlanningNode::on_subscribe_vehicle_velocity(generated_interfaces::msg::VehicleVelocity::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /localization/velocity");
}
void PlanningNode::on_subscribe_ego_state(generated_interfaces::msg::EgoState::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /vehicle/ego_state");
}
void PlanningNode::on_subscribe_safety_state(generated_interfaces::msg::SafetyState::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /safety/state");
}

void PlanningNode::handle_server_request_replan(const std::shared_ptr<generated_interfaces::srv::RequestReplan::Request> request, std::shared_ptr<generated_interfaces::srv::RequestReplan::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /planning/request_replan");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_request_replan
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->accepted = true;
  response->message = "sample_message";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_request_replan
  // ============================================================================
}

void PlanningNode::send_client_get_object_details_request()
{
  auto request = std::make_shared<generated_interfaces::srv::GetObjectDetails::Request>();
  if (client_get_object_details_client_->service_is_ready()) {
    RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT SEND: /perception/get_object_details");
    client_get_object_details_client_->async_send_request(request);
  }
}
void PlanningNode::send_client_check_safety_risk_request()
{
  auto request = std::make_shared<generated_interfaces::srv::CheckSafetyRisk::Request>();
  if (client_check_safety_risk_client_->service_is_ready()) {
    RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT SEND: /safety/check_risk");
    client_check_safety_risk_client_->async_send_request(request);
  }
}

}  // namespace planning_app