#include "control_app/control_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace control_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

ControlNode::ControlNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("control_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: control_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&ControlNode::publish_generated_messages, this));
}

void ControlNode::declare_generated_parameters()
{
  this->declare_parameter<double>("control_rate_hz", 20.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: control_rate_hz");
  this->declare_parameter<double>("max_acceleration_mps2", 20.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: max_acceleration_mps2");
}

void ControlNode::setup_publishers()
{
  auto qos_publish_control_cmd = make_qos(20, "reliable", "volatile");
  publish_control_cmd_publisher_ = this->create_publisher<generated_interfaces::msg::ControlCmd>("/control/command", qos_publish_control_cmd);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_control_cmd -> /control/command");
  auto qos_publish_actuator_feedback = make_qos(10, "reliable", "volatile");
  publish_actuator_feedback_publisher_ = this->create_publisher<generated_interfaces::msg::ActuatorFeedback>("/control/actuator_feedback", qos_publish_actuator_feedback);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_actuator_feedback -> /control/actuator_feedback");
  auto qos_publish_control_health = make_qos(10, "reliable", "volatile");
  publish_control_health_publisher_ = this->create_publisher<generated_interfaces::msg::ControlHealth>("/control/health", qos_publish_control_health);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: publish_control_health -> /control/health");
}

void ControlNode::setup_subscribers()
{
  auto qos_subscribe_trajectory = make_qos(20, "reliable", "volatile");
  subscribe_trajectory_subscriber_ = this->create_subscription<generated_interfaces::msg::Trajectory>("/planning/trajectory", qos_subscribe_trajectory, std::bind(&ControlNode::on_subscribe_trajectory, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_trajectory <- /planning/trajectory");
  auto qos_subscribe_emergency_brake = make_qos(20, "reliable", "volatile");
  subscribe_emergency_brake_subscriber_ = this->create_subscription<generated_interfaces::msg::EmergencyBrake>("/safety/emergency_brake", qos_subscribe_emergency_brake, std::bind(&ControlNode::on_subscribe_emergency_brake, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_emergency_brake <- /safety/emergency_brake");
  auto qos_subscribe_vehicle_velocity = make_qos(10, "reliable", "volatile");
  subscribe_vehicle_velocity_subscriber_ = this->create_subscription<generated_interfaces::msg::VehicleVelocity>("/localization/velocity", qos_subscribe_vehicle_velocity, std::bind(&ControlNode::on_subscribe_vehicle_velocity, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: subscribe_vehicle_velocity <- /localization/velocity");
}

void ControlNode::setup_service_servers()
{
  server_set_control_mode_service_ = this->create_service<generated_interfaces::srv::SetControlMode>("/control/set_mode", std::bind(&ControlNode::handle_server_set_control_mode, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_set_control_mode -> /control/set_mode");
  server_reset_controller_service_ = this->create_service<generated_interfaces::srv::ResetController>("/control/reset_controller", std::bind(&ControlNode::handle_server_reset_controller, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_reset_controller -> /control/reset_controller");
}

void ControlNode::setup_service_clients()
{
  client_request_replan_client_ = this->create_client<generated_interfaces::srv::RequestReplan>("/planning/request_replan");
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT CREATED: client_request_replan -> /planning/request_replan");
}

void ControlNode::publish_generated_messages()
{
  auto msg_publish_control_cmd = generated_interfaces::msg::ControlCmd();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_control_cmd
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_control_cmd.stamp_sec = 1;
  msg_publish_control_cmd.source = "sample_source";
  msg_publish_control_cmd.valid = true;
  msg_publish_control_cmd.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_control_cmd
  // ============================================================================

  publish_control_cmd_publisher_->publish(msg_publish_control_cmd);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /control/command");
  auto msg_publish_actuator_feedback = generated_interfaces::msg::ActuatorFeedback();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_actuator_feedback
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_actuator_feedback.stamp_sec = 1;
  msg_publish_actuator_feedback.source = "sample_source";
  msg_publish_actuator_feedback.valid = true;
  msg_publish_actuator_feedback.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_actuator_feedback
  // ============================================================================

  publish_actuator_feedback_publisher_->publish(msg_publish_actuator_feedback);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /control/actuator_feedback");
  auto msg_publish_control_health = generated_interfaces::msg::ControlHealth();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for publish_control_health
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  msg_publish_control_health.stamp_sec = 1;
  msg_publish_control_health.source = "sample_source";
  msg_publish_control_health.valid = true;
  msg_publish_control_health.value = 4.0;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for publish_control_health
  // ============================================================================

  publish_control_health_publisher_->publish(msg_publish_control_health);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /control/health");
}

void ControlNode::on_subscribe_trajectory(generated_interfaces::msg::Trajectory::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /planning/trajectory");
}
void ControlNode::on_subscribe_emergency_brake(generated_interfaces::msg::EmergencyBrake::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /safety/emergency_brake");
}
void ControlNode::on_subscribe_vehicle_velocity(generated_interfaces::msg::VehicleVelocity::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /localization/velocity");
}

void ControlNode::handle_server_set_control_mode(const std::shared_ptr<generated_interfaces::srv::SetControlMode::Request> request, std::shared_ptr<generated_interfaces::srv::SetControlMode::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /control/set_mode");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_set_control_mode
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->accepted = true;
  response->message = "sample_message";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_set_control_mode
  // ============================================================================
}
void ControlNode::handle_server_reset_controller(const std::shared_ptr<generated_interfaces::srv::ResetController::Request> request, std::shared_ptr<generated_interfaces::srv::ResetController::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /control/reset_controller");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_reset_controller
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->accepted = true;
  response->message = "sample_message";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_reset_controller
  // ============================================================================
}

void ControlNode::send_client_request_replan_request()
{
  auto request = std::make_shared<generated_interfaces::srv::RequestReplan::Request>();
  if (client_request_replan_client_->service_is_ready()) {
    RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT SEND: /planning/request_replan");
    client_request_replan_client_->async_send_request(request);
  }
}

}  // namespace control_app