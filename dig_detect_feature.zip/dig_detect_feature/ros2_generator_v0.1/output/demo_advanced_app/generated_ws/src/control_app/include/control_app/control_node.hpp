#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/actuator_feedback.hpp"
#include "generated_interfaces/msg/control_cmd.hpp"
#include "generated_interfaces/msg/control_health.hpp"
#include "generated_interfaces/msg/emergency_brake.hpp"
#include "generated_interfaces/msg/trajectory.hpp"
#include "generated_interfaces/msg/vehicle_velocity.hpp"
#include "generated_interfaces/srv/request_replan.hpp"
#include "generated_interfaces/srv/reset_controller.hpp"
#include "generated_interfaces/srv/set_control_mode.hpp"

namespace control_app
{

/**
 * @brief Generated ROS2 node class for `control_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class ControlNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit ControlNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();

  /**
   * @brief Generated subscriber callback for `subscribe_trajectory`.
   */
  void on_subscribe_trajectory(generated_interfaces::msg::Trajectory::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_emergency_brake`.
   */
  void on_subscribe_emergency_brake(generated_interfaces::msg::EmergencyBrake::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `subscribe_vehicle_velocity`.
   */
  void on_subscribe_vehicle_velocity(generated_interfaces::msg::VehicleVelocity::SharedPtr msg);

  /**
   * @brief Generated service handler for `server_set_control_mode`.
   */
  void handle_server_set_control_mode(
    const std::shared_ptr<generated_interfaces::srv::SetControlMode::Request> request,
    std::shared_ptr<generated_interfaces::srv::SetControlMode::Response> response);
  /**
   * @brief Generated service handler for `server_reset_controller`.
   */
  void handle_server_reset_controller(
    const std::shared_ptr<generated_interfaces::srv::ResetController::Request> request,
    std::shared_ptr<generated_interfaces::srv::ResetController::Response> response);

  /**
   * @brief Generated helper that prepares an async request for `client_request_replan`.
   */
  void send_client_request_replan_request();

  rclcpp::Publisher<generated_interfaces::msg::ControlCmd>::SharedPtr publish_control_cmd_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::ActuatorFeedback>::SharedPtr publish_actuator_feedback_publisher_;
  rclcpp::Publisher<generated_interfaces::msg::ControlHealth>::SharedPtr publish_control_health_publisher_;
  rclcpp::Subscription<generated_interfaces::msg::Trajectory>::SharedPtr subscribe_trajectory_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::EmergencyBrake>::SharedPtr subscribe_emergency_brake_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::VehicleVelocity>::SharedPtr subscribe_vehicle_velocity_subscriber_;
  rclcpp::Service<generated_interfaces::srv::SetControlMode>::SharedPtr server_set_control_mode_service_;
  rclcpp::Service<generated_interfaces::srv::ResetController>::SharedPtr server_reset_controller_service_;
  rclcpp::Client<generated_interfaces::srv::RequestReplan>::SharedPtr client_request_replan_client_;
  rclcpp::TimerBase::SharedPtr publish_timer_;
};

}  // namespace control_app