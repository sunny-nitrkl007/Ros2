from schema.model.schema_4_ecu import (
    BASET1,
    ECU,
    MII,
    ECUPort,
    Switch,
    VLANEntry,
)
from schema.model.schema_4_someip import (
    SOMEIPServiceInterface,
)


def test_ecu_parsing_from_dicts(metadata_entry, embedded_metadata_entry, ecu_port: ECUPort, MII_entry):
    SOMEIPServiceInterface(meta=metadata_entry, name="s", id=1)
    kwargs = dict(
        name="test",
        topology={
            "connections": [
                {
                    "type": "ecu_port_to_switch_port",
                    "id": "1",
                    "ecu_port": "test_ecu_port",
                    "switch_port": "b",
                },
            ]
        },
        switches=[
            dict(
                meta=embedded_metadata_entry,
                name="a",
                ports=[
                    dict(
                        name="b",
                        silicon_port_no=1,
                        default_vlan_id=1,
                        mii_config=MII(mode="mac"),
                    ),
                    dict(name="c", silicon_port_no=2, default_vlan_id=1),
                ],
                vlans=[VLANEntry(name="vlan10", id=1, default_priority=1, ports=["a"])],
            )
        ],
        controllers=[],
        ports=[
            ECUPort(
                name="test_ecu_port",
                mdi_config=BASET1(speed=100, role="slave"),
                mii_config=MII(mode="phy"),
            )
        ],
        ecu_metadata=metadata_entry,
    )
    switch = dict(
        meta=embedded_metadata_entry,
        name="d",
        ports=[
            dict(
                name="e",
                silicon_port_no=1,
                default_vlan_id=1,
                mii_config=MII(mode="mac"),
            ),
            dict(name="f", silicon_port_no=2, default_vlan_id=1),
        ],
        vlans=[VLANEntry(name="vlan10", id=1, default_priority=1, ports=["a"])],
    )
    Switch.model_validate(switch)
    ECU.model_validate(kwargs)
