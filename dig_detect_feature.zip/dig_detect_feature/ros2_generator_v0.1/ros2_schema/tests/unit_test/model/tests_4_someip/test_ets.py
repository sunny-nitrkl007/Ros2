import pydantic_yaml

from schema.model.schema_4_someip import SOMEIPServiceInterface


def test_ets():
    ets_high: SOMEIPServiceInterface = pydantic_yaml.parse_yaml_file_as(
        SOMEIPServiceInterface,
        "./examples/schema_example/general/someip/services/ets.yaml",
    )
    assert ets_high.id == 0x101
