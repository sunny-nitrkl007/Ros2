import pytest
from approvaltests import set_default_reporter
from approvaltests.reporters.diff_reporter import DiffReporter

from schema.sdk.workspace.schema_workspace import schemaWorkspace


@pytest.fixture
def get_schema_example_path(pytestconfig):
    project_root = pytestconfig.rootpath
    return str((project_root / "examples" / "schema_example"))


@pytest.fixture
def loaded_workspace(get_schema_example_path):
    return schemaWorkspace.load_workspace("test_workspace", get_schema_example_path)


@pytest.fixture
def get_relative_schema_example_path():
    return "examples/schema_example"


def configure_approvaltests():
    set_default_reporter(DiffReporter())


@pytest.fixture(scope="session", autouse=True)
def set_default_reporter_for_all_tests() -> None:
    configure_approvaltests()
