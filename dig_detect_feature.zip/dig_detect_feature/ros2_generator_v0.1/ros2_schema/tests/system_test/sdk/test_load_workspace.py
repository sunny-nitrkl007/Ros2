import asyncio
import shutil
from pathlib import Path

import pytest
from pydantic import ValidationError

from schema.sdk.workspace.schema_workspace import schemaWorkspace

from .helper_load_ws import (
    append_yaml_content,
    model_has_socket,
    update_yaml_content,
)

# Verify loading workspace multiple times
absolute_path = Path(__file__).parents[3] / "examples" / "schema_example"


@pytest.mark.xfail(reason="Known bug")
def test_load_workspace_multiple_times(tmpdir):
    for i in range(1, 4):
        destination_folder = Path(tmpdir) / f"copy{i}"
        shutil.copytree(absolute_path, destination_folder)
        workspace = schemaWorkspace.load_workspace("schema_example", destination_folder)
        assert workspace is not None
        if destination_folder.exists():
            shutil.rmtree(destination_folder)


# Verify workspace loads with valid absolute path
@pytest.mark.skip(reason="Fails if Workspace already loaded")
def test_load_workspace_valid_absolute_path():
    workspace = schemaWorkspace.load_workspace("schema_example", absolute_path)
    assert workspace is not None
    assert workspace.schema_model is not None
    assert workspace.schema_model.ecus
    assert workspace.schema_model.topology
    assert workspace.schema_model.topology.system_topology
    assert workspace.schema_model.general
    assert workspace.schema_model.general.someip_config
    assert workspace.schema_model.general.tcp_profiles
    assert workspace.schema_model.metadata
    assert model_has_socket(workspace)


# Verify workspace loads with valid relative path
relative_path = Path(Path(__file__).parent, "..", "..", "..", "examples", "schema_example")


def test_load_workspace_valid_relative_path():
    workspace = schemaWorkspace.load_workspace("schema_example", relative_path)
    assert workspace is not None
    assert workspace.schema_model is not None
    assert workspace.schema_model.ecus
    assert workspace.schema_model.topology
    assert workspace.schema_model.topology.system_topology
    assert workspace.schema_model.general
    assert workspace.schema_model.general.someip_config
    assert workspace.schema_model.general.tcp_profiles
    assert workspace.schema_model.metadata
    assert model_has_socket(workspace)


def test_load_workspace_valid_str_path():
    workspace = schemaWorkspace.load_workspace("schema_example", str(absolute_path))
    assert workspace is not None
    assert workspace.schema_model is not None
    assert workspace.schema_model.ecus
    assert workspace.schema_model.topology
    assert workspace.schema_model.topology.system_topology
    assert workspace.schema_model.general
    assert workspace.schema_model.general.someip_config
    assert workspace.schema_model.general.tcp_profiles
    assert workspace.schema_model.metadata
    assert model_has_socket(workspace)


# Verify the existence of attributes
required_attributes = [
    "name",
    "documents",
    "objects",
    "sources",
    "dependencies",
    "reverse_deps",
    "_diagnostics",
]


@pytest.mark.parametrize("attribute", required_attributes)
@pytest.mark.xfail(reason="Known bug")
def test_load_workspace_exsistence_attribute(attribute):
    workspace = schemaWorkspace.load_workspace("schema_example", absolute_path)
    assert hasattr(workspace, attribute), f"Workspace is missing attribute: {attribute}"


# Verify handling invalid workspace directory path
def test_load_workspace_invalid_yaml_path():
    with pytest.raises(FileNotFoundError):
        schemaWorkspace.load_workspace("schema_example", "/path/to/nonexistent/directory")


def test_load_workspace_empty_name():
    with pytest.raises(Exception):
        schemaWorkspace.load_workspace("", absolute_path)


def test_load_workspace_empty_path():
    with pytest.raises(Exception):
        schemaWorkspace.load_workspace("schema_example", "")


# Verify handling missing mandatory directory
subfolders = [
    Path(absolute_path, "ecus"),
    *Path(absolute_path).glob("ecus/*/controllers"),
]


@pytest.mark.parametrize("subfolder", subfolders)
def test_load_workspace_missing_mandatory_folder(tmpdir, subfolder):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    shutil.rmtree(destination_folder / subfolder.relative_to(absolute_path))
    with pytest.raises(FileNotFoundError):
        schemaWorkspace.load_workspace("schema_example", destination_folder)
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


# Verify handling missing mandatory file
files = [
    Path(absolute_path, "system_metadata.yaml"),
    *Path(absolute_path).glob("ecus/*/ports.yaml"),
    *Path(absolute_path).glob("ecus/*/topology.yaml"),
    *Path(absolute_path).glob("ecus/*/ecu_metadata.yaml"),
    *Path(absolute_path).glob("ecus/*/controllers/*/ethernet_interfaces/*/interface_config.yaml"),
    *Path(absolute_path).glob("ecus/*/controllers/*/controller_metadata.yaml"),
]


@pytest.mark.parametrize("file", files)
def test_load_workspace_missing_mandatory_file(tmpdir, file):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    path_to_remove = destination_folder / file.relative_to(absolute_path)
    path_to_remove.unlink()
    try:
        loaded_ws = schemaWorkspace.load_workspace("schema_example", destination_folder)
        assert loaded_ws.load_errors != []
    except ValidationError:
        pass
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


# Verify handling unsupported file format
files = [
    Path(absolute_path, "system_metadata.yaml"),
    *Path(absolute_path).glob("ecus/*/ports.yaml"),
    *Path(absolute_path).glob("ecus/*/topology.yaml"),
    *Path(absolute_path).glob("ecus/*/ecu_metadata.yaml"),
    *Path(absolute_path).glob("ecus/*/controllers/*/ethernet_interfaces/*/interface_config.yaml"),
    *Path(absolute_path).glob("ecus/*/controllers/*/controller_metadata.yaml"),
]


@pytest.mark.parametrize("file", files)
def test_load_workspace_invalid_format(tmpdir, file):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    file_to_rename = destination_folder / file.relative_to(absolute_path)
    new_file_name = file_to_rename.name[: -len(".yaml")] + "yaml"
    new_file_path = file_to_rename.with_name(new_file_name)
    file_to_rename.rename(new_file_path)
    try:
        loaded_ws = schemaWorkspace.load_workspace("schema_example", destination_folder)
        assert loaded_ws.load_errors != []
    except ValidationError:
        pass
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


# Verify workspace loading with added image (schema/diagram)
image_path = Path(__file__).parents[2] / "docs" / "source" / "_static" / "technica-logo.png"
directories = [absolute_path] + [path for path in absolute_path.rglob("*") if path.is_dir()]


@pytest.mark.parametrize("dir", directories)
@pytest.mark.skip(reason="feature not implemented")
def test_load_workspace_add_image(tmpdir, dir):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    path_to_add = destination_folder / dir.relative_to(absolute_path)
    shutil.copy(image_path, path_to_add)
    workspace = schemaWorkspace.load_workspace("schema_example", destination_folder)
    assert workspace is not None
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


# Verify handling case sensitivity for keys
def test_load_workspace_upper_key(tmpdir):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    file_to_update = (
        destination_folder
        / "ecus"
        / "eth_ecu"
        / "controllers"
        / "eth_ecu_controller1"
        / "ethernet_interfaces"
        / "eth_ecu_c1_iface1"
        / "interface_config.yaml"
    )
    update_yaml_content(file_to_update, "name", "NAME")
    workspace = schemaWorkspace.load_workspace("schema_example", destination_folder)
    assert "Field required" in str(workspace.load_errors)
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


# Verify handling incorrect type for value
def test_load_workspace_incorret_value_type(tmpdir):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    file_to_update = (
        destination_folder
        / "ecus"
        / "eth_ecu"
        / "controllers"
        / "eth_ecu_controller1"
        / "ethernet_interfaces"
        / "eth_ecu_c1_iface1"
        / "interface_config.yaml"
    )
    update_yaml_content(file_to_update, "name: eth_ecu_c1_iface1", "name: 123")
    workspace = schemaWorkspace.load_workspace("schema_example", destination_folder)
    assert "Input should be a valid string" in str(workspace.load_errors)
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


# Verify handling incorrect format for value
invalid_format = {
    "001122334455": "mac_address_format\n  Must have the format",
    "00:11:22:33:xx:XX": "mac_address\n  Unrecognized format",
    "00:11:22": "mac_address\n  Length for a 00:11:22 MAC address must be 14",
}


@pytest.mark.parametrize("key, value", invalid_format.items())
@pytest.mark.xfail(reason="Known bug")
def test_load_workspace_incorret_value_format(tmpdir, key, value):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    file_to_update = (
        destination_folder
        / "ecus"
        / "eth_ecu"
        / "controllers"
        / "eth_ecu_controller1"
        / "ethernet_interfaces"
        / "eth_ecu_c1_iface1"
        / "interface_config.yaml"
    )
    update_yaml_content(file_to_update, "mac_address: 00:11:22:33:44:55", f"mac_address: {key}")
    with pytest.raises(ValidationError) as exc_info:
        schemaWorkspace.load_workspace("schema_example", destination_folder)
    assert value in str(exc_info.value)
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


# Validate handling of extra key/value
def test_load_workspace_extra_key_value(tmpdir):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    file_to_update = (
        destination_folder
        / "ecus"
        / "eth_ecu"
        / "controllers"
        / "eth_ecu_controller1"
        / "ethernet_interfaces"
        / "eth_ecu_c1_iface1"
        / "interface_config.yaml"
    )
    append_yaml_content(file_to_update, "\nnew_value: something\n")
    try:
        loaded_ws = schemaWorkspace.load_workspace("schema_example", destination_folder)
        assert loaded_ws.load_errors != []
    except ValidationError as exc_info:
        assert "new_value\n  Extra inputs are not permitted" in str(exc_info)
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


# Verify handling indentation fault
def test_load_workspace_key_value_misplaced(tmpdir):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    file_to_update = (
        destination_folder
        / "ecus"
        / "eth_ecu"
        / "controllers"
        / "eth_ecu_controller1"
        / "ethernet_interfaces"
        / "eth_ecu_c1_iface1"
        / "interface_config.yaml"
    )
    update_yaml_content(file_to_update, "  mode: mac", "mode: mac")
    try:
        loaded_ws = schemaWorkspace.load_workspace("schema_example", destination_folder)
        assert loaded_ws.load_errors != []
    except ValidationError as exc_info:
        assert "mii_config.sgmii.mode\n  Field required" in str(exc_info)
        assert "mode\n  Extra inputs are not permitted" in str(exc_info)
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


# Verify handling duplicate keys
@pytest.mark.skip(reason="feature not implemented")
def test_load_workspace_duplicate_key(tmpdir):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    file_to_update = (
        destination_folder
        / "ecus"
        / "eth_ecu"
        / "controllers"
        / "eth_ecu_controller1"
        / "ethernet_interfaces"
        / "eth_ecu_c1_iface1"
        / "interface_config.yaml"
    )
    update_yaml_content(
        file_to_update,
        "mac_address: 00:11:22:33:44:55",
        "mac_address: 00:11:22:33:44:55\n    mac_address: 11:22:33:44:55:66",
    )
    with pytest.raises(Exception):
        schemaWorkspace.load_workspace("schema_example", destination_folder)
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


# Verify handling missing dashe in list items
@pytest.mark.skip(reason="Test should not depend on number of spaces")
def test_load_workspace_missing_dashe(tmpdir):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    file_to_update = (
        destination_folder
        / "ecus"
        / "eth_ecu"
        / "controllers"
        / "eth_ecu_controller1"
        / "ethernet_interfaces"
        / "eth_ecu_c1_iface1"
        / "interface_config.yaml"
    )
    update_yaml_content(
        file_to_update,
        "multicast:\n            - 224.0.0.1",
        "multicast:\n            224.0.0.1",
    )
    try:
        loaded_ws = schemaWorkspace.load_workspace("schema_example", destination_folder)
        assert loaded_ws.load_errors != []
    except ValidationError as exc_info:
        assert "multicast\n  Input should be a valid list" in str(exc_info)
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


# Verify handling missing key/value
def test_load_workspace_missing_key_value(tmpdir):
    destination_folder = Path(tmpdir) / "copy"
    shutil.copytree(absolute_path, destination_folder)
    file_to_update = (
        destination_folder
        / "ecus"
        / "eth_ecu"
        / "controllers"
        / "eth_ecu_controller1"
        / "ethernet_interfaces"
        / "eth_ecu_c1_iface1"
        / "interface_config.yaml"
    )
    update_yaml_content(file_to_update, "name: eth_ecu_c1_iface1", "")
    try:
        loaded_ws = schemaWorkspace.load_workspace("schema_example", destination_folder)
        assert loaded_ws.load_errors != []
    except ValidationError as exc_info:
        assert "name\n  Field required" in str(exc_info)
    if destination_folder.exists():
        shutil.rmtree(destination_folder)


def _assert_workspace_valid(ws: schemaWorkspace):
    assert ws is not None
    assert ws.schema_model is not None
    assert ws.load_errors == []
    assert ws.schema_model.ecus
    assert ws.schema_model.topology
    assert ws.schema_model.topology.system_topology
    assert ws.schema_model.general
    assert ws.schema_model.general.someip_config
    assert ws.schema_model.general.tcp_profiles
    assert ws.schema_model.metadata
    assert model_has_socket(ws)


# Verify loading multiple independent workspace copies sequentially
@pytest.mark.skip("time consumption high")
def test_load_multiple_workspaces_sync(tmpdir):
    workspaces = []
    for i in range(1, 4):
        destination = Path(tmpdir) / f"copy{i}"
        shutil.copytree(absolute_path, destination)
        ws = schemaWorkspace.load_workspace(f"schema_example_{i}", destination)
        workspaces.append(ws)

    for ws in workspaces:
        _assert_workspace_valid(ws)


# Verify loading multiple independent workspace copies concurrently
@pytest.mark.skip("time consumption high")
def test_load_multiple_workspaces_async(tmpdir):
    paths = []
    for i in range(1, 4):
        destination = Path(tmpdir) / f"copy{i}"
        shutil.copytree(absolute_path, destination)
        paths.append((f"schema_example_{i}", destination))

    async def load_all():
        tasks = [asyncio.to_thread(schemaWorkspace.load_workspace, name, path) for name, path in paths]
        return await asyncio.gather(*tasks)

    workspaces = asyncio.run(load_all())

    for ws in workspaces:
        _assert_workspace_valid(ws)
