from pathlib import Path

import pytest

from schema.core.base_models import (
    DictInstances,
    ListInstances,
    NamedDictInstances,
    NamedListInstances,
    Registry,
    UniqueName,
)
from schema.core.base_models.instances_registery import registry_context

CENTRAL_REGISTRIES = [
    UniqueName,
    ListInstances,
    NamedListInstances,
    NamedDictInstances,
    DictInstances,
]

from schema.sdk.utils.model_dependencies import cleanup_old_caches


def pytest_configure(config):
    # Build the on-disk dependency graph cache once in the xdist master so that
    # workers start with a warm cache and don't serialise on the FileLock.
    if hasattr(config, "workerinput"):
        return
    cleanup_old_caches()
    from schema.sdk.workspace.schema_workspace import schemaWorkspace

    example_path = Path(__file__).parent.parent / "examples" / "schema_example"
    schemaWorkspace.load_workspace("schema_example", example_path)


@pytest.fixture(autouse=True)
def reset_global_registery():
    with registry_context(Registry()):
        yield
