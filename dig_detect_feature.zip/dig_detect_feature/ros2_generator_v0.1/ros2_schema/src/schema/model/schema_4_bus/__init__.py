"""Top-level package for schema-4-bus."""

from schema.model.schema_4_bus.can_bus import (
    CANBus,
)
from schema.model.schema_4_bus.lin_bus import (
    LINBus,
    LINScheduleEntry,
    LINScheduleTable,
)

__all__ = [
    # CAN
    "CANBus",
    # LIN
    "LINScheduleEntry",
    "LINScheduleTable",
    "LINBus",
]
