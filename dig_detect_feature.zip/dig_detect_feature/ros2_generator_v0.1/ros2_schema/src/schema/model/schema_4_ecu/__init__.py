"""
This package provides models for representing an ECU in the schema architecture, including controllers, ports, switches, sockets,
and internal topology definitions.
"""

from .controller import (
    ComputeNodes,
    Controller,
    ControllerInterface,
    EthernetInterface,
    VirtualControllerInterface,
    VirtualSwitch,
    VirtualSwitchPort,
)
from .ecu import ECU
from .internal_topology import InternalTopology
from .mac_multicast_endpoint import (
    AVTPMulticastEndpoint,
    MACMulticastEndpoint,
    MACMulticastEndpoints,
)
from .multicast_groups import MulticastGroupMembership
from .phy import BASET, BASET1, BASET1S, MII, RGMII, RMII, SGMII, XFI
from .port import ECUPort
from .router import RouteEntry
from .socket_container import SocketContainer
from .sockets import (
    IPv4AddressEndpoint,
    IPv6AddressEndpoint,
    Socket,
    SocketTCP,
    SocketUDP,
    TCPOption,
    UDPOption,
)
from .switch import (
    Switch,
    SwitchPort,
    TCAMRule,
    TrafficClass,
)
from .vlan_entry import MulticastGroup, VLANEntry

__all__ = [
    "ComputeNodes",
    "Controller",
    "ControllerInterface",
    "EthernetInterface",
    "VirtualSwitch",
    "VirtualSwitchPort",
    "VirtualControllerInterface",
    "IPv4AddressEndpoint",
    "IPv6AddressEndpoint",
    "Socket",
    "TCPOption",
    "UDPOption",
    "SocketTCP",
    "SocketUDP",
    "SocketContainer",
    "ECU",
    "InternalTopology",
    "MII",
    "RMII",
    "RGMII",
    "SGMII",
    "XFI",
    "BASET",
    "BASET1",
    "BASET1S",
    "ECUPort",
    "RouteEntry",
    "Switch",
    "SwitchPort",
    "VLANEntry",
    "MulticastGroup",
    "TCAMRule",
    "TrafficClass",
    "MulticastGroupMembership",
    "AVTPMulticastEndpoint",
    "MACMulticastEndpoint",
    "MACMulticastEndpoints",
]
