"""
This package provides models for the general configuration
in schema.
"""

from .schema_channels import schemaChannelConfig
from .schema_general import schemaGeneralConfig

__all__ = [
    "schemaChannelConfig",
    "schemaGeneralConfig",
]
