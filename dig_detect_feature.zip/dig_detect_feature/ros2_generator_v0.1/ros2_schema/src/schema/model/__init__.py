"""
This package provides the main schema model definitions and
aggregates all domain-specific model packages, including ECU,
topology, security, SOME/IP, TSN, metadata, and general configuration.
"""

from ..core.base_models.base_model import schemaBaseModel
from . import (
    schema_4_bus,
    schema_4_ecu,
    schema_4_general_configuration,
    schema_4_metadata,
    schema_4_security,
    schema_4_signal,
    schema_4_someip,
    schema_4_topology,
    schema_4_tsn,
)
from .schema_model import schemaModel

__all__ = [
    "schema_4_bus",
    "schema_4_ecu",
    "schema_4_general_configuration",
    "schema_4_metadata",
    "schema_4_security",
    "schema_4_signal",
    "schema_4_someip",
    "schema_4_topology",
    "schema_4_tsn",
    "schemaModel",
    "schemaBaseModel",
]
