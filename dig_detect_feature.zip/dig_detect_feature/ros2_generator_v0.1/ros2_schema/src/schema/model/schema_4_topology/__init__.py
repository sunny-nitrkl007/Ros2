"""
This package provides system topology models for schema
"""

from .system_topology import ExternalConnection, schemaTopology, SystemTopology

__all__ = [
    "ExternalConnection",
    "SystemTopology",
    "schemaTopology",
]
