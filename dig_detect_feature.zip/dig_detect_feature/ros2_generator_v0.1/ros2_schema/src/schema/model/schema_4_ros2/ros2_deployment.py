from typing import List, Literal, Optional
from pydantic import Field, field_validator
from schema.core.base_models import schemaBaseModel

from .ros2_config import (
    ROS2Topic,
    ROS2Service,
    ROS2QoSProfile,
    ROS2DiscoveryProfile,
    Application,
)

class ROS2CallbackConfig(schemaBaseModel):
    on_data_available: Optional[bool] = Field(default=None)
    on_subscription_matched: Optional[bool] = Field(default=None)
    on_publication_matched: Optional[bool] = Field(default=None)

class ROS2Deployment(schemaBaseModel):
    deployment_type: Literal["ros2"] = Field(default="ros2")
    application_name: str = Field()

    @field_validator("application_name")
    @classmethod
    def validate_app_exists(cls, value):
        from .ros2_config import Application
        if value not in Application.INSTANCES:
            raise ValueError(f"Deployment Error: Target application profile '{value}' does not exist.")
        return value
