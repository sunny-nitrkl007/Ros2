from typing import Annotated, List, Literal, Optional, Union, TYPE_CHECKING
from pydantic import Field, BeforeValidator, RootModel
from schema.core.base_models import schemaBaseModel

# 💡 FIXED: Prevent runtime circular imports by hiding configuration classes
if TYPE_CHECKING:
    from .ros2_config import (
        ROS2Topic,
        ROS2Service,
        ROS2QoSProfile,
        ROS2DiscoveryProfile,
        Application,
    )

class ROS2BaseType(schemaBaseModel):
    """Base class for ROS2 message/service field types."""
    name: str = Field(description="Field name")
    optional: Optional[bool] = Field(
        default=None,
        description="Optional field (kept for extensibility)"
    )

class ROS2Primitive(ROS2BaseType):
    type: Literal["bool", "int32", "int64","uint64", "uint32", "float32", "float64", "string"]

class ROS2Array(ROS2BaseType):
    type: Literal["array"] = Field("array")
    element_type: "ROS2AllTypes"
    bound: Optional[int] = Field(default=None)

class ROS2Struct(ROS2BaseType):
    type: Literal["struct"] = Field("struct")
    members: List["ROS2AllTypes"]

def parse_bracket_arrays(v):
    """Transforms native 'type[]' strings into structured ROS2Array dictionaries."""
    if isinstance(v, str) and v.endswith("[]"):
        base_type = v[:-2]
        return {
            "type": "array",
            "name": "array_field",
            "element_type": {"type": base_type, "name": "element_item"}
        }
    if isinstance(v, dict) and "type" in v and isinstance(v["type"], str):
        type_str = v["type"]
        if type_str.endswith("[]"):
            base_type = type_str[:-2]
            v["type"] = "array"
            v["element_type"] = {"type": base_type, "name": f"{v.get('name', 'elem')}_item"}
    return v

ROS2UnionTypes = Annotated[
    Union[
        ROS2Primitive,
        ROS2Array,
        ROS2Struct,
    ],
    Field(discriminator="type")
]

class ROS2AllTypes(RootModel):
    root: Annotated[ROS2UnionTypes, BeforeValidator(parse_bracket_arrays)]

# Rebuild recursive trees cleanly
ROS2Array.model_rebuild()
ROS2Struct.model_rebuild()