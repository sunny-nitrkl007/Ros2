from typing import Annotated, List, Literal, Optional
from pydantic import BeforeValidator, Field, model_validator
from schema.core.annotations.external import External, NamingStrategy, OutputStrategy
from schema.core.base_models import schemaBaseModel, NamedDictInstances

from .ros2_datatypes import ROS2AllTypes


# ---------------------------
# Topics
# ---------------------------
class ROS2Topic(NamedDictInstances):
    name: str = Field(alias="topic_name")
    topic_path: str = Field()
    structure: Optional[List[ROS2AllTypes]] = Field(default=None)

    @property
    def topic_name(self) -> str:
        return self.name


class ROS2ServiceField(schemaBaseModel):
    name: str = Field()
    type: str = Field()


class ROS2Service(NamedDictInstances):
    name: str = Field(alias="service_name")
    service_path: str = Field()
    request_structure: List[ROS2ServiceField] = Field(default_factory=list)
    response_structure: List[ROS2ServiceField] = Field(default_factory=list)

    @property
    def service_name(self) -> str:
        return self.name


# ---------------------------
# QoS Profiles
# ---------------------------
class ROS2QoSProfile(NamedDictInstances):
    reliability: Literal["RELIABLE", "BEST_EFFORT", "reliable", "best_effort"] = Field()
    durability: Literal["VOLATILE", "TRANSIENT_LOCAL", "volatile", "transient_local"] = Field()
    history_kind: Literal["KEEP_LAST", "KEEP_ALL", "keep_last", "keep_all"] = Field()
    history_depth: int = Field()
    deadline_ms: Optional[int] = Field(default=None)
    lifespan_ms: Optional[int] = Field(default=None)


# ---------------------------
# Discovery Profiles
# ---------------------------
class DiscoveryServer(schemaBaseModel):
    server_id: int = Field()
    ip: str = Field()
    port: int = Field()


class ROS2DiscoveryProfile(NamedDictInstances):
    domain_id: int = Field(ge=0)
    mode: Literal["SUPER_CLIENT", "CLIENT", "SERVER", "simple"] = Field()
    discovery_servers: List[DiscoveryServer] = Field(default_factory=list)


# ---------------------------
# Parameter Profiles
# ---------------------------
class Parameter(schemaBaseModel):
    name: str = Field()
    type: str = Field()
    min: Optional[float] = Field(default=None)
    max: Optional[float] = Field(default=None)
    default: Optional[
        Annotated[str, BeforeValidator(lambda x: str(x) if x is not None else None)]
    ] = Field(default=None)
    dynamic: Optional[bool] = Field(default=None)

    @model_validator(mode="after")
    def validate_parameter_bounds(self) -> "Parameter":
        if self.min is not None and self.max is not None:
            if self.min > self.max:
                raise ValueError(
                    f"Parameter Configuration Error: Parameter '{self.name}' has min ({self.min}) "
                    f"configured higher than max ({self.max})."
                )

        if self.default is not None:
            val = None
            try:
                if self.type in ["int32", "int64", "float32", "float64"]:
                    val = float(self.default)
            except ValueError:
                pass

            if val is not None:
                if self.min is not None and val < self.min:
                    raise ValueError(
                        f"Parameter Configuration Error: Default value '{self.default}' for "
                        f"parameter '{self.name}' is lower than min ({self.min})."
                    )
                if self.max is not None and val > self.max:
                    raise ValueError(
                        f"Parameter Configuration Error: Default value '{self.default}' for "
                        f"parameter '{self.name}' is higher than max ({self.max})."
                    )
        return self


class ROS2ParameterProfile(NamedDictInstances):
    description: Optional[str] = Field(default=None)
    parameters: List[Parameter]


# ---------------------------
# Applications
# ---------------------------
class Application(NamedDictInstances):
    discovery_ref: str = Field()
    # 💡 FIXED: Added alias to handle pluralized 'nodes' definition inside applications.yaml
    node: List[str] = Field(default_factory=list, alias="nodes")


# ---------------------------
# Segments (Core logic layer)
# ---------------------------
class Publisher(schemaBaseModel):
    name: str = Field()
    topic_name: str = Field()
    qos_profile: str = Field()


class Subscriber(schemaBaseModel):
    name: str = Field()
    topic_name: str = Field()
    qos_profile: str = Field()


class ServiceClient(schemaBaseModel):
    name: str = Field()
    service_name: str = Field()
    qos_profile: str = Field()


class ServiceServer(schemaBaseModel):
    name: str = Field()
    service_name: str = Field()
    qos_profile: str = Field()


class InteractionBlock(schemaBaseModel):
    publisher: Optional[List[Publisher]] = Field(default_factory=list)
    subscriber: Optional[List[Subscriber]] = Field(default_factory=list)
    service_client: Optional[List[ServiceClient]] = Field(default_factory=list)
    service_server: Optional[List[ServiceServer]] = Field(default_factory=list)


class Node(schemaBaseModel):
    name: str = Field()
    parameter_ref: Optional[str] = Field(default=None)
    interactions_ref: List[str] = Field(default_factory=list)


class ROS2SegmentInstance(NamedDictInstances):
    interactions: List[InteractionBlock] = Field(default_factory=list)


class ROS2SegmentFile(schemaBaseModel):
    segments: List[ROS2SegmentInstance] = Field(default_factory=list)
    node: List[Node] = Field(default_factory=list)


# ----------------------------------------------------
# 📁 FOLDER CONTAINERS
# ----------------------------------------------------
class ROS2InterfacesContainer(schemaBaseModel):
    """Maps the general/ros2/Interfaces_data subdirectory."""

    topic_data: Annotated[
        List[ROS2Topic],
        External(
            output_structure=OutputStrategy.SINGLE_FILE | OutputStrategy.FIXED_ROOT,
            root="topic_data",
            naming_strategy=NamingStrategy.FIXED_PATH,
            path="topics_data",
        ),
    ] = Field(default_factory=list)

    service_data: Annotated[
        List[ROS2Service],
        External(
            output_structure=OutputStrategy.SINGLE_FILE | OutputStrategy.FIXED_ROOT,
            root="service_data",
            naming_strategy=NamingStrategy.FIXED_PATH,
            path="services_data",
        ),
    ] = Field(default_factory=list)


class ROS2ProfilesContainer(schemaBaseModel):
    """Maps the general/ros2/profiles subdirectory."""

    qos_profiles: Annotated[
        List[ROS2QoSProfile],
        External(
            output_structure=OutputStrategy.SINGLE_FILE | OutputStrategy.FIXED_ROOT,
            root="qos_profiles",
            naming_strategy=NamingStrategy.FIXED_PATH,
            path="qos_profiles",
        ),
    ] = Field(default_factory=list)

    discovery_profiles: Annotated[
        List[ROS2DiscoveryProfile],
        External(
            output_structure=OutputStrategy.SINGLE_FILE | OutputStrategy.FIXED_ROOT,
            root="discovery_profiles",
            naming_strategy=NamingStrategy.FIXED_PATH,
            path="discovery_profiles",
        ),
    ] = Field(default_factory=list)

    parameter_profiles: Annotated[
        List[ROS2ParameterProfile],
        External(
            output_structure=OutputStrategy.SINGLE_FILE | OutputStrategy.FIXED_ROOT,
            root="parameter_profiles",
            naming_strategy=NamingStrategy.FIXED_PATH,
            path="parameter_profiles",
        ),
    ] = Field(default_factory=list)


class ROS2AppsContainer(schemaBaseModel):
    """Maps the general/ros2/apps subdirectory."""

    applications: Annotated[
        List[Application],
        External(
            output_structure=OutputStrategy.SINGLE_FILE | OutputStrategy.FIXED_ROOT,
            root="application",
            naming_strategy=NamingStrategy.FIXED_PATH,
            path="applications",
        ),
    ] = Field(default_factory=list)

    segments: Annotated[
        List[ROS2SegmentFile],
        External(
            output_structure=OutputStrategy.FOLDER,
            naming_strategy=NamingStrategy.FIELD_NAME,
        ),
    ] = Field(default_factory=list)


# ---------------------------
# ROOT CONFIG GATE
# ---------------------------
class ROS2Config(schemaBaseModel):
    version: Literal["1.0"] = Field(default="1.0")

    interfaces_data: Annotated[
        Optional[ROS2InterfacesContainer],
        External(
            output_structure=OutputStrategy.FOLDER,
            naming_strategy=NamingStrategy.FIXED_PATH,
            path="Interfaces_data",
        ),
    ] = Field(default=None)

    profiles: Annotated[
        Optional[ROS2ProfilesContainer],
        External(
            output_structure=OutputStrategy.FOLDER,
            naming_strategy=NamingStrategy.FIXED_PATH,
            path="profiles",
        ),
    ] = Field(default=None)

    apps: Annotated[
        Optional[ROS2AppsContainer],
        External(
            output_structure=OutputStrategy.FOLDER,
            naming_strategy=NamingStrategy.FIXED_PATH,
            path="apps",
        ),
    ] = Field(default=None)

    @model_validator(mode="after")
    def cross_validate_ros2_semantic_links(self) -> "ROS2Config":
        """Executes deep validation checks between components."""
        if not self.apps or not self.interfaces_data:
            return self

        # 1. Resolve global registries
        valid_topics = {t.topic_name for t in (self.interfaces_data.topic_data or [])}
        valid_services = {s.service_name for s in (self.interfaces_data.service_data or [])}
        valid_qos = {q.name for q in (self.profiles.qos_profiles or [])} if self.profiles else set()
        valid_params = {p.name for p in (self.profiles.parameter_profiles or [])} if self.profiles else set()

        # 2. Use Case 4: Verify unique paths for topics and services
        topic_paths = {}
        for topic in (self.interfaces_data.topic_data or []):
            if topic.topic_path in topic_paths:
                prev_topic = topic_paths[topic.topic_path]
                raise ValueError(
                    f"Interface Conflict: Topic '{topic.name}' uses the same path '{topic.topic_path}' "
                    f"as topic '{prev_topic}'."
                )
            topic_paths[topic.topic_path] = topic.name

        service_paths = {}
        for service in (self.interfaces_data.service_data or []):
            if service.service_path in service_paths:
                prev_service = service_paths[service.service_path]
                raise ValueError(
                    f"Interface Conflict: Service '{service.name}' uses the same path '{service.service_path}' "
                    f"as service '{prev_service}'."
                )
            service_paths[service.service_path] = service.name

        # 3. Use Case 1: Track node declarations vs implementations
        declared_nodes = set()
        for app in (self.apps.applications or []):
            declared_nodes.update(app.node)

        implemented_nodes = set()
        
        # Topic Pub/Sub compatibility tracking (Use Case 3)
        from collections import defaultdict
        topic_publishers = defaultdict(list)
        topic_subscribers = defaultdict(list)

        for segment_file in (self.apps.segments or []):
            for node_obj in (segment_file.node or []):
                implemented_nodes.add(node_obj.name)
                # Use Case 2: Validate Parameter Profile Reference
                if node_obj.parameter_ref and node_obj.parameter_ref not in valid_params:
                    raise ValueError(
                        f"Node Configuration Error: Node '{node_obj.name}' references "
                        f"undefined parameter profile '{node_obj.parameter_ref}'."
                    )

            for segment in (segment_file.segments or []):
                declared_interactions = set()
                for block in (segment.interactions or []):
                    for pub in (block.publisher or []):
                        declared_interactions.add(pub.name)
                        topic_publishers[pub.topic_name].append(pub)
                        if pub.topic_name not in valid_topics:
                            raise ValueError(f"Topic Mismatch: Topic '{pub.topic_name}' inside publisher '{pub.name}' is unregistered.")
                        if pub.qos_profile not in valid_qos:
                            raise ValueError(f"QoS Mismatch: QoS profile '{pub.qos_profile}' inside publisher '{pub.name}' is unregistered.")

                    for sub in (block.subscriber or []):
                        declared_interactions.add(sub.name)
                        topic_subscribers[sub.topic_name].append(sub)
                        if sub.topic_name not in valid_topics:
                            raise ValueError(f"Topic Mismatch: Topic '{sub.topic_name}' inside subscriber '{sub.name}' is unregistered.")
                        if sub.qos_profile not in valid_qos:
                            raise ValueError(f"QoS Mismatch: QoS profile '{sub.qos_profile}' inside subscriber '{sub.name}' is unregistered.")

                    for client in (block.service_client or []):
                        declared_interactions.add(client.name)
                        if client.service_name not in valid_services:
                            raise ValueError(f"Service Mismatch: Service '{client.service_name}' inside client '{client.name}' is unregistered.")
                        if client.qos_profile not in valid_qos:
                            raise ValueError(f"QoS Mismatch: QoS profile '{client.qos_profile}' inside client '{client.name}' is unregistered.")

                    for server in (block.service_server or []):
                        declared_interactions.add(server.name)
                        if server.service_name not in valid_services:
                            raise ValueError(f"Service Mismatch: Service '{server.service_name}' inside server '{server.name}' is unregistered.")
                        if server.qos_profile not in valid_qos:
                            raise ValueError(f"QoS Mismatch: QoS profile '{server.qos_profile}' inside server '{server.name}' is unregistered.")

            # Validate that node interaction references exist in the segment interactions
            for node_obj in segment_file.node:
                for ref in node_obj.interactions_ref:
                    if ref not in declared_interactions:
                        raise ValueError(
                            f"Node Configuration Error: Node '{node_obj.name}' references "
                            f"undefined interaction '{ref}'."
                        )

        # Use Case 1: Dangling Node Reference Mismatch
        dangling_declarations = declared_nodes - implemented_nodes
        dangling_implementations = implemented_nodes - declared_nodes
        if dangling_declarations:
            raise ValueError(f"Application Blueprint Error: Nodes declared in applications.yaml but missing from segments: {sorted(dangling_declarations)}")
        if dangling_implementations:
            raise ValueError(f"Segment Configuration Error: Nodes implemented in segments but missing from applications.yaml: {sorted(dangling_implementations)}")

        # Use Case 3: QoS Pub/Sub Compatibility checks
        qos_by_name = {q.name: q for q in (self.profiles.qos_profiles or [])} if self.profiles else {}
        for topic_name, subs in topic_subscribers.items():
            pubs = topic_publishers[topic_name]
            for sub in subs:
                sub_qos = qos_by_name.get(sub.qos_profile)
                if not sub_qos:
                    continue
                for pub in pubs:
                    pub_qos = qos_by_name.get(pub.qos_profile)
                    if not pub_qos:
                        continue
                    if sub_qos.reliability == "RELIABLE" and pub_qos.reliability == "BEST_EFFORT":
                        raise ValueError(
                            f"QoS Compatibility Error on topic '{topic_name}': Subscriber '{sub.name}' expects RELIABLE "
                            f"but Publisher '{pub.name}' only provides BEST_EFFORT."
                        )

        return self