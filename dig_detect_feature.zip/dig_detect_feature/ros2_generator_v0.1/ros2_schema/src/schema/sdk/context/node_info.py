"""
Node metadata types for the schema SDK context.

Provides :class:`NodeInfo`, which captures type and path information for nodes in the schema model dependency graph.
"""

from typing import Type

from pydantic import Field, dataclasses, field_serializer


@dataclasses.dataclass
class NodeInfo:
    """
    Metadata for a node in the schema model dependency graph.

    Attributes:
        name (str): Human-readable name of the node (typically the class name).
        python_type (Type): The Python type (usually a Pydantic model class) that this node represents.
        schema_paths (list[str]): Dot-separated paths from the root model to this node through the dependency graph.
    """

    name: str
    python_type: Type
    schema_paths: list[str] = Field(default_factory=list)

    @field_serializer("python_type")
    def serialize_type(self, value: Type) -> str:
        """
        Serialize the Python type to its string representation.

        Args:
            value (Type): The type to serialize.

        Returns:
            str: The string form of the type.
        """

        return str(value)
