"""
This package provides the core functionality for interacting \
with the schema core modules, including utilities for workspace management.
It exposes a clean, Pythonic API for developers to integrate schema \
capabilities into their applications.
"""
