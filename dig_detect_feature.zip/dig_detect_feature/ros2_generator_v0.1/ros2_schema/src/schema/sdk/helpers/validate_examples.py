"""
Example validation script for the schema SDK.

Iterates over every subdirectory in the ``examples/`` folder at the project root and validates each one as a schema workspace by invoking
:mod:`schema.sdk.helpers.validate_workspace` as a subprocess.
"""

import subprocess
from pathlib import Path
from sys import executable

PROJECT_BASE = Path(__file__).resolve().parents[4]
VALIDATE_WORKSPACE_SCRIPT = Path.joinpath(Path(__file__).resolve().parent, Path("validate_workspace.py"))
EXAMPLES_DIR = PROJECT_BASE.parent / "examples"
WORKSPACE_EXAMPLE = EXAMPLES_DIR / "schema_example"
ECU_VARIANTS = EXAMPLES_DIR / "ecu_variants"
ROS2_GRAMMAR = EXAMPLES_DIR / "01_demo_simple_pubsub"
ROS2_GRAMMAR1 = EXAMPLES_DIR / "02_demo_mesh_app"
ROS2_demo = EXAMPLES_DIR /"03_demo_advanced_automotive_app"


print("----- Validate 03_demo_advanced_automotive_app Example -----")
subprocess.run(
    [
        executable,
        VALIDATE_WORKSPACE_SCRIPT,
        ROS2_demo,
        "--name",
        ROS2_demo.name
    ]
)

print("----- Validate 01_demo_simple_pubsub Example -----")
subprocess.run(
    [
        executable,
        VALIDATE_WORKSPACE_SCRIPT,
        ROS2_GRAMMAR,
        "--name",
        ROS2_GRAMMAR.name
    ]
)

print("----- Validate 02_demo_mesh_app Example -----")
subprocess.run(
    [
        executable,
        VALIDATE_WORKSPACE_SCRIPT,
        ROS2_GRAMMAR1,
        "--name",
        ROS2_GRAMMAR1.name
    ]
)

