"""
Workspace package for schema SDK.

Provides classes and functions to manage workspace operations.
"""
