"""
Utils package for the schema SDK.

Provides shared type definitions, field introspection utilities, and model
dependency graph construction used throughout the SDK.
"""
