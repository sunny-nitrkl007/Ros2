"""
This package provides additional functionality for the schema model,
including:

- pydantic base models,
- annotation classes for loading a schema model based on field annotations,
- common validators and utilities that are used across the model.
"""
