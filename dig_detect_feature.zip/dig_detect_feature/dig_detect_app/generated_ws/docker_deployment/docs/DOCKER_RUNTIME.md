# Docker ECU Runtime Guide

## Visual ECU Demo

```bash
cd generated_ws/docker_deployment
./scripts/docker_launch_ecu_terminals.sh
```

If automatic terminal launch fails:

```bash
./scripts/docker_print_ecu_commands.sh
```

Paste each printed command into a separate Ubuntu/Linux terminal.

## Validate Running ECU Containers

```bash
./scripts/docker_validate_running_ecus.sh
```

## Stop All

```bash
./scripts/docker_down.sh
```