#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source ./scripts/docker_cmd_lib.sh

if [[ "$DOCKER_CMD" == "sudo docker" ]]; then
  echo "[INFO] Caching sudo credentials once before opening terminals..."
  sudo -v
fi

echo "[INFO] Stopping/removing old ECU demo containers..."
$DOCKER_CMD compose down --remove-orphans || true

IMAGE_NAME="dig_detect_grammar_generated_ws:latest"
if [[ "${FORCE_DOCKER_BUILD:-0}" == "1" ]]; then
  echo "[INFO] FORCE_DOCKER_BUILD=1, building Docker image..."
  $DOCKER_CMD compose build
elif $DOCKER_CMD image inspect "$IMAGE_NAME" >/dev/null 2>&1; then
  echo "[INFO] Docker image already exists locally: $IMAGE_NAME"
  echo "[INFO] Skipping build to avoid Docker Hub/network dependency. Use FORCE_DOCKER_BUILD=1 to rebuild."
else
  echo "[INFO] Docker image not found locally, building Docker image..."
  $DOCKER_CMD compose build
fi

echo "[OK] Docker ECU demo prepared."