#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source ./scripts/docker_cmd_lib.sh
./scripts/docker_prepare_ecu_demo.sh
open_terminal() {
  local title="$1"
  local cmd="$2"
  if command -v wt.exe >/dev/null 2>&1 && command -v wslpath >/dev/null 2>&1; then
    local win_pwd
    win_pwd="$(wslpath -w "$PWD" 2>/dev/null || true)"
    if [[ -n "$win_pwd" ]]; then
      wt.exe new-tab --title "$title" wsl.exe --cd "$win_pwd" bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
      wt.exe new-window --title "$title" wsl.exe --cd "$win_pwd" bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
    fi
  fi
  if command -v gnome-terminal >/dev/null 2>&1; then
    gnome-terminal --title="$title" -- bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
  fi
  if command -v xterm >/dev/null 2>&1; then
    xterm -T "$title" -e bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
  fi
  return 1
}
FAILED=0
echo "[INFO] Opening discovery_server terminal..."
open_terminal "T1 DDS Discovery Server" "cd '$PWD' && $DOCKER_CMD compose up --no-deps discovery_server" || FAILED=1
sleep 6
echo "[INFO] Opening ECU terminal for sensor_simulator_app..."
open_terminal "ECU sensor_simulator_app" "cd '$PWD' && $DOCKER_CMD compose up --no-deps sensor_simulator_app" || FAILED=1
sleep 2
echo "[INFO] Opening ECU terminal for weighing_app..."
open_terminal "ECU weighing_app" "cd '$PWD' && $DOCKER_CMD compose up --no-deps weighing_app" || FAILED=1
sleep 2
echo "[INFO] Opening ECU terminal for dig_detect_app..."
open_terminal "ECU dig_detect_app" "cd '$PWD' && $DOCKER_CMD compose up --no-deps dig_detect_app" || FAILED=1
sleep 2
echo "[INFO] Opening ECU terminal for job_manager_app..."
open_terminal "ECU job_manager_app" "cd '$PWD' && $DOCKER_CMD compose up --no-deps job_manager_app" || FAILED=1
sleep 2
echo "[INFO] Opening ECU terminal for diagnostics_app..."
open_terminal "ECU diagnostics_app" "cd '$PWD' && $DOCKER_CMD compose up --no-deps diagnostics_app" || FAILED=1
sleep 2
if [[ "$FAILED" == "1" ]]; then
  echo "[WARN] Auto launch failed. Manual commands:"
  ./scripts/docker_print_ecu_commands.sh
else
  echo "[OK] ECU terminal demo launched."
fi