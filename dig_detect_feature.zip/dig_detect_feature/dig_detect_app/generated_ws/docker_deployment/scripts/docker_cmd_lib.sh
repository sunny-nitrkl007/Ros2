select_docker_cmd() {
  if docker ps >/dev/null 2>&1; then echo docker; return 0; fi
  if command -v sudo >/dev/null 2>&1 && sudo docker ps >/dev/null 2>&1; then echo "sudo docker"; return 0; fi
  echo docker
}
DOCKER_CMD="${DOCKER_CMD:-$(select_docker_cmd)}"
echo "[INFO] Using Docker command: $DOCKER_CMD"