#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source ./scripts/docker_cmd_lib.sh
SERVICE="${1:-inspector}"
$DOCKER_CMD compose up -d "$SERVICE"
$DOCKER_CMD compose exec "$SERVICE" bash -lc "source /opt/ros/${ROS_DISTRO:-jazzy}/setup.bash && source /generated_ws/install/setup.bash && cd /generated_ws && exec bash"