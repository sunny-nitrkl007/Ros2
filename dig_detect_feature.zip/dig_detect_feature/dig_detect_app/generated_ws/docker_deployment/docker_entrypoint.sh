#!/usr/bin/env bash
set -e
source /opt/ros/${ROS_DISTRO}/setup.bash
if [[ -f /generated_ws/install/setup.bash ]]; then source /generated_ws/install/setup.bash; fi
exec "$@"