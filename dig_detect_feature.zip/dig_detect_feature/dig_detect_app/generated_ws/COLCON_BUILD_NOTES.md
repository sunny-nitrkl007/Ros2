# Colcon Build Notes

## Recommended Build

```bash
cd generated_ws
./build.sh
```

## Manual Build

```bash
cd generated_ws
colcon build --event-handlers console_direct+
```

## Source After Build

```bash
source install/setup.bash
```

## Launch

```bash
ros2 launch generated_bringup system_launch.py
```

## Structural Test Without ROS2 Runtime

```bash
python3 test/test_generated_files.py
```

## Notes

- `generated_interfaces` contains custom `.msg` and `.srv` files.
- Application packages contain generated C++ node infrastructure.
- `generated_bringup` contains launch and discovery-server configuration.
- Developers should edit only marked business-logic sections.