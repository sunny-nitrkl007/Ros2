#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")/../.."

unset AMENT_PREFIX_PATH || true
unset CMAKE_PREFIX_PATH || true
unset COLCON_PREFIX_PATH || true
export COLCON_TRACE="${COLCON_TRACE:-}"
export AMENT_TRACE_SETUP_FILES="${AMENT_TRACE_SETUP_FILES:-}"

source /opt/ros/${ROS_DISTRO:-humble}/setup.bash
colcon build --executor sequential --parallel-workers 2 --event-handlers console_direct+