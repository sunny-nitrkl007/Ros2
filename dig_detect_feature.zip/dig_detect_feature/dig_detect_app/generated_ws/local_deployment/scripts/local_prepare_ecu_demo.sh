#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")/../.."

echo "[INFO] Stopping old local ECU demo processes..."
./local_deployment/scripts/local_down.sh || true

echo "[INFO] Building local workspace..."
./local_deployment/scripts/local_build.sh

export COLCON_TRACE="${COLCON_TRACE:-}"
export AMENT_TRACE_SETUP_FILES="${AMENT_TRACE_SETUP_FILES:-}"
source install/setup.bash
export FASTDDS_DEFAULT_PROFILES_FILE="$PWD/config/dds/fastdds_discovery.xml"
echo "[OK] Local ECU demo prepared."