#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")/../.."
export COLCON_TRACE="${COLCON_TRACE:-}"
export AMENT_TRACE_SETUP_FILES="${AMENT_TRACE_SETUP_FILES:-}"
source install/setup.bash
export ROS_DOMAIN_ID=42
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
export ROS_DISCOVERY_SERVER=127.0.0.1:11811
export ROS_SUPER_CLIENT=true
export FASTDDS_DEFAULT_PROFILES_FILE="$PWD/config/dds/fastdds_discovery.xml"
ros2 daemon stop >/dev/null 2>&1 || true
sleep 2
ros2 daemon start >/dev/null 2>&1 || true
sleep 8
echo "[INFO] Nodes:"
ros2 node list
echo "[INFO] Topics:"
ros2 topic list
echo "[INFO] Services:"
ros2 service list
echo "[INFO] Echoing /lps/diagnostics/sensor_health"
ros2 topic echo "/lps/diagnostics/sensor_health" --once
echo "[INFO] Echoing /lps/dig_detect/status"
ros2 topic echo "/lps/dig_detect/status" --once
echo "[INFO] Echoing /lps/job_mgr/status"
ros2 topic echo "/lps/job_mgr/status" --once
echo "[INFO] Echoing /lps/sensors/hydraulic_data"
ros2 topic echo "/lps/sensors/hydraulic_data" --once
echo "[INFO] Echoing /lps/weigh/status"
ros2 topic echo "/lps/weigh/status" --once
echo "[OK] Local ECU graph validation completed."