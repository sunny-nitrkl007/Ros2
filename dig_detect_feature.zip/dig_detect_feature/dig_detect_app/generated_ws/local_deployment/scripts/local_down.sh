#!/usr/bin/env bash
set -eo pipefail

kill_own_matching() {
  local pattern="$1"
  pgrep -u "$USER" -f "$pattern" 2>/dev/null | while read -r pid; do
    if [[ -n "$pid" && "$pid" != "$$" ]]; then
      kill "$pid" 2>/dev/null || true
    fi
  done
}

kill_own_matching "fast-discovery-server"
kill_own_matching "ros2 run sensor_simulator_app sensor_simulator_app_combined"
kill_own_matching "sensor_simulator_app_combined"
kill_own_matching "ros2 run weighing_app weighing_app_combined"
kill_own_matching "weighing_app_combined"
kill_own_matching "ros2 run dig_detect_app dig_detect_app_combined"
kill_own_matching "dig_detect_app_combined"
kill_own_matching "ros2 run job_manager_app job_manager_app_combined"
kill_own_matching "job_manager_app_combined"
kill_own_matching "ros2 run diagnostics_app diagnostics_app_combined"
kill_own_matching "diagnostics_app_combined"
ros2 daemon stop >/dev/null 2>&1 || true
sleep 1
echo "[OK] Local demo processes stopped where owned by user."