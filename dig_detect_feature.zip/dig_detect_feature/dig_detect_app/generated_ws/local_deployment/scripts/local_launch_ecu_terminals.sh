#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")/../.."

./local_deployment/scripts/local_prepare_ecu_demo.sh

open_terminal() {
  local title="$1"
  local cmd="$2"

  if command -v wt.exe >/dev/null 2>&1 && command -v wslpath >/dev/null 2>&1; then
    local win_pwd
    win_pwd="$(wslpath -w "$PWD" 2>/dev/null || true)"
    if [[ -n "$win_pwd" ]]; then
      wt.exe new-tab --title "$title" wsl.exe --cd "$win_pwd" bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
      wt.exe new-window --title "$title" wsl.exe --cd "$win_pwd" bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
    fi
  fi

  if command -v gnome-terminal >/dev/null 2>&1; then
    gnome-terminal --title="$title" -- bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
  fi

  if command -v xterm >/dev/null 2>&1; then
    xterm -T "$title" -e bash -lc "$cmd; exec bash" >/dev/null 2>&1 && return 0
  fi

  return 1
}

FAILED=0

echo "[INFO] Opening local discovery terminal..."
open_terminal "T1 Local DDS Discovery" "cd '$PWD' && export COLCON_TRACE=\${COLCON_TRACE:-} && export AMENT_TRACE_SETUP_FILES=\${AMENT_TRACE_SETUP_FILES:-} && source install/setup.bash && export ROS_DOMAIN_ID=42 && export RMW_IMPLEMENTATION=rmw_fastrtps_cpp && export FASTDDS_DEFAULT_PROFILES_FILE=\$PWD/config/dds/fastdds_discovery.xml && fast-discovery-server -i 0 -l 127.0.0.1 -p 11811" || FAILED=1
echo "[INFO] Waiting for local discovery server startup..."
sleep 6

echo "[INFO] Opening local ECU terminal for sensor_simulator_app..."
open_terminal "Local ECU sensor_simulator_app" "cd '$PWD' && export COLCON_TRACE=\${COLCON_TRACE:-} && export AMENT_TRACE_SETUP_FILES=\${AMENT_TRACE_SETUP_FILES:-} && source install/setup.bash && export ROS_DOMAIN_ID=42 && export RMW_IMPLEMENTATION=rmw_fastrtps_cpp && export ROS_DISCOVERY_SERVER=127.0.0.1:11811 && export FASTDDS_DEFAULT_PROFILES_FILE=\$PWD/config/dds/fastdds_discovery.xml && ros2 run sensor_simulator_app sensor_simulator_app_combined" || FAILED=1
sleep 2
echo "[INFO] Opening local ECU terminal for weighing_app..."
open_terminal "Local ECU weighing_app" "cd '$PWD' && export COLCON_TRACE=\${COLCON_TRACE:-} && export AMENT_TRACE_SETUP_FILES=\${AMENT_TRACE_SETUP_FILES:-} && source install/setup.bash && export ROS_DOMAIN_ID=42 && export RMW_IMPLEMENTATION=rmw_fastrtps_cpp && export ROS_DISCOVERY_SERVER=127.0.0.1:11811 && export FASTDDS_DEFAULT_PROFILES_FILE=\$PWD/config/dds/fastdds_discovery.xml && ros2 run weighing_app weighing_app_combined" || FAILED=1
sleep 2
echo "[INFO] Opening local ECU terminal for dig_detect_app..."
open_terminal "Local ECU dig_detect_app" "cd '$PWD' && export COLCON_TRACE=\${COLCON_TRACE:-} && export AMENT_TRACE_SETUP_FILES=\${AMENT_TRACE_SETUP_FILES:-} && source install/setup.bash && export ROS_DOMAIN_ID=42 && export RMW_IMPLEMENTATION=rmw_fastrtps_cpp && export ROS_DISCOVERY_SERVER=127.0.0.1:11811 && export FASTDDS_DEFAULT_PROFILES_FILE=\$PWD/config/dds/fastdds_discovery.xml && ros2 run dig_detect_app dig_detect_app_combined" || FAILED=1
sleep 2
echo "[INFO] Opening local ECU terminal for job_manager_app..."
open_terminal "Local ECU job_manager_app" "cd '$PWD' && export COLCON_TRACE=\${COLCON_TRACE:-} && export AMENT_TRACE_SETUP_FILES=\${AMENT_TRACE_SETUP_FILES:-} && source install/setup.bash && export ROS_DOMAIN_ID=42 && export RMW_IMPLEMENTATION=rmw_fastrtps_cpp && export ROS_DISCOVERY_SERVER=127.0.0.1:11811 && export FASTDDS_DEFAULT_PROFILES_FILE=\$PWD/config/dds/fastdds_discovery.xml && ros2 run job_manager_app job_manager_app_combined" || FAILED=1
sleep 2
echo "[INFO] Opening local ECU terminal for diagnostics_app..."
open_terminal "Local ECU diagnostics_app" "cd '$PWD' && export COLCON_TRACE=\${COLCON_TRACE:-} && export AMENT_TRACE_SETUP_FILES=\${AMENT_TRACE_SETUP_FILES:-} && source install/setup.bash && export ROS_DOMAIN_ID=42 && export RMW_IMPLEMENTATION=rmw_fastrtps_cpp && export ROS_DISCOVERY_SERVER=127.0.0.1:11811 && export FASTDDS_DEFAULT_PROFILES_FILE=\$PWD/config/dds/fastdds_discovery.xml && ros2 run diagnostics_app diagnostics_app_combined" || FAILED=1
sleep 2

if [[ "$FAILED" == "1" ]]; then
  echo "[WARN] Auto launch failed for at least one terminal. Manual commands:"
  ./local_deployment/scripts/local_print_ecu_commands.sh
else
  echo "[OK] Local ECU terminal demo launched."
fi