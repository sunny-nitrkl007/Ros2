# Local Deployment Runtime Guide

## Visual Local ECU Demo

```bash
cd generated_ws
./local_deployment/scripts/local_launch_ecu_terminals.sh
```

Expected layout:

- T1: local FastDDS discovery server
- Local ECU terminal: `sensor_simulator_app` running `ros2 run sensor_simulator_app sensor_simulator_app_combined`
- Local ECU terminal: `weighing_app` running `ros2 run weighing_app weighing_app_combined`
- Local ECU terminal: `dig_detect_app` running `ros2 run dig_detect_app dig_detect_app_combined`
- Local ECU terminal: `job_manager_app` running `ros2 run job_manager_app job_manager_app_combined`
- Local ECU terminal: `diagnostics_app` running `ros2 run diagnostics_app diagnostics_app_combined`

If automatic terminal launch fails:

```bash
./local_deployment/scripts/local_print_ecu_commands.sh
```

## Validate

```bash
./local_deployment/scripts/local_validate_running_ecus.sh
```

## Stop

```bash
./local_deployment/scripts/local_down.sh
```