# Runtime Testing Guide

## Core DDS XML

```bash
config/dds/fastdds_discovery.xml
```

Use it with:

```bash
export FASTDDS_DEFAULT_PROFILES_FILE=$PWD/config/dds/fastdds_discovery.xml
```

## Discovery Server Same-Machine Test

Terminal 1:

```bash
source install/setup.bash
export FASTDDS_DEFAULT_PROFILES_FILE=$PWD/config/dds/fastdds_discovery.xml
fast-discovery-server -i 0 -l 127.0.0.1 -p 11811
```

Application terminals:

```bash
source install/setup.bash
export ROS_DOMAIN_ID=42
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
export ROS_DISCOVERY_SERVER=127.0.0.1:11811
export FASTDDS_DEFAULT_PROFILES_FILE=$PWD/config/dds/fastdds_discovery.xml
ros2 run <package> <package>_combined
```

## Expected Nodes
- `/diagnostics_node`
- `/dig_detect_node`
- `/job_manager_node`
- `/sensor_simulator_node`
- `/weighing_node`

## Expected Topics
- `/lps/diagnostics/sensor_health`
- `/lps/dig_detect/status`
- `/lps/job_mgr/status`
- `/lps/sensors/hydraulic_data`
- `/lps/weigh/status`

## Expected Services
- `/lps/diagnostics/get_sensor_health`
- `/lps/dig_detect/reset`
