#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"

# Avoid nounset failures inside ROS/colcon setup scripts.
export COLCON_TRACE="${COLCON_TRACE:-}"

if [[ ! -f install/setup.bash ]]; then
  echo "[ERROR] install/setup.bash not found. Run ./test_build.sh first."
  exit 1
fi
source install/setup.bash

if [[ -f config/dds/fastdds_discovery.xml ]]; then
  export FASTDDS_DEFAULT_PROFILES_FILE="$PWD/config/dds/fastdds_discovery.xml"
  echo "[INFO] FASTDDS_DEFAULT_PROFILES_FILE=$FASTDDS_DEFAULT_PROFILES_FILE"
fi

LOG_FILE="runtime_smoke_test.log"
rm -f "$LOG_FILE" runtime_nodes.txt runtime_topics.txt runtime_services.txt runtime_params.txt

ros2 launch generated_bringup system_launch.py > "$LOG_FILE" 2>&1 &
LAUNCH_PID=$!
cleanup() {
  if kill -0 "$LAUNCH_PID" >/dev/null 2>&1; then
    kill -INT "$LAUNCH_PID" >/dev/null 2>&1 || true
    wait "$LAUNCH_PID" >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT

sleep 8
ros2 daemon stop >/dev/null 2>&1 || true
sleep 1
ros2 daemon start >/dev/null 2>&1 || true
sleep 3

echo "[INFO] Nodes:"
ros2 node list | tee runtime_nodes.txt

echo "[INFO] Topics:"
ros2 topic list | tee runtime_topics.txt

echo "[INFO] Services:"
ros2 service list | tee runtime_services.txt

grep -q "/diagnostics_node" runtime_nodes.txt || { echo "[ERROR] Missing node /diagnostics_node"; cat "$LOG_FILE"; exit 1; }
grep -q "/dig_detect_node" runtime_nodes.txt || { echo "[ERROR] Missing node /dig_detect_node"; cat "$LOG_FILE"; exit 1; }
grep -q "/job_manager_node" runtime_nodes.txt || { echo "[ERROR] Missing node /job_manager_node"; cat "$LOG_FILE"; exit 1; }
grep -q "/sensor_simulator_node" runtime_nodes.txt || { echo "[ERROR] Missing node /sensor_simulator_node"; cat "$LOG_FILE"; exit 1; }
grep -q "/weighing_node" runtime_nodes.txt || { echo "[ERROR] Missing node /weighing_node"; cat "$LOG_FILE"; exit 1; }

grep -q "/lps/diagnostics/sensor_health" runtime_topics.txt || { echo "[ERROR] Missing topic /lps/diagnostics/sensor_health"; cat "$LOG_FILE"; exit 1; }
ros2 topic echo "/lps/diagnostics/sensor_health" --once >/tmp/topic_echo_1.txt || { echo "[ERROR] Topic echo failed for /lps/diagnostics/sensor_health"; cat "$LOG_FILE"; exit 1; }
grep -q "/lps/dig_detect/status" runtime_topics.txt || { echo "[ERROR] Missing topic /lps/dig_detect/status"; cat "$LOG_FILE"; exit 1; }
ros2 topic echo "/lps/dig_detect/status" --once >/tmp/topic_echo_2.txt || { echo "[ERROR] Topic echo failed for /lps/dig_detect/status"; cat "$LOG_FILE"; exit 1; }
grep -q "/lps/job_mgr/status" runtime_topics.txt || { echo "[ERROR] Missing topic /lps/job_mgr/status"; cat "$LOG_FILE"; exit 1; }
ros2 topic echo "/lps/job_mgr/status" --once >/tmp/topic_echo_3.txt || { echo "[ERROR] Topic echo failed for /lps/job_mgr/status"; cat "$LOG_FILE"; exit 1; }
grep -q "/lps/sensors/hydraulic_data" runtime_topics.txt || { echo "[ERROR] Missing topic /lps/sensors/hydraulic_data"; cat "$LOG_FILE"; exit 1; }
ros2 topic echo "/lps/sensors/hydraulic_data" --once >/tmp/topic_echo_4.txt || { echo "[ERROR] Topic echo failed for /lps/sensors/hydraulic_data"; cat "$LOG_FILE"; exit 1; }
grep -q "/lps/weigh/status" runtime_topics.txt || { echo "[ERROR] Missing topic /lps/weigh/status"; cat "$LOG_FILE"; exit 1; }
ros2 topic echo "/lps/weigh/status" --once >/tmp/topic_echo_5.txt || { echo "[ERROR] Topic echo failed for /lps/weigh/status"; cat "$LOG_FILE"; exit 1; }

grep -q "/lps/diagnostics/get_sensor_health" runtime_services.txt || { echo "[ERROR] Missing service /lps/diagnostics/get_sensor_health"; cat "$LOG_FILE"; exit 1; }
grep -q "/lps/dig_detect/reset" runtime_services.txt || { echo "[ERROR] Missing service /lps/dig_detect/reset"; cat "$LOG_FILE"; exit 1; }

FIRST_NODE="/diagnostics_node"

if [[ "$FIRST_NODE" != "/" ]]; then
  echo "[INFO] Parameters for $FIRST_NODE:"
  ros2 param list "$FIRST_NODE" | tee runtime_params.txt
  if ! grep -q "publish_rate_hz" runtime_params.txt; then
    echo "[WARN] publish_rate_hz not listed on $FIRST_NODE. This may be okay if grammar profile provides different parameter names."
  fi
fi

echo "[OK] Runtime smoke test passed."