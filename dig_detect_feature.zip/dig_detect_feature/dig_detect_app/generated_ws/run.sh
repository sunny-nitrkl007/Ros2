#!/usr/bin/env bash
set -euo pipefail

# ============================================================================
# Generated workspace run helper
# Uses local launch by default. For distributed testing use system_discovery_launch.py.
# ============================================================================
cd "$(dirname "$0")"
if [[ ! -f install/setup.bash ]]; then
  echo "[ERROR] install/setup.bash not found. Run ./build.sh first."
  exit 1
fi
source install/setup.bash
ros2 launch generated_bringup system_launch.py