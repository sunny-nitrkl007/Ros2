#include "weighing_app/weighing_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace weighing_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

WeighingNode::WeighingNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("weighing_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: weighing_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&WeighingNode::publish_generated_messages, this));
}

void WeighingNode::declare_generated_parameters()
{
  this->declare_parameter<double>("exec_rate_sec", 0.02);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: exec_rate_sec");
  this->declare_parameter<int64_t>("num_lift_cylinders", 2);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: num_lift_cylinders");
  this->declare_parameter<double>("lift_cyl_bore_dia_mm", 140.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: lift_cyl_bore_dia_mm");
  this->declare_parameter<double>("lift_cyl_rod_dia_mm", 80.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: lift_cyl_rod_dia_mm");
  this->declare_parameter<int64_t>("hyd_oil_type", 0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: hyd_oil_type");
  this->declare_parameter<double>("start_of_weigh_pct", 15.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: start_of_weigh_pct");
  this->declare_parameter<double>("end_of_weigh_pct", 85.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: end_of_weigh_pct");
  this->declare_parameter<double>("butterworth_wt_cf", 8.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: butterworth_wt_cf");
  this->declare_parameter<double>("butterworth_stage_one_cf", 10.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: butterworth_stage_one_cf");
  this->declare_parameter<double>("butterworth_stage_two_cf", 11.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: butterworth_stage_two_cf");
  this->declare_parameter<double>("butterworth_stage_three_cf", 12.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: butterworth_stage_three_cf");
  this->declare_parameter<double>("butterworth_damping_rate", 1.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: butterworth_damping_rate");
  this->declare_parameter<double>("he_line_loss_2nd_order_coeff", 0.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: he_line_loss_2nd_order_coeff");
  this->declare_parameter<double>("he_line_loss_1st_order_coeff", 0.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: he_line_loss_1st_order_coeff");
  this->declare_parameter<double>("re_line_loss_2nd_order_coeff", 0.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: re_line_loss_2nd_order_coeff");
  this->declare_parameter<double>("re_line_loss_1st_order_coeff", 0.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: re_line_loss_1st_order_coeff");
}

void WeighingNode::setup_publishers()
{
  auto qos_pub_weigh_status = make_qos(10, "RELIABLE", "VOLATILE");
  pub_weigh_status_publisher_ = this->create_publisher<generated_interfaces::msg::WeighStatus>("/lps/weigh/status", qos_pub_weigh_status);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: pub_weigh_status -> /lps/weigh/status");
}

void WeighingNode::setup_subscribers()
{
  auto qos_sub_hydraulic_sensor_data = make_qos(5, "BEST_EFFORT", "VOLATILE");
  sub_hydraulic_sensor_data_subscriber_ = this->create_subscription<generated_interfaces::msg::HydraulicSensorData>("/lps/sensors/hydraulic_data", qos_sub_hydraulic_sensor_data, std::bind(&WeighingNode::on_sub_hydraulic_sensor_data, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: sub_hydraulic_sensor_data <- /lps/sensors/hydraulic_data");
}

void WeighingNode::setup_service_servers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE SERVERS: weighing_node");
}

void WeighingNode::setup_service_clients()
{
  client_get_sensor_health_client_ = this->create_client<generated_interfaces::srv::GetSensorHealth>("/lps/diagnostics/get_sensor_health");
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT CREATED: client_get_sensor_health -> /lps/diagnostics/get_sensor_health");
}

void WeighingNode::publish_generated_messages()
{
  auto msg_pub_weigh_status = generated_interfaces::msg::WeighStatus();

  // ============================================================================
  // USER BUSINESS LOGIC START: Simplified DiffPres → InstWeight → Filter
  // Ported from LpsCalcDiffPres() + LpsCalcInstantWt() in LpsProcess.c
  // ============================================================================
  if (!sensor_received_) return;  // wait for first sensor msg

  auto & s = latest_sensor_;
  double bore_dia = this->get_parameter("lift_cyl_bore_dia_mm").as_double();
  double rod_dia = this->get_parameter("lift_cyl_rod_dia_mm").as_double();
  double start_of_weigh = this->get_parameter("start_of_weigh_pct").as_double();

  // DiffPres calculation (from LpsProcess.c LpsCalcDiffPres)
  double bore_area = 3.14159 * (bore_dia / 2.0) * (bore_dia / 2.0);
  double rod_area = 3.14159 * (rod_dia / 2.0) * (rod_dia / 2.0);
  double area_ratio = (bore_area - rod_area) / bore_area;
  double diff_pres = s.lift_cyl_he_pressure_kpa - (s.lift_cyl_re_pressure_kpa * area_ratio);

  // Simplified InstWeight (linear approx: ~2000 kPa per tonne, baseline ~5000 kPa)
  float raw_weight = static_cast<float>((diff_pres - 3500.0) / 1500.0);
  if (raw_weight < 0.0f) raw_weight = 0.0f;

  // Low-pass filter (simplified Butterworth)
  filtered_weight_ = filter_alpha_ * raw_weight + (1.0f - filter_alpha_) * filtered_weight_;

  // Weight derivative (rate of change)
  weight_derivative_ = filtered_weight_ - prev_weight_;
  prev_weight_ = filtered_weight_;

  // Dump state detection (from LpsWeighDumpState.c)
  uint8_t dump_state = 0;  // UNKNOWN
  if (s.bucket_angle_deg > 35.0f && (s.tilt_cyl_extension_pct > 85.0f)) {
    dump_state = 1;  // FULLY_RACKED
  } else if (s.bucket_angle_deg <= -35.0f) {
    dump_state = 4;  // FULLY_DUMPED
  } else if (s.bucket_angle_deg <= 40.0f && s.tilt_cyl_extension_pct <= 85.0f) {
    dump_state = 3;  // PARTIALLY_DUMPED
  } else {
    dump_state = 2;  // NOT_RACKED_NOT_DUMPED
  }

  bool is_forward = (s.requested_gear == 1);
  bool full_rack = (dump_state == 1);
  bool full_dump = (dump_state == 4);

  msg_pub_weigh_status.inst_weight_filtered = filtered_weight_;
  msg_pub_weigh_status.inst_weight_derivative = weight_derivative_;
  msg_pub_weigh_status.inst_weight_raw = raw_weight;
  msg_pub_weigh_status.inst_weight_raw_status = 0;  // OK
  msg_pub_weigh_status.lift_cyl_pres_compensated_kpa = static_cast<float>(diff_pres);
  msg_pub_weigh_status.best_bucket_weight = filtered_weight_;
  msg_pub_weigh_status.payload_calc_method = 0x1201;  // Butterworth + HIGH + HPS_HE_RE
  msg_pub_weigh_status.weigh_dec_flag = false;
  msg_pub_weigh_status.latch_conditions_ok = (s.lift_cyl_extension_pct >= start_of_weigh) && full_rack;
  msg_pub_weigh_status.weigh_range_indicator = (s.lift_cyl_extension_pct < start_of_weigh) ? 0x0323 : 0x0325;
  msg_pub_weigh_status.dump_state = dump_state;
  msg_pub_weigh_status.cal_state_calibrated = true;
  msg_pub_weigh_status.use_filter_data_flag = true;
  msg_pub_weigh_status.is_requested_gear_forward = is_forward;
  msg_pub_weigh_status.lift_cyl_extension_pct = s.lift_cyl_extension_pct;
  msg_pub_weigh_status.start_of_weigh_pct = static_cast<float>(start_of_weigh);
  msg_pub_weigh_status.full_rack_detected = full_rack;
  msg_pub_weigh_status.full_dump_detected = full_dump;

  RCLCPP_INFO(this->get_logger(), "[WEIGH] wt=%.2f filt=%.2f deriv=%.3f dump=%d gear=%s ext=%.1f%%",
    raw_weight, filtered_weight_, weight_derivative_, dump_state, is_forward ? "FWD" : "OTHER", s.lift_cyl_extension_pct);
  // ============================================================================
  // USER BUSINESS LOGIC END: Simplified DiffPres → InstWeight → Filter
  // ============================================================================

  pub_weigh_status_publisher_->publish(msg_pub_weigh_status);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /lps/weigh/status");
}

void WeighingNode::on_sub_hydraulic_sensor_data(generated_interfaces::msg::HydraulicSensorData::SharedPtr msg)
{
  latest_sensor_ = *msg;
  sensor_received_ = true;
}


void WeighingNode::send_client_get_sensor_health_request()
{
  auto request = std::make_shared<generated_interfaces::srv::GetSensorHealth::Request>();
  if (client_get_sensor_health_client_->service_is_ready()) {
    RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT SEND: /lps/diagnostics/get_sensor_health");
    client_get_sensor_health_client_->async_send_request(request);
  }
}

}  // namespace weighing_app