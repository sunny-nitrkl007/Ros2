#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/hydraulic_sensor_data.hpp"
#include "generated_interfaces/msg/weigh_status.hpp"
#include "generated_interfaces/srv/get_sensor_health.hpp"

namespace weighing_app
{

/**
 * @brief Generated ROS2 node class for `weighing_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class WeighingNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit WeighingNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();

  /**
   * @brief Generated subscriber callback for `sub_hydraulic_sensor_data`.
   */
  void on_sub_hydraulic_sensor_data(generated_interfaces::msg::HydraulicSensorData::SharedPtr msg);


  /**
   * @brief Generated helper that prepares an async request for `client_get_sensor_health`.
   */
  void send_client_get_sensor_health_request();

  rclcpp::Publisher<generated_interfaces::msg::WeighStatus>::SharedPtr pub_weigh_status_publisher_;
  rclcpp::Subscription<generated_interfaces::msg::HydraulicSensorData>::SharedPtr sub_hydraulic_sensor_data_subscriber_;
  rclcpp::Client<generated_interfaces::srv::GetSensorHealth>::SharedPtr client_get_sensor_health_client_;
  rclcpp::TimerBase::SharedPtr publish_timer_;

  // ── Business logic state ──
  generated_interfaces::msg::HydraulicSensorData latest_sensor_{};
  bool sensor_received_ = false;
  float prev_weight_ = 0.0f;
  float filtered_weight_ = 0.0f;
  float weight_derivative_ = 0.0f;
  float filter_alpha_ = 0.3f;  // simple low-pass filter coefficient
};

}  // namespace weighing_app