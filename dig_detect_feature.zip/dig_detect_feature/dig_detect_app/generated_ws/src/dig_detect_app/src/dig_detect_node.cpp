#include "dig_detect_app/dig_detect_node.hpp"

#include <functional>
#include <utility>
#include <cmath>
#include <algorithm>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace dig_detect_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

DigDetectNode::DigDetectNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("dig_detect_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: dig_detect_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&DigDetectNode::publish_generated_messages, this));
}

void DigDetectNode::declare_generated_parameters()
{
  this->declare_parameter<double>("dig_target_wt_tonnes", 5.874);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: dig_target_wt_tonnes");
  this->declare_parameter<double>("dig_start_limit_ratio_per_sec", -0.15);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: dig_start_limit_ratio_per_sec");
  this->declare_parameter<double>("dig_end_limit_ratio_per_sec", 0.025);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: dig_end_limit_ratio_per_sec");
  this->declare_parameter<double>("dig_duration_min_limit_sec", 0.5);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: dig_duration_min_limit_sec");
  this->declare_parameter<double>("dig_duration_max_limit_sec", 45.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: dig_duration_max_limit_sec");
  this->declare_parameter<double>("lift_lower_velocity_limit", -1.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: lift_lower_velocity_limit");
  this->declare_parameter<double>("wt_stability_gain", 2.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: wt_stability_gain");
  this->declare_parameter<double>("wt_stability_threshold", 0.03);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: wt_stability_threshold");
  this->declare_parameter<double>("dump_wt_change_startup_delay_sec", 1.2);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: dump_wt_change_startup_delay_sec");
  this->declare_parameter<int64_t>("circular_buffer_size", 60);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: circular_buffer_size");
  this->declare_parameter<double>("exec_rate_sec", 0.02);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: exec_rate_sec");
}

void DigDetectNode::setup_publishers()
{
  auto qos_pub_dig_detection_status = make_qos(10, "RELIABLE", "VOLATILE");
  pub_dig_detection_status_publisher_ = this->create_publisher<generated_interfaces::msg::DigDetectionStatus>("/lps/dig_detect/status", qos_pub_dig_detection_status);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: pub_dig_detection_status -> /lps/dig_detect/status");
}

void DigDetectNode::setup_subscribers()
{
  auto qos_sub_weigh_status = make_qos(10, "RELIABLE", "VOLATILE");
  sub_weigh_status_subscriber_ = this->create_subscription<generated_interfaces::msg::WeighStatus>("/lps/weigh/status", qos_sub_weigh_status, std::bind(&DigDetectNode::on_sub_weigh_status, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: sub_weigh_status <- /lps/weigh/status");
}

void DigDetectNode::setup_service_servers()
{
  server_reset_dig_state_service_ = this->create_service<generated_interfaces::srv::ResetDigState>("/lps/dig_detect/reset", std::bind(&DigDetectNode::handle_server_reset_dig_state, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_reset_dig_state -> /lps/dig_detect/reset");
}

void DigDetectNode::setup_service_clients()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE CLIENTS: dig_detect_node");
}

void DigDetectNode::publish_generated_messages()
{
  auto msg_pub_dig_detection_status = generated_interfaces::msg::DigDetectionStatus();

  // ============================================================================
  // USER BUSINESS LOGIC START: Dig Detection State Machine
  // Ported from LpsWeighDigDetect.c PayloadDigDetectUpdate()
  //       and LpsWeighDumpWtChange.c LpsWeighDumpWtChangeUpdate()
  //
  // IMPORTANT: Timer fires at 1Hz (1 second intervals).
  // All duration/rate calculations use ACTUAL_RATE = 1.0s, not the
  // 0.02s exec_rate param (which is the production 50Hz rate).
  // ============================================================================
  if (!weigh_received_) return;

  const double ACTUAL_RATE = 1.0;  // Timer fires every 1 second
  const int DEMO_BUF_SIZE = 5;    // Small buffer for 1Hz demo (fills in 5 sec)
  const uint32_t DEMO_STARTUP = 2; // 2 seconds startup delay

  auto & w = latest_weigh_;
  double dig_target = this->get_parameter("dig_target_wt_tonnes").as_double();
  double dig_start_limit = this->get_parameter("dig_start_limit_ratio_per_sec").as_double();
  double dig_end_limit = this->get_parameter("dig_end_limit_ratio_per_sec").as_double();
  double dig_min_dur = this->get_parameter("dig_duration_min_limit_sec").as_double();
  double dig_max_dur = this->get_parameter("dig_duration_max_limit_sec").as_double();
  double stab_gain = this->get_parameter("wt_stability_gain").as_double();
  double stab_thresh = this->get_parameter("wt_stability_threshold").as_double();

  // ── Step 1: DumpWtChange tracker (from LpsWeighDumpWtChange.c) ──
  if (!dwc_initialized_) {
    weight_buffer_.resize(DEMO_BUF_SIZE, 0.0f);
    startup_delay_ = DEMO_STARTUP;
    dwc_initialized_ = true;
  }

  if (w.cal_state_calibrated && w.use_filter_data_flag) {
    if (startup_delay_ > 0) {
      startup_delay_--;
      RCLCPP_INFO(this->get_logger(), "[DIG] startup delay: %u sec remaining", startup_delay_);
    } else {
      // Circular buffer update — store current filtered weight
      weight_buffer_[buffer_write_idx_] = w.inst_weight_filtered;
      if (buffer_count_ < weight_buffer_.size()) {
        buffer_count_++;
        dump_cumulative_wt_change_ = 0.0f;
      } else {
        // oldest - newest: negative means gaining weight (digging)
        size_t oldest_idx = (buffer_write_idx_ + 1) % weight_buffer_.size();
        dump_cumulative_wt_change_ = weight_buffer_[oldest_idx] - weight_buffer_[buffer_write_idx_];
      }
      buffer_write_idx_ = (buffer_write_idx_ + 1) % weight_buffer_.size();

      // Weight stability index (how stable is the weight right now?)
      float deriv_abs = std::abs(w.inst_weight_derivative);
      float pct_per_sec = (dig_target > 0) ? (deriv_abs / static_cast<float>(dig_target)) : 1.0f;
      float stab_inc = static_cast<float>(stab_gain * (1.0 - pct_per_sec / stab_thresh) * ACTUAL_RATE);
      wt_stability_index_ = std::max(0.0f, std::min(1.0f, wt_stability_index_ + stab_inc));
    }

    // ── Step 2: Dig Detection state machine (from LpsWeighDigDetect.c) ──
    weight_stabilized_ = (wt_stability_index_ >= 1.0f);

    // Check ALL 6 dig start conditions
    float start_thresh = static_cast<float>(dig_start_limit * dig_target);  // -0.881
    bool material_gaining = (dump_cumulative_wt_change_ < start_thresh);
    bool gear_forward = w.is_requested_gear_forward;
    bool boom_low = (w.lift_cyl_extension_pct < w.start_of_weigh_pct);
    bool not_racked = !w.full_rack_detected;

    if (material_gaining && gear_forward && boom_low && not_racked &&
        !dig_detected_ && !dig_started_) {
      dig_started_ = true;
      dig_state_ = 2;  // TENTATIVE_DIGGING
      RCLCPP_WARN(this->get_logger(),
        "[DIG] >>> TENTATIVE! wtChg=%.3f < thresh=%.3f, gear=FWD, ext=%.1f%%",
        dump_cumulative_wt_change_, start_thresh, w.lift_cyl_extension_pct);
    }

    // Count duration while tentative dig active
    if (dig_started_) {
      dig_duration_++;
      // Timeout check: at 1Hz, duration in seconds = dig_duration_
      if (dig_duration_ > static_cast<uint32_t>(dig_max_dur)) {
        RCLCPP_WARN(this->get_logger(), "[DIG] Timeout! %u sec > max %0.f sec", dig_duration_, dig_max_dur);
        dig_started_ = false;
        dig_duration_ = 0;
        dig_state_ = 1;  // NOT_DIGGING
      }
    } else if (dig_state_ == 0) {
      dig_state_ = 1;  // NOT_DIGGING
    }

    // Check if dig ended (weight gain stopped)
    float end_thresh = static_cast<float>(dig_end_limit * dig_target);  // +0.147
    if (dig_started_ && (dump_cumulative_wt_change_ > end_thresh)) {
      if (dig_duration_ < static_cast<uint32_t>(dig_min_dur)) {
        // Too short — cancel
        RCLCPP_WARN(this->get_logger(), "[DIG] Too short! %u sec < min %.1f sec", dig_duration_, dig_min_dur);
        dig_started_ = false;
        dig_state_ = 1;
        dig_duration_ = 0;
      } else {
        // VALID DIG CONFIRMED!
        dig_state_ = 3;  // DIGGING
        dig_detected_ = true;
        dig_started_ = false;
        dig_duration_ = 0;
        RCLCPP_WARN(this->get_logger(),
          "[DIG] >>> DIGGING CONFIRMED! Bucket filled successfully!");
      }
    }

    // Exit DIGGING state when weight stabilizes or bucket dumped
    if (dig_detected_ && (weight_stabilized_ || w.full_dump_detected)) {
      RCLCPP_WARN(this->get_logger(), "[DIG] >>> Back to NOT_DIGGING (stable=%d dump=%d)",
        weight_stabilized_, w.full_dump_detected);
      dig_detected_ = false;
      dig_state_ = 1;  // NOT_DIGGING
    }
  } else {
    dig_state_ = 0;  // UNKNOWN — not calibrated
    dig_duration_ = 0;
    weight_stabilized_ = false;
    dig_started_ = false;
    dig_detected_ = false;
  }

  const char* state_names[] = {"UNKNOWN", "NOT_DIGGING", "TENTATIVE", "DIGGING"};
  RCLCPP_INFO(this->get_logger(), "[DIG] state=%s started=%d detected=%d dur=%u wtChg=%.3f stab=%.2f filtWt=%.2f",
    state_names[dig_state_], dig_started_, dig_detected_, dig_duration_,
    dump_cumulative_wt_change_, wt_stability_index_, w.inst_weight_filtered);

  msg_pub_dig_detection_status.dig_state = dig_state_;
  msg_pub_dig_detection_status.dig_started = dig_started_;
  msg_pub_dig_detection_status.dig_detected = dig_detected_;
  msg_pub_dig_detection_status.dig_duration_cycles = dig_duration_;
  msg_pub_dig_detection_status.weight_stabilized = weight_stabilized_;
  msg_pub_dig_detection_status.dump_cumulative_wt_change = dump_cumulative_wt_change_;
  msg_pub_dig_detection_status.wt_stability_index = wt_stability_index_;
  // ============================================================================
  // USER BUSINESS LOGIC END: Dig Detection State Machine
  // ============================================================================

  pub_dig_detection_status_publisher_->publish(msg_pub_dig_detection_status);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /lps/dig_detect/status");
}

void DigDetectNode::on_sub_weigh_status(generated_interfaces::msg::WeighStatus::SharedPtr msg)
{
  latest_weigh_ = *msg;
  weigh_received_ = true;
}

void DigDetectNode::handle_server_reset_dig_state(const std::shared_ptr<generated_interfaces::srv::ResetDigState::Request> request, std::shared_ptr<generated_interfaces::srv::ResetDigState::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /lps/dig_detect/reset");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_reset_dig_state
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  RCLCPP_WARN(this->get_logger(), "[DIG] Reset requested: reason='%s'", request->reason.c_str());
  dig_state_ = 1;  dig_started_ = false;  dig_detected_ = false;
  dig_duration_ = 0;  weight_stabilized_ = false;
  dump_cumulative_wt_change_ = 0.0f;  wt_stability_index_ = 0.0f;
  buffer_count_ = 0;  buffer_write_idx_ = 0;
  response->success = true;
  response->current_dig_state = dig_state_;
  response->message = "Dig state reset to NOT_DIGGING";
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_reset_dig_state
  // ============================================================================
}


}  // namespace dig_detect_app