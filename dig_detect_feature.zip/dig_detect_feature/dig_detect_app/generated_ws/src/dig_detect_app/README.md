# dig_detect_app

Generated ROS2 application package from finalized grammar.

## Nodes

- `dig_detect_node` -> `DigDetectNode`

## Developer Rule

Generated code contains infrastructure only. Add business logic only inside marked sections:

```cpp
// USER BUSINESS LOGIC START
// USER BUSINESS LOGIC END
```