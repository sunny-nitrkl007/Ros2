#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/dig_detection_status.hpp"
#include "generated_interfaces/msg/weigh_status.hpp"
#include "generated_interfaces/srv/reset_dig_state.hpp"

namespace dig_detect_app
{

/**
 * @brief Generated ROS2 node class for `dig_detect_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class DigDetectNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit DigDetectNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();

  /**
   * @brief Generated subscriber callback for `sub_weigh_status`.
   */
  void on_sub_weigh_status(generated_interfaces::msg::WeighStatus::SharedPtr msg);

  /**
   * @brief Generated service handler for `server_reset_dig_state`.
   */
  void handle_server_reset_dig_state(
    const std::shared_ptr<generated_interfaces::srv::ResetDigState::Request> request,
    std::shared_ptr<generated_interfaces::srv::ResetDigState::Response> response);


  rclcpp::Publisher<generated_interfaces::msg::DigDetectionStatus>::SharedPtr pub_dig_detection_status_publisher_;
  rclcpp::Subscription<generated_interfaces::msg::WeighStatus>::SharedPtr sub_weigh_status_subscriber_;
  rclcpp::Service<generated_interfaces::srv::ResetDigState>::SharedPtr server_reset_dig_state_service_;
  rclcpp::TimerBase::SharedPtr publish_timer_;

  // ── Dig Detection State Machine (ported from LpsWeighDigDetect.c) ──
  // Dig states: 0=UNKNOWN, 1=NOT_DIGGING, 2=TENTATIVE_DIGGING, 3=DIGGING
  uint8_t dig_state_ = 0;
  bool dig_started_ = false;
  bool dig_detected_ = false;
  uint32_t dig_duration_ = 0;
  bool weight_stabilized_ = false;

  // DumpWtChange tracker (ported from LpsWeighDumpWtChange.c)
  std::vector<float> weight_buffer_;
  size_t buffer_write_idx_ = 0;
  size_t buffer_count_ = 0;
  float dump_cumulative_wt_change_ = 0.0f;
  float wt_stability_index_ = 0.0f;
  uint32_t startup_delay_ = 0;
  bool dwc_initialized_ = false;

  // Latest weigh status
  generated_interfaces::msg::WeighStatus latest_weigh_{};
  bool weigh_received_ = false;
};

}  // namespace dig_detect_app