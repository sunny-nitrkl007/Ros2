"""Generated launch file from finalized grammar."""

from launch import LaunchDescription
from launch.actions import SetEnvironmentVariable
from launch.substitutions import PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    actions = []

    actions.append(SetEnvironmentVariable("FASTDDS_DEFAULT_PROFILES_FILE", "output/dig_detect_ws/generated_ws/config/dds/fastdds_discovery.xml"))

    sensor_simulator_app_params = PathJoinSubstitution([
        FindPackageShare("sensor_simulator_app"),
        "config",
        "params.yaml",
    ])

    actions.append(Node(
        package="sensor_simulator_app",
        executable="sensor_simulator_app_combined",
        output="screen",
        parameters=[sensor_simulator_app_params],
    ))
    weighing_app_params = PathJoinSubstitution([
        FindPackageShare("weighing_app"),
        "config",
        "params.yaml",
    ])

    actions.append(Node(
        package="weighing_app",
        executable="weighing_app_combined",
        output="screen",
        parameters=[weighing_app_params],
    ))
    dig_detect_app_params = PathJoinSubstitution([
        FindPackageShare("dig_detect_app"),
        "config",
        "params.yaml",
    ])

    actions.append(Node(
        package="dig_detect_app",
        executable="dig_detect_app_combined",
        output="screen",
        parameters=[dig_detect_app_params],
    ))
    job_manager_app_params = PathJoinSubstitution([
        FindPackageShare("job_manager_app"),
        "config",
        "params.yaml",
    ])

    actions.append(Node(
        package="job_manager_app",
        executable="job_manager_app_combined",
        output="screen",
        parameters=[job_manager_app_params],
    ))
    diagnostics_app_params = PathJoinSubstitution([
        FindPackageShare("diagnostics_app"),
        "config",
        "params.yaml",
    ])

    actions.append(Node(
        package="diagnostics_app",
        executable="diagnostics_app_combined",
        output="screen",
        parameters=[diagnostics_app_params],
    ))

    return LaunchDescription(actions)