# generated_bringup

Generated bringup package for the grammar-generated ROS2 workspace.

## Launch

```bash
ros2 launch generated_bringup system_launch.py
```

## Discovery

Discovery enabled: `True`

Primary discovery server: `192.168.10.50:11811`
Domain ID: `42`
