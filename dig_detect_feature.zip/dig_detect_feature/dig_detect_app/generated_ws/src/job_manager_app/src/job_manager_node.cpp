#include "job_manager_app/job_manager_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace job_manager_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

JobManagerNode::JobManagerNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("job_manager_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: job_manager_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&JobManagerNode::publish_generated_messages, this));
}

void JobManagerNode::declare_generated_parameters()
{
  this->declare_parameter<double>("cycle_rate_hz", 10.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: cycle_rate_hz");
  this->declare_parameter<double>("default_target_weight_tonnes", 0.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: default_target_weight_tonnes");
  this->declare_parameter<int64_t>("default_tip_off_trigger_type", 1);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: default_tip_off_trigger_type");
  this->declare_parameter<int64_t>("default_tip_off_state", 0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: default_tip_off_state");
  this->declare_parameter<int64_t>("simple_cal_max_trucks", 15);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: simple_cal_max_trucks");
}

void JobManagerNode::setup_publishers()
{
  auto qos_pub_job_manager_status = make_qos(10, "RELIABLE", "VOLATILE");
  pub_job_manager_status_publisher_ = this->create_publisher<generated_interfaces::msg::JobManagerStatus>("/lps/job_mgr/status", qos_pub_job_manager_status);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: pub_job_manager_status -> /lps/job_mgr/status");
}

void JobManagerNode::setup_subscribers()
{
  auto qos_sub_weigh_status_jm = make_qos(10, "RELIABLE", "VOLATILE");
  sub_weigh_status_jm_subscriber_ = this->create_subscription<generated_interfaces::msg::WeighStatus>("/lps/weigh/status", qos_sub_weigh_status_jm, std::bind(&JobManagerNode::on_sub_weigh_status_jm, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: sub_weigh_status_jm <- /lps/weigh/status");
  auto qos_sub_dig_detection_status = make_qos(10, "RELIABLE", "VOLATILE");
  sub_dig_detection_status_subscriber_ = this->create_subscription<generated_interfaces::msg::DigDetectionStatus>("/lps/dig_detect/status", qos_sub_dig_detection_status, std::bind(&JobManagerNode::on_sub_dig_detection_status, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: sub_dig_detection_status <- /lps/dig_detect/status");
}

void JobManagerNode::setup_service_servers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE SERVERS: job_manager_node");
}

void JobManagerNode::setup_service_clients()
{
  client_reset_dig_state_client_ = this->create_client<generated_interfaces::srv::ResetDigState>("/lps/dig_detect/reset");
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT CREATED: client_reset_dig_state -> /lps/dig_detect/reset");
}

void JobManagerNode::publish_generated_messages()
{
  auto msg_pub_job_manager_status = generated_interfaces::msg::JobManagerStatus();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for pub_job_manager_status
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  float target = static_cast<float>(this->get_parameter("default_target_weight_tonnes").as_double());
  msg_pub_job_manager_status.dig_detected_for_pass = dig_detected_for_pass_;
  msg_pub_job_manager_status.truck_weight = truck_weight_;
  msg_pub_job_manager_status.pass_count = pass_count_;
  msg_pub_job_manager_status.target_weight = target;
  msg_pub_job_manager_status.remaining_weight = (target > 0) ? (target - truck_weight_) : 0.0f;
  msg_pub_job_manager_status.tip_off_state = (target > 0 && truck_weight_ >= target) ? 1 : 0;
  msg_pub_job_manager_status.weight_status = (pass_count_ > 0);

  RCLCPP_INFO(this->get_logger(), "[JOBMGR] passes=%u truck=%.2ft dig=%s",
    pass_count_, truck_weight_, dig_detected_for_pass_ ? "YES" : "no");
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for pub_job_manager_status
  // ============================================================================

  pub_job_manager_status_publisher_->publish(msg_pub_job_manager_status);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /lps/job_mgr/status");
}

void JobManagerNode::on_sub_weigh_status_jm(generated_interfaces::msg::WeighStatus::SharedPtr msg)
{
  last_bucket_weight_ = msg->best_bucket_weight;
}
void JobManagerNode::on_sub_dig_detection_status(generated_interfaces::msg::DigDetectionStatus::SharedPtr msg)
{
  uint8_t new_state = msg->dig_state;
  // Detect transition TO DIGGING (state 3) — means dig completed, add pass
  if (new_state == 3 && last_dig_state_ != 3) {
    dig_detected_for_pass_ = true;
    pass_count_++;
    truck_weight_ += last_bucket_weight_;
    RCLCPP_WARN(this->get_logger(), "[JOBMGR] DIG DETECTED! pass=%u bkt_wt=%.2f truck_wt=%.2f",
      pass_count_, last_bucket_weight_, truck_weight_);
  }
  // Reset when dig goes back to NOT_DIGGING
  if (new_state == 1 && last_dig_state_ == 3) {
    dig_detected_for_pass_ = false;
  }
  last_dig_state_ = new_state;
}


void JobManagerNode::send_client_reset_dig_state_request()
{
  auto request = std::make_shared<generated_interfaces::srv::ResetDigState::Request>();
  if (client_reset_dig_state_client_->service_is_ready()) {
    RCLCPP_WARN(this->get_logger(), "DEMO SERVICE CLIENT SEND: /lps/dig_detect/reset");
    client_reset_dig_state_client_->async_send_request(request);
  }
}

}  // namespace job_manager_app