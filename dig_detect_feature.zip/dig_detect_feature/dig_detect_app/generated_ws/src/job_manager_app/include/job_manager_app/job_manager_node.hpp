#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/dig_detection_status.hpp"
#include "generated_interfaces/msg/job_manager_status.hpp"
#include "generated_interfaces/msg/weigh_status.hpp"
#include "generated_interfaces/srv/reset_dig_state.hpp"

namespace job_manager_app
{

/**
 * @brief Generated ROS2 node class for `job_manager_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class JobManagerNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit JobManagerNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();

  /**
   * @brief Generated subscriber callback for `sub_weigh_status_jm`.
   */
  void on_sub_weigh_status_jm(generated_interfaces::msg::WeighStatus::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `sub_dig_detection_status`.
   */
  void on_sub_dig_detection_status(generated_interfaces::msg::DigDetectionStatus::SharedPtr msg);


  /**
   * @brief Generated helper that prepares an async request for `client_reset_dig_state`.
   */
  void send_client_reset_dig_state_request();

  rclcpp::Publisher<generated_interfaces::msg::JobManagerStatus>::SharedPtr pub_job_manager_status_publisher_;
  rclcpp::Subscription<generated_interfaces::msg::WeighStatus>::SharedPtr sub_weigh_status_jm_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::DigDetectionStatus>::SharedPtr sub_dig_detection_status_subscriber_;
  rclcpp::Client<generated_interfaces::srv::ResetDigState>::SharedPtr client_reset_dig_state_client_;
  rclcpp::TimerBase::SharedPtr publish_timer_;

  // ── Business logic state ──
  bool dig_detected_for_pass_ = false;
  uint8_t last_dig_state_ = 0;
  float truck_weight_ = 0.0f;
  uint16_t pass_count_ = 0;
  float last_bucket_weight_ = 0.0f;
  bool pass_added_ = false;
};

}  // namespace job_manager_app