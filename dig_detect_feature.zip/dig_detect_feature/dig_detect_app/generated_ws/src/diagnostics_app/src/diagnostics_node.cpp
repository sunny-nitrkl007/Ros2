#include "diagnostics_app/diagnostics_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace diagnostics_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

DiagnosticsNode::DiagnosticsNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("diagnostics_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: diagnostics_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&DiagnosticsNode::publish_generated_messages, this));
}

void DiagnosticsNode::declare_generated_parameters()
{
  this->declare_parameter<double>("cycle_rate_hz", 10.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: cycle_rate_hz");
  this->declare_parameter<double>("he_voltage_upper_limit_v", 4.8);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: he_voltage_upper_limit_v");
  this->declare_parameter<double>("he_voltage_lower_limit_v", 0.2);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: he_voltage_lower_limit_v");
  this->declare_parameter<double>("re_voltage_upper_limit_v", 4.8);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: re_voltage_upper_limit_v");
  this->declare_parameter<double>("re_voltage_lower_limit_v", 0.2);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: re_voltage_lower_limit_v");
  this->declare_parameter<double>("freq_abnormal_threshold_hz", 100.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: freq_abnormal_threshold_hz");
  this->declare_parameter<double>("startup_inhibit_time_sec", 285.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: startup_inhibit_time_sec");
}

void DiagnosticsNode::setup_publishers()
{
  auto qos_pub_sensor_diagnostics = make_qos(10, "RELIABLE", "VOLATILE");
  pub_sensor_diagnostics_publisher_ = this->create_publisher<generated_interfaces::msg::SensorDiagnostics>("/lps/diagnostics/sensor_health", qos_pub_sensor_diagnostics);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: pub_sensor_diagnostics -> /lps/diagnostics/sensor_health");
}

void DiagnosticsNode::setup_subscribers()
{
  auto qos_sub_hydraulic_sensor_diag = make_qos(5, "BEST_EFFORT", "VOLATILE");
  sub_hydraulic_sensor_diag_subscriber_ = this->create_subscription<generated_interfaces::msg::HydraulicSensorData>("/lps/sensors/hydraulic_data", qos_sub_hydraulic_sensor_diag, std::bind(&DiagnosticsNode::on_sub_hydraulic_sensor_diag, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: sub_hydraulic_sensor_diag <- /lps/sensors/hydraulic_data");
  auto qos_sub_dig_status_diag = make_qos(10, "RELIABLE", "VOLATILE");
  sub_dig_status_diag_subscriber_ = this->create_subscription<generated_interfaces::msg::DigDetectionStatus>("/lps/dig_detect/status", qos_sub_dig_status_diag, std::bind(&DiagnosticsNode::on_sub_dig_status_diag, this, std::placeholders::_1));
  RCLCPP_WARN(this->get_logger(), "DEMO SUBSCRIBER CREATED: sub_dig_status_diag <- /lps/dig_detect/status");
}

void DiagnosticsNode::setup_service_servers()
{
  server_get_sensor_health_service_ = this->create_service<generated_interfaces::srv::GetSensorHealth>("/lps/diagnostics/get_sensor_health", std::bind(&DiagnosticsNode::handle_server_get_sensor_health, this, std::placeholders::_1, std::placeholders::_2));
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE SERVER CREATED: server_get_sensor_health -> /lps/diagnostics/get_sensor_health");
}

void DiagnosticsNode::setup_service_clients()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE CLIENTS: diagnostics_node");
}

void DiagnosticsNode::publish_generated_messages()
{
  auto msg_pub_sensor_diagnostics = generated_interfaces::msg::SensorDiagnostics();

  // ============================================================================
  // USER BUSINESS LOGIC START: populate message for pub_sensor_diagnostics
  // Generated sample values below make runtime topic echo meaningful.
  // ============================================================================
  // All sensors healthy in simulation
  msg_pub_sensor_diagnostics.he_voltage_above = false;
  msg_pub_sensor_diagnostics.he_voltage_below = false;
  msg_pub_sensor_diagnostics.he_freq_abnormal = false;
  msg_pub_sensor_diagnostics.re_voltage_above = false;
  msg_pub_sensor_diagnostics.re_voltage_below = false;
  msg_pub_sensor_diagnostics.re_freq_abnormal = false;
  msg_pub_sensor_diagnostics.system_calibrated = true;
  msg_pub_sensor_diagnostics.overall_sensor_health_ok = true;
  // ============================================================================
  // USER BUSINESS LOGIC END: populate message for pub_sensor_diagnostics
  // ============================================================================

  pub_sensor_diagnostics_publisher_->publish(msg_pub_sensor_diagnostics);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /lps/diagnostics/sensor_health");
}

void DiagnosticsNode::on_sub_hydraulic_sensor_diag(generated_interfaces::msg::HydraulicSensorData::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /lps/sensors/hydraulic_data");
}
void DiagnosticsNode::on_sub_dig_status_diag(generated_interfaces::msg::DigDetectionStatus::SharedPtr msg)
{
  (void)msg;
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO SUBSCRIBE: received /lps/dig_detect/status");
}

void DiagnosticsNode::handle_server_get_sensor_health(const std::shared_ptr<generated_interfaces::srv::GetSensorHealth::Request> request, std::shared_ptr<generated_interfaces::srv::GetSensorHealth::Response> response)
{
  (void)request;
  RCLCPP_WARN(this->get_logger(), "DEMO SERVICE REQUEST: /lps/diagnostics/get_sensor_health");

  // ============================================================================
  // USER BUSINESS LOGIC START: handle service server_get_sensor_health
  // Generated sample values below make service-call responses meaningful.
  // ============================================================================
  response->he_sensor_ok = true;
  response->re_sensor_ok = true;
  response->lift_link_ok = true;
  response->tilt_link_ok = true;
  response->oil_temp_ok = true;
  response->overall_health_ok = true;
  response->fault_count = 7;
  // ============================================================================
  // USER BUSINESS LOGIC END: handle service server_get_sensor_health
  // ============================================================================
}


}  // namespace diagnostics_app