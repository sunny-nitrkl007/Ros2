#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/dig_detection_status.hpp"
#include "generated_interfaces/msg/hydraulic_sensor_data.hpp"
#include "generated_interfaces/msg/sensor_diagnostics.hpp"
#include "generated_interfaces/srv/get_sensor_health.hpp"

namespace diagnostics_app
{

/**
 * @brief Generated ROS2 node class for `diagnostics_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class DiagnosticsNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit DiagnosticsNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();

  /**
   * @brief Generated subscriber callback for `sub_hydraulic_sensor_diag`.
   */
  void on_sub_hydraulic_sensor_diag(generated_interfaces::msg::HydraulicSensorData::SharedPtr msg);
  /**
   * @brief Generated subscriber callback for `sub_dig_status_diag`.
   */
  void on_sub_dig_status_diag(generated_interfaces::msg::DigDetectionStatus::SharedPtr msg);

  /**
   * @brief Generated service handler for `server_get_sensor_health`.
   */
  void handle_server_get_sensor_health(
    const std::shared_ptr<generated_interfaces::srv::GetSensorHealth::Request> request,
    std::shared_ptr<generated_interfaces::srv::GetSensorHealth::Response> response);


  rclcpp::Publisher<generated_interfaces::msg::SensorDiagnostics>::SharedPtr pub_sensor_diagnostics_publisher_;
  rclcpp::Subscription<generated_interfaces::msg::HydraulicSensorData>::SharedPtr sub_hydraulic_sensor_diag_subscriber_;
  rclcpp::Subscription<generated_interfaces::msg::DigDetectionStatus>::SharedPtr sub_dig_status_diag_subscriber_;
  rclcpp::Service<generated_interfaces::srv::GetSensorHealth>::SharedPtr server_get_sensor_health_service_;
  rclcpp::TimerBase::SharedPtr publish_timer_;
};

}  // namespace diagnostics_app