#include "sensor_simulator_app/sensor_simulator_node.hpp"

#include <functional>
#include <utility>

#include "rmw/qos_policy_kind.h"

using namespace std::chrono_literals;

namespace sensor_simulator_app
{

namespace
{

rclcpp::QoS make_qos(std::size_t depth, const std::string & reliability, const std::string & durability)
{
  auto qos = rclcpp::QoS(rclcpp::KeepLast(depth));
  if (reliability == "RELIABLE") {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  } else {
    qos.reliability(RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT);
  }
  if (durability == "TRANSIENT_LOCAL") {
    qos.durability(RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL);
  } else {
    qos.durability(RMW_QOS_POLICY_DURABILITY_VOLATILE);
  }
  return qos;
}

}  // namespace

SensorSimulatorNode::SensorSimulatorNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("sensor_simulator_node", options)
{
  RCLCPP_WARN(this->get_logger(), "DEMO NODE STARTED: sensor_simulator_node");
  declare_generated_parameters();
  setup_publishers();
  setup_subscribers();
  setup_service_servers();
  setup_service_clients();
  publish_timer_ = this->create_wall_timer(1s, std::bind(&SensorSimulatorNode::publish_generated_messages, this));
}

void SensorSimulatorNode::declare_generated_parameters()
{
  this->declare_parameter<double>("publish_rate_hz", 50.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: publish_rate_hz");
  this->declare_parameter<double>("he_pressure_min_kpa", 0.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: he_pressure_min_kpa");
  this->declare_parameter<double>("he_pressure_max_kpa", 35000.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: he_pressure_max_kpa");
  this->declare_parameter<double>("re_pressure_min_kpa", 0.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: re_pressure_min_kpa");
  this->declare_parameter<double>("re_pressure_max_kpa", 25000.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: re_pressure_max_kpa");
  this->declare_parameter<double>("lift_extension_min_pct", 0.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: lift_extension_min_pct");
  this->declare_parameter<double>("lift_extension_max_pct", 100.0);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: lift_extension_max_pct");
  this->declare_parameter<bool>("enable_dig_scenario", true);
  RCLCPP_WARN(this->get_logger(), "DEMO PARAM DECLARED: enable_dig_scenario");
}

void SensorSimulatorNode::setup_publishers()
{
  auto qos_pub_hydraulic_sensor_data = make_qos(5, "BEST_EFFORT", "VOLATILE");
  pub_hydraulic_sensor_data_publisher_ = this->create_publisher<generated_interfaces::msg::HydraulicSensorData>("/lps/sensors/hydraulic_data", qos_pub_hydraulic_sensor_data);
  RCLCPP_WARN(this->get_logger(), "DEMO PUBLISHER CREATED: pub_hydraulic_sensor_data -> /lps/sensors/hydraulic_data");
}

void SensorSimulatorNode::setup_subscribers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SUBSCRIBERS: sensor_simulator_node");
}

void SensorSimulatorNode::setup_service_servers()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE SERVERS: sensor_simulator_node");
}

void SensorSimulatorNode::setup_service_clients()
{
  RCLCPP_WARN(this->get_logger(), "DEMO NO SERVICE CLIENTS: sensor_simulator_node");
}

void SensorSimulatorNode::publish_generated_messages()
{
  auto msg_pub_hydraulic_sensor_data = generated_interfaces::msg::HydraulicSensorData();

  // ============================================================================
  // USER BUSINESS LOGIC START: Dig scenario simulator
  // Simulates a loader performing: idle → approach pile → dig → raise → dump → repeat
  // Each phase lasts several seconds at 1Hz publish rate
  // ============================================================================
  tick_++;
  uint64_t phase_tick = tick_ % 30;  // 30-second repeating cycle

  if (phase_tick < 3) {
    // Phase 0: IDLE — bucket empty, low, forward gear, stationary
    scenario_phase_ = 0;
    sim_weight_ = 0.0;
    sim_lift_ext_ = 5.0;
    sim_lift_vel_ = 0.0;
    sim_bucket_angle_ = 50.0;  // fully racked
    sim_tilt_ext_ = 92.0;
  } else if (phase_tick < 6) {
    // Phase 1: APPROACH — driving forward toward pile, boom low
    scenario_phase_ = 1;
    sim_weight_ = 0.1;  // slight ground contact weight
    sim_lift_ext_ = 3.0;
    sim_lift_vel_ = 0.5;
    sim_bucket_angle_ = 45.0;
    sim_tilt_ext_ = 80.0;
  } else if (phase_tick < 14) {
    // Phase 2: DIGGING — bucket filling, weight increasing rapidly
    scenario_phase_ = 2;
    double dig_progress = (phase_tick - 6) / 8.0;  // 0.0 to 1.0
    sim_weight_ = 0.5 + dig_progress * 5.0;  // 0.5 to 5.5 tonnes
    sim_lift_ext_ = 3.0 + dig_progress * 5.0;  // stays low (3-8%)
    sim_lift_vel_ = 1.5;   // raising slightly
    sim_bucket_angle_ = 45.0 - dig_progress * 10.0;  // curling bucket
    sim_tilt_ext_ = 80.0 - dig_progress * 15.0;  // tilt curling
  } else if (phase_tick < 22) {
    // Phase 3: RAISE — lifting loaded bucket, weight stable
    scenario_phase_ = 3;
    double raise_progress = (phase_tick - 14) / 8.0;
    sim_weight_ = 5.5;  // stable weight
    sim_lift_ext_ = 8.0 + raise_progress * 80.0;  // 8% to 88%
    sim_lift_vel_ = 8.0;  // fast raise
    sim_bucket_angle_ = 35.0;  // racked
    sim_tilt_ext_ = 92.0;
  } else if (phase_tick < 27) {
    // Phase 4: DUMP — tilting bucket, losing material
    scenario_phase_ = 4;
    double dump_progress = (phase_tick - 22) / 5.0;
    sim_weight_ = 5.5 * (1.0 - dump_progress);  // weight drops to 0
    sim_lift_ext_ = 85.0;
    sim_lift_vel_ = 0.0;
    sim_bucket_angle_ = 35.0 - dump_progress * 75.0;  // 35 to -40 (dumping)
    sim_tilt_ext_ = 30.0;
  } else {
    // Phase 5: RETURN — empty bucket lowering, back to idle
    scenario_phase_ = 0;
    sim_weight_ = 0.0;
    sim_lift_ext_ = 85.0 - (phase_tick - 27) * 25.0;
    sim_lift_vel_ = -5.0;
    sim_bucket_angle_ = 50.0;
    sim_tilt_ext_ = 92.0;
  }

  // Simulate pressures from weight (simplified: ~2000 kPa per tonne)
  double he_pressure = 5000.0 + sim_weight_ * 2000.0;
  double re_pressure = 2000.0 + sim_weight_ * 500.0;

  msg_pub_hydraulic_sensor_data.lift_cyl_he_pressure_kpa = static_cast<float>(he_pressure);
  msg_pub_hydraulic_sensor_data.lift_cyl_re_pressure_kpa = static_cast<float>(re_pressure);
  msg_pub_hydraulic_sensor_data.he_sensor_status = 0;   // OK
  msg_pub_hydraulic_sensor_data.re_sensor_status = 0;   // OK
  msg_pub_hydraulic_sensor_data.lift_cyl_extension_pct = static_cast<float>(sim_lift_ext_);
  msg_pub_hydraulic_sensor_data.lift_cyl_velocity = static_cast<float>(sim_lift_vel_);
  msg_pub_hydraulic_sensor_data.tilt_cyl_extension_pct = static_cast<float>(sim_tilt_ext_);
  msg_pub_hydraulic_sensor_data.tilt_cyl_velocity = 0.0f;
  msg_pub_hydraulic_sensor_data.bucket_angle_deg = static_cast<float>(sim_bucket_angle_);
  msg_pub_hydraulic_sensor_data.hyd_oil_temp_deg_c = 45.0f;
  msg_pub_hydraulic_sensor_data.hyd_oil_temp_status = 0;   // OK
  msg_pub_hydraulic_sensor_data.requested_gear = (scenario_phase_ <= 2) ? 1 : 0;  // 1=Forward during approach/dig
  msg_pub_hydraulic_sensor_data.requested_gear_status = 0;  // OK

  RCLCPP_INFO(this->get_logger(), "[SIM] phase=%d wt=%.2f ext=%.1f%% vel=%.1f gear=%s",
    scenario_phase_, sim_weight_, sim_lift_ext_, sim_lift_vel_,
    (msg_pub_hydraulic_sensor_data.requested_gear == 1) ? "FWD" : "OTHER");
  // ============================================================================
  // USER BUSINESS LOGIC END: Dig scenario simulator
  // ============================================================================

  pub_hydraulic_sensor_data_publisher_->publish(msg_pub_hydraulic_sensor_data);
  RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 5000, "DEMO PUBLISH: /lps/sensors/hydraulic_data");
}




}  // namespace sensor_simulator_app