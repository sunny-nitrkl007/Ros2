#pragma once

// ============================================================================
// AUTO-GENERATED ROS2 NODE HEADER - INFRASTRUCTURE CODE
// ============================================================================

#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "generated_interfaces/msg/hydraulic_sensor_data.hpp"

namespace sensor_simulator_app
{

/**
 * @brief Generated ROS2 node class for `sensor_simulator_node`.
 *
 * This class is generated from finalized grammar. Developers should place
 * business logic only inside marked USER BUSINESS LOGIC sections in the .cpp file.
 */
class SensorSimulatorNode : public rclcpp::Node
{
public:
  /**
   * @brief Constructs the node and initializes generated ROS2 infrastructure.
   */
  explicit SensorSimulatorNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  /**
   * @brief Declares ROS2 parameters generated from the node parameter profile.
   */
  void declare_generated_parameters();

  /**
   * @brief Creates publisher endpoints generated from grammar interactions.
   */
  void setup_publishers();

  /**
   * @brief Creates subscriber endpoints generated from grammar interactions.
   */
  void setup_subscribers();

  /**
   * @brief Creates service server endpoints generated from grammar interactions.
   */
  void setup_service_servers();

  /**
   * @brief Creates service client endpoints generated from grammar interactions.
   */
  void setup_service_clients();

  /**
   * @brief Publishes sample/default messages for all generated publishers.
   */
  void publish_generated_messages();




  rclcpp::Publisher<generated_interfaces::msg::HydraulicSensorData>::SharedPtr pub_hydraulic_sensor_data_publisher_;
  rclcpp::TimerBase::SharedPtr publish_timer_;

  // ── Business logic state ──
  uint64_t tick_ = 0;          // cycle counter (increments each publish)
  int scenario_phase_ = 0;     // 0=idle, 1=approach, 2=digging, 3=raise, 4=dump, repeat
  double sim_weight_ = 0.0;    // simulated bucket payload (tonnes)
  double sim_lift_ext_ = 5.0;  // simulated lift cylinder extension %
  double sim_lift_vel_ = 0.0;
  double sim_bucket_angle_ = 50.0;
  double sim_tilt_ext_ = 90.0;
};

}  // namespace sensor_simulator_app