# sensor_simulator_app

Generated ROS2 application package from finalized grammar.

## Nodes

- `sensor_simulator_node` -> `SensorSimulatorNode`

## Developer Rule

Generated code contains infrastructure only. Add business logic only inside marked sections:

```cpp
// USER BUSINESS LOGIC START
// USER BUSINESS LOGIC END
```