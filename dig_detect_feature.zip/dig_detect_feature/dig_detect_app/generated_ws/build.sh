#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./local_deployment/scripts/local_build.sh