"""Structural tests for generated ROS2 workspace."""

from pathlib import Path


# --------------------------------------------------------------------------------------------------
# test_required_files_exist
# --------------------------------------------------------------------------------------------------
# Verifies that expected generated files exist after generation.
# This test intentionally avoids requiring a ROS2 environment.
# --------------------------------------------------------------------------------------------------
def test_required_files_exist():
    workspace = Path(__file__).resolve().parents[1]
    required_files = [
        "COLCON_BUILD_NOTES.md",
        "README.md",
        "RUNTIME_TESTING.md",
        "build.sh",
        "config/dds/fastdds_discovery.xml",
        "run.sh",
        "runtime_smoke_test.sh",
        "src/diagnostics_app/CMakeLists.txt",
        "src/diagnostics_app/README.md",
        "src/diagnostics_app/config/params.yaml",
        "src/diagnostics_app/include/diagnostics_app/diagnostics_node.hpp",
        "src/diagnostics_app/package.xml",
        "src/diagnostics_app/src/combined_main.cpp",
        "src/diagnostics_app/src/diagnostics_node.cpp",
        "src/diagnostics_app/src/diagnostics_node_main.cpp",
        "src/dig_detect_app/CMakeLists.txt",
        "src/dig_detect_app/README.md",
        "src/dig_detect_app/config/params.yaml",
        "src/dig_detect_app/include/dig_detect_app/dig_detect_node.hpp",
        "src/dig_detect_app/package.xml",
        "src/dig_detect_app/src/combined_main.cpp",
        "src/dig_detect_app/src/dig_detect_node.cpp",
        "src/dig_detect_app/src/dig_detect_node_main.cpp",
        "src/generated_bringup/CMakeLists.txt",
        "src/generated_bringup/README.md",
        "src/generated_bringup/launch/system_discovery_launch.py",
        "src/generated_bringup/launch/system_launch.py",
        "src/generated_bringup/package.xml",
        "src/generated_interfaces/CMakeLists.txt",
        "src/generated_interfaces/msg/DigDetectionStatus.msg",
        "src/generated_interfaces/msg/HydraulicSensorData.msg",
        "src/generated_interfaces/msg/JobManagerStatus.msg",
        "src/generated_interfaces/msg/SensorDiagnostics.msg",
        "src/generated_interfaces/msg/WeighStatus.msg",
        "src/generated_interfaces/package.xml",
        "src/generated_interfaces/srv/GetSensorHealth.srv",
        "src/generated_interfaces/srv/ResetDigState.srv",
        "src/job_manager_app/CMakeLists.txt",
        "src/job_manager_app/README.md",
        "src/job_manager_app/config/params.yaml",
        "src/job_manager_app/include/job_manager_app/job_manager_node.hpp",
        "src/job_manager_app/package.xml",
        "src/job_manager_app/src/combined_main.cpp",
        "src/job_manager_app/src/job_manager_node.cpp",
        "src/job_manager_app/src/job_manager_node_main.cpp",
        "src/sensor_simulator_app/CMakeLists.txt",
        "src/sensor_simulator_app/README.md",
        "src/sensor_simulator_app/config/params.yaml",
        "src/sensor_simulator_app/include/sensor_simulator_app/sensor_simulator_node.hpp",
        "src/sensor_simulator_app/package.xml",
        "src/sensor_simulator_app/src/combined_main.cpp",
        "src/sensor_simulator_app/src/sensor_simulator_node.cpp",
        "src/sensor_simulator_app/src/sensor_simulator_node_main.cpp",
        "src/weighing_app/CMakeLists.txt",
        "src/weighing_app/README.md",
        "src/weighing_app/config/params.yaml",
        "src/weighing_app/include/weighing_app/weighing_node.hpp",
        "src/weighing_app/package.xml",
        "src/weighing_app/src/combined_main.cpp",
        "src/weighing_app/src/weighing_node.cpp",
        "src/weighing_app/src/weighing_node_main.cpp",
        "test/test_generated_files.py",
        "test_build.sh",
    ]
    for relative_file in required_files:
        assert (workspace / relative_file).exists(), f"Missing generated file: {relative_file}"


# --------------------------------------------------------------------------------------------------
# test_workspace_helpers_exist
# --------------------------------------------------------------------------------------------------
# Ensures workspace helper files are generated.
# --------------------------------------------------------------------------------------------------
def test_workspace_helpers_exist():
    workspace = Path(__file__).resolve().parents[1]
    assert (workspace / "README.md").exists()
    assert (workspace / "COLCON_BUILD_NOTES.md").exists()
    assert (workspace / "build.sh").exists()
    assert (workspace / "run.sh").exists()
    assert (workspace / "test_build.sh").exists()


# --------------------------------------------------------------------------------------------------
# test_business_logic_markers_exist
# --------------------------------------------------------------------------------------------------
# Ensures generated C++ code contains developer extension points.
# --------------------------------------------------------------------------------------------------
def test_business_logic_markers_exist():
    workspace = Path(__file__).resolve().parents[1]
    source_files = list((workspace / "src").glob("**/*.cpp"))
    assert source_files, "Expected generated C++ source files"
    combined = "\n".join(path.read_text(encoding="utf-8") for path in source_files)
    assert "USER BUSINESS LOGIC START" in combined
    assert "USER BUSINESS LOGIC END" in combined


# --------------------------------------------------------------------------------------------------
# test_bringup_launch_uses_param_files
# --------------------------------------------------------------------------------------------------
# Ensures generated launch file wires params.yaml from each package.
# --------------------------------------------------------------------------------------------------
def test_bringup_launch_uses_param_files():
    workspace = Path(__file__).resolve().parents[1]
    launch_file = workspace / "src" / "generated_bringup" / "launch" / "system_launch.py"
    text = launch_file.read_text(encoding="utf-8")
    assert "PathJoinSubstitution" in text
    assert "FindPackageShare" in text
    assert "params.yaml" in text