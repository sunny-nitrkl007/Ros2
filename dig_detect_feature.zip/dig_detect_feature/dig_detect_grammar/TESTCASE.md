# Testcase: dig_detect_loader_system

## Purpose

Demonstrates the Dig Detection feature from the CAT Loader Payload System (LPS)
as a ROS2 workspace. Sensor simulator publishes hydraulic pressure data,
weighing node calculates instantaneous weight, dig detect node runs the
state machine, and job manager consumes the dig state output.

## Expected Output Location

```text
output/dig_detect_loader_system/generated_ws/
```

## Expected Validation

- Generated workspace folders exist for all 5 application packages.
- Generated custom interfaces package contains all 5 topic messages and 2 service definitions.
- Each application node has publisher/subscriber/service callbacks generated.
- Generated code contains business-logic placeholders for dig detection algorithm.
- Generated launch file starts all 5 nodes with correct parameter files.
- Generated parameter YAML files contain real loader machine config values.
- Generated code has comments above and inside every function.
