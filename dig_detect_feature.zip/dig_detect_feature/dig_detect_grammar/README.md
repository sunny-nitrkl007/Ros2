# Dig Detection — ROS2 Grammar (LPS Loader Payload System)

This grammar defines the **Dig Detection** feature from the CAT Loader Payload System,
migrated from the AIS/SCS platform to a ROS2 architecture.

## System Description

Detects when a wheel loader bucket is being filled with material by monitoring
the rate of weight change derived from hydraulic lift cylinder pressure sensors.

## Architecture

- **sensor_simulator_app**: Publishes simulated PWM sensor data (replaces physical HE/RE pressure sensors)
- **weighing_app**: Converts sensor data to instantaneous weight, runs Butterworth filter, dump weight change tracker
- **dig_detect_app**: Core dig detection state machine (NOT_DIGGING → TENTATIVE → DIGGING)
- **job_manager_app**: Consumes dig state for pass tracking and operator display
- **diagnostics_app**: Monitors sensor health and publishes diagnostic events

## V1 Generator Note

The V1 generator consumes only the `general/` grammar for ROS2 boilerplate generation.
The `ecus/` and `topology/` folders are retained for folder completeness and future deployment-aware generation.
