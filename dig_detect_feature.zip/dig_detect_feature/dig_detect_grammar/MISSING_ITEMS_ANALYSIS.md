# Dig Detection Grammar — Missing Items Analysis

## What the Grammar DOES Cover ✅

| Item | Grammar Location | Source in Current Code |
|------|------------------|----------------------|
| HE/RE pressure sensor data | `topics_data.yaml` → `hydraulic_sensor_data` | `PwmInputApp` SCS channel |
| Lift/Tilt cylinder extension & velocity | `topics_data.yaml` → `hydraulic_sensor_data` | `PwmInputApp` + kinematics |
| Bucket angle, oil temp, gear status | `topics_data.yaml` → `hydraulic_sensor_data` | `bmiCdl` DataLinkData |
| Filtered instantaneous weight | `topics_data.yaml` → `weigh_status` | `LpsWrk.InstWtFilt` |
| Weight derivative (rate of change) | `topics_data.yaml` → `weigh_status` | `LpsWrk.InstWtDer` |
| Dump state, full rack/dump flags | `topics_data.yaml` → `weigh_status` | `GetDumpStateStatus()` |
| Calibration status flag | `topics_data.yaml` → `weigh_status` | `LpsWrk.InitTbl.MachSpecificCfg.CalibTbl.CalStat` |
| Forward gear detection | `topics_data.yaml` → `weigh_status` | `LpsWeighIsRequestedGearForward()` |
| Dig state (4 states) | `topics_data.yaml` → `dig_detection_status` | `LpsWeighGetDigState()` |
| Dig started/detected/duration flags | `topics_data.yaml` → `dig_detection_status` | `LpsWrk.DigDetectData` |
| Cumulative weight change | `topics_data.yaml` → `dig_detection_status` | `LpsWrk.DumpWtChangeData` |
| Weight stability index | `topics_data.yaml` → `dig_detection_status` | `LpsWrk.DumpWtChangeData.WtStabilityIndex` |
| Truck weight, pass count, target | `topics_data.yaml` → `job_manager_status` | `LpsPtOutputs_t` |
| Sensor health diagnostics | `topics_data.yaml` → `sensor_diagnostics` | `AutonomyConditions` |
| Dig state reset service | `services_data.yaml` → `reset_dig_state` | `LpsSaWeighReqstChannel` |
| Sensor health query service | `services_data.yaml` → `get_sensor_health` | `AutonomyConditionDiag` |
| All 5 dig config params (target, limits, duration) | `parameter_profiles.yaml` → `dig_detect_parameters` | `Robot_CAT_950GC_HL.rb` |
| Weighing config (bore/rod dia, filter params) | `parameter_profiles.yaml` → `weighing_parameters` | `Robot_CAT_950GC_HL.rb` |
| Job manager config (rate, target wt, tip-off) | `parameter_profiles.yaml` → `job_manager_parameters` | `LpsSaJobMgrApp.rb` |
| Diagnostic thresholds (voltage, freq limits) | `parameter_profiles.yaml` → `diagnostics_parameters` | `AutonomyConditionDiagnostics.rb` |
| QoS profiles (sensor, realtime, default, service) | `qos_profiles.yaml` | SCS channel config |
| Discovery server config | `discovery_profiles.yaml` | SCS `--advertisedIntf` |
| 5 apps × 5 nodes with proper pub/sub/srv wiring | `applications.yaml` + segments | AIS always-on tasks |

---

## What the Grammar CANNOT Express (Grammar Limitations) ❌

These are items that the **FLYNC Grammar schema itself does not support** — no YAML fields exist for them.

| # | Missing Item | Current Code Location | Why It Matters | Workaround |
|---|---|---|---|---|
| 1 | **Calibration curves (11-point arrays)** | `LpsCalNvmTbl_t` — `SlowRaiseEmptyBktLiftHt[11]`, `SlowRaiseEmptyBktLiftPres[11]`, etc. (8 arrays × 11 points) | Core weight calculation: `InstWt = CalWt × (CurrPres - EmptyPres) / (FullPres - EmptyPres)` | Load from YAML parameter file or NVM file at runtime. Grammar has no array/table parameter type. |
| 2 | **Kinematics lookup tables** | `Robot_CAT_950GC_HL.rb` — `inLiftAngle[21]`, `outLiftCylLen[21]`, `outTiltAngle[17]`, `outTiltCylLen[21×17]` 2D table | Converts sensor duty cycle → cylinder extension % → angle. 300+ float values. | Load from separate YAML/CSV config file. Grammar has no 2D table support. |
| 3 | **Tilt compensation gain map** | `Robot_CAT_950GC_HL.rb` — `TiltCompGainData[20×15]` = 300 floats | Corrects weight for bucket tilt angle at each lift/tilt position | Load from separate YAML/CSV file. Grammar cannot express 2D maps. |
| 4 | **NVM persistence model** | `app_nvm_file_cfg.c`, `app_nvm_file_access.c` — block-based file storage with CRC integrity | Retains cal curves, zero weight, lifetime totals, pass data across power cycles | Implement as a ROS2 parameter server with YAML dump/load, or a custom NVM node. Grammar has no persistence concept. |
| 5 | **Circular buffer definition** | `LpsWeighWtRateChangePtrs_t` — ring buffer with `StartPtr`, `EndPtr`, `FixedStartPtr`, `MaxSamples` | Core data structure for `DumpCumulativeWtChange` calculation (oldest - newest sample) | Implementation detail inside the node code. Grammar describes interfaces, not internal data structures. |
| 6 | **Butterworth filter state** | `BSFILT`, `LPFILT` structs in `cpm_filter.h` — 3-stage cascaded band-stop filter coefficients | Filters raw instantaneous weight before dig detection uses it | Implementation detail. Grammar only provides the tuning params (center freq, damping). |
| 7 | **Timer/periodic execution model** | `app_rtos_config.h` — `SCL_TASK_1X_PERIOD = 0.01s` (100Hz task), weighing exec at 20ms | Grammar has no concept of execution rate or timer scheduling | Set via `exec_rate_sec` parameter. ROS2 node uses `create_wall_timer()`. |
| 8 | **Task priority / real-time scheduling** | `app_rtos_config_posix.c` — POSIX thread priorities, `SCHED_FIFO` | Ensures weighing runs at deterministic 20ms intervals | ROS2 executor config — not expressible in grammar. Configure in launch file or code. |
| 9 | **CAN J1939 protocol mapping** | `bmiCdl` — PID `0xF840`/`0xF841` for cal commands, MID `0x1C` for master ECM, DSI offsets | How physical CAN messages map to sensor data fields | Replaced by ROS2 topics in the grammar. CAN bridge node needed separately. |
| 10 | **SCS channel queue sizes** | `interfaces_Loaders.rb` — `queueSize = 20` per channel | Buffering depth for inter-process communication | Mapped to QoS `history_depth` in grammar (partially covered). |
| 11 | **EDDT fault code mapping** | `AutonomyConditionDiagnostics.rb` — maps condition names to numeric fault codes (e.g., `LiftHEVoltageAbove` → EDDT event) | Machine diagnostic event log integration | Use `diagnostic_msgs/DiagnosticArray` standard ROS2 message. Grammar cannot express fault code mappings. |
| 12 | **Calibration state machine** | `LpsCalEmptyCalMain()`, `LpsCalFullCalMain()` — multi-step guided calibration with operator interaction | Required to generate the 11-point cal curves in the first place | Separate ROS2 action or lifecycle node. Grammar has no action/lifecycle support (marked "future" in templates). |
| 13 | **VP3 telematics record format** | `LpsPtPayloadBlk_t` — binary payload record with CA14 timestamp, SHM, weight, calc method | Telematics upload to MineStar/VisionLink | Out of scope for dig detection demo. Would be a separate file-writer node. |
| 14 | **Horn-on-store hardware output** | `OutputApp` — drives physical horn relay via GPIO | Audible alert when pass is stored | Out of scope for dig detection. Would be an I/O bridge node. |
| 15 | **Machine model selection** | `ApplicationTable.rb` — maps serial number → `Robot_CAT_950GC_HL.rb` config (69 loader variants) | Selects correct kinematics/cal params per machine model | Load correct parameter file based on a `machine_model` parameter. Grammar has no conditional config. |
| 16 | **Conditional compilation / feature flags** | `CPMInstallStat`, `UseFilterDataFlag`, `AutoManulDumpStateActiveFlag` | Enables/disables subsystems at runtime | Express as boolean parameters in grammar (partially done). |
| 17 | **Overload warning logic** | `LpsWeighOverloadWarnings_t` — `BucketLoadFactor > 116.5%` triggers overload | Safety alert when bucket exceeds rated capacity | Not part of dig detection. Would be a separate topic/node. |
| 18 | **Zero/tare adjustment logic** | `LpsZeroing.c` — auto-zero timer (5min init, 4hr recurring), oil temp delta trigger | Compensates for oil temp drift affecting weight accuracy | Not part of dig detection. Would be in the weighing node. |
| 19 | **Simple calibration (on-the-fly)** | `LpsSaJobMgrProcess.cpp` — `add_truck_simple_cal` adjusts CalAdjust factor from truck scale comparison | Runtime cal correction without full empty/full cal procedure | Not part of dig detection. Would be a service on the weighing node. |
| 20 | **Multi-instance node support** | SCS supports multiple machines (`MachineMap["one"]` through `["five"]`), each running same apps | Fleet of loaders sharing data | ROS2 namespacing. Grammar has no multi-instance/namespace concept. |

---

## Summary Statistics

| Category | Count |
|---|---|
| ✅ Items fully covered by grammar | 22 |
| ❌ Items grammar CANNOT express | 20 |
| 🔧 Items partially covered (workaround exists) | 8 of the 20 |
| 🚫 Items truly out of scope for dig detection | 7 of the 20 (#13, #14, #17, #18, #19, #12 partial, #9) |
| ⚠️ Items requiring code-level implementation only | 6 of the 20 (#5, #6, #7, #8, #16, #20) |

## Key Takeaway

The grammar covers **all interfaces, topics, services, parameters, QoS, and discovery** — everything needed to generate the ROS2 communication skeleton. What it **cannot** express are:

1. **Internal algorithm state** (circular buffers, filter coefficients, state machine internals) — these are implementation details inside the generated node code
2. **Large data tables** (cal curves, kinematics, tilt maps) — need separate config files loaded at runtime
3. **Persistence/NVM** — needs a custom solution outside the grammar
4. **Hardware I/O mapping** (CAN PIDs, GPIO pins) — replaced by ROS2 topics in the abstraction
5. **Lifecycle/actions** — grammar schema placeholder exists but generator doesn't emit them yet
