#include "application.h"
int Application::getValue()
{
    return 100;
}
