#pragma once
#include <memory>
namespace rclcpp
{
class Node;
}
class RosInterface
{
public:
    RosInterface();
    ~RosInterface();
    void publish(int value);
    void spin();
private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};
