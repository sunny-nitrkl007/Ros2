#include "application.h"
#include "ros_interface.h"
#include <chrono>
#include <thread>
#include <rclcpp/rclcpp.hpp>
int main(int argc,char **argv)
{
    rclcpp::init(argc,argv);
    Application app;
    RosInterface ros;
    while(true)
    {
        ros.publish(app.getValue());
        ros.spin();
        std::this_thread::sleep_for(std::chrono::seconds(1));
        std::cout<<"Sending....\n";
    }
    rclcpp::shutdown();
}
