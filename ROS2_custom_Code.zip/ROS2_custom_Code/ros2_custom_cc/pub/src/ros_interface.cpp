#include "ros_interface.h"
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/int32.hpp>
class RosInterface::Impl
{
public:
    Impl()
    {
        node = std::make_shared<rclcpp::Node>("publisher");
        std::cout<<"Node created: "<<node->get_fully_qualified_name()<<std::endl; 
        publisher =
            node->create_publisher<std_msgs::msg::Int32>("number",10);
    }
    void publish(int value)
    {
        std_msgs::msg::Int32 msg;
        msg.data = value;
        publisher->publish(msg);
        std::cout<<"Published....\n";
    }
    std::shared_ptr<rclcpp::Node> node;
    rclcpp::Publisher<std_msgs::msg::Int32>::SharedPtr publisher;
};
RosInterface::~RosInterface() = default;

RosInterface::RosInterface()
{
    impl_ = std::make_unique<Impl>();
}
void RosInterface::publish(int value)
{
    impl_->publish(value);
}
void RosInterface::spin()
{
    rclcpp::spin_some(impl_->node);
}
