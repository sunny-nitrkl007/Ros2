#pragma once
class Application
{
public:
    int getValue();
};
