#!/bin/bash
 
set -e
 
source /opt/ros/jazzy/setup.bash
 
rm -rf build
mkdir build
cd build
 
cmake ..
make -j$(nproc)
