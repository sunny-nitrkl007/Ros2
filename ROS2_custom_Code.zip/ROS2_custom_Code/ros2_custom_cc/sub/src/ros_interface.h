#pragma once
 
#include <memory>
 
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/int32.hpp>
 
class RosInterface
{
public:
    RosInterface();
    ~RosInterface();
    void spin();
 
private:
    rclcpp::Node::SharedPtr node_;
 
    rclcpp::Subscription<std_msgs::msg::Int32>::SharedPtr subscription_;
};
  
