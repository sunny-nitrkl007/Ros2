#include "ros_interface.h"
 
#include <rclcpp/rclcpp.hpp>
 
int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
 
    RosInterface ros;
 
    while (rclcpp::ok())
    {
//        std::cout<<"While called\n";
        ros.spin();
    }
 
    rclcpp::shutdown();
 
    return 0;
}
