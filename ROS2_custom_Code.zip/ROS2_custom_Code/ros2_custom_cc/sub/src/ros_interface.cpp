#include "ros_interface.h"
 
#include <iostream>
 
RosInterface::RosInterface()
{
    node_ = std::make_shared<rclcpp::Node>("subscriber");
    std::cout<<"Node created: "<<node_->get_fully_qualified_name()<<std::endl; 
    subscription_ =
        node_->create_subscription<std_msgs::msg::Int32>(
            "number",
            10,
            [](const std_msgs::msg::Int32::SharedPtr msg)
            {
                std::cout << "Received: "
                          << msg->data
                          << std::endl;
            });
}
 
void RosInterface::spin()
{
    rclcpp::spin_some(node_);
}
RosInterface::~RosInterface() = default;
