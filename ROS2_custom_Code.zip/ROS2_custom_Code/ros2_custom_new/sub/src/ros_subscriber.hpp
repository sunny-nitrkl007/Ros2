#ifndef ROS_SUBSCRIBER_HPP_
#define ROS_SUBSCRIBER_HPP_

#include <string>
#include <memory>
#include <mutex>
#include <thread>
#include <atomic>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

// Thin wrapper around ROS 2 subscribing.
// Spins its own executor on a background thread, so your application
// code never calls rclcpp::spin() and never writes a message callback —
// it only ever calls RosSubscriber::receive(out).
class RosSubscriber
{
public:
  explicit RosSubscriber(const std::string & topic_name, const std::string & node_name = "ros_subscriber_wrapper");
  ~RosSubscriber();

  // Non-blocking. Returns true and fills `out` if a new message has
  // arrived since the last call to receive(). Returns false otherwise.
  bool receive(std::string & out);

private:
  void topic_callback(const std_msgs::msg::String & msg);
  void spin_loop();

  std::shared_ptr<rclcpp::Node> node_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription_;

  std::thread spin_thread_;
  std::atomic<bool> running_;

  std::mutex mutex_;
  std::string latest_msg_;
  bool has_new_msg_;
};

#endif  // ROS_SUBSCRIBER_HPP_
