#include <chrono>
#include <thread>
#include <string>
#include <iostream>

#include "rclcpp/rclcpp.hpp"
#include "ros_subscriber.hpp"

// This is "your" application code. It does not know about rclcpp::Node,
// callbacks, or spinning — it just has a RosSubscriber and calls receive().
int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);

  RosSubscriber sub("chatter");

  while (rclcpp::ok()) {
    std::string data;

    // <-- this is the only ROS-related call your app logic ever makes
    if (sub.receive(data)) {
      std::cout << "App received: " << data << std::endl;
    }

    // ... rest of your application logic runs here, independent of ROS ...

    std::this_thread::sleep_for(std::chrono::milliseconds(50));
  }

  rclcpp::shutdown();
  return 0;
}
