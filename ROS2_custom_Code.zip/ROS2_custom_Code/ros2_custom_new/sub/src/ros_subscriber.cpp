#include "ros_subscriber.hpp"

RosSubscriber::RosSubscriber(const std::string & topic_name, const std::string & node_name)
: running_(true), has_new_msg_(false)
{
  // Assumes rclcpp::init() was already called once by main().
  node_ = std::make_shared<rclcpp::Node>(node_name);

  subscription_ = node_->create_subscription<std_msgs::msg::String>(
    topic_name, 10,
    std::bind(&RosSubscriber::topic_callback, this, std::placeholders::_1));

  // Spin this node's executor on its own thread so receive() can be
  // a plain non-blocking call from the app's main loop.
  spin_thread_ = std::thread(&RosSubscriber::spin_loop, this);
}

RosSubscriber::~RosSubscriber()
{
  running_ = false;
  if (spin_thread_.joinable()) {
    spin_thread_.join();
  }
}

void RosSubscriber::spin_loop()
{
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(node_);
  while (running_ && rclcpp::ok()) {
    executor.spin_some(std::chrono::milliseconds(100));
  }
}

void RosSubscriber::topic_callback(const std_msgs::msg::String & msg)
{
  std::lock_guard<std::mutex> lock(mutex_);
  latest_msg_ = msg.data;
  has_new_msg_ = true;
}

bool RosSubscriber::receive(std::string & out)
{
  std::lock_guard<std::mutex> lock(mutex_);
  if (!has_new_msg_) {
    return false;
  }
  out = latest_msg_;
  has_new_msg_ = false;
  return true;
}
