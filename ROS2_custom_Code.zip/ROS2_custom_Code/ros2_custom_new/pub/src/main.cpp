#include <chrono>
#include <thread>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "ros_publisher.hpp"

// This is "your" application code. It does not know about rclcpp::Node,
// callbacks, or spinning — it just has a RosPublisher and calls publish().
int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);

  RosPublisher pub("chatter");

  int count = 0;
  while (rclcpp::ok()) {
    std::string data = "Hello ROS2, count: " + std::to_string(count++);

    // <-- this is the only ROS-related call your app logic ever makes
    pub.publish(data);

    std::this_thread::sleep_for(std::chrono::milliseconds(500));
  }

  rclcpp::shutdown();
  return 0;
}
