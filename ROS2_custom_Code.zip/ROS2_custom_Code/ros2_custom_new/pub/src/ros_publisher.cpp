#include "ros_publisher.hpp"

RosPublisher::RosPublisher(const std::string & topic_name, const std::string & node_name)
{
  // Assumes rclcpp::init() was already called once by main().
  node_ = std::make_shared<rclcpp::Node>(node_name);
  publisher_ = node_->create_publisher<std_msgs::msg::String>(topic_name, 10);
}

RosPublisher::~RosPublisher() = default;

void RosPublisher::publish(const std::string & data)
{
  auto message = std_msgs::msg::String();
  message.data = data;
  publisher_->publish(message);
}
