#ifndef ROS_PUBLISHER_HPP_
#define ROS_PUBLISHER_HPP_

#include <string>
#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

// Thin wrapper around ROS 2 publishing.
// Your application code never touches rclcpp::Node directly —
// it only ever calls RosPublisher::publish(data).
class RosPublisher
{
public:
  explicit RosPublisher(const std::string & topic_name, const std::string & node_name = "ros_publisher_wrapper");
  ~RosPublisher();

  // The only call your app logic needs.
  void publish(const std::string & data);

private:
  std::shared_ptr<rclcpp::Node> node_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
};

#endif  // ROS_PUBLISHER_HPP_
