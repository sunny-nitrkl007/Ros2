Commands befor execute the prgm
--------------------------
echo $ROS_DOMAIN_ID 

echo $RMW_IMPLEMENTATION 

source /opt/ros/jazzy/setup.bash



For build
--------------------------

./build.sh


executable path
------------------------------
CUR_DIR/build



Incase of not working.
-----------------------------------
ros2 daemon stop

ros2 daemon start


For monitor
-----------------------------------
 ros2 topic list
 ros2 node list


Pre-requisites
------------------------------
ROS2 -jazzy installed.