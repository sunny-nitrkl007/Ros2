// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from cpm_common_interfaces:msg/LpsSaJobMgrReqstChannel.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst_channel__functions.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst_channel__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace cpm_common_interfaces
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void LpsSaJobMgrReqstChannel_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel(_init);
}

void LpsSaJobMgrReqstChannel_fini_function(void * message_memory)
{
  auto typed_message = static_cast<cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel *>(message_memory);
  typed_message->~LpsSaJobMgrReqstChannel();
}

size_t size_function__LpsSaJobMgrReqstChannel__requests(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<cpm_common_interfaces::msg::LpsSaJobMgrReqst> *>(untyped_member);
  return member->size();
}

const void * get_const_function__LpsSaJobMgrReqstChannel__requests(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<cpm_common_interfaces::msg::LpsSaJobMgrReqst> *>(untyped_member);
  return &member[index];
}

void * get_function__LpsSaJobMgrReqstChannel__requests(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<cpm_common_interfaces::msg::LpsSaJobMgrReqst> *>(untyped_member);
  return &member[index];
}

void fetch_function__LpsSaJobMgrReqstChannel__requests(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const cpm_common_interfaces::msg::LpsSaJobMgrReqst *>(
    get_const_function__LpsSaJobMgrReqstChannel__requests(untyped_member, index));
  auto & value = *reinterpret_cast<cpm_common_interfaces::msg::LpsSaJobMgrReqst *>(untyped_value);
  value = item;
}

void assign_function__LpsSaJobMgrReqstChannel__requests(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<cpm_common_interfaces::msg::LpsSaJobMgrReqst *>(
    get_function__LpsSaJobMgrReqstChannel__requests(untyped_member, index));
  const auto & value = *reinterpret_cast<const cpm_common_interfaces::msg::LpsSaJobMgrReqst *>(untyped_value);
  item = value;
}

void resize_function__LpsSaJobMgrReqstChannel__requests(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<cpm_common_interfaces::msg::LpsSaJobMgrReqst> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember LpsSaJobMgrReqstChannel_message_member_array[13] = {
  {
    "app_name",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, app_name),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "app_request_id",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, app_request_id),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "command",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<cpm_common_interfaces::msg::JobMgrReqstChannelCommand>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, command),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "data_tipoff_trigger_type",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<cpm_common_interfaces::msg::TipOffTriggerType>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, data_tipoff_trigger_type),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "data_tipoff_mode",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<cpm_common_interfaces::msg::TipOffState>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, data_tipoff_mode),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "data_auto_store_pass_count",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, data_auto_store_pass_count),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "data_task_number",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, data_task_number),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "data_enabled",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, data_enabled),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "data_target_type",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, data_target_type),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "data_subtotal_index",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, data_subtotal_index),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "data_total_target_weight",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, data_total_target_weight),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "data_subtotal_info",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<cpm_common_interfaces::msg::LpsSaJobMgrSubtotalInfo>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, data_subtotal_info),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "requests",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<cpm_common_interfaces::msg::LpsSaJobMgrReqst>(),  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel, requests),  // bytes offset in struct
    nullptr,  // default value
    size_function__LpsSaJobMgrReqstChannel__requests,  // size() function pointer
    get_const_function__LpsSaJobMgrReqstChannel__requests,  // get_const(index) function pointer
    get_function__LpsSaJobMgrReqstChannel__requests,  // get(index) function pointer
    fetch_function__LpsSaJobMgrReqstChannel__requests,  // fetch(index, &value) function pointer
    assign_function__LpsSaJobMgrReqstChannel__requests,  // assign(index, value) function pointer
    resize_function__LpsSaJobMgrReqstChannel__requests  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers LpsSaJobMgrReqstChannel_message_members = {
  "cpm_common_interfaces::msg",  // message namespace
  "LpsSaJobMgrReqstChannel",  // message name
  13,  // number of fields
  sizeof(cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel),
  false,  // has_any_key_member_
  LpsSaJobMgrReqstChannel_message_member_array,  // message members
  LpsSaJobMgrReqstChannel_init_function,  // function to initialize message memory (memory has to be allocated)
  LpsSaJobMgrReqstChannel_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t LpsSaJobMgrReqstChannel_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &LpsSaJobMgrReqstChannel_message_members,
  get_message_typesupport_handle_function,
  &cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__get_type_hash,
  &cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__get_type_description,
  &cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace cpm_common_interfaces


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel>()
{
  return &::cpm_common_interfaces::msg::rosidl_typesupport_introspection_cpp::LpsSaJobMgrReqstChannel_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, cpm_common_interfaces, msg, LpsSaJobMgrReqstChannel)() {
  return &::cpm_common_interfaces::msg::rosidl_typesupport_introspection_cpp::LpsSaJobMgrReqstChannel_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
