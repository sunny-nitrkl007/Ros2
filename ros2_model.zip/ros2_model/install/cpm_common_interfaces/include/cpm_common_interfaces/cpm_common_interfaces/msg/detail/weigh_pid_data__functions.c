// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/WeighPidData.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/weigh_pid_data__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `prod_measure_sensor_status`
#include "cpm_common_interfaces/msg/detail/prod_measure_sensor_status__functions.h"
// Member `link_sensor_cal_lim`
#include "cpm_common_interfaces/msg/detail/link_sensor_cal_lim__functions.h"

bool
cpm_common_interfaces__msg__WeighPidData__init(cpm_common_interfaces__msg__WeighPidData * msg)
{
  if (!msg) {
    return false;
  }
  // pload_sys_zero_stat
  // ldr_payload_stat
  // overload_warning_enabled
  // prod_measure_sensor_status
  if (!cpm_common_interfaces__msg__ProdMeasureSensorStatus__init(&msg->prod_measure_sensor_status)) {
    cpm_common_interfaces__msg__WeighPidData__fini(msg);
    return false;
  }
  // link_sensor_cal_lim
  if (!cpm_common_interfaces__msg__LinkSensorCalLim__init(&msg->link_sensor_cal_lim)) {
    cpm_common_interfaces__msg__WeighPidData__fini(msg);
    return false;
  }
  // loader_bkt_pload_tgt_wt
  // loader_bkt_pload_tgt_wt_per
  // pload_sys_zero_req_stat
  // pload_sys_cal_wt_entry_req_stat
  // last_pload_wt
  // prod_measure_weigh_status
  // bkt_payload_data
  // qr_hyd_oil_temp_min_c
  // qr_lift_cyl_vel_min_mm_sec
  // qr_lift_cyl_vel_max_mm_sec
  // machine_rear_lateral_acceleration
  // machine_rear_longitudinal_acceleration
  // machine_rear_vertical_acceleration
  // machine_pitch
  // machine_slope
  // machine_rear_roll
  // machine_rear_side_slope
  // machine_roll
  // machine_side_slope
  // tipoff_pitch_cal_offset
  // hyd_oil_temp_enabled
  // audible_weight_enabled
  // audible_weight_command
  return true;
}

void
cpm_common_interfaces__msg__WeighPidData__fini(cpm_common_interfaces__msg__WeighPidData * msg)
{
  if (!msg) {
    return;
  }
  // pload_sys_zero_stat
  // ldr_payload_stat
  // overload_warning_enabled
  // prod_measure_sensor_status
  cpm_common_interfaces__msg__ProdMeasureSensorStatus__fini(&msg->prod_measure_sensor_status);
  // link_sensor_cal_lim
  cpm_common_interfaces__msg__LinkSensorCalLim__fini(&msg->link_sensor_cal_lim);
  // loader_bkt_pload_tgt_wt
  // loader_bkt_pload_tgt_wt_per
  // pload_sys_zero_req_stat
  // pload_sys_cal_wt_entry_req_stat
  // last_pload_wt
  // prod_measure_weigh_status
  // bkt_payload_data
  // qr_hyd_oil_temp_min_c
  // qr_lift_cyl_vel_min_mm_sec
  // qr_lift_cyl_vel_max_mm_sec
  // machine_rear_lateral_acceleration
  // machine_rear_longitudinal_acceleration
  // machine_rear_vertical_acceleration
  // machine_pitch
  // machine_slope
  // machine_rear_roll
  // machine_rear_side_slope
  // machine_roll
  // machine_side_slope
  // tipoff_pitch_cal_offset
  // hyd_oil_temp_enabled
  // audible_weight_enabled
  // audible_weight_command
}

bool
cpm_common_interfaces__msg__WeighPidData__are_equal(const cpm_common_interfaces__msg__WeighPidData * lhs, const cpm_common_interfaces__msg__WeighPidData * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // pload_sys_zero_stat
  if (lhs->pload_sys_zero_stat != rhs->pload_sys_zero_stat) {
    return false;
  }
  // ldr_payload_stat
  if (lhs->ldr_payload_stat != rhs->ldr_payload_stat) {
    return false;
  }
  // overload_warning_enabled
  if (lhs->overload_warning_enabled != rhs->overload_warning_enabled) {
    return false;
  }
  // prod_measure_sensor_status
  if (!cpm_common_interfaces__msg__ProdMeasureSensorStatus__are_equal(
      &(lhs->prod_measure_sensor_status), &(rhs->prod_measure_sensor_status)))
  {
    return false;
  }
  // link_sensor_cal_lim
  if (!cpm_common_interfaces__msg__LinkSensorCalLim__are_equal(
      &(lhs->link_sensor_cal_lim), &(rhs->link_sensor_cal_lim)))
  {
    return false;
  }
  // loader_bkt_pload_tgt_wt
  if (lhs->loader_bkt_pload_tgt_wt != rhs->loader_bkt_pload_tgt_wt) {
    return false;
  }
  // loader_bkt_pload_tgt_wt_per
  if (lhs->loader_bkt_pload_tgt_wt_per != rhs->loader_bkt_pload_tgt_wt_per) {
    return false;
  }
  // pload_sys_zero_req_stat
  if (lhs->pload_sys_zero_req_stat != rhs->pload_sys_zero_req_stat) {
    return false;
  }
  // pload_sys_cal_wt_entry_req_stat
  if (lhs->pload_sys_cal_wt_entry_req_stat != rhs->pload_sys_cal_wt_entry_req_stat) {
    return false;
  }
  // last_pload_wt
  if (lhs->last_pload_wt != rhs->last_pload_wt) {
    return false;
  }
  // prod_measure_weigh_status
  if (lhs->prod_measure_weigh_status != rhs->prod_measure_weigh_status) {
    return false;
  }
  // bkt_payload_data
  if (lhs->bkt_payload_data != rhs->bkt_payload_data) {
    return false;
  }
  // qr_hyd_oil_temp_min_c
  if (lhs->qr_hyd_oil_temp_min_c != rhs->qr_hyd_oil_temp_min_c) {
    return false;
  }
  // qr_lift_cyl_vel_min_mm_sec
  if (lhs->qr_lift_cyl_vel_min_mm_sec != rhs->qr_lift_cyl_vel_min_mm_sec) {
    return false;
  }
  // qr_lift_cyl_vel_max_mm_sec
  if (lhs->qr_lift_cyl_vel_max_mm_sec != rhs->qr_lift_cyl_vel_max_mm_sec) {
    return false;
  }
  // machine_rear_lateral_acceleration
  if (lhs->machine_rear_lateral_acceleration != rhs->machine_rear_lateral_acceleration) {
    return false;
  }
  // machine_rear_longitudinal_acceleration
  if (lhs->machine_rear_longitudinal_acceleration != rhs->machine_rear_longitudinal_acceleration) {
    return false;
  }
  // machine_rear_vertical_acceleration
  if (lhs->machine_rear_vertical_acceleration != rhs->machine_rear_vertical_acceleration) {
    return false;
  }
  // machine_pitch
  if (lhs->machine_pitch != rhs->machine_pitch) {
    return false;
  }
  // machine_slope
  if (lhs->machine_slope != rhs->machine_slope) {
    return false;
  }
  // machine_rear_roll
  if (lhs->machine_rear_roll != rhs->machine_rear_roll) {
    return false;
  }
  // machine_rear_side_slope
  if (lhs->machine_rear_side_slope != rhs->machine_rear_side_slope) {
    return false;
  }
  // machine_roll
  if (lhs->machine_roll != rhs->machine_roll) {
    return false;
  }
  // machine_side_slope
  if (lhs->machine_side_slope != rhs->machine_side_slope) {
    return false;
  }
  // tipoff_pitch_cal_offset
  if (lhs->tipoff_pitch_cal_offset != rhs->tipoff_pitch_cal_offset) {
    return false;
  }
  // hyd_oil_temp_enabled
  if (lhs->hyd_oil_temp_enabled != rhs->hyd_oil_temp_enabled) {
    return false;
  }
  // audible_weight_enabled
  if (lhs->audible_weight_enabled != rhs->audible_weight_enabled) {
    return false;
  }
  // audible_weight_command
  if (lhs->audible_weight_command != rhs->audible_weight_command) {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__WeighPidData__copy(
  const cpm_common_interfaces__msg__WeighPidData * input,
  cpm_common_interfaces__msg__WeighPidData * output)
{
  if (!input || !output) {
    return false;
  }
  // pload_sys_zero_stat
  output->pload_sys_zero_stat = input->pload_sys_zero_stat;
  // ldr_payload_stat
  output->ldr_payload_stat = input->ldr_payload_stat;
  // overload_warning_enabled
  output->overload_warning_enabled = input->overload_warning_enabled;
  // prod_measure_sensor_status
  if (!cpm_common_interfaces__msg__ProdMeasureSensorStatus__copy(
      &(input->prod_measure_sensor_status), &(output->prod_measure_sensor_status)))
  {
    return false;
  }
  // link_sensor_cal_lim
  if (!cpm_common_interfaces__msg__LinkSensorCalLim__copy(
      &(input->link_sensor_cal_lim), &(output->link_sensor_cal_lim)))
  {
    return false;
  }
  // loader_bkt_pload_tgt_wt
  output->loader_bkt_pload_tgt_wt = input->loader_bkt_pload_tgt_wt;
  // loader_bkt_pload_tgt_wt_per
  output->loader_bkt_pload_tgt_wt_per = input->loader_bkt_pload_tgt_wt_per;
  // pload_sys_zero_req_stat
  output->pload_sys_zero_req_stat = input->pload_sys_zero_req_stat;
  // pload_sys_cal_wt_entry_req_stat
  output->pload_sys_cal_wt_entry_req_stat = input->pload_sys_cal_wt_entry_req_stat;
  // last_pload_wt
  output->last_pload_wt = input->last_pload_wt;
  // prod_measure_weigh_status
  output->prod_measure_weigh_status = input->prod_measure_weigh_status;
  // bkt_payload_data
  output->bkt_payload_data = input->bkt_payload_data;
  // qr_hyd_oil_temp_min_c
  output->qr_hyd_oil_temp_min_c = input->qr_hyd_oil_temp_min_c;
  // qr_lift_cyl_vel_min_mm_sec
  output->qr_lift_cyl_vel_min_mm_sec = input->qr_lift_cyl_vel_min_mm_sec;
  // qr_lift_cyl_vel_max_mm_sec
  output->qr_lift_cyl_vel_max_mm_sec = input->qr_lift_cyl_vel_max_mm_sec;
  // machine_rear_lateral_acceleration
  output->machine_rear_lateral_acceleration = input->machine_rear_lateral_acceleration;
  // machine_rear_longitudinal_acceleration
  output->machine_rear_longitudinal_acceleration = input->machine_rear_longitudinal_acceleration;
  // machine_rear_vertical_acceleration
  output->machine_rear_vertical_acceleration = input->machine_rear_vertical_acceleration;
  // machine_pitch
  output->machine_pitch = input->machine_pitch;
  // machine_slope
  output->machine_slope = input->machine_slope;
  // machine_rear_roll
  output->machine_rear_roll = input->machine_rear_roll;
  // machine_rear_side_slope
  output->machine_rear_side_slope = input->machine_rear_side_slope;
  // machine_roll
  output->machine_roll = input->machine_roll;
  // machine_side_slope
  output->machine_side_slope = input->machine_side_slope;
  // tipoff_pitch_cal_offset
  output->tipoff_pitch_cal_offset = input->tipoff_pitch_cal_offset;
  // hyd_oil_temp_enabled
  output->hyd_oil_temp_enabled = input->hyd_oil_temp_enabled;
  // audible_weight_enabled
  output->audible_weight_enabled = input->audible_weight_enabled;
  // audible_weight_command
  output->audible_weight_command = input->audible_weight_command;
  return true;
}

cpm_common_interfaces__msg__WeighPidData *
cpm_common_interfaces__msg__WeighPidData__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__WeighPidData * msg = (cpm_common_interfaces__msg__WeighPidData *)allocator.allocate(sizeof(cpm_common_interfaces__msg__WeighPidData), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__WeighPidData));
  bool success = cpm_common_interfaces__msg__WeighPidData__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__WeighPidData__destroy(cpm_common_interfaces__msg__WeighPidData * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__WeighPidData__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__WeighPidData__Sequence__init(cpm_common_interfaces__msg__WeighPidData__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__WeighPidData * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__WeighPidData)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__WeighPidData *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__WeighPidData), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__WeighPidData__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__WeighPidData__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__WeighPidData__Sequence__fini(cpm_common_interfaces__msg__WeighPidData__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__WeighPidData__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__WeighPidData__Sequence *
cpm_common_interfaces__msg__WeighPidData__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__WeighPidData__Sequence * array = (cpm_common_interfaces__msg__WeighPidData__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__WeighPidData__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__WeighPidData__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__WeighPidData__Sequence__destroy(cpm_common_interfaces__msg__WeighPidData__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__WeighPidData__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__WeighPidData__Sequence__are_equal(const cpm_common_interfaces__msg__WeighPidData__Sequence * lhs, const cpm_common_interfaces__msg__WeighPidData__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__WeighPidData__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__WeighPidData__Sequence__copy(
  const cpm_common_interfaces__msg__WeighPidData__Sequence * input,
  cpm_common_interfaces__msg__WeighPidData__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__WeighPidData)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__WeighPidData);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__WeighPidData * data =
      (cpm_common_interfaces__msg__WeighPidData *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__WeighPidData__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__WeighPidData__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__WeighPidData__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
