// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/ProdMeasureSensorStatus.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/prod_measure_sensor_status__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__ProdMeasureSensorStatus__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x17, 0x0f, 0x8e, 0xf4, 0x7b, 0x31, 0x23, 0xe9,
      0x23, 0xf7, 0x0d, 0x60, 0x1a, 0x49, 0xd4, 0xc5,
      0x9a, 0xc0, 0x11, 0x62, 0xad, 0x36, 0x69, 0x45,
      0xb4, 0xe6, 0xb6, 0x0b, 0x57, 0xa8, 0x35, 0x81,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__TYPE_NAME[] = "cpm_common_interfaces/msg/ProdMeasureSensorStatus";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__lift_link_dc[] = "lift_link_dc";
static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__lift_cyl_pos[] = "lift_cyl_pos";
static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__lift_cyl_he_pres[] = "lift_cyl_he_pres";
static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__lift_cyl_re_pres[] = "lift_cyl_re_pres";
static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__tilt_sensor_config[] = "tilt_sensor_config";
static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__tilt_cyl_he_pres[] = "tilt_cyl_he_pres";
static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__tilt_cyl_re_pres[] = "tilt_cyl_re_pres";
static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__tilt_link_dc[] = "tilt_link_dc";
static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__hyd_oil_temp[] = "hyd_oil_temp";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__lift_link_dc, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__lift_cyl_pos, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__lift_cyl_he_pres, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__lift_cyl_re_pres, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__tilt_sensor_config, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__tilt_cyl_he_pres, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__tilt_cyl_re_pres, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__tilt_link_dc, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELD_NAME__hyd_oil_temp, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__ProdMeasureSensorStatus__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__ProdMeasureSensorStatus__TYPE_NAME, 49, 49},
      {cpm_common_interfaces__msg__ProdMeasureSensorStatus__FIELDS, 9, 9},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# TiltSensorConfig_t\n"
  "################################################################################\n"
  "\n"
  "uint16 TILT_SENSOR_ROTARY_POSITION=451\n"
  "uint16 TILT_SENSOR_IN_CYLINDER_POSITION=452\n"
  "\n"
  "################################################################################\n"
  "# ProdMeasureSensorStatus_t\n"
  "################################################################################\n"
  "\n"
  "float32 lift_link_dc\n"
  "float32 lift_cyl_pos\n"
  "float32 lift_cyl_he_pres\n"
  "float32 lift_cyl_re_pres\n"
  "uint16 tilt_sensor_config\n"
  "float32 tilt_cyl_he_pres\n"
  "float32 tilt_cyl_re_pres\n"
  "float32 tilt_link_dc\n"
  "float32 hyd_oil_temp";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__ProdMeasureSensorStatus__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__TYPE_NAME, 49, 49},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 669, 669},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__ProdMeasureSensorStatus__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__ProdMeasureSensorStatus__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
