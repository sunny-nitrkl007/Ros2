// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/TipoffWeightAdjustData.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/tipoff_weight_adjust_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__TipoffWeightAdjustData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x21, 0x20, 0x4f, 0xa8, 0x1e, 0xe0, 0x2b, 0xe4,
      0x92, 0xad, 0xaf, 0x06, 0xcf, 0xb8, 0xb2, 0xde,
      0x37, 0xdb, 0x18, 0xa2, 0x44, 0x69, 0x56, 0xdd,
      0xc2, 0x28, 0x47, 0x16, 0xd9, 0xa6, 0x2d, 0x5d,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__TipoffWeightAdjustData__TYPE_NAME[] = "cpm_common_interfaces/msg/TipoffWeightAdjustData";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__tip_off_weight1[] = "tip_off_weight1";
static char cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__weigh_range_weight1[] = "weigh_range_weight1";
static char cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__tip_off_weight2[] = "tip_off_weight2";
static char cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__weigh_range_weight2[] = "weigh_range_weight2";
static char cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__new_data_flag[] = "new_data_flag";
static char cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__reset[] = "reset";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__tip_off_weight1, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__weigh_range_weight1, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__tip_off_weight2, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__weigh_range_weight2, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__new_data_flag, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELD_NAME__reset, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__TipoffWeightAdjustData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__TipoffWeightAdjustData__TYPE_NAME, 48, 48},
      {cpm_common_interfaces__msg__TipoffWeightAdjustData__FIELDS, 6, 6},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# AisJhm2TxChannelStorage::tipoff_weight_adjust_data_t\n"
  "################################################################################\n"
  "\n"
  "float32 tip_off_weight1\n"
  "float32 weigh_range_weight1\n"
  "float32 tip_off_weight2\n"
  "float32 weigh_range_weight2\n"
  "bool new_data_flag\n"
  "bool reset";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__TipoffWeightAdjustData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__TipoffWeightAdjustData__TYPE_NAME, 48, 48},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 352, 352},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__TipoffWeightAdjustData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__TipoffWeightAdjustData__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
