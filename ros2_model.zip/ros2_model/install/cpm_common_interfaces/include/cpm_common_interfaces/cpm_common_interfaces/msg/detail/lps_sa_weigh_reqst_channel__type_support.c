// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from cpm_common_interfaces:msg/LpsSaWeighReqstChannel.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "cpm_common_interfaces/msg/detail/lps_sa_weigh_reqst_channel__rosidl_typesupport_introspection_c.h"
#include "cpm_common_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_weigh_reqst_channel__functions.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_weigh_reqst_channel__struct.h"


// Include directives for member types
// Member `app_name`
// Member `arg_s`
#include "rosidl_runtime_c/string_functions.h"
// Member `command`
#include "cpm_common_interfaces/msg/weigh_reqst_channel_command.h"
// Member `command`
#include "cpm_common_interfaces/msg/detail/weigh_reqst_channel_command__rosidl_typesupport_introspection_c.h"
// Member `arg_map`
#include "cpm_common_interfaces/msg/float_pair.h"
// Member `arg_map`
#include "cpm_common_interfaces/msg/detail/float_pair__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel__init(message_memory);
}

void cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_fini_function(void * message_memory)
{
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel__fini(message_memory);
}

size_t cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__size_function__LpsSaWeighReqstChannel__arg_map(
  const void * untyped_member)
{
  const cpm_common_interfaces__msg__FloatPair__Sequence * member =
    (const cpm_common_interfaces__msg__FloatPair__Sequence *)(untyped_member);
  return member->size;
}

const void * cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__get_const_function__LpsSaWeighReqstChannel__arg_map(
  const void * untyped_member, size_t index)
{
  const cpm_common_interfaces__msg__FloatPair__Sequence * member =
    (const cpm_common_interfaces__msg__FloatPair__Sequence *)(untyped_member);
  return &member->data[index];
}

void * cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__get_function__LpsSaWeighReqstChannel__arg_map(
  void * untyped_member, size_t index)
{
  cpm_common_interfaces__msg__FloatPair__Sequence * member =
    (cpm_common_interfaces__msg__FloatPair__Sequence *)(untyped_member);
  return &member->data[index];
}

void cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__fetch_function__LpsSaWeighReqstChannel__arg_map(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const cpm_common_interfaces__msg__FloatPair * item =
    ((const cpm_common_interfaces__msg__FloatPair *)
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__get_const_function__LpsSaWeighReqstChannel__arg_map(untyped_member, index));
  cpm_common_interfaces__msg__FloatPair * value =
    (cpm_common_interfaces__msg__FloatPair *)(untyped_value);
  *value = *item;
}

void cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__assign_function__LpsSaWeighReqstChannel__arg_map(
  void * untyped_member, size_t index, const void * untyped_value)
{
  cpm_common_interfaces__msg__FloatPair * item =
    ((cpm_common_interfaces__msg__FloatPair *)
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__get_function__LpsSaWeighReqstChannel__arg_map(untyped_member, index));
  const cpm_common_interfaces__msg__FloatPair * value =
    (const cpm_common_interfaces__msg__FloatPair *)(untyped_value);
  *item = *value;
}

bool cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__resize_function__LpsSaWeighReqstChannel__arg_map(
  void * untyped_member, size_t size)
{
  cpm_common_interfaces__msg__FloatPair__Sequence * member =
    (cpm_common_interfaces__msg__FloatPair__Sequence *)(untyped_member);
  cpm_common_interfaces__msg__FloatPair__Sequence__fini(member);
  return cpm_common_interfaces__msg__FloatPair__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_message_member_array[9] = {
  {
    "app_name",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel, app_name),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "app_request_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel, app_request_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "command",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel, command),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "arg_b",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel, arg_b),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "arg_f1",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel, arg_f1),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "arg_f2",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel, arg_f2),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "arg_s",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel, arg_s),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "arg_u",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel, arg_u),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "arg_map",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel, arg_map),  // bytes offset in struct
    NULL,  // default value
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__size_function__LpsSaWeighReqstChannel__arg_map,  // size() function pointer
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__get_const_function__LpsSaWeighReqstChannel__arg_map,  // get_const(index) function pointer
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__get_function__LpsSaWeighReqstChannel__arg_map,  // get(index) function pointer
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__fetch_function__LpsSaWeighReqstChannel__arg_map,  // fetch(index, &value) function pointer
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__assign_function__LpsSaWeighReqstChannel__arg_map,  // assign(index, value) function pointer
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__resize_function__LpsSaWeighReqstChannel__arg_map  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_message_members = {
  "cpm_common_interfaces__msg",  // message namespace
  "LpsSaWeighReqstChannel",  // message name
  9,  // number of fields
  sizeof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel),
  false,  // has_any_key_member_
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_message_member_array,  // message members
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_init_function,  // function to initialize message memory (memory has to be allocated)
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_message_type_support_handle = {
  0,
  &cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_message_members,
  get_message_typesupport_handle_function,
  &cpm_common_interfaces__msg__LpsSaWeighReqstChannel__get_type_hash,
  &cpm_common_interfaces__msg__LpsSaWeighReqstChannel__get_type_description,
  &cpm_common_interfaces__msg__LpsSaWeighReqstChannel__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_cpm_common_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, LpsSaWeighReqstChannel)() {
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, WeighReqstChannelCommand)();
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_message_member_array[8].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, FloatPair)();
  if (!cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_message_type_support_handle.typesupport_identifier) {
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &cpm_common_interfaces__msg__LpsSaWeighReqstChannel__rosidl_typesupport_introspection_c__LpsSaWeighReqstChannel_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
