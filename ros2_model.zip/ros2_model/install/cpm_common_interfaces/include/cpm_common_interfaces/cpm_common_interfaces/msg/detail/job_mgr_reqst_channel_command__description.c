// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/JobMgrReqstChannelCommand.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/job_mgr_reqst_channel_command__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__JobMgrReqstChannelCommand__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x9e, 0x96, 0x7a, 0x71, 0xf4, 0xb1, 0x48, 0x16,
      0x2f, 0xd4, 0x53, 0xed, 0xbb, 0xa5, 0x52, 0x4b,
      0x42, 0xdc, 0x7b, 0xf6, 0x45, 0xf0, 0xc4, 0xaa,
      0x49, 0x5a, 0xd6, 0x02, 0x78, 0x9f, 0xb5, 0x6e,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__JobMgrReqstChannelCommand__TYPE_NAME[] = "cpm_common_interfaces/msg/JobMgrReqstChannelCommand";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__JobMgrReqstChannelCommand__FIELD_NAME__value[] = "value";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__JobMgrReqstChannelCommand__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__JobMgrReqstChannelCommand__FIELD_NAME__value, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__JobMgrReqstChannelCommand__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__JobMgrReqstChannelCommand__TYPE_NAME, 51, 51},
      {cpm_common_interfaces__msg__JobMgrReqstChannelCommand__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaJobMgrReqstChannelStorage::Command\n"
  "################################################################################\n"
  "\n"
  "uint8 NONE=0\n"
  "uint8 ZERO=1\n"
  "uint8 MINUS_ONE=2\n"
  "uint8 CLEAR=3\n"
  "uint8 STORE=4\n"
  "uint8 REWEIGH=5\n"
  "uint8 MANUAL_ADD=6\n"
  "uint8 STANDBY_ACTIVATE=7\n"
  "uint8 STANDBY_DEACTIVATE=8\n"
  "uint8 TIPOFF_MODE_TOGGLE=9\n"
  "uint8 MANUAL_TIPOFF_ACTIVATE=10\n"
  "uint8 MANUAL_TIPOFF_DEACTIVATE=11\n"
  "uint8 WRITE_TIPOFF_TRIGGER_TYPE=12\n"
  "uint8 WRITE_TIPOFF_MODE=13\n"
  "uint8 WRITE_HORN_ON_STORE_ENABLED=14\n"
  "uint8 WRITE_AUTO_STORE_PASS_COUNT=15\n"
  "uint8 WRITE_AUTO_TRUCK_ID_ENABLED=16\n"
  "uint8 WRITE_AUTO_MATERIAL_ID_ENABLED=17\n"
  "uint8 WRITE_MANUAL_ADD_ENABLED=18\n"
  "uint8 WRITE_MULTI_TASK_ENABLED=19\n"
  "uint8 WRITE_MULTI_TASK_COUNT=20\n"
  "uint8 WRITE_SPLIT_MODE_ENABLED=21\n"
  "uint8 SELECT_TASK=22\n"
  "uint8 SELECT_NEXT_TASK=23\n"
  "uint8 SELECT_PREVIOUS_TASK=24\n"
  "uint8 WRITE_TRUCK_LIST_ENABLED=25\n"
  "uint8 WRITE_MATERIAL_LIST_ENABLED=26\n"
  "uint8 WRITE_TAG1_ENABLED=27\n"
  "uint8 WRITE_TAG2_ENABLED=28\n"
  "uint8 WRITE_TAG3_ENABLED=29\n"
  "uint8 WRITE_TAG4_ENABLED=30\n"
  "uint8 WRITE_PAYLOAD_NEXT_SUBTOTAL=31\n"
  "uint8 WRITE_LFT_DISABLED=32\n"
  "uint8 WRITE_TARGET_TYPE=33\n"
  "uint8 WRITE_TOTAL_TARGET_WEIGHT=34\n"
  "uint8 SELECT_SUBTOTAL=35\n"
  "uint8 PAYLOAD_DETAILS_FILE_REQUEST=36\n"
  "uint8 WRITE_SUBTOTAL_INFO=37\n"
  "\n"
  "uint8 value";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__JobMgrReqstChannelCommand__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__JobMgrReqstChannelCommand__TYPE_NAME, 51, 51},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 1296, 1296},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__JobMgrReqstChannelCommand__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__JobMgrReqstChannelCommand__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
