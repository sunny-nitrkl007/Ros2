// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/TipOffState.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/tip_off_state__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__TipOffState__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x74, 0x21, 0xd3, 0xa1, 0x4f, 0xa2, 0x6c, 0x7b,
      0xb1, 0x47, 0x75, 0x95, 0x34, 0x40, 0x22, 0x07,
      0x5a, 0x8d, 0x56, 0x63, 0xf5, 0x18, 0xa4, 0xaf,
      0xb2, 0x76, 0x49, 0xa6, 0x1e, 0x69, 0x84, 0x82,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__TipOffState__TYPE_NAME[] = "cpm_common_interfaces/msg/TipOffState";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__TipOffState__FIELD_NAME__value[] = "value";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__TipOffState__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__TipOffState__FIELD_NAME__value, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__TipOffState__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__TipOffState__TYPE_NAME, 37, 37},
      {cpm_common_interfaces__msg__TipOffState__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaJobMgrTipOffState_t\n"
  "################################################################################\n"
  "\n"
  "uint8 PILE_ENABLE=0\n"
  "uint8 TRUCK_ENABLE=1\n"
  "uint8 UNAVAILABLE=2\n"
  "\n"
  "uint8 value";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__TipOffState__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__TipOffState__TYPE_NAME, 37, 37},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 264, 264},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__TipOffState__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__TipOffState__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
