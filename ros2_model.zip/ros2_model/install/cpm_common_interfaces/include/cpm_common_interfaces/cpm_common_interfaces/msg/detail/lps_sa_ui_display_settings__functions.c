// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/LpsSaUIDisplaySettings.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_settings__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__init(cpm_common_interfaces__msg__LpsSaUIDisplaySettings * msg)
{
  if (!msg) {
    return false;
  }
  // units
  // language
  // brightness
  // time_format
  // date_format
  // weight_units
  // weight_precision
  // service_mode_enable_code
  // keyboard_layout_setting
  return true;
}

void
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__fini(cpm_common_interfaces__msg__LpsSaUIDisplaySettings * msg)
{
  if (!msg) {
    return;
  }
  // units
  // language
  // brightness
  // time_format
  // date_format
  // weight_units
  // weight_precision
  // service_mode_enable_code
  // keyboard_layout_setting
}

bool
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__are_equal(const cpm_common_interfaces__msg__LpsSaUIDisplaySettings * lhs, const cpm_common_interfaces__msg__LpsSaUIDisplaySettings * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // units
  if (lhs->units != rhs->units) {
    return false;
  }
  // language
  if (lhs->language != rhs->language) {
    return false;
  }
  // brightness
  if (lhs->brightness != rhs->brightness) {
    return false;
  }
  // time_format
  if (lhs->time_format != rhs->time_format) {
    return false;
  }
  // date_format
  if (lhs->date_format != rhs->date_format) {
    return false;
  }
  // weight_units
  if (lhs->weight_units != rhs->weight_units) {
    return false;
  }
  // weight_precision
  if (lhs->weight_precision != rhs->weight_precision) {
    return false;
  }
  // service_mode_enable_code
  if (lhs->service_mode_enable_code != rhs->service_mode_enable_code) {
    return false;
  }
  // keyboard_layout_setting
  if (lhs->keyboard_layout_setting != rhs->keyboard_layout_setting) {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__copy(
  const cpm_common_interfaces__msg__LpsSaUIDisplaySettings * input,
  cpm_common_interfaces__msg__LpsSaUIDisplaySettings * output)
{
  if (!input || !output) {
    return false;
  }
  // units
  output->units = input->units;
  // language
  output->language = input->language;
  // brightness
  output->brightness = input->brightness;
  // time_format
  output->time_format = input->time_format;
  // date_format
  output->date_format = input->date_format;
  // weight_units
  output->weight_units = input->weight_units;
  // weight_precision
  output->weight_precision = input->weight_precision;
  // service_mode_enable_code
  output->service_mode_enable_code = input->service_mode_enable_code;
  // keyboard_layout_setting
  output->keyboard_layout_setting = input->keyboard_layout_setting;
  return true;
}

cpm_common_interfaces__msg__LpsSaUIDisplaySettings *
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaUIDisplaySettings * msg = (cpm_common_interfaces__msg__LpsSaUIDisplaySettings *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings));
  bool success = cpm_common_interfaces__msg__LpsSaUIDisplaySettings__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__destroy(cpm_common_interfaces__msg__LpsSaUIDisplaySettings * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__LpsSaUIDisplaySettings__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence__init(cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaUIDisplaySettings * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__LpsSaUIDisplaySettings *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__LpsSaUIDisplaySettings__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__LpsSaUIDisplaySettings__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence__fini(cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__LpsSaUIDisplaySettings__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence *
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence * array = (cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence__destroy(cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence__are_equal(const cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence * lhs, const cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaUIDisplaySettings__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence__copy(
  const cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence * input,
  cpm_common_interfaces__msg__LpsSaUIDisplaySettings__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__LpsSaUIDisplaySettings * data =
      (cpm_common_interfaces__msg__LpsSaUIDisplaySettings *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__LpsSaUIDisplaySettings__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__LpsSaUIDisplaySettings__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaUIDisplaySettings__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
