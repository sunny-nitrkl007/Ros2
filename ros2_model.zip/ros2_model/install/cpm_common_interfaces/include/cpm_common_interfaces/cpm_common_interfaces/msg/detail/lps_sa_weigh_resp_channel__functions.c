// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/LpsSaWeighRespChannel.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/lps_sa_weigh_resp_channel__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `app_name`
// Member `arg1`
#include "rosidl_runtime_c/string_functions.h"
// Member `command`
#include "cpm_common_interfaces/msg/detail/weigh_reqst_channel_command__functions.h"

bool
cpm_common_interfaces__msg__LpsSaWeighRespChannel__init(cpm_common_interfaces__msg__LpsSaWeighRespChannel * msg)
{
  if (!msg) {
    return false;
  }
  // app_name
  if (!rosidl_runtime_c__String__init(&msg->app_name)) {
    cpm_common_interfaces__msg__LpsSaWeighRespChannel__fini(msg);
    return false;
  }
  // app_request_id
  // time_point_ns
  // command
  if (!cpm_common_interfaces__msg__WeighReqstChannelCommand__init(&msg->command)) {
    cpm_common_interfaces__msg__LpsSaWeighRespChannel__fini(msg);
    return false;
  }
  // success
  // arg1
  if (!rosidl_runtime_c__String__init(&msg->arg1)) {
    cpm_common_interfaces__msg__LpsSaWeighRespChannel__fini(msg);
    return false;
  }
  return true;
}

void
cpm_common_interfaces__msg__LpsSaWeighRespChannel__fini(cpm_common_interfaces__msg__LpsSaWeighRespChannel * msg)
{
  if (!msg) {
    return;
  }
  // app_name
  rosidl_runtime_c__String__fini(&msg->app_name);
  // app_request_id
  // time_point_ns
  // command
  cpm_common_interfaces__msg__WeighReqstChannelCommand__fini(&msg->command);
  // success
  // arg1
  rosidl_runtime_c__String__fini(&msg->arg1);
}

bool
cpm_common_interfaces__msg__LpsSaWeighRespChannel__are_equal(const cpm_common_interfaces__msg__LpsSaWeighRespChannel * lhs, const cpm_common_interfaces__msg__LpsSaWeighRespChannel * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // app_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->app_name), &(rhs->app_name)))
  {
    return false;
  }
  // app_request_id
  if (lhs->app_request_id != rhs->app_request_id) {
    return false;
  }
  // time_point_ns
  if (lhs->time_point_ns != rhs->time_point_ns) {
    return false;
  }
  // command
  if (!cpm_common_interfaces__msg__WeighReqstChannelCommand__are_equal(
      &(lhs->command), &(rhs->command)))
  {
    return false;
  }
  // success
  if (lhs->success != rhs->success) {
    return false;
  }
  // arg1
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->arg1), &(rhs->arg1)))
  {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaWeighRespChannel__copy(
  const cpm_common_interfaces__msg__LpsSaWeighRespChannel * input,
  cpm_common_interfaces__msg__LpsSaWeighRespChannel * output)
{
  if (!input || !output) {
    return false;
  }
  // app_name
  if (!rosidl_runtime_c__String__copy(
      &(input->app_name), &(output->app_name)))
  {
    return false;
  }
  // app_request_id
  output->app_request_id = input->app_request_id;
  // time_point_ns
  output->time_point_ns = input->time_point_ns;
  // command
  if (!cpm_common_interfaces__msg__WeighReqstChannelCommand__copy(
      &(input->command), &(output->command)))
  {
    return false;
  }
  // success
  output->success = input->success;
  // arg1
  if (!rosidl_runtime_c__String__copy(
      &(input->arg1), &(output->arg1)))
  {
    return false;
  }
  return true;
}

cpm_common_interfaces__msg__LpsSaWeighRespChannel *
cpm_common_interfaces__msg__LpsSaWeighRespChannel__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaWeighRespChannel * msg = (cpm_common_interfaces__msg__LpsSaWeighRespChannel *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaWeighRespChannel), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__LpsSaWeighRespChannel));
  bool success = cpm_common_interfaces__msg__LpsSaWeighRespChannel__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__LpsSaWeighRespChannel__destroy(cpm_common_interfaces__msg__LpsSaWeighRespChannel * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__LpsSaWeighRespChannel__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence__init(cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaWeighRespChannel * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaWeighRespChannel)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__LpsSaWeighRespChannel *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__LpsSaWeighRespChannel), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__LpsSaWeighRespChannel__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__LpsSaWeighRespChannel__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence__fini(cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__LpsSaWeighRespChannel__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence *
cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence * array = (cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence__destroy(cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence__are_equal(const cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence * lhs, const cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaWeighRespChannel__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence__copy(
  const cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence * input,
  cpm_common_interfaces__msg__LpsSaWeighRespChannel__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaWeighRespChannel)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__LpsSaWeighRespChannel);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__LpsSaWeighRespChannel * data =
      (cpm_common_interfaces__msg__LpsSaWeighRespChannel *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__LpsSaWeighRespChannel__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__LpsSaWeighRespChannel__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaWeighRespChannel__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
