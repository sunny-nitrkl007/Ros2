// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from cpm_common_interfaces:msg/LpsSaWeighReqstChannel.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_weigh_reqst_channel__functions.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_weigh_reqst_channel__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace cpm_common_interfaces
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void LpsSaWeighReqstChannel_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) cpm_common_interfaces::msg::LpsSaWeighReqstChannel(_init);
}

void LpsSaWeighReqstChannel_fini_function(void * message_memory)
{
  auto typed_message = static_cast<cpm_common_interfaces::msg::LpsSaWeighReqstChannel *>(message_memory);
  typed_message->~LpsSaWeighReqstChannel();
}

size_t size_function__LpsSaWeighReqstChannel__arg_map(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<cpm_common_interfaces::msg::FloatPair> *>(untyped_member);
  return member->size();
}

const void * get_const_function__LpsSaWeighReqstChannel__arg_map(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<cpm_common_interfaces::msg::FloatPair> *>(untyped_member);
  return &member[index];
}

void * get_function__LpsSaWeighReqstChannel__arg_map(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<cpm_common_interfaces::msg::FloatPair> *>(untyped_member);
  return &member[index];
}

void fetch_function__LpsSaWeighReqstChannel__arg_map(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const cpm_common_interfaces::msg::FloatPair *>(
    get_const_function__LpsSaWeighReqstChannel__arg_map(untyped_member, index));
  auto & value = *reinterpret_cast<cpm_common_interfaces::msg::FloatPair *>(untyped_value);
  value = item;
}

void assign_function__LpsSaWeighReqstChannel__arg_map(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<cpm_common_interfaces::msg::FloatPair *>(
    get_function__LpsSaWeighReqstChannel__arg_map(untyped_member, index));
  const auto & value = *reinterpret_cast<const cpm_common_interfaces::msg::FloatPair *>(untyped_value);
  item = value;
}

void resize_function__LpsSaWeighReqstChannel__arg_map(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<cpm_common_interfaces::msg::FloatPair> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember LpsSaWeighReqstChannel_message_member_array[9] = {
  {
    "app_name",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaWeighReqstChannel, app_name),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "app_request_id",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaWeighReqstChannel, app_request_id),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "command",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<cpm_common_interfaces::msg::WeighReqstChannelCommand>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaWeighReqstChannel, command),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "arg_b",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaWeighReqstChannel, arg_b),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "arg_f1",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaWeighReqstChannel, arg_f1),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "arg_f2",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaWeighReqstChannel, arg_f2),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "arg_s",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaWeighReqstChannel, arg_s),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "arg_u",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaWeighReqstChannel, arg_u),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "arg_map",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<cpm_common_interfaces::msg::FloatPair>(),  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::LpsSaWeighReqstChannel, arg_map),  // bytes offset in struct
    nullptr,  // default value
    size_function__LpsSaWeighReqstChannel__arg_map,  // size() function pointer
    get_const_function__LpsSaWeighReqstChannel__arg_map,  // get_const(index) function pointer
    get_function__LpsSaWeighReqstChannel__arg_map,  // get(index) function pointer
    fetch_function__LpsSaWeighReqstChannel__arg_map,  // fetch(index, &value) function pointer
    assign_function__LpsSaWeighReqstChannel__arg_map,  // assign(index, value) function pointer
    resize_function__LpsSaWeighReqstChannel__arg_map  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers LpsSaWeighReqstChannel_message_members = {
  "cpm_common_interfaces::msg",  // message namespace
  "LpsSaWeighReqstChannel",  // message name
  9,  // number of fields
  sizeof(cpm_common_interfaces::msg::LpsSaWeighReqstChannel),
  false,  // has_any_key_member_
  LpsSaWeighReqstChannel_message_member_array,  // message members
  LpsSaWeighReqstChannel_init_function,  // function to initialize message memory (memory has to be allocated)
  LpsSaWeighReqstChannel_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t LpsSaWeighReqstChannel_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &LpsSaWeighReqstChannel_message_members,
  get_message_typesupport_handle_function,
  &cpm_common_interfaces__msg__LpsSaWeighReqstChannel__get_type_hash,
  &cpm_common_interfaces__msg__LpsSaWeighReqstChannel__get_type_description,
  &cpm_common_interfaces__msg__LpsSaWeighReqstChannel__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace cpm_common_interfaces


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<cpm_common_interfaces::msg::LpsSaWeighReqstChannel>()
{
  return &::cpm_common_interfaces::msg::rosidl_typesupport_introspection_cpp::LpsSaWeighReqstChannel_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, cpm_common_interfaces, msg, LpsSaWeighReqstChannel)() {
  return &::cpm_common_interfaces::msg::rosidl_typesupport_introspection_cpp::LpsSaWeighReqstChannel_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
