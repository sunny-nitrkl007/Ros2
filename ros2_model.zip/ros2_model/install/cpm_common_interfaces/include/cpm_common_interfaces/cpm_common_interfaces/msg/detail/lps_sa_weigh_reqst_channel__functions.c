// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/LpsSaWeighReqstChannel.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/lps_sa_weigh_reqst_channel__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `app_name`
// Member `arg_s`
#include "rosidl_runtime_c/string_functions.h"
// Member `command`
#include "cpm_common_interfaces/msg/detail/weigh_reqst_channel_command__functions.h"
// Member `arg_map`
#include "cpm_common_interfaces/msg/detail/float_pair__functions.h"

bool
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__init(cpm_common_interfaces__msg__LpsSaWeighReqstChannel * msg)
{
  if (!msg) {
    return false;
  }
  // app_name
  if (!rosidl_runtime_c__String__init(&msg->app_name)) {
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__fini(msg);
    return false;
  }
  // app_request_id
  // command
  if (!cpm_common_interfaces__msg__WeighReqstChannelCommand__init(&msg->command)) {
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__fini(msg);
    return false;
  }
  // arg_b
  // arg_f1
  // arg_f2
  // arg_s
  if (!rosidl_runtime_c__String__init(&msg->arg_s)) {
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__fini(msg);
    return false;
  }
  // arg_u
  // arg_map
  if (!cpm_common_interfaces__msg__FloatPair__Sequence__init(&msg->arg_map, 0)) {
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__fini(msg);
    return false;
  }
  return true;
}

void
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__fini(cpm_common_interfaces__msg__LpsSaWeighReqstChannel * msg)
{
  if (!msg) {
    return;
  }
  // app_name
  rosidl_runtime_c__String__fini(&msg->app_name);
  // app_request_id
  // command
  cpm_common_interfaces__msg__WeighReqstChannelCommand__fini(&msg->command);
  // arg_b
  // arg_f1
  // arg_f2
  // arg_s
  rosidl_runtime_c__String__fini(&msg->arg_s);
  // arg_u
  // arg_map
  cpm_common_interfaces__msg__FloatPair__Sequence__fini(&msg->arg_map);
}

bool
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__are_equal(const cpm_common_interfaces__msg__LpsSaWeighReqstChannel * lhs, const cpm_common_interfaces__msg__LpsSaWeighReqstChannel * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // app_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->app_name), &(rhs->app_name)))
  {
    return false;
  }
  // app_request_id
  if (lhs->app_request_id != rhs->app_request_id) {
    return false;
  }
  // command
  if (!cpm_common_interfaces__msg__WeighReqstChannelCommand__are_equal(
      &(lhs->command), &(rhs->command)))
  {
    return false;
  }
  // arg_b
  if (lhs->arg_b != rhs->arg_b) {
    return false;
  }
  // arg_f1
  if (lhs->arg_f1 != rhs->arg_f1) {
    return false;
  }
  // arg_f2
  if (lhs->arg_f2 != rhs->arg_f2) {
    return false;
  }
  // arg_s
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->arg_s), &(rhs->arg_s)))
  {
    return false;
  }
  // arg_u
  if (lhs->arg_u != rhs->arg_u) {
    return false;
  }
  // arg_map
  if (!cpm_common_interfaces__msg__FloatPair__Sequence__are_equal(
      &(lhs->arg_map), &(rhs->arg_map)))
  {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__copy(
  const cpm_common_interfaces__msg__LpsSaWeighReqstChannel * input,
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel * output)
{
  if (!input || !output) {
    return false;
  }
  // app_name
  if (!rosidl_runtime_c__String__copy(
      &(input->app_name), &(output->app_name)))
  {
    return false;
  }
  // app_request_id
  output->app_request_id = input->app_request_id;
  // command
  if (!cpm_common_interfaces__msg__WeighReqstChannelCommand__copy(
      &(input->command), &(output->command)))
  {
    return false;
  }
  // arg_b
  output->arg_b = input->arg_b;
  // arg_f1
  output->arg_f1 = input->arg_f1;
  // arg_f2
  output->arg_f2 = input->arg_f2;
  // arg_s
  if (!rosidl_runtime_c__String__copy(
      &(input->arg_s), &(output->arg_s)))
  {
    return false;
  }
  // arg_u
  output->arg_u = input->arg_u;
  // arg_map
  if (!cpm_common_interfaces__msg__FloatPair__Sequence__copy(
      &(input->arg_map), &(output->arg_map)))
  {
    return false;
  }
  return true;
}

cpm_common_interfaces__msg__LpsSaWeighReqstChannel *
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel * msg = (cpm_common_interfaces__msg__LpsSaWeighReqstChannel *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel));
  bool success = cpm_common_interfaces__msg__LpsSaWeighReqstChannel__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__destroy(cpm_common_interfaces__msg__LpsSaWeighReqstChannel * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence__init(cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__LpsSaWeighReqstChannel *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__LpsSaWeighReqstChannel__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__LpsSaWeighReqstChannel__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence__fini(cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__LpsSaWeighReqstChannel__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence *
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence * array = (cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence__destroy(cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence__are_equal(const cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence * lhs, const cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaWeighReqstChannel__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence__copy(
  const cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence * input,
  cpm_common_interfaces__msg__LpsSaWeighReqstChannel__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__LpsSaWeighReqstChannel);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__LpsSaWeighReqstChannel * data =
      (cpm_common_interfaces__msg__LpsSaWeighReqstChannel *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__LpsSaWeighReqstChannel__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__LpsSaWeighReqstChannel__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaWeighReqstChannel__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
