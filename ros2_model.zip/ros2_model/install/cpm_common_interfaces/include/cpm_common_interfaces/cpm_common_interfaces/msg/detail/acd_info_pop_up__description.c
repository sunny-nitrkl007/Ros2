// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/AcdInfoPopUp.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/acd_info_pop_up__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__AcdInfoPopUp__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x7c, 0xc6, 0x45, 0xb6, 0x86, 0xa6, 0xe4, 0x18,
      0xf6, 0x12, 0x94, 0x44, 0x3b, 0xf4, 0xbb, 0xa1,
      0x12, 0xf8, 0xe7, 0xb5, 0xe4, 0xa5, 0xe4, 0xfe,
      0x81, 0x18, 0x27, 0x5f, 0xc7, 0x71, 0x77, 0x17,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__AcdInfoPopUp__TYPE_NAME[] = "cpm_common_interfaces/msg/AcdInfoPopUp";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__AcdInfoPopUp__FIELD_NAME__bits[] = "bits";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__AcdInfoPopUp__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__AcdInfoPopUp__FIELD_NAME__bits, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__AcdInfoPopUp__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__AcdInfoPopUp__TYPE_NAME, 38, 38},
      {cpm_common_interfaces__msg__AcdInfoPopUp__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# ACDInfoPopUp::type\n"
  "################################################################################\n"
  "\n"
  "uint8 PAYLOAD_TOO_HEAVY_TO_ZERO=0\n"
  "uint8 PAYLOAD_NOT_ZEROED=1\n"
  "uint8 PAYLOAD_CAL_ACCEPTED=2\n"
  "uint8 PAYLOAD_ZERO_ACCEPTED=3\n"
  "uint8 PAYLOAD_REWEIGH_LIFT_TOO_SLOW=4\n"
  "uint8 PAYLOAD_REWEIGH_STOPPED_IN_RANGE=5\n"
  "uint8 PAYLOAD_REWEIGH_NOT_RACKED=6\n"
  "uint8 PAYLOAD_REWEIGH_SPEED_CHANGING=7\n"
  "uint8 PAYLOAD_REWEIGH_INCONSISTENT=8\n"
  "uint8 PAYLOAD_REWEIGH_PRESSURE_CHANGING=9\n"
  "uint8 PAYLOAD_REWEIGH_EXCESSIVE_PITCH=10\n"
  "uint8 PAYLOAD_REWEIGH_WARMUP_LIFT=11\n"
  "uint8 PAYLOAD_RAISE_STALL=12\n"
  "uint8 PAYLOAD_LOWER_STALL=13\n"
  "uint8 PAYLOAD_CAL_WT_ENTRY_REQUIRED=14\n"
  "\n"
  "uint32 bits";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__AcdInfoPopUp__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__AcdInfoPopUp__TYPE_NAME, 38, 38},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 724, 724},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__AcdInfoPopUp__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__AcdInfoPopUp__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
