// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/SimpleCalDataT.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/simple_cal_data_t__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__SimpleCalDataT__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xee, 0x84, 0xb6, 0xfa, 0x87, 0xe3, 0x80, 0x8a,
      0xdd, 0x82, 0x6e, 0xca, 0x74, 0xbd, 0x78, 0xb0,
      0xfb, 0x9c, 0x75, 0x66, 0xa7, 0x98, 0xba, 0x6d,
      0xa1, 0x8b, 0xa6, 0xf6, 0x1f, 0xcf, 0x1a, 0x09,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__SimpleCalDataT__TYPE_NAME[] = "cpm_common_interfaces/msg/SimpleCalDataT";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__SimpleCalDataT__FIELD_NAME__time_stamp[] = "time_stamp";
static char cpm_common_interfaces__msg__SimpleCalDataT__FIELD_NAME__adjtruckweight[] = "adjtruckweight";
static char cpm_common_interfaces__msg__SimpleCalDataT__FIELD_NAME__zeroed_truck_wt[] = "zeroed_truck_wt";
static char cpm_common_interfaces__msg__SimpleCalDataT__FIELD_NAME__new_data_flag[] = "new_data_flag";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__SimpleCalDataT__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__SimpleCalDataT__FIELD_NAME__time_stamp, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__SimpleCalDataT__FIELD_NAME__adjtruckweight, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__SimpleCalDataT__FIELD_NAME__zeroed_truck_wt, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__SimpleCalDataT__FIELD_NAME__new_data_flag, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__SimpleCalDataT__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__SimpleCalDataT__TYPE_NAME, 40, 40},
      {cpm_common_interfaces__msg__SimpleCalDataT__FIELDS, 4, 4},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# AisJhm2TxChannelStorage::simplecal_data_t\n"
  "################################################################################\n"
  "\n"
  "string time_stamp\n"
  "float32 adjtruckweight\n"
  "float32 zeroed_truck_wt\n"
  "bool new_data_flag";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__SimpleCalDataT__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__SimpleCalDataT__TYPE_NAME, 40, 40},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 291, 291},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__SimpleCalDataT__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__SimpleCalDataT__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
