// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/LpsSaJobMgrSubtotalInfo.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_subtotal_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `subtotal_command`
// Member `material_name`
#include "rosidl_runtime_c/string_functions.h"

bool
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__init(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo * msg)
{
  if (!msg) {
    return false;
  }
  // subtotal_command
  if (!rosidl_runtime_c__String__init(&msg->subtotal_command)) {
    cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__fini(msg);
    return false;
  }
  // current_step_number
  // new_step_number
  // target_weight
  // target_proportion
  // target_passes
  // material_id
  // material_name
  if (!rosidl_runtime_c__String__init(&msg->material_name)) {
    cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__fini(msg);
    return false;
  }
  // material_density
  // icon_type
  return true;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__fini(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo * msg)
{
  if (!msg) {
    return;
  }
  // subtotal_command
  rosidl_runtime_c__String__fini(&msg->subtotal_command);
  // current_step_number
  // new_step_number
  // target_weight
  // target_proportion
  // target_passes
  // material_id
  // material_name
  rosidl_runtime_c__String__fini(&msg->material_name);
  // material_density
  // icon_type
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__are_equal(const cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo * lhs, const cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // subtotal_command
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->subtotal_command), &(rhs->subtotal_command)))
  {
    return false;
  }
  // current_step_number
  if (lhs->current_step_number != rhs->current_step_number) {
    return false;
  }
  // new_step_number
  if (lhs->new_step_number != rhs->new_step_number) {
    return false;
  }
  // target_weight
  if (lhs->target_weight != rhs->target_weight) {
    return false;
  }
  // target_proportion
  if (lhs->target_proportion != rhs->target_proportion) {
    return false;
  }
  // target_passes
  if (lhs->target_passes != rhs->target_passes) {
    return false;
  }
  // material_id
  if (lhs->material_id != rhs->material_id) {
    return false;
  }
  // material_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->material_name), &(rhs->material_name)))
  {
    return false;
  }
  // material_density
  if (lhs->material_density != rhs->material_density) {
    return false;
  }
  // icon_type
  if (lhs->icon_type != rhs->icon_type) {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__copy(
  const cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo * input,
  cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // subtotal_command
  if (!rosidl_runtime_c__String__copy(
      &(input->subtotal_command), &(output->subtotal_command)))
  {
    return false;
  }
  // current_step_number
  output->current_step_number = input->current_step_number;
  // new_step_number
  output->new_step_number = input->new_step_number;
  // target_weight
  output->target_weight = input->target_weight;
  // target_proportion
  output->target_proportion = input->target_proportion;
  // target_passes
  output->target_passes = input->target_passes;
  // material_id
  output->material_id = input->material_id;
  // material_name
  if (!rosidl_runtime_c__String__copy(
      &(input->material_name), &(output->material_name)))
  {
    return false;
  }
  // material_density
  output->material_density = input->material_density;
  // icon_type
  output->icon_type = input->icon_type;
  return true;
}

cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo *
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo * msg = (cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo));
  bool success = cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__destroy(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence__init(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence__fini(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence *
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence * array = (cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence__destroy(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence__are_equal(const cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence * lhs, const cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence__copy(
  const cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence * input,
  cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo * data =
      (cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
