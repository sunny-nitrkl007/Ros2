// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LpsSaJobMgrReqst.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LpsSaJobMgrReqst__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x41, 0xde, 0x95, 0x84, 0xb0, 0xbf, 0xb4, 0x07,
      0x84, 0xba, 0xb8, 0x56, 0x42, 0x93, 0x15, 0x93,
      0x8f, 0xc0, 0xbe, 0x1b, 0x46, 0xd1, 0xdb, 0x23,
      0x5a, 0x46, 0xfc, 0x88, 0x0d, 0x25, 0xf6, 0x8e,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__LpsSaJobMgrReqst__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaJobMgrReqst";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELD_NAME__command[] = "command";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELD_NAME__arg1[] = "arg1";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELD_NAME__arg2[] = "arg2";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELD_NAME__arg3[] = "arg3";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELD_NAME__arg4[] = "arg4";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELD_NAME__command, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELD_NAME__arg1, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELD_NAME__arg2, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELD_NAME__arg3, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELD_NAME__arg4, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LpsSaJobMgrReqst__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LpsSaJobMgrReqst__TYPE_NAME, 42, 42},
      {cpm_common_interfaces__msg__LpsSaJobMgrReqst__FIELDS, 5, 5},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaJobMgrReqstCommand\n"
  "################################################################################\n"
  "\n"
  "uint8 WRITE_MATERIAL_ID=0\n"
  "uint8 WRITE_MATERIAL_NAME=1\n"
  "uint8 WRITE_MATERIAL_DENSITY=2\n"
  "uint8 WRITE_TRUCK_ID=3\n"
  "uint8 WRITE_TRUCK_NAME=4\n"
  "uint8 WRITE_TRUCK_TARGET_WEIGHT=5\n"
  "uint8 WRITE_TAG1=6\n"
  "uint8 WRITE_TAG2=7\n"
  "uint8 WRITE_TAG3=8\n"
  "uint8 WRITE_TAG4=9\n"
  "uint8 NONE=10\n"
  "\n"
  "################################################################################\n"
  "# LpsSaJobMgrReqst\n"
  "################################################################################\n"
  "\n"
  "uint8 command\n"
  "string arg1\n"
  "float32 arg2\n"
  "uint32 arg3\n"
  "string arg4";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LpsSaJobMgrReqst__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqst__TYPE_NAME, 42, 42},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 692, 692},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LpsSaJobMgrReqst__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LpsSaJobMgrReqst__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
