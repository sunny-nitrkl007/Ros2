// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LiftPosition.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/lift_position__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LiftPosition__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xe9, 0x49, 0x0d, 0x24, 0x59, 0x9e, 0x81, 0xba,
      0x87, 0x7b, 0x14, 0xa9, 0x3c, 0x6e, 0xa3, 0x4d,
      0xa9, 0xb2, 0xe7, 0x63, 0x51, 0x0b, 0xdf, 0xff,
      0x68, 0x1e, 0x3b, 0xda, 0xde, 0xd6, 0xd7, 0x64,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__LiftPosition__TYPE_NAME[] = "cpm_common_interfaces/msg/LiftPosition";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__angle[] = "angle";
static char cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__percent_angle[] = "percent_angle";
static char cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__cylinder_length[] = "cylinder_length";
static char cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__percent_cylinder_length[] = "percent_cylinder_length";
static char cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__cylinder_extension[] = "cylinder_extension";
static char cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__status[] = "status";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LiftPosition__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__angle, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__percent_angle, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__cylinder_length, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__percent_cylinder_length, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__cylinder_extension, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LiftPosition__FIELD_NAME__status, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LiftPosition__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LiftPosition__TYPE_NAME, 38, 38},
      {cpm_common_interfaces__msg__LiftPosition__FIELDS, 6, 6},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaLiftPosition_t\n"
  "################################################################################\n"
  "\n"
  "float32 angle\n"
  "float32 percent_angle\n"
  "float32 cylinder_length\n"
  "float32 percent_cylinder_length\n"
  "float32 cylinder_extension\n"
  "int32 status";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LiftPosition__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LiftPosition__TYPE_NAME, 38, 38},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 317, 317},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LiftPosition__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LiftPosition__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
