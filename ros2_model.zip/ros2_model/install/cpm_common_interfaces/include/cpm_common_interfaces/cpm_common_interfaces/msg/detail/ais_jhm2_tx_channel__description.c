// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/AisJhm2TxChannel.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/ais_jhm2_tx_channel__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__AisJhm2TxChannel__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xf8, 0xa5, 0x34, 0xce, 0x8d, 0x80, 0x72, 0x4d,
      0xbe, 0x31, 0x13, 0x35, 0x64, 0x88, 0x52, 0x93,
      0x94, 0xb2, 0x21, 0x96, 0x94, 0x3a, 0x25, 0x70,
      0x8a, 0x2f, 0x48, 0xd1, 0x94, 0x10, 0xb2, 0x19,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "cpm_common_interfaces/msg/detail/tipoff_weight_adjust_data__functions.h"
#include "cpm_common_interfaces/msg/detail/simple_cal_data_t__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t cpm_common_interfaces__msg__SimpleCalDataT__EXPECTED_HASH = {1, {
    0xee, 0x84, 0xb6, 0xfa, 0x87, 0xe3, 0x80, 0x8a,
    0xdd, 0x82, 0x6e, 0xca, 0x74, 0xbd, 0x78, 0xb0,
    0xfb, 0x9c, 0x75, 0x66, 0xa7, 0x98, 0xba, 0x6d,
    0xa1, 0x8b, 0xa6, 0xf6, 0x1f, 0xcf, 0x1a, 0x09,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__TipoffWeightAdjustData__EXPECTED_HASH = {1, {
    0x21, 0x20, 0x4f, 0xa8, 0x1e, 0xe0, 0x2b, 0xe4,
    0x92, 0xad, 0xaf, 0x06, 0xcf, 0xb8, 0xb2, 0xde,
    0x37, 0xdb, 0x18, 0xa2, 0x44, 0x69, 0x56, 0xdd,
    0xc2, 0x28, 0x47, 0x16, 0xd9, 0xa6, 0x2d, 0x5d,
  }};
#endif

static char cpm_common_interfaces__msg__AisJhm2TxChannel__TYPE_NAME[] = "cpm_common_interfaces/msg/AisJhm2TxChannel";
static char cpm_common_interfaces__msg__SimpleCalDataT__TYPE_NAME[] = "cpm_common_interfaces/msg/SimpleCalDataT";
static char cpm_common_interfaces__msg__TipoffWeightAdjustData__TYPE_NAME[] = "cpm_common_interfaces/msg/TipoffWeightAdjustData";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__AisJhm2TxChannel__FIELD_NAME__simplecal_data[] = "simplecal_data";
static char cpm_common_interfaces__msg__AisJhm2TxChannel__FIELD_NAME__tipoff_weight_adjust_data[] = "tipoff_weight_adjust_data";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__AisJhm2TxChannel__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__AisJhm2TxChannel__FIELD_NAME__simplecal_data, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__SimpleCalDataT__TYPE_NAME, 40, 40},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__AisJhm2TxChannel__FIELD_NAME__tipoff_weight_adjust_data, 25, 25},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__TipoffWeightAdjustData__TYPE_NAME, 48, 48},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription cpm_common_interfaces__msg__AisJhm2TxChannel__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {cpm_common_interfaces__msg__SimpleCalDataT__TYPE_NAME, 40, 40},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TipoffWeightAdjustData__TYPE_NAME, 48, 48},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__AisJhm2TxChannel__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__AisJhm2TxChannel__TYPE_NAME, 42, 42},
      {cpm_common_interfaces__msg__AisJhm2TxChannel__FIELDS, 2, 2},
    },
    {cpm_common_interfaces__msg__AisJhm2TxChannel__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&cpm_common_interfaces__msg__SimpleCalDataT__EXPECTED_HASH, cpm_common_interfaces__msg__SimpleCalDataT__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = cpm_common_interfaces__msg__SimpleCalDataT__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__TipoffWeightAdjustData__EXPECTED_HASH, cpm_common_interfaces__msg__TipoffWeightAdjustData__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = cpm_common_interfaces__msg__TipoffWeightAdjustData__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# AisJhm2TxChannelStorage\n"
  "################################################################################\n"
  "\n"
  "SimpleCalDataT simplecal_data\n"
  "TipoffWeightAdjustData tipoff_weight_adjust_data";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__AisJhm2TxChannel__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__AisJhm2TxChannel__TYPE_NAME, 42, 42},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 268, 268},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__AisJhm2TxChannel__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__AisJhm2TxChannel__get_individual_type_description_source(NULL),
    sources[1] = *cpm_common_interfaces__msg__SimpleCalDataT__get_individual_type_description_source(NULL);
    sources[2] = *cpm_common_interfaces__msg__TipoffWeightAdjustData__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
