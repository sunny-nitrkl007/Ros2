// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/AcdEventPopUp.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/acd_event_pop_up__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__AcdEventPopUp__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x8a, 0xbf, 0x3b, 0x96, 0x66, 0x8e, 0xdd, 0x3c,
      0xba, 0x9b, 0x0c, 0x08, 0xda, 0xd6, 0xdb, 0x89,
      0xd2, 0xad, 0x85, 0xdb, 0x77, 0x9e, 0x84, 0x98,
      0xa7, 0x69, 0x2f, 0x81, 0xd5, 0xfa, 0xd9, 0x1d,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__AcdEventPopUp__TYPE_NAME[] = "cpm_common_interfaces/msg/AcdEventPopUp";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__AcdEventPopUp__FIELD_NAME__bits[] = "bits";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__AcdEventPopUp__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__AcdEventPopUp__FIELD_NAME__bits, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__AcdEventPopUp__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__AcdEventPopUp__TYPE_NAME, 39, 39},
      {cpm_common_interfaces__msg__AcdEventPopUp__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# ACDEventPopUp::type\n"
  "################################################################################\n"
  "\n"
  "uint8 BATTERY_HIGH=28\n"
  "uint8 BATTERY_LOW=29\n"
  "uint8 PAYLOAD_LFT_NOT_SEALED=30\n"
  "uint8 OVERLOAD_LIMIT_EXCEEDED=31\n"
  "\n"
  "uint32 bits";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__AcdEventPopUp__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__AcdEventPopUp__TYPE_NAME, 39, 39},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 306, 306},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__AcdEventPopUp__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__AcdEventPopUp__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
