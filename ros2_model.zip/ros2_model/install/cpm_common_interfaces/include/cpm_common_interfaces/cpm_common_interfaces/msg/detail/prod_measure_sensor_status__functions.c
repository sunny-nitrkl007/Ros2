// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/ProdMeasureSensorStatus.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/prod_measure_sensor_status__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
cpm_common_interfaces__msg__ProdMeasureSensorStatus__init(cpm_common_interfaces__msg__ProdMeasureSensorStatus * msg)
{
  if (!msg) {
    return false;
  }
  // lift_link_dc
  // lift_cyl_pos
  // lift_cyl_he_pres
  // lift_cyl_re_pres
  // tilt_sensor_config
  // tilt_cyl_he_pres
  // tilt_cyl_re_pres
  // tilt_link_dc
  // hyd_oil_temp
  return true;
}

void
cpm_common_interfaces__msg__ProdMeasureSensorStatus__fini(cpm_common_interfaces__msg__ProdMeasureSensorStatus * msg)
{
  if (!msg) {
    return;
  }
  // lift_link_dc
  // lift_cyl_pos
  // lift_cyl_he_pres
  // lift_cyl_re_pres
  // tilt_sensor_config
  // tilt_cyl_he_pres
  // tilt_cyl_re_pres
  // tilt_link_dc
  // hyd_oil_temp
}

bool
cpm_common_interfaces__msg__ProdMeasureSensorStatus__are_equal(const cpm_common_interfaces__msg__ProdMeasureSensorStatus * lhs, const cpm_common_interfaces__msg__ProdMeasureSensorStatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // lift_link_dc
  if (lhs->lift_link_dc != rhs->lift_link_dc) {
    return false;
  }
  // lift_cyl_pos
  if (lhs->lift_cyl_pos != rhs->lift_cyl_pos) {
    return false;
  }
  // lift_cyl_he_pres
  if (lhs->lift_cyl_he_pres != rhs->lift_cyl_he_pres) {
    return false;
  }
  // lift_cyl_re_pres
  if (lhs->lift_cyl_re_pres != rhs->lift_cyl_re_pres) {
    return false;
  }
  // tilt_sensor_config
  if (lhs->tilt_sensor_config != rhs->tilt_sensor_config) {
    return false;
  }
  // tilt_cyl_he_pres
  if (lhs->tilt_cyl_he_pres != rhs->tilt_cyl_he_pres) {
    return false;
  }
  // tilt_cyl_re_pres
  if (lhs->tilt_cyl_re_pres != rhs->tilt_cyl_re_pres) {
    return false;
  }
  // tilt_link_dc
  if (lhs->tilt_link_dc != rhs->tilt_link_dc) {
    return false;
  }
  // hyd_oil_temp
  if (lhs->hyd_oil_temp != rhs->hyd_oil_temp) {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__ProdMeasureSensorStatus__copy(
  const cpm_common_interfaces__msg__ProdMeasureSensorStatus * input,
  cpm_common_interfaces__msg__ProdMeasureSensorStatus * output)
{
  if (!input || !output) {
    return false;
  }
  // lift_link_dc
  output->lift_link_dc = input->lift_link_dc;
  // lift_cyl_pos
  output->lift_cyl_pos = input->lift_cyl_pos;
  // lift_cyl_he_pres
  output->lift_cyl_he_pres = input->lift_cyl_he_pres;
  // lift_cyl_re_pres
  output->lift_cyl_re_pres = input->lift_cyl_re_pres;
  // tilt_sensor_config
  output->tilt_sensor_config = input->tilt_sensor_config;
  // tilt_cyl_he_pres
  output->tilt_cyl_he_pres = input->tilt_cyl_he_pres;
  // tilt_cyl_re_pres
  output->tilt_cyl_re_pres = input->tilt_cyl_re_pres;
  // tilt_link_dc
  output->tilt_link_dc = input->tilt_link_dc;
  // hyd_oil_temp
  output->hyd_oil_temp = input->hyd_oil_temp;
  return true;
}

cpm_common_interfaces__msg__ProdMeasureSensorStatus *
cpm_common_interfaces__msg__ProdMeasureSensorStatus__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__ProdMeasureSensorStatus * msg = (cpm_common_interfaces__msg__ProdMeasureSensorStatus *)allocator.allocate(sizeof(cpm_common_interfaces__msg__ProdMeasureSensorStatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__ProdMeasureSensorStatus));
  bool success = cpm_common_interfaces__msg__ProdMeasureSensorStatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__ProdMeasureSensorStatus__destroy(cpm_common_interfaces__msg__ProdMeasureSensorStatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__ProdMeasureSensorStatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence__init(cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__ProdMeasureSensorStatus * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__ProdMeasureSensorStatus)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__ProdMeasureSensorStatus *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__ProdMeasureSensorStatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__ProdMeasureSensorStatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__ProdMeasureSensorStatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence__fini(cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__ProdMeasureSensorStatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence *
cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence * array = (cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence__destroy(cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence__are_equal(const cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence * lhs, const cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__ProdMeasureSensorStatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence__copy(
  const cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence * input,
  cpm_common_interfaces__msg__ProdMeasureSensorStatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__ProdMeasureSensorStatus)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__ProdMeasureSensorStatus);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__ProdMeasureSensorStatus * data =
      (cpm_common_interfaces__msg__ProdMeasureSensorStatus *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__ProdMeasureSensorStatus__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__ProdMeasureSensorStatus__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__ProdMeasureSensorStatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
