// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LpsSaWeighReqstChannel.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/lps_sa_weigh_reqst_channel__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x8b, 0x3a, 0x1d, 0x27, 0xa9, 0x7b, 0x42, 0x4b,
      0x65, 0x03, 0x6c, 0x57, 0x2a, 0x07, 0x7a, 0x50,
      0x0e, 0x7b, 0xab, 0x3e, 0xc9, 0x38, 0x6d, 0xbb,
      0x49, 0x95, 0x49, 0xd4, 0x5b, 0xf5, 0x3a, 0x21,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "cpm_common_interfaces/msg/detail/float_pair__functions.h"
#include "cpm_common_interfaces/msg/detail/weigh_reqst_channel_command__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t cpm_common_interfaces__msg__FloatPair__EXPECTED_HASH = {1, {
    0x10, 0x2b, 0x0f, 0xaa, 0x7a, 0x2c, 0x7d, 0x97,
    0x72, 0x20, 0xce, 0x5d, 0xd5, 0x7e, 0x07, 0xc2,
    0x11, 0x5d, 0x77, 0x15, 0x44, 0x91, 0x38, 0xa0,
    0xe0, 0x13, 0x88, 0x61, 0x7a, 0x93, 0x1b, 0x5b,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__WeighReqstChannelCommand__EXPECTED_HASH = {1, {
    0x92, 0x8c, 0xec, 0x7a, 0xdf, 0x79, 0xc2, 0x0d,
    0x7c, 0xb7, 0x80, 0x12, 0x0d, 0x2c, 0x24, 0xaf,
    0xa1, 0x94, 0x47, 0xa2, 0xfc, 0x11, 0xbd, 0x39,
    0x27, 0x8b, 0x8b, 0x64, 0x6a, 0x02, 0x83, 0x17,
  }};
#endif

static char cpm_common_interfaces__msg__LpsSaWeighReqstChannel__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaWeighReqstChannel";
static char cpm_common_interfaces__msg__FloatPair__TYPE_NAME[] = "cpm_common_interfaces/msg/FloatPair";
static char cpm_common_interfaces__msg__WeighReqstChannelCommand__TYPE_NAME[] = "cpm_common_interfaces/msg/WeighReqstChannelCommand";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__app_name[] = "app_name";
static char cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__app_request_id[] = "app_request_id";
static char cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__command[] = "command";
static char cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_b[] = "arg_b";
static char cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_f1[] = "arg_f1";
static char cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_f2[] = "arg_f2";
static char cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_s[] = "arg_s";
static char cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_u[] = "arg_u";
static char cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_map[] = "arg_map";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__app_name, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__app_request_id, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__command, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__WeighReqstChannelCommand__TYPE_NAME, 50, 50},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_b, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_f1, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_f2, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_s, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_u, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELD_NAME__arg_map, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {cpm_common_interfaces__msg__FloatPair__TYPE_NAME, 35, 35},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription cpm_common_interfaces__msg__LpsSaWeighReqstChannel__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {cpm_common_interfaces__msg__FloatPair__TYPE_NAME, 35, 35},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighReqstChannelCommand__TYPE_NAME, 50, 50},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__TYPE_NAME, 48, 48},
      {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__FIELDS, 9, 9},
    },
    {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&cpm_common_interfaces__msg__FloatPair__EXPECTED_HASH, cpm_common_interfaces__msg__FloatPair__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = cpm_common_interfaces__msg__FloatPair__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__WeighReqstChannelCommand__EXPECTED_HASH, cpm_common_interfaces__msg__WeighReqstChannelCommand__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = cpm_common_interfaces__msg__WeighReqstChannelCommand__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaWeighReqstChannelStorage\n"
  "################################################################################\n"
  "\n"
  "string app_name\n"
  "uint32 app_request_id\n"
  "\n"
  "WeighReqstChannelCommand command\n"
  "\n"
  "bool arg_b\n"
  "float32 arg_f1\n"
  "float32 arg_f2\n"
  "string arg_s\n"
  "uint32 arg_u\n"
  "FloatPair[] arg_map";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LpsSaWeighReqstChannel__TYPE_NAME, 48, 48},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 355, 355},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LpsSaWeighReqstChannel__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LpsSaWeighReqstChannel__get_individual_type_description_source(NULL),
    sources[1] = *cpm_common_interfaces__msg__FloatPair__get_individual_type_description_source(NULL);
    sources[2] = *cpm_common_interfaces__msg__WeighReqstChannelCommand__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
