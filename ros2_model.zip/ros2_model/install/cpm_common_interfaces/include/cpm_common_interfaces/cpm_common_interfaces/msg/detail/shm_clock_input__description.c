// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/ShmClockInput.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/shm_clock_input__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__ShmClockInput__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xf2, 0x75, 0x43, 0x43, 0xab, 0x7a, 0x46, 0x09,
      0x73, 0x7c, 0x67, 0x9f, 0x4b, 0x0d, 0x2e, 0x8e,
      0xb7, 0x63, 0xec, 0xbd, 0x24, 0xb8, 0x1b, 0x8d,
      0x40, 0xcb, 0x80, 0xb9, 0xaf, 0x68, 0xdc, 0xc7,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__ShmClockInput__TYPE_NAME[] = "cpm_common_interfaces/msg/ShmClockInput";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__ShmClockInput__FIELD_NAME__shm_sec[] = "shm_sec";
static char cpm_common_interfaces__msg__ShmClockInput__FIELD_NAME__utc_sec_us[] = "utc_sec_us";
static char cpm_common_interfaces__msg__ShmClockInput__FIELD_NAME__utc_offset_min[] = "utc_offset_min";
static char cpm_common_interfaces__msg__ShmClockInput__FIELD_NAME__tzone_info[] = "tzone_info";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__ShmClockInput__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__ShmClockInput__FIELD_NAME__shm_sec, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ShmClockInput__FIELD_NAME__utc_sec_us, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT64,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ShmClockInput__FIELD_NAME__utc_offset_min, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ShmClockInput__FIELD_NAME__tzone_info, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8_ARRAY,
      20,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__ShmClockInput__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__ShmClockInput__TYPE_NAME, 39, 39},
      {cpm_common_interfaces__msg__ShmClockInput__FIELDS, 4, 4},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# ShmClockStorage\n"
  "################################################################################\n"
  "\n"
  "uint32 shm_sec\n"
  "int64 utc_sec_us\n"
  "int32 utc_offset_min\n"
  "uint8[20] tzone_info";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__ShmClockInput__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__ShmClockInput__TYPE_NAME, 39, 39},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 255, 255},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__ShmClockInput__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__ShmClockInput__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
