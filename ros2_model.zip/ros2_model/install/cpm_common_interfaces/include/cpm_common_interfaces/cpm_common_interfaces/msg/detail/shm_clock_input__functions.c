// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/ShmClockInput.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/shm_clock_input__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
cpm_common_interfaces__msg__ShmClockInput__init(cpm_common_interfaces__msg__ShmClockInput * msg)
{
  if (!msg) {
    return false;
  }
  // shm_sec
  // utc_sec_us
  // utc_offset_min
  // tzone_info
  return true;
}

void
cpm_common_interfaces__msg__ShmClockInput__fini(cpm_common_interfaces__msg__ShmClockInput * msg)
{
  if (!msg) {
    return;
  }
  // shm_sec
  // utc_sec_us
  // utc_offset_min
  // tzone_info
}

bool
cpm_common_interfaces__msg__ShmClockInput__are_equal(const cpm_common_interfaces__msg__ShmClockInput * lhs, const cpm_common_interfaces__msg__ShmClockInput * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // shm_sec
  if (lhs->shm_sec != rhs->shm_sec) {
    return false;
  }
  // utc_sec_us
  if (lhs->utc_sec_us != rhs->utc_sec_us) {
    return false;
  }
  // utc_offset_min
  if (lhs->utc_offset_min != rhs->utc_offset_min) {
    return false;
  }
  // tzone_info
  for (size_t i = 0; i < 20; ++i) {
    if (lhs->tzone_info[i] != rhs->tzone_info[i]) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__ShmClockInput__copy(
  const cpm_common_interfaces__msg__ShmClockInput * input,
  cpm_common_interfaces__msg__ShmClockInput * output)
{
  if (!input || !output) {
    return false;
  }
  // shm_sec
  output->shm_sec = input->shm_sec;
  // utc_sec_us
  output->utc_sec_us = input->utc_sec_us;
  // utc_offset_min
  output->utc_offset_min = input->utc_offset_min;
  // tzone_info
  for (size_t i = 0; i < 20; ++i) {
    output->tzone_info[i] = input->tzone_info[i];
  }
  return true;
}

cpm_common_interfaces__msg__ShmClockInput *
cpm_common_interfaces__msg__ShmClockInput__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__ShmClockInput * msg = (cpm_common_interfaces__msg__ShmClockInput *)allocator.allocate(sizeof(cpm_common_interfaces__msg__ShmClockInput), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__ShmClockInput));
  bool success = cpm_common_interfaces__msg__ShmClockInput__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__ShmClockInput__destroy(cpm_common_interfaces__msg__ShmClockInput * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__ShmClockInput__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__ShmClockInput__Sequence__init(cpm_common_interfaces__msg__ShmClockInput__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__ShmClockInput * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__ShmClockInput)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__ShmClockInput *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__ShmClockInput), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__ShmClockInput__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__ShmClockInput__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__ShmClockInput__Sequence__fini(cpm_common_interfaces__msg__ShmClockInput__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__ShmClockInput__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__ShmClockInput__Sequence *
cpm_common_interfaces__msg__ShmClockInput__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__ShmClockInput__Sequence * array = (cpm_common_interfaces__msg__ShmClockInput__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__ShmClockInput__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__ShmClockInput__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__ShmClockInput__Sequence__destroy(cpm_common_interfaces__msg__ShmClockInput__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__ShmClockInput__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__ShmClockInput__Sequence__are_equal(const cpm_common_interfaces__msg__ShmClockInput__Sequence * lhs, const cpm_common_interfaces__msg__ShmClockInput__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__ShmClockInput__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__ShmClockInput__Sequence__copy(
  const cpm_common_interfaces__msg__ShmClockInput__Sequence * input,
  cpm_common_interfaces__msg__ShmClockInput__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__ShmClockInput)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__ShmClockInput);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__ShmClockInput * data =
      (cpm_common_interfaces__msg__ShmClockInput *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__ShmClockInput__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__ShmClockInput__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__ShmClockInput__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
