// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/WeighRange.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/weigh_range__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__WeighRange__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x8c, 0x1e, 0xa7, 0x04, 0xfc, 0x6d, 0xa9, 0x63,
      0xac, 0x3a, 0x04, 0xba, 0xd8, 0x06, 0xf4, 0x09,
      0x47, 0xc0, 0x50, 0xb0, 0x27, 0x41, 0xcc, 0x7d,
      0x3c, 0x13, 0x36, 0x25, 0x34, 0xa0, 0xb7, 0x9e,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__WeighRange__TYPE_NAME[] = "cpm_common_interfaces/msg/WeighRange";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__WeighRange__FIELD_NAME__weigh_range_bottom[] = "weigh_range_bottom";
static char cpm_common_interfaces__msg__WeighRange__FIELD_NAME__weigh_range_size[] = "weigh_range_size";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__WeighRange__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__WeighRange__FIELD_NAME__weigh_range_bottom, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighRange__FIELD_NAME__weigh_range_size, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__WeighRange__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__WeighRange__TYPE_NAME, 36, 36},
      {cpm_common_interfaces__msg__WeighRange__FIELDS, 2, 2},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaWeighRange_t\n"
  "################################################################################\n"
  "\n"
  "float32 weigh_range_bottom\n"
  "float32 weigh_range_size";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__WeighRange__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__WeighRange__TYPE_NAME, 36, 36},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 235, 235},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__WeighRange__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__WeighRange__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
