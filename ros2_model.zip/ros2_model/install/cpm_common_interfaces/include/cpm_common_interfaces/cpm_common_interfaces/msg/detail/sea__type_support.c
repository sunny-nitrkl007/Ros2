// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from cpm_common_interfaces:msg/SEA.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "cpm_common_interfaces/msg/detail/sea__rosidl_typesupport_introspection_c.h"
#include "cpm_common_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "cpm_common_interfaces/msg/detail/sea__functions.h"
#include "cpm_common_interfaces/msg/detail/sea__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  cpm_common_interfaces__msg__SEA__init(message_memory);
}

void cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_fini_function(void * message_memory)
{
  cpm_common_interfaces__msg__SEA__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_message_member_array[3] = {
  {
    "free_count",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__SEA, free_count),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reason_code",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__SEA, reason_code),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "status",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__SEA, status),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_message_members = {
  "cpm_common_interfaces__msg",  // message namespace
  "SEA",  // message name
  3,  // number of fields
  sizeof(cpm_common_interfaces__msg__SEA),
  false,  // has_any_key_member_
  cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_message_member_array,  // message members
  cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_init_function,  // function to initialize message memory (memory has to be allocated)
  cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_message_type_support_handle = {
  0,
  &cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_message_members,
  get_message_typesupport_handle_function,
  &cpm_common_interfaces__msg__SEA__get_type_hash,
  &cpm_common_interfaces__msg__SEA__get_type_description,
  &cpm_common_interfaces__msg__SEA__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_cpm_common_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, SEA)() {
  if (!cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_message_type_support_handle.typesupport_identifier) {
    cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &cpm_common_interfaces__msg__SEA__rosidl_typesupport_introspection_c__SEA_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
