// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LpsSaJobMgrSubtotalInfo.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_subtotal_info__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xe2, 0x04, 0xf6, 0x03, 0xcf, 0xaf, 0x4a, 0xa1,
      0x76, 0x7a, 0xb8, 0x55, 0x7e, 0x16, 0x15, 0x07,
      0xd6, 0xbd, 0x9a, 0x4c, 0x52, 0x64, 0x56, 0xf6,
      0xf3, 0x35, 0x7e, 0xff, 0xfb, 0xf4, 0xf2, 0x12,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaJobMgrSubtotalInfo";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__subtotal_command[] = "subtotal_command";
static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__current_step_number[] = "current_step_number";
static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__new_step_number[] = "new_step_number";
static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__target_weight[] = "target_weight";
static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__target_proportion[] = "target_proportion";
static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__target_passes[] = "target_passes";
static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__material_id[] = "material_id";
static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__material_name[] = "material_name";
static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__material_density[] = "material_density";
static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__icon_type[] = "icon_type";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__subtotal_command, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__current_step_number, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__new_step_number, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__target_weight, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__target_proportion, 17, 17},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__target_passes, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__material_id, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__material_name, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__material_density, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELD_NAME__icon_type, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__TYPE_NAME, 49, 49},
      {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__FIELDS, 10, 10},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaJobMgrReqstChannelStorage::LpsSaJobMgrSubtotalInfo_t\n"
  "################################################################################\n"
  "\n"
  "string subtotal_command\n"
  "uint16 current_step_number\n"
  "uint16 new_step_number\n"
  "float32 target_weight\n"
  "uint16 target_proportion\n"
  "uint16 target_passes\n"
  "uint32 material_id\n"
  "string material_name\n"
  "float32 material_density\n"
  "uint8 icon_type";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__TYPE_NAME, 49, 49},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 446, 446},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
