// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LpsSaUIDisplaySettings.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_settings__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x36, 0x9a, 0x54, 0x91, 0xf4, 0x9f, 0x2d, 0xc1,
      0x32, 0x1f, 0x36, 0x4c, 0x61, 0x94, 0xc6, 0x79,
      0x3a, 0x2e, 0xc6, 0xa7, 0x72, 0xf5, 0xd9, 0xf9,
      0x7b, 0x56, 0xec, 0xbf, 0x7e, 0x02, 0xc7, 0x6e,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaUIDisplaySettings";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__units[] = "units";
static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__language[] = "language";
static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__brightness[] = "brightness";
static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__time_format[] = "time_format";
static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__date_format[] = "date_format";
static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__weight_units[] = "weight_units";
static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__weight_precision[] = "weight_precision";
static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__service_mode_enable_code[] = "service_mode_enable_code";
static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__keyboard_layout_setting[] = "keyboard_layout_setting";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__units, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__language, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__brightness, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__time_format, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__date_format, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__weight_units, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__weight_precision, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__service_mode_enable_code, 24, 24},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELD_NAME__keyboard_layout_setting, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__TYPE_NAME, 48, 48},
      {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__FIELDS, 9, 9},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# Units\n"
  "################################################################################\n"
  "\n"
  "uint8 UNITS_METRIC=0\n"
  "uint8 UNITS_ENGLISH=1\n"
  "\n"
  "################################################################################\n"
  "# LpsSaUIDisplaySettingsLanguage\n"
  "################################################################################\n"
  "\n"
  "uint16 LANG_ENGLISH=0\n"
  "uint16 LANG_SPANISH=1\n"
  "uint16 LANG_FRENCH=2\n"
  "uint16 LANG_PORTUGUESE=3\n"
  "uint16 LANG_GERMAN=4\n"
  "uint16 LANG_NORWEGIAN=5\n"
  "uint16 LANG_SWEDISH=6\n"
  "uint16 LANG_FINNISH=7\n"
  "uint16 LANG_DUTCH=8\n"
  "uint16 LANG_DANISH=9\n"
  "uint16 LANG_ITALIAN=10\n"
  "uint16 LANG_GREEK=11\n"
  "uint16 LANG_TURKISH=12\n"
  "uint16 LANG_INDONESIAN=13\n"
  "uint16 LANG_RUSSIAN=14\n"
  "uint16 LANG_JAPANESE=15\n"
  "uint16 LANG_HUNGARIAN=16\n"
  "uint16 LANG_ICELANDIC=17\n"
  "uint16 LANG_ARABIC=18\n"
  "uint16 LANG_TRADITIONAL_CHINESE=19\n"
  "uint16 LANG_CZECH=20\n"
  "uint16 LANG_POLISH=21\n"
  "uint16 LANG_SIMPLIFIED_CHINESE=22\n"
  "uint16 LANG_THAI=23\n"
  "uint16 LANG_SLOVENIAN=24\n"
  "uint16 LANG_SLOVAKIAN=25\n"
  "uint16 LANG_ESTONIAN=26\n"
  "uint16 LANG_LATVIAN=27\n"
  "uint16 LANG_LITHUANIAN=28\n"
  "uint16 LANG_MALAYSIAN=29\n"
  "uint16 LANG_KOREAN=30\n"
  "uint16 LANG_PORTUGUESE_BRAZIL=31\n"
  "uint16 LANG_FARSI=32\n"
  "uint16 LANG_HEBREW=33\n"
  "uint16 LANG_SERBIAN=34\n"
  "uint16 LANG_CROATIAN=35\n"
  "uint16 LANG_BULGARIAN=36\n"
  "uint16 LANG_ROMANIAN=37\n"
  "uint16 LANG_VIETNAMESE=38\n"
  "uint16 LANG_MONGOLIAN=39\n"
  "uint16 LANG_MACEDONIAN=40\n"
  "uint16 LANG_BURMESE=41\n"
  "uint16 LANG_KHMER=42\n"
  "uint16 LANG_UKRAINIAN=43\n"
  "uint16 LANG_SPANISH_CASTILIAN_EAME=44\n"
  "uint16 LANG_FRENCH_EAME=45\n"
  "uint16 LANG_PORTUGUESE_EAME=46\n"
  "uint16 LANG_DUTCH_NETHERLANDS=47\n"
  "uint16 LANG_BURMESE_MYANMASA=48\n"
  "uint16 LANG_AFRIKAANS=49\n"
  "uint16 LANG_ALBANIAN=50\n"
  "uint16 LANG_ARMENIAN=51\n"
  "uint16 LANG_BOSNIAN=52\n"
  "uint16 LANG_DARI=53\n"
  "uint16 LANG_DUTCH_BELGIUM=54\n"
  "uint16 LANG_FRENCH_CANADIAN=55\n"
  "uint16 LANG_HINDI=56\n"
  "uint16 LANG_KAZAKH=57\n"
  "uint16 LANG_LAOTIAN=58\n"
  "uint16 LANG_SPANISH_LACD=59\n"
  "uint16 LANG_TAMIL=60\n"
  "uint16 LANG_TURKMEN=61\n"
  "uint16 LANG_URDU=62\n"
  "\n"
  "################################################################################\n"
  "# Time Format\n"
  "################################################################################\n"
  "\n"
  "uint8 TIME_FORMAT_24HR=0\n"
  "uint8 TIME_FORMAT_12HR=1\n"
  "\n"
  "################################################################################\n"
  "# Date Format\n"
  "################################################################################\n"
  "\n"
  "uint16 DATE_FORMAT_YYYY_MM_DD=1648\n"
  "uint16 DATE_FORMAT_MM_DD_YYYY=1649\n"
  "uint16 DATE_FORMAT_DD_MM_YYYY=1650\n"
  "\n"
  "################################################################################\n"
  "# Keyboard Layout\n"
  "################################################################################\n"
  "\n"
  "uint8 KEYBOARD_QWERTY=0\n"
  "uint8 KEYBOARD_NATIVE=1\n"
  "uint8 KEYBOARD_MIXED=2\n"
  "\n"
  "################################################################################\n"
  "# LpsSaUIDisplaySettings\n"
  "################################################################################\n"
  "\n"
  "uint8 units\n"
  "uint16 language\n"
  "uint8 brightness\n"
  "uint8 time_format\n"
  "uint16 date_format\n"
  "int32 weight_units\n"
  "int32 weight_precision\n"
  "uint16 service_mode_enable_code\n"
  "uint8 keyboard_layout_setting";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__TYPE_NAME, 48, 48},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 3097, 3097},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
