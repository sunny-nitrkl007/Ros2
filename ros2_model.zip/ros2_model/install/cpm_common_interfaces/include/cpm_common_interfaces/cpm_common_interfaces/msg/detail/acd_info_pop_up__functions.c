// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/AcdInfoPopUp.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/acd_info_pop_up__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
cpm_common_interfaces__msg__AcdInfoPopUp__init(cpm_common_interfaces__msg__AcdInfoPopUp * msg)
{
  if (!msg) {
    return false;
  }
  // bits
  return true;
}

void
cpm_common_interfaces__msg__AcdInfoPopUp__fini(cpm_common_interfaces__msg__AcdInfoPopUp * msg)
{
  if (!msg) {
    return;
  }
  // bits
}

bool
cpm_common_interfaces__msg__AcdInfoPopUp__are_equal(const cpm_common_interfaces__msg__AcdInfoPopUp * lhs, const cpm_common_interfaces__msg__AcdInfoPopUp * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // bits
  if (lhs->bits != rhs->bits) {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__AcdInfoPopUp__copy(
  const cpm_common_interfaces__msg__AcdInfoPopUp * input,
  cpm_common_interfaces__msg__AcdInfoPopUp * output)
{
  if (!input || !output) {
    return false;
  }
  // bits
  output->bits = input->bits;
  return true;
}

cpm_common_interfaces__msg__AcdInfoPopUp *
cpm_common_interfaces__msg__AcdInfoPopUp__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__AcdInfoPopUp * msg = (cpm_common_interfaces__msg__AcdInfoPopUp *)allocator.allocate(sizeof(cpm_common_interfaces__msg__AcdInfoPopUp), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__AcdInfoPopUp));
  bool success = cpm_common_interfaces__msg__AcdInfoPopUp__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__AcdInfoPopUp__destroy(cpm_common_interfaces__msg__AcdInfoPopUp * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__AcdInfoPopUp__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__AcdInfoPopUp__Sequence__init(cpm_common_interfaces__msg__AcdInfoPopUp__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__AcdInfoPopUp * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__AcdInfoPopUp)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__AcdInfoPopUp *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__AcdInfoPopUp), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__AcdInfoPopUp__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__AcdInfoPopUp__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__AcdInfoPopUp__Sequence__fini(cpm_common_interfaces__msg__AcdInfoPopUp__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__AcdInfoPopUp__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__AcdInfoPopUp__Sequence *
cpm_common_interfaces__msg__AcdInfoPopUp__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__AcdInfoPopUp__Sequence * array = (cpm_common_interfaces__msg__AcdInfoPopUp__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__AcdInfoPopUp__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__AcdInfoPopUp__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__AcdInfoPopUp__Sequence__destroy(cpm_common_interfaces__msg__AcdInfoPopUp__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__AcdInfoPopUp__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__AcdInfoPopUp__Sequence__are_equal(const cpm_common_interfaces__msg__AcdInfoPopUp__Sequence * lhs, const cpm_common_interfaces__msg__AcdInfoPopUp__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__AcdInfoPopUp__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__AcdInfoPopUp__Sequence__copy(
  const cpm_common_interfaces__msg__AcdInfoPopUp__Sequence * input,
  cpm_common_interfaces__msg__AcdInfoPopUp__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__AcdInfoPopUp)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__AcdInfoPopUp);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__AcdInfoPopUp * data =
      (cpm_common_interfaces__msg__AcdInfoPopUp *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__AcdInfoPopUp__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__AcdInfoPopUp__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__AcdInfoPopUp__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
