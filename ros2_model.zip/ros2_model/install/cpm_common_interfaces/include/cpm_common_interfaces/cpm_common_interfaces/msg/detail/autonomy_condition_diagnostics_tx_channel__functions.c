// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/AutonomyConditionDiagnosticsTxChannel.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/autonomy_condition_diagnostics_tx_channel__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `sea_list`
#include "cpm_common_interfaces/msg/detail/sea__functions.h"

bool
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__init(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel * msg)
{
  if (!msg) {
    return false;
  }
  // time_point_ns
  // display_ethernet_bad
  // product_link_ethernet_bad
  // sea_list
  if (!cpm_common_interfaces__msg__SEA__Sequence__init(&msg->sea_list, 0)) {
    cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__fini(msg);
    return false;
  }
  return true;
}

void
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__fini(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel * msg)
{
  if (!msg) {
    return;
  }
  // time_point_ns
  // display_ethernet_bad
  // product_link_ethernet_bad
  // sea_list
  cpm_common_interfaces__msg__SEA__Sequence__fini(&msg->sea_list);
}

bool
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__are_equal(const cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel * lhs, const cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // time_point_ns
  if (lhs->time_point_ns != rhs->time_point_ns) {
    return false;
  }
  // display_ethernet_bad
  if (lhs->display_ethernet_bad != rhs->display_ethernet_bad) {
    return false;
  }
  // product_link_ethernet_bad
  if (lhs->product_link_ethernet_bad != rhs->product_link_ethernet_bad) {
    return false;
  }
  // sea_list
  if (!cpm_common_interfaces__msg__SEA__Sequence__are_equal(
      &(lhs->sea_list), &(rhs->sea_list)))
  {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__copy(
  const cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel * input,
  cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel * output)
{
  if (!input || !output) {
    return false;
  }
  // time_point_ns
  output->time_point_ns = input->time_point_ns;
  // display_ethernet_bad
  output->display_ethernet_bad = input->display_ethernet_bad;
  // product_link_ethernet_bad
  output->product_link_ethernet_bad = input->product_link_ethernet_bad;
  // sea_list
  if (!cpm_common_interfaces__msg__SEA__Sequence__copy(
      &(input->sea_list), &(output->sea_list)))
  {
    return false;
  }
  return true;
}

cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel *
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel * msg = (cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel *)allocator.allocate(sizeof(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel));
  bool success = cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__destroy(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence__init(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence__fini(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence *
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence * array = (cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence__destroy(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence__are_equal(const cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence * lhs, const cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence__copy(
  const cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence * input,
  cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel * data =
      (cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
