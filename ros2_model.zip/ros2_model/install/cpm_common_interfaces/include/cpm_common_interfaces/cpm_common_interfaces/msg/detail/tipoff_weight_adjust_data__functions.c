// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/TipoffWeightAdjustData.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/tipoff_weight_adjust_data__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
cpm_common_interfaces__msg__TipoffWeightAdjustData__init(cpm_common_interfaces__msg__TipoffWeightAdjustData * msg)
{
  if (!msg) {
    return false;
  }
  // tip_off_weight1
  // weigh_range_weight1
  // tip_off_weight2
  // weigh_range_weight2
  // new_data_flag
  // reset
  return true;
}

void
cpm_common_interfaces__msg__TipoffWeightAdjustData__fini(cpm_common_interfaces__msg__TipoffWeightAdjustData * msg)
{
  if (!msg) {
    return;
  }
  // tip_off_weight1
  // weigh_range_weight1
  // tip_off_weight2
  // weigh_range_weight2
  // new_data_flag
  // reset
}

bool
cpm_common_interfaces__msg__TipoffWeightAdjustData__are_equal(const cpm_common_interfaces__msg__TipoffWeightAdjustData * lhs, const cpm_common_interfaces__msg__TipoffWeightAdjustData * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // tip_off_weight1
  if (lhs->tip_off_weight1 != rhs->tip_off_weight1) {
    return false;
  }
  // weigh_range_weight1
  if (lhs->weigh_range_weight1 != rhs->weigh_range_weight1) {
    return false;
  }
  // tip_off_weight2
  if (lhs->tip_off_weight2 != rhs->tip_off_weight2) {
    return false;
  }
  // weigh_range_weight2
  if (lhs->weigh_range_weight2 != rhs->weigh_range_weight2) {
    return false;
  }
  // new_data_flag
  if (lhs->new_data_flag != rhs->new_data_flag) {
    return false;
  }
  // reset
  if (lhs->reset != rhs->reset) {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__TipoffWeightAdjustData__copy(
  const cpm_common_interfaces__msg__TipoffWeightAdjustData * input,
  cpm_common_interfaces__msg__TipoffWeightAdjustData * output)
{
  if (!input || !output) {
    return false;
  }
  // tip_off_weight1
  output->tip_off_weight1 = input->tip_off_weight1;
  // weigh_range_weight1
  output->weigh_range_weight1 = input->weigh_range_weight1;
  // tip_off_weight2
  output->tip_off_weight2 = input->tip_off_weight2;
  // weigh_range_weight2
  output->weigh_range_weight2 = input->weigh_range_weight2;
  // new_data_flag
  output->new_data_flag = input->new_data_flag;
  // reset
  output->reset = input->reset;
  return true;
}

cpm_common_interfaces__msg__TipoffWeightAdjustData *
cpm_common_interfaces__msg__TipoffWeightAdjustData__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__TipoffWeightAdjustData * msg = (cpm_common_interfaces__msg__TipoffWeightAdjustData *)allocator.allocate(sizeof(cpm_common_interfaces__msg__TipoffWeightAdjustData), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__TipoffWeightAdjustData));
  bool success = cpm_common_interfaces__msg__TipoffWeightAdjustData__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__TipoffWeightAdjustData__destroy(cpm_common_interfaces__msg__TipoffWeightAdjustData * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__TipoffWeightAdjustData__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence__init(cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__TipoffWeightAdjustData * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__TipoffWeightAdjustData)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__TipoffWeightAdjustData *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__TipoffWeightAdjustData), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__TipoffWeightAdjustData__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__TipoffWeightAdjustData__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence__fini(cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__TipoffWeightAdjustData__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence *
cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence * array = (cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence__destroy(cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence__are_equal(const cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence * lhs, const cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__TipoffWeightAdjustData__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence__copy(
  const cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence * input,
  cpm_common_interfaces__msg__TipoffWeightAdjustData__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__TipoffWeightAdjustData)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__TipoffWeightAdjustData);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__TipoffWeightAdjustData * data =
      (cpm_common_interfaces__msg__TipoffWeightAdjustData *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__TipoffWeightAdjustData__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__TipoffWeightAdjustData__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__TipoffWeightAdjustData__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
