// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/LpsSaJobMgrReqstChannel.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst_channel__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `app_name`
#include "rosidl_runtime_c/string_functions.h"
// Member `command`
#include "cpm_common_interfaces/msg/detail/job_mgr_reqst_channel_command__functions.h"
// Member `data_tipoff_trigger_type`
#include "cpm_common_interfaces/msg/detail/tip_off_trigger_type__functions.h"
// Member `data_tipoff_mode`
#include "cpm_common_interfaces/msg/detail/tip_off_state__functions.h"
// Member `data_subtotal_info`
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_subtotal_info__functions.h"
// Member `requests`
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst__functions.h"

bool
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__init(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel * msg)
{
  if (!msg) {
    return false;
  }
  // app_name
  if (!rosidl_runtime_c__String__init(&msg->app_name)) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(msg);
    return false;
  }
  // app_request_id
  // command
  if (!cpm_common_interfaces__msg__JobMgrReqstChannelCommand__init(&msg->command)) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(msg);
    return false;
  }
  // data_tipoff_trigger_type
  if (!cpm_common_interfaces__msg__TipOffTriggerType__init(&msg->data_tipoff_trigger_type)) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(msg);
    return false;
  }
  // data_tipoff_mode
  if (!cpm_common_interfaces__msg__TipOffState__init(&msg->data_tipoff_mode)) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(msg);
    return false;
  }
  // data_auto_store_pass_count
  // data_task_number
  // data_enabled
  // data_target_type
  // data_subtotal_index
  // data_total_target_weight
  // data_subtotal_info
  if (!cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__init(&msg->data_subtotal_info)) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(msg);
    return false;
  }
  // requests
  if (!cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__init(&msg->requests, 0)) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(msg);
    return false;
  }
  return true;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel * msg)
{
  if (!msg) {
    return;
  }
  // app_name
  rosidl_runtime_c__String__fini(&msg->app_name);
  // app_request_id
  // command
  cpm_common_interfaces__msg__JobMgrReqstChannelCommand__fini(&msg->command);
  // data_tipoff_trigger_type
  cpm_common_interfaces__msg__TipOffTriggerType__fini(&msg->data_tipoff_trigger_type);
  // data_tipoff_mode
  cpm_common_interfaces__msg__TipOffState__fini(&msg->data_tipoff_mode);
  // data_auto_store_pass_count
  // data_task_number
  // data_enabled
  // data_target_type
  // data_subtotal_index
  // data_total_target_weight
  // data_subtotal_info
  cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__fini(&msg->data_subtotal_info);
  // requests
  cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__fini(&msg->requests);
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__are_equal(const cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel * lhs, const cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // app_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->app_name), &(rhs->app_name)))
  {
    return false;
  }
  // app_request_id
  if (lhs->app_request_id != rhs->app_request_id) {
    return false;
  }
  // command
  if (!cpm_common_interfaces__msg__JobMgrReqstChannelCommand__are_equal(
      &(lhs->command), &(rhs->command)))
  {
    return false;
  }
  // data_tipoff_trigger_type
  if (!cpm_common_interfaces__msg__TipOffTriggerType__are_equal(
      &(lhs->data_tipoff_trigger_type), &(rhs->data_tipoff_trigger_type)))
  {
    return false;
  }
  // data_tipoff_mode
  if (!cpm_common_interfaces__msg__TipOffState__are_equal(
      &(lhs->data_tipoff_mode), &(rhs->data_tipoff_mode)))
  {
    return false;
  }
  // data_auto_store_pass_count
  if (lhs->data_auto_store_pass_count != rhs->data_auto_store_pass_count) {
    return false;
  }
  // data_task_number
  if (lhs->data_task_number != rhs->data_task_number) {
    return false;
  }
  // data_enabled
  if (lhs->data_enabled != rhs->data_enabled) {
    return false;
  }
  // data_target_type
  if (lhs->data_target_type != rhs->data_target_type) {
    return false;
  }
  // data_subtotal_index
  if (lhs->data_subtotal_index != rhs->data_subtotal_index) {
    return false;
  }
  // data_total_target_weight
  if (lhs->data_total_target_weight != rhs->data_total_target_weight) {
    return false;
  }
  // data_subtotal_info
  if (!cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__are_equal(
      &(lhs->data_subtotal_info), &(rhs->data_subtotal_info)))
  {
    return false;
  }
  // requests
  if (!cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__are_equal(
      &(lhs->requests), &(rhs->requests)))
  {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__copy(
  const cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel * input,
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel * output)
{
  if (!input || !output) {
    return false;
  }
  // app_name
  if (!rosidl_runtime_c__String__copy(
      &(input->app_name), &(output->app_name)))
  {
    return false;
  }
  // app_request_id
  output->app_request_id = input->app_request_id;
  // command
  if (!cpm_common_interfaces__msg__JobMgrReqstChannelCommand__copy(
      &(input->command), &(output->command)))
  {
    return false;
  }
  // data_tipoff_trigger_type
  if (!cpm_common_interfaces__msg__TipOffTriggerType__copy(
      &(input->data_tipoff_trigger_type), &(output->data_tipoff_trigger_type)))
  {
    return false;
  }
  // data_tipoff_mode
  if (!cpm_common_interfaces__msg__TipOffState__copy(
      &(input->data_tipoff_mode), &(output->data_tipoff_mode)))
  {
    return false;
  }
  // data_auto_store_pass_count
  output->data_auto_store_pass_count = input->data_auto_store_pass_count;
  // data_task_number
  output->data_task_number = input->data_task_number;
  // data_enabled
  output->data_enabled = input->data_enabled;
  // data_target_type
  output->data_target_type = input->data_target_type;
  // data_subtotal_index
  output->data_subtotal_index = input->data_subtotal_index;
  // data_total_target_weight
  output->data_total_target_weight = input->data_total_target_weight;
  // data_subtotal_info
  if (!cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__copy(
      &(input->data_subtotal_info), &(output->data_subtotal_info)))
  {
    return false;
  }
  // requests
  if (!cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__copy(
      &(input->requests), &(output->requests)))
  {
    return false;
  }
  return true;
}

cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel *
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel * msg = (cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel));
  bool success = cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__destroy(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence__init(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence__fini(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence *
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence * array = (cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence__destroy(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence__are_equal(const cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence * lhs, const cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence__copy(
  const cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence * input,
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel * data =
      (cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
