// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/FloatIO.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/float_io__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__FloatIO__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x69, 0x6c, 0xad, 0x90, 0x0a, 0xa5, 0xc4, 0xea,
      0x3a, 0x5e, 0x8b, 0x13, 0xb4, 0x6e, 0xa3, 0xdc,
      0xfc, 0x9b, 0x5b, 0x07, 0x29, 0xa6, 0x58, 0x56,
      0x75, 0xd0, 0x02, 0x47, 0x9e, 0x1c, 0x32, 0x91,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__FloatIO__TYPE_NAME[] = "cpm_common_interfaces/msg/FloatIO";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__FloatIO__FIELD_NAME__stat[] = "stat";
static char cpm_common_interfaces__msg__FloatIO__FIELD_NAME__val[] = "val";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__FloatIO__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__FloatIO__FIELD_NAME__stat, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__FloatIO__FIELD_NAME__val, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__FloatIO__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__FloatIO__TYPE_NAME, 33, 33},
      {cpm_common_interfaces__msg__FloatIO__FIELDS, 2, 2},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsFloatIO_t\n"
  "################################################################################\n"
  "\n"
  "int32 stat\n"
  "float32 val";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__FloatIO__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__FloatIO__TYPE_NAME, 33, 33},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 201, 201},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__FloatIO__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__FloatIO__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
