// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LpsSaWeighTxChannel.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/lps_sa_weigh_tx_channel__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LpsSaWeighTxChannel__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xa4, 0x0c, 0x2c, 0x17, 0x6d, 0x17, 0x69, 0x0b,
      0x35, 0x63, 0x5d, 0x05, 0xba, 0xa0, 0xf6, 0xa5,
      0x43, 0x2f, 0x0e, 0x3e, 0x2b, 0xf0, 0x2a, 0x7a,
      0x5b, 0x5e, 0x02, 0x75, 0x12, 0xfd, 0x6f, 0xfb,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "cpm_common_interfaces/msg/detail/acd_event_pop_up__functions.h"
#include "cpm_common_interfaces/msg/detail/lft_seal_status__functions.h"
#include "cpm_common_interfaces/msg/detail/prod_measure_sensor_status__functions.h"
#include "cpm_common_interfaces/msg/detail/float_io__functions.h"
#include "cpm_common_interfaces/msg/detail/link_sensor_cal_lim__functions.h"
#include "cpm_common_interfaces/msg/detail/weigh_pid_data__functions.h"
#include "cpm_common_interfaces/msg/detail/tilt_position__functions.h"
#include "cpm_common_interfaces/msg/detail/lift_position__functions.h"
#include "cpm_common_interfaces/msg/detail/payload__functions.h"
#include "cpm_common_interfaces/msg/detail/acd_info_pop_up__functions.h"
#include "cpm_common_interfaces/msg/detail/acd_diag_pop_up__functions.h"
#include "cpm_common_interfaces/msg/detail/weigh_range__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t cpm_common_interfaces__msg__AcdDiagPopUp__EXPECTED_HASH = {1, {
    0xf5, 0x2e, 0x39, 0x2f, 0xb7, 0x74, 0xb7, 0x55,
    0x2e, 0xfa, 0x45, 0xf8, 0x1b, 0xfb, 0x1e, 0x5f,
    0x3f, 0xe4, 0xd8, 0xb0, 0x4c, 0x41, 0xbd, 0x4a,
    0x23, 0xf9, 0x97, 0x4c, 0x6b, 0x3d, 0xc5, 0x03,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__AcdEventPopUp__EXPECTED_HASH = {1, {
    0x8a, 0xbf, 0x3b, 0x96, 0x66, 0x8e, 0xdd, 0x3c,
    0xba, 0x9b, 0x0c, 0x08, 0xda, 0xd6, 0xdb, 0x89,
    0xd2, 0xad, 0x85, 0xdb, 0x77, 0x9e, 0x84, 0x98,
    0xa7, 0x69, 0x2f, 0x81, 0xd5, 0xfa, 0xd9, 0x1d,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__AcdInfoPopUp__EXPECTED_HASH = {1, {
    0x7c, 0xc6, 0x45, 0xb6, 0x86, 0xa6, 0xe4, 0x18,
    0xf6, 0x12, 0x94, 0x44, 0x3b, 0xf4, 0xbb, 0xa1,
    0x12, 0xf8, 0xe7, 0xb5, 0xe4, 0xa5, 0xe4, 0xfe,
    0x81, 0x18, 0x27, 0x5f, 0xc7, 0x71, 0x77, 0x17,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__FloatIO__EXPECTED_HASH = {1, {
    0x69, 0x6c, 0xad, 0x90, 0x0a, 0xa5, 0xc4, 0xea,
    0x3a, 0x5e, 0x8b, 0x13, 0xb4, 0x6e, 0xa3, 0xdc,
    0xfc, 0x9b, 0x5b, 0x07, 0x29, 0xa6, 0x58, 0x56,
    0x75, 0xd0, 0x02, 0x47, 0x9e, 0x1c, 0x32, 0x91,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__LftSealStatus__EXPECTED_HASH = {1, {
    0x30, 0x11, 0xc3, 0xa6, 0xe2, 0x10, 0xb4, 0x04,
    0x56, 0x46, 0xb2, 0x55, 0x62, 0x1b, 0x72, 0x2f,
    0xf8, 0xbc, 0x38, 0x1d, 0x43, 0x2a, 0x6a, 0xbe,
    0x04, 0xe1, 0x2b, 0x0b, 0x4b, 0xd3, 0x83, 0x9d,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__LiftPosition__EXPECTED_HASH = {1, {
    0xe9, 0x49, 0x0d, 0x24, 0x59, 0x9e, 0x81, 0xba,
    0x87, 0x7b, 0x14, 0xa9, 0x3c, 0x6e, 0xa3, 0x4d,
    0xa9, 0xb2, 0xe7, 0x63, 0x51, 0x0b, 0xdf, 0xff,
    0x68, 0x1e, 0x3b, 0xda, 0xde, 0xd6, 0xd7, 0x64,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__LinkSensorCalLim__EXPECTED_HASH = {1, {
    0x7f, 0xfc, 0xf3, 0x66, 0xf2, 0x61, 0x48, 0x25,
    0xcd, 0xdf, 0x30, 0xcb, 0x08, 0x9c, 0x7f, 0x5d,
    0xf8, 0x4e, 0x03, 0x70, 0xb7, 0x98, 0x64, 0x95,
    0x9b, 0x98, 0x56, 0xc6, 0xcd, 0x65, 0x44, 0x81,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__Payload__EXPECTED_HASH = {1, {
    0x7c, 0xfc, 0xab, 0xf8, 0x6d, 0xbe, 0x92, 0x76,
    0x88, 0xed, 0x8d, 0xdd, 0x6b, 0xf6, 0x93, 0x9d,
    0x35, 0x86, 0x6a, 0x6b, 0x24, 0x43, 0x6d, 0x2a,
    0x83, 0x1c, 0x71, 0x1e, 0x61, 0x11, 0x1d, 0xae,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__ProdMeasureSensorStatus__EXPECTED_HASH = {1, {
    0x17, 0x0f, 0x8e, 0xf4, 0x7b, 0x31, 0x23, 0xe9,
    0x23, 0xf7, 0x0d, 0x60, 0x1a, 0x49, 0xd4, 0xc5,
    0x9a, 0xc0, 0x11, 0x62, 0xad, 0x36, 0x69, 0x45,
    0xb4, 0xe6, 0xb6, 0x0b, 0x57, 0xa8, 0x35, 0x81,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__TiltPosition__EXPECTED_HASH = {1, {
    0x2c, 0xb6, 0x78, 0xe6, 0x4e, 0xa0, 0x58, 0x32,
    0xee, 0x75, 0x2e, 0xd7, 0x4a, 0xec, 0x4a, 0xb8,
    0xb6, 0x77, 0x28, 0x1c, 0xe9, 0xf3, 0xab, 0x36,
    0x53, 0xb1, 0xd4, 0x8b, 0x43, 0x49, 0x13, 0x4f,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__WeighPidData__EXPECTED_HASH = {1, {
    0xaf, 0x40, 0x8b, 0xf8, 0x35, 0x8b, 0x55, 0xb7,
    0x4c, 0x5d, 0x54, 0xa8, 0x40, 0x28, 0x30, 0x59,
    0x12, 0x50, 0x31, 0x28, 0x1f, 0x85, 0x58, 0xfb,
    0x53, 0x01, 0xb3, 0x4b, 0x72, 0x66, 0xe3, 0x64,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__WeighRange__EXPECTED_HASH = {1, {
    0x8c, 0x1e, 0xa7, 0x04, 0xfc, 0x6d, 0xa9, 0x63,
    0xac, 0x3a, 0x04, 0xba, 0xd8, 0x06, 0xf4, 0x09,
    0x47, 0xc0, 0x50, 0xb0, 0x27, 0x41, 0xcc, 0x7d,
    0x3c, 0x13, 0x36, 0x25, 0x34, 0xa0, 0xb7, 0x9e,
  }};
#endif

static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaWeighTxChannel";
static char cpm_common_interfaces__msg__AcdDiagPopUp__TYPE_NAME[] = "cpm_common_interfaces/msg/AcdDiagPopUp";
static char cpm_common_interfaces__msg__AcdEventPopUp__TYPE_NAME[] = "cpm_common_interfaces/msg/AcdEventPopUp";
static char cpm_common_interfaces__msg__AcdInfoPopUp__TYPE_NAME[] = "cpm_common_interfaces/msg/AcdInfoPopUp";
static char cpm_common_interfaces__msg__FloatIO__TYPE_NAME[] = "cpm_common_interfaces/msg/FloatIO";
static char cpm_common_interfaces__msg__LftSealStatus__TYPE_NAME[] = "cpm_common_interfaces/msg/LftSealStatus";
static char cpm_common_interfaces__msg__LiftPosition__TYPE_NAME[] = "cpm_common_interfaces/msg/LiftPosition";
static char cpm_common_interfaces__msg__LinkSensorCalLim__TYPE_NAME[] = "cpm_common_interfaces/msg/LinkSensorCalLim";
static char cpm_common_interfaces__msg__Payload__TYPE_NAME[] = "cpm_common_interfaces/msg/Payload";
static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__TYPE_NAME[] = "cpm_common_interfaces/msg/ProdMeasureSensorStatus";
static char cpm_common_interfaces__msg__TiltPosition__TYPE_NAME[] = "cpm_common_interfaces/msg/TiltPosition";
static char cpm_common_interfaces__msg__WeighPidData__TYPE_NAME[] = "cpm_common_interfaces/msg/WeighPidData";
static char cpm_common_interfaces__msg__WeighRange__TYPE_NAME[] = "cpm_common_interfaces/msg/WeighRange";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__time_point_ns[] = "time_point_ns";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__dig_stat[] = "dig_stat";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__cal_stat[] = "cal_stat";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__dump_stat[] = "dump_stat";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__best_bkt_wt_in_tonnes[] = "best_bkt_wt_in_tonnes";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__warmup_lifts_required[] = "warmup_lifts_required";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__payload_calc_meth[] = "payload_calc_meth";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__bkt_wt_latched_flag[] = "bkt_wt_latched_flag";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__latch_conditions_met[] = "latch_conditions_met";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__zero_available[] = "zero_available";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__payload[] = "payload";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lft_seal_status[] = "lft_seal_status";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__flash_enabled[] = "flash_enabled";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_position_sensor_id[] = "lift_position_sensor_id";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__tilt_position_sensor_id[] = "tilt_position_sensor_id";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_head_end_pressure_sensor_id[] = "lift_head_end_pressure_sensor_id";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_rod_end_pressure_sensor_id[] = "lift_rod_end_pressure_sensor_id";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__hydraulic_oil_temperature_sensor_id[] = "hydraulic_oil_temperature_sensor_id";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__imu_sensor_id[] = "imu_sensor_id";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__implement_serial_num[] = "implement_serial_num";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__work_tool_id[] = "work_tool_id";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_position[] = "lift_position";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_cyl_vel[] = "lift_cyl_vel";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__tilt_position[] = "tilt_position";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__weigh_range[] = "weigh_range";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__indicator[] = "indicator";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__cal_wt[] = "cal_wt";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_stalled[] = "lift_stalled";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_valve_command[] = "lift_valve_command";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__tilt_valve_command[] = "tilt_valve_command";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__event_state[] = "event_state";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__diag_state[] = "diag_state";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__info_state[] = "info_state";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__show_exclamation_point[] = "show_exclamation_point";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__excessive_pitch[] = "excessive_pitch";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__bucket_fully_racked[] = "bucket_fully_racked";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__zero_weight[] = "zero_weight";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__simple_cal_adjust[] = "simple_cal_adjust";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__engine_speed_rpm[] = "engine_speed_rpm";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__pid_data[] = "pid_data";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__can11_message_timeout_flag[] = "can11_message_timeout_flag";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__toa_anchored_zero_offset[] = "toa_anchored_zero_offset";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__toa_anchored_factor[] = "toa_anchored_factor";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__toa_anchor_status[] = "toa_anchor_status";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__payload_cal_in_progress[] = "payload_cal_in_progress";
static char cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__test_status[] = "test_status";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__time_point_ns, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT64,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__dig_stat, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__cal_stat, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__dump_stat, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__best_bkt_wt_in_tonnes, 21, 21},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__warmup_lifts_required, 21, 21},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__payload_calc_meth, 17, 17},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__bkt_wt_latched_flag, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__latch_conditions_met, 20, 20},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__zero_available, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__payload, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__Payload__TYPE_NAME, 33, 33},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lft_seal_status, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__LftSealStatus__TYPE_NAME, 39, 39},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__flash_enabled, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_position_sensor_id, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__tilt_position_sensor_id, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_head_end_pressure_sensor_id, 32, 32},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_rod_end_pressure_sensor_id, 31, 31},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__hydraulic_oil_temperature_sensor_id, 35, 35},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__imu_sensor_id, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__implement_serial_num, 20, 20},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__work_tool_id, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_position, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__LiftPosition__TYPE_NAME, 38, 38},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_cyl_vel, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__FloatIO__TYPE_NAME, 33, 33},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__tilt_position, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__TiltPosition__TYPE_NAME, 38, 38},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__weigh_range, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__WeighRange__TYPE_NAME, 36, 36},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__indicator, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__cal_wt, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_stalled, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__lift_valve_command, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__FloatIO__TYPE_NAME, 33, 33},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__tilt_valve_command, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__FloatIO__TYPE_NAME, 33, 33},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__event_state, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__AcdEventPopUp__TYPE_NAME, 39, 39},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__diag_state, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__AcdDiagPopUp__TYPE_NAME, 38, 38},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__info_state, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__AcdInfoPopUp__TYPE_NAME, 38, 38},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__show_exclamation_point, 22, 22},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__excessive_pitch, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__bucket_fully_racked, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__zero_weight, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__simple_cal_adjust, 17, 17},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__engine_speed_rpm, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__pid_data, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__WeighPidData__TYPE_NAME, 38, 38},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__can11_message_timeout_flag, 26, 26},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__toa_anchored_zero_offset, 24, 24},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__toa_anchored_factor, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__toa_anchor_status, 17, 17},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__payload_cal_in_progress, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELD_NAME__test_status, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription cpm_common_interfaces__msg__LpsSaWeighTxChannel__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {cpm_common_interfaces__msg__AcdDiagPopUp__TYPE_NAME, 38, 38},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__AcdEventPopUp__TYPE_NAME, 39, 39},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__AcdInfoPopUp__TYPE_NAME, 38, 38},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__FloatIO__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LftSealStatus__TYPE_NAME, 39, 39},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LiftPosition__TYPE_NAME, 38, 38},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LinkSensorCalLim__TYPE_NAME, 42, 42},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__Payload__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__TYPE_NAME, 49, 49},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TiltPosition__TYPE_NAME, 38, 38},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__TYPE_NAME, 38, 38},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighRange__TYPE_NAME, 36, 36},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LpsSaWeighTxChannel__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LpsSaWeighTxChannel__TYPE_NAME, 45, 45},
      {cpm_common_interfaces__msg__LpsSaWeighTxChannel__FIELDS, 46, 46},
    },
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__REFERENCED_TYPE_DESCRIPTIONS, 12, 12},
  };
  if (!constructed) {
    assert(0 == memcmp(&cpm_common_interfaces__msg__AcdDiagPopUp__EXPECTED_HASH, cpm_common_interfaces__msg__AcdDiagPopUp__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = cpm_common_interfaces__msg__AcdDiagPopUp__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__AcdEventPopUp__EXPECTED_HASH, cpm_common_interfaces__msg__AcdEventPopUp__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = cpm_common_interfaces__msg__AcdEventPopUp__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__AcdInfoPopUp__EXPECTED_HASH, cpm_common_interfaces__msg__AcdInfoPopUp__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[2].fields = cpm_common_interfaces__msg__AcdInfoPopUp__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__FloatIO__EXPECTED_HASH, cpm_common_interfaces__msg__FloatIO__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[3].fields = cpm_common_interfaces__msg__FloatIO__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__LftSealStatus__EXPECTED_HASH, cpm_common_interfaces__msg__LftSealStatus__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[4].fields = cpm_common_interfaces__msg__LftSealStatus__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__LiftPosition__EXPECTED_HASH, cpm_common_interfaces__msg__LiftPosition__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[5].fields = cpm_common_interfaces__msg__LiftPosition__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__LinkSensorCalLim__EXPECTED_HASH, cpm_common_interfaces__msg__LinkSensorCalLim__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[6].fields = cpm_common_interfaces__msg__LinkSensorCalLim__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__Payload__EXPECTED_HASH, cpm_common_interfaces__msg__Payload__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[7].fields = cpm_common_interfaces__msg__Payload__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__ProdMeasureSensorStatus__EXPECTED_HASH, cpm_common_interfaces__msg__ProdMeasureSensorStatus__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[8].fields = cpm_common_interfaces__msg__ProdMeasureSensorStatus__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__TiltPosition__EXPECTED_HASH, cpm_common_interfaces__msg__TiltPosition__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[9].fields = cpm_common_interfaces__msg__TiltPosition__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__WeighPidData__EXPECTED_HASH, cpm_common_interfaces__msg__WeighPidData__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[10].fields = cpm_common_interfaces__msg__WeighPidData__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__WeighRange__EXPECTED_HASH, cpm_common_interfaces__msg__WeighRange__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[11].fields = cpm_common_interfaces__msg__WeighRange__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# ToaAnchorStatus_t\n"
  "################################################################################\n"
  "\n"
  "uint8 TOA_ANCHOR_UNCHANGED=0\n"
  "uint8 TOA_ANCHOR_RESET=1\n"
  "uint8 TOA_ANCHOR_ACCEPTED=2\n"
  "uint8 TOA_ANCHOR_REJECTED=3\n"
  "\n"
  "################################################################################\n"
  "# TestStatus_t\n"
  "################################################################################\n"
  "\n"
  "uint8 TEST_INACTIVE=0\n"
  "uint8 TEST_TESTING=1\n"
  "uint8 TEST_RECORDING=2\n"
  "uint8 TEST_FAILED=3\n"
  "\n"
  "################################################################################\n"
  "# LpsSaWeighTxChannelStorage\n"
  "################################################################################\n"
  "\n"
  "int64 time_point_ns\n"
  "\n"
  "int32 dig_stat\n"
  "int32 cal_stat\n"
  "int32 dump_stat\n"
  "\n"
  "float32 best_bkt_wt_in_tonnes\n"
  "uint16 warmup_lifts_required\n"
  "uint16 payload_calc_meth\n"
  "bool bkt_wt_latched_flag\n"
  "bool latch_conditions_met\n"
  "bool zero_available\n"
  "\n"
  "Payload payload\n"
  "LftSealStatus lft_seal_status\n"
  "bool flash_enabled\n"
  "\n"
  "string lift_position_sensor_id\n"
  "string tilt_position_sensor_id\n"
  "string lift_head_end_pressure_sensor_id\n"
  "string lift_rod_end_pressure_sensor_id\n"
  "string hydraulic_oil_temperature_sensor_id\n"
  "string imu_sensor_id\n"
  "string implement_serial_num\n"
  "string work_tool_id\n"
  "\n"
  "LiftPosition lift_position\n"
  "FloatIO lift_cyl_vel\n"
  "TiltPosition tilt_position\n"
  "\n"
  "WeighRange weigh_range\n"
  "int32 indicator\n"
  "float32 cal_wt\n"
  "bool lift_stalled\n"
  "\n"
  "FloatIO lift_valve_command\n"
  "FloatIO tilt_valve_command\n"
  "\n"
  "AcdEventPopUp event_state\n"
  "AcdDiagPopUp diag_state\n"
  "AcdInfoPopUp info_state\n"
  "bool show_exclamation_point\n"
  "bool excessive_pitch\n"
  "bool bucket_fully_racked\n"
  "\n"
  "float32 zero_weight\n"
  "float32 simple_cal_adjust\n"
  "\n"
  "int16 engine_speed_rpm\n"
  "\n"
  "WeighPidData pid_data\n"
  "\n"
  "bool can11_message_timeout_flag\n"
  "\n"
  "float32 toa_anchored_zero_offset\n"
  "float32 toa_anchored_factor\n"
  "uint8 toa_anchor_status\n"
  "\n"
  "bool payload_cal_in_progress\n"
  "uint8 test_status";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LpsSaWeighTxChannel__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LpsSaWeighTxChannel__TYPE_NAME, 45, 45},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 1908, 1908},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LpsSaWeighTxChannel__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[13];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 13, 13};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LpsSaWeighTxChannel__get_individual_type_description_source(NULL),
    sources[1] = *cpm_common_interfaces__msg__AcdDiagPopUp__get_individual_type_description_source(NULL);
    sources[2] = *cpm_common_interfaces__msg__AcdEventPopUp__get_individual_type_description_source(NULL);
    sources[3] = *cpm_common_interfaces__msg__AcdInfoPopUp__get_individual_type_description_source(NULL);
    sources[4] = *cpm_common_interfaces__msg__FloatIO__get_individual_type_description_source(NULL);
    sources[5] = *cpm_common_interfaces__msg__LftSealStatus__get_individual_type_description_source(NULL);
    sources[6] = *cpm_common_interfaces__msg__LiftPosition__get_individual_type_description_source(NULL);
    sources[7] = *cpm_common_interfaces__msg__LinkSensorCalLim__get_individual_type_description_source(NULL);
    sources[8] = *cpm_common_interfaces__msg__Payload__get_individual_type_description_source(NULL);
    sources[9] = *cpm_common_interfaces__msg__ProdMeasureSensorStatus__get_individual_type_description_source(NULL);
    sources[10] = *cpm_common_interfaces__msg__TiltPosition__get_individual_type_description_source(NULL);
    sources[11] = *cpm_common_interfaces__msg__WeighPidData__get_individual_type_description_source(NULL);
    sources[12] = *cpm_common_interfaces__msg__WeighRange__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
