// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/TiltPosition.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/tilt_position__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__TiltPosition__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x2c, 0xb6, 0x78, 0xe6, 0x4e, 0xa0, 0x58, 0x32,
      0xee, 0x75, 0x2e, 0xd7, 0x4a, 0xec, 0x4a, 0xb8,
      0xb6, 0x77, 0x28, 0x1c, 0xe9, 0xf3, 0xab, 0x36,
      0x53, 0xb1, 0xd4, 0x8b, 0x43, 0x49, 0x13, 0x4f,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__TiltPosition__TYPE_NAME[] = "cpm_common_interfaces/msg/TiltPosition";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__angle[] = "angle";
static char cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__percent_angle[] = "percent_angle";
static char cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__cylinder_length[] = "cylinder_length";
static char cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__percent_cylinder_length[] = "percent_cylinder_length";
static char cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__cylinder_extension[] = "cylinder_extension";
static char cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__bucket_angle[] = "bucket_angle";
static char cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__status[] = "status";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__TiltPosition__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__angle, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__percent_angle, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__cylinder_length, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__percent_cylinder_length, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__cylinder_extension, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__bucket_angle, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TiltPosition__FIELD_NAME__status, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__TiltPosition__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__TiltPosition__TYPE_NAME, 38, 38},
      {cpm_common_interfaces__msg__TiltPosition__FIELDS, 7, 7},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaTiltPosition_t\n"
  "################################################################################\n"
  "\n"
  "float32 angle\n"
  "float32 percent_angle\n"
  "float32 cylinder_length\n"
  "float32 percent_cylinder_length\n"
  "float32 cylinder_extension\n"
  "float32 bucket_angle\n"
  "int32 status";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__TiltPosition__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__TiltPosition__TYPE_NAME, 38, 38},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 338, 338},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__TiltPosition__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__TiltPosition__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
