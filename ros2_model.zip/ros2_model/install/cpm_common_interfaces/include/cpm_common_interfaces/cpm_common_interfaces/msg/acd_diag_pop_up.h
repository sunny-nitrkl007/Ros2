// generated from rosidl_generator_c/resource/idl.h.em
// with input from cpm_common_interfaces:msg/AcdDiagPopUp.idl
// generated code does not contain a copyright notice

#ifndef CPM_COMMON_INTERFACES__MSG__ACD_DIAG_POP_UP_H_
#define CPM_COMMON_INTERFACES__MSG__ACD_DIAG_POP_UP_H_

#include "cpm_common_interfaces/msg/detail/acd_diag_pop_up__struct.h"
#include "cpm_common_interfaces/msg/detail/acd_diag_pop_up__functions.h"
#include "cpm_common_interfaces/msg/detail/acd_diag_pop_up__type_support.h"

#endif  // CPM_COMMON_INTERFACES__MSG__ACD_DIAG_POP_UP_H_
