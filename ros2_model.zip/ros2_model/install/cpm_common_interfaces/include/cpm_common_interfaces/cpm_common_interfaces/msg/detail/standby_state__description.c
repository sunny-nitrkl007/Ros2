// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/StandbyState.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/standby_state__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__StandbyState__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x4e, 0x7a, 0xed, 0xb9, 0x14, 0xdc, 0xec, 0x46,
      0xca, 0xad, 0x41, 0xf9, 0xc8, 0x0c, 0x26, 0x9a,
      0xed, 0x89, 0x0e, 0x2d, 0x62, 0x0d, 0xb8, 0x1b,
      0xa0, 0xbd, 0x38, 0x11, 0x52, 0xae, 0xc6, 0xc8,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__StandbyState__TYPE_NAME[] = "cpm_common_interfaces/msg/StandbyState";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__StandbyState__FIELD_NAME__value[] = "value";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__StandbyState__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__StandbyState__FIELD_NAME__value, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__StandbyState__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__StandbyState__TYPE_NAME, 38, 38},
      {cpm_common_interfaces__msg__StandbyState__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaJobMgrStandbyState_t\n"
  "################################################################################\n"
  "\n"
  "uint8 ACTIVATED=0\n"
  "uint8 DEACTIVATED=1\n"
  "\n"
  "uint8 value";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__StandbyState__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__StandbyState__TYPE_NAME, 38, 38},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 242, 242},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__StandbyState__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__StandbyState__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
