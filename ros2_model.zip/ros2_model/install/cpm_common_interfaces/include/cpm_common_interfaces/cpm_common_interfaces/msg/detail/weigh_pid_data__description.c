// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/WeighPidData.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/weigh_pid_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__WeighPidData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xaf, 0x40, 0x8b, 0xf8, 0x35, 0x8b, 0x55, 0xb7,
      0x4c, 0x5d, 0x54, 0xa8, 0x40, 0x28, 0x30, 0x59,
      0x12, 0x50, 0x31, 0x28, 0x1f, 0x85, 0x58, 0xfb,
      0x53, 0x01, 0xb3, 0x4b, 0x72, 0x66, 0xe3, 0x64,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "cpm_common_interfaces/msg/detail/prod_measure_sensor_status__functions.h"
#include "cpm_common_interfaces/msg/detail/link_sensor_cal_lim__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t cpm_common_interfaces__msg__LinkSensorCalLim__EXPECTED_HASH = {1, {
    0x7f, 0xfc, 0xf3, 0x66, 0xf2, 0x61, 0x48, 0x25,
    0xcd, 0xdf, 0x30, 0xcb, 0x08, 0x9c, 0x7f, 0x5d,
    0xf8, 0x4e, 0x03, 0x70, 0xb7, 0x98, 0x64, 0x95,
    0x9b, 0x98, 0x56, 0xc6, 0xcd, 0x65, 0x44, 0x81,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__ProdMeasureSensorStatus__EXPECTED_HASH = {1, {
    0x17, 0x0f, 0x8e, 0xf4, 0x7b, 0x31, 0x23, 0xe9,
    0x23, 0xf7, 0x0d, 0x60, 0x1a, 0x49, 0xd4, 0xc5,
    0x9a, 0xc0, 0x11, 0x62, 0xad, 0x36, 0x69, 0x45,
    0xb4, 0xe6, 0xb6, 0x0b, 0x57, 0xa8, 0x35, 0x81,
  }};
#endif

static char cpm_common_interfaces__msg__WeighPidData__TYPE_NAME[] = "cpm_common_interfaces/msg/WeighPidData";
static char cpm_common_interfaces__msg__LinkSensorCalLim__TYPE_NAME[] = "cpm_common_interfaces/msg/LinkSensorCalLim";
static char cpm_common_interfaces__msg__ProdMeasureSensorStatus__TYPE_NAME[] = "cpm_common_interfaces/msg/ProdMeasureSensorStatus";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__pload_sys_zero_stat[] = "pload_sys_zero_stat";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__ldr_payload_stat[] = "ldr_payload_stat";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__overload_warning_enabled[] = "overload_warning_enabled";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__prod_measure_sensor_status[] = "prod_measure_sensor_status";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__link_sensor_cal_lim[] = "link_sensor_cal_lim";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__loader_bkt_pload_tgt_wt[] = "loader_bkt_pload_tgt_wt";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__loader_bkt_pload_tgt_wt_per[] = "loader_bkt_pload_tgt_wt_per";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__pload_sys_zero_req_stat[] = "pload_sys_zero_req_stat";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__pload_sys_cal_wt_entry_req_stat[] = "pload_sys_cal_wt_entry_req_stat";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__last_pload_wt[] = "last_pload_wt";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__prod_measure_weigh_status[] = "prod_measure_weigh_status";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__bkt_payload_data[] = "bkt_payload_data";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__qr_hyd_oil_temp_min_c[] = "qr_hyd_oil_temp_min_c";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__qr_lift_cyl_vel_min_mm_sec[] = "qr_lift_cyl_vel_min_mm_sec";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__qr_lift_cyl_vel_max_mm_sec[] = "qr_lift_cyl_vel_max_mm_sec";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_rear_lateral_acceleration[] = "machine_rear_lateral_acceleration";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_rear_longitudinal_acceleration[] = "machine_rear_longitudinal_acceleration";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_rear_vertical_acceleration[] = "machine_rear_vertical_acceleration";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_pitch[] = "machine_pitch";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_slope[] = "machine_slope";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_rear_roll[] = "machine_rear_roll";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_rear_side_slope[] = "machine_rear_side_slope";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_roll[] = "machine_roll";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_side_slope[] = "machine_side_slope";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__tipoff_pitch_cal_offset[] = "tipoff_pitch_cal_offset";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__hyd_oil_temp_enabled[] = "hyd_oil_temp_enabled";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__audible_weight_enabled[] = "audible_weight_enabled";
static char cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__audible_weight_command[] = "audible_weight_command";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__WeighPidData__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__pload_sys_zero_stat, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__ldr_payload_stat, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__overload_warning_enabled, 24, 24},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__prod_measure_sensor_status, 26, 26},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__ProdMeasureSensorStatus__TYPE_NAME, 49, 49},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__link_sensor_cal_lim, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__LinkSensorCalLim__TYPE_NAME, 42, 42},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__loader_bkt_pload_tgt_wt, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__loader_bkt_pload_tgt_wt_per, 27, 27},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__pload_sys_zero_req_stat, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__pload_sys_cal_wt_entry_req_stat, 31, 31},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__last_pload_wt, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__prod_measure_weigh_status, 25, 25},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__bkt_payload_data, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__qr_hyd_oil_temp_min_c, 21, 21},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__qr_lift_cyl_vel_min_mm_sec, 26, 26},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__qr_lift_cyl_vel_max_mm_sec, 26, 26},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_rear_lateral_acceleration, 33, 33},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_rear_longitudinal_acceleration, 38, 38},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_rear_vertical_acceleration, 34, 34},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_pitch, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_slope, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_rear_roll, 17, 17},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_rear_side_slope, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_roll, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__machine_side_slope, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__tipoff_pitch_cal_offset, 23, 23},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__hyd_oil_temp_enabled, 20, 20},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__audible_weight_enabled, 22, 22},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__WeighPidData__FIELD_NAME__audible_weight_command, 22, 22},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription cpm_common_interfaces__msg__WeighPidData__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {cpm_common_interfaces__msg__LinkSensorCalLim__TYPE_NAME, 42, 42},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__ProdMeasureSensorStatus__TYPE_NAME, 49, 49},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__WeighPidData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__WeighPidData__TYPE_NAME, 38, 38},
      {cpm_common_interfaces__msg__WeighPidData__FIELDS, 28, 28},
    },
    {cpm_common_interfaces__msg__WeighPidData__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&cpm_common_interfaces__msg__LinkSensorCalLim__EXPECTED_HASH, cpm_common_interfaces__msg__LinkSensorCalLim__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = cpm_common_interfaces__msg__LinkSensorCalLim__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__ProdMeasureSensorStatus__EXPECTED_HASH, cpm_common_interfaces__msg__ProdMeasureSensorStatus__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = cpm_common_interfaces__msg__ProdMeasureSensorStatus__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# PloadSysZeroStat_t\n"
  "################################################################################\n"
  "\n"
  "uint16 ZERO_STAT_ZEROED=916\n"
  "uint16 ZERO_STAT_NOT_ZEROED=917\n"
  "\n"
  "################################################################################\n"
  "# PloadSysCalWtEntryReqStat_t\n"
  "################################################################################\n"
  "\n"
  "uint16 CAL_WT_ENTRY_REQUIRED=26\n"
  "uint16 CAL_WT_ENTRY_NOT_REQUIRED=27\n"
  "\n"
  "################################################################################\n"
  "# ACDWeighStatus::type\n"
  "################################################################################\n"
  "\n"
  "uint16 WEIGH_STATUS_BIT_LOWER_STALL=7\n"
  "uint16 WEIGH_STATUS_BIT_RAISE_STALL=8\n"
  "uint16 WEIGH_STATUS_BIT_INSUFFICIENT_DATA=9\n"
  "uint16 WEIGH_STATUS_BIT_REWEIGH_PRESSURE_CHANGING=10\n"
  "uint16 WEIGH_STATUS_BIT_REWEIGH_INCONSISTENT=11\n"
  "uint16 WEIGH_STATUS_BIT_REWEIGH_SPEED_CHANGING=12\n"
  "uint16 WEIGH_STATUS_BIT_REWEIGH_NOT_RACKED_EXCESSIVE_PITCH=13\n"
  "uint16 WEIGH_STATUS_BIT_REWEIGH_STOPPED_IN_RANGE=14\n"
  "uint16 WEIGH_STATUS_BIT_REWEIGH_LIFT_TOO_SLOW=15\n"
  "\n"
  "################################################################################\n"
  "# BktPayloadData_t\n"
  "################################################################################\n"
  "\n"
  "uint8 BKT_PAYLOAD_NOT_AVAILABLE=0\n"
  "uint8 BKT_PAYLOAD_AVAILABLE=1\n"
  "uint8 BKT_PAYLOAD_STORED=2\n"
  "uint8 BKT_PAYLOAD_NOT_INSTALLED=244\n"
  "\n"
  "################################################################################\n"
  "# AudibleAnnunciationPriority_t\n"
  "################################################################################\n"
  "\n"
  "uint16 TONE_NONE=0\n"
  "uint16 TONE_CONFIRMATION=2\n"
  "uint16 TONE_ATTENTION=6\n"
  "\n"
  "################################################################################\n"
  "# WeighPidData_t\n"
  "################################################################################\n"
  "\n"
  "uint16 pload_sys_zero_stat\n"
  "\n"
  "uint16 ldr_payload_stat\n"
  "bool overload_warning_enabled\n"
  "\n"
  "ProdMeasureSensorStatus prod_measure_sensor_status\n"
  "LinkSensorCalLim link_sensor_cal_lim\n"
  "\n"
  "float32 loader_bkt_pload_tgt_wt\n"
  "float32 loader_bkt_pload_tgt_wt_per\n"
  "uint16 pload_sys_zero_req_stat\n"
  "uint16 pload_sys_cal_wt_entry_req_stat\n"
  "\n"
  "float32 last_pload_wt\n"
  "\n"
  "uint16 prod_measure_weigh_status\n"
  "uint8 bkt_payload_data\n"
  "\n"
  "int16 qr_hyd_oil_temp_min_c\n"
  "int16 qr_lift_cyl_vel_min_mm_sec\n"
  "int16 qr_lift_cyl_vel_max_mm_sec\n"
  "\n"
  "int16 machine_rear_lateral_acceleration\n"
  "int16 machine_rear_longitudinal_acceleration\n"
  "int16 machine_rear_vertical_acceleration\n"
  "\n"
  "int16 machine_pitch\n"
  "int16 machine_slope\n"
  "int16 machine_rear_roll\n"
  "int16 machine_rear_side_slope\n"
  "int16 machine_roll\n"
  "int16 machine_side_slope\n"
  "\n"
  "float32 tipoff_pitch_cal_offset\n"
  "bool hyd_oil_temp_enabled\n"
  "bool audible_weight_enabled\n"
  "uint16 audible_weight_command";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__WeighPidData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__WeighPidData__TYPE_NAME, 38, 38},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 2752, 2752},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__WeighPidData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__WeighPidData__get_individual_type_description_source(NULL),
    sources[1] = *cpm_common_interfaces__msg__LinkSensorCalLim__get_individual_type_description_source(NULL);
    sources[2] = *cpm_common_interfaces__msg__ProdMeasureSensorStatus__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
