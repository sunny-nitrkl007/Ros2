// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from cpm_common_interfaces:msg/WeighRange.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "cpm_common_interfaces/msg/detail/weigh_range__functions.h"
#include "cpm_common_interfaces/msg/detail/weigh_range__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace cpm_common_interfaces
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void WeighRange_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) cpm_common_interfaces::msg::WeighRange(_init);
}

void WeighRange_fini_function(void * message_memory)
{
  auto typed_message = static_cast<cpm_common_interfaces::msg::WeighRange *>(message_memory);
  typed_message->~WeighRange();
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember WeighRange_message_member_array[2] = {
  {
    "weigh_range_bottom",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::WeighRange, weigh_range_bottom),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "weigh_range_size",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::WeighRange, weigh_range_size),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers WeighRange_message_members = {
  "cpm_common_interfaces::msg",  // message namespace
  "WeighRange",  // message name
  2,  // number of fields
  sizeof(cpm_common_interfaces::msg::WeighRange),
  false,  // has_any_key_member_
  WeighRange_message_member_array,  // message members
  WeighRange_init_function,  // function to initialize message memory (memory has to be allocated)
  WeighRange_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t WeighRange_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &WeighRange_message_members,
  get_message_typesupport_handle_function,
  &cpm_common_interfaces__msg__WeighRange__get_type_hash,
  &cpm_common_interfaces__msg__WeighRange__get_type_description,
  &cpm_common_interfaces__msg__WeighRange__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace cpm_common_interfaces


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<cpm_common_interfaces::msg::WeighRange>()
{
  return &::cpm_common_interfaces::msg::rosidl_typesupport_introspection_cpp::WeighRange_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, cpm_common_interfaces, msg, WeighRange)() {
  return &::cpm_common_interfaces::msg::rosidl_typesupport_introspection_cpp::WeighRange_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
