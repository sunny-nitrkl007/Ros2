// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/AcdDiagPopUp.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/acd_diag_pop_up__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__AcdDiagPopUp__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xf5, 0x2e, 0x39, 0x2f, 0xb7, 0x74, 0xb7, 0x55,
      0x2e, 0xfa, 0x45, 0xf8, 0x1b, 0xfb, 0x1e, 0x5f,
      0x3f, 0xe4, 0xd8, 0xb0, 0x4c, 0x41, 0xbd, 0x4a,
      0x23, 0xf9, 0x97, 0x4c, 0x6b, 0x3d, 0xc5, 0x03,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__AcdDiagPopUp__TYPE_NAME[] = "cpm_common_interfaces/msg/AcdDiagPopUp";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__AcdDiagPopUp__FIELD_NAME__bits[] = "bits";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__AcdDiagPopUp__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__AcdDiagPopUp__FIELD_NAME__bits, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__AcdDiagPopUp__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__AcdDiagPopUp__TYPE_NAME, 38, 38},
      {cpm_common_interfaces__msg__AcdDiagPopUp__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# ACDDiagPopUp::type\n"
  "################################################################################\n"
  "\n"
  "uint8 TILT_RE_FREQ_ABNORMAL=8\n"
  "uint8 TILT_RE_VOLTAGE_BELOW_NORMAL=9\n"
  "uint8 TILT_RE_VOLTAGE_ABOVE_NORMAL=10\n"
  "uint8 TILT_HE_FREQ_ABNORMAL=11\n"
  "uint8 TILT_HE_VOLTAGE_BELOW_NORMAL=12\n"
  "uint8 TILT_HE_VOLTAGE_ABOVE_NORMAL=13\n"
  "uint8 HYDRAULIC_OIL_TEMP_BAD=14\n"
  "uint8 MACHINE_MODEL_NOT_SET=15\n"
  "uint8 PAYLOAD_SYSTEM_NOT_INSTALLED=16\n"
  "uint8 PAYLOAD_SYSTEM_OUT_OF_CAL=17\n"
  "uint8 LIFT_RE_FREQ_ABNORMAL=18\n"
  "uint8 LIFT_RE_VOLTAGE_BELOW_NORMAL=19\n"
  "uint8 LIFT_RE_VOLTAGE_ABOVE_NORMAL=20\n"
  "uint8 LIFT_HE_FREQ_ABNORMAL=21\n"
  "uint8 LIFT_HE_VOLTAGE_BELOW_NORMAL=22\n"
  "uint8 LIFT_HE_VOLTAGE_ABOVE_NORMAL=23\n"
  "uint8 LIFT_LINK_OUT_OF_CAL=24\n"
  "uint8 LIFT_LINK_FREQ_ABNORMAL=25\n"
  "uint8 LIFT_LINK_VOLTAGE_BELOW_NORMAL=26\n"
  "uint8 LIFT_LINK_VOLTAGE_ABOVE_NORMAL=27\n"
  "uint8 TILT_LINK_OUT_OF_CAL=28\n"
  "uint8 TILT_LINK_FREQ_ABNORMAL=29\n"
  "uint8 TILT_LINK_VOLTAGE_BELOW_NORMAL=30\n"
  "uint8 TILT_LINK_VOLTAGE_ABOVE_NORMAL=31\n"
  "\n"
  "uint32 bits";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__AcdDiagPopUp__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__AcdDiagPopUp__TYPE_NAME, 38, 38},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 1045, 1045},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__AcdDiagPopUp__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__AcdDiagPopUp__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
