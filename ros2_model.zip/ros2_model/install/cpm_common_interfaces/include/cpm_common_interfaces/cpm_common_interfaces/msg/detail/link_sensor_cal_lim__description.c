// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LinkSensorCalLim.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/link_sensor_cal_lim__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LinkSensorCalLim__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x7f, 0xfc, 0xf3, 0x66, 0xf2, 0x61, 0x48, 0x25,
      0xcd, 0xdf, 0x30, 0xcb, 0x08, 0x9c, 0x7f, 0x5d,
      0xf8, 0x4e, 0x03, 0x70, 0xb7, 0x98, 0x64, 0x95,
      0x9b, 0x98, 0x56, 0xc6, 0xcd, 0x65, 0x44, 0x81,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__LinkSensorCalLim__TYPE_NAME[] = "cpm_common_interfaces/msg/LinkSensorCalLim";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__lift_pos_sensor_dc[] = "lift_pos_sensor_dc";
static char cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__lift_pos_sensor_full_raise_dc[] = "lift_pos_sensor_full_raise_dc";
static char cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__lift_pos_sensor_full_lower_dc[] = "lift_pos_sensor_full_lower_dc";
static char cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__tilt_pos_sensor_dc[] = "tilt_pos_sensor_dc";
static char cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__tilt_pos_sensor_full_rack_dc[] = "tilt_pos_sensor_full_rack_dc";
static char cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__tilt_pos_sensor_full_dump_dc[] = "tilt_pos_sensor_full_dump_dc";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LinkSensorCalLim__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__lift_pos_sensor_dc, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__lift_pos_sensor_full_raise_dc, 29, 29},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__lift_pos_sensor_full_lower_dc, 29, 29},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__tilt_pos_sensor_dc, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__tilt_pos_sensor_full_rack_dc, 28, 28},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LinkSensorCalLim__FIELD_NAME__tilt_pos_sensor_full_dump_dc, 28, 28},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LinkSensorCalLim__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LinkSensorCalLim__TYPE_NAME, 42, 42},
      {cpm_common_interfaces__msg__LinkSensorCalLim__FIELDS, 6, 6},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LinkSensorCalLim_t\n"
  "################################################################################\n"
  "\n"
  "float32 lift_pos_sensor_dc\n"
  "float32 lift_pos_sensor_full_raise_dc\n"
  "float32 lift_pos_sensor_full_lower_dc\n"
  "float32 tilt_pos_sensor_dc\n"
  "float32 tilt_pos_sensor_full_rack_dc\n"
  "float32 tilt_pos_sensor_full_dump_dc";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LinkSensorCalLim__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LinkSensorCalLim__TYPE_NAME, 42, 42},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 388, 388},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LinkSensorCalLim__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LinkSensorCalLim__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
