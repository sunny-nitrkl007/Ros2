// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from cpm_common_interfaces:msg/ShmClockInput.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "cpm_common_interfaces/msg/detail/shm_clock_input__functions.h"
#include "cpm_common_interfaces/msg/detail/shm_clock_input__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace cpm_common_interfaces
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void ShmClockInput_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) cpm_common_interfaces::msg::ShmClockInput(_init);
}

void ShmClockInput_fini_function(void * message_memory)
{
  auto typed_message = static_cast<cpm_common_interfaces::msg::ShmClockInput *>(message_memory);
  typed_message->~ShmClockInput();
}

size_t size_function__ShmClockInput__tzone_info(const void * untyped_member)
{
  (void)untyped_member;
  return 20;
}

const void * get_const_function__ShmClockInput__tzone_info(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<uint8_t, 20> *>(untyped_member);
  return &member[index];
}

void * get_function__ShmClockInput__tzone_info(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<uint8_t, 20> *>(untyped_member);
  return &member[index];
}

void fetch_function__ShmClockInput__tzone_info(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__ShmClockInput__tzone_info(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__ShmClockInput__tzone_info(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__ShmClockInput__tzone_info(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember ShmClockInput_message_member_array[4] = {
  {
    "shm_sec",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::ShmClockInput, shm_sec),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "utc_sec_us",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT64,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::ShmClockInput, utc_sec_us),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "utc_offset_min",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::ShmClockInput, utc_offset_min),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "tzone_info",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    20,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::ShmClockInput, tzone_info),  // bytes offset in struct
    nullptr,  // default value
    size_function__ShmClockInput__tzone_info,  // size() function pointer
    get_const_function__ShmClockInput__tzone_info,  // get_const(index) function pointer
    get_function__ShmClockInput__tzone_info,  // get(index) function pointer
    fetch_function__ShmClockInput__tzone_info,  // fetch(index, &value) function pointer
    assign_function__ShmClockInput__tzone_info,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers ShmClockInput_message_members = {
  "cpm_common_interfaces::msg",  // message namespace
  "ShmClockInput",  // message name
  4,  // number of fields
  sizeof(cpm_common_interfaces::msg::ShmClockInput),
  false,  // has_any_key_member_
  ShmClockInput_message_member_array,  // message members
  ShmClockInput_init_function,  // function to initialize message memory (memory has to be allocated)
  ShmClockInput_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t ShmClockInput_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &ShmClockInput_message_members,
  get_message_typesupport_handle_function,
  &cpm_common_interfaces__msg__ShmClockInput__get_type_hash,
  &cpm_common_interfaces__msg__ShmClockInput__get_type_description,
  &cpm_common_interfaces__msg__ShmClockInput__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace cpm_common_interfaces


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<cpm_common_interfaces::msg::ShmClockInput>()
{
  return &::cpm_common_interfaces::msg::rosidl_typesupport_introspection_cpp::ShmClockInput_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, cpm_common_interfaces, msg, ShmClockInput)() {
  return &::cpm_common_interfaces::msg::rosidl_typesupport_introspection_cpp::ShmClockInput_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
