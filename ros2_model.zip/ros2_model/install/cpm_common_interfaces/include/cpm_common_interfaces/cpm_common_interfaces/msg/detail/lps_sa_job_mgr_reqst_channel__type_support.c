// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from cpm_common_interfaces:msg/LpsSaJobMgrReqstChannel.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst_channel__rosidl_typesupport_introspection_c.h"
#include "cpm_common_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst_channel__functions.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst_channel__struct.h"


// Include directives for member types
// Member `app_name`
#include "rosidl_runtime_c/string_functions.h"
// Member `command`
#include "cpm_common_interfaces/msg/job_mgr_reqst_channel_command.h"
// Member `command`
#include "cpm_common_interfaces/msg/detail/job_mgr_reqst_channel_command__rosidl_typesupport_introspection_c.h"
// Member `data_tipoff_trigger_type`
#include "cpm_common_interfaces/msg/tip_off_trigger_type.h"
// Member `data_tipoff_trigger_type`
#include "cpm_common_interfaces/msg/detail/tip_off_trigger_type__rosidl_typesupport_introspection_c.h"
// Member `data_tipoff_mode`
#include "cpm_common_interfaces/msg/tip_off_state.h"
// Member `data_tipoff_mode`
#include "cpm_common_interfaces/msg/detail/tip_off_state__rosidl_typesupport_introspection_c.h"
// Member `data_subtotal_info`
#include "cpm_common_interfaces/msg/lps_sa_job_mgr_subtotal_info.h"
// Member `data_subtotal_info`
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_subtotal_info__rosidl_typesupport_introspection_c.h"
// Member `requests`
#include "cpm_common_interfaces/msg/lps_sa_job_mgr_reqst.h"
// Member `requests`
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__init(message_memory);
}

void cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_fini_function(void * message_memory)
{
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__fini(message_memory);
}

size_t cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__size_function__LpsSaJobMgrReqstChannel__requests(
  const void * untyped_member)
{
  const cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * member =
    (const cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence *)(untyped_member);
  return member->size;
}

const void * cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__get_const_function__LpsSaJobMgrReqstChannel__requests(
  const void * untyped_member, size_t index)
{
  const cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * member =
    (const cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence *)(untyped_member);
  return &member->data[index];
}

void * cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__get_function__LpsSaJobMgrReqstChannel__requests(
  void * untyped_member, size_t index)
{
  cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * member =
    (cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence *)(untyped_member);
  return &member->data[index];
}

void cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__fetch_function__LpsSaJobMgrReqstChannel__requests(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const cpm_common_interfaces__msg__LpsSaJobMgrReqst * item =
    ((const cpm_common_interfaces__msg__LpsSaJobMgrReqst *)
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__get_const_function__LpsSaJobMgrReqstChannel__requests(untyped_member, index));
  cpm_common_interfaces__msg__LpsSaJobMgrReqst * value =
    (cpm_common_interfaces__msg__LpsSaJobMgrReqst *)(untyped_value);
  *value = *item;
}

void cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__assign_function__LpsSaJobMgrReqstChannel__requests(
  void * untyped_member, size_t index, const void * untyped_value)
{
  cpm_common_interfaces__msg__LpsSaJobMgrReqst * item =
    ((cpm_common_interfaces__msg__LpsSaJobMgrReqst *)
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__get_function__LpsSaJobMgrReqstChannel__requests(untyped_member, index));
  const cpm_common_interfaces__msg__LpsSaJobMgrReqst * value =
    (const cpm_common_interfaces__msg__LpsSaJobMgrReqst *)(untyped_value);
  *item = *value;
}

bool cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__resize_function__LpsSaJobMgrReqstChannel__requests(
  void * untyped_member, size_t size)
{
  cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * member =
    (cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence *)(untyped_member);
  cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__fini(member);
  return cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_member_array[13] = {
  {
    "app_name",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, app_name),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "app_request_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, app_request_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "command",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, command),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data_tipoff_trigger_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, data_tipoff_trigger_type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data_tipoff_mode",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, data_tipoff_mode),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data_auto_store_pass_count",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, data_auto_store_pass_count),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data_task_number",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, data_task_number),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data_enabled",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, data_enabled),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data_target_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, data_target_type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data_subtotal_index",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, data_subtotal_index),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data_total_target_weight",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, data_total_target_weight),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data_subtotal_info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, data_subtotal_info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "requests",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel, requests),  // bytes offset in struct
    NULL,  // default value
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__size_function__LpsSaJobMgrReqstChannel__requests,  // size() function pointer
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__get_const_function__LpsSaJobMgrReqstChannel__requests,  // get_const(index) function pointer
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__get_function__LpsSaJobMgrReqstChannel__requests,  // get(index) function pointer
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__fetch_function__LpsSaJobMgrReqstChannel__requests,  // fetch(index, &value) function pointer
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__assign_function__LpsSaJobMgrReqstChannel__requests,  // assign(index, value) function pointer
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__resize_function__LpsSaJobMgrReqstChannel__requests  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_members = {
  "cpm_common_interfaces__msg",  // message namespace
  "LpsSaJobMgrReqstChannel",  // message name
  13,  // number of fields
  sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel),
  false,  // has_any_key_member_
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_member_array,  // message members
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_init_function,  // function to initialize message memory (memory has to be allocated)
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_type_support_handle = {
  0,
  &cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_members,
  get_message_typesupport_handle_function,
  &cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__get_type_hash,
  &cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__get_type_description,
  &cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_cpm_common_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, LpsSaJobMgrReqstChannel)() {
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, JobMgrReqstChannelCommand)();
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, TipOffTriggerType)();
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_member_array[4].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, TipOffState)();
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_member_array[11].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, LpsSaJobMgrSubtotalInfo)();
  cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_member_array[12].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, LpsSaJobMgrReqst)();
  if (!cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_type_support_handle.typesupport_identifier) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__rosidl_typesupport_introspection_c__LpsSaJobMgrReqstChannel_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
