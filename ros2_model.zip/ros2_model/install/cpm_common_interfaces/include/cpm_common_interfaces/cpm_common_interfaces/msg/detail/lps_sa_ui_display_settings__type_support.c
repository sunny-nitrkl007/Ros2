// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from cpm_common_interfaces:msg/LpsSaUIDisplaySettings.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_settings__rosidl_typesupport_introspection_c.h"
#include "cpm_common_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_settings__functions.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_settings__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  cpm_common_interfaces__msg__LpsSaUIDisplaySettings__init(message_memory);
}

void cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_fini_function(void * message_memory)
{
  cpm_common_interfaces__msg__LpsSaUIDisplaySettings__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_message_member_array[9] = {
  {
    "units",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings, units),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "language",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings, language),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "brightness",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings, brightness),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "time_format",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings, time_format),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "date_format",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings, date_format),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "weight_units",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings, weight_units),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "weight_precision",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings, weight_precision),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "service_mode_enable_code",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings, service_mode_enable_code),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "keyboard_layout_setting",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings, keyboard_layout_setting),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_message_members = {
  "cpm_common_interfaces__msg",  // message namespace
  "LpsSaUIDisplaySettings",  // message name
  9,  // number of fields
  sizeof(cpm_common_interfaces__msg__LpsSaUIDisplaySettings),
  false,  // has_any_key_member_
  cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_message_member_array,  // message members
  cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_init_function,  // function to initialize message memory (memory has to be allocated)
  cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_message_type_support_handle = {
  0,
  &cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_message_members,
  get_message_typesupport_handle_function,
  &cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_type_hash,
  &cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_type_description,
  &cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_cpm_common_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, LpsSaUIDisplaySettings)() {
  if (!cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_message_type_support_handle.typesupport_identifier) {
    cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &cpm_common_interfaces__msg__LpsSaUIDisplaySettings__rosidl_typesupport_introspection_c__LpsSaUIDisplaySettings_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
