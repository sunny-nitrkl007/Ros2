// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LftSealStatus.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/lft_seal_status__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LftSealStatus__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x30, 0x11, 0xc3, 0xa6, 0xe2, 0x10, 0xb4, 0x04,
      0x56, 0x46, 0xb2, 0x55, 0x62, 0x1b, 0x72, 0x2f,
      0xf8, 0xbc, 0x38, 0x1d, 0x43, 0x2a, 0x6a, 0xbe,
      0x04, 0xe1, 0x2b, 0x0b, 0x4b, 0xd3, 0x83, 0x9d,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__LftSealStatus__TYPE_NAME[] = "cpm_common_interfaces/msg/LftSealStatus";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LftSealStatus__FIELD_NAME__sealed[] = "sealed";
static char cpm_common_interfaces__msg__LftSealStatus__FIELD_NAME__seal_time_ns[] = "seal_time_ns";
static char cpm_common_interfaces__msg__LftSealStatus__FIELD_NAME__seal_id[] = "seal_id";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LftSealStatus__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LftSealStatus__FIELD_NAME__sealed, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LftSealStatus__FIELD_NAME__seal_time_ns, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT64,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LftSealStatus__FIELD_NAME__seal_id, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LftSealStatus__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LftSealStatus__TYPE_NAME, 39, 39},
      {cpm_common_interfaces__msg__LftSealStatus__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaLftSealStatus_t\n"
  "################################################################################\n"
  "\n"
  "bool sealed\n"
  "int64 seal_time_ns\n"
  "uint32 seal_id";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LftSealStatus__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LftSealStatus__TYPE_NAME, 39, 39},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 232, 232},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LftSealStatus__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LftSealStatus__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
