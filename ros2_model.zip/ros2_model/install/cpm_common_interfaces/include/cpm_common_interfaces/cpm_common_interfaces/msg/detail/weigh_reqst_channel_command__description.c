// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/WeighReqstChannelCommand.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/weigh_reqst_channel_command__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__WeighReqstChannelCommand__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x92, 0x8c, 0xec, 0x7a, 0xdf, 0x79, 0xc2, 0x0d,
      0x7c, 0xb7, 0x80, 0x12, 0x0d, 0x2c, 0x24, 0xaf,
      0xa1, 0x94, 0x47, 0xa2, 0xfc, 0x11, 0xbd, 0x39,
      0x27, 0x8b, 0x8b, 0x64, 0x6a, 0x02, 0x83, 0x17,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__WeighReqstChannelCommand__TYPE_NAME[] = "cpm_common_interfaces/msg/WeighReqstChannelCommand";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__WeighReqstChannelCommand__FIELD_NAME__value[] = "value";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__WeighReqstChannelCommand__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__WeighReqstChannelCommand__FIELD_NAME__value, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__WeighReqstChannelCommand__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__WeighReqstChannelCommand__TYPE_NAME, 50, 50},
      {cpm_common_interfaces__msg__WeighReqstChannelCommand__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaWeighReqstChannelStorage::Command\n"
  "################################################################################\n"
  "\n"
  "uint8 NONE=0\n"
  "uint8 WRITE_OVERLOAD_WARNING_ENABLE=1\n"
  "uint8 WRITE_BUCKET_PAYLOAD_TARGET_WEIGHT=2\n"
  "uint8 ZERO=3\n"
  "uint8 RESET_BEST_BUCKET_WEIGHT=4\n"
  "uint8 CAPTURE_CYLINDER_EXTENSION_REFERENCE=5\n"
  "uint8 CLEAR_REWEIGH_WARNING=6\n"
  "uint8 WRITE_WEIGH_RANGE=7\n"
  "uint8 WRITE_CALIBRATION_WEIGHT=8\n"
  "uint8 WRITE_MACHINE_PITCH_CAL_OFFSET=9\n"
  "uint8 WRITE_HYD_OIL_TEMP_ENABLE=10\n"
  "uint8 WRITE_AUDIBLE_WEIGHT_ENABLE=11\n"
  "uint8 WRITE_LFT_SEALED=12\n"
  "uint8 WRITE_LFT_SEALED_FLASH_ENABLE=13\n"
  "uint8 WRITE_LIFT_POSITION_SENSOR_ID=14\n"
  "uint8 WRITE_TILT_POSITION_SENSOR_ID=15\n"
  "uint8 WRITE_LIFT_HE_PRESSURE_SENSOR_ID=16\n"
  "uint8 WRITE_LIFT_RE_PRESSURE_SENSOR_ID=17\n"
  "uint8 WRITE_HYDRAULIC_OIL_TEMP_SENSOR_ID=18\n"
  "uint8 WRITE_PAYLOAD_OUT_OF_CAL=19\n"
  "uint8 NOTIFY_TICKET_NUMBER_WRITE=20\n"
  "uint8 PUBLISH_SERVICE_HISTORY=21\n"
  "uint8 WRITE_WORK_TOOL_ID=22\n"
  "uint8 PUBLISH_LIFT_SENSOR_CALIBRATION=23\n"
  "uint8 PUBLISH_TILT_SENSOR_CALIBRATION=24\n"
  "uint8 PUBLISH_WEIGH_CALIBRATION=25\n"
  "uint8 PUBLISH_WEIGH_CONFIGURATION=26\n"
  "uint8 PUBLISH_RECENT_WEIGH_RESULTS=27\n"
  "uint8 WRITE_REWEIGH_MAX_PITCH=28\n"
  "uint8 WRITE_REWEIGH_MIN_PITCH=29\n"
  "uint8 WRITE_REWEIGH_MAX_ABS_ROLL=30\n"
  "uint8 WRITE_REWEIGH_MIN_LIFT_CYL_VEL=31\n"
  "uint8 WRITE_ADVANCED_CALIBRATION_ADJUSTMENT=32\n"
  "uint8 RUN_TEST=33\n"
  "uint8 RECORD_TEST=34\n"
  "uint8 WRITE_IMU_COMP_ENABLE=35\n"
  "\n"
  "uint8 value";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__WeighReqstChannelCommand__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__WeighReqstChannelCommand__TYPE_NAME, 50, 50},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 1455, 1455},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__WeighReqstChannelCommand__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__WeighReqstChannelCommand__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
