// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/LiftPosition.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/lift_position__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
cpm_common_interfaces__msg__LiftPosition__init(cpm_common_interfaces__msg__LiftPosition * msg)
{
  if (!msg) {
    return false;
  }
  // angle
  // percent_angle
  // cylinder_length
  // percent_cylinder_length
  // cylinder_extension
  // status
  return true;
}

void
cpm_common_interfaces__msg__LiftPosition__fini(cpm_common_interfaces__msg__LiftPosition * msg)
{
  if (!msg) {
    return;
  }
  // angle
  // percent_angle
  // cylinder_length
  // percent_cylinder_length
  // cylinder_extension
  // status
}

bool
cpm_common_interfaces__msg__LiftPosition__are_equal(const cpm_common_interfaces__msg__LiftPosition * lhs, const cpm_common_interfaces__msg__LiftPosition * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // angle
  if (lhs->angle != rhs->angle) {
    return false;
  }
  // percent_angle
  if (lhs->percent_angle != rhs->percent_angle) {
    return false;
  }
  // cylinder_length
  if (lhs->cylinder_length != rhs->cylinder_length) {
    return false;
  }
  // percent_cylinder_length
  if (lhs->percent_cylinder_length != rhs->percent_cylinder_length) {
    return false;
  }
  // cylinder_extension
  if (lhs->cylinder_extension != rhs->cylinder_extension) {
    return false;
  }
  // status
  if (lhs->status != rhs->status) {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__LiftPosition__copy(
  const cpm_common_interfaces__msg__LiftPosition * input,
  cpm_common_interfaces__msg__LiftPosition * output)
{
  if (!input || !output) {
    return false;
  }
  // angle
  output->angle = input->angle;
  // percent_angle
  output->percent_angle = input->percent_angle;
  // cylinder_length
  output->cylinder_length = input->cylinder_length;
  // percent_cylinder_length
  output->percent_cylinder_length = input->percent_cylinder_length;
  // cylinder_extension
  output->cylinder_extension = input->cylinder_extension;
  // status
  output->status = input->status;
  return true;
}

cpm_common_interfaces__msg__LiftPosition *
cpm_common_interfaces__msg__LiftPosition__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LiftPosition * msg = (cpm_common_interfaces__msg__LiftPosition *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LiftPosition), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__LiftPosition));
  bool success = cpm_common_interfaces__msg__LiftPosition__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__LiftPosition__destroy(cpm_common_interfaces__msg__LiftPosition * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__LiftPosition__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__LiftPosition__Sequence__init(cpm_common_interfaces__msg__LiftPosition__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LiftPosition * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LiftPosition)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__LiftPosition *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__LiftPosition), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__LiftPosition__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__LiftPosition__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__LiftPosition__Sequence__fini(cpm_common_interfaces__msg__LiftPosition__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__LiftPosition__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__LiftPosition__Sequence *
cpm_common_interfaces__msg__LiftPosition__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LiftPosition__Sequence * array = (cpm_common_interfaces__msg__LiftPosition__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LiftPosition__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__LiftPosition__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__LiftPosition__Sequence__destroy(cpm_common_interfaces__msg__LiftPosition__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__LiftPosition__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__LiftPosition__Sequence__are_equal(const cpm_common_interfaces__msg__LiftPosition__Sequence * lhs, const cpm_common_interfaces__msg__LiftPosition__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__LiftPosition__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__LiftPosition__Sequence__copy(
  const cpm_common_interfaces__msg__LiftPosition__Sequence * input,
  cpm_common_interfaces__msg__LiftPosition__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LiftPosition)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__LiftPosition);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__LiftPosition * data =
      (cpm_common_interfaces__msg__LiftPosition *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__LiftPosition__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__LiftPosition__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__LiftPosition__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
