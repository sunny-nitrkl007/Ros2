// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LpsSaJobMgrReqstChannel.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst_channel__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xd7, 0xea, 0xfc, 0x4a, 0xf8, 0x80, 0xa2, 0x16,
      0x6e, 0x6e, 0x99, 0xf5, 0x44, 0x26, 0x35, 0xc1,
      0x5f, 0xed, 0x79, 0x5e, 0x28, 0xb1, 0x83, 0x67,
      0x2a, 0xb7, 0x93, 0x85, 0xa1, 0xc8, 0x0a, 0xed,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_subtotal_info__functions.h"
#include "cpm_common_interfaces/msg/detail/tip_off_state__functions.h"
#include "cpm_common_interfaces/msg/detail/tip_off_trigger_type__functions.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst__functions.h"
#include "cpm_common_interfaces/msg/detail/job_mgr_reqst_channel_command__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t cpm_common_interfaces__msg__JobMgrReqstChannelCommand__EXPECTED_HASH = {1, {
    0x9e, 0x96, 0x7a, 0x71, 0xf4, 0xb1, 0x48, 0x16,
    0x2f, 0xd4, 0x53, 0xed, 0xbb, 0xa5, 0x52, 0x4b,
    0x42, 0xdc, 0x7b, 0xf6, 0x45, 0xf0, 0xc4, 0xaa,
    0x49, 0x5a, 0xd6, 0x02, 0x78, 0x9f, 0xb5, 0x6e,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__LpsSaJobMgrReqst__EXPECTED_HASH = {1, {
    0x41, 0xde, 0x95, 0x84, 0xb0, 0xbf, 0xb4, 0x07,
    0x84, 0xba, 0xb8, 0x56, 0x42, 0x93, 0x15, 0x93,
    0x8f, 0xc0, 0xbe, 0x1b, 0x46, 0xd1, 0xdb, 0x23,
    0x5a, 0x46, 0xfc, 0x88, 0x0d, 0x25, 0xf6, 0x8e,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__EXPECTED_HASH = {1, {
    0xe2, 0x04, 0xf6, 0x03, 0xcf, 0xaf, 0x4a, 0xa1,
    0x76, 0x7a, 0xb8, 0x55, 0x7e, 0x16, 0x15, 0x07,
    0xd6, 0xbd, 0x9a, 0x4c, 0x52, 0x64, 0x56, 0xf6,
    0xf3, 0x35, 0x7e, 0xff, 0xfb, 0xf4, 0xf2, 0x12,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__TipOffState__EXPECTED_HASH = {1, {
    0x74, 0x21, 0xd3, 0xa1, 0x4f, 0xa2, 0x6c, 0x7b,
    0xb1, 0x47, 0x75, 0x95, 0x34, 0x40, 0x22, 0x07,
    0x5a, 0x8d, 0x56, 0x63, 0xf5, 0x18, 0xa4, 0xaf,
    0xb2, 0x76, 0x49, 0xa6, 0x1e, 0x69, 0x84, 0x82,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__TipOffTriggerType__EXPECTED_HASH = {1, {
    0x5b, 0x92, 0x9a, 0x4e, 0xcb, 0x6b, 0x06, 0x7f,
    0xd4, 0x22, 0x62, 0x28, 0x49, 0x6a, 0x47, 0x1b,
    0xfc, 0x36, 0x1f, 0x4d, 0x4f, 0x3b, 0x82, 0x18,
    0xbd, 0xdf, 0x7a, 0xce, 0xb6, 0x77, 0xf2, 0x6c,
  }};
#endif

static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaJobMgrReqstChannel";
static char cpm_common_interfaces__msg__JobMgrReqstChannelCommand__TYPE_NAME[] = "cpm_common_interfaces/msg/JobMgrReqstChannelCommand";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqst__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaJobMgrReqst";
static char cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaJobMgrSubtotalInfo";
static char cpm_common_interfaces__msg__TipOffState__TYPE_NAME[] = "cpm_common_interfaces/msg/TipOffState";
static char cpm_common_interfaces__msg__TipOffTriggerType__TYPE_NAME[] = "cpm_common_interfaces/msg/TipOffTriggerType";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__app_name[] = "app_name";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__app_request_id[] = "app_request_id";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__command[] = "command";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_tipoff_trigger_type[] = "data_tipoff_trigger_type";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_tipoff_mode[] = "data_tipoff_mode";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_auto_store_pass_count[] = "data_auto_store_pass_count";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_task_number[] = "data_task_number";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_enabled[] = "data_enabled";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_target_type[] = "data_target_type";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_subtotal_index[] = "data_subtotal_index";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_total_target_weight[] = "data_total_target_weight";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_subtotal_info[] = "data_subtotal_info";
static char cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__requests[] = "requests";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__app_name, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__app_request_id, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__command, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__JobMgrReqstChannelCommand__TYPE_NAME, 51, 51},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_tipoff_trigger_type, 24, 24},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__TipOffTriggerType__TYPE_NAME, 43, 43},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_tipoff_mode, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__TipOffState__TYPE_NAME, 37, 37},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_auto_store_pass_count, 26, 26},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_task_number, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_enabled, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_target_type, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_subtotal_index, 19, 19},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_total_target_weight, 24, 24},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__data_subtotal_info, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__TYPE_NAME, 49, 49},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELD_NAME__requests, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {cpm_common_interfaces__msg__LpsSaJobMgrReqst__TYPE_NAME, 42, 42},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {cpm_common_interfaces__msg__JobMgrReqstChannelCommand__TYPE_NAME, 51, 51},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqst__TYPE_NAME, 42, 42},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__TYPE_NAME, 49, 49},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TipOffState__TYPE_NAME, 37, 37},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__TipOffTriggerType__TYPE_NAME, 43, 43},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__TYPE_NAME, 49, 49},
      {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__FIELDS, 13, 13},
    },
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__REFERENCED_TYPE_DESCRIPTIONS, 5, 5},
  };
  if (!constructed) {
    assert(0 == memcmp(&cpm_common_interfaces__msg__JobMgrReqstChannelCommand__EXPECTED_HASH, cpm_common_interfaces__msg__JobMgrReqstChannelCommand__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = cpm_common_interfaces__msg__JobMgrReqstChannelCommand__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__LpsSaJobMgrReqst__EXPECTED_HASH, cpm_common_interfaces__msg__LpsSaJobMgrReqst__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = cpm_common_interfaces__msg__LpsSaJobMgrReqst__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__EXPECTED_HASH, cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[2].fields = cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__TipOffState__EXPECTED_HASH, cpm_common_interfaces__msg__TipOffState__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[3].fields = cpm_common_interfaces__msg__TipOffState__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__TipOffTriggerType__EXPECTED_HASH, cpm_common_interfaces__msg__TipOffTriggerType__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[4].fields = cpm_common_interfaces__msg__TipOffTriggerType__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaJobMgrReqstChannelStorage\n"
  "################################################################################\n"
  "\n"
  "string app_name\n"
  "uint32 app_request_id\n"
  "\n"
  "JobMgrReqstChannelCommand command\n"
  "\n"
  "TipOffTriggerType data_tipoff_trigger_type\n"
  "TipOffState data_tipoff_mode\n"
  "uint16 data_auto_store_pass_count\n"
  "uint8 data_task_number\n"
  "bool data_enabled\n"
  "uint8 data_target_type\n"
  "uint16 data_subtotal_index\n"
  "float32 data_total_target_weight\n"
  "LpsSaJobMgrSubtotalInfo data_subtotal_info\n"
  "\n"
  "LpsSaJobMgrReqst[] requests";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__TYPE_NAME, 49, 49},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 572, 572},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[6];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 6, 6};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LpsSaJobMgrReqstChannel__get_individual_type_description_source(NULL),
    sources[1] = *cpm_common_interfaces__msg__JobMgrReqstChannelCommand__get_individual_type_description_source(NULL);
    sources[2] = *cpm_common_interfaces__msg__LpsSaJobMgrReqst__get_individual_type_description_source(NULL);
    sources[3] = *cpm_common_interfaces__msg__LpsSaJobMgrSubtotalInfo__get_individual_type_description_source(NULL);
    sources[4] = *cpm_common_interfaces__msg__TipOffState__get_individual_type_description_source(NULL);
    sources[5] = *cpm_common_interfaces__msg__TipOffTriggerType__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
