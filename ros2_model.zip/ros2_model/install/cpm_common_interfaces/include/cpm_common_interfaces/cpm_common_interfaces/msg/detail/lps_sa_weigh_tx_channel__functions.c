// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/LpsSaWeighTxChannel.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/lps_sa_weigh_tx_channel__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `payload`
#include "cpm_common_interfaces/msg/detail/payload__functions.h"
// Member `lft_seal_status`
#include "cpm_common_interfaces/msg/detail/lft_seal_status__functions.h"
// Member `lift_position_sensor_id`
// Member `tilt_position_sensor_id`
// Member `lift_head_end_pressure_sensor_id`
// Member `lift_rod_end_pressure_sensor_id`
// Member `hydraulic_oil_temperature_sensor_id`
// Member `imu_sensor_id`
// Member `implement_serial_num`
// Member `work_tool_id`
#include "rosidl_runtime_c/string_functions.h"
// Member `lift_position`
#include "cpm_common_interfaces/msg/detail/lift_position__functions.h"
// Member `lift_cyl_vel`
// Member `lift_valve_command`
// Member `tilt_valve_command`
#include "cpm_common_interfaces/msg/detail/float_io__functions.h"
// Member `tilt_position`
#include "cpm_common_interfaces/msg/detail/tilt_position__functions.h"
// Member `weigh_range`
#include "cpm_common_interfaces/msg/detail/weigh_range__functions.h"
// Member `event_state`
#include "cpm_common_interfaces/msg/detail/acd_event_pop_up__functions.h"
// Member `diag_state`
#include "cpm_common_interfaces/msg/detail/acd_diag_pop_up__functions.h"
// Member `info_state`
#include "cpm_common_interfaces/msg/detail/acd_info_pop_up__functions.h"
// Member `pid_data`
#include "cpm_common_interfaces/msg/detail/weigh_pid_data__functions.h"

bool
cpm_common_interfaces__msg__LpsSaWeighTxChannel__init(cpm_common_interfaces__msg__LpsSaWeighTxChannel * msg)
{
  if (!msg) {
    return false;
  }
  // time_point_ns
  // dig_stat
  // cal_stat
  // dump_stat
  // best_bkt_wt_in_tonnes
  // warmup_lifts_required
  // payload_calc_meth
  // bkt_wt_latched_flag
  // latch_conditions_met
  // zero_available
  // payload
  if (!cpm_common_interfaces__msg__Payload__init(&msg->payload)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // lft_seal_status
  if (!cpm_common_interfaces__msg__LftSealStatus__init(&msg->lft_seal_status)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // flash_enabled
  // lift_position_sensor_id
  if (!rosidl_runtime_c__String__init(&msg->lift_position_sensor_id)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // tilt_position_sensor_id
  if (!rosidl_runtime_c__String__init(&msg->tilt_position_sensor_id)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // lift_head_end_pressure_sensor_id
  if (!rosidl_runtime_c__String__init(&msg->lift_head_end_pressure_sensor_id)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // lift_rod_end_pressure_sensor_id
  if (!rosidl_runtime_c__String__init(&msg->lift_rod_end_pressure_sensor_id)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // hydraulic_oil_temperature_sensor_id
  if (!rosidl_runtime_c__String__init(&msg->hydraulic_oil_temperature_sensor_id)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // imu_sensor_id
  if (!rosidl_runtime_c__String__init(&msg->imu_sensor_id)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // implement_serial_num
  if (!rosidl_runtime_c__String__init(&msg->implement_serial_num)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // work_tool_id
  if (!rosidl_runtime_c__String__init(&msg->work_tool_id)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // lift_position
  if (!cpm_common_interfaces__msg__LiftPosition__init(&msg->lift_position)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // lift_cyl_vel
  if (!cpm_common_interfaces__msg__FloatIO__init(&msg->lift_cyl_vel)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // tilt_position
  if (!cpm_common_interfaces__msg__TiltPosition__init(&msg->tilt_position)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // weigh_range
  if (!cpm_common_interfaces__msg__WeighRange__init(&msg->weigh_range)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // indicator
  // cal_wt
  // lift_stalled
  // lift_valve_command
  if (!cpm_common_interfaces__msg__FloatIO__init(&msg->lift_valve_command)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // tilt_valve_command
  if (!cpm_common_interfaces__msg__FloatIO__init(&msg->tilt_valve_command)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // event_state
  if (!cpm_common_interfaces__msg__AcdEventPopUp__init(&msg->event_state)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // diag_state
  if (!cpm_common_interfaces__msg__AcdDiagPopUp__init(&msg->diag_state)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // info_state
  if (!cpm_common_interfaces__msg__AcdInfoPopUp__init(&msg->info_state)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // show_exclamation_point
  // excessive_pitch
  // bucket_fully_racked
  // zero_weight
  // simple_cal_adjust
  // engine_speed_rpm
  // pid_data
  if (!cpm_common_interfaces__msg__WeighPidData__init(&msg->pid_data)) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
    return false;
  }
  // can11_message_timeout_flag
  // toa_anchored_zero_offset
  // toa_anchored_factor
  // toa_anchor_status
  // payload_cal_in_progress
  // test_status
  return true;
}

void
cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(cpm_common_interfaces__msg__LpsSaWeighTxChannel * msg)
{
  if (!msg) {
    return;
  }
  // time_point_ns
  // dig_stat
  // cal_stat
  // dump_stat
  // best_bkt_wt_in_tonnes
  // warmup_lifts_required
  // payload_calc_meth
  // bkt_wt_latched_flag
  // latch_conditions_met
  // zero_available
  // payload
  cpm_common_interfaces__msg__Payload__fini(&msg->payload);
  // lft_seal_status
  cpm_common_interfaces__msg__LftSealStatus__fini(&msg->lft_seal_status);
  // flash_enabled
  // lift_position_sensor_id
  rosidl_runtime_c__String__fini(&msg->lift_position_sensor_id);
  // tilt_position_sensor_id
  rosidl_runtime_c__String__fini(&msg->tilt_position_sensor_id);
  // lift_head_end_pressure_sensor_id
  rosidl_runtime_c__String__fini(&msg->lift_head_end_pressure_sensor_id);
  // lift_rod_end_pressure_sensor_id
  rosidl_runtime_c__String__fini(&msg->lift_rod_end_pressure_sensor_id);
  // hydraulic_oil_temperature_sensor_id
  rosidl_runtime_c__String__fini(&msg->hydraulic_oil_temperature_sensor_id);
  // imu_sensor_id
  rosidl_runtime_c__String__fini(&msg->imu_sensor_id);
  // implement_serial_num
  rosidl_runtime_c__String__fini(&msg->implement_serial_num);
  // work_tool_id
  rosidl_runtime_c__String__fini(&msg->work_tool_id);
  // lift_position
  cpm_common_interfaces__msg__LiftPosition__fini(&msg->lift_position);
  // lift_cyl_vel
  cpm_common_interfaces__msg__FloatIO__fini(&msg->lift_cyl_vel);
  // tilt_position
  cpm_common_interfaces__msg__TiltPosition__fini(&msg->tilt_position);
  // weigh_range
  cpm_common_interfaces__msg__WeighRange__fini(&msg->weigh_range);
  // indicator
  // cal_wt
  // lift_stalled
  // lift_valve_command
  cpm_common_interfaces__msg__FloatIO__fini(&msg->lift_valve_command);
  // tilt_valve_command
  cpm_common_interfaces__msg__FloatIO__fini(&msg->tilt_valve_command);
  // event_state
  cpm_common_interfaces__msg__AcdEventPopUp__fini(&msg->event_state);
  // diag_state
  cpm_common_interfaces__msg__AcdDiagPopUp__fini(&msg->diag_state);
  // info_state
  cpm_common_interfaces__msg__AcdInfoPopUp__fini(&msg->info_state);
  // show_exclamation_point
  // excessive_pitch
  // bucket_fully_racked
  // zero_weight
  // simple_cal_adjust
  // engine_speed_rpm
  // pid_data
  cpm_common_interfaces__msg__WeighPidData__fini(&msg->pid_data);
  // can11_message_timeout_flag
  // toa_anchored_zero_offset
  // toa_anchored_factor
  // toa_anchor_status
  // payload_cal_in_progress
  // test_status
}

bool
cpm_common_interfaces__msg__LpsSaWeighTxChannel__are_equal(const cpm_common_interfaces__msg__LpsSaWeighTxChannel * lhs, const cpm_common_interfaces__msg__LpsSaWeighTxChannel * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // time_point_ns
  if (lhs->time_point_ns != rhs->time_point_ns) {
    return false;
  }
  // dig_stat
  if (lhs->dig_stat != rhs->dig_stat) {
    return false;
  }
  // cal_stat
  if (lhs->cal_stat != rhs->cal_stat) {
    return false;
  }
  // dump_stat
  if (lhs->dump_stat != rhs->dump_stat) {
    return false;
  }
  // best_bkt_wt_in_tonnes
  if (lhs->best_bkt_wt_in_tonnes != rhs->best_bkt_wt_in_tonnes) {
    return false;
  }
  // warmup_lifts_required
  if (lhs->warmup_lifts_required != rhs->warmup_lifts_required) {
    return false;
  }
  // payload_calc_meth
  if (lhs->payload_calc_meth != rhs->payload_calc_meth) {
    return false;
  }
  // bkt_wt_latched_flag
  if (lhs->bkt_wt_latched_flag != rhs->bkt_wt_latched_flag) {
    return false;
  }
  // latch_conditions_met
  if (lhs->latch_conditions_met != rhs->latch_conditions_met) {
    return false;
  }
  // zero_available
  if (lhs->zero_available != rhs->zero_available) {
    return false;
  }
  // payload
  if (!cpm_common_interfaces__msg__Payload__are_equal(
      &(lhs->payload), &(rhs->payload)))
  {
    return false;
  }
  // lft_seal_status
  if (!cpm_common_interfaces__msg__LftSealStatus__are_equal(
      &(lhs->lft_seal_status), &(rhs->lft_seal_status)))
  {
    return false;
  }
  // flash_enabled
  if (lhs->flash_enabled != rhs->flash_enabled) {
    return false;
  }
  // lift_position_sensor_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->lift_position_sensor_id), &(rhs->lift_position_sensor_id)))
  {
    return false;
  }
  // tilt_position_sensor_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->tilt_position_sensor_id), &(rhs->tilt_position_sensor_id)))
  {
    return false;
  }
  // lift_head_end_pressure_sensor_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->lift_head_end_pressure_sensor_id), &(rhs->lift_head_end_pressure_sensor_id)))
  {
    return false;
  }
  // lift_rod_end_pressure_sensor_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->lift_rod_end_pressure_sensor_id), &(rhs->lift_rod_end_pressure_sensor_id)))
  {
    return false;
  }
  // hydraulic_oil_temperature_sensor_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->hydraulic_oil_temperature_sensor_id), &(rhs->hydraulic_oil_temperature_sensor_id)))
  {
    return false;
  }
  // imu_sensor_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->imu_sensor_id), &(rhs->imu_sensor_id)))
  {
    return false;
  }
  // implement_serial_num
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->implement_serial_num), &(rhs->implement_serial_num)))
  {
    return false;
  }
  // work_tool_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->work_tool_id), &(rhs->work_tool_id)))
  {
    return false;
  }
  // lift_position
  if (!cpm_common_interfaces__msg__LiftPosition__are_equal(
      &(lhs->lift_position), &(rhs->lift_position)))
  {
    return false;
  }
  // lift_cyl_vel
  if (!cpm_common_interfaces__msg__FloatIO__are_equal(
      &(lhs->lift_cyl_vel), &(rhs->lift_cyl_vel)))
  {
    return false;
  }
  // tilt_position
  if (!cpm_common_interfaces__msg__TiltPosition__are_equal(
      &(lhs->tilt_position), &(rhs->tilt_position)))
  {
    return false;
  }
  // weigh_range
  if (!cpm_common_interfaces__msg__WeighRange__are_equal(
      &(lhs->weigh_range), &(rhs->weigh_range)))
  {
    return false;
  }
  // indicator
  if (lhs->indicator != rhs->indicator) {
    return false;
  }
  // cal_wt
  if (lhs->cal_wt != rhs->cal_wt) {
    return false;
  }
  // lift_stalled
  if (lhs->lift_stalled != rhs->lift_stalled) {
    return false;
  }
  // lift_valve_command
  if (!cpm_common_interfaces__msg__FloatIO__are_equal(
      &(lhs->lift_valve_command), &(rhs->lift_valve_command)))
  {
    return false;
  }
  // tilt_valve_command
  if (!cpm_common_interfaces__msg__FloatIO__are_equal(
      &(lhs->tilt_valve_command), &(rhs->tilt_valve_command)))
  {
    return false;
  }
  // event_state
  if (!cpm_common_interfaces__msg__AcdEventPopUp__are_equal(
      &(lhs->event_state), &(rhs->event_state)))
  {
    return false;
  }
  // diag_state
  if (!cpm_common_interfaces__msg__AcdDiagPopUp__are_equal(
      &(lhs->diag_state), &(rhs->diag_state)))
  {
    return false;
  }
  // info_state
  if (!cpm_common_interfaces__msg__AcdInfoPopUp__are_equal(
      &(lhs->info_state), &(rhs->info_state)))
  {
    return false;
  }
  // show_exclamation_point
  if (lhs->show_exclamation_point != rhs->show_exclamation_point) {
    return false;
  }
  // excessive_pitch
  if (lhs->excessive_pitch != rhs->excessive_pitch) {
    return false;
  }
  // bucket_fully_racked
  if (lhs->bucket_fully_racked != rhs->bucket_fully_racked) {
    return false;
  }
  // zero_weight
  if (lhs->zero_weight != rhs->zero_weight) {
    return false;
  }
  // simple_cal_adjust
  if (lhs->simple_cal_adjust != rhs->simple_cal_adjust) {
    return false;
  }
  // engine_speed_rpm
  if (lhs->engine_speed_rpm != rhs->engine_speed_rpm) {
    return false;
  }
  // pid_data
  if (!cpm_common_interfaces__msg__WeighPidData__are_equal(
      &(lhs->pid_data), &(rhs->pid_data)))
  {
    return false;
  }
  // can11_message_timeout_flag
  if (lhs->can11_message_timeout_flag != rhs->can11_message_timeout_flag) {
    return false;
  }
  // toa_anchored_zero_offset
  if (lhs->toa_anchored_zero_offset != rhs->toa_anchored_zero_offset) {
    return false;
  }
  // toa_anchored_factor
  if (lhs->toa_anchored_factor != rhs->toa_anchored_factor) {
    return false;
  }
  // toa_anchor_status
  if (lhs->toa_anchor_status != rhs->toa_anchor_status) {
    return false;
  }
  // payload_cal_in_progress
  if (lhs->payload_cal_in_progress != rhs->payload_cal_in_progress) {
    return false;
  }
  // test_status
  if (lhs->test_status != rhs->test_status) {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaWeighTxChannel__copy(
  const cpm_common_interfaces__msg__LpsSaWeighTxChannel * input,
  cpm_common_interfaces__msg__LpsSaWeighTxChannel * output)
{
  if (!input || !output) {
    return false;
  }
  // time_point_ns
  output->time_point_ns = input->time_point_ns;
  // dig_stat
  output->dig_stat = input->dig_stat;
  // cal_stat
  output->cal_stat = input->cal_stat;
  // dump_stat
  output->dump_stat = input->dump_stat;
  // best_bkt_wt_in_tonnes
  output->best_bkt_wt_in_tonnes = input->best_bkt_wt_in_tonnes;
  // warmup_lifts_required
  output->warmup_lifts_required = input->warmup_lifts_required;
  // payload_calc_meth
  output->payload_calc_meth = input->payload_calc_meth;
  // bkt_wt_latched_flag
  output->bkt_wt_latched_flag = input->bkt_wt_latched_flag;
  // latch_conditions_met
  output->latch_conditions_met = input->latch_conditions_met;
  // zero_available
  output->zero_available = input->zero_available;
  // payload
  if (!cpm_common_interfaces__msg__Payload__copy(
      &(input->payload), &(output->payload)))
  {
    return false;
  }
  // lft_seal_status
  if (!cpm_common_interfaces__msg__LftSealStatus__copy(
      &(input->lft_seal_status), &(output->lft_seal_status)))
  {
    return false;
  }
  // flash_enabled
  output->flash_enabled = input->flash_enabled;
  // lift_position_sensor_id
  if (!rosidl_runtime_c__String__copy(
      &(input->lift_position_sensor_id), &(output->lift_position_sensor_id)))
  {
    return false;
  }
  // tilt_position_sensor_id
  if (!rosidl_runtime_c__String__copy(
      &(input->tilt_position_sensor_id), &(output->tilt_position_sensor_id)))
  {
    return false;
  }
  // lift_head_end_pressure_sensor_id
  if (!rosidl_runtime_c__String__copy(
      &(input->lift_head_end_pressure_sensor_id), &(output->lift_head_end_pressure_sensor_id)))
  {
    return false;
  }
  // lift_rod_end_pressure_sensor_id
  if (!rosidl_runtime_c__String__copy(
      &(input->lift_rod_end_pressure_sensor_id), &(output->lift_rod_end_pressure_sensor_id)))
  {
    return false;
  }
  // hydraulic_oil_temperature_sensor_id
  if (!rosidl_runtime_c__String__copy(
      &(input->hydraulic_oil_temperature_sensor_id), &(output->hydraulic_oil_temperature_sensor_id)))
  {
    return false;
  }
  // imu_sensor_id
  if (!rosidl_runtime_c__String__copy(
      &(input->imu_sensor_id), &(output->imu_sensor_id)))
  {
    return false;
  }
  // implement_serial_num
  if (!rosidl_runtime_c__String__copy(
      &(input->implement_serial_num), &(output->implement_serial_num)))
  {
    return false;
  }
  // work_tool_id
  if (!rosidl_runtime_c__String__copy(
      &(input->work_tool_id), &(output->work_tool_id)))
  {
    return false;
  }
  // lift_position
  if (!cpm_common_interfaces__msg__LiftPosition__copy(
      &(input->lift_position), &(output->lift_position)))
  {
    return false;
  }
  // lift_cyl_vel
  if (!cpm_common_interfaces__msg__FloatIO__copy(
      &(input->lift_cyl_vel), &(output->lift_cyl_vel)))
  {
    return false;
  }
  // tilt_position
  if (!cpm_common_interfaces__msg__TiltPosition__copy(
      &(input->tilt_position), &(output->tilt_position)))
  {
    return false;
  }
  // weigh_range
  if (!cpm_common_interfaces__msg__WeighRange__copy(
      &(input->weigh_range), &(output->weigh_range)))
  {
    return false;
  }
  // indicator
  output->indicator = input->indicator;
  // cal_wt
  output->cal_wt = input->cal_wt;
  // lift_stalled
  output->lift_stalled = input->lift_stalled;
  // lift_valve_command
  if (!cpm_common_interfaces__msg__FloatIO__copy(
      &(input->lift_valve_command), &(output->lift_valve_command)))
  {
    return false;
  }
  // tilt_valve_command
  if (!cpm_common_interfaces__msg__FloatIO__copy(
      &(input->tilt_valve_command), &(output->tilt_valve_command)))
  {
    return false;
  }
  // event_state
  if (!cpm_common_interfaces__msg__AcdEventPopUp__copy(
      &(input->event_state), &(output->event_state)))
  {
    return false;
  }
  // diag_state
  if (!cpm_common_interfaces__msg__AcdDiagPopUp__copy(
      &(input->diag_state), &(output->diag_state)))
  {
    return false;
  }
  // info_state
  if (!cpm_common_interfaces__msg__AcdInfoPopUp__copy(
      &(input->info_state), &(output->info_state)))
  {
    return false;
  }
  // show_exclamation_point
  output->show_exclamation_point = input->show_exclamation_point;
  // excessive_pitch
  output->excessive_pitch = input->excessive_pitch;
  // bucket_fully_racked
  output->bucket_fully_racked = input->bucket_fully_racked;
  // zero_weight
  output->zero_weight = input->zero_weight;
  // simple_cal_adjust
  output->simple_cal_adjust = input->simple_cal_adjust;
  // engine_speed_rpm
  output->engine_speed_rpm = input->engine_speed_rpm;
  // pid_data
  if (!cpm_common_interfaces__msg__WeighPidData__copy(
      &(input->pid_data), &(output->pid_data)))
  {
    return false;
  }
  // can11_message_timeout_flag
  output->can11_message_timeout_flag = input->can11_message_timeout_flag;
  // toa_anchored_zero_offset
  output->toa_anchored_zero_offset = input->toa_anchored_zero_offset;
  // toa_anchored_factor
  output->toa_anchored_factor = input->toa_anchored_factor;
  // toa_anchor_status
  output->toa_anchor_status = input->toa_anchor_status;
  // payload_cal_in_progress
  output->payload_cal_in_progress = input->payload_cal_in_progress;
  // test_status
  output->test_status = input->test_status;
  return true;
}

cpm_common_interfaces__msg__LpsSaWeighTxChannel *
cpm_common_interfaces__msg__LpsSaWeighTxChannel__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaWeighTxChannel * msg = (cpm_common_interfaces__msg__LpsSaWeighTxChannel *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaWeighTxChannel), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__LpsSaWeighTxChannel));
  bool success = cpm_common_interfaces__msg__LpsSaWeighTxChannel__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__LpsSaWeighTxChannel__destroy(cpm_common_interfaces__msg__LpsSaWeighTxChannel * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence__init(cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaWeighTxChannel * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaWeighTxChannel)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__LpsSaWeighTxChannel *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__LpsSaWeighTxChannel), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__LpsSaWeighTxChannel__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence__fini(cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence *
cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence * array = (cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence__destroy(cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence__are_equal(const cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence * lhs, const cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaWeighTxChannel__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence__copy(
  const cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence * input,
  cpm_common_interfaces__msg__LpsSaWeighTxChannel__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaWeighTxChannel)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__LpsSaWeighTxChannel);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__LpsSaWeighTxChannel * data =
      (cpm_common_interfaces__msg__LpsSaWeighTxChannel *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__LpsSaWeighTxChannel__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__LpsSaWeighTxChannel__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaWeighTxChannel__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
