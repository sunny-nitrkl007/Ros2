// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/SEA.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/sea__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__SEA__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xfa, 0xa5, 0xf0, 0x1b, 0xf7, 0x79, 0x09, 0xfd,
      0x2c, 0x2a, 0x7f, 0x33, 0x3f, 0xdd, 0x0f, 0x0b,
      0x72, 0x6e, 0x50, 0x48, 0xac, 0x83, 0x01, 0xfa,
      0x79, 0x26, 0x94, 0x7a, 0x43, 0xc0, 0x81, 0x1a,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__SEA__TYPE_NAME[] = "cpm_common_interfaces/msg/SEA";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__SEA__FIELD_NAME__free_count[] = "free_count";
static char cpm_common_interfaces__msg__SEA__FIELD_NAME__reason_code[] = "reason_code";
static char cpm_common_interfaces__msg__SEA__FIELD_NAME__status[] = "status";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__SEA__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__SEA__FIELD_NAME__free_count, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__SEA__FIELD_NAME__reason_code, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__SEA__FIELD_NAME__status, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__SEA__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__SEA__TYPE_NAME, 29, 29},
      {cpm_common_interfaces__msg__SEA__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# SEAStatusCodes\n"
  "################################################################################\n"
  "\n"
  "uint16 STATUS_UNKNOWN=0\n"
  "uint16 STATUS_NOT_INSTALLED=1\n"
  "uint16 STATUS_INSTALLED=2\n"
  "uint16 STATUS_ENABLED=3\n"
  "uint16 STATUS_TEMP_INSTALLED=4\n"
  "\n"
  "################################################################################\n"
  "# SEA\n"
  "################################################################################\n"
  "\n"
  "uint16 free_count\n"
  "uint16 reason_code\n"
  "uint16 status";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__SEA__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__SEA__TYPE_NAME, 29, 29},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 536, 536},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__SEA__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__SEA__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
