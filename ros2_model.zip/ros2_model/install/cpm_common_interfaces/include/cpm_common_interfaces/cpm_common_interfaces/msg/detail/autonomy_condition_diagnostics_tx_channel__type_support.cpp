// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from cpm_common_interfaces:msg/AutonomyConditionDiagnosticsTxChannel.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "cpm_common_interfaces/msg/detail/autonomy_condition_diagnostics_tx_channel__functions.h"
#include "cpm_common_interfaces/msg/detail/autonomy_condition_diagnostics_tx_channel__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace cpm_common_interfaces
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void AutonomyConditionDiagnosticsTxChannel_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) cpm_common_interfaces::msg::AutonomyConditionDiagnosticsTxChannel(_init);
}

void AutonomyConditionDiagnosticsTxChannel_fini_function(void * message_memory)
{
  auto typed_message = static_cast<cpm_common_interfaces::msg::AutonomyConditionDiagnosticsTxChannel *>(message_memory);
  typed_message->~AutonomyConditionDiagnosticsTxChannel();
}

size_t size_function__AutonomyConditionDiagnosticsTxChannel__sea_list(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<cpm_common_interfaces::msg::SEA> *>(untyped_member);
  return member->size();
}

const void * get_const_function__AutonomyConditionDiagnosticsTxChannel__sea_list(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<cpm_common_interfaces::msg::SEA> *>(untyped_member);
  return &member[index];
}

void * get_function__AutonomyConditionDiagnosticsTxChannel__sea_list(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<cpm_common_interfaces::msg::SEA> *>(untyped_member);
  return &member[index];
}

void fetch_function__AutonomyConditionDiagnosticsTxChannel__sea_list(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const cpm_common_interfaces::msg::SEA *>(
    get_const_function__AutonomyConditionDiagnosticsTxChannel__sea_list(untyped_member, index));
  auto & value = *reinterpret_cast<cpm_common_interfaces::msg::SEA *>(untyped_value);
  value = item;
}

void assign_function__AutonomyConditionDiagnosticsTxChannel__sea_list(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<cpm_common_interfaces::msg::SEA *>(
    get_function__AutonomyConditionDiagnosticsTxChannel__sea_list(untyped_member, index));
  const auto & value = *reinterpret_cast<const cpm_common_interfaces::msg::SEA *>(untyped_value);
  item = value;
}

void resize_function__AutonomyConditionDiagnosticsTxChannel__sea_list(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<cpm_common_interfaces::msg::SEA> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember AutonomyConditionDiagnosticsTxChannel_message_member_array[4] = {
  {
    "time_point_ns",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT64,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::AutonomyConditionDiagnosticsTxChannel, time_point_ns),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "display_ethernet_bad",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::AutonomyConditionDiagnosticsTxChannel, display_ethernet_bad),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "product_link_ethernet_bad",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::AutonomyConditionDiagnosticsTxChannel, product_link_ethernet_bad),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "sea_list",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<cpm_common_interfaces::msg::SEA>(),  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces::msg::AutonomyConditionDiagnosticsTxChannel, sea_list),  // bytes offset in struct
    nullptr,  // default value
    size_function__AutonomyConditionDiagnosticsTxChannel__sea_list,  // size() function pointer
    get_const_function__AutonomyConditionDiagnosticsTxChannel__sea_list,  // get_const(index) function pointer
    get_function__AutonomyConditionDiagnosticsTxChannel__sea_list,  // get(index) function pointer
    fetch_function__AutonomyConditionDiagnosticsTxChannel__sea_list,  // fetch(index, &value) function pointer
    assign_function__AutonomyConditionDiagnosticsTxChannel__sea_list,  // assign(index, value) function pointer
    resize_function__AutonomyConditionDiagnosticsTxChannel__sea_list  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers AutonomyConditionDiagnosticsTxChannel_message_members = {
  "cpm_common_interfaces::msg",  // message namespace
  "AutonomyConditionDiagnosticsTxChannel",  // message name
  4,  // number of fields
  sizeof(cpm_common_interfaces::msg::AutonomyConditionDiagnosticsTxChannel),
  false,  // has_any_key_member_
  AutonomyConditionDiagnosticsTxChannel_message_member_array,  // message members
  AutonomyConditionDiagnosticsTxChannel_init_function,  // function to initialize message memory (memory has to be allocated)
  AutonomyConditionDiagnosticsTxChannel_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t AutonomyConditionDiagnosticsTxChannel_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &AutonomyConditionDiagnosticsTxChannel_message_members,
  get_message_typesupport_handle_function,
  &cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__get_type_hash,
  &cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__get_type_description,
  &cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace cpm_common_interfaces


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<cpm_common_interfaces::msg::AutonomyConditionDiagnosticsTxChannel>()
{
  return &::cpm_common_interfaces::msg::rosidl_typesupport_introspection_cpp::AutonomyConditionDiagnosticsTxChannel_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, cpm_common_interfaces, msg, AutonomyConditionDiagnosticsTxChannel)() {
  return &::cpm_common_interfaces::msg::rosidl_typesupport_introspection_cpp::AutonomyConditionDiagnosticsTxChannel_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
