// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CPM_COMMON_INTERFACES__MSG__AIS_JHM2_TX_CHANNEL_HPP_
#define CPM_COMMON_INTERFACES__MSG__AIS_JHM2_TX_CHANNEL_HPP_

#include "cpm_common_interfaces/msg/detail/ais_jhm2_tx_channel__struct.hpp"
#include "cpm_common_interfaces/msg/detail/ais_jhm2_tx_channel__builder.hpp"
#include "cpm_common_interfaces/msg/detail/ais_jhm2_tx_channel__traits.hpp"
#include "cpm_common_interfaces/msg/detail/ais_jhm2_tx_channel__type_support.hpp"

#endif  // CPM_COMMON_INTERFACES__MSG__AIS_JHM2_TX_CHANNEL_HPP_
