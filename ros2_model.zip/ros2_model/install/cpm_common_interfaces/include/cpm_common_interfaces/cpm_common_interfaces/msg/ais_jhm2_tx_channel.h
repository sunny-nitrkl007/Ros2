// generated from rosidl_generator_c/resource/idl.h.em
// with input from cpm_common_interfaces:msg/AisJhm2TxChannel.idl
// generated code does not contain a copyright notice

#ifndef CPM_COMMON_INTERFACES__MSG__AIS_JHM2_TX_CHANNEL_H_
#define CPM_COMMON_INTERFACES__MSG__AIS_JHM2_TX_CHANNEL_H_

#include "cpm_common_interfaces/msg/detail/ais_jhm2_tx_channel__struct.h"
#include "cpm_common_interfaces/msg/detail/ais_jhm2_tx_channel__functions.h"
#include "cpm_common_interfaces/msg/detail/ais_jhm2_tx_channel__type_support.h"

#endif  // CPM_COMMON_INTERFACES__MSG__AIS_JHM2_TX_CHANNEL_H_
