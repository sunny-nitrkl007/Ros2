// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/LpsSaUIDisplayState.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `settings`
#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_settings__functions.h"

bool
cpm_common_interfaces__msg__LpsSaUIDisplayState__init(cpm_common_interfaces__msg__LpsSaUIDisplayState * msg)
{
  if (!msg) {
    return false;
  }
  // service_mode_enable_code_entered
  // in_service_mode
  // in_verification_mode
  // heartbeat_count
  // document_id
  // weight_capacity
  // weight_decimal_precision
  // weight_interval
  // settings
  if (!cpm_common_interfaces__msg__LpsSaUIDisplaySettings__init(&msg->settings)) {
    cpm_common_interfaces__msg__LpsSaUIDisplayState__fini(msg);
    return false;
  }
  return true;
}

void
cpm_common_interfaces__msg__LpsSaUIDisplayState__fini(cpm_common_interfaces__msg__LpsSaUIDisplayState * msg)
{
  if (!msg) {
    return;
  }
  // service_mode_enable_code_entered
  // in_service_mode
  // in_verification_mode
  // heartbeat_count
  // document_id
  // weight_capacity
  // weight_decimal_precision
  // weight_interval
  // settings
  cpm_common_interfaces__msg__LpsSaUIDisplaySettings__fini(&msg->settings);
}

bool
cpm_common_interfaces__msg__LpsSaUIDisplayState__are_equal(const cpm_common_interfaces__msg__LpsSaUIDisplayState * lhs, const cpm_common_interfaces__msg__LpsSaUIDisplayState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // service_mode_enable_code_entered
  if (lhs->service_mode_enable_code_entered != rhs->service_mode_enable_code_entered) {
    return false;
  }
  // in_service_mode
  if (lhs->in_service_mode != rhs->in_service_mode) {
    return false;
  }
  // in_verification_mode
  if (lhs->in_verification_mode != rhs->in_verification_mode) {
    return false;
  }
  // heartbeat_count
  if (lhs->heartbeat_count != rhs->heartbeat_count) {
    return false;
  }
  // document_id
  if (lhs->document_id != rhs->document_id) {
    return false;
  }
  // weight_capacity
  if (lhs->weight_capacity != rhs->weight_capacity) {
    return false;
  }
  // weight_decimal_precision
  if (lhs->weight_decimal_precision != rhs->weight_decimal_precision) {
    return false;
  }
  // weight_interval
  if (lhs->weight_interval != rhs->weight_interval) {
    return false;
  }
  // settings
  if (!cpm_common_interfaces__msg__LpsSaUIDisplaySettings__are_equal(
      &(lhs->settings), &(rhs->settings)))
  {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaUIDisplayState__copy(
  const cpm_common_interfaces__msg__LpsSaUIDisplayState * input,
  cpm_common_interfaces__msg__LpsSaUIDisplayState * output)
{
  if (!input || !output) {
    return false;
  }
  // service_mode_enable_code_entered
  output->service_mode_enable_code_entered = input->service_mode_enable_code_entered;
  // in_service_mode
  output->in_service_mode = input->in_service_mode;
  // in_verification_mode
  output->in_verification_mode = input->in_verification_mode;
  // heartbeat_count
  output->heartbeat_count = input->heartbeat_count;
  // document_id
  output->document_id = input->document_id;
  // weight_capacity
  output->weight_capacity = input->weight_capacity;
  // weight_decimal_precision
  output->weight_decimal_precision = input->weight_decimal_precision;
  // weight_interval
  output->weight_interval = input->weight_interval;
  // settings
  if (!cpm_common_interfaces__msg__LpsSaUIDisplaySettings__copy(
      &(input->settings), &(output->settings)))
  {
    return false;
  }
  return true;
}

cpm_common_interfaces__msg__LpsSaUIDisplayState *
cpm_common_interfaces__msg__LpsSaUIDisplayState__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaUIDisplayState * msg = (cpm_common_interfaces__msg__LpsSaUIDisplayState *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaUIDisplayState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__LpsSaUIDisplayState));
  bool success = cpm_common_interfaces__msg__LpsSaUIDisplayState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__LpsSaUIDisplayState__destroy(cpm_common_interfaces__msg__LpsSaUIDisplayState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__LpsSaUIDisplayState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence__init(cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaUIDisplayState * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaUIDisplayState)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__LpsSaUIDisplayState *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__LpsSaUIDisplayState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__LpsSaUIDisplayState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__LpsSaUIDisplayState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence__fini(cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__LpsSaUIDisplayState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence *
cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence * array = (cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence__destroy(cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence__are_equal(const cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence * lhs, const cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaUIDisplayState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence__copy(
  const cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence * input,
  cpm_common_interfaces__msg__LpsSaUIDisplayState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaUIDisplayState)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__LpsSaUIDisplayState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__LpsSaUIDisplayState * data =
      (cpm_common_interfaces__msg__LpsSaUIDisplayState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__LpsSaUIDisplayState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__LpsSaUIDisplayState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaUIDisplayState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
