// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LpsSaWeighRespChannel.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/lps_sa_weigh_resp_channel__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LpsSaWeighRespChannel__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xec, 0xfe, 0x17, 0xa8, 0x1d, 0x92, 0x95, 0xd5,
      0xae, 0x38, 0xa3, 0xf7, 0xaf, 0x98, 0x85, 0xd2,
      0x0d, 0x6a, 0x0b, 0xee, 0xd1, 0x9d, 0xb3, 0x0e,
      0xeb, 0x27, 0xaa, 0xc7, 0x30, 0xef, 0x91, 0x34,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "cpm_common_interfaces/msg/detail/weigh_reqst_channel_command__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t cpm_common_interfaces__msg__WeighReqstChannelCommand__EXPECTED_HASH = {1, {
    0x92, 0x8c, 0xec, 0x7a, 0xdf, 0x79, 0xc2, 0x0d,
    0x7c, 0xb7, 0x80, 0x12, 0x0d, 0x2c, 0x24, 0xaf,
    0xa1, 0x94, 0x47, 0xa2, 0xfc, 0x11, 0xbd, 0x39,
    0x27, 0x8b, 0x8b, 0x64, 0x6a, 0x02, 0x83, 0x17,
  }};
#endif

static char cpm_common_interfaces__msg__LpsSaWeighRespChannel__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaWeighRespChannel";
static char cpm_common_interfaces__msg__WeighReqstChannelCommand__TYPE_NAME[] = "cpm_common_interfaces/msg/WeighReqstChannelCommand";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__app_name[] = "app_name";
static char cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__app_request_id[] = "app_request_id";
static char cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__time_point_ns[] = "time_point_ns";
static char cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__command[] = "command";
static char cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__success[] = "success";
static char cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__arg1[] = "arg1";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__app_name, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__app_request_id, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__time_point_ns, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT64,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__command, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__WeighReqstChannelCommand__TYPE_NAME, 50, 50},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__success, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELD_NAME__arg1, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription cpm_common_interfaces__msg__LpsSaWeighRespChannel__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {cpm_common_interfaces__msg__WeighReqstChannelCommand__TYPE_NAME, 50, 50},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LpsSaWeighRespChannel__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LpsSaWeighRespChannel__TYPE_NAME, 47, 47},
      {cpm_common_interfaces__msg__LpsSaWeighRespChannel__FIELDS, 6, 6},
    },
    {cpm_common_interfaces__msg__LpsSaWeighRespChannel__REFERENCED_TYPE_DESCRIPTIONS, 1, 1},
  };
  if (!constructed) {
    assert(0 == memcmp(&cpm_common_interfaces__msg__WeighReqstChannelCommand__EXPECTED_HASH, cpm_common_interfaces__msg__WeighReqstChannelCommand__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = cpm_common_interfaces__msg__WeighReqstChannelCommand__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaWeighRespChannelStorage\n"
  "################################################################################\n"
  "\n"
  "string app_name\n"
  "uint32 app_request_id\n"
  "int64 time_point_ns\n"
  "WeighReqstChannelCommand command\n"
  "bool success\n"
  "string arg1";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LpsSaWeighRespChannel__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LpsSaWeighRespChannel__TYPE_NAME, 47, 47},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 310, 310},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LpsSaWeighRespChannel__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[2];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 2, 2};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LpsSaWeighRespChannel__get_individual_type_description_source(NULL),
    sources[1] = *cpm_common_interfaces__msg__WeighReqstChannelCommand__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
