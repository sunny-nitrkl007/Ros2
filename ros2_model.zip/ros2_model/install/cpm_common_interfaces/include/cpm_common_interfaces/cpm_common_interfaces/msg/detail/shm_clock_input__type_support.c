// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from cpm_common_interfaces:msg/ShmClockInput.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "cpm_common_interfaces/msg/detail/shm_clock_input__rosidl_typesupport_introspection_c.h"
#include "cpm_common_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "cpm_common_interfaces/msg/detail/shm_clock_input__functions.h"
#include "cpm_common_interfaces/msg/detail/shm_clock_input__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  cpm_common_interfaces__msg__ShmClockInput__init(message_memory);
}

void cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_fini_function(void * message_memory)
{
  cpm_common_interfaces__msg__ShmClockInput__fini(message_memory);
}

size_t cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__size_function__ShmClockInput__tzone_info(
  const void * untyped_member)
{
  (void)untyped_member;
  return 20;
}

const void * cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__get_const_function__ShmClockInput__tzone_info(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__get_function__ShmClockInput__tzone_info(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__fetch_function__ShmClockInput__tzone_info(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__get_const_function__ShmClockInput__tzone_info(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__assign_function__ShmClockInput__tzone_info(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__get_function__ShmClockInput__tzone_info(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_message_member_array[4] = {
  {
    "shm_sec",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__ShmClockInput, shm_sec),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "utc_sec_us",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT64,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__ShmClockInput, utc_sec_us),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "utc_offset_min",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__ShmClockInput, utc_offset_min),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "tzone_info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    true,  // is array
    20,  // array size
    false,  // is upper bound
    offsetof(cpm_common_interfaces__msg__ShmClockInput, tzone_info),  // bytes offset in struct
    NULL,  // default value
    cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__size_function__ShmClockInput__tzone_info,  // size() function pointer
    cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__get_const_function__ShmClockInput__tzone_info,  // get_const(index) function pointer
    cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__get_function__ShmClockInput__tzone_info,  // get(index) function pointer
    cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__fetch_function__ShmClockInput__tzone_info,  // fetch(index, &value) function pointer
    cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__assign_function__ShmClockInput__tzone_info,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_message_members = {
  "cpm_common_interfaces__msg",  // message namespace
  "ShmClockInput",  // message name
  4,  // number of fields
  sizeof(cpm_common_interfaces__msg__ShmClockInput),
  false,  // has_any_key_member_
  cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_message_member_array,  // message members
  cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_init_function,  // function to initialize message memory (memory has to be allocated)
  cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_message_type_support_handle = {
  0,
  &cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_message_members,
  get_message_typesupport_handle_function,
  &cpm_common_interfaces__msg__ShmClockInput__get_type_hash,
  &cpm_common_interfaces__msg__ShmClockInput__get_type_description,
  &cpm_common_interfaces__msg__ShmClockInput__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_cpm_common_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cpm_common_interfaces, msg, ShmClockInput)() {
  if (!cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_message_type_support_handle.typesupport_identifier) {
    cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &cpm_common_interfaces__msg__ShmClockInput__rosidl_typesupport_introspection_c__ShmClockInput_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
