// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cpm_common_interfaces:msg/LpsSaJobMgrReqst.idl
// generated code does not contain a copyright notice
#include "cpm_common_interfaces/msg/detail/lps_sa_job_mgr_reqst__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `arg1`
// Member `arg4`
#include "rosidl_runtime_c/string_functions.h"

bool
cpm_common_interfaces__msg__LpsSaJobMgrReqst__init(cpm_common_interfaces__msg__LpsSaJobMgrReqst * msg)
{
  if (!msg) {
    return false;
  }
  // command
  // arg1
  if (!rosidl_runtime_c__String__init(&msg->arg1)) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqst__fini(msg);
    return false;
  }
  // arg2
  // arg3
  // arg4
  if (!rosidl_runtime_c__String__init(&msg->arg4)) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqst__fini(msg);
    return false;
  }
  return true;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrReqst__fini(cpm_common_interfaces__msg__LpsSaJobMgrReqst * msg)
{
  if (!msg) {
    return;
  }
  // command
  // arg1
  rosidl_runtime_c__String__fini(&msg->arg1);
  // arg2
  // arg3
  // arg4
  rosidl_runtime_c__String__fini(&msg->arg4);
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrReqst__are_equal(const cpm_common_interfaces__msg__LpsSaJobMgrReqst * lhs, const cpm_common_interfaces__msg__LpsSaJobMgrReqst * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // command
  if (lhs->command != rhs->command) {
    return false;
  }
  // arg1
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->arg1), &(rhs->arg1)))
  {
    return false;
  }
  // arg2
  if (lhs->arg2 != rhs->arg2) {
    return false;
  }
  // arg3
  if (lhs->arg3 != rhs->arg3) {
    return false;
  }
  // arg4
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->arg4), &(rhs->arg4)))
  {
    return false;
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrReqst__copy(
  const cpm_common_interfaces__msg__LpsSaJobMgrReqst * input,
  cpm_common_interfaces__msg__LpsSaJobMgrReqst * output)
{
  if (!input || !output) {
    return false;
  }
  // command
  output->command = input->command;
  // arg1
  if (!rosidl_runtime_c__String__copy(
      &(input->arg1), &(output->arg1)))
  {
    return false;
  }
  // arg2
  output->arg2 = input->arg2;
  // arg3
  output->arg3 = input->arg3;
  // arg4
  if (!rosidl_runtime_c__String__copy(
      &(input->arg4), &(output->arg4)))
  {
    return false;
  }
  return true;
}

cpm_common_interfaces__msg__LpsSaJobMgrReqst *
cpm_common_interfaces__msg__LpsSaJobMgrReqst__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaJobMgrReqst * msg = (cpm_common_interfaces__msg__LpsSaJobMgrReqst *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqst), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqst));
  bool success = cpm_common_interfaces__msg__LpsSaJobMgrReqst__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrReqst__destroy(cpm_common_interfaces__msg__LpsSaJobMgrReqst * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqst__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__init(cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaJobMgrReqst * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqst)) {
      return false;
    }
    data = (cpm_common_interfaces__msg__LpsSaJobMgrReqst *)allocator.zero_allocate(size, sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqst), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cpm_common_interfaces__msg__LpsSaJobMgrReqst__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cpm_common_interfaces__msg__LpsSaJobMgrReqst__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__fini(cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cpm_common_interfaces__msg__LpsSaJobMgrReqst__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence *
cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * array = (cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence *)allocator.allocate(sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__destroy(cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__are_equal(const cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * lhs, const cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaJobMgrReqst__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence__copy(
  const cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * input,
  cpm_common_interfaces__msg__LpsSaJobMgrReqst__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqst)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cpm_common_interfaces__msg__LpsSaJobMgrReqst);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cpm_common_interfaces__msg__LpsSaJobMgrReqst * data =
      (cpm_common_interfaces__msg__LpsSaJobMgrReqst *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cpm_common_interfaces__msg__LpsSaJobMgrReqst__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cpm_common_interfaces__msg__LpsSaJobMgrReqst__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cpm_common_interfaces__msg__LpsSaJobMgrReqst__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
