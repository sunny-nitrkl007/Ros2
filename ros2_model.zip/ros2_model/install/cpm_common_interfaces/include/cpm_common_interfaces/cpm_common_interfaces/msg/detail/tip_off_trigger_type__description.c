// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/TipOffTriggerType.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/tip_off_trigger_type__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__TipOffTriggerType__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x5b, 0x92, 0x9a, 0x4e, 0xcb, 0x6b, 0x06, 0x7f,
      0xd4, 0x22, 0x62, 0x28, 0x49, 0x6a, 0x47, 0x1b,
      0xfc, 0x36, 0x1f, 0x4d, 0x4f, 0x3b, 0x82, 0x18,
      0xbd, 0xdf, 0x7a, 0xce, 0xb6, 0x77, 0xf2, 0x6c,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__TipOffTriggerType__TYPE_NAME[] = "cpm_common_interfaces/msg/TipOffTriggerType";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__TipOffTriggerType__FIELD_NAME__value[] = "value";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__TipOffTriggerType__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__TipOffTriggerType__FIELD_NAME__value, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__TipOffTriggerType__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__TipOffTriggerType__TYPE_NAME, 43, 43},
      {cpm_common_interfaces__msg__TipOffTriggerType__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaTipOffTriggerType_t\n"
  "################################################################################\n"
  "\n"
  "uint8 AUTO=0\n"
  "uint8 MANUAL=1\n"
  "uint8 DISABLED=2\n"
  "\n"
  "uint8 value";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__TipOffTriggerType__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__TipOffTriggerType__TYPE_NAME, 43, 43},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 248, 248},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__TipOffTriggerType__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__TipOffTriggerType__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
