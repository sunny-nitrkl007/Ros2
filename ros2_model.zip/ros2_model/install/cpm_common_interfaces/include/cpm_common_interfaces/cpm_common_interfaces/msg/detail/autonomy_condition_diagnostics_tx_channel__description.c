// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/AutonomyConditionDiagnosticsTxChannel.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/autonomy_condition_diagnostics_tx_channel__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xfa, 0x1a, 0xff, 0xce, 0xf1, 0x7f, 0x6b, 0xa5,
      0xa1, 0xf0, 0xe5, 0x1e, 0xb6, 0x69, 0xe7, 0x81,
      0xfd, 0x35, 0x31, 0xe0, 0xa9, 0x59, 0x82, 0x07,
      0x63, 0xf0, 0x90, 0x7c, 0x57, 0x85, 0x72, 0x90,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "cpm_common_interfaces/msg/detail/sea__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t cpm_common_interfaces__msg__SEA__EXPECTED_HASH = {1, {
    0xfa, 0xa5, 0xf0, 0x1b, 0xf7, 0x79, 0x09, 0xfd,
    0x2c, 0x2a, 0x7f, 0x33, 0x3f, 0xdd, 0x0f, 0x0b,
    0x72, 0x6e, 0x50, 0x48, 0xac, 0x83, 0x01, 0xfa,
    0x79, 0x26, 0x94, 0x7a, 0x43, 0xc0, 0x81, 0x1a,
  }};
#endif

static char cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__TYPE_NAME[] = "cpm_common_interfaces/msg/AutonomyConditionDiagnosticsTxChannel";
static char cpm_common_interfaces__msg__SEA__TYPE_NAME[] = "cpm_common_interfaces/msg/SEA";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__FIELD_NAME__time_point_ns[] = "time_point_ns";
static char cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__FIELD_NAME__display_ethernet_bad[] = "display_ethernet_bad";
static char cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__FIELD_NAME__product_link_ethernet_bad[] = "product_link_ethernet_bad";
static char cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__FIELD_NAME__sea_list[] = "sea_list";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__FIELD_NAME__time_point_ns, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT64,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__FIELD_NAME__display_ethernet_bad, 20, 20},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__FIELD_NAME__product_link_ethernet_bad, 25, 25},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__FIELD_NAME__sea_list, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {cpm_common_interfaces__msg__SEA__TYPE_NAME, 29, 29},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {cpm_common_interfaces__msg__SEA__TYPE_NAME, 29, 29},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__TYPE_NAME, 63, 63},
      {cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__FIELDS, 4, 4},
    },
    {cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__REFERENCED_TYPE_DESCRIPTIONS, 1, 1},
  };
  if (!constructed) {
    assert(0 == memcmp(&cpm_common_interfaces__msg__SEA__EXPECTED_HASH, cpm_common_interfaces__msg__SEA__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = cpm_common_interfaces__msg__SEA__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# AutonomyConditionDiagnosticsTxInterfaceStorage\n"
  "################################################################################\n"
  "\n"
  "int64 time_point_ns\n"
  "bool display_ethernet_bad\n"
  "bool product_link_ethernet_bad\n"
  "SEA[] sea_list";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__TYPE_NAME, 63, 63},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 304, 304},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[2];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 2, 2};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__AutonomyConditionDiagnosticsTxChannel__get_individual_type_description_source(NULL),
    sources[1] = *cpm_common_interfaces__msg__SEA__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
