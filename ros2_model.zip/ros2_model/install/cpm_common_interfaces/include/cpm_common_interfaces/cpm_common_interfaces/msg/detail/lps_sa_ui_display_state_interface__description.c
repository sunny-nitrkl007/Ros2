// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LpsSaUIDisplayStateInterface.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_state_interface__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xe7, 0xd1, 0xa3, 0xc9, 0xb7, 0xbb, 0xef, 0x25,
      0x8a, 0x9d, 0x47, 0xbe, 0x45, 0x13, 0x3c, 0x9b,
      0x08, 0x01, 0xe5, 0x32, 0x9f, 0x6b, 0xcb, 0xcc,
      0xa9, 0x7b, 0x76, 0x86, 0xa7, 0x21, 0x44, 0x98,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_settings__functions.h"
#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_state__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t cpm_common_interfaces__msg__LpsSaUIDisplaySettings__EXPECTED_HASH = {1, {
    0x36, 0x9a, 0x54, 0x91, 0xf4, 0x9f, 0x2d, 0xc1,
    0x32, 0x1f, 0x36, 0x4c, 0x61, 0x94, 0xc6, 0x79,
    0x3a, 0x2e, 0xc6, 0xa7, 0x72, 0xf5, 0xd9, 0xf9,
    0x7b, 0x56, 0xec, 0xbf, 0x7e, 0x02, 0xc7, 0x6e,
  }};
static const rosidl_type_hash_t cpm_common_interfaces__msg__LpsSaUIDisplayState__EXPECTED_HASH = {1, {
    0x2e, 0xc8, 0x63, 0x74, 0x32, 0x72, 0x3d, 0xdd,
    0x32, 0x94, 0x38, 0x6f, 0xd3, 0xd1, 0x41, 0x17,
    0x0c, 0x01, 0x10, 0xaa, 0x94, 0x25, 0x04, 0x95,
    0xb0, 0x08, 0xea, 0x47, 0x04, 0x70, 0x50, 0xc5,
  }};
#endif

static char cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaUIDisplayStateInterface";
static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaUIDisplaySettings";
static char cpm_common_interfaces__msg__LpsSaUIDisplayState__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaUIDisplayState";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__FIELD_NAME__state[] = "state";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__FIELD_NAME__state, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__LpsSaUIDisplayState__TYPE_NAME, 45, 45},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__TYPE_NAME, 48, 48},
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__TYPE_NAME, 45, 45},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__TYPE_NAME, 54, 54},
      {cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__FIELDS, 1, 1},
    },
    {cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&cpm_common_interfaces__msg__LpsSaUIDisplaySettings__EXPECTED_HASH, cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&cpm_common_interfaces__msg__LpsSaUIDisplayState__EXPECTED_HASH, cpm_common_interfaces__msg__LpsSaUIDisplayState__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = cpm_common_interfaces__msg__LpsSaUIDisplayState__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaUIDisplayStateInterfaceStorage\n"
  "################################################################################\n"
  "\n"
  "LpsSaUIDisplayState state";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__TYPE_NAME, 54, 54},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 227, 227},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LpsSaUIDisplayStateInterface__get_individual_type_description_source(NULL),
    sources[1] = *cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_individual_type_description_source(NULL);
    sources[2] = *cpm_common_interfaces__msg__LpsSaUIDisplayState__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
