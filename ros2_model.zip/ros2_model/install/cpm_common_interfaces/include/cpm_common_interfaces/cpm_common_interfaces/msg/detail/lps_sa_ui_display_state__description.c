// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/LpsSaUIDisplayState.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_state__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__LpsSaUIDisplayState__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x2e, 0xc8, 0x63, 0x74, 0x32, 0x72, 0x3d, 0xdd,
      0x32, 0x94, 0x38, 0x6f, 0xd3, 0xd1, 0x41, 0x17,
      0x0c, 0x01, 0x10, 0xaa, 0x94, 0x25, 0x04, 0x95,
      0xb0, 0x08, 0xea, 0x47, 0x04, 0x70, 0x50, 0xc5,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "cpm_common_interfaces/msg/detail/lps_sa_ui_display_settings__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t cpm_common_interfaces__msg__LpsSaUIDisplaySettings__EXPECTED_HASH = {1, {
    0x36, 0x9a, 0x54, 0x91, 0xf4, 0x9f, 0x2d, 0xc1,
    0x32, 0x1f, 0x36, 0x4c, 0x61, 0x94, 0xc6, 0x79,
    0x3a, 0x2e, 0xc6, 0xa7, 0x72, 0xf5, 0xd9, 0xf9,
    0x7b, 0x56, 0xec, 0xbf, 0x7e, 0x02, 0xc7, 0x6e,
  }};
#endif

static char cpm_common_interfaces__msg__LpsSaUIDisplayState__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaUIDisplayState";
static char cpm_common_interfaces__msg__LpsSaUIDisplaySettings__TYPE_NAME[] = "cpm_common_interfaces/msg/LpsSaUIDisplaySettings";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__service_mode_enable_code_entered[] = "service_mode_enable_code_entered";
static char cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__in_service_mode[] = "in_service_mode";
static char cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__in_verification_mode[] = "in_verification_mode";
static char cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__heartbeat_count[] = "heartbeat_count";
static char cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__document_id[] = "document_id";
static char cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__weight_capacity[] = "weight_capacity";
static char cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__weight_decimal_precision[] = "weight_decimal_precision";
static char cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__weight_interval[] = "weight_interval";
static char cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__settings[] = "settings";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__service_mode_enable_code_entered, 32, 32},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__in_service_mode, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__in_verification_mode, 20, 20},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__heartbeat_count, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__document_id, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__weight_capacity, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__weight_decimal_precision, 24, 24},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__weight_interval, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELD_NAME__settings, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__TYPE_NAME, 48, 48},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription cpm_common_interfaces__msg__LpsSaUIDisplayState__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {cpm_common_interfaces__msg__LpsSaUIDisplaySettings__TYPE_NAME, 48, 48},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__LpsSaUIDisplayState__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__LpsSaUIDisplayState__TYPE_NAME, 45, 45},
      {cpm_common_interfaces__msg__LpsSaUIDisplayState__FIELDS, 9, 9},
    },
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__REFERENCED_TYPE_DESCRIPTIONS, 1, 1},
  };
  if (!constructed) {
    assert(0 == memcmp(&cpm_common_interfaces__msg__LpsSaUIDisplaySettings__EXPECTED_HASH, cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaUIDisplayState\n"
  "################################################################################\n"
  "\n"
  "bool service_mode_enable_code_entered\n"
  "bool in_service_mode\n"
  "bool in_verification_mode\n"
  "uint32 heartbeat_count\n"
  "uint16 document_id\n"
  "float32 weight_capacity\n"
  "int32 weight_decimal_precision\n"
  "float32 weight_interval\n"
  "LpsSaUIDisplaySettings settings";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__LpsSaUIDisplayState__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__LpsSaUIDisplayState__TYPE_NAME, 45, 45},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 423, 423},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__LpsSaUIDisplayState__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[2];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 2, 2};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__LpsSaUIDisplayState__get_individual_type_description_source(NULL),
    sources[1] = *cpm_common_interfaces__msg__LpsSaUIDisplaySettings__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
