// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/FloatPair.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/float_pair__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__FloatPair__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x10, 0x2b, 0x0f, 0xaa, 0x7a, 0x2c, 0x7d, 0x97,
      0x72, 0x20, 0xce, 0x5d, 0xd5, 0x7e, 0x07, 0xc2,
      0x11, 0x5d, 0x77, 0x15, 0x44, 0x91, 0x38, 0xa0,
      0xe0, 0x13, 0x88, 0x61, 0x7a, 0x93, 0x1b, 0x5b,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__FloatPair__TYPE_NAME[] = "cpm_common_interfaces/msg/FloatPair";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__FloatPair__FIELD_NAME__first[] = "first";
static char cpm_common_interfaces__msg__FloatPair__FIELD_NAME__second[] = "second";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__FloatPair__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__FloatPair__FIELD_NAME__first, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__FloatPair__FIELD_NAME__second, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__FloatPair__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__FloatPair__TYPE_NAME, 35, 35},
      {cpm_common_interfaces__msg__FloatPair__FIELDS, 2, 2},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# std::pair<float, float>\n"
  "################################################################################\n"
  "\n"
  "float32 first\n"
  "float32 second";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__FloatPair__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__FloatPair__TYPE_NAME, 35, 35},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 218, 218},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__FloatPair__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__FloatPair__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
