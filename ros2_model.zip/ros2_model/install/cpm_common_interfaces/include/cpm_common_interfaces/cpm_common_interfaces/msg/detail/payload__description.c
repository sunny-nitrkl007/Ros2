// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cpm_common_interfaces:msg/Payload.idl
// generated code does not contain a copyright notice

#include "cpm_common_interfaces/msg/detail/payload__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cpm_common_interfaces
const rosidl_type_hash_t *
cpm_common_interfaces__msg__Payload__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x7c, 0xfc, 0xab, 0xf8, 0x6d, 0xbe, 0x92, 0x76,
      0x88, 0xed, 0x8d, 0xdd, 0x6b, 0xf6, 0x93, 0x9d,
      0x35, 0x86, 0x6a, 0x6b, 0x24, 0x43, 0x6d, 0x2a,
      0x83, 0x1c, 0x71, 0x1e, 0x61, 0x11, 0x1d, 0xae,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cpm_common_interfaces__msg__Payload__TYPE_NAME[] = "cpm_common_interfaces/msg/Payload";

// Define type names, field names, and default values
static char cpm_common_interfaces__msg__Payload__FIELD_NAME__payload_ratio_raw[] = "payload_ratio_raw";
static char cpm_common_interfaces__msg__Payload__FIELD_NAME__payload_ratio[] = "payload_ratio";
static char cpm_common_interfaces__msg__Payload__FIELD_NAME__payload_ratio_status[] = "payload_ratio_status";

static rosidl_runtime_c__type_description__Field cpm_common_interfaces__msg__Payload__FIELDS[] = {
  {
    {cpm_common_interfaces__msg__Payload__FIELD_NAME__payload_ratio_raw, 17, 17},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__Payload__FIELD_NAME__payload_ratio, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cpm_common_interfaces__msg__Payload__FIELD_NAME__payload_ratio_status, 20, 20},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cpm_common_interfaces__msg__Payload__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cpm_common_interfaces__msg__Payload__TYPE_NAME, 33, 33},
      {cpm_common_interfaces__msg__Payload__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "################################################################################\n"
  "# LpsSaPayload_t\n"
  "################################################################################\n"
  "\n"
  "float32 payload_ratio_raw\n"
  "float32 payload_ratio\n"
  "int32 payload_ratio_status";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cpm_common_interfaces__msg__Payload__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cpm_common_interfaces__msg__Payload__TYPE_NAME, 33, 33},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 255, 255},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cpm_common_interfaces__msg__Payload__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cpm_common_interfaces__msg__Payload__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
