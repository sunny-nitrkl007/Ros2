import os
import yaml
from jinja2 import Environment, FileSystemLoader

# ✅ Base directory
BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ✅ Templates folder
TEMPLATE_PATH = os.path.join(BASE_PATH, "templates")

env = Environment(loader=FileSystemLoader(TEMPLATE_PATH))


# ✅ Load YAML helper
def load_yaml(path):
    full_path = os.path.join(BASE_PATH, path)
    print(f"Loading: {full_path}")
    with open(full_path) as f:
        return yaml.safe_load(f)


# ✅ Load configs
application = load_yaml("application/application.yaml")["application"]
topics = load_yaml("topics/topics.yaml")["topics"]
qos_profiles = load_yaml("qos/qos_profiles.yaml")["qos_profiles"]
parameters = load_yaml("parameters/parameters.yaml")["parameters"]


# ✅ Logging summary
print("\n✅ ===== CONFIG LOAD SUMMARY =====")
print(f"Application loaded: {application is not None}")
print(f"Application name: {application.get('name', 'N/A')}")
print(f"Domain ID: {application.get('domain_id', 'N/A')}")
print(f"\nNodes defined: {application.get('nodes', [])}")
print(f"Topics loaded: {list(topics.keys())}")
print(f"QoS profiles loaded: {list(qos_profiles.keys())}")
print(f"Parameter groups loaded: {list(parameters.keys())}")
print("✅ =================================\n")


# ✅ Resolve node fully
def resolve_node(node_name):
    node_yaml = load_yaml(f"nodes/{node_name}.yaml")["node"]

    topic_name = node_yaml["topic"]
    topic_info = topics[topic_name]

    qos = qos_profiles[node_yaml["qos"]]
    params = parameters[node_yaml["parameters"]]

    return {
        "name": node_name,
        "type": node_yaml["type"],
        "topic": topic_name,
        "message_type": topic_info["type"],
        "qos": qos,
        "parameters": params,
        "qos_name": node_yaml["qos"],
        "param_group": node_yaml["parameters"]
    }


# ✅ Message helpers

# ✅ Correct C++ type → KEEP case (String)
def msg_to_cpp(msg):
    return msg.replace("/", "::")


# ✅ Correct include → lowercase header
def msg_to_include(msg):
    parts = msg.split("/")
    parts[-1] = parts[-1].lower()
    return "/".join(parts) + ".hpp"


# ✅ Generate node
def generate_node(node):
    print(f"\n🔷 Processing node: {node['name']}")
    print(f"  Type       : {node['type']}")
    print(f"  Topic      : {node['topic']}")
    print(f"  Msg Type   : {node['message_type']}")
    print(f"  QoS        : {node['qos_name']}")
    print(f"  Parameters : {node['param_group']}")

    msg_type = msg_to_cpp(node["message_type"])
    msg_include = msg_to_include(node["message_type"])

    # ✅ Generate .cpp
    template_name = f"{node['type']}.cpp.jinja"
    template = env.get_template(template_name)

    rendered_cpp = template.render(
        node=node,
        msg_type=msg_type,
        msg_include=msg_include
    )

    cpp_path = f"generated_pkg/src/{node['name']}.cpp"
    print(f"  ➜ Generating source: {cpp_path}")
    with open(cpp_path, "w") as f:
        f.write(rendered_cpp)

    # ✅ Generate .hpp
    header_template = env.get_template("node.hpp.jinja")

    rendered_hpp = header_template.render(
        node=node,
        msg_type=msg_type,
        msg_include=msg_include
    )

    hpp_path = f"generated_pkg/include/{node['name']}.hpp"
    print(f"  ➜ Generating header: {hpp_path}")
    with open(hpp_path, "w") as f:
        f.write(rendered_hpp)


# ✅ Generate CMake and package
def generate_package(nodes):
    print("\n📦 Generating package files...")

    cmake_template = env.get_template("CMakeLists.txt.jinja")
    cmake = cmake_template.render(nodes=nodes)

    with open("generated_pkg/CMakeLists.txt", "w") as f:
        f.write(cmake)

    package_template = env.get_template("package.xml.jinja")
    package = package_template.render()

    with open("generated_pkg/package.xml", "w") as f:
        f.write(package)

    print("  ➜ CMakeLists.txt generated")
    print("  ➜ package.xml generated")


# ✅ MAIN
def main():
    print("\n🚀 Starting code generation...\n")

    os.makedirs("generated_pkg/src", exist_ok=True)
    os.makedirs("generated_pkg/include", exist_ok=True)

    resolved_nodes = []

    for node_name in application["nodes"]:
        node = resolve_node(node_name)
        resolved_nodes.append(node)
        generate_node(node)

    generate_package(resolved_nodes)

    print("\n🚀 ===== GENERATION COMPLETE =====")
    print(f"Generated nodes: {application['nodes']}")
    print("Output directory: generated_pkg/")
    print("✅ Ready for colcon build")
    print("=================================\n")


if __name__ == "__main__":
    main()