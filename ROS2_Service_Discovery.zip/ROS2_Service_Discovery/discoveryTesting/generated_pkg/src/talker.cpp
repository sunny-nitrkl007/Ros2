#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "talker.hpp"

using namespace std::chrono_literals;

Talker::Talker()
    : Node("talker")
{
    this->declare_parameter<double>("publish_rate", 2.0);
    publish_rate_ = this->get_parameter("publish_rate").as_double();

    rclcpp::QoS qos(rclcpp::KeepLast(10));

    
    qos.reliable();
    

    publisher_ = this->create_publisher<std_msgs::msg::String>(
        "chatter", qos);

    timer_ = this->create_wall_timer(
        std::chrono::milliseconds(500),
        std::bind(&Talker::publish_message, this));
}

void Talker::publish_message()
{
    auto msg = std_msgs::msg::String();
    msg.data = "Hello ROS2!";
    publisher_->publish(msg);
}

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<Talker>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}