#include "listener.hpp"
#include "std_msgs/msg/string.hpp"

Listener::Listener() : Node("listener")
{



    chatter_sub = this->create_subscription<std_msgs/msg/String>(
        "/chatter",
        10,
        std::bind(&Listener::on_message,
                  this, std::placeholders::_1));

}


void Listener::on_message(const std_msgs/msg/String::SharedPtr msg)
{
    RCLCPP_INFO(this->get_logger(), "Message received");
}
