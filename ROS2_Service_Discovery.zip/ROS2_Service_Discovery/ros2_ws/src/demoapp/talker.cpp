#include "talker.hpp"
#include "std_msgs/msg/string.hpp"

Talker::Talker() : Node("talker")
{

    chatter_pub = this->create_publisher<std_msgs/msg/String>(
        "/chatter", 10);



}

