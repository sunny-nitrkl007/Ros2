#pragma once
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

class Listener : public rclcpp::Node
{
public:
    Listener();

private:



    rclcpp::Subscription<std_msgs/msg/String>::SharedPtr chatter_sub;



    void on_message(const std_msgs/msg/String::SharedPtr msg);

};