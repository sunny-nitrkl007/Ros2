#pragma once
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

class Talker : public rclcpp::Node
{
public:
    Talker();

private:

    rclcpp::Publisher<std_msgs/msg/String>::SharedPtr chatter_pub;





};