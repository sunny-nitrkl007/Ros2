from launch_ros.actions import Node

Node(
    package='demo_pkg',
    executable='talker_node',
    name='talker'
)