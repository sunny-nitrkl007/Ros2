from jinja2 import Environment, FileSystemLoader
from pathlib import Path


# ✅ Setup Jinja environment



# ✅ Go to project root (one level up from scripts/)
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# ✅ Templates folder is here
TEMPLATE_DIR = PROJECT_ROOT / "templates"

print(f"[DEBUG] Template dir: {TEMPLATE_DIR}")

env = Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)))



# =========================================================
# ✅ NODE FILES
# =========================================================
def generate_nodes(model, output_path):

    hpp_template = env.get_template("node.hpp.j2")
    cpp_template = env.get_template("node.cpp.j2")

    for node in model.nodes.values():

        context = {
            "node_name": node.name,
            "class_name": node.class_name,
            "publishers": node.publishers,
            "subscribers": node.subscribers,
        }

        # HPP
        hpp_code = hpp_template.render(context)
        (output_path / f"{node.name}.hpp").write_text(hpp_code)

        # CPP
        cpp_code = cpp_template.render(context)
        (output_path / f"{node.name}.cpp").write_text(cpp_code)


# =========================================================
# ✅ MAIN FILE
# =========================================================
def generate_main(model, output_path):

    template = env.get_template("main.cpp.j2")

    nodes = list(model.nodes.values())

    output = template.render(nodes=nodes)

    (output_path / "main.cpp").write_text(output)


# =========================================================
# ✅ COMMON FILES: CMake, package.xml, launch
# =========================================================
def generate_common_files(model, output_path):

    nodes = list(model.nodes.values())

    files = [
        ("CMakeLists.txt.j2", "CMakeLists.txt"),
        ("package.xml.j2", "package.xml"),
        ("launch.py.j2", "system.launch.py"),
    ]

    for template_name, output_name in files:
        template = env.get_template(template_name)
        rendered = template.render(nodes=nodes)

        (output_path / output_name).write_text(rendered)