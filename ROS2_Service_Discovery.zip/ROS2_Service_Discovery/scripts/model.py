class Node:
    def __init__(self, name):
        self.name = name
        self.class_name = name.capitalize()
        self.publishers = []
        self.subscribers = []
        self.parameters = []


class Publisher:
    def __init__(self, name, topic, msg_type):
        self.name = name
        self.topic = topic
        self.msg_type = msg_type


class Subscriber:
    def __init__(self, name, topic, msg_type, callback):
        self.name = name
        self.topic = topic
        self.msg_type = msg_type
        self.callback = callback


class Model:
    def __init__(self):
        self.nodes = {}

def convert_msg_type(msg):
    return msg.replace("/", "::")

def build_model(configs):
    model = Model()

    for node_name, node_yaml in configs["nodes"].items():

        node_data = node_yaml["node"]
        node_obj = Node(node_name)

        # Publishers
        for pub in node_data.get("publishers", []):
            node_obj.publishers.append(
                Publisher(
                    pub["name"],
                    pub["topic"],
                    pub["type"]
                )
            )

        # Subscribers
        for sub in node_data.get("subscribers", []):
            node_obj.subscribers.append(
                Subscriber(
                    sub["name"],
                    sub["topic"],
                    sub["type"],
                    sub["callback"]
                )
            )

        # Parameters (optional for now)
        node_obj.parameters = node_data.get("parameters", [])

        model.nodes[node_name] = node_obj

    return model