#!/usr/bin/env python3

import sys
from pathlib import Path

from loader import load_all_configs
from model import build_model
from node_gen import generate_nodes, generate_main, generate_common_files


def main():
    if len(sys.argv) != 3:
        print("Usage: python generator.py <config_path> <output_path>")
        sys.exit(1)

    config_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    output_path.mkdir(parents=True, exist_ok=True)

    print("[INFO] Loading YAML configs...")
    configs = load_all_configs(config_path)

    print("\n[DEBUG] ===== CONFIG SUMMARY =====")

    print(f"Application: {configs['application'] is not None}")
    print(f"Topology: {configs['topology'] is not None}")
    print(f"Nodes: {list(configs['nodes'].keys())}")
    print(f"QoS: {configs['qos'] is not None}")
    print(f"Parameters: {configs['parameters'] is not None}")
    print(f"Executors: {configs['executors'] is not None}")
    print(f"Callback Groups: {configs['callback_groups'] is not None}")

    print("=================================\n")

    print("[INFO] Building internal model...")
    model = build_model(configs)

    print("[INFO] Generating node code...")
    generate_nodes(model, output_path)

    print("[INFO] Generating main...")
    generate_main(model, output_path)

    print("[INFO] Generating CMake / package / launch...")
    generate_common_files(model, output_path)

    print("\n✅ GENERATION COMPLETE ✅")


if __name__ == "__main__":
    main()
