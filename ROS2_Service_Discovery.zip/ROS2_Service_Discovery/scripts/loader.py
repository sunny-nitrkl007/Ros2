import yaml
from pathlib import Path


def load_yaml(file_path):
    try:
        with open(file_path, "r") as f:
            return yaml.safe_load(f)
    except Exception:
        return None


def load_all_configs(base_path: Path):
    all_yaml = {}

    for file in base_path.rglob("*.yaml"):
        data = load_yaml(file)
        if data:
            all_yaml[file.stem] = data

    return classify_configs(all_yaml)


def classify_configs(all_yaml):
    configs = {
        "application": None,
        "topology": None,
        "nodes": {},
        "qos": None,
        "parameters": None,
        "executors": None,
        "callback_groups": None,
    }

    for _, data in all_yaml.items():

        yaml_type = data.get("type")

        if yaml_type == "application":
            configs["application"] = data

        elif yaml_type == "topology":
            configs["topology"] = data

        elif yaml_type == "node":
            node_name = data["node"]["name"]
            configs["nodes"][node_name] = data

        elif yaml_type == "qos":
            configs["qos"] = data

        elif yaml_type == "parameters":
            configs["parameters"] = data

        elif yaml_type == "executors":
            configs["executors"] = data

        elif yaml_type == "callback_groups":
            configs["callback_groups"] = data

    return configs