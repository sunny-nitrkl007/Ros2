/*******************************************************************************
** COPYRIGHT (C) 2026 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: JobMgrScsRos2Bridge.h
DESCRIPTION:
    Provides the AIS-SCS leg for 5 channels that LpsSaJobMgrApp now handles
    exclusively via ROS2. Each channel is bridged in exactly one direction:

        LpsSaJobMgrReqstChannel : AIS SCS -> ROS2  (original 3 -- regression fix)
        LpsSaJobMgrRespChannel  : ROS2 -> AIS SCS
        AisJhm2TxChannel        : AIS SCS -> ROS2

        SwitchInputScs          : AIS SCS -> ROS2  (newly ported channels)
        LpsSaLoadRecordChannel  : ROS2 -> AIS SCS

    See porting_artefacts/plan.md and apps/JobMgrScsRos2Bridge/README.md.
*******************************************************************************/
#ifndef JOBMGRSCSROS2BRIDGE_H
#define JOBMGRSCSROS2BRIDGE_H

#include <memory>
#include <string>

#include <ais/task/Task.h>
#include <ais/log/AisLogger.h>

#include <interfaces/LpsSaJobMgrReqstChannel/InterfaceTypes.h>
#include <interfaces/LpsSaJobMgrRespChannel/InterfaceTypes.h>
#include <interfaces/AisJhm2TxChannel/InterfaceTypes.h>
#include <interfaces/SwitchInputScs/InterfaceTypes.h>
#include <interfaces/LpsSaLoadRecordChannel/Channel/Output/channel.h>
#include <interfaces/LpsSaLoadRecordChannel/LpsSaLoadRecordChannel.h>

/* ROS2/DDS wrapper + generated message headers */
#include "rclcpp/rclcpp.hpp"
#include "ros2wrapper/RosInputInterface.h"
#include "ros2wrapper/RosOutputInterface.h"
#include <cpm_common_interfaces/msg/lps_sa_job_mgr_reqst_channel.hpp>
#include <job_mgr_interfaces/msg/lps_sa_job_mgr_resp_channel.hpp>
#include <cpm_common_interfaces/msg/ais_jhm2_tx_channel.hpp>
#include <job_mgr_interfaces/msg/switch_input_scs.hpp>
#include <job_mgr_interfaces/msg/lps_sa_load_record_channel.hpp>

class JobMgrScsRos2Bridge: public task::Task
{
public:
    JobMgrScsRos2Bridge( const std::string& taskName );
    virtual ~JobMgrScsRos2Bridge( );

    virtual bool initialize( );
    virtual bool executive( );
    virtual void cleanup( );

private:
    /*----------------------------------------------------------------------
    ** AIS SCS side. Bound via InterfaceDb::bind, exactly like
    ** hornOnStoreTest.h binds LpsSaJobMgrReqstChannelOutput/
    ** LpsSaJobMgrTxChannelInput today -- real, working precedent in this
    ** repo for a standalone process binding these interface names.
    **--------------------------------------------------------------------*/
    LpsSaJobMgrReqstChannelInput*  jobMgrReqstScsIn_;   /* subscribe: requests from WorkOrderAssist / hornOnStoreTest / AisJhm2RequestProcessor / LpsSaWeighApp */
    LpsSaJobMgrRespChannelOutput*  jobMgrRespScsOut_;   /* publish: forwards JobMgr's ack to AutonomyConditionDiagnostics / aisXcpServer / AisJhm2RequestProcessor */
    AisJhm2TxChannelInput*         aisJhm2TxScsIn_;     /* subscribe: JHM2 dispatch data from AisJhm2RequestProcessor */
    SwitchInputScsInput*           switchInputScsIn_;    /* subscribe: SwitchInputApp's store/tip-off button states */
    LpsSaLoadRecordChannelOutputChannel* loadRecordScsOut_; /* publish: forwards ROS2 load records to LpsSaTotalsApp/WorkOrderAssist/AisJhm2RequestProcessor */

    /*----------------------------------------------------------------------
    ** ROS2 side. One shared node + executor for this process, mirroring
    ** the pattern already used in LpsSaJobMgrApp.h/LpsSaWeighApp.h.
    **--------------------------------------------------------------------*/
    rclcpp::Node::SharedPtr rosNode_;
    rclcpp::executors::SingleThreadedExecutor executor_;

    std::unique_ptr<ros2_wrapper::RosOutputInterface<cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel>> jobMgrReqstRosOut_;
    std::unique_ptr<ros2_wrapper::RosInputInterface<job_mgr_interfaces::msg::LpsSaJobMgrRespChannel>>       jobMgrRespRosIn_;
    std::unique_ptr<ros2_wrapper::RosOutputInterface<cpm_common_interfaces::msg::AisJhm2TxChannel>>         aisJhm2TxRosOut_;
    std::unique_ptr<ros2_wrapper::RosOutputInterface<job_mgr_interfaces::msg::SwitchInputScs>>              switchInputRosOut_;
    std::unique_ptr<ros2_wrapper::RosInputInterface<job_mgr_interfaces::msg::LpsSaLoadRecordChannel>>       loadRecordRosIn_;

    /* Conversion helpers -- pure, no side effects, no I/O. Static private
       methods rather than free functions so they stay scoped to this class
       instead of polluting translation-unit-global namespace. */
    static cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel convertJobMgrReqstToRos(const LpsSaJobMgrReqstChannel& scs);
    static LpsSaJobMgrRespChannel convertJobMgrRespToScs(const job_mgr_interfaces::msg::LpsSaJobMgrRespChannel& ros);
    static cpm_common_interfaces::msg::AisJhm2TxChannel convertAisJhm2TxToRos(const AisJhm2TxChannel& scs);
    static job_mgr_interfaces::msg::SwitchInputScs convertSwitchInputToRos(const SwitchInputScs& scs);
    static LpsSaLoadRecordChannel convertLoadRecordToScs(const job_mgr_interfaces::msg::LpsSaLoadRecordChannel& ros);
};

#endif
