/*******************************************************************************
** COPYRIGHT (C) 2026 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: JobMgrScsRos2Bridge.cpp
DESCRIPTION: See JobMgrScsRos2Bridge.h for the design rationale.
*******************************************************************************/
#include "JobMgrScsRos2Bridge.h"

using namespace task;

/******************************************************************************
FUNCTION NAME:task::getTaskImplementation
*******************************************************************************/
AbstractTaskCore* task::getTaskImplementation(void)
{
    rclcpp::init(0, nullptr);
    std::cout << "[ROS2][Initialized][JOB_MGR_SCS_ROS2_BRIDGE]";
    static JobMgrScsRos2Bridge thisTask("JobMgrScsRos2Bridge");
    return dynamic_cast<Task *>(&thisTask);
}

/******************************************************************************
FUNCTION NAME:JobMgrScsRos2Bridge::JobMgrScsRos2Bridge()
*******************************************************************************/
JobMgrScsRos2Bridge::JobMgrScsRos2Bridge(const std::string& taskName):
    Task(taskName),
    jobMgrReqstScsIn_(nullptr),
    jobMgrRespScsOut_(nullptr),
    aisJhm2TxScsIn_(nullptr),
    switchInputScsIn_(nullptr),
    loadRecordScsOut_(nullptr),
    rosNode_(nullptr),
    executor_(),
    jobMgrReqstRosOut_(),
    jobMgrRespRosIn_(),
    aisJhm2TxRosOut_(),
    switchInputRosOut_(),
    loadRecordRosIn_()
{
}

/******************************************************************************
FUNCTION NAME:JobMgrScsRos2Bridge::~JobMgrScsRos2Bridge()
*******************************************************************************/
JobMgrScsRos2Bridge::~JobMgrScsRos2Bridge()
{
}

/******************************************************************************
FUNCTION NAME:JobMgrScsRos2Bridge::initialize
DESCRIPTION: Binds the AIS SCS side (same interface names LpsSaJobMgrApp used
    to bind before its ROS2-only cutover) and sets up the ROS2 side (same
    topic names LpsSaJobMgrApp already publishes/subscribes on).
*******************************************************************************/
bool JobMgrScsRos2Bridge::initialize()
{
    bool everythingOk = true;

    getLogger().log_info("JobMgrScsRos2Bridge::initialize");

    if (!rclcpp::ok()) {
        rclcpp::init(0, nullptr);
    }
    rosNode_ = std::make_shared<rclcpp::Node>("job_mgr_scs_ros2_bridge_node");
    executor_.add_node(rosNode_);

    /* AIS SCS side */
    if (!task::InterfaceDb::bind("LpsSaJobMgrReqstChannelInput", jobMgrReqstScsIn_)) {
        AIS_LOG_ERROR("LpsSaJobMgrReqstChannelInput Interface not configured.");
        everythingOk = false;
    }

    if (!task::InterfaceDb::bind("LpsSaJobMgrRespChannelOutput", jobMgrRespScsOut_)) {
        AIS_LOG_ERROR("LpsSaJobMgrRespChannelOutput Interface not configured.");
        everythingOk = false;
    }

    if (!task::InterfaceDb::bind("AisJhm2TxChannelInput", aisJhm2TxScsIn_)) {
        AIS_LOG_ERROR("AisJhm2TxChannelInput Interface not configured.");
        everythingOk = false;
    }

    if (!task::InterfaceDb::bind("SwitchInputScsInput", switchInputScsIn_)) {
        AIS_LOG_ERROR("SwitchInputScsInput Interface not configured.");
        everythingOk = false;
    }

    if (!task::InterfaceDb::bind("LoadRecordOutput", loadRecordScsOut_)) {
        AIS_LOG_ERROR("LoadRecordOutput Interface not configured.");
        everythingOk = false;
    }

    /* ROS2 side -- topic names matching what LpsSaJobMgrApp subscribes/publishes */
    jobMgrReqstRosOut_ = std::make_unique<ros2_wrapper::RosOutputInterface<cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel>>(
            rosNode_, "lps_sa_job_mgr_reqst_channel");
    jobMgrRespRosIn_ = std::make_unique<ros2_wrapper::RosInputInterface<job_mgr_interfaces::msg::LpsSaJobMgrRespChannel>>(
            rosNode_, "lps_sa_job_mgr_resp_channel");
    aisJhm2TxRosOut_ = std::make_unique<ros2_wrapper::RosOutputInterface<cpm_common_interfaces::msg::AisJhm2TxChannel>>(
            rosNode_, "ais_jhm2_tx_channel");
    switchInputRosOut_ = std::make_unique<ros2_wrapper::RosOutputInterface<job_mgr_interfaces::msg::SwitchInputScs>>(
            rosNode_, "switch_input_scs");
    loadRecordRosIn_ = std::make_unique<ros2_wrapper::RosInputInterface<job_mgr_interfaces::msg::LpsSaLoadRecordChannel>>(
            rosNode_, "lps_sa_load_record_channel");

    if (!jobMgrReqstRosOut_ || !jobMgrRespRosIn_ || !aisJhm2TxRosOut_ || !switchInputRosOut_ || !loadRecordRosIn_) {
        AIS_LOG_ERROR("Failed to initialize one or more ROS2 wrapper interfaces.");
        everythingOk = false;
    }

    return everythingOk;
}

/******************************************************************************
FUNCTION NAME:JobMgrScsRos2Bridge::executive
DESCRIPTION: Drains each side and forwards to the other, one direction per
    channel (see JobMgrScsRos2Bridge.h for the direction table).
*******************************************************************************/
bool JobMgrScsRos2Bridge::executive()
{
    executor_.spin_some();

    /* Forward 1: LpsSaJobMgrReqstChannel, AIS SCS -> ROS2 */
    if (nullptr != jobMgrReqstScsIn_) {
        LpsSaJobMgrReqstChannel reqScs;
        while (jobMgrReqstScsIn_->get(reqScs)) {
            cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel reqRos = convertJobMgrReqstToRos(reqScs);
            if (!jobMgrReqstRosOut_->publish(reqRos)) {
                AIS_LOG_ERROR("Failed to forward LpsSaJobMgrReqstChannel SCS->ROS2");
            }
        }
    }

    /* Forward 2: LpsSaJobMgrRespChannel, ROS2 -> AIS SCS */
    if (nullptr != jobMgrRespRosIn_) {
        job_mgr_interfaces::msg::LpsSaJobMgrRespChannel respRos;
        while (jobMgrRespRosIn_->get(respRos)) {
            LpsSaJobMgrRespChannel respScs = convertJobMgrRespToScs(respRos);
            if (nullptr != jobMgrRespScsOut_) {
                if (!jobMgrRespScsOut_->publish(respScs)) {
                    AIS_LOG_ERROR("Failed to forward LpsSaJobMgrRespChannel ROS2->SCS");
                }
            }
        }
    }

    /* Forward 3: AisJhm2TxChannel, AIS SCS -> ROS2 */
    if (nullptr != aisJhm2TxScsIn_) {
        AisJhm2TxChannel jhmScs;
        while (aisJhm2TxScsIn_->get(jhmScs)) {
            cpm_common_interfaces::msg::AisJhm2TxChannel jhmRos = convertAisJhm2TxToRos(jhmScs);
            if (!aisJhm2TxRosOut_->publish(jhmRos)) {
                AIS_LOG_ERROR("Failed to forward AisJhm2TxChannel SCS->ROS2");
            }
        }
    }

    /* Forward 4: SwitchInputScs, AIS SCS -> ROS2 */
    if (nullptr != switchInputScsIn_) {
        SwitchInputScs swScs;
        while (switchInputScsIn_->get(swScs)) {
            job_mgr_interfaces::msg::SwitchInputScs swRos = convertSwitchInputToRos(swScs);
            if (!switchInputRosOut_->publish(swRos)) {
                AIS_LOG_ERROR("Failed to forward SwitchInputScs SCS->ROS2");
            }
        }
    }

    /* Forward 5: LpsSaLoadRecordChannel, ROS2 -> AIS SCS */
    if (nullptr != loadRecordRosIn_) {
        job_mgr_interfaces::msg::LpsSaLoadRecordChannel lrRos;
        while (loadRecordRosIn_->get(lrRos)) {
            LpsSaLoadRecordChannel lrScs = convertLoadRecordToScs(lrRos);
            if (nullptr != loadRecordScsOut_) {
                if (!loadRecordScsOut_->publish(lrScs)) {
                    AIS_LOG_ERROR("Failed to forward LpsSaLoadRecordChannel ROS2->SCS");
                }
            }
        }
    }

    return true;
}

/******************************************************************************
FUNCTION NAME:JobMgrScsRos2Bridge::cleanup
*******************************************************************************/
void JobMgrScsRos2Bridge::cleanup()
{
    AIS_LOG_INFO("JobMgrScsRos2Bridge::cleanup");
    if (rclcpp::ok()) {
        rclcpp::shutdown();
    }
}

/******************************************************************************
FUNCTION NAME:JobMgrScsRos2Bridge::convertJobMgrReqstToRos
DESCRIPTION: LpsSaJobMgrReqstChannelStorage (AIS SCS) -> cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel (ROS2)
    Field-for-field mapping, verified against both:
      prod/common/interfaces/LpsSaJobMgrReqstChannel/LpsSaJobMgrReqstChannel.h
      ros2_model/src/cpm_common_interfaces/msg/LpsSaJobMgrReqstChannel.msg (+ nested .msg files)
    Enum numeric values line up 1:1 on both sides (both ultimately trace back
    to the same TIP_OFF_* #defines in LpsPtPublic.h), so plain static_cast is safe.
*******************************************************************************/
cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel JobMgrScsRos2Bridge::convertJobMgrReqstToRos(const LpsSaJobMgrReqstChannel& scs)
{
    cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel ros;

    ros.app_name = scs.appName;
    ros.app_request_id = scs.appRequestId;

    ros.command.value = static_cast<uint8_t>(scs.command);

    ros.data_tipoff_trigger_type.value = static_cast<uint8_t>(scs.data.tipoffTriggerType);
    ros.data_tipoff_mode.value = static_cast<uint8_t>(scs.data.tipoffMode);
    ros.data_auto_store_pass_count = scs.data.autoStorePassCount;
    ros.data_task_number = scs.data.taskNumber;
    ros.data_enabled = scs.data.enabled;
    ros.data_target_type = scs.data.targetType;
    ros.data_subtotal_index = scs.data.subtotalIndex;
    ros.data_total_target_weight = scs.data.totalTargetWeight;

    ros.data_subtotal_info.subtotal_command = scs.data.subtotalInfo.command;
    ros.data_subtotal_info.current_step_number = scs.data.subtotalInfo.currentStepNumber;
    ros.data_subtotal_info.new_step_number = scs.data.subtotalInfo.newStepNumber;
    ros.data_subtotal_info.target_weight = scs.data.subtotalInfo.targetWeight;
    ros.data_subtotal_info.target_proportion = scs.data.subtotalInfo.targetProportion;
    ros.data_subtotal_info.target_passes = scs.data.subtotalInfo.targetPasses;
    ros.data_subtotal_info.material_id = scs.data.subtotalInfo.materialId;
    ros.data_subtotal_info.material_name = scs.data.subtotalInfo.materialName;
    ros.data_subtotal_info.material_density = scs.data.subtotalInfo.materialDensity;
    ros.data_subtotal_info.icon_type = scs.data.subtotalInfo.iconType;

    ros.requests.reserve(scs.requests.size());
    for (const auto& r : scs.requests) {
        cpm_common_interfaces::msg::LpsSaJobMgrReqst reqRos;
        reqRos.command = LpsSaJobMgrReqstCommand_Base_t(r.command);
        reqRos.arg1 = r.tagValue();   // arg1 is private; every accessor (materialName/truckName/tagValue) reads the same underlying arg1
        reqRos.arg2 = r.materialDensity(); // arg2 is private; materialDensity/truckTargetWeight alias the same underlying arg2
        reqRos.arg3 = r.materialId();  // arg3 is private; materialId/truckId alias the same underlying arg3
        reqRos.arg4 = r.tagName();
        ros.requests.push_back(reqRos);
    }

    return ros;
}

/******************************************************************************
FUNCTION NAME:JobMgrScsRos2Bridge::convertJobMgrRespToScs
DESCRIPTION: job_mgr_interfaces::msg::LpsSaJobMgrRespChannel (ROS2) -> LpsSaJobMgrRespChannelStorage (AIS SCS)
    Field-for-field mapping, verified against:
      prod/common/interfaces/LpsSaJobMgrRespChannel/LpsSaJobMgrRespChannel.h
      ros2_model/src/job_mgr_interfaces/msg/LpsSaJobMgrRespChannel.msg
*******************************************************************************/
LpsSaJobMgrRespChannel JobMgrScsRos2Bridge::convertJobMgrRespToScs(const job_mgr_interfaces::msg::LpsSaJobMgrRespChannel& ros)
{
    LpsSaJobMgrRespChannel scs;

    scs.appName = ros.app_name;
    scs.appRequestId = ros.app_request_id;
    scs.timePoint = std::chrono::steady_clock::time_point(
            std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::nanoseconds(ros.time_point_ns)));
    scs.command = static_cast<LpsSaJobMgrReqstChannel::Command>(ros.command.value);
    scs.success = ros.success;

    return scs;
}

/******************************************************************************
FUNCTION NAME:JobMgrScsRos2Bridge::convertAisJhm2TxToRos
DESCRIPTION: AisJhm2TxChannelStorage (AIS SCS) -> cpm_common_interfaces::msg::AisJhm2TxChannel (ROS2)
    Field-for-field mapping, verified against:
      prod/common/interfaces/AisJhm2TxChannel/AisJhm2TxChannel.h
      ros2_model/src/cpm_common_interfaces/msg/AisJhm2TxChannel.msg (+ SimpleCalDataT.msg, TipoffWeightAdjustData.msg)
*******************************************************************************/
cpm_common_interfaces::msg::AisJhm2TxChannel JobMgrScsRos2Bridge::convertAisJhm2TxToRos(const AisJhm2TxChannel& scs)
{
    cpm_common_interfaces::msg::AisJhm2TxChannel ros;

    ros.simplecal_data.time_stamp = scs.simplecal_data.timeStamp;
    ros.simplecal_data.adjtruckweight = scs.simplecal_data.adjtruckweight;
    ros.simplecal_data.zeroed_truck_wt = scs.simplecal_data.zeroedTruckWt;
    ros.simplecal_data.new_data_flag = scs.simplecal_data.newDataFlag;

    ros.tipoff_weight_adjust_data.tip_off_weight1 = scs.tipoff_weight_adjust_data.tipOffWeight1;
    ros.tipoff_weight_adjust_data.weigh_range_weight1 = scs.tipoff_weight_adjust_data.weighRangeWeight1;
    ros.tipoff_weight_adjust_data.tip_off_weight2 = scs.tipoff_weight_adjust_data.tipOffWeight2;
    ros.tipoff_weight_adjust_data.weigh_range_weight2 = scs.tipoff_weight_adjust_data.weighRangeWeight2;
    ros.tipoff_weight_adjust_data.new_data_flag = scs.tipoff_weight_adjust_data.newDataFlag;
    ros.tipoff_weight_adjust_data.reset = scs.tipoff_weight_adjust_data.reset;

    return ros;
}

/******************************************************************************
FUNCTION NAME: JobMgrScsRos2Bridge::convertSwitchInputToRos
DESCRIPTION: SwitchInputScsStorage -> job_mgr_interfaces::msg::SwitchInputScs
    AIS side: int STG_values[4] (values 0=OPEN,1=CLOSED,2=UNKNOWN -- enum STG)
    ROS2 side: std::array<STG_, 4> stg_values where STG_.value maps the same ints.
    Confirmed from SwitchInputApp.cpp: STG4 written into index [3], same enum values.
*******************************************************************************/
job_mgr_interfaces::msg::SwitchInputScs JobMgrScsRos2Bridge::convertSwitchInputToRos(const SwitchInputScs& scs)
{
    job_mgr_interfaces::msg::SwitchInputScs ros;
    for (int i = 0; i < NO_OF_STG_INPUTS; ++i) {
        ros.stg_values[i].value = static_cast<uint8_t>(scs.get_STG_value(i));
    }
    return ros;
}

/******************************************************************************
FUNCTION NAME: JobMgrScsRos2Bridge::convertLoadRecordToScs
DESCRIPTION: job_mgr_interfaces::msg::LpsSaLoadRecordChannel -> LpsSaLoadRecordChannelStorage
    Reverse of LpsSaJobMgrApp::convertLoadRecordToRos (LpsSaJobMgrProcess.cpp).
    All fields set via public setters or direct public member access.
    chrono: utc_time_ns (int64 nanoseconds since epoch) -> system_clock::time_point.
    Weight units: int32 -> LpsCommonWeightUnits (uint16_t enum class, same underlying value).
*******************************************************************************/
LpsSaLoadRecordChannel JobMgrScsRos2Bridge::convertLoadRecordToScs(const job_mgr_interfaces::msg::LpsSaLoadRecordChannel& ros)
{
    LpsSaLoadRecordChannel scs;

    scs.storeAction(static_cast<LpsSaLoadRecordStoreAction>(ros.store_action));
    scs.ticketNumber(ros.ticket_number);

    scs.productId(ros.product_id);
    scs.equipmentId(ros.equipment_id);
    scs.weightInterval(ros.weight_interval);
    scs.weightDecimalPrecision(ros.weight_decimal_precision);
    scs.weightUnits(static_cast<LpsCommonWeightUnits>(static_cast<uint16_t>(ros.weight_units)));

    scs.recipeName(ros.recipe_name);
    scs.setTargetType(static_cast<LpsSaLoadRecordTargetType>(ros.target_type));
    scs.setTotalTargetWeight(ros.total_target_weight);

    scs.storeTime.utcTime = std::chrono::system_clock::time_point(
            std::chrono::duration_cast<std::chrono::system_clock::duration>(
                    std::chrono::nanoseconds(ros.store_time.utc_time_ns)));
    scs.storeTime.shmTime = ros.store_time.shm_time;

    /* Convert subtotals using public API (setters + addPass) */
    auto convertSubtotal = [](const job_mgr_interfaces::msg::LoadRecordSubtotal& rs,
                               LpsSaLoadRecordSubtotal& s)
    {
        s.startTime.utcTime = std::chrono::system_clock::time_point(
                std::chrono::duration_cast<std::chrono::system_clock::duration>(
                        std::chrono::nanoseconds(rs.start_time.utc_time_ns)));
        s.startTime.shmTime  = rs.start_time.shm_time;
        s.endTime.utcTime = std::chrono::system_clock::time_point(
                std::chrono::duration_cast<std::chrono::system_clock::duration>(
                        std::chrono::nanoseconds(rs.end_time.utc_time_ns)));
        s.endTime.shmTime    = rs.end_time.shm_time;

        s.truckId                   = rs.truck_id;
        s.truckName                 = rs.truck_name;
        s.truckTargetWeightTonnes   = rs.truck_target_weight_tonnes;
        s.targetProportion          = rs.target_proportion;
        s.targetPasses              = rs.target_passes;
        s.materialId                = rs.material_id;
        s.materialName              = rs.material_name;
        s.materialDensity           = rs.material_density;
        s.customListName1           = rs.custom_list_name1;
        s.customListName2           = rs.custom_list_name2;
        s.customListName3           = rs.custom_list_name3;
        s.customListName4           = rs.custom_list_name4;
        s.tag1                      = rs.tag1;
        s.tag2                      = rs.tag2;
        s.tag3                      = rs.tag3;
        s.tag4                      = rs.tag4;
        s.iconType                  = rs.icon_type;
        s.zeroWeight                = rs.zero_weight;
        s.calAdjust                 = rs.cal_adjust;

        for (const auto& rp : rs.passes) {
            LpsSaLoadRecordPass p;
            p.weightTonnes = rp.weight_tonnes;
            p.calcMethod   = rp.calc_method;
            p.time.utcTime = std::chrono::system_clock::time_point(
                    std::chrono::duration_cast<std::chrono::system_clock::duration>(
                            std::chrono::nanoseconds(rp.time.utc_time_ns)));
            p.time.shmTime = rp.time.shm_time;
            s.addPassRaw(p);
        }
    };

    convertSubtotal(ros.subtotal, scs.getCurrentSubtotal());
    for (const auto& rsub : ros.subtotals) {
        LpsSaLoadRecordSubtotal sub;
        convertSubtotal(rsub, sub);
        scs.addSubtotalRaw(sub);
    }

    return scs;
}
