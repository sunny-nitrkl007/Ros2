# JobMgrScsRos2Bridge

## What this is

A small, standalone AIS task whose only job is to maintain the AIS-SCS leg for
5 channels that `LpsSaJobMgrApp` now handles exclusively via ROS2:

| Channel | Direction bridged | Status |
|---|---|---|
| `LpsSaJobMgrReqstChannel` | AIS SCS &rarr; ROS2 | Regression fix (was broken) |
| `LpsSaJobMgrRespChannel`  | ROS2 &rarr; AIS SCS | Regression fix (was broken) |
| `AisJhm2TxChannel`        | AIS SCS &rarr; ROS2 | Regression fix (was broken) |
| `SwitchInputScs`          | AIS SCS &rarr; ROS2 | Newly ported |
| `LpsSaLoadRecordChannel`  | ROS2 &rarr; AIS SCS | Newly ported |

## Why it exists

When `LpsSaJobMgrApp` was ported to publish/subscribe these 3 channels over
ROS2 only, every producer/consumer of these channels that is **still on AIS
SCS** stopped being able to talk to JobMgr:

- `LpsSaJobMgrReqstChannel` producers left stranded: `WorkOrderAssistApp`,
  `hornOnStoreTest`, `AisJhm2RequestProcessor`, and `LpsSaWeighApp`'s own
  `LpsSaScsSendZeroRqst()` call.
- `LpsSaJobMgrRespChannel` consumers left stranded: `AutonomyConditionDiagnostics`,
  `aisXcpServer`, `AisJhm2RequestProcessor`.
- `AisJhm2TxChannel` consumer left stranded: `LpsSaJobMgrApp` itself no longer
  reads the AIS SCS side, so its `simpleCal_` cleanup trigger never fires.

None of these are in scope to modify. This bridge closes the gap without
touching `LpsSaJobMgrApp`, `LpsSaWeighApp`, or any of the affected apps above.

Full analysis: `porting_artefacts/current_refinement.md` (§1).
Full design rationale, including why a bridge was chosen over a revert or a
native dual-publish, and a safety walk-through: `porting_artefacts/plan.md`.

## How it works

One AIS `task::Task`, one ROS2 node, three independent forwarders running
in `executive()`, each in exactly one direction (never both, so no message
loops are possible):

1. **`LpsSaJobMgrReqstChannel` (SCS &rarr; ROS2)**: binds AIS SCS input
   `LpsSaJobMgrReqstChannelInput`, drains it, converts each message, and
   publishes it on ROS2 topic `lps_sa_job_mgr_reqst_channel` (the same topic
   `LpsSaJobMgrApp` already subscribes to).
2. **`LpsSaJobMgrRespChannel` (ROS2 &rarr; SCS)**: subscribes ROS2 topic
   `lps_sa_job_mgr_resp_channel` (the same topic `LpsSaJobMgrApp` already
   publishes to), converts each message, and publishes it on AIS SCS output
   `LpsSaJobMgrRespChannelOutput`.
3. **`AisJhm2TxChannel` (SCS &rarr; ROS2)**: binds AIS SCS input
   `AisJhm2TxChannelInput`, drains it, converts each message, and publishes
   it on ROS2 topic `ais_jhm2_tx_channel` (the same topic `LpsSaJobMgrApp`
   already subscribes to).

Binding the same AIS SCS interface names other processes already bind is
safe -- AIS SCS is a pub/sub bus, not a single-owner pipe (e.g.
`SwitchInputScsInput` already has multiple independent binders today).

## Files

| File | Purpose |
|---|---|
| `JobMgrScsRos2Bridge.h` | Class declaration: 3 AIS SCS interface pointers, ROS2 node/executor, 3 ROS2 wrapper members, 3 static conversion helpers. |
| `JobMgrScsRos2Bridge.cpp` | `initialize()` (bind AIS SCS + set up ROS2), `executive()` (drain-and-forward loop, called at `cycleRate_hz`), `cleanup()`, and the 3 field-by-field conversion functions. |
| `SConscript` | Build file. Copies the ROS2 linking recipe already proven working in `apps/LpsSaJobMgrApp/SConscript` (same `ros2_jazzy_sdk`/`ros2_models` discovery, same rpath handling), minus the `lps_pass_tracker` dependency this bridge doesn't need. |
| `../../config/JobMgrScsRos2Bridge.rb` | Ruby task config: interface bindings + parameters (`cycleRate_hz`, `loggerThreshold`). |

## Registration (already wired in this checkout)

- `apps/SConscript`: `testEnv.buildit('JobMgrScsRos2Bridge', ['suse'])`
- `config/ExecutionTable_CPM.rb`: `"JobMgrScsRos2Bridge" => { "executableName" => "JobMgrScsRos2Bridge", "autoRestart" => true }`
- `config/CommonTasks.rb` (`AuxiliaryProcesses`): entry pointing at `$CAT_DIR/bin/JobMgrScsRos2Bridge`, mirroring the existing `LpsJobMgr`/`LpsWeighing` entries -- this is what actually causes the process to be launched by the AIS process/config manager, same as `LpsSaJobMgrApp`/`LpsSaWeighApp` are launched today.

## What this does NOT change

No file inside `LpsSaJobMgrApp/`, `LpsSaWeighApp/`, `WorkOrderAssist/`,
`hornOnStoreTest/`, `AisJhm2RequestProcessor/`, or
`AutonomyConditionDiagnostics/` is modified. This is a brand-new, independent
process; no existing binary needs to be rebuilt or redeployed.

## Build

Same top-level SCons build as every other app in `apps/` (`scons --apps`,
see `porting_artefacts/kt_and_flow.md` §5). Verify the new binary links
cleanly against the same `ros2_jazzy_sdk`/`ros2_models` paths
`LpsSaJobMgrApp`/`LpsSaWeighApp` already use -- there is no build/deploy
environment available in this analysis session to actually compile it, so
this is the first thing to confirm after checkout.

## Verification order (cheapest/lowest-risk first)

1. **`AisJhm2TxChannel` (SCS&rarr;ROS2)**: confirm `LpsSaJobMgrApp`'s
   `simpleCal_` entries are being erased again on JHM2 dispatch.
2. **`LpsSaJobMgrRespChannel` (ROS2&rarr;SCS)**: trigger a JobMgr command,
   confirm `AutonomyConditionDiagnostics`/`aisXcpServer` see the ack again.
3. **`LpsSaJobMgrReqstChannel` (SCS&rarr;ROS2)**: trigger `LpsSaWeighApp`'s
   zero request, confirm JobMgr receives and acts on it; repeat for
   `WorkOrderAssistApp`/`hornOnStoreTest`/`AisJhm2RequestProcessor`-originated
   requests.

## Confidence & residual risk

High confidence in the design and wiring: every interface name, ROS2 topic
name, message field name/type, and build-recipe detail used here was
verified directly against the source in this repo (both the AIS SCS `.h`
channel definitions and the generated ROS2 message headers under
`ros2_model/install/`) before writing this code -- nothing here is guessed
or copied from documentation alone. The one thing that could not be verified
in this session is an actual compile/run, since no build environment was
available -- treat a first build as the remaining validation step.
