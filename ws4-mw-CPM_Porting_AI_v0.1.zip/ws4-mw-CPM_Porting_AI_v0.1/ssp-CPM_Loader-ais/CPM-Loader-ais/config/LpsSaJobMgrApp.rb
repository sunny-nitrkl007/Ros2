require "commonLoad.rb"
require "commonTaskParams.rb"
require "interfaces_Loaders.rb"
require "interfaces_CpmCommon.rb"
require "Robot.rb"

Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update({
  "LpsSaJobMgrTxChannelOutput" => InterfaceDefs_Loaders::LpsSaJobMgrTxChannelOutput,##write param to UI
  "LpsSaJobMgrReqstChannelInput" => InterfaceDefs_Loaders::LpsSaJobMgrReqstChannelInput, ##getcmd from UI
  "LpsSaJobMgrRespChannelOutput" => InterfaceDefs_Loaders::LpsSaJobMgrRespChannelOutput,##setRes to UI
  "LpsSaJobMgrDebugChannelOutput" => InterfaceDefs_Loaders::LpsSaJobMgrDebugChannelOutput,##Debug
  "LpsSaWeighReqstChannelOutput" => InterfaceDefs_Loaders::LpsSaWeighReqstChannelOutput,##setCmd to weighing App
  "LpsSaWeighRespChannelInput" => InterfaceDefs_Loaders::LpsSaWeighRespChannelInput,##getRes from weighing App
  "LpsSaWeighTxChannelInput" => InterfaceDefs_Loaders::LpsSaWeighTxChannelInput,##get parameters from weighing app
  ## SwitchInputScsInput removed -- now ROS2-only (bridge: switch_input_scs topic)
  "OutputChannelOutput" => InterfaceDefs_CpmCommon::OutputChannelOutput,
  "AisJhm2TxChannelInput" => InterfaceDefs_Loaders::AisJhm2TxChannelInput,
  "DisplayStateInput" => InterfaceDefs_Loaders::LpsSaUIDisplayStateInputChannel,
  "ShmClockInput" => InterfaceDefs::ShmClockInput,
  ## LoadRecordOutput removed -- now ROS2-only (bridge: lps_sa_load_record_channel topic)
  "DataLinkDataInput" => InterfaceDefs_CpmCommon::DataLinkDataInput,
  "AutonomyConditionDiagnosticsTxChannelInput"  => InterfaceDefs_Loaders::AutonomyConditionDiagnosticsTxInputChannel,
  "EventDiagnosticDataInput" => InterfaceDefs::EventDiagnosticDataInput,
})

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update( {
  "loggerThreshold" => "error",  ##  All options listed in descending severity order
                                 ##  - emerg, fatal, alert, crit, error, warn, notice, info, debug 

  "cycleRate_hz" => 10.0, #every 100 ms changed to match with ACD App
  "scheduler" => "SCHED_RR",
  "schedulerPriority" => 1,
  "SimpleCalMaxTrucksSupported" => 15,  ## Maximum number of trucks supported for simple cal.
  "storageRoot" => "/opt/appdata/CPM/LpsSaJobMgrApp/nvm"
})

Execution = {
    "executableName" => "LpsSaJobMgrApp",
}

