require "commonLoad.rb"
require "commonTaskParams.rb"
require "interfaces_Loaders.rb"
require "interfaces_CpmCommon.rb"

# Binds the same AIS SCS interface names other processes already bind
# independently (e.g. SwitchInputScsInput has multiple binders today) --
# see porting_artefacts/plan.md for why this is safe.
Interfaces = CommonTaskParams::Interfaces.dup;
Interfaces.update({
  # Original 3 regression-fix channels
  "LpsSaJobMgrReqstChannelInput" => InterfaceDefs_Loaders::LpsSaJobMgrReqstChannelInput,
  "LpsSaJobMgrRespChannelOutput" => InterfaceDefs_Loaders::LpsSaJobMgrRespChannelOutput,
  "AisJhm2TxChannelInput"        => InterfaceDefs_Loaders::AisJhm2TxChannelInput,
  # Newly ported channels
  "SwitchInputScsInput"          => InterfaceDefs_CpmCommon::SwitchInputScsInput,
  "LoadRecordOutput"             => InterfaceDefs_Loaders::LpsSaLoadRecordChannelOutput,
})

Parameters = CommonTaskParams::Parameters.dup;
Parameters.update({
  "loggerThreshold" => "error",  ##  All options listed in descending severity order
                                 ##  - emerg, fatal, alert, crit, error, warn, notice, info, debug

  "cycleRate_hz" => 20.0, # fast enough that operator-facing command/ack latency through this bridge is not user-visible
})

Execution = {
    "executableName" => "JobMgrScsRos2Bridge",
}
